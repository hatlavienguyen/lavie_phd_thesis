The model can be opened by dragging "1.8Ga_submit.gproj" into GPlates 2
