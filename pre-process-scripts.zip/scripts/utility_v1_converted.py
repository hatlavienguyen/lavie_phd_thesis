import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import numpy as np
import geopandas as gpd
from geopandas.tools import sjoin
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap 
from mpl_toolkits.axes_grid1 import host_subplot
import matplotlib.pyplot as plt
import math

#convert gpml file to shp file 
def convert_gpml_to_shp(path_and_name_of_gpml_file,output_filename):
	print("Here is path_and_name_of_gpml_file:")
	print(path_and_name_of_gpml_file)
	old_FeatureCollection = pygplates.FeatureCollection.read(path_and_name_of_gpml_file)
	new_FeatureCollection = pygplates.FeatureCollection()
	for ft in old_FeatureCollection:
		new_FeatureCollection.add(ft)
	output_filename = output_filename+".shp"
	new_FeatureCollection.write(output_filename)

#convert shp file to gpml file 
def convert_shp_to_gpml(path_and_name_of_shp_file,output_filename):
	print("Here is path_and_name_of_shp_file:")
	print(path_and_name_of_shp_file)
	old_FeatureCollection = pygplates.FeatureCollection.read(path_and_name_of_shp_file)
	new_FeatureCollection = pygplates.FeatureCollection()
	for ft in old_FeatureCollection:
		new_FeatureCollection.add(ft)
	output_filename = output_filename+".gpml"
	new_FeatureCollection.write(output_filename)

#define a function or a module to read a shapefile 
def read_gpml_or_shapefile(path_to_a_shp_or_gpml):
	print('Here is an input shapefile or gpml:')
	print(path_to_a_shp_or_gpml)
	new_FeatureCollection = pygplates.FeatureCollection.read(path_to_a_shp_or_gpml)
	print('Sucessfully read the input file')
	return new_FeatureCollection

def read_rot_file(path_to_a_rot_file):
	print('Here is an input path_to_a_rot_file:')
	print(path_to_a_rot_file)
	rotation_model = pygplates.RotationModel(path_to_a_rot_file)
	print('Sucessfully read the input file')
	return rotation_model

#define a function or a module to reconstruct features in FeatureCollection to a specific time
def reconstruct_features_to_specific_time_from_present(features_collection, rotation_model, reconstruction_time, reference):
	reconstructed_result = []
	print('Number of features to be reconstructed')
	print(len(features_collection))
	print('Call pygplates.reconstruct')
	if (reference is None): 
	#if there is no specific reference that needs to be specify like spin axis or mantle 
		pygplates.reconstruct(features_collection,\
								rotation_model,\
								reconstructed_result,\
								reconstruction_time,\
								group_with_feature = True)
	else:
	#if there is specific reference that needs to be specify like spin axis or mantle 
		pygplates.reconstruct(features_collection,\
								rotation_model,\
								reconstructed_result,\
								reconstruction_time,\
								anchor_plate_id = reference,\
								group_with_feature = True)
	#because we specifically indicate group_with_feature = True
	#pygplates will reconstruct features in features_collection to the reconstruction time
	#reconstruted features are stored in reconstructed_result
	#reconstructed_result is a list of tuples
	#each tuple has a format (feature, reconstructed_feature_geometries)
	print('Finished features_collection')
	print('the number of features in reconstructed_result')
	print(len(reconstructed_result))
	return(reconstructed_result)
	

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def get_midpoint_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_last_point_of_line is None")
		exit()
	if (len(polyline_on_sphere.to_lat_lon_list()) == 2):
		mid_point = polyline_on_sphere.get_centroid()
		return mid_point
	else:
		mid_point_index = int(len(polyline_on_sphere.to_lat_lon_list())/2)
		return pygplates.PointOnSphere(polyline_on_sphere[mid_point_index])

	
#A function to calculate the distance between two points on the sphere - specifically the Earth 
#I could have used haversine module for python, but for the purpose of practise, I do it myself
#According to the formula from https://www.igismap.com/haversine-formula-calculate-geographic-distance-earth/, 
#a = sin^2(Difference in latitudes/2)+cos(lat1)*cos(lat2)*sin^2(Difference in longitude/2)
#c = 2*atan2(sqrt(a),sqrt(1-a))
#d = Radius of the sphere * c
def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def calculate_the_actual_length_of_a_line_in_km(current_line):
	if (current_line is None):
		print ("Error in calculate_the_actual_length_of_a_line_feature_in_km")
		print ("Error input line is None")
		exit()
	else:#if line is NOT None
		current_first_point = get_first_point_of_line(current_line)	
		current_last_point = get_last_point_of_line(current_line)
		lat1,lon1 = current_first_point.to_lat_lon()
		lat2,lon2 = current_last_point.to_lat_lon()
		list_of_nodes = current_line.to_lat_lon_list()
		current_length = 0.0
		for i in range(0,len(list_of_nodes)-1):
			j = i + 1
			node_1 = list_of_nodes[i]
			lat1,lon1 = node_1
			node_2 = list_of_nodes[j]
			lat2,lon2 = node_2
			dist = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
			current_length = current_length + dist
		return current_length

#define a function or a module to extract reconstructed geometry from reconstructed_result 
def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = mean(lat_values)
				mean_lon = mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		count_invalid_line = 0.00
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
			else:
				count_invalid_line = count_invalid_line + 1
		print("number_of_invalid_lines", count_invalid_line)
	return list_of_final_reconstructed_geometries
	
#define a function to create reconstructable features from list of tuples of (feature, reconstructed_geometry)
def create_reconstructable_feature_geometries(list_of_final_reconstructed_geometries, rotation_model, reconstruction_time,reference):
	#a storage to store a new feature
	list_of_new_features = []
	for (feature, reconstructed_geometry) in list_of_final_reconstructed_geometries:
		#from feature obtain
		original_PlateID_or_GDU_ID = feature.get_reconstruction_plate_id() 
		original_name = feature.get_name()
		featType = pygplates.FeatureType.gpml_continental_crust
		if (reference is None):
			new_Feature = pygplates.Feature.create_reconstructable_feature(featType,\
																		reconstructed_geometry,\
																		valid_time = (reconstruction_time,0.0),\
																		reconstruction_plate_id = 0)
			new_Feature.set_name(original_name)
			new_Feature.set_reconstruction_plate_id(original_PlateID_or_GDU_ID)
			pygplates.reverse_reconstruct(new_Feature,rotation_model,reconstruction_time)
			list_of_new_features.append(new_Feature)
		else:
			new_Feature = pygplates.Feature.create_reconstructable_feature(featType,\
																		reconstructed_geometry,\
																		valid_time = (reconstruction_time,0.0),\
																		reconstruction_plate_id = reference)
			new_Feature.set_name(original_name)
			new_Feature.set_reconstruction_plate_id(original_PlateID_or_GDU_ID)																
			pygplates.reverse_reconstruct(new_Feature,rotation_model,reconstruction_time,reference)
			list_of_new_features.append(new_Feature)
	return list_of_new_features

#define a function to write the output through FeatureCollection
def write_output_features(list_of_new_features,filename,mmddyy):
	outputFeatureCollection = pygplates.FeatureCollection(list_of_new_features)
	final_filename = filename+"_"+mmddyy+".shp"
	print('name of the output filename')
	print(final_filename)
	outputFeatureCollection.write(final_filename)
	print('Sucessfully write the outputfile as the shapefile')
	final_filename = filename+"_"+mmddyy+".gpml"
	print('name of the output filename')
	print(final_filename)
	outputFeatureCollection.write(final_filename)
	print('Sucessfully write the outputfile as the gpml')

def read_multiple_feature_files(name_of_feature_file,from_time,to_time,interval,yyyymmdd_of_input_files):
	list_of_new_features = []
	current_time = from_time
	while (current_time > (to_time)):
		print(current_time)
		filename = name_of_feature_file+"__"+str(current_time)+"_"+str(current_time - (interval*4))+"_"+str(interval)+"Ma_"+yyyymmdd_of_input_files+".gpml"
		new_FeatureCollection = pygplates.FeatureCollection(filename)
		for ft in new_FeatureCollection:
			list_of_new_features.append(ft)
		current_time = current_time - (interval*4)
		print("after_update")
		print(current_time)
	output_filename = "combined_files_tectonic_boundaies"+"_"+str(from_time)+"_"+str(to_time)+"_"+str(interval)+"Ma"
	write_output_features(list_of_new_features,output_filename,yyyymmdd_of_input_files)

def convert_possible_convergent_boundaries_features_to_permanent_features(feature_file, name, yyyymmdd, include_shp):
	features_collection = pygplates.FeatureCollection(feature_file)
	output_permanent_fts = []
	for ft in features_collection:
		geometry_of_convergent_boundary = ft.get_geometry()
		if (geometry_of_convergent_boundary is None):
			print('Error in convert_possible_boundaries_features_to_permanent_features')
			print('geometry_of_convergent_boundary is None')
			print('ft.get_geometries()')
			print(ft.get_geometries())
			exit()
		if (ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone or ft.get_feature_type() == pygplates.FeatureType.gpml_closed_continental_boundary):
			featType = pygplates.FeatureType.gpml_subduction_zone
			new_convergent_ft = pygplates.Feature.create_reconstructable_feature(featType,geometry_of_convergent_boundary,name = ft.get_name(), valid_time = ft.get_valid_time(), reconstruction_plate_id = ft.get_reconstruction_plate_id())
			new_convergent_ft.set_description('upper_plate_margin')
			output_permanent_fts.append(new_convergent_ft)
	#create a new gpml file or shapefile
	outputFeatureCollection = pygplates.FeatureCollection(output_permanent_fts)
	if (include_shp == True):
		outputFile = "convert_possible_boundaries_features_to_permanent_features_"+name+"_"+yyyymmdd+".shp"
		outputFeatureCollection.write(outputFile)
	outputFile = "convert_possible_boundaries_features_to_permanent_features_"+name+"_"+yyyymmdd+".gpml"
	outputFeatureCollection.write(outputFile)

def convert_possible_CON_OCN_div_boundaries_features_to_permanent_features(feature_file, name, yyyymmdd, include_shp):
	features_collection = pygplates.FeatureCollection(feature_file)
	output_permanent_fts = []
	for ft in features_collection:
		geometry_of_convergent_boundary = ft.get_geometry()
		if (geometry_of_convergent_boundary is None):
			print('Error in convert_possible_boundaries_features_to_permanent_features')
			print('geometry_of_convergent_boundary is None')
			print('ft.get_geometries()')
			print(ft.get_geometries())
			exit()
		if (ft.get_feature_type() == pygplates.FeatureType.gpml_closed_continental_boundary):
			featType = pygplates.FeatureType.gpml_passive_continental_boundary
			new_margin_ft = pygplates.Feature.create_reconstructable_feature(featType,geometry_of_convergent_boundary,name = ft.get_name(), valid_time = ft.get_valid_time(), reconstruction_plate_id = ft.get_reconstruction_plate_id())
			descr = ft.get_description()
			new_margin_ft.set_description(descr)
			output_permanent_fts.append(new_margin_ft)
	#create a new gpml file or shapefile
	outputFeatureCollection = pygplates.FeatureCollection(output_permanent_fts)
	if (include_shp == True):
		outputFile = "convert_possible_CON_OCN_div_boundaries_features_to_permanent_features"+name+"_"+yyyymmdd+".shp"
		outputFeatureCollection.write(outputFile)
	outputFile = "convert_possible_CON_OCN_div_boundaries_features_to_permanent_features"+name+"_"+yyyymmdd+".gpml"
	outputFeatureCollection.write(outputFile)
	
def generate_list_of_filenames_to_combine_multiple_tectonic_boundaries_features(common_name_for_output_files,modelname,threshold,yyyymmdd,begin,end,interval,output_freq,fileformat):
	time = begin
	list_of_filename = []
	list_of_temporal_fts = []
	list_of_final_fts = []
	already_proccessed_ft = []
	output_features = []
	while (time > end):
		print('time')
		print(time)
		next_time = time - (interval * output_freq)
		if (next_time < end):
			next_time = end 
		print('next_time')
		print(next_time)
		#tectonic_boundaries_features_test_5_for_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_800km__170.0_150.0_5Ma_20210204.gpml
		txt = """{input_common_name_for_output_files}_{input_modelname}_{input_threshold}km__{input_begin}_{input_end}_{input_interval}Ma_{input_yyyymmdd}.{input_fileformat}"""
		final_filename = txt.format(input_common_name_for_output_files = common_name_for_output_files, input_modelname = modelname, input_threshold = threshold, input_begin = str(time), input_end = str(next_time), input_interval = str(interval), input_yyyymmdd = yyyymmdd, input_fileformat = fileformat)
		print('final_filename')
		print(final_filename)
		list_of_filename.append(final_filename)
		
		time = next_time
	return(list_of_filename)

def generate_list_of_csv_filenames(common_name_for_output_files, test_number, type_of_tectonic_margin, modelname, yyyymmdd, begin, end, interval, fileformat):
	#length_of_topological_con_ocn_margins_output_csv_file_400.0_11_con_ocn_margins_from_PalaePlates2020__20210905
	age = begin
	list_of_filename = []
	while (age > (end - interval)):
		print('age')
		print(age)
		txt = """{input_common_name_for_output_files}_{input_age}_{input_test_number}_{input_type_of_tectonic_margin}_from_{input_modelname}__{input_yyyymmdd}.{input_fileformat}"""
		final_filename = txt.format(input_common_name_for_output_files = common_name_for_output_files, input_age = str(age), input_test_number = str(test_number), input_type_of_tectonic_margin = type_of_tectonic_margin, input_modelname = modelname, input_yyyymmdd = yyyymmdd, input_fileformat = fileformat)
		print('final_filename')
		print(final_filename)
		list_of_filename.append(final_filename)
		age = age - interval
	return(list_of_filename)
	
def combine_multiple_shapefile_or_gpml_files(featType,list_of_filenames,include_shp,name,yyyymmdd):
	#it does not matter whether they are all shapefile or gpml files 
	final_list_of_features = []
	for filename in list_of_filenames:
		print(filename)
		temp_FeatureCollection = pygplates.FeatureCollection(filename)
		print('number of features in FeatureCollection')
		print(len(temp_FeatureCollection))
		for ft in temp_FeatureCollection:
			if (featType is not None):
				if (ft.get_feature_type() == featType):
					clone = ft.clone()
					final_list_of_features.append(clone)
			else:
				clone = ft.clone()
				final_list_of_features.append(clone)
	#create a new gpml file or shapefile
	outputFeatureCollection = pygplates.FeatureCollection(final_list_of_features)
	if (include_shp == True):
		outputFile = "combined_files"+name+"_"+yyyymmdd+".shp"
		outputFeatureCollection.write(outputFile)
	
	outputFile = "combined_files"+name+"_"+yyyymmdd+".gpml"
	outputFeatureCollection.write(outputFile)

def filter_features_with_valid_period_smaller_than_thresold(features_file,threshold_period,name_of_outputfile,included_shp,yyyymmdd):
	final_output_features = []
	feature_collection = pygplates.FeatureCollection(features_file)
	for ft in feature_collection:
		ft_begin_age, ft_end_age = ft.get_valid_time()
		if (ft_begin_age - ft_end_age >= threshold_period):
			final_output_features.append(ft)
	outputFeatureCollection = pygplates.FeatureCollection(final_output_features)
	outputFeatureCollection.write(name_of_outputfile+"_"+yyyymmdd+".gpml")
	if (included_shp == True):
		outputFeatureCollection.write(name_of_outputfile+"_"+yyyymmdd+".shp")

def extract_features_based_on_GDU_ID(filename,list_of_GDU_ID,modelname,mmddyy,include_shp):
	features_collection = pygplates.FeatureCollection(filename)
	wanted_features = features_collection.get(
		lambda feature: feature.get_reconstruction_plate_id() in list_of_GDU_ID, pygplates.FeatureReturn.all)
	outputFeatureCollection = pygplates.FeatureCollection(wanted_features)
	if (include_shp == True):
		outputFile = "extracted_features"+modelname+"_"+mmddyy+".shp"
		outputFeatureCollection.write(outputFile)
	
	outputFile = "extracted_features"+modelname+"_"+mmddyy+".gpml"
	outputFeatureCollection.write(outputFile)

def extract_features_based_on_reconstruction_time(filename,from_time,to_time,interval,modelname,mmddyy,include_shp):
	features_collection = pygplates.FeatureCollection(filename)
	reconstruction_time = from_time
	wanted_features = []
	already_included_fts_id = []
	while(reconstruction_time > (to_time - interval)):
		for ft in features_collection:
			if (ft.get_feature_id() not in already_included_fts_id):
				if (ft.is_valid_at_time(reconstruction_time)):
					already_included_fts_id.append(ft.get_feature_id())
					wanted_features.append(ft)
		#update reconstruction_time
		reconstruction_time = reconstruction_time - interval
	print("number of wanted_features")
	print(len(wanted_features))
	outputFeatureCollection = pygplates.FeatureCollection(wanted_features)
	if (include_shp == True):
		outputFile = "extracted_features_"+str(from_time)+"_"+str(to_time)+"_"+modelname+"_"+mmddyy+".shp"
		outputFeatureCollection.write(outputFile)
	outputFile = "extracted_features_"+str(from_time)+"_"+str(to_time)+"_"+modelname+"_"+mmddyy+".gpml"
	outputFeatureCollection.write(outputFile)
	
def extract_features_based_on_PlateID_of_other_feature_collection(filename_of_features_to_be_extracted,filename_of_reference_features,modelname):
	features_to_be_extracted = pygplates.FeatureCollection(filename_of_features_to_be_extracted)
	reference_features = pygplates.FeatureCollection(filename_of_reference_features)
	results = []
	for ref_ft in reference_features:
		plate_id = ref_ft.get_reconstruction_plate_id()
		for ft in features_to_be_extracted:
			if (ft.get_reconstruction_plate_id() == plate_id):
				results.append(ft)
	outputFeatureCollection = pygplates.FeatureCollection(results)
	outputFile = "extract_features_based_on_PlateID_of_other_feature_collection_"+modelname+".shp"
	outputFeatureCollection.write(outputFile)
	outputFile = "extract_features_based_on_PlateID_of_other_feature_collection_"+modelname+".gpml"
	outputFeatureCollection.write(outputFile)

def extract_features_based_on_geometry(filename_of_features_to_be_extracted, geometry_type, modelname, yyyymmdd):
	features_to_be_extracted = pygplates.FeatureCollection(filename_of_features_to_be_extracted)
	results = []
	for ft in features_to_be_extracted:
		if (type(ft.get_geometry()) == geometry_type):
			results.append(ft)
	outputFeatureCollection = pygplates.FeatureCollection(results)
	outputFile = "extract_features_based_on_geometry_"+modelname+"_"+yyyymmdd+".shp"
	outputFeatureCollection.write(outputFile)
	outputFile = "extract_features_based_on_geometry_"+modelname+"_"+yyyymmdd+".gpml"
	outputFeatureCollection.write(outputFile)

def extract_features_based_on_featureType(filename_of_features_to_be_extracted, featType, modelname, yyyymmdd):
	features_to_be_extracted = pygplates.FeatureCollection(filename_of_features_to_be_extracted)
	results = []
	for ft in features_to_be_extracted:
		if (ft.get_feature_type() == featType):
			results.append(ft)
	outputFeatureCollection = pygplates.FeatureCollection(results)
	outputFile = "extract_features_based_on_featType_"+modelname+"_"+yyyymmdd+".shp"
	outputFeatureCollection.write(outputFile)
	outputFile = "extract_features_based_on_featType_"+modelname+"_"+yyyymmdd+".gpml"
	outputFeatureCollection.write(outputFile)

def extract_features_based_on_description(filename_of_features_to_be_extracted, values_for_description, modelname, yyyymmdd):
	features_to_be_extracted = pygplates.FeatureCollection(filename_of_features_to_be_extracted)
	results = []
	for ft in features_to_be_extracted:
		if (ft.get_description() in values_for_description):
			results.append(ft)
	outputFeatureCollection = pygplates.FeatureCollection(results)
	outputFile = "extract_features_based_on_description"+modelname+"_"+yyyymmdd+".shp"
	outputFeatureCollection.write(outputFile)
	outputFile = "extract_features_based_on_description"+modelname+"_"+yyyymmdd+".gpml"
	outputFeatureCollection.write(outputFile)

def extract_features_based_on_a_shp_field(filename_of_features_to_be_extracted, name_of_shp_field, values_for_the_field, modelname, yyyymmdd):
	features_to_be_extracted = pygplates.FeatureCollection(filename_of_features_to_be_extracted)
	results = []
	for ft in features_to_be_extracted:
		print(ft.get_shapefile_attribute(name_of_shp_field))
		if (ft.get_shapefile_attribute(name_of_shp_field) in values_for_the_field):
			results.append(ft)
	print(results)
	outputFeatureCollection = pygplates.FeatureCollection(results)
	outputFile = "extract_features_based_on_"+name_of_shp_field+"_"+modelname+"_"+yyyymmdd+".shp"
	outputFeatureCollection.write(outputFile)

def extract_features_based_on_a_shp_field(filename_of_features_to_be_extracted, name_of_shp_field, value, modelname, yyyymmdd):
	dataframe = gpd.read_file(filename_of_features_to_be_extracted) 
	selected_records = dataframe.loc[dataframe[name_of_shp_field] == value]
	outputFile = "extract_features_based_on_"+name_of_shp_field+"_"+modelname+"_"+yyyymmdd+".shp"
	selected_records.to_file(outputFile)

def extract_features_which_were_not_yet_proccessed(initial_input_features, features_were_already_processed, output_filename, yearmonthday):
	# dic = {}
	# output_features = pygplates.FeatureCollection()
	# for already_proccessed_ft in features_were_already_processed:
		# dic[already_proccessed_ft.get_name()] = None
	# for ft in initial_input_features:	
		# if (ft.get_feature_id().get_string() not in dic):
			# output_features.add(ft)
	# final_output_filename = output_filename + "_" + yearmonthday + ".gpml"
	# output_features.write(final_output_filename)
	# final_output_filename = output_filename + "_" + yearmonthday + ".shp"
	# output_features.write(final_output_filename)
	
	output_features = pygplates.FeatureCollection()
	for ft in initial_input_features:	
		geometry = ft.get_geometry()
		gdu_id = ft.get_reconstruction_plate_id()
		included = False
		for already_proccessed_ft in features_were_already_processed:
			already_proccessed_geom	 = already_proccessed_ft.get_geometry()
			already_gdu_id = already_proccessed_ft.get_reconstruction_plate_id()
			if (geometry == already_proccessed_geom and already_gdu_id == gdu_id):
				included = True
				break
		if (included == False):
			output_features.add(ft)
	final_output_filename = output_filename + "_" + yearmonthday + ".gpml"
	output_features.write(final_output_filename)
	final_output_filename = output_filename + "_" + yearmonthday + ".shp"
	output_features.write(final_output_filename)



def edit_end_time_of_each_features_based_of_age_interval(filename,age_interval,from_time_input_file,to_time_input_file,yyyymmdd_of_input_file):
	features_collection = pygplates.FeatureCollection(filename)
	for ft in features_collection:
		begin_age,end_age = ft.get_valid_time()
		new_end_age = begin_age - age_interval + 0.0500
		ft.set_valid_time(begin_age,new_end_age)
	outputFile = "edit_end_age_for_features_"+str(from_time_input_file)+"_"+str(to_time_input_file)+"_"+str(age_interval)+"_"+yyyymmdd_of_input_file+".shp"
	features_collection.write(outputFile)
	outputFile = "edit_end_age_for_features_"+str(from_time_input_file)+"_"+str(to_time_input_file)+"_"+str(age_interval)+"_"+yyyymmdd_of_input_file+".gpml"
	features_collection.write(outputFile)

def pre_process_polygon_features_from_shp_file(list_of_polygon_GDU_fts,modelname,yearmonthday,write_ouput):
	list_of_processed_polygon_features = []
	featType = pygplates.FeatureType.gpml_continental_crust
	for polygon_ft in list_of_polygon_GDU_fts:
		#obtain the geometries of a polygon ft_begin_age
		polygons = polygon_ft.get_geometries()
		#choose the polygon that have the most points
		final_polygon = None
		number_of_points = 0
		for each_polygon in polygons:
			current_number_of_points = len(each_polygon.to_lat_lon_list())
			if (current_number_of_points > number_of_points):
				final_polygon = each_polygon
				number_of_points = current_number_of_points
		#once we have a final polygon with the most points we want to create a dateline wrapper for the polygons,if it is required
		# Wrap a polygon to the range [-180, +180].
		date_line_wrapper = pygplates.DateLineWrapper()
		wrapped_polygons = date_line_wrapper.wrap(final_polygon)
		for wrapped_polygon in wrapped_polygons:
			#print 'value of wrapped_polygon'
			#print wrapped_polygon
			new_polygon = pygplates.PolygonOnSphere(wrapped_polygon.get_exterior_points())
			#create a new polygon feature for each wrapped polygon
			new_polygon_ft = pygplates.Feature.create_reconstructable_feature(featType,new_polygon,valid_time = polygon_ft.get_valid_time(), reconstruction_plate_id = polygon_ft.get_reconstruction_plate_id())
			list_of_processed_polygon_features.append(new_polygon_ft)
			#for wrapped_point in wrapped_polygon.get_exterior_points():
			#	wrapped_point_lat_lon = wrapped_point.get_latitude(), wrapped_point.get_longitude()
	if (write_ouput == True):
		outputFeatureCollection = pygplates.FeatureCollection(list_of_processed_polygon_features)
		outputFeatureFile = './pre_processed_polygon_fts_'+modelname+'_'+yearmonthday+'.shp'
		outputFeatureCollection.write(outputFeatureFile)
		outputFeatureFile = './pre_processed_polygon_fts_'+modelname+'_'+yearmonthday+'.gpml'
		outputFeatureCollection.write(outputFeatureFile)
	return list_of_processed_polygon_features
	
def test():
	point = pygplates.PointOnSphere((30.00,10.00))
	if (type(point) is pygplates.PointOnSphere):
		print('Point')
		return True
	else:
		print('Does not recognize')
		return False 

#A function to calculate the distance between two points on the sphere - specifically the Earth 
#I could have used haversine module for python, but for the purpose of practise, I do it myself
#According to the formula from https://www.igismap.com/haversine-formula-calculate-geographic-distance-earth/, 
#a = sin^2(Difference in latitudes/2)+cos(lat1)*cos(lat2)*sin^2(Difference in longitude/2)
#c = 2*atan2(sqrt(a),sqrt(1-a))
#d = Radius of the sphere * c
def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance	

def calculate_distance_between_polygons(input_features_file,rotation_file,reconstruction_time,reference):
	input_features = pygplates.FeatureCollection(input_features_file)
	rotation_model = pygplates.RotationModel(rotation_file)
	reconstructed_GDU_polygon_features = []
	if (reference is not None):
		pygplates.reconstruct(input_features,rotation_model,reconstructed_GDU_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(input_features,rotation_model,reconstructed_GDU_polygon_features,reconstruction_time,group_with_feature = True)
	final_reconstructed_GDU_polygon_fts = find_final_reconstructed_geometries(reconstructed_GDU_polygon_features,pygplates.PolygonOnSphere)
	for polygon_ft,polygon in final_reconstructed_GDU_polygon_fts:
		ft_id_1 = polygon_ft.get_feature_id()
		for other_polygon_ft,other_polygon in final_reconstructed_GDU_polygon_fts:
			ft_id_2 = other_polygon_ft.get_feature_id()
			if (ft_id_1 != ft_id_2):
				#find the two closest between these two polygons
				distance,point_on_polygon_1,point_on_polygon_2 =  pygplates.GeometryOnSphere.distance(polygon, other_polygon, return_closest_positions=True)
				lat1,lon1 = point_on_polygon_1.to_lat_lon()
				lat2,lon2 = point_on_polygon_2.to_lat_lon()
				distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
				print('Reconstruction plate id & SuperGDU id of polygon_ft and other_polygon_ft')
				print(polygon_ft.get_reconstruction_plate_id(),polygon_ft.get_name())
				print(other_polygon_ft.get_reconstruction_plate_id(),other_polygon_ft.get_name())
				print('Here is value of distance in km')
				print(distance_in_km)

def plot_histogram_duration_area_of_SuperGDU_features(SuperGDU_fts_w_duration_shp, from_time_input_file, to_time_input_file):
	SuperGDU_features = gpd.read_file(SuperGDU_fts_w_duration_shp)
	duration = SuperGDU_features['Duration'].unique()

	# make a custom colormap with transparency
	# ncolors = 256
	# color_array = plt.get_cmap('YlOrRd')(range(ncolors))
	# color_array[:, -1] = np.linspace(0, 1, ncolors)
	# cmap = LinearSegmentedColormap.from_list(name='YlOrRd', colors=color_array)

	fig,ax = plt.subplots()
	plot_title = 'Duration_of_SuperGDU_features_'+str(from_time_input_file)+"_"+str(to_time_input_file)
	plt.title(plot_title)
	ax.set_xlabel('Duration of SuperGDU in Ma')
	plt.hist(duration)
	#plt.hist2d(time_steps, distance_overtime, bins = [100, 100])
	#plt.colorbar()
	plt.show()

def plot_histogram_area_of_SuperGDU_features_within_period(each_SuperGDU_area_overtime_csv, from_time_input_file, to_time_input_file):
	dataframe = pd.read_csv(each_SuperGDU_area_overtime_csv, sep = ',', header = 0)
	area = dataframe['total_area']

	# make a custom colormap with transparency
	# ncolors = 256
	# color_array = plt.get_cmap('YlOrRd')(range(ncolors))
	# color_array[:, -1] = np.linspace(0, 1, ncolors)
	# cmap = LinearSegmentedColormap.from_list(name='YlOrRd', colors=color_array)

	fig,ax = plt.subplots()
	plot_title = 'Area_of_each_SuperGDU_feature_'+str(from_time_input_file)+"_"+str(to_time_input_file)
	plt.title(plot_title)
	ax.set_xlabel('Area of each SuperGDU feature')
	ax.set_ylabel('Number of SuperGDUs')
	plt.hist(area,bins = 100)
	#plt.hist2d(time_steps, distance_overtime, bins = [100, 100])
	#plt.colorbar()
	plt.show()

def plot_time_series_histogram_duration_area_of_SuperGDU_features(SuperGDU_fts_w_duration_shp, from_time_input_file, to_time_input_file, interval_input_file, density):
	fig,ax = plt.subplots()
	SuperGDU_features = gpd.read_file(SuperGDU_fts_w_duration_shp)
	duration = SuperGDU_features['Duration']
	#_,overall_bin_edges = np.histogram(duration,bin = 'fd') #'fd' stands for Freedman Diaconis Estimator - consider data variability and data size
	reconstruction_time = from_time_input_file
	tuples_of_time_duration_num_of_observations = []
	while(reconstruction_time > (to_time_input_file - interval_input_file)):
		series = SuperGDU_features.loc[(SuperGDU_features['FROMAGE'] > reconstruction_time)&(SuperGDU_features['TOAGE'] <= reconstruction_time),'Duration']
		#calculate the histogram
		if (density == True):
			hist,bin_edges = np.histogram(series, bins = 10, density = True) #probability density function
			for i in range(len(hist)):
				pdf = hist[i]
				duration_min = bin_edges[i]
				tuples_of_time_duration_num_of_observations.append((reconstruction_time,duration_min,pdf))
				if (i == (len(hist) - 1)):
					duration_max = bin_edges[i+1]
					tuples_of_time_duration_num_of_observations.append((reconstruction_time,duration_max,pdf))
		else:
			hist,bin_edges = np.histogram(series, bins = 10, density = False)
			for i in range(len(hist)):
				number_of_observations = hist[i]
				duration_min = bin_edges[i]
				tuples_of_time_duration_num_of_observations.append((reconstruction_time,duration_min,number_of_observations))
				if (i == (len(hist) - 1)):
					duration_max = bin_edges[i+1]
					tuples_of_time_duration_num_of_observations.append((reconstruction_time,duration_max,number_of_observations))
		#updated reconstruction_time
		reconstruction_time = reconstruction_time - interval_input_file
	#create a new dataframe
	new_dataframe = None
	if (density == True):
		new_dataframe = pd.DataFrame.from_records(tuples_of_time_duration_num_of_observations, columns= ['reconstruction_time','duration','pdf'])
	else:
		new_dataframe = pd.DataFrame.from_records(tuples_of_time_duration_num_of_observations, columns= ['reconstruction_time','duration','number_of_observations'])
	#print(new_dataframe)
	print("number of SuperGDU with duration > 160:")
	print(len(SuperGDU_features[SuperGDU_features['Duration'] >= 160.00]))
	print(new_dataframe[new_dataframe['reconstruction_time'] == 195.00])
	print(new_dataframe[new_dataframe['reconstruction_time'] == 15.00])
	# make a custom colormap with transparency
	# ncolors = 256
	# color_array = plt.get_cmap('YlOrRd')(range(ncolors))
	# color_array[:, -1] = np.linspace(0, 1, ncolors)
	# cmap = LinearSegmentedColormap.from_list(name='YlOrRd', colors = color_array)
	if (density == True):
		plt.scatter(new_dataframe['reconstruction_time'], new_dataframe['duration'], c = new_dataframe['pdf'])
		ax.set_xlabel('Reconstruction time in Ma')
		ax.set_ylabel('Duration in Ma')
		cbar = plt.colorbar()
		cbar.set_label('Probability Density Function')
	else:
		plt.scatter(new_dataframe['reconstruction_time'], new_dataframe['duration'], c = new_dataframe['number_of_observations'])
		ax.set_xlabel('Reconstruction time in Ma')
		ax.set_ylabel('Duration in Ma')
		cbar = plt.colorbar()
		cbar.set_label('Number of observations')
	plt.show()

def plot_time_series_histogram_of_continental_area(each_SuperGDU_area_overtime_csv, from_time_input_file, to_time_input_file, interval_input_file, density):
	fig,ax = plt.subplots()
	dataframe = pd.read_csv(each_SuperGDU_area_overtime_csv, sep = ',', header = 0)
	
	print("number of SuperGDU with area == 0.00")
	print(len(dataframe[dataframe['total_area'] == 0.00]))
	
	#_,overall_bin_edges = np.histogram(duration,bin = 'fd') #'fd' stands for Freedman Diaconis Estimator - consider data variability and data size
	reconstruction_time = from_time_input_file
	tuples_of_time_area_num_of_observations = []
	while(reconstruction_time > (to_time_input_file - interval_input_file)):
		series = dataframe.loc[(dataframe['reconstruction_time'] == reconstruction_time),'total_area']
		#calculate the histogram
		if (density == True):
			hist,bin_edges = np.histogram(series, bins = 10, density = True) #probability density function
			for i in range(len(hist)):
				pdf = hist[i]
				area_min = bin_edges[i]
				#print("value of area_min")
				#print(area_min)
				tuples_of_time_area_num_of_observations.append((reconstruction_time,area_min,pdf))
				if (i == (len(hist) - 1)):
					area_max = bin_edges[i+1]
					tuples_of_time_area_num_of_observations.append((reconstruction_time,area_max,pdf))
		else:
			hist,bin_edges = np.histogram(series, bins = 10, density = False)
			for i in range(len(hist)):
				number_of_observations = hist[i]
				area_min = bin_edges[i]
				#print("value of area_min")
				#print(area_min)
				tuples_of_time_area_num_of_observations.append((reconstruction_time,area_min,number_of_observations))
				if (i == (len(hist) - 1)):
					area_max = bin_edges[i+1]
					tuples_of_time_area_num_of_observations.append((reconstruction_time,area_max,number_of_observations))
		#updated reconstruction_time
		reconstruction_time = reconstruction_time - interval_input_file
	#create a new dataframe
	new_dataframe = None
	if (density == True):
		new_dataframe = pd.DataFrame.from_records(tuples_of_time_area_num_of_observations, columns= ['reconstruction_time','area','pdf'])
	else:
		new_dataframe = pd.DataFrame.from_records(tuples_of_time_area_num_of_observations, columns= ['reconstruction_time','area','number_of_observations'])
	#print(new_dataframe)
	print(new_dataframe[new_dataframe['reconstruction_time'] == 195.00])
	print(new_dataframe[new_dataframe['reconstruction_time'] == 15.00])
	# make a custom colormap with transparency
	# ncolors = 256
	# color_array = plt.get_cmap('YlOrRd')(range(ncolors))
	# color_array[:, -1] = np.linspace(0, 1, ncolors)
	# cmap = LinearSegmentedColormap.from_list(name='YlOrRd', colors = color_array)
	if (density == True):
		plt.scatter(new_dataframe['reconstruction_time'], new_dataframe['area'], c = new_dataframe['pdf'])
		ax.set_xlabel('Reconstruction time in Ma')
		ax.set_ylabel('Area in squared-meters')
		cbar = plt.colorbar()
		cbar.set_label('Probability Density Function')
	else:
		plt.scatter(new_dataframe['reconstruction_time'], new_dataframe['area'], c = new_dataframe['number_of_observations'])
		ax.set_xlabel('Reconstruction time in Ma')
		ax.set_ylabel('Area in squared-meters')
		cbar = plt.colorbar()
		cbar.set_label('Number of observations')
	plt.show()

def plot_continental_mass_from_SuperGDU_fts_w_area(SuperGDU_fts_w_area_csv, modelname, from_time_input_file, to_time_input_file):
	dataframe = pd.read_csv(SuperGDU_fts_w_area_csv, sep = ',', header = 0)
	reconstruction_time = dataframe['reconstruction_time']
	continental_mass = dataframe['total_area']

	# make a custom colormap with transparency
	# ncolors = 256
	# color_array = plt.get_cmap('YlOrRd')(range(ncolors))
	# color_array[:, -1] = np.linspace(0, 1, ncolors)
	# cmap = LinearSegmentedColormap.from_list(name='YlOrRd', colors=color_array)

	fig,ax = plt.subplots()
	plot_title = 'Total continental mass for'+ modelname + " "+str(from_time_input_file)+"_"+str(to_time_input_file)
	plt.title(plot_title)
	ax.set_xlabel('Reconstruction time in Ma')
	ax.set_ylabel('Total continental mass in square meters')
	plt.bar(reconstruction_time,continental_mass)
	#plt.hist2d(time_steps, distance_overtime, bins = [100, 100])
	#plt.colorbar()
	plt.show()

def total_number_of_each_deposit_type_within_period(from_time, to_time, interval, mineral_deposit_feature_file_shp, datasource, yyyymmdd):
	print("Find total number of each deposit type within:")
	print(from_time,to_time)
	deposits_features = gpd.read_file(mineral_deposit_feature_file_shp)
	print(deposits_features)
	unique_deposit_type = deposits_features['TYPE'].unique()
	results = []
	reconstruction_time = from_time
	while (reconstruction_time > (to_time - interval)):
		print("Here is reconstruction_time:")
		print(reconstruction_time)
		for type in unique_deposit_type:
			# print((SuperGDU_features['TOAGE'] <= reconstruction_time))
			# print(SuperGDU_features['FROMAGE'] >= reconstruction_time)
			# print(SuperGDU_features['PLATEID1'] == plate_id)
			#print(SuperGDU_features.loc[SuperGDU_features['PLATEID1'] == plate_id & (SuperGDU_features['FROMAGE'] >= reconstruction_time) & (SuperGDU_features['TOAGE'] <= reconstruction_time),'Area'])
			total_deposits = len(deposits_features[(deposits_features['TYPE'] == type) & (deposits_features['APPEARANCE'] >= reconstruction_time) & (deposits_features['DISAPPEARA'] < reconstruction_time)])
			print("value of total_deposits")
			print(total_deposits)
			results.append((reconstruction_time,type,total_deposits))
		reconstruction_time = reconstruction_time - interval
	new_dataframe = pd.DataFrame.from_records(results, columns= ['reconstruction_time','type','total_deposits'])
	print(new_dataframe)
	filename = datasource+'_total_number_of_each_deposit_type_within_period_'+str(from_time)+'_'+str(to_time)+'_'+str(interval)+yyyymmdd+'.csv'
	new_dataframe.to_csv(filename,index=False)
	
def plot_historgram2d_of_continental_area_and_total_number_of_specific_deposits(SuperGDU_fts_w_area_csv, total_deposits_csv, specific_type, modelname, from_time_input_file, to_time_input_file):
	dataframe = pd.read_csv(SuperGDU_fts_w_area_csv, sep = ',', header = 0)
	reconstruction_time = dataframe['reconstruction_time']
	continental_mass = dataframe['total_area']
	
	dataframe_2 = pd.read_csv(total_deposits_csv, sep = ',', header = 0)
	total_deposits = dataframe_2.loc[dataframe_2['type'] == specific_type, 'total_deposits']
	
	# make a custom colormap with transparency
	ncolors = 256
	color_array = plt.get_cmap('YlOrRd')(range(ncolors))
	color_array[:, -1] = np.linspace(0, 1, ncolors)
	cmap = LinearSegmentedColormap.from_list(name='YlOrRd', colors=color_array)

	fig,ax = plt.subplots()
	plot_title = "Histogram 2D of total continental mass and total number of deposits "+specific_type+" from "+str(from_time_input_file)+" to "+str(to_time_input_file)
	plt.title(plot_title)
	ax.set_xlabel('Total continental mass')
	ax.set_ylabel('Total deposits')
	plt.hist2d(continental_mass, total_deposits, bins = [100, 100], cmap=cmap)
	#plt.hist2d(time_steps, distance_overtime, bins = [100, 100])
	plt.colorbar()
	plt.show()


#####Cannot be used for our purpose with SuperGDU - but definitely for other purpose
def plot_histogram2d_of_SuperGDU_area_and_number_of_members_within_period(from_time_input_file, to_time_input_file, interval_input_file, acceptable_time_difference, area_for_each_SuperGDU_overtime_csv, members_for_each_SuperGDU_overtime_csv, modelname, yyyymmdd):
	fig,ax = plt.subplots()
	dataframe_area = pd.read_csv(area_for_each_SuperGDU_overtime_csv, sep = ',', header = 0)
	dataframe_members = pd.read_csv(members_for_each_SuperGDU_overtime_csv, sep = ',', header = 0)
	tuples_of_time_pdf = []
	reconstruction_time = from_time_input_file
	while(reconstruction_time > (to_time_input_file - interval_input_file)):
		area_at_time = dataframe_area.loc[abs(dataframe_area['reconstruction_time'] - reconstruction_time) <= acceptable_time_difference,'total_area']
		members_at_time = dataframe_members.loc[abs(dataframe_members['reconstruction_time'] - reconstruction_time) <= acceptable_time_difference,'total_members']
		
		print(area_at_time)
		print(members_at_time)
		
		H,_,_ = np.histogram2d (area_at_time, members_at_time, bins = 10, density = True)
		print('H')
		print(H)
		#H is a bi-dimensional array: the first dimension is for histogramed values along x and the second dimension is for histogramed values along y axis
		#given that SuperGDU area is independent from SuperGDU members, P(area,members) at any given time = P(area)*P(members)
		joint_probabilities = H[0]*H[1]
		print(joint_probabilities)

		for i in range(0,len(joint_probabilities)):
			tuples_of_time_pdf.append((reconstruction_time,joint_probabilities[i]))
		reconstruction_time = reconstruction_time - interval_input_file
	new_dataframe = pd.DataFrame.from_records(tuples_of_time_pdf, columns= ['reconstruction_time','joint_pdf'])
	plt.scatter(new_dataframe['reconstruction_time'], new_dataframe['joint_pdf'], c = new_dataframe['joint_pdf'], cmap = 'YlOrRd', alpha=0.8)
	ax.set_xlabel('Reconstruction time in Ma')
	ax.set_ylabel('Joint PDF between area and members of SuperGDUs')
	cbar = plt.colorbar()
	cbar.set_label('Joint PDF')
	plt.show()
	
def time_series_plot_for_SuperGDU_area_and_number_of_members_within_period(from_time_input_file, to_time_input_file, interval_input_file, acceptable_time_difference, total_area_overtime_csv, total_members_overtime_csv, modelname, yyyymmdd):
	#reference: https://matplotlib.org/3.1.1/gallery/axes_grid1/parasite_simple.html#sphx-glr-gallery-axes-grid1-parasite-simple-py
	host = host_subplot(111)
	par = host.twinx()
	host.set_xlabel('Reconstruction time in Ma')
	host.set_ylabel('SuperGDU area in meters square')
	par.set_ylabel('SuperGDU members')
	
	dataframe_area = pd.read_csv(total_area_overtime_csv, sep = ',', header = 0)
	dataframe_members = pd.read_csv(total_members_overtime_csv, sep = ',', header = 0)
	series_area = dataframe_area.loc[dataframe_area['reconstruction_time'] < from_time_input_file,'total_area']
	series_members = dataframe_area.loc[dataframe_area['reconstruction_time'] < from_time_input_file,'total_members']
	area_line, = host.plot(dataframe_area['reconstruction_time'], series_area,lw = 1,label = 'SuperGDU area')
	members_line, = par.plot(dataframe_members['reconstruction_time'], series_members,lw = 1, label = 'SuperGDU members')
	leg = plt.legend(loc='lower left')
	
	host.yaxis.get_label().set_color(area_line.get_color())
	leg.texts[0].set_color(area_line.get_color())
	
	par.yaxis.get_label().set_color(members_line.get_color())
	leg.texts[1].set_color(members_line.get_color())
	
	plt.show()

def plot_area_of_represent_gdu_of_SuperGDU_within_period(represent_gdu_w_area_csv, list_of_represent_gdu_id, from_time_input_file, to_time_input_file):
	dataframe = pd.read_csv(represent_gdu_w_area_csv, sep = ',', header = 0)
	fig,ax = plt.subplots()
	dic = {}
	for gdu_id in list_of_represent_gdu_id:
		selected = dataframe.loc[(dataframe['represent_gdu_id'] == gdu_id),['represent_gdu_id','reconstruction_time','total_area']]
		if (gdu_id == 10784):
			gdu_name = 'S China Yangtze 1'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3000.0}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
		elif (gdu_id == 10310):
			gdu_name = 'N China Langgan'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3820.0}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
		elif (gdu_id == 10802):
			gdu_name = 'Yilgarn (Narryer)'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 4150.0}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
		elif (gdu_id == 10041):
			gdu_name = 'Slave W'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 4050.0}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
		elif (gdu_id == 10401):
			gdu_name = 'Kaapvaal Swaziland'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3900.0}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
		elif (gdu_id == 10439):
			gdu_name = 'Amazonia Archean'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3900.0}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
		elif (gdu_id == 10480):
			gdu_name = 'Grunehogna'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3900.0}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
		elif (gdu_id == 10714):
			gdu_name = 'India Bastar'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3400.0}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
		else:
			gdu_name = str(gdu_id)
			dic[str(gdu_id)] = {'name': gdu_name, 'age': -1.00}
			ax.scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
	
	ax.legend(ncol=3,fontsize=8)
	ax.set_xlabel('Reconstruction time in Ma')
	ax.set_ylabel('Area in squared-meters')
	plt.yscale("log")
	plt.show()		

def plot_perimeter_and_index_of_SuperGDU_within_period(SuperGDU_w_perimeter_csv,modelname):
	#'reconstruction_time','super_GDU_id','total_super_GDU_perimeter_for_all_SuperGDUs','total_perimeter_for_all_SuperGDUs','ratio','perimeter_closed_packed','index_1','index_2'
	dataframe = pd.read_csv(SuperGDU_w_perimeter_csv, sep = ',', header = 0)
	#fig,(ax1,ax2) = plt.subplots(2,1)#try to do 2 subplots - one with two perimeters and the other is ratio and index_2
	fig,ax2 = plt.subplots()
	# ax1.scatter(dataframe['reconstruction_time'],dataframe['total_super_GDU_perimeter_for_all_SuperGDUs'],marker = '+',label = 'Total perimeter of all SuperGDU after dissolve')
	# ax1.scatter(dataframe['reconstruction_time'],dataframe['total_perimeter_for_all_GDUs'],marker = '+',label = 'Total perimeter of all GDUs')
	# ax1.set_xlabel('Reconstruction time in Ma')
	# ax1.set_ylabel('Perimeter in km')
	# ax1.legend()

	#ax2.scatter(dataframe['reconstruction_time'],dataframe['ratio'],marker = 'o',label = 'ratio')
	ax2.scatter(dataframe['reconstruction_time'],dataframe['index_2'],marker = 'o',label = 'index_2')
	ax2.set_xlabel('Reconstruction time in Ma')
	ax2.legend()
	plt.title(modelname)
	plt.show()	

def plot_multiple_plots_of_area_of_represent_gdu_of_SuperGDU_within_period(represent_gdu_w_area_csv, list_of_represent_gdu_id, from_time_input_file, to_time_input_file):
	dataframe = pd.read_csv(represent_gdu_w_area_csv, sep = ',', header = 0)
	number_of_represent_gdus = len(list_of_represent_gdu_id)
	plt.rc('legend',fontsize=8) # using a size in points
	plt.rc('ytick', labelsize=8)
	fig, axs = plt.subplots(number_of_represent_gdus, sharex=True, sharey=True)
	fig.suptitle('Area of some SuperGDUs with represent gdu overtime')
	dic = {}
	for i in range(0,number_of_represent_gdus):
		gdu_id = list_of_represent_gdu_id[i]
		selected = dataframe.loc[(dataframe['represent_gdu_id'] == gdu_id),['represent_gdu_id','reconstruction_time','total_area']]
		if (gdu_id == 10784):
			gdu_name = 'S China Yangtze 1'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3000.0}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()
		elif (gdu_id == 10310):
			gdu_name = 'N China Langgan'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3820.0}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()
		elif (gdu_id == 10802):
			gdu_name = 'Yilgarn (Narryer)'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 4150.0}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()
		elif (gdu_id == 10041):
			gdu_name = 'Slave W'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 4050.0}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()
		elif (gdu_id == 10401):
			gdu_name = 'Kaapvaal Swaziland'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3900.0}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()
		elif (gdu_id == 10439):
			gdu_name = 'Amazonia Archean'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3900.0}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()
		elif (gdu_id == 10480):
			gdu_name = 'Grunehogna'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3900.0}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()
		elif (gdu_id == 10714):
			gdu_name = 'India Bastar'
			dic[str(gdu_id)] = {'name': gdu_name, 'age': 3400.0}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()
		else:
			gdu_name = str(gdu_id)
			dic[str(gdu_id)] = {'name': None, 'age': -1.00}
			axs[i].scatter(selected['reconstruction_time'],selected['total_area'],marker = '+',label = gdu_name)
			axs[i].legend()

	#axs.set_xlabel('Reconstruction time in Ma')
	#axs.set_ylabel('Area in squared-meters')
	plt.yscale("log")
	plt.show()
	

def find_finite_rotation_pole_for_a_pair_of_GDUs(rotation_model, moving_plate_id, fixed_plate_id, reconstruction_time, interval, reference_frame):
	finite_rotation = rotation_model.get_rotation(reconstruction_time, moving_plate_id, reconstruction_time + interval, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation.represents_identity_rotation() == False):
		Euler_pole,angle_rads = finite_rotation.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)

	else:
		print("Error in find_rift_segment_and_transform_faults")
		print("Error finite_rotation is identity")
		print(plate_id_1,plate_id_2)
		print("reconstruction_time")
		print(reconstruction_time)

def find_total_equivalent_reconstruction_rotation_(rotation_model,plat_id_or_gdu_id,reconstruction_time,reference_frame):
	"""
	Total reconstruction is a reconstruction relative to the present (in time) and relative to any reference frame (spin axis or mantle or anything else)
	rotation_model: A pygplates.RotationModel
	plat_id_or_gdu_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('plat_id_or_gdu_id')
		print(plat_id_or_gdu_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(plat_id_or_gdu_id,reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
		print('plat_id_or_gdu_id')
		print(plat_id_or_gdu_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_total_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,reconstruction_time,reference_frame):
	"""
	Total reconstruction is a reconstruction relative to the present (in time) and relative to any reference frame (spin axis or mantle or anything else)
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_stage_rotation_pole_for_a_pair_of_GDUs_using_reference_frame(rotation_model, plate_id_1, plate_id_2, reconstruction_time, interval, reference_frame):
	"""
	Incorrect version --- does not make any sense
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		finite_rotation_1 = rotation_model.get_rotation(0.00, plate_id_1, reconstruction_time + interval, anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(0.00, plate_id_1, reconstruction_time + interval, anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print('plate_id_1')
		print(plate_id_1)
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_2 is identity")
		print(plate_id_1,reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
	
	finite_rotation_2 = None
	if (reference_frame is None):
		finite_rotation_2 = rotation_model.get_rotation(0.00, plate_id_2, reconstruction_time + interval, anchor_plate_id = 0)
	else:
		finite_rotation_2 = rotation_model.get_rotation(0.00, plate_id_2, reconstruction_time + interval, anchor_plate_id = reference_frame)
	if (finite_rotation_2.represents_identity_rotation() == False):
		Euler_pole,angle_rads = finite_rotation_2.get_euler_pole_and_angle()
		print('plate_id_2')
		print(plate_id_2)
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_2.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_2 is identity")
		print(plate_id_2,reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
	
	rotation_of_plate_id_1_to_plate_id_2 = finite_rotation_2 * finite_rotation_1
	print("relative stage rotation of rotation_of_plate_id_1_to_plate_id_2")
	print("Euler_pole,angle_rads")
	Euler_pole,angle_rads = rotation_of_plate_id_1_to_plate_id_2.get_euler_pole_and_angle()
	print(Euler_pole,angle_rads)
	lat,lon,angle_degrees = rotation_of_plate_id_1_to_plate_id_2.get_lat_lon_euler_pole_and_angle_degrees()
	print("lat,lon,angle_degrees")
	print(lat,lon,angle_degrees)
	
	rotation_of_plate_id_2_to_plate_id_1 = finite_rotation_1 * finite_rotation_2
	print("relative stage rotation of rotation_of_plate_id_2_to_plate_id_1")
	print("Euler_pole,angle_rads")
	Euler_pole,angle_rads = rotation_of_plate_id_2_to_plate_id_1.get_euler_pole_and_angle()
	print(Euler_pole,angle_rads)
	lat,lon,angle_degrees = rotation_of_plate_id_2_to_plate_id_1.get_lat_lon_euler_pole_and_angle_degrees()
	print("lat,lon,angle_degrees")
	print(lat,lon,angle_degrees)

def find_intersecting_polygons(polygon_features_1,polygon_features_2,name_of_file_1,name_of_file_2,yearmonthday):
	outputFeatureCollection = pygplates.FeatureCollection()
	l = []
	for ft_1 in polygon_features_1:
		polygon_1 = ft_1.get_geometry()
		if (polygon_1 is not None):
			for ft_2 in polygon_features_2:
				if (ft_2.get_feature_id().get_string() not in l):
					polygon_2 = ft_2.get_geometry()
					if (polygon_2 is not None):
						if (polygon_2.partition(polygon_1) == pygplates.PolygonOnSphere.PartitionResult.inside or polygon_2.partition(polygon_1) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
							l.append(ft_2.get_feature_id().get_string())
							outputFeatureCollection.add(ft_2)
					else:
						print("Warning in utility")
						print("Warning in find_intersecting_polygons")
						print("polygon_2 is None")
						print("ft_2:", ft_2.get_feature_id().get_string())
						print(ft_2.get_name())
		else:
			print("Warning in utility")
			print("Warning in find_intersecting_polygons")
			print("polygon_1 is None")
			print("ft_1:", ft_1.get_feature_id().get_string())
			print(ft_1.get_name())
	outputFeatureCollection.write("find_polygons_in_file_2_intersecting_polygons_in_file_1_"+name_of_file_1+"_"+name_of_file_2+"_"+yearmonthday+".shp")

def convert_interested_ft_based_on_featureType_to_another_featureType(input_features,interested_ft_type,converted_to_ft_type,modelname,yearmonthday):
	output_features = pygplates.FeatureCollection()
	for ft in input_features:
		if (ft.get_feature_type() == interested_ft_type):
			geometry = ft.get_geometry()
			ini_valid_time = ft.get_valid_time()
			name = ft.get_name()
			plat_id_or_gdu_id = ft.get_reconstruction_plate_id()
			descr = ft.get_description()
			new_ft = pygplates.Feature.create_reconstructable_feature(converted_to_ft_type,geometry,valid_time = ini_valid_time, reconstruction_plate_id = plat_id_or_gdu_id)
			new_ft.set_description(descr)
			output_features.add(new_ft)
		else:
			output_features.add(ft)
	outputFeatureFile = "convert_interested_ft_"+modelname+"_"+yearmonthday+".shp"
	output_features.write(outputFeatureFile)
	outputFeatureFile = "convert_interested_ft_"+modelname+"_"+yearmonthday+".gpml"
	output_features.write(outputFeatureFile)
	
def count_number_of_valid_records_with_tonnage_and_grade_for_deposits(shp_file_of_deposits, commodity_field, commodity, total_tonnage_field, field_for_age, age_diff, from_time, to_time, interval, dataset_name):
	dataframe = gpd.read_file(shp_file_of_deposits)
	list_of_valid_counts = []
	list_of_ratios = []
	reconstruction_time = from_time
	while (reconstruction_time > (to_time - interval)):
		total_at_age = dataframe.loc[(abs(dataframe[field_for_age] - reconstruction_time) <= age_diff) & (dataframe[commodity_field] == commodity) & (dataframe[total_tonnage_field] > 0.00), total_tonnage_field].sum()
		total_valid_records = len(dataframe.loc[(abs(dataframe[field_for_age] - reconstruction_time) <= age_diff) & (dataframe[commodity_field] == commodity) & (pd.notna(dataframe[total_tonnage_field])) & (dataframe[total_tonnage_field] > 0.00), total_tonnage_field])
		total_records = len(dataframe.loc[(abs(dataframe[field_for_age] - reconstruction_time) <= age_diff) & (dataframe[commodity_field] == commodity), total_tonnage_field])
		print(total_valid_records)
		print(total_records)
		if (total_records > 0):
			ratio = (float(total_valid_records)/float(total_records)) 
			if (ratio < 1.00):
				print(ratio)
				print(total_valid_records)
				print(total_records)
		list_of_valid_counts.append((reconstruction_time,total_records,total_valid_records,ratio, total_at_age))
		reconstruction_time = reconstruction_time - interval
	new_dataframe = pd.DataFrame.from_records(list_of_valid_counts, columns= ['reconstruction_time','total_records','total_valid_records','ratio','total_at_age'])
	print(new_dataframe)
	filename = commodity+'_total_number_of_records_and_valid_records_within_period_'+str(from_time)+'_'+str(to_time)+'_'+str(interval)+"_"+str(age_diff)+"_"+dataset_name+'.csv'
	new_dataframe.to_csv(filename,index=False)

def calculate_the_endowment_for_each_distinct_GDU_features(shp_file_of_deposits_linked_with_GDUID_PLATEID, field_to_identify_distinct_GDU_or_PLATE, field_of_GDUID_or_PLATEID, endowment_field,dataset_name,yearmonthday):
	list_of_feature_id_and_endowment = []
	dataframe = gpd.read_file(shp_file_of_deposits_linked_with_GDUID_PLATEID)
	distinct_ID_for_GDU_or_PLATE = dataframe[field_to_identify_distinct_GDU_or_PLATE].unique()
	#print(distinct_ID_for_GDU_or_PLATE)
	for id in distinct_ID_for_GDU_or_PLATE:
		GDUID_or_PLATEID_max = dataframe.loc[dataframe[field_to_identify_distinct_GDU_or_PLATE] == id, field_of_GDUID_or_PLATEID].max()
		GDUID_or_PLATEID_min = dataframe.loc[dataframe[field_to_identify_distinct_GDU_or_PLATE] == id, field_of_GDUID_or_PLATEID].min()
		if (GDUID_or_PLATEID_max != GDUID_or_PLATEID_min):
			print("GDUID_or_PLATEID_max != GDUID_or_PLATEID_min",GDUID_or_PLATEID_max,GDUID_or_PLATEID_min)
			#exit()
		else:
			endowment = dataframe.loc[dataframe[field_to_identify_distinct_GDU_or_PLATE] == id, endowment_field].sum() 
			list_of_feature_id_and_endowment.append((id,GDUID_or_PLATEID_max,endowment))
	new_dataframe = pd.DataFrame.from_records(list_of_feature_id_and_endowment, columns= [field_to_identify_distinct_GDU_or_PLATE,field_of_GDUID_or_PLATEID,endowment_field])
	print(new_dataframe)
	filename = endowment_field +"_calculate_the_endowment_for_each_distinct_GDU_features_"+dataset_name+"_"+yearmonthday+".csv"
	new_dataframe.to_csv(filename,index=False)

def generate_list_of_csv_filenames_for_general_prefix_and_postfix(common_prefix_for_output_files,begin,end,interval,common_postfix_for_output_files,fileformat):
	#find_line_features_under_compression_or_extesion_relative_to_relative_velocity_vector_on_upper_plate_margin_45.0_spatial_joined_BC_faults_and_PalaeoPlates2020_local_center_lat_0_lon_0_test_1__20211018
	age = begin
	list_of_filename = []
	while (age > (end - interval)):
		print('age')
		print(age)
		txt = """{input_common_prefix_for_output_files}_{input_age}_{input_common_postfix_for_output_files}.{input_fileformat}"""
		final_filename = txt.format(input_common_prefix_for_output_files = common_prefix_for_output_files,input_age = str(age),input_common_postfix_for_output_files = common_postfix_for_output_files, input_fileformat = fileformat)
		print('final_filename')
		print(final_filename)
		list_of_filename.append(final_filename)
		age = age - interval
	return(list_of_filename)
	
def combine_multiple_csv_files_with_the_same_fields(list_of_csv_files_with_the_same_field, output_filename):
	dataframe = None
	for filename in list_of_csv_files_with_the_same_field:
		print(filename)
		if (dataframe is None):
			dataframe = pd.read_csv(filename, sep = ',', header = 0)
		else:
			
			temp_dataframe = pd.read_csv(filename, sep = ',', header = 0)
			dataframe = dataframe.append(temp_dataframe, ignore_index = True)
	print(dataframe)
	dataframe.to_csv(output_filename,index=False)

def edit_begin_age_of_features_based_of_an_input(input_filename,output_filename,output_format,amount_to_be_subtracted_from_begin_age,yyyymmdd_of_input_file):
	features = pygplates.FeatureCollection(input_filename)
	output_features = pygplates.FeatureCollection()
	for ft in features:
		begin_age,end_age = ft.get_valid_time()
		new_begin_age = begin_age - amount_to_be_subtracted_from_begin_age

		ft.set_valid_time(new_begin_age,end_age)
		output_features.add(ft)
	final_output_filename = output_filename+"_"+yyyymmdd_of_input_file+"."+output_format
	output_features.write(final_output_filename)
	
def check_and_assign_ft_id_str_in_GPlates_format_to_ft_name(input_filename,output_format,output_name,yyyymmdd_of_input_file):
	outputFeatureCollection = pygplates.FeatureCollection()
	features = pygplates.FeatureCollection(input_filename)
	for ft in features:
		ft_name = ft.get_name()
		if (ft_name is not None):
			#try to split the string to see whether ft_id_str is already in GPlates format
			split_str_list = ft_name.split('-')
			if (len(split_str_list) > 1):
				first_str = split_str_list[0]
				if (first_str == 'GPlates'):
					outputFeatureCollection.add(ft)
				else:
					#ft.set_description(ft_name)
					ft.set_name(ft.get_feature_id().get_string())
					outputFeatureCollection.add(ft)
			else:
				#ft.set_description(ft_name)
				ft.set_name(ft.get_feature_id().get_string())
				outputFeatureCollection.add(ft)
		else:
			ft.set_name(ft.get_feature_id().get_string())
			outputFeatureCollection.add(ft)
	prefix = "check_and_assign_ft_id_str_in_GPlates_format_to_ft_name"
	final_output_filename = prefix+"_"+output_name+"_"+yyyymmdd_of_input_file+"."+output_format
	outputFeatureCollection.write(final_output_filename)

def check_whether_every_ft_has_descrpt_as_the_specific_value(input_filename, specific_value):
	features = pygplates.FeatureCollection(input_filename)
	outputFeatureCollection = pygplates.FeatureCollection()
	for ft in features:
		if (ft.get_description() != specific_value):
			print("found ft.get_description() != specific_value")
			outputFeatureCollection.add(ft)
	if (len(outputFeatureCollection) > 0):
		outputFeatureCollection.write("features_required_to_have_description_modified_to_specific_value_"+specific_value+".gpml")

def calculate_ratio_between_two_fields_from_two_csv_files(numerator_field_for_first_csv,denominator_field_for_second_csv,first_csv,second_csv,field_for_age,name_of_outputdata,is_percent,yearmonthday):
	'''Be careful with the deliminter used in both csv files. By default, the module assumes the delimiter is a comma. Also, the first row of the csv file is the header.
	Both csv file needs to have the same number of records and the same field for age/time.'''
	df1 = pd.read_csv(first_csv, header = 0, delimiter = ',')
	df2 = pd.read_csv(second_csv, header = 0, delimiter = ',')
	series_of_ratio = df1[numerator_field_for_first_csv]/df2[denominator_field_for_second_csv]
	series_of_age = df1[field_for_age]
	series_of_pct = None
	if (is_percent == True):
		series_of_pct = series_of_ratio*100.00
	output_dic = None
	if (is_percent == True):
		output_dic = {field_for_age:series_of_age,'ratio':series_of_ratio,'pct':series_of_pct}
	else:
		output_dic = {field_for_age:series_of_age,'ratio':series_of_ratio}
	output_dataframe = pd.DataFrame(data = output_dic)
	output_dataframe.to_csv('ratio_btw_'+numerator_field_for_first_csv+'_'+denominator_field_for_second_csv+'_'+name_of_outputdata+'_'+yearmonthday+'.csv',index = False)

def calculate_ratio_between_area_of_each_sgdu_and_total_area(numerator_field_for_first_csv,denominator_field_for_second_csv,first_csv,second_csv,field_for_upper_age_1,field_for_lower_age_1,field_for_age_2,begin_age,end_age,age_interval,name_of_outputdata,yearmonthday):
	'''Be careful with the deliminter used in both csv files. By default, the module assumes the delimiter is a comma. Also, the first row of the csv file is the header.
	Both csv file needs to have the same number of records and the same field for age/time.'''
	df1 = pd.read_csv(first_csv, header = 0, delimiter = ';')
	df2 = pd.read_csv(second_csv, header = 0, delimiter = ',')
	output_dic = {field_for_age_2:[],'sgdu':[],'ratio':[],'pct':[]}
	age = begin_age
	while (age >= end_age):
		print('age',age)
		value_of_denominator = 0
		record_for_denominator = df2.loc[df2[field_for_age_2] == age,denominator_field_for_second_csv]
		array_record_for_denominator = record_for_denominator.to_numpy()
		value_of_denominator = float(array_record_for_denominator[0])
		record_for_numerator = None
		if (age > 0.00):
			record_for_numerator = df1.loc[(df1[field_for_upper_age_1] >= age) & (df1[field_for_lower_age_1] < age),['SGDU',numerator_field_for_first_csv]]
		elif (age == 0.00):
			record_for_numerator = df1.loc[(df1[field_for_upper_age_1] == age) & (df1[field_for_lower_age_1] == age),['SGDU',numerator_field_for_first_csv]]
		for sgduid,area in record_for_numerator.itertuples(index=False,name=None):
			output_dic[field_for_age_2].append(age)
			output_dic['sgdu'].append(sgduid)
			r = (float(area)/value_of_denominator)
			output_dic['ratio'].append(r)
			output_dic['pct'].append(r*100.00)
		age = age - age_interval
	output_dataframe = pd.DataFrame(data = output_dic)
	output_dataframe.to_csv('ratio_btw_area_of_each_sgdu_and_total_area_'+numerator_field_for_first_csv+'_'+denominator_field_for_second_csv+'_'+name_of_outputdata+'_'+yearmonthday+'.csv',index = False)

def calculate_ratio_between_area_of_top_n_sgdu_and_total_area(n_sgdu,numerator_field_for_first_csv,denominator_field_for_second_csv,first_csv,second_csv,field_for_age_1,field_for_age_2,begin_age,end_age,age_interval,name_of_outputdata,yearmonthday):
	'''Be careful with the deliminter used in both csv files. By default, the module assumes the delimiter is a comma. Also, the first row of the csv file is the header.
	Both csv file needs to have the same number of records and the same field for age/time.'''
	df1 = pd.read_csv(first_csv, header = 0, delimiter = ',')
	df2 = pd.read_csv(second_csv, header = 0, delimiter = ',')
	output_dic = {field_for_age_2:[],'sgdu':[],'ratio':[],'pct':[]}
	age = begin_age
	while (age >= end_age):
		print('age',age)
		value_of_denominator = 0
		record_for_denominator = df2.loc[df2[field_for_age_2] == age,denominator_field_for_second_csv]
		array_record_for_denominator = record_for_denominator.to_numpy()
		value_of_denominator = float(array_record_for_denominator[0])
		record_for_numerator = None
		record_for_numerator = df1.loc[(df1[field_for_age_1] == age),['SGDU',numerator_field_for_first_csv]]
		for sgduid,area in record_for_numerator.itertuples(index=False,name=None):
			output_dic[field_for_age_2].append(age)
			output_dic['sgdu'].append(sgduid)
			r = (float(area)/value_of_denominator)
			output_dic['ratio'].append(r)
			output_dic['pct'].append(r*100.00)
		age = age - age_interval
	output_dataframe = pd.DataFrame(data = output_dic)
	output_dataframe.to_csv('ratio_btw_area_of_'+str(n_sgdu)+'_sgdu_and_total_area_'+numerator_field_for_first_csv+'_'+denominator_field_for_second_csv+'_'+name_of_outputdata+'_'+yearmonthday+'.csv',index = False)

def calculate_the_diff_between_two_fields_from_two_csv_files(field_1,field_2,first_csv,second_csv,field_for_age,name_of_outputdata,yearmonthday):
	'''Be careful with the deliminter used in both csv files. By default, the module assumes the delimiter is a comma. Also, the first row of the csv file is the header.
	Both csv file needs to have the same number of records and the same field for age/time.'''
	df1 = pd.read_csv(first_csv, header = 0, delimiter = ',')
	df2 = pd.read_csv(second_csv, header = 0, delimiter = ',')
	series_of_ratio = df1[field_1]-df2[field_2]
	series_of_age = df1[field_for_age]
	output_dic = {field_for_age:series_of_age,'diff':series_of_ratio}
	output_dataframe = pd.DataFrame(data = output_dic)
	output_dataframe.to_csv('diff_btw_'+field_1+'_'+field_2+'_'+name_of_outputdata+'_'+yearmonthday+'.csv',index = False)

def calculate_the_diff_of_one_field_over_time_from_one_csv_files(field_1,first_csv,field_for_time,time_interval,name_of_outputdata,yearmonthday):
	'''Be careful with the deliminter used in both csv files. By default, the module assumes the delimiter is a comma. Also, the first row of the csv file is the header.
	Both csv file needs to have the same number of records and the same field for age/time.'''
	df1 = pd.read_csv(first_csv, header = 0, delimiter = ',')
	times = []
	results = []
	max_time = df1[field_for_time].max()
	min_time = df1[field_for_time].min()
	time = max_time 
	while (time > min_time):
		times.append(time)
		records_at_time = df1.loc[df1[field_for_time] == time,field_1].to_numpy()
		if (len(records_at_time) > 1):
			print("Error found more than one record at one time")
			print("records_at_time",records_at_time)
			exit()
		value_at_time = records_at_time[0]
		records_at_next_time = df1.loc[df1[field_for_time] == (time-time_interval),field_1].to_numpy()
		if (len(records_at_next_time) > 1):
			print("Error found more than one record at one time")
			print("records_at_next_time",records_at_next_time)
			exit()
		value_at_next_time = records_at_next_time[0]
		results.append(((value_at_time-value_at_next_time)/time_interval))
		time = time - time_interval
	output_dic = {field_for_time:times,'diff':results}
	output_dataframe = pd.DataFrame(data = output_dic)
	output_dataframe.to_csv('diff_btw_'+field_1+'_'+name_of_outputdata+'_'+yearmonthday+'.csv',index = False)

def assign_values_of_selected_field_at_selected_field_for_age_of_input_csv_to_output_shp_file(name_of_selected_field_csv, name_of_age_field_csv, name_of_wanted_field_csv, csv_file, name_of_selected_field_shp, name_of_selected_age_field_shp, smallest_thershold_value, shp_file, output_field_shp, modelname, yearmonthday):
	#reconstruction_time,sgdu,ratio,pct
	df = pd.read_csv(csv_file)
	gdf = gpd.read_file(shp_file)
	unique_values_for_selected_field_csv = df[name_of_selected_field_csv].unique()
	for unique_value in unique_values_for_selected_field_csv:
		int_unique_value = int(unique_value)
		array_selected_age = gdf.loc[(gdf[name_of_selected_field_shp] == int_unique_value),name_of_selected_age_field_shp].to_numpy()
		selected_age = float(array_selected_age[0])
		#print(unique_value,selected_age)
		array_record = df.loc[(df[name_of_selected_field_csv] == unique_value) & (df[name_of_age_field_csv] == selected_age), name_of_wanted_field_csv].to_numpy()
		if (len(array_record) == 0):
			array_record = df.loc[(df[name_of_selected_field_csv] == unique_value) & (abs(df[name_of_age_field_csv] - selected_age) <= smallest_thershold_value), name_of_wanted_field_csv].to_numpy()
		selected_value = float(array_record[0])
		gdf.loc[(gdf[name_of_selected_field_shp] == unique_value),output_field_shp] = selected_value
	gdf.to_file('assign_values_to_'+name_of_selected_field_shp+'_based_on_'+name_of_selected_age_field_shp+'_for_'+modelname+'_'+yearmonthday+'.shp')

def join_a_csv_to_a_shp_based_on_an_attribute(name_of_selected_field_csv, name_of_selected_field_shp, csv_file, shp_file, output_shp):
	#df = pd.read_csv(csv_file, sep = ';')
	df = pd.read_csv(csv_file, sep = ',')
	gdf = gpd.read_file(shp_file)
	gdf = gdf.merge(df, how = 'left', left_on = name_of_selected_field_shp, right_on = name_of_selected_field_csv)
	gdf.to_file(output_shp)
	
def spatial_join_left_shp_and_right_shp(left_shp, right_shp, spatial_rlx_of_left_relative_to_right, output_shp_filename):
	left_gdf = gpd.read_file(left_shp)
	right_gdf = gpd.read_file(right_shp)
	left_gdf_w_right_attributes = gpd.sjoin(left_gdf, right_gdf, how='left')
	left_gdf_w_right_attributes.to_file(output_shp_filename)

#rotation_file = r"C:\\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\Rotation\T_Rot_Model_PalaeoPlates_20200131be.rot"
# rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2021\PalaeoPlates\T_Rot_Model_PalaeoPlates_20210129be.grot"
# rotation_model = pygplates.RotationModel(rotation_file)
# print('fixed_plate_id')
# print(10752)
# print('moving_plate_id')
# print(10911)
# find_finite_rotation_pole_for_a_pair_of_GDUs(rotation_model, 10911, 10752, 170.0, 5.0, 700)
# print('fixed_plate_id')
# print(10911)
# print('moving_plate_id')
# print(10752)
# find_finite_rotation_pole_for_a_pair_of_GDUs(rotation_model, 10752, 10911, 170.0, 5.0, 700)

#plate_id_1 = 10752
#plate_id_2 = 10911
#reconstruction_time = 170.00
#interval = 5.00
#reference_frame = 700
#find_stage_rotation_pole_for_a_pair_of_GDUs_using_reference_frame(rotation_model, plate_id_1, plate_id_2, reconstruction_time, interval, reference_frame)

#using above modules
# name_of_feature_file = r"C:\Users\lavie\OneDrive - University of Saskatchewan\Geology\Research\Fall2020\Code\identify_plate_boundaries\results\result_from_12012020_12062020\tectonic_boundaries_features_PalaeoPlates_April_2020_test_6_threshold_800km"
# from_time = 600.0
# to_time = 0.0
# interval = 5
# yyyymmdd_of_input_files = '20201201'
# read_multiple_feature_files(name_of_feature_file,from_time,to_time,interval,yyyymmdd_of_input_files)

#from_time_input_file = 200.00
#to_time_input_file = 0.00
#age_interval = 5.00
#modelname = "PalaeoPlates2020"
#filename = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\\testing_dissolved_polygon_fts_5.0_0.0_PalaeoPlates2020_test_90__20210118.gpml"
#filename = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\\testing_dissolved_polygon_fts_205.0_0.0_PalaeoPlates2020_test_91_with_from_time_adding_small_amount_of_time_20210120.gpml"
#filename = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\\testing_dissolved_polygon_fts_205.0_0.0_PalaeoPlates2020_test_93_with_from_time_adding_small_amount_of_time_20210120.gpml"
#filename = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU_for_Neftex\\testing_dissolved_polygon_fts_205.0_0.0_Neftex2018_test_1_with_dateline_wrapper_EPSG_4326_and_uncertainty_values_20210126.gpml"
#yyyymmdd_of_input_file = "20210129"
#edit_end_time_of_each_features_based_of_age_interval(filename,age_interval,from_time_input_file,to_time_input_file,yyyymmdd_of_input_file)																
#path_and_name_of_gpml_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\edit_shapes_continents_Merdith_et_al.gpml"
#output_filename = r"edit_shapes_continents_Merdith_et_al"
#convert_gpml_to_shp(path_and_name_of_gpml_file,output_filename)

#SuperGDU_fts_w_duration_shp = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\edited_w_area_and_dur_final_SuperGDU_fts_test_19_205_0_20210121.shp"
#plot_histogram_duration_area_of_SuperGDU_features(SuperGDU_fts_w_duration_shp,from_time_input_file,to_time_input_file)
#density = False
#plot_time_series_histogram_duration_area_of_SuperGDU_features(SuperGDU_fts_w_duration_shp, from_time_input_file, to_time_input_file, age_interval, density)

#SuperGDU_fts_w_area_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_test_93_with_from_time_adding_small_amount_of_time_sum_total_area_of_continental_crust_within_period_205.0_0.0_5.020210128.csv"
#plot_continental_mass_from_SuperGDU_fts_w_area(SuperGDU_fts_w_area_csv, modelname, from_time_input_file, to_time_input_file)

#acceptable_time_difference = 0.00
#total_area_overtime_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_test_93_with_from_time_adding_small_amount_of_time_sum_total_area_of_continental_crust_within_period_205.0_0.0_5.020210203.csv"
#total_members_overtime_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_test_93_with_from_time_adding_small_amount_of_time_sum_total_gdu_members_of_continental_crust_within_period_205.0_0.0_5.020210203.csv"
#total_area_overtime_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU_for_Neftex\Neftex2018_test_1_with_dateline_wrapper_EPSG_4326_and_uncertainty_values_sum_total_area_and_gdu_members_of_SuperGDU_within_period_205.0_0.0_5.020210210.csv"
#total_members_overtime_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU_for_Neftex\Neftex2018_test_1_with_dateline_wrapper_EPSG_4326_and_uncertainty_values_sum_total_area_and_gdu_members_of_SuperGDU_within_period_205.0_0.0_5.020210210.csv"
#yyyymmdd = '20210211'
#modelname = 'Neftex2018'
#time_series_plot_for_SuperGDU_area_and_number_of_members_within_period(from_time_input_file, to_time_input_file, age_interval, acceptable_time_difference, total_area_overtime_csv, total_members_overtime_csv, modelname, yyyymmdd)

#represent_gdu_w_area_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_manual_calculating_perimeter_area_of_each_represent_gdu_ft_of_SuperGDU_feature_at_each_time_within_period_205.0_5.0_5.020210310.csv"
# represent_gdu_w_area_csv = r"C:\Users\lavie\OneDrive - University of Saskatchewan\Geology\Research\Winter2021\Code\superGDU\20210330\PalaeoPlates2021\PalaeoPlates2021_test_2_area_of_each_represent_gdu_ft_of_SuperGDU_feature_at_each_time_within_period_2000.0_5.0_5.020210405.csv"
# #list_of_represent_gdu_id = [10784,10310,10802,10041,10401,10439,10480,10714]
# list_of_represent_gdu_id = [10802,10041,10401,10439,10480]
# from_time_input_file = 2000.00
# to_time_input_file = 5.00
# #plot_area_of_represent_gdu_of_SuperGDU_within_period(represent_gdu_w_area_csv, list_of_represent_gdu_id, from_time_input_file, to_time_input_file)
# plot_multiple_plots_of_area_of_represent_gdu_of_SuperGDU_within_period(represent_gdu_w_area_csv, list_of_represent_gdu_id, from_time_input_file, to_time_input_file)
#each_SuperGDU_area_overtime_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_test_93_with_from_time_adding_small_amount_of_time_area_of_each_SuperGDU_feature_at_each_time_within_period_205.0_0.0_5.020210203.csv"
#density = False
#plot_time_series_histogram_of_continental_area(each_SuperGDU_area_overtime_csv, from_time_input_file, to_time_input_file, age_interval, density)

#plot_histogram_area_of_SuperGDU_features_within_period(each_SuperGDU_area_overtime_csv, from_time_input_file, to_time_input_file)

#area_for_each_SuperGDU_overtime_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_test_93_with_from_time_adding_small_amount_of_time_area_of_each_SuperGDU_feature_at_each_time_within_period_205.0_0.0_5.020210203.csv"
#members_for_each_SuperGDU_overtime_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_test_93_with_from_time_adding_small_amount_of_time_gdu_members_of_each_SuperGDU_feature_at_each_time_within_period_205.0_0.0_5.020210203.csv"
#plot_histogram2d_of_SuperGDU_area_and_number_of_members_within_period(from_time_input_file, to_time_input_file, age_interval, acceptable_time_difference, area_for_each_SuperGDU_overtime_csv, members_for_each_SuperGDU_overtime_csv, modelname, yyyymmdd)

# filename_of_features_to_be_extracted = r"C:\Users\lavie\Desktop\Research\Winter2021\examine_line_topology\line_features_with_type_CON_OCN__test_8_for_PalaeoPlates2020_with_finalized_superGDU_from_20210121_test93_buffer_distance_10000km_test_19_20210127.gpml"
# filename_of_reference_features = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\GDUs\NAM_SAM_AFR_ANT_INO_PalaeoPlates2020.shp"
# modelname = "PalaeoPlates2020"
# extract_features_based_on_PlateID_of_other_feature_collection(filename_of_features_to_be_extracted,filename_of_reference_features,modelname)

# mineral_deposit_feature_file_shp = r"C:\Users\lavie\Desktop\Research\BDEP_17_Lavie\BDEP_17_GEOCHRON_AND_MINEX\BDEP_17_MINEX.shp"
# datasource = 'Halliburton_Neftex_2018'
# yyyymmdd = '20210203'
# from_time_input_file = 3800.00
# to_time_input_file = 0.00
# age_interval = 5.00
# total_number_of_each_deposit_type_within_period(from_time_input_file, to_time_input_file, age_interval, mineral_deposit_feature_file_shp, datasource, yyyymmdd)
#total_deposits_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_test_93_with_from_time_adding_small_amount_of_time_total_number_of_each_deposit_type_within_period_205.0_0.0_5.020210127.csv"
#specific_type = "Calc-alkalic Porphyry"
#plot_historgram2d_of_continental_mass_and_total_number_of_specific_deposits(SuperGDU_fts_w_area_csv, total_deposits_csv, specific_type, modelname, from_time_input_file, to_time_input_file)

#SuperGDU_w_perimeter_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2020_manual_calculating_perimeter_perimeter_of_all_SuperGDU_features_at_each_time_within_period_205.0_0.0_5.020210310.csv"
#SuperGDU_w_perimeter_csv = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\PalaeoPlates2021_test_4_perimeter_of_all_SuperGDU_features_at_each_time_within_period_2000.0_5.0_5.020210407.csv"
#plot_perimeter_and_index_of_SuperGDU_within_period(SuperGDU_w_perimeter_csv,'PalaeoPlates2021_without_projection')
