import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import utility_v1_converted as u

def main():
	path_and_name_of_gpml_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\Cao2023\Cao2023\shapes_continents_Cao.gpmlz"
	output_filename = "shape_continents_Cao_et_al_2023_20230906"
	u.convert_gpml_to_shp(path_and_name_of_gpml_file,output_filename)
	# path_and_name_of_shp_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\modified_end_age_of_rift_point_features_for_test_17_PalaeoPlatesendOct2022_w_1_deg_from_1000Ma_20230618.shp"
	# output_filename = r"modified_end_age_of_rift_point_features_for_test_17_PalaeoPlatesendOct2022_w_1_deg_from_1000Ma_20230618"
	# u.convert_shp_to_gpml(path_and_name_of_shp_file,output_filename)

if __name__ == "__main__":
	main()