import math
import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import pyproj
import geopandas as gpd
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing
from shapely.ops import transform
from shapely.validation import explain_validity

#convert gpml file to shp file 
def convert_gpml_to_shp(path_and_name_of_gpml_file,output_filename):
	print("Here is path_and_name_of_gpml_file:")
	print(path_and_name_of_gpml_file)
	old_FeatureCollection = pygplates.FeatureCollection.read(path_and_name_of_gpml_file)
	new_FeatureCollection = pygplates.FeatureCollection()
	for ft in old_FeatureCollection:
		new_FeatureCollection.add(ft)
	output_filename = output_filename+".shp"
	new_FeatureCollection.write(output_filename)

def convert_polygon_to_Polygon_in_shapely(each_polygon):
	list_of_lon_lat_vertices = []
	for lat,lon in each_polygon.to_lat_lon_list():
		round_up_lat = round(lat,5)
		round_up_lon = round(lon,5)
		list_of_lon_lat_vertices.append((lon,lat))
	new_polygon = Polygon(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating Polygon in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_polygon

def calculate_area_of_valid_GDUs_at_each_reconstruction_time(GDU_features_shp_or_gpml_file, epsg_code, convert_squared_meters_to_squared_km, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time): # using PLATEID and FEATUREID in GPlates/pygplates convention to create unique key for each GDU polygon feature
	GDU_features = pygplates.FeatureCollection(GDU_features_shp_or_gpml_file)
	wgs_84 = pyproj.CRS('EPSG:4326')
	if (epsg_code is None):
		epsg_code = 'ESRI:54030'
	proj_epsg = pyproj.CRS(epsg_code)
	project = pyproj.Transformer.from_crs(wgs_84, proj_epsg, always_xy = True).transform
	
	dic_unique_GDU_fts = {}
	output_dic = {"reconstruction_time":[],"total_area":[],"count_features":[]}
	for GDU_ft in GDU_features:
		feature_id = GDU_ft.get_feature_id().get_string()
		gdu_id = GDU_ft.get_reconstruction_plate_id()
		unique_key = None
		if (GDU_ft.get_name() is not None):
			unique_key = str(gdu_id)+"$"+feature_id+"$"+GDU_ft.get_name()
		else:
			unique_key = str(gdu_id)+"$"+feature_id+"$"+"$"
		if (unique_key not in dic_unique_GDU_fts):
			polygon = GDU_ft.get_geometry()
			if (polygon is None):
				max_area = 0.00
				for p in GDU_ft.get_geometries():
					if (p.get_area() > max_area):
						max_area = p.get_area()
						polygon = p
			#convert SuperGDU_polygon to Shapely Polygon
			polygon_Shapely = convert_polygon_to_Polygon_in_shapely(polygon)
			#convert polygon_Shapely from EPSG:4326
			projected_Polygon = transform(project,polygon_Shapely)
			area = projected_Polygon.area #unit depends on proj_epsg
			if (convert_squared_meters_to_squared_km == True):
				area = area/1000000.00
			dic_unique_GDU_fts[unique_key] = (GDU_ft,area)
		else:
			print("Warning unique_key created from str(gdu_id)+$+feature_id is not unique for every GDU feature")
			print("unique_key",unique_key)
			print("please review the model")
			print("Here we will keep adding the area of all polygon features with the same unique_key to calculate area")
			polygon = GDU_ft.get_geometry()
			if (polygon is None):
				max_area = 0.00
				for p in GDU_ft.get_geometries():
					if (p.get_area() > max_area):
						max_area = p.get_area()
						polygon = p
			#convert SuperGDU_polygon to Shapely Polygon
			polygon_Shapely = convert_polygon_to_Polygon_in_shapely(polygon)
			#convert polygon_Shapely from EPSG:4326
			projected_Polygon = transform(project,polygon_Shapely)
			area = projected_Polygon.area #unit depends on proj_epsg
			if (convert_squared_meters_to_squared_km == True):
				area = area/1000000.00
			previous_GDU_ft,previous_area = dic_unique_GDU_fts[unique_key]
			dic_unique_GDU_fts[unique_key] = (GDU_ft,previous_area+area)

	current_time = begin_reconstruction_time
	while (current_time > (end_reconstruction_time - interval_reconstruction_time)):
		list_of_valid_GDU_features = [ft for ft in GDU_features if ft.is_valid_at_time(current_time)]
		total_area = 0.00
		for valid_GDU_ft in list_of_valid_GDU_features:
			feature_id = GDU_ft.get_feature_id().get_string()
			gdu_id = GDU_ft.get_reconstruction_plate_id()
			unique_key = None
			if (GDU_ft.get_name() is not None):
				unique_key = str(gdu_id)+"$"+feature_id+"$"+GDU_ft.get_name()
			else:
				unique_key = str(gdu_id)+"$"+feature_id+"$"+"$"
			if (unique_key in dic_unique_GDU_fts):
				_,area = dic_unique_GDU_fts[unique_key]
				total_area = total_area + area
			else:
				unique_key = str(gdu_id)+"$"+feature_id+"$"+valid_GDU_ft.get_name()
		output_dic["reconstruction_time"].append(current_time)
		output_dic["total_area"].append(total_area)
		output_dic["count_features"].append(len(list_of_valid_GDU_features))
		current_time = current_time - interval_reconstruction_time
	return output_dic

def calculate_area_of_valid_GDUs_at_each_reconstruction_time(GDU_features_shp_file, epsg_code, convert_squared_meters_to_squared_km, field_of_begin_age_for_ft, field_of_end_age_for_ft, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time,modelname,yearmonthday):
	output_list = []
	gdf = gpd.read_file(GDU_features_shp_file)
	project_gdf = gdf.to_crs(epsg_code)
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		selected_records = project_gdf.loc[(project_gdf[field_of_begin_age_for_ft] >= reconstruction_time) & (project_gdf[field_of_end_age_for_ft] <= reconstruction_time)]
		total_area = 0.00
		total_num_records = 0
		if (len(selected_records) > 0):
			total_area_in_sq_meters= selected_records.geometry.area.sum()
			if (convert_squared_meters_to_squared_km == True):
				total_area = total_area_in_sq_meters/1000000.000
			else:
				total_area = total_area_in_sq_meters
			total_num_records = len(selected_records)
		output_list.append((reconstruction_time,total_area,total_num_records))
		reconstruction_time = reconstruction_time - interval_reconstruction_time
	output_df = pd.DataFrame(output_list, columns = ['reconstruction_time','total_area','count_features'])
	filename = "area_and_count_of_valid_GDUs_at_each_reconstruction_time_for_"+modelname+"_"+yearmonthday+".csv"
	output_df.to_csv(filename,index = False)

def calculate_area_of_valid_GDUs_at_each_reconstruction_time_for_multiple_models(list_of_GDU_features_files, epsg_code, convert_squared_meters_to_squared_km, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time, list_of_modelnames_associated_with_GDU_fts_files, yearmonthday):
	if (len(list_of_GDU_features_files) != len(list_of_modelnames_associated_with_GDU_fts_files)):
		print("Error in calculate_area_of_valid_GDUs_at_each_reconstruction_time_for_multiple_models")
		print("len(list_of_GDU_features_files) != len(list_of_modelnames_associated_with_GDU_fts_files)")
		print("please make sure to provide the modelname for each GDU_feature_file in the list_of_GDU_features_files")
		print("list_of_GDU_features_files")
		print(list_of_GDU_features_files)
		print("list_of_modelnames_associated_with_GDU_fts_files")
		print(list_of_modelnames_associated_with_GDU_fts_files)
		exit()
	number_of_files = len(list_of_GDU_features_files)
	for i in range(0,number_of_files):
		each_file = list_of_GDU_features_files[i]
		modelname = list_of_modelnames_associated_with_GDU_fts_files[i]
		print("file",each_file)
		output_dic = calculate_area_of_valid_GDUs_at_each_reconstruction_time(each_file, epsg_code, convert_squared_meters_to_squared_km, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time)
		new_dataframe = pd.DataFrame.from_dict(output_dic)
		filename = "area_and_count_of_valid_GDUs_at_each_reconstruction_time_for_"+modelname+"_"+yearmonthday+".csv"
		new_dataframe.to_csv(filename,index = False)

def study_rotation_of_member_with_the_anchor(rotation_model,member_GDU_ID,from_time,to_time,reference):
	#Get the rotation of "other plate" from other_plate_ID from previous_reconstruction_time which is reconstruction_time + interval to reconstruction_time
	equivalent_stage_rotation_ref_plate = None
	if (reference is None):
		equivalent_stage_rotation_ref_plate = rotation_model.get_rotation(float(to_time),member_GDU_ID,float(from_time),anchor_plate_id = 0,use_identity_for_missing_plate_ids = False)
	else:
		equivalent_stage_rotation_ref_plate = rotation_model.get_rotation(float(to_time),member_GDU_ID,float(from_time),anchor_plate_id = reference,use_identity_for_missing_plate_ids = False)
	if (equivalent_stage_rotation_ref_plate is not None):
		pole_latitude, pole_longitude, angle_degrees = equivalent_stage_rotation_ref_plate.get_lat_lon_euler_pole_and_angle_degrees()
		return pole_latitude, pole_longitude, angle_degrees
	else:
		return None

def calculate_number_of_valid_rotation_records_for_valid_GDUs_at_each_reconstruction_time(GDU_features_shp_or_gpml_file, rotation_file, reference, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time):
	GDU_features = pygplates.FeatureCollection(GDU_features_shp_or_gpml_file)
	output_dic = {"reconstruction_time":[],"total_valid_rot_records":[],"count_features":[]}
	rotation_model = pygplates.RotationModel(rotation_file)
	current_time = begin_reconstruction_time
	already_included = []
	list_of_valid_GDU_w_valid_rot = []
	while (current_time > (end_reconstruction_time - interval_reconstruction_time)):
		list_of_valid_GDU_features = [ft for ft in GDU_features if ft.is_valid_at_time(current_time)]
		list_of_valid_GDU_w_valid_rot[:] = []
		total_valid_rot_records = 0
		already_included[:] = []
		for valid_GDU_ft in list_of_valid_GDU_features:
			gdu_id = valid_GDU_ft.get_reconstruction_plate_id()
			if (gdu_id not in already_included):
				already_included.append(gdu_id)
				rot = study_rotation_of_member_with_the_anchor(rotation_model,gdu_id,current_time+interval_reconstruction_time,current_time,reference)
				if (rot is not None):
					total_valid_rot_records = total_valid_rot_records + 1
		output_dic["reconstruction_time"].append(current_time)
		output_dic["total_valid_rot_records"].append(total_valid_rot_records)
		output_dic["count_features"].append(len(list_of_valid_GDU_features))
		current_time = current_time - interval_reconstruction_time
	return output_dic

def calculate_area_for_valid_GDUs_w_valid_rot_at_each_reconstruction_time(GDU_features_shp_file, rotation_file, reference, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time, field_of_begin_age_for_ft, field_of_end_age_for_ft, field_of_GDUID, epsg_code, convert_squared_meters_to_squared_km, modelname, yearmonthday):
	gdf = gpd.read_file(GDU_features_shp_file)
	project_gdf = gdf.to_crs(epsg_code)
	GDU_features = pygplates.FeatureCollection(GDU_features_shp_file)
	output_dic = {"reconstruction_time":[],"total_valid_rot_records":[],"count_features":[],"total_area":[]}
	rotation_model = pygplates.RotationModel(rotation_file)
	current_time = begin_reconstruction_time
	already_included = []
	list_of_valid_GDU_w_valid_rot = []
	while (current_time > (end_reconstruction_time - interval_reconstruction_time)):
		list_of_valid_GDU_features = [ft for ft in GDU_features if ft.is_valid_at_time(current_time)]
		list_of_valid_GDU_w_valid_rot[:] = []
		total_valid_rot_records = 0
		already_included[:] = []
		for valid_GDU_ft in list_of_valid_GDU_features:
			gdu_id = valid_GDU_ft.get_reconstruction_plate_id()
			if (gdu_id not in already_included):
				already_included.append(gdu_id)
				rot = study_rotation_of_member_with_the_anchor(rotation_model,gdu_id,current_time+interval_reconstruction_time,current_time,reference)
				if (rot is not None):
					total_valid_rot_records = total_valid_rot_records + 1
					list_of_valid_GDU_w_valid_rot.append(gdu_id)
		output_dic["reconstruction_time"].append(current_time)
		output_dic["total_valid_rot_records"].append(total_valid_rot_records)
		output_dic["count_features"].append(len(list_of_valid_GDU_features))
		
		total_area = 0.00
		for gdu_id in list_of_valid_GDU_w_valid_rot:
			selected_records = project_gdf.loc[(project_gdf[field_of_begin_age_for_ft] >= current_time) & (project_gdf[field_of_end_age_for_ft] <= current_time) & (project_gdf[field_of_GDUID] == gdu_id)]
			print("len(selected_records)",len(selected_records))
			if (len(selected_records) > 0):
				total_area_in_sq_meters = selected_records.geometry.area.sum()
				if (convert_squared_meters_to_squared_km == True):
					total_area = total_area + (total_area_in_sq_meters/1000000.000)
				else:
					total_area = total_area + total_area_in_sq_meters
			print("current_time", current_time)
		output_dic["total_area"].append(total_area)
		current_time = current_time - interval_reconstruction_time
	df = pd.DataFrame.from_dict(output_dic)
	filename = "area_for_valid_GDUs_w_valid_rot_at_each_reconstruction_time_for_"+modelname+"_"+yearmonthday+".csv"
	df.to_csv(filename,index = False)


def calculate_number_of_valid_rotation_records_for_valid_GDUs_at_each_reconstruction_time_for_multiple_models(list_of_GDU_features_files, list_of_rotation_files, list_of_references, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time, list_of_modelnames_associated_with_GDU_fts_files, yearmonthday):
	number_of_files = len(list_of_GDU_features_files)
	if (number_of_files != len(list_of_rotation_files)):
		print("Error in calculate_area_of_valid_GDUs_at_each_reconstruction_time_for_multiple_models")
		print("len(list_of_GDU_features_files) != len(list_of_rotation_files)")
		print("please make sure to provide the rotation file for each GDU_feature_file in the list_of_GDU_features_files")
		print("list_of_GDU_features_files")
		print(list_of_GDU_features_files)
		print("list_of_rotation_files")
		print(list_of_rotation_files)
		exit()
	if (number_of_files != len(list_of_references)):
		print("Error in calculate_area_of_valid_GDUs_at_each_reconstruction_time_for_multiple_models")
		print("len(list_of_GDU_features_files) != len(list_of_references)")
		print("please make sure to provide the reference frame for each rotation file associated with each GDU_feature_file in the list_of_GDU_features_files")
		print("list_of_GDU_features_files")
		print(list_of_GDU_features_files)
		print("list_of_references")
		print(list_of_references)
		exit()
	if (number_of_files != len(list_of_modelnames_associated_with_GDU_fts_files)):
		print("Error in calculate_area_of_valid_GDUs_at_each_reconstruction_time_for_multiple_models")
		print("len(list_of_GDU_features_files) != len(list_of_modelnames_associated_with_GDU_fts_files)")
		print("please make sure to provide the modelname for each GDU_feature_file in the list_of_GDU_features_files")
		print("list_of_GDU_features_files")
		print(list_of_GDU_features_files)
		print("list_of_modelnames_associated_with_GDU_fts_files")
		print(list_of_modelnames_associated_with_GDU_fts_files)
		exit()
	number_of_files = len(list_of_GDU_features_files)
	for i in range(0,number_of_files):
		each_file = list_of_GDU_features_files[i]
		rotation_model = list_of_rotation_files[i]
		reference = list_of_references[i]
		modelname = list_of_modelnames_associated_with_GDU_fts_files[i]
		print("file",each_file)
		output_dic = calculate_number_of_valid_rotation_records_for_valid_GDUs_at_each_reconstruction_time(each_file, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time)
		new_dataframe = pd.DataFrame.from_dict(output_dic)
		filename = "count_valid_rot_records_and_GDUs_present_at_each_reconstruction_time_for_"+modelname+"_"+yearmonthday+".csv"
		new_dataframe.to_csv(filename,index = False)

def identify_initial_gdu_polygon_features_with_invalid_age_or_invalid_rotation(GDU_features_shp_or_gpml_file, rotation_file, max_reconstruction_time, reference, interval_reconstruction_time, modelname, yearmonthday):
	output_valid_gdu_features = pygplates.FeatureCollection()
	output_invalid_age_gdu_features = pygplates.FeatureCollection()
	output_invalid_rot_gdu_features = pygplates.FeatureCollection()
	GDU_features = pygplates.FeatureCollection(GDU_features_shp_or_gpml_file)
	output_dic_for_rot = {"reconstruction_time":[],"invalid_gdu":[]}
	rotation_model = pygplates.RotationModel(rotation_file)
	already_checked = []
	list_of_valid_GDU_w_valid_rot = []
	
	#check the initial valid age relationship
	for initial_gdu_ft in GDU_features:
		from_age,end_age = initial_gdu_ft.get_valid_time()
		if (from_age < end_age or from_age < 0.00 or pygplates.GeoTimeInstant(from_age).is_distant_past()):
			fid = initial_gdu_ft.get_feature_id()
			if (fid not in already_checked):
				already_checked.append(fid)
				output_invalid_age_gdu_features.add(initial_gdu_ft)
	#check whether the period that GDU feature is valid there is always a rotation record
	for initial_gdu_ft in GDU_features:
		fid = initial_gdu_ft.get_feature_id()
		if (fid not in already_checked):
			already_checked.append(fid)
			gdu_id = initial_gdu_ft.get_reconstruction_plate_id()
			begin_reconstruction_time, end_reconstruction_time = initial_gdu_ft.get_valid_time()
			current_time = begin_reconstruction_time
			if (current_time > max_reconstruction_time):
				current_time = max_reconstruction_time
			is_valid = True
			# while (current_time > end_reconstruction_time):
				# rot = study_rotation_of_member_with_the_anchor(rotation_model, gdu_id, current_time, current_time-interval_reconstruction_time, reference)
				# if (rot is None):
					# output_dic_for_rot['reconstruction_time'].append(current_time)
					# output_dic_for_rot['invalid_gdu'].append(gdu_id)
					# is_valid = False
					# break
				# current_time = current_time - interval_reconstruction_time
			to_time_for_rot = 0.00
			if (current_time-interval_reconstruction_time < 0.00):
				to_time_for_rot = 0.00
			else:
				to_time_for_rot = current_time-interval_reconstruction_time
			rot = study_rotation_of_member_with_the_anchor(rotation_model, gdu_id, current_time, to_time_for_rot, reference)
			if (rot is None):
				output_dic_for_rot['reconstruction_time'].append(current_time)
				output_dic_for_rot['invalid_gdu'].append(gdu_id)
				is_valid = False
			if (is_valid == True):
				output_valid_gdu_features.add(initial_gdu_ft)
			else:
				output_invalid_rot_gdu_features.add(initial_gdu_ft)
	output_valid_gdu_features.write("gdu_features_w_valid_age_and_rotation_"+modelname+"_"+yearmonthday+".shp")
	if (len(output_invalid_rot_gdu_features) > 0):
		output_invalid_rot_gdu_features.write("gdu_features_w_invalid_rotation_"+modelname+"_"+yearmonthday+".shp")
		invalid_df = pd.DataFrame.from_dict(output_dic_for_rot)
		invalid_df.to_csv("records_of_invalid_rot_gdu_features_"+modelname+"_"+yearmonthday+".csv")
	if (len(output_invalid_age_gdu_features)):
		output_invalid_age_gdu_features.write("gdu_features_w_invalid_age_"+modelname+"_"+yearmonthday+".shp")

def validate_geometry_of_input_gdu_features_at_present_day(gdu_features_shp_file, field_of_GDUID, modelname, yearmonthday):
	initial_gdf = gpd.read_file(gdu_features_shp_file)
	#explode from Multipart geometry to Singlepart
	explode_gdf = initial_gdf.explode()
	#check validity 
	results_validation = explode_gdf['geometry'].is_valid
	explode_gdf['isvalid'] = results_validation
	#assign unique polygid 
	current_id = 10000
	number_of_features = len(explode_gdf)
	array_of_GDUID = explode_gdf[field_of_GDUID].to_numpy()
	print('number_of_features',number_of_features)
	print('len(array_of_GDUID)',len(array_of_GDUID))
	list_of_polygid = []
	for i in range(0, number_of_features):
		current_GDUID = array_of_GDUID[i]
		polygid = str(current_GDUID)+'_'+str(10000+i)
		list_of_polygid.append(polygid)
	explode_gdf['POLYGID'] = list_of_polygid
	valid_gdu_features = explode_gdf.loc[explode_gdf['isvalid'] == True]
	valid_gdu_features.to_file("gdu_features_w_all_valid_attributes_"+modelname+"_"+yearmonthday+".shp")
	invalid_gdu_features = explode_gdf.loc[explode_gdf['isvalid'] == False]
	if (len(invalid_gdu_features) > 0):
		invalid_gdu_features.to_file("gdu_features_w_invalid_geom_"+modelname+"_"+yearmonthday+".shp")

def main():
	#Pre-process input reconstruction model - for PlatePolygons_Continental.shp
	#First with age and rotation record at each age
	modelname = "PalaeoPlatesendJan2023"
	yearmonthday = "20231125"
	initial_GDU_features_shp_or_gpml_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\PlatePolygons_Continental.shp"
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	reference = 700
	interval_reconstruction_time = 5.00
	#identify_initial_gdu_polygon_features_with_invalid_age_or_invalid_rotation(initial_GDU_features_shp_or_gpml_file, rotation_file, reference, interval_reconstruction_time, modelname, yearmonthday)
	
	gdu_features_shp_file = r"gdu_features_w_valid_age_and_rotation_PalaeoPlatesendJan2023_20231125.shp"
	field_of_GDUID = r"PLATEID1"
	#validate_geometry_of_input_gdu_features_at_present_day(gdu_features_shp_file, field_of_GDUID, modelname, yearmonthday)
	
	#Pre-process input reconstruction model - for the all continental polygon features designed for the PalaeoPlates model 
	#First with age and rotation record at each age
	modelname = "all_cont_PalaeoPlatesFeb2024"
	yearmonthday = "20240217"
	#GDU_features_shp_or_gpml_file = r"C:\Users\lavie\Desktop\Research\Winter2024\PalaeoPlatesFeb2024\PlatePolygons_Continental.shp"
	GDU_features_shp_or_gpml_file = r"C:\Users\lavie\Desktop\Research\Winter2024\PalaeoPlatesFeb2024\all_gdu_features_w_all_valid_attributes_PalaeoPlatesFeb2024_20240214.shp"
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2024\PalaeoPlatesFeb2024\T_Rot_Model_PalaeoPlates_20240205.grot"
	#rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2024/T_Rot_Model_PalaeoPlates_20240205.grot"
	reference = 700
	interval_reconstruction_time = 5.00
	max_reconstruction_time = 3000.00
	#identify_initial_gdu_polygon_features_with_invalid_age_or_invalid_rotation(GDU_features_shp_or_gpml_file, rotation_file, max_reconstruction_time, reference, interval_reconstruction_time, modelname, yearmonthday)
	
	gdu_features_shp_file = r"gdu_features_w_valid_age_and_rotation_all_cont_PalaeoPlatesFeb2024_20240214.shp"
	field_of_GDUID = r"PlateID"
	#validate_geometry_of_input_gdu_features_at_present_day(gdu_features_shp_file, field_of_GDUID, modelname, yearmonthday)
	
	#Calculate area of all valid GDU features at each reconstruction time. A valid GDU feature has a valid geometry and a valid rotation record at the time. 
	GDU_features_shp_file = GDU_features_shp_or_gpml_file
	begin_reconstruction_time = 3000.00
	end_reconstruction_time = 0.00
	interval_reconstruction_time = 5.00
	field_of_begin_age_for_ft = "LimOldP"
	field_of_end_age_for_ft = "LimYngP"
	epsg_code = r"ESRI:54009"
	convert_squared_meters_to_squared_km = True
	#calculate_area_for_valid_GDUs_w_valid_rot_at_each_reconstruction_time(GDU_features_shp_file, rotation_file, reference, begin_reconstruction_time, end_reconstruction_time, interval_reconstruction_time, field_of_begin_age_for_ft, field_of_end_age_for_ft, field_of_GDUID, epsg_code, convert_squared_meters_to_squared_km, modelname, yearmonthday)

if __name__ == '__main__':
	main()
