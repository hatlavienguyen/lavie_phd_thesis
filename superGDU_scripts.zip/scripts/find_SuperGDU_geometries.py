import os
import csv
import math
#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.errors import TopologicalError
from shapely.geometry import Point, Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, JOIN_STYLE
from shapely.ops import unary_union, transform, cascaded_union, polygonize, polygonize_full, linemerge, triangulate 
from functools import partial
from shapely.validation import explain_validity
import pyproj

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(line):
	if (line.length > 0.00):
		try:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.coords]
		except NotImplementedError as error:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.exterior.coords]
		line_on_sphere = pygplates.PolylineOnSphere(list_of_lat_lon_vertices)
		if (line_on_sphere is None):
			print ("Error to convert convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
			print ("Here is a list_of_lat_lon_vertices")
			print (list_of_lat_lon_vertices)
			print (list_of_lat_lon_vertices)
			exit()
		return line_on_sphere
	else:
		print ("Error in convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
		print ("line.length == 0")
		print ("here are coords for line:")
		print((line.coords))
		print ("here is line")
		print (line)
		exit()

def convert_Polygon_to_PolygonOnSphere_in_pygplates(each_polygon):
	if (each_polygon.area > 0.00):
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			#print("lat,lon")
			#print(lat,lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
				print("Warning invalid value of latitude or/and longitude")
				print("value of latitude")
				print(lat)
				print("value of longitude")
				print(lon)
				if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
					if (abs(abs(lat) - 90.00) < 0.500):
						if (lat < -90.00):
							lat = -90.000
						elif (lat > 90.00):
							lat = 90.000
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of latitude")
						print("value of latitude")
						print(lat)					
						exit()
				if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
					if (abs(abs(lon) - 180.00) < 0.500):
						if (lon < -180.00):
							lon = -180.00
						elif (lon > 180.00):
							lon = 180.00
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of longitude")
						print("value of longitude")
						print(lon)					
						exit()
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print("Error in creating polygon in pygplates in conversion module")
			print("Here is a list of lat_lon vertices")
			print(list_of_lat_lon_vertices)
			print("Here is the first vertex and the last vertex:")
			print(list_of_lat_lon_vertices[0])
			print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
			exit()
		return new_polygon
	else:
		print("Error in creating polygon in pygplates in conversion module")
		print("Error each_polygon.area <= 0.00")
		print("here is each_polygon")
		print(each_polygon)
		print([(lon,lat) for lon,lat in each_polygon.exterior.coords])
		exit()

def create_LinearRing_to_PolygonOnSphere_in_pygplates(each_ring):
	list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_ring.coords)]
	final_list_of_lat_lon_vertices = []
	for lat,lon in list_of_lat_lon_vertices:
		#print("lat,lon")
		#print(lat,lon)
		if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
			print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
			print("Warning invalid value of latitude or/and longitude")
			print("value of latitude")
			print(lat)
			print("value of longitude")
			print(lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
				if (abs(abs(lat) - 90.00) < 0.500):
					if (lat < -90.00):
						lat = -90.000
					elif (lat > 90.00):
						lat = 90.000
				else:
					print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
					print("Error invalid value of latitude")
					print("value of latitude")
					print(lat)					
					exit()
			if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				if (abs(abs(lon) - 180.00) < 0.500):
					if (lon < -180.00):
						lon = -180.00
					elif (lon > 180.00):
						lon = 180.00
				else:
					print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
					print("Error invalid value of longitude")
					print("value of longitude")
					print(lon)					
					exit()
		final_list_of_lat_lon_vertices.append((lat,lon))	
	new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
	if (new_polygon is None):
		print("Error in creating polygon in pygplates in conversion module")
		print("Here is a list of lat_lon vertices")
		print(list_of_lat_lon_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lat_lon_vertices[0])
		print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
		exit()
	return new_polygon
	

def convert_polygon_to_Polygon_in_shapely(each_polygon):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in each_polygon.to_lat_lon_list()]
	new_polygon = Polygon(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating Polygon in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_polygon


def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = mean(lat_values)
				mean_lon = mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def are_two_geometries_within_a_threshold_distance_km(geometry_1,geometry_2,threshold_distance_km):
	#find the two closest between these two polygons
	distance,point_on_geometry_1,point_on_geometry_2 =  pygplates.GeometryOnSphere.distance(geometry_1, geometry_2, return_closest_positions=True)
	lat1,lon1 = point_on_geometry_1.to_lat_lon()
	lat2,lon2 = point_on_geometry_2.to_lat_lon()
	distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
	if (distance_in_km > threshold_distance_km):
		return False
	else:
		return True
	
def pre_process_polygon_features_from_shp_file(list_of_polygon_GDU_fts,modelname,yearmonthday,write_ouput):
	list_of_processed_polygon_features = []
	featType = pygplates.FeatureType.gpml_continental_crust
	for polygon_ft in list_of_polygon_GDU_fts:
		#obtain the geometries of a polygon ft_begin_age
		polygons = polygon_ft.get_geometries()
		#choose the polygon that have the most points
		final_polygon = None
		number_of_points = 0
		for each_polygon in polygons:
			current_number_of_points = len(each_polygon.to_lat_lon_list())
			if (current_number_of_points > number_of_points):
				final_polygon = each_polygon
				number_of_points = current_number_of_points
		#once we have a final polygon with the most points we want to create a dateline wrapper for the polygons,if it is required
		# Wrap a polygon to the range [-180, +180].
		date_line_wrapper = pygplates.DateLineWrapper()
		wrapped_polygons = date_line_wrapper.wrap(final_polygon)
		for wrapped_polygon in wrapped_polygons:
			#print 'value of wrapped_polygon'
			#print wrapped_polygon
			new_polygon = pygplates.PolygonOnSphere(wrapped_polygon.get_exterior_points())
			#create a new polygon feature for each wrapped polygon
			new_polygon_ft = pygplates.Feature.create_reconstructable_feature(featType,new_polygon,valid_time = polygon_ft.get_valid_time(), reconstruction_plate_id = polygon_ft.get_reconstruction_plate_id())
			list_of_processed_polygon_features.append(new_polygon_ft)
			#for wrapped_point in wrapped_polygon.get_exterior_points():
			#	wrapped_point_lat_lon = wrapped_point.get_latitude(), wrapped_point.get_longitude()
	if (write_ouput == True):
		outputFeatureCollection = pygplates.FeatureCollection(list_of_processed_polygon_features)
		outputFeatureFile = './pre_processed_polygon_fts_'+modelname+'_'+yearmonthday+'.shp'
		outputFeatureCollection.write(outputFeatureFile)
		outputFeatureFile = './pre_processed_polygon_fts_'+modelname+'_'+yearmonthday+'.gpml'
		outputFeatureCollection.write(outputFeatureFile)
	return list_of_processed_polygon_features

# def clean_polygon_features_w_date_line_wrapper(rotation_model,list_of_polygon_GDU_fts,reconstruction_time,reference,modelname,yearmonthday):
	# reconstructed_polygon_features = []
	# final_reconstructed_polygon_features = []
	# reconstructed_dissolved_polygon_features = []
	# reconstructed_line_features = []
	# reconstructed_dangles_cuts = []
	# distant_future = pygplates.GeoTimeInstant.create_distant_future()
	# #reconstruct all features to reconstruction_time
	# list_of_valid_polygon_fts = [polygon_ft for polygon_ft in list_of_polygon_GDU_fts if polygon_ft.is_valid_at_time(reconstruction_time)]
	# if (reference is not None):
		# #polygon_features
		# pygplates.reconstruct(list_of_valid_polygon_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	# else:
		# #polygon_features
		# pygplates.reconstruct(list_of_valid_polygon_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
	# final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
	# error_polygon_fts = []
	
	# polygon_fts_and_wrapped_polygons = []
	# polygon_fts_clean_polygons = []
	
	# for polygon_ft,polygon in final_reconstructed_polygon_features:
		# #wrap polygon with the DateLineWrapper
		# date_line_wrapper = pygplates.DateLineWrapper()
		# wrapped_polygons = date_line_wrapper.wrap(polygon)
		# for wrapped_polygon in wrapped_polygons:
			# new_polygon = pygplates.PolygonOnSphere(wrapped_polygon.get_exterior_points())
			# clone_feature = polygon_ft.clone()
			# clone_feature.set_geometry(new_polygon)
			# clone_feature.set_name('wrapped_polygon_ft_'+polygon_ft.get_name())
			# polygon_fts_and_wrapped_polygons.append((clone_feature,new_polygon))
			
	# for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		# featType = polygon_ft.get_feature_type()
		# #original_name = polygon_ft.get_name()
		# #convert polygon to the list of lat lon tuples
		# list_of_lat_lon_tuples = polygon.to_lat_lon_list()
		# Polygon_in_shapely = convert_polygon_to_Polygon_in_shapely(polygon)
		# new_feature = None
		# if (Polygon_in_shapely.is_valid):
			# #convert the polygon to PolygonOnSphere
			# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(Polygon_in_shapely)
			# #create new Feature in pygplates
			# #new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='wrapped_polygon_ft_'+original_name,valid_time = polygon_ft.get_valid_time(),reconstruction_plate_id = polygon_ft.get_reconstruction_plate_id())
			# if (polygon_ft is not None):
				# reconstructed_dissolved_polygon_features.append(polygon_ft)
			# polygon_fts_clean_polygons.append((polygon_ft,polygon))
		# else:
			# error_polygon_fts.append(polygon_ft)
			# original_list_of_lon_lat = [(lon,lat) for lat,lon in polygon.to_lat_lon_list()]
			# #print(original_list_of_lon_lat)
			# #using list comprehension + enumerate() 
			# #to remove duplicated  
			# #from list  -- reference: https://www.geeksforgeeks.org/python-ways-to-remove-duplicates-from-list/
			# res = [i for n, i in enumerate(original_list_of_lon_lat) if i not in original_list_of_lon_lat[:n]] 
			# #print(res)
			# #print("len(original_list_of_lon_lat),len(res)")
			# #print(len(original_list_of_lon_lat),len(res))
			# #pre process res
			# for index in range(0,len(res)):
				# if (index > 0):
					# current_lon,current_lat = res[index]
					# previous_lon,previous_lat = res[index - 1]
					# if ((current_lon > 0 and previous_lon < 0) or (current_lon < 0 and previous_lon > 0)):
						# res[index] = (current_lon * (-1.00),current_lat)
			# new_LineString = LineString(res[:]+res[0:1])
			# #print("new_LineString.is_simple")
			# #print(new_LineString.is_simple)
			# new_Polygon = Polygon(res)
			# if (new_Polygon.is_valid):
				# #convert the polygon to PolygonOnSphere
				# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(new_Polygon)
				# clone_feature = polygon_ft.clone()
				# clone_feature.set_geometry(new_PolygonOnSphere)
				# clone_feature.set_name("fixed_polygon_ft_with_dateline_wrapper_remove_duplicate_points"+polygon_ft.get_name())
				# if (clone_feature is not None):
					# reconstructed_dissolved_polygon_features.append(clone_feature)
				# polygon_fts_clean_polygons.append((clone_feature,new_PolygonOnSphere))
			# else:
				# #print(explain_validity(new_Polygon))
				# new_MultiLineString = unary_union(new_LineString)
				# #for l in new_MultiLineString:
				# #	list_of_lat_lon_points = [pygplates.PointOnSphere((lat,lon)) for lon,lat in l.coords]
				# #	new_LineOnSphere = pygplates.PolylineOnSphere(list_of_lat_lon_points)
					# #create new Feature in pygplates
				# #	new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_LineOnSphere,name='line_ft_with_new_LineString',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
				# #	new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
				# #	if (new_feature is not None):
				# #		reconstructed_line_features.append(new_feature)
			
				# result, dangles, cuts, invalids = polygonize_full(new_MultiLineString)
				# if (result.geom_type == "GeometryCollection"):
					# for polygon in result:
						# # print("valid polygon in result")
						# # print(polygon.is_valid)
						# # print(explain_validity(result))
						
						# #convert the polygon to PolygonOnSphere
						# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
						
						# #create new Feature in pygplates
						# # new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='cleaned_polygon_ft',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
						# # new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
						# # if (new_feature is not None):
							# # reconstructed_dissolved_polygon_features.append(new_feature)
						
						# clone_feature = polygon_ft.clone()
						# clone_feature.set_geometry(new_PolygonOnSphere)
						# clone_feature.set_name("fixed_polygon_ft_with_dateline_wrapper_and_polygonize"+polygon_ft.get_name())
						# if (clone_feature is not None):
							# reconstructed_dissolved_polygon_features.append(clone_feature)
						# polygon_fts_clean_polygons.append((clone_feature,new_PolygonOnSphere))
				# else:
					# #print(new_LineString)
					# #print(new_LineString.buffer(0))
					# print("result")
					# print(result)
					# print(result.geom_type)
					# print(explain_validity(result))
					# exit()
			
				# #if (dangles.is_empty == False or cuts.is_empty == False or invalids.is_empty == False):
				# if (invalids.is_empty == False):
					# print("Error in clean_polygon_features")
					# print("dangles, cuts, invalids")
					# print(dangles, cuts, invalids)
					# invalid_reconstruced_polygon_fts = []
					# #simplify invalids with unary_union
					# union_geometries = unary_union(invalids)
					# for polygon in polygonize(invalids):
						# print (polygon.is_valid)
						# #convert the polygon to PolygonOnSphere
						# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
						# #create new Feature in pygplates
						# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='invalid_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
						# new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
						# if (new_feature is not None):
							# invalid_reconstruced_polygon_fts.append(new_feature)
					# #reverse_reconstruct
					# if (reference is not None):
						# pygplates.reverse_reconstruct(invalid_reconstruced_polygon_fts,rotation_model,reconstruction_time,reference)
					# else:
						# pygplates.reverse_reconstruct(invalid_reconstruced_polygon_fts,rotation_model,reconstruction_time)
					
					# outputFeatureCollection = pygplates.FeatureCollection(invalid_reconstruced_polygon_fts)
					# outputFeatureFile = 'invalid_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
					# outputFeatureCollection.write(outputFeatureFile)
					# outputFeatureFile = 'invalid_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
					# outputFeatureCollection.write(outputFeatureFile)
					
					# #reverse_reconstruct
					# if (reference is not None):
						# pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
						# pygplates.reverse_reconstruct(error_polygon_fts,rotation_model,reconstruction_time,reference)
					# else:
						# pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
						# pygplates.reverse_reconstruct(error_polygon_fts,rotation_model,reconstruction_time)
	
					# polygon_fts_with_dateline_wrapper = pre_process_polygon_features_from_shp_file(reconstructed_dissolved_polygon_features,modelname,yearmonthday,False)
	
					# outputFeatureCollection = pygplates.FeatureCollection(polygon_fts_with_dateline_wrapper)
					# outputFeatureFile = 'fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
					# outputFeatureCollection.write(outputFeatureFile)
					# outputFeatureFile = 'fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
					# outputFeatureCollection.write(outputFeatureFile)
	
					# outputFeatureCollection = pygplates.FeatureCollection(error_polygon_fts)
					# outputFeatureFile = 'required_to_be_fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
					# outputFeatureCollection.write(outputFeatureFile)
					# outputFeatureFile = 'required_to_be_fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
					# outputFeatureCollection.write(outputFeatureFile)

					# exit()
				
				# #This could be helpful for future model development but not important to find SuperGDU features
				# # if (dangles.is_empty == False or cuts.is_empty == False):
					# # if (dangles.is_empty == False):
						# # for d in dangles:
							# # list_of_lat_lon_points = [pygplates.PointOnSphere((lat,lon)) for lon,lat in d.coords]
							# # new_LineOnSphere = pygplates.PolylineOnSphere(list_of_lat_lon_points)
							# # #create new Feature in pygplates
							# # new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_LineOnSphere,name='dangle_ft_',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
							# # new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
							# # if (new_feature is not None):
								# # reconstructed_dangles_cuts.append(new_feature)
					# # if (cuts.is_empty == False):
						# # for c in cuts:
							# # list_of_lat_lon_points = [pygplates.PointOnSphere((lat,lon)) for lon,lat in c.coords]
							# # new_LineOnSphere = pygplates.PolylineOnSphere(list_of_lat_lon_points)
							# # #create new Feature in pygplates
							# # new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_LineOnSphere,name='cut_ft_',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
							# # new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
							# # if (new_feature is not None):
								# # reconstructed_dangles_cuts.append(new_feature)
	# #reverse_reconstruct
	# if (reference is not None):
		# pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
		# # pygplates.reverse_reconstruct(reconstructed_line_features,rotation_model,reconstruction_time,reference)
		# # pygplates.reverse_reconstruct(error_polygon_fts,rotation_model,reconstruction_time,reference)
		# # pygplates.reverse_reconstruct(reconstructed_dangles_cuts,rotation_model,reconstruction_time,reference)
	# else:
		# pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
		# # pygplates.reverse_reconstruct(reconstructed_line_features,rotation_model,reconstruction_time)
		# # pygplates.reverse_reconstruct(error_polygon_fts,rotation_model,reconstruction_time)
		# # pygplates.reverse_reconstruct(reconstructed_dangles_cuts,rotation_model,reconstruction_time)
	# polygon_fts_with_dateline_wrapper_at_present = pre_process_polygon_features_from_shp_file(reconstructed_dissolved_polygon_features,modelname,yearmonthday,False)
	# return(polygon_fts_with_dateline_wrapper_at_present,polygon_fts_clean_polygons)

# def find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time(rotation_model,list_of_polygon_GDU_fts,reconstruction_time,reference,modelname,yearmonthday,warning_on):
	# featType = pygplates.FeatureType.gpml_continental_crust
	# error_polygon_fts = []
	# _,polygon_fts_and_wrapped_polygons= clean_polygon_features_w_date_line_wrapper(rotation_model,list_of_polygon_GDU_fts,reconstruction_time,reference,modelname,yearmonthday)
	# #_,polygon_fts_and_wrapped_polygons= clean_polygon_features_w_changing_longitude(rotation_model,list_of_polygon_GDU_fts,reconstruction_time,reference,modelname,yearmonthday)
	# polygons_for_unary_union = []
	# reconstructed_dissolved_polygon_features = []
	# if (polygon_fts_and_wrapped_polygons is None):
		# print ("Error in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
		# print ("Error polygon_fts_and_wrapped_polygons is None")
		# print ("Here is input list_of_polygon_GDU_fts:")
		# print (list_of_polygon_GDU_fts)
		# exit()
	# if (len(polygon_fts_and_wrapped_polygons) == 0):
		# print ("Suspection in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
		# print ("Issue len(polygon_fts_and_wrapped_polygons) == 0")
		# print ("Here is input list_of_polygon_GDU_fts:")
		# print (list_of_polygon_GDU_fts)
		# if (warning_on == True):
			# exit()
	# for polygon_ft,polygon in polygon_fts_and_wrapped_polygons: 
		# #create polygon in Shapely from PolygonOnSphere
		# Polygon_in_shapely = convert_polygon_to_Polygon_in_shapely(polygon)
		
		# if (Polygon_in_shapely.is_valid == False):
			# print("Error in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
			# print("Error Polygon_in_shapely is invalid")
			# print(explain_validity(Polygon_in_shapely))
			# print(polygon.to_lat_lon_list())
			# error_features = pygplates.FeatureCollection()
			# error_features.add(polygon_ft)
			# error_features.write("invalid_polygon_in_Shapely_at_"+str(reconstruction_time)+"_"+str(polygon_ft.get_name())+"_"+str(polygon_ft.get_reconstruction_plate_id())+".shp")
			# #exit()
		# else:
			# polygons_for_unary_union.append(Polygon_in_shapely)
	# #perform union 
	# result = unary_union([polygon for polygon in polygons_for_unary_union])
	# if (result.geom_type == 'Polygon'):
		# if (result.is_valid):
			# #only take the exterior 
			# #convert the polygon to PolygonOnSphere
			# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(result)
			# #create new Feature in pygplates
			# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='dissolved_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
			# if (reference is not None):
				# new_feature.set_reconstruction_plate_id(reference)
			# reconstructed_dissolved_polygon_features.append(new_feature)
		# else:
			# buffer_result = result.buffer(0.0001)
			# if (buffer_result.is_valid):
				# if (buffer_result.geom_type == "Polygon"):
					# #convert the polygon to PolygonOnSphere
					# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(buffer_result)
					# #create new Feature in pygplates
					# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='dissolved_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
					# if (reference is not None):
						# new_feature.set_reconstruction_plate_id(reference)
					# reconstructed_dissolved_polygon_features.append(new_feature)
				# elif (buffer_result.geom_type == "MultiPolygon"):
					# for polygon in buffer_result.geoms:
						# #convert the polygon to PolygonOnSphere
						# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
						# #create new Feature in pygplates
						# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='dissolved_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
						# if (reference is not None):
							# new_feature.set_reconstruction_plate_id(reference)
						# reconstructed_dissolved_polygon_features.append(new_feature)
			# else:
				# print("Error in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
				# print("Error buffer result is invalid")
				# print(buffer_result)
				# exit()
	# elif (result.geom_type == 'MultiPolygon'):
		# for polygon in result.geoms:
			# if (polygon.is_valid):
				# #convert the polygon to PolygonOnSphere
				# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
				# #create new Feature in pygplates
				# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='dissolved_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
				# if (reference is not None):
					# new_feature.set_reconstruction_plate_id(reference)
				# reconstructed_dissolved_polygon_features.append(new_feature)
			# else:
				# buffer_result = polygon.buffer(0.0001)
				# if (buffer_result.is_valid):
					# if (buffer_result.geom_type == "Polygon"):
						# #convert the polygon to PolygonOnSphere
						# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(buffer_result)
						# #create new Feature in pygplates
						# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='dissolved_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
						# if (reference is not None):
							# new_feature.set_reconstruction_plate_id(reference)
						# reconstructed_dissolved_polygon_features.append(new_feature)
					# elif (buffer_result.geom_type == "MultiPolygon"):
						# for polygon in buffer_result.geoms:
							# #convert the polygon to PolygonOnSphere
							# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
							# #create new Feature in pygplates
							# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='dissolved_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
							# if (reference is not None):
								# new_feature.set_reconstruction_plate_id(reference)
						# reconstructed_dissolved_polygon_features.append(new_feature)
				# else:
					# print("Error in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
					# print("Error buffer result is invalid")
					# print(buffer_result)
					# exit()
	# #reverse_reconstruct
	# if (reference is not None):
		# pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
	# else:
		# pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
	
	# polygon_fts_with_dateline_wrapper = pre_process_polygon_features_from_shp_file(reconstructed_dissolved_polygon_features,modelname,yearmonthday,False)
	
	# if (len(error_polygon_fts) > 0):
		# outputFeatureCollection = pygplates.FeatureCollection(error_polygon_fts)
		# outputFeatureFile = 'error_polygon_fts_when_find_dissolve'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
		# outputFeatureCollection.write(outputFeatureFile)
		# outputFeatureFile = 'error_polygon_fts_when_find_dissolve'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
		# outputFeatureCollection.write(outputFeatureFile)
	
	# return polygon_fts_with_dateline_wrapper

#ideas for the implementation from Pawarit Laosunthara - https://towardsdatascience.com/around-the-world-in-80-lines-crossing-the-antimeridian-with-python-and-shapely-c87c9b6e1513
def is_crossing_the_DateLine(geometry):
	list_of_lat_lon = geometry.to_lat_lon_list()
	for lat1,lon1 in list_of_lat_lon:
		for lat2,lon2 in list_of_lat_lon:
			if (abs(lon1 - lon2) >= 180.00):
				return True
	return False

def determine_whether_geometry_of_a_feature_closed_to_geo_North_pole(geometry):
	geo_North_pole = pygplates.PointOnSphere((90.00,0.00))
	distance_in_rads = pygplates.GeometryOnSphere.distance(geometry,geo_North_pole)
	#convert distance_in_rads to km
	approx_distance_in_km = pygplates.Earth.polar_radius_in_kms * distance_in_rads
	if (approx_distance_in_km <= 1000.00): #threshold_distance_km is 1000.00 to check proximity
		return True
	else:
		return False
	
def determine_whether_geometry_of_a_feature_closed_to_geo_South_pole(geometry):
	geo_South_pole = pygplates.PointOnSphere((-90.00,0.00))
	distance_in_rads = pygplates.GeometryOnSphere.distance(geometry,geo_South_pole)
	#convert distance_in_rads to km
	approx_distance_in_km = pygplates.Earth.polar_radius_in_kms * distance_in_rads
	if (approx_distance_in_km <= 1000.00): #threshold_distance_km is 1000.00 to check proximity
		return True
	else:
		return False

def clean_polygon_features_w_date_line_wrapper(rotation_model,list_of_polygon_GDU_fts,reconstruction_time,reference,modelname,yearmonthday):
	reconstructed_polygon_features = []
	final_reconstructed_polygon_features = []
	reconstructed_dissolved_polygon_features = []
	reconstructed_line_features = []
	reconstructed_dangles_cuts = []
	distant_future = pygplates.GeoTimeInstant.create_distant_future()
	#reconstruct all features to reconstruction_time
	list_of_valid_polygon_fts = [polygon_ft for polygon_ft in list_of_polygon_GDU_fts if polygon_ft.is_valid_at_time(reconstruction_time)]
	
	
	#debug
	#randome_name=list_of_valid_polygon_fts[0].get_name()
	#pygplates.FeatureCollection(list_of_valid_polygon_fts).write('valid_polygon_fts_for_'+randome_name+'.shp')
	
	
	if (reference is not None):
		#polygon_features
		pygplates.reconstruct(list_of_valid_polygon_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	else:
		#polygon_features
		pygplates.reconstruct(list_of_valid_polygon_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
	final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
	error_polygon_fts = []
	debug_error_polygon_fts = []
	
	polygon_fts_and_wrapped_polygons = []
	polygon_fts_clean_polygons = []
	
	for polygon_ft,polygon in final_reconstructed_polygon_features:
		#wrap polygon with the DateLineWrapper
		date_line_wrapper = pygplates.DateLineWrapper()
		wrapped_polygons = date_line_wrapper.wrap(polygon)
		#if(polygon_ft.get_reconstruction_plate_id() == 802):
		#print('number of wrapped_polygons')
		#print(len(wrapped_polygons))
		for wrapped_polygon in wrapped_polygons:
			new_polygon = pygplates.PolygonOnSphere(wrapped_polygon.get_exterior_points())
			clone_feature = polygon_ft.clone()
			clone_feature.set_geometry(new_polygon)
			clone_feature.set_name('wrapped_polygon_ft_'+polygon_ft.get_name())
			
			#debug
			# pygplates.reverse_reconstruct(clone_feature,rotation_model,reconstruction_time,reference)
			# pygplates.FeatureCollection(clone_feature).write("wrapped_Azania_at_1630Ma.shp")
			
			polygon_fts_and_wrapped_polygons.append((clone_feature,new_polygon))
	for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		featType = polygon_ft.get_feature_type()
		original_name = polygon_ft.get_name()
		Polygon_in_shapely = convert_polygon_to_Polygon_in_shapely(polygon)
		if (Polygon_in_shapely.is_valid):
			#convert the polygon to PolygonOnSphere
			new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(Polygon_in_shapely)
			#create new Feature in pygplates
			new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='wrapped_polygon_ft_'+original_name,valid_time = polygon_ft.get_valid_time(),reconstruction_plate_id = polygon_ft.get_reconstruction_plate_id())
			reconstructed_dissolved_polygon_features.append(new_feature)
			polygon_fts_clean_polygons.append((polygon_ft,polygon))
			# if (len(Polygon_in_shapely.interiors) > 0):
				# for interior_hole in Polygon_in_shapely.interiors:
					# new_PolygonOnSphere = create_LinearRing_to_PolygonOnSphere_in_pygplates(interior_hole)
					# #create new Feature in pygplates
					# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='wrapped_polygon_ft_'+original_name,valid_time = polygon_ft.get_valid_time(),reconstruction_plate_id = polygon_ft.get_reconstruction_plate_id())
					# reconstructed_dissolved_polygon_features.append(new_feature)
					# polygon_fts_clean_polygons.append((polygon_ft,polygon))
		else:
			#print('explain_validity(Polygon_in_shapely)')
			#print(explain_validity(Polygon_in_shapely))
			#error_polygon_fts.append((polygon_ft,polygon))
			debug_error_polygon_fts.append(polygon_ft)
			
			original_list_of_lon_lat = [(lon,lat) for lat,lon in polygon.to_lat_lon_list()]
			#print(original_list_of_lon_lat)
			#using list comprehension + enumerate() 
			#to remove duplicated  
			#from list	-- reference: https://www.geeksforgeeks.org/python-ways-to-remove-duplicates-from-list/
			#res = [i for n, i in enumerate(original_list_of_lon_lat) if i not in original_list_of_lon_lat[:n]] 
			#print(res)
			original_multipoint = MultiPoint(original_list_of_lon_lat)
			# print('original_multipoint')
			# print(original_multipoint)
			res = []
			for p in original_multipoint.geoms:
				if (len(res) == 0):
					res.append(p)
				else:
					already_included_p = False
					for other_p in res:
						if (p.__eq__(other_p)):
							already_included_p = True
							break
					if (already_included_p == False):
						res.append(p)
						
			# # print("len(original_list_of_lon_lat),len(res)")
			# # print(len(original_list_of_lon_lat),len(res))
			
			# #pre process res --- I am not sure we need this
			# # for index in range(0,len(res)):
				# # if (index > 0):
					# # current_lon,current_lat = res[index]
					# # previous_lon,previous_lat = res[index - 1]
					# # if ((current_lon > 0 and previous_lon < 0) or (current_lon < 0 and previous_lon > 0)):
						# # res[index] = (current_lon * (-1.00),current_lat)
			new_LineString = LineString(res[:]+res[0:1])
			# # print("new_LineString.is_simple")
			# # print(new_LineString.is_simple)
			new_Polygon = Polygon(res)
			# #new_Polygon = Polygon(original_multipoint)
			
			# #debug
			# for point in new_Polygon.boundary.coords:
				# print(point)
			
			if (new_Polygon.is_valid):
				#convert the polygon to PolygonOnSphere
				new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(new_Polygon)
				clone_feature = polygon_ft.clone()
				clone_feature.set_geometry(new_PolygonOnSphere)
				clone_feature.set_name("fixed_polygon_ft_with_dateline_wrapper_remove_duplicate_points"+polygon_ft.get_name())
				if (clone_feature is not None):
					reconstructed_dissolved_polygon_features.append(clone_feature)
				polygon_fts_clean_polygons.append((clone_feature,new_PolygonOnSphere))
				
				# if (len(new_Polygon.interiors) > 0):
					# for interior_hole in new_Polygon.interiors:
						# new_PolygonOnSphere = create_LinearRing_to_PolygonOnSphere_in_pygplates(interior_hole)
						# clone_feature = polygon_ft.clone()
						# clone_feature.set_geometry(new_PolygonOnSphere)
						# clone_feature.set_name("fixed_polygon_ft_with_dateline_wrapper_remove_duplicate_points"+polygon_ft.get_name())
						# if (clone_feature is not None):
							# reconstructed_dissolved_polygon_features.append(clone_feature)
						# polygon_fts_clean_polygons.append((clone_feature,new_PolygonOnSphere))
			else:
				error_polygon_fts.append((polygon_ft,polygon))
				
			
				# #debug
				# #print('explain_validity(new_Polygon)')
				# #print(explain_validity(new_Polygon))
				
				#original method
				#new_MultiLineString = unary_union(new_LineString)
				# selected_MultiLineString = []
				# for l in new_MultiLineString:
					# list_of_lat_lon_points = [pygplates.PointOnSphere((lat,lon)) for lon,lat in l.coords]
					
					# if (len(list_of_lat_lon_points) >= 2):
						# p1 = list_of_lat_lon_points[0]
						# p2 = list_of_lat_lon_points[len(list_of_lat_lon_points) - 1]
						# if (p1 != p2):
							# selected_MultiLineString.append(l)
							# new_LineOnSphere = pygplates.PolylineOnSphere(list_of_lat_lon_points)
							# #create new Feature in pygplates
							# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_LineOnSphere,name='selected_line_ft_with_new_LineString',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
							# new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
							# if (new_feature is not None):
								# reconstructed_line_features.append(new_feature)
					# else:
						# #selected_MultiLineString.append(l)
						# new_LineOnSphere = pygplates.PolylineOnSphere(list_of_lat_lon_points)
						# #create new Feature in pygplates
						# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_LineOnSphere,name='selected_line_ft_with_new_LineString',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
						# new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
						# if (new_feature is not None):
							# reconstructed_line_features.append(new_feature)
				# result, dangles, cuts, invalids = polygonize_full(selected_MultiLineString)
				
				#Just commented this portion
				# result, dangles, cuts, invalids = polygonize_full(new_MultiLineString)
				# #debug
				# #print('result',result)
				
				# if (result.geom_type == "GeometryCollection" or result.geom_type == "MultiPolygon"):
					# for polygon in result:
						# # print("valid polygon in result")
						# # print(polygon.is_valid)
						# # print(explain_validity(result))
						
						# #convert the polygon to PolygonOnSphere
						# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
						# clone_feature = polygon_ft.clone()
						# clone_feature.set_geometry(new_PolygonOnSphere)
						# clone_feature.set_name("fixed_polygon_ft_with_dateline_wrapper_and_polygonize"+polygon_ft.get_name())
						# reconstructed_dissolved_polygon_features.append(clone_feature)
						# polygon_fts_clean_polygons.append((clone_feature,new_PolygonOnSphere))
				# elif (result.geom_type == 'Polygon'):
					# #convert the polygon to PolygonOnSphere
					# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(result)
					# clone_feature = polygon_ft.clone()
					# clone_feature.set_geometry(new_PolygonOnSphere)
					# clone_feature.set_name("fixed_polygon_ft_with_dateline_wrapper_and_polygonize"+polygon_ft.get_name())
					# reconstructed_dissolved_polygon_features.append(clone_feature)
					# polygon_fts_clean_polygons.append((clone_feature,new_PolygonOnSphere))
					
					
					# # #debug
					# # #perform unary_union on result 
					# # temp_union_result = unary_union(result)
					# # print('temp_union_result')
					# # print(temp_union_result)
					# # print('valid of temp_union_result')
					# # print(explain_validity(temp_union_result))
					# # for polygon in temp_union_result:
						# # print("valid polygon in result")
						# # print(polygon.is_valid)
						# # print(explain_validity(result))
					# # print('len(result), len(temp_union_result)')
					# # print(len(result),len(temp_union_result))
				# else:
					# print("result")
					# print(result)
					# print(result.geom_type)
					# print(explain_validity(result))
					# exit()
						
				# if (invalids.is_empty == False):
					# print("Error in clean_polygon_features")
					# print("dangles, cuts, invalids")
					# print(dangles, cuts, invalids)
					# invalid_reconstruced_polygon_fts = []
					# for geometry in invalids:
						# print('geometry in invalids')
						# print(geometry)
						# print (geometry.is_valid)
						# pygplates_geometry = None
						# if (type(geometry) == Polygon):
							# #convert the polygon to PolygonOnSphere
							# pygplates_geometry = convert_Polygon_to_PolygonOnSphere_in_pygplates(geometry)
						# elif (type(geometry) == LineString or type(geometry) == LinearRing ):
							# pygplates_geometry = convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(geometry)
						# #create new Feature in pygplates
						# new_feature = pygplates.Feature.create_reconstructable_feature(featType,pygplates_geometry,name='invalid_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
						# new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
						# if (new_feature is not None):
							# invalid_reconstruced_polygon_fts.append(new_feature)
					# #reverse_reconstruct
					# if (reference is not None):
						# pygplates.reverse_reconstruct(invalid_reconstruced_polygon_fts,rotation_model,reconstruction_time,reference)
					# else:
						# pygplates.reverse_reconstruct(invalid_reconstruced_polygon_fts,rotation_model,reconstruction_time)
					
					# outputFeatureCollection = pygplates.FeatureCollection(invalid_reconstruced_polygon_fts)
					# outputFeatureFile = 'invalid_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+str(polygon_ft.get_reconstruction_plate_id())+'_'+modelname+'_'+yearmonthday+'.shp'
					# outputFeatureCollection.write(outputFeatureFile)
					# outputFeatureFile = 'invalid_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+str(polygon_ft.get_reconstruction_plate_id())+'_'+modelname+'_'+yearmonthday+'.gpml'
					# outputFeatureCollection.write(outputFeatureFile)
					
					# #reverse_reconstruct
					# if (reference is not None):
						# pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
						# pygplates.reverse_reconstruct(error_polygon_fts,rotation_model,reconstruction_time,reference)
					# else:
						# pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
						# pygplates.reverse_reconstruct(error_polygon_fts,rotation_model,reconstruction_time)
	
					# polygon_fts_with_dateline_wrapper = pre_process_polygon_features_from_shp_file(reconstructed_dissolved_polygon_features,modelname,yearmonthday,False)
	
					# outputFeatureCollection = pygplates.FeatureCollection(polygon_fts_with_dateline_wrapper)
					# outputFeatureFile = 'fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
					# outputFeatureCollection.write(outputFeatureFile)
					# outputFeatureFile = 'fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
					# outputFeatureCollection.write(outputFeatureFile)
	
					# outputFeatureCollection = pygplates.FeatureCollection(error_polygon_fts)
					# outputFeatureFile = 'required_to_be_fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
					# outputFeatureCollection.write(outputFeatureFile)
					# outputFeatureFile = 'required_to_be_fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
					# outputFeatureCollection.write(outputFeatureFile)

					# exit()
					
				#This could be helpful for future model development but not important to find SuperGDU features
				# if (dangles.is_empty == False or cuts.is_empty == False):
					# if (dangles.is_empty == False):
						# for d in dangles:
							# list_of_lat_lon_points = [pygplates.PointOnSphere((lat,lon)) for lon,lat in d.coords]
							# new_LineOnSphere = pygplates.PolylineOnSphere(list_of_lat_lon_points)
							# #create new Feature in pygplates
							# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_LineOnSphere,name='dangle_ft_',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
							# new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
							# if (new_feature is not None):
								# reconstructed_dangles_cuts.append(new_feature)
					# if (cuts.is_empty == False):
						# for c in cuts:
							# list_of_lat_lon_points = [pygplates.PointOnSphere((lat,lon)) for lon,lat in c.coords]
							# new_LineOnSphere = pygplates.PolylineOnSphere(list_of_lat_lon_points)
							# #create new Feature in pygplates
							# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_LineOnSphere,name='cut_ft_',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
							# new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
							# if (new_feature is not None):
								# reconstructed_dangles_cuts.append(new_feature)
	#reverse_reconstruct
	if (reference is not None):
		pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
		#pygplates.reverse_reconstruct(reconstructed_line_features,rotation_model,reconstruction_time,reference)
		pygplates.reverse_reconstruct(debug_error_polygon_fts,rotation_model,reconstruction_time,reference)
		# pygplates.reverse_reconstruct(reconstructed_dangles_cuts,rotation_model,reconstruction_time,reference)
	else:
		pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
		#pygplates.reverse_reconstruct(reconstructed_line_features,rotation_model,reconstruction_time)
		pygplates.reverse_reconstruct(debug_error_polygon_fts,rotation_model,reconstruction_time)
		# pygplates.reverse_reconstruct(reconstructed_dangles_cuts,rotation_model,reconstruction_time)
	# polygon_fts_with_dateline_wrapper_at_present = pre_process_polygon_features_from_shp_file(reconstructed_dissolved_polygon_features,modelname,yearmonthday,False)
	
	if (polygon_ft.get_reconstruction_plate_id() == 16000 and reconstruction_time == 125.0):
		outputFeatureCollection = pygplates.FeatureCollection(reconstructed_dissolved_polygon_features)
		outputFeatureFile = 'fixed_polygon_fts_from_date_line_wrapper_from_'+str(polygon_ft.get_reconstruction_plate_id())+"_"+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
		outputFeatureCollection.write(outputFeatureFile)
	# outputFeatureFile = 'fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
	# outputFeatureCollection.write(outputFeatureFile)
	
	if (polygon_ft.get_reconstruction_plate_id() == 16000 and reconstruction_time == 125.0):
		if (len(debug_error_polygon_fts) > 0):
			outputFeatureCollection = pygplates.FeatureCollection(debug_error_polygon_fts)
			random_error_polygon_ft = debug_error_polygon_fts[0]
			outputFeatureFile = 'error_polygon_fts_from_'+random_error_polygon_ft.get_name()+'_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
			outputFeatureCollection.write(outputFeatureFile)
	# outputFeatureFile = 'required_to_be_fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
	# outputFeatureCollection.write(outputFeatureFile)
	
	# outputFeatureCollection = pygplates.FeatureCollection(reconstructed_line_features)
	# outputFeatureFile = 'line_fts_from_date_line_wrapper_from_'+str(polygon_ft.get_reconstruction_plate_id())+'_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
	# outputFeatureCollection.write(outputFeatureFile)
	# outputFeatureFile = 'line_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
	# outputFeatureCollection.write(outputFeatureFile)
	
	# outputFeatureCollection = pygplates.FeatureCollection(reconstructed_dangles_cuts)
	# outputFeatureFile = 'dangles_and_cuts_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
	# outputFeatureCollection.write(outputFeatureFile)
	# outputFeatureFile = 'dangles_and_cuts_fts_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
	# outputFeatureCollection.write(outputFeatureFile)
	
	#return(polygon_fts_with_dateline_wrapper_at_present,polygon_fts_clean_polygons)
	
	return(reconstructed_dissolved_polygon_features,polygon_fts_clean_polygons,error_polygon_fts)

def fix_invalid_Shapely_polygon(shapely_polygon):
	exterior_coords = shapely_polygon.exterior.coords
	original_list_of_lon_lat = []
	for c in exterior_coords:
		original_list_of_lon_lat.append(c)
	original_multipoint = MultiPoint(original_list_of_lon_lat)
	res = []
	for p in original_multipoint:
		if (len(res) == 0):
			res.append(p)
		else:
			already_included_p = False
			for other_p in res:
				if (p.equals(other_p)):
					already_included_p = True
					break
			if (already_included_p == False):
				res.append(p)
						
	new_LineString = LineString(res[:]+res[0:1])
	new_MultiLineString = unary_union(new_LineString)
	if (new_MultiLineString.geom_type == 'LineString'):
		result, dangles, cuts, invalids = polygonize_full(new_MultiLineString)
		if (invalids.is_empty == False):
			print("Error in clean_polygon_features")
			print("dangles, cuts, invalids")
			print(dangles, cuts, invalids)
			exit()
		return result
	else:
		selected_MultiLineString = []
		for l in new_MultiLineString:
			list_of_lat_lon_points = [pygplates.PointOnSphere((lat,lon)) for lon,lat in l.coords]
			if (len(list_of_lat_lon_points) >= 2):
				p1 = list_of_lat_lon_points[0]
				p2 = list_of_lat_lon_points[len(list_of_lat_lon_points) - 1]
				selected_MultiLineString.append(l)
		print('len(selected_MultiLineString)',len(selected_MultiLineString))
		result, dangles, cuts, invalids = polygonize_full(selected_MultiLineString)
		if (invalids.is_empty == False):
			print("Error in clean_polygon_features")
			print("dangles, cuts, invalids")
			print(dangles, cuts, invalids)
			exit()
		if (result.geom_type == "GeometryCollection"):
			return result

def fix_invalid_Shapely_polygon(polygon_with_issue):
	buffered_pos = polygon_with_issue.buffer(0.1000)
	buffered_neg = buffered_pos.buffer(-0.100)
	return buffered_neg

def find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time(rotation_model, list_of_polygon_GDU_fts, reconstruction_time, interval, reference, modelname, yearmonthday, warning_on):
	featType = pygplates.FeatureType.gpml_continental_crust
	_, polygon_fts_and_wrapped_polygons, error_polygon_fts = clean_polygon_features_w_date_line_wrapper(rotation_model, list_of_polygon_GDU_fts, reconstruction_time, reference, modelname, yearmonthday)
	
	polygons_for_unary_union = []
	temporary_wrapped_polygons = []
	reconstructed_dissolved_polygon_features = []
	invalid_polygons_for_later_union = []
	invalid_initial_Shapely_polygons_for_later_union = []
	if (polygon_fts_and_wrapped_polygons is None):
		print ("Error in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
		print ("Error polygon_fts_and_wrapped_polygons is None")
		print ("Here is input list_of_polygon_GDU_fts:")
		print (list_of_polygon_GDU_fts)
		exit()
	if (len(polygon_fts_and_wrapped_polygons) == 0 and len(error_polygon_fts) == 0):
		print ("Suspection in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
		print ("Issue len(polygon_fts_and_wrapped_polygons) == 0")
		print ("Here is input list_of_polygon_GDU_fts:")
		print (list_of_polygon_GDU_fts)
		if (warning_on == True):
			exit()
	
	# if (len(polygon_fts_and_wrapped_polygons) == 0):
		# print ("Suspection in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
		# print ("Issue len(polygon_fts_and_wrapped_polygons) == 0")
		# print ("Here is input list_of_polygon_GDU_fts:")
		# print (list_of_polygon_GDU_fts)
		# if (warning_on == True):
			# exit()
	
			
	#NEW
	#print('len(error_polygon_fts)',len(error_polygon_fts))
	polygon_fts_and_wrapped_polygons = polygon_fts_and_wrapped_polygons + error_polygon_fts
	
	closed_to_North_pole = False
	closed_to_South_pole = False
	closed_to_dateline = False
	for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		if (determine_whether_geometry_of_a_feature_closed_to_geo_North_pole(polygon) == True):
			closed_to_North_pole = True
			break
		elif (determine_whether_geometry_of_a_feature_closed_to_geo_South_pole(polygon) == True):
			closed_to_South_pole = True
			break
	for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		#print('is_crossing_the_DateLine(polygon)',is_crossing_the_DateLine(polygon))
		if (is_crossing_the_DateLine(polygon) == True):
			closed_to_dateline = True
			break
	
	#choose a random representative GDUID: all GDU members have a similar equivalent stage rotation 
	random_repGDUID = polygon_ft.get_reconstruction_plate_id()
	
	finite_rotation = None
	if (closed_to_North_pole == True):
		#project away the North pole: the rotation axis through the pole (0 degree lat, 0 degree lon) and angle of rotation is -90.00
		finite_rotation = pygplates.FiniteRotation((0.00,0.00),math.radians(-90.00))
	elif (closed_to_South_pole == True):
		#project away the South pole: the rotation axis through the pole (0 degree lat, 0 degree lon) and angle of rotation is +90.00
		finite_rotation = pygplates.FiniteRotation((0.00,0.00),math.radians(90.00))
	finite_rotation_2 = None
	if (closed_to_dateline == True):
		finite_rotation_2 = pygplates.FiniteRotation((89.00,0.00),math.radians(90.00))

	# if (finite_rotation is not None):
		# if (finite_rotation_2 is not None):
			# composed_finite_rotation = finite_rotation*finite_rotation_2
			# finite_rotation = composed_finite_rotation
	# else:
		# if (finite_rotation_2 is not None):
			# finite_rotation = finite_rotation_2
	
	#print('finite_rotation_2',finite_rotation_2)

	#temporal_rotated_polygon_fts = []
	for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		if (finite_rotation is not None):
			rotated_polygon = finite_rotation*polygon
			polygon = rotated_polygon.clone()
		#old
		# Polygon_in_shapely = convert_polygon_to_Polygon_in_shapely(polygon)
		# if (Polygon_in_shapely.is_valid == False):
			# invalid_polygons_for_later_union.append(polygon.clone())
		# else:
			# temporary_wrapped_polygons.append(Polygon_in_shapely)
		#new
		date_line_wrapper = pygplates.DateLineWrapper()
		wrapped_polygons = date_line_wrapper.wrap(polygon)
		if (len(wrapped_polygons) >= 2):
			for wrapped_polygon in wrapped_polygons:
				new_polygon = pygplates.PolygonOnSphere(wrapped_polygon.get_exterior_points())
				Polygon_in_shapely = convert_polygon_to_Polygon_in_shapely(new_polygon)
				if (Polygon_in_shapely.is_valid == False):
					#don't reverse-rotate anything until after create final output dissolved features
					invalid_polygons_for_later_union.append(new_polygon.clone())
					#invalid_initial_Shapely_polygons_for_later_union.append(Polygon_in_shapely)
					
					# fixed_valid_polygons = fix_invalid_Shapely_polygon(Polygon_in_shapely)
					# if (fixed_valid_polygons.geom_type == "MultiPolygon"):
						# for individual_polygon in fixed_valid_polygons:
							# temporary_wrapped_polygons.append(individual_polygon)
					# elif (fixed_valid_polygons.geom_type == "Polygon"):
						# temporary_wrapped_polygons.append(fixed_valid_polygons)
				else:
					temporary_wrapped_polygons.append(Polygon_in_shapely)
		else:
			Polygon_in_shapely = convert_polygon_to_Polygon_in_shapely(polygon)
			if (Polygon_in_shapely.is_valid == False):
				#don't reverse-rotate anything until after create final output dissolved features
				invalid_polygons_for_later_union.append(polygon.clone())
				#invalid_initial_Shapely_polygons_for_later_union.append(Polygon_in_shapely)

				# fixed_valid_polygons = fix_invalid_Shapely_polygon(Polygon_in_shapely)
				# if (fixed_valid_polygons.geom_type == "MultiPolygon"):
					# for individual_polygon in fixed_valid_polygons:
						# temporary_wrapped_polygons.append(individual_polygon)
				# elif (fixed_valid_polygons.geom_type == "Polygon"):
					# temporary_wrapped_polygons.append(fixed_valid_polygons)
			else:
				temporary_wrapped_polygons.append(Polygon_in_shapely)

	#make sure to remove duplicated Polygon first before peforming union 
	for polygon_1 in temporary_wrapped_polygons:
		if (len(polygons_for_unary_union) == 0):
			polygons_for_unary_union.append(polygon_1)
		else:
			duplicated = False
			for polygon_2 in polygons_for_unary_union:
				if(polygon_1.__eq__(polygon_2)):
					duplicated = True
					break
			if (duplicated == False):
				polygons_for_unary_union.append(polygon_1)
	#perform union
	result = unary_union([polygon for polygon in polygons_for_unary_union])
	print('result.geom_type',result.geom_type)
	if (result.geom_type == 'Polygon'):
		new_PolygonOnSphere = None
		if (result.is_valid):
			#only take the exterior
			#convert the polygon to PolygonOnSphere
			new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(result)
			if (finite_rotation is not None):
				original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
				new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
			#create new Feature in pygplates
			new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='dissolved_polygon_ft_only',valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
			if (reference is not None):
				new_feature.set_reconstruction_plate_id(reference)
			reconstructed_dissolved_polygon_features.append(new_feature)
		else:
			#NEW 
			print("result of unary_union for polygons_for_unary_union is an INVALID POLYGON")
			count = 0
			for polygon_with_issue in invalid_polygons_for_later_union:
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*polygon_with_issue
					polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
				#create new Feature in pygplates
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,polygon_with_issue,name='invalid_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				count = count + 1
			#reverse_reconstruct
			if (reference is not None):
				pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
			else:
				pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
			reconstructed_dissolved_polygon_features.write("invalid_polygon_features_at_"+str(reconstruction_time)+".shp")
			exit()
		list_of_invalid_polygon_to_created_as_sep_ft = []
		if (len(invalid_polygons_for_later_union) > 0):
			count = 0
			for ini_polygon_with_issue in invalid_polygons_for_later_union:
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*ini_polygon_with_issue
					ini_polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
				if (new_PolygonOnSphere.partition(ini_polygon_with_issue) != pygplates.PolygonOnSphere.PartitionResult.inside):
					list_of_invalid_polygon_to_created_as_sep_ft.append(ini_polygon_with_issue)
			for invalid_polygon_to_be_included in list_of_invalid_polygon_to_created_as_sep_ft:
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,invalid_polygon_to_be_included,name='other_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				count = count + 1 
	elif (result.geom_type == 'MultiPolygon'):
		biggest_polygon = None
		final_list_of_valid_polygons = []
		invalid_Shapley_polygons_for_later_union = []
		for polygon in result.geoms:
			if (polygon.is_valid == False):
				invalid_Shapley_polygons_for_later_union.append(polygon)
			else:
				final_list_of_valid_polygons.append(polygon)
		#NEW
		print('invalid_Shapley_polygons_for_later_union',len(invalid_Shapley_polygons_for_later_union))
		if (len(invalid_Shapley_polygons_for_later_union) > 0):
			list_of_invalid_polygon_to_created_as_sep_ft = []
			list_of_valid_dissolved_polygon = []
			count = 0
			for polygon in final_list_of_valid_polygons:
				new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
					new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
				list_of_valid_dissolved_polygon.append(new_PolygonOnSphere)
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='multi_other_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				count = count + 1
			for polygon_with_issue in invalid_Shapley_polygons_for_later_union:
				polygonOnSphere_w_issue = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon_with_issue)
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*polygonOnSphere_w_issue
					polygonOnSphere_w_issue = original_coords_for_PolygonOnSphere.clone()
				valid_polygonOnSphere_w_issue = True
				for valid_polygonOnSphere in list_of_valid_dissolved_polygon:
					if (valid_polygonOnSphere.partition(polygonOnSphere_w_issue) == pygplates.PolygonOnSphere.PartitionResult.inside):
						valid_polygonOnSphere_w_issue = False
						break
				if (valid_polygonOnSphere_w_issue == True):
					list_of_invalid_polygon_to_created_as_sep_ft.append(polygonOnSphere_w_issue)
			print('len(invalid_polygons_for_later_union)',len(invalid_polygons_for_later_union))
			if (len(invalid_polygons_for_later_union) > 0):
				for ini_polygon_with_issue in invalid_polygons_for_later_union:
					valid_polygonOnSphere_w_issue = True
					if (finite_rotation is not None):
						original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*ini_polygon_with_issue
						ini_polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
					for valid_polygonOnSphere in list_of_valid_dissolved_polygon:
						if (valid_polygonOnSphere.partition(ini_polygon_with_issue) == pygplates.PolygonOnSphere.PartitionResult.inside):
							valid_polygonOnSphere_w_issue = False
							break
					if (valid_polygonOnSphere_w_issue == True):
						list_of_invalid_polygon_to_created_as_sep_ft.append(ini_polygon_with_issue)
			
			for invalid_polygon_to_be_included in list_of_invalid_polygon_to_created_as_sep_ft:
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,invalid_polygon_to_be_included,name='multi_other_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				
		elif (len(invalid_Shapley_polygons_for_later_union) == 0):
			#print('len(invalid_polygons_for_later_union)',len(invalid_polygons_for_later_union))
			list_of_invalid_polygon_to_created_as_sep_ft = []
			list_of_valid_dissolved_polygon = []
			count = 0
			for polygon in final_list_of_valid_polygons:
				new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
					new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='multi_valid_other_dissolved_polygon_ft'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				list_of_valid_dissolved_polygon.append(new_PolygonOnSphere)
				count = count + 1

			if (len(invalid_polygons_for_later_union) > 0):
				for ini_polygon_with_issue in invalid_polygons_for_later_union:
					valid_polygonOnSphere_w_issue = True
					if (finite_rotation is not None):
						original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*ini_polygon_with_issue
						ini_polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
					for valid_polygonOnSphere in list_of_valid_dissolved_polygon:
						if (valid_polygonOnSphere.partition(ini_polygon_with_issue) == pygplates.PolygonOnSphere.PartitionResult.inside):
							valid_polygonOnSphere_w_issue = False
							#print('valid_polygonOnSphere_w_issue',valid_polygonOnSphere_w_issue)
							break
					if (valid_polygonOnSphere_w_issue == True):
						list_of_invalid_polygon_to_created_as_sep_ft.append(ini_polygon_with_issue)
			#print('len(list_of_invalid_polygon_to_created_as_sep_ft)',len(list_of_invalid_polygon_to_created_as_sep_ft))
			for invalid_polygon_to_be_included in list_of_invalid_polygon_to_created_as_sep_ft:
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,invalid_polygon_to_be_included,name='multi_ini_invalid_other_dissolved_polygon_ft'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				count = count + 1
	if (len(polygons_for_unary_union) == 0 and len(invalid_polygons_for_later_union) > 0):
		count = 0
		for polygon_with_issue in invalid_polygons_for_later_union:
			if (finite_rotation is not None):
				original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*polygon_with_issue
				polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
			#create new Feature in pygplates
			new_feature = pygplates.Feature.create_reconstructable_feature(featType,polygon_with_issue,name='troubled_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
			if (reference is not None):
				new_feature.set_reconstruction_plate_id(reference)
			reconstructed_dissolved_polygon_features.append(new_feature)
			count = count + 1
	#reverse_reconstruct
	if (reference is not None):
		pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
	else:
		pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
		
	# outputFeatureCollection = pygplates.FeatureCollection(reconstructed_dissolved_polygon_features)
	# outputFeatureFile = 'temp_reconstructed_dissolved_polygon_features_'+str(polygon_ft.get_reconstruction_plate_id())+"_"+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
	# outputFeatureCollection.write(outputFeatureFile)
	
	return reconstructed_dissolved_polygon_features

def are_two_geoms_touched_at_dateline(geom_1,geom_2):
	list_of_lat_lon_1 = geom_1.to_lat_lon_list()
	list_of_lat_lon_2 = geom_2.to_lat_lon_list()
	for lat1,lon1 in list_of_lat_lon_1:
		if ((abs(lon1) - 180.00) <= 0.00100 and lon1 < 0.00):
			for lat2,lon2 in list_of_lat_lon_2:
				if ((abs(lon2) - 180.00) <= 0.00100 and lon2 > 0.00):
					if (lat1 == lat2):
						return True
		elif ((abs(lon1) - 180.00) <= 0.00100 and lon1 > 0.00):
			for lat2,lon2 in list_of_lat_lon_2:
				if ((abs(lon2) - 180.00) <= 0.00100 and lon2 < 0.00):
					if (lat1 == lat2):
						return True
	return False


def are_group_of_GDUs_spatially_together_at_reconstruction_time_v2_without_projection(rotation_model, list_of_polygon_GDU_fts, buffer_distance_km, reconstruction_time, time_interval, reference, modelname, yearmonthday):
	reconstructed_polygon_features = []
	final_reconstructed_polygon_features = []
	list_of_transform_polygon = []
	list_of_transform_point = []
	list_of_GDU_id = []
	list_of_left_over_GDUs = []
	list_of_used_GDUs = []
	
	#reconstruct all features to reconstruction_time
	list_of_valid_polygon_fts = [polygon_ft for polygon_ft in list_of_polygon_GDU_fts if polygon_ft.is_valid_at_time(reconstruction_time)]
	
	#found the example 17300
	# found_example_ft = False
	# for example_ft in list_of_valid_polygon_fts:
		# if (example_ft.get_reconstruction_plate_id() == 17300):
			# found_example_ft = True
	
	if (len(list_of_valid_polygon_fts) != len(list_of_polygon_GDU_fts)):
		return [False,list_of_GDU_id,None]
	
	warning_on = True
	fts = find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time(rotation_model,list_of_valid_polygon_fts,reconstruction_time,time_interval,reference,modelname,yearmonthday,warning_on)
	#fts = find_dissolved_polygon_features_from_polygon_features_with_laea_proj_at_reconstruction_time(rotation_model,list_of_valid_polygon_fts,reconstruction_time,reference,modelname,yearmonthday,warning_on)

	if (reference is not None):
		#polygon_features
		pygplates.reconstruct(fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	else:
		#polygon_features
		pygplates.reconstruct(fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
	final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
	#this is the flag - it will be turned on when we find any distance among GDU in superGDU > buffer distance 
	valid_superGDU = True
	already_processed_polygon_fts = []
	list_of_outsider = []
	for polygon_ft,polygon in final_reconstructed_polygon_features:
		ft_id_1 = polygon_ft.get_feature_id()
		#find the minimum distance - evaluate on the minimum distance
		min_distance = -1.00
		for other_polygon_ft,other_polygon in final_reconstructed_polygon_features:
			ft_id_2 = other_polygon_ft.get_feature_id()
			if (ft_id_1 != ft_id_2):
				#find the two closest between these two polygons
				distance,point_on_polygon_1,point_on_polygon_2 =  pygplates.GeometryOnSphere.distance(polygon, other_polygon, return_closest_positions=True)
				lat1,lon1 = point_on_polygon_1.to_lat_lon()
				lat2,lon2 = point_on_polygon_2.to_lat_lon()
				distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
				if ((min_distance == -1.00) or (min_distance > -1.00 and distance_in_km < min_distance)):
					min_distance = distance_in_km
				if (min_distance == 0.00):
					break
		if (min_distance > buffer_distance_km):
			valid_superGDU = False
			list_of_outsider.append(polygon_ft.get_feature_id())
	if (valid_superGDU == False):
		return [False,list_of_GDU_id,final_reconstructed_polygon_features,list_of_outsider]
	else:
		list_of_GDU_id = [ft.get_reconstruction_plate_id() for ft in list_of_valid_polygon_fts]
		return [True,list_of_GDU_id,final_reconstructed_polygon_features,list_of_outsider]


def examine_tobeconsidered_gdu_features_with_gdu_features_rotating_together(rotation_model,list_of_polygon_GDU_fts_to_be_considered,list_of_polygon_GDU_fts,threshold_distance_km_to_be_included,reconstruction_time,reference):
	reconstructed_polygon_features_to_be_considered = []
	reconstructed_polygon_features = []
	if (reference is not None):
		#polygon_features
		pygplates.reconstruct(list_of_polygon_GDU_fts_to_be_considered,rotation_model,reconstructed_polygon_features_to_be_considered,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(list_of_polygon_GDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	else:
		#polygon_features
		pygplates.reconstruct(list_of_polygon_GDU_fts_to_be_considered,rotation_model,reconstructed_polygon_features_to_be_considered,reconstruction_time,group_with_feature = True)
		pygplates.reconstruct(list_of_polygon_GDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
	final_reconstructed_polygon_features_to_be_considered = find_final_reconstructed_geometries(reconstructed_polygon_features_to_be_considered,pygplates.PolygonOnSphere)
	final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
	
	for other_feature,other_polygon in final_reconstructed_polygon_features_to_be_considered:
		to_be_included = False
		for already_included_current_ft,already_included_current_polygon in final_reconstructed_polygon_features:
			distance,point_on_polygon_1,point_on_polygon_2 =  pygplates.GeometryOnSphere.distance(already_included_current_polygon, other_polygon, return_closest_positions=True)
			lat1,lon1 = point_on_polygon_1.to_lat_lon()
			lat2,lon2 = point_on_polygon_2.to_lat_lon()
			distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
			if (distance_in_km < threshold_distance_km_to_be_included):
				to_be_included = True
				break
		if (to_be_included == True):
			list_of_polygon_GDU_fts.append(other_feature)
	return list_of_polygon_GDU_fts

def create_equivalent_rotation_groups_with_uncertainity_for_finite_rotation_without_projection(equivalent_stage_rotation_csv_file, rotation_model, polygon_features_collection, from_time, to_time, interval,buffer_distance_km, uncertainity_to_lat_and_lon_of_finite_rot_pole, uncertainty_to_rotation_angle, number_of_digits_for_rot, reference, modelname, yearmonthday):
	#'from_time', 'to_time', 'member_GDU_ID', 'anchor_plate_id', 'pole_latitude', 'pole_longitude', 'angle_degrees'
	equiv_rot = pd.read_csv(equivalent_stage_rotation_csv_file, delimiter = ';', header = 0)
	equiv_rot = equiv_rot.round(3)
	no_duplicates_equiv_rot = equiv_rot.drop_duplicates(subset=['from_time', 'to_time', 'anchor_plate_id', 'pole_latitude', 'pole_longitude', 'angle_degrees'])
	reconstruction_time = from_time
	conn = None 
	list_of_polygon_GDU_fts = []
	list_of_polygon_GDU_fts_to_be_considered = []
	reconstructed_GDU_polygon_features = []
	result_GDU_fts = []
	already_recorded = []
	already_included_gdu_id = []
	suspected_gdu_ids = []
	missing_gdu_feats = []
	union_polygon_fts = []
	already_examined_rot_records = []
	already_examined_GDUID = []
	suspected_union_polygon_fts = []
	supergdu_and_members_tuples = []
	previous_record_time = from_time

	Super_GDU_id = 50000 
	while (reconstruction_time > (to_time - interval)):
		print('Here is reconstruction_time')
		print(reconstruction_time)
		valid_polygon_features_collection = [random_polygon_ft for random_polygon_ft in polygon_features_collection if random_polygon_ft.is_valid_at_time(reconstruction_time)]
		#print('len(valid_polygon_features_collection)',valid_polygon_features_collection)
		# txt_1 = """ SELECT DISTINCT from_time, to_time, anchor_plate_id, pole_latitude, pole_longitude, angle_degrees 
							# FROM equivalent_stage_rotation
							# WHERE to_time = {reconstruction_time} 
								# AND pole_latitude IS NOT NULL 
								# AND pole_longitude IS NOT NULL 
								# AND angle_degrees is NOT NULL"""
		#sql_1 = txt_1.format(reconstruction_time = reconstruction_time)
			
		records_1 = no_duplicates_equiv_rot.loc[(no_duplicates_equiv_rot['to_time']==reconstruction_time)&(no_duplicates_equiv_rot['pole_latitude'].isna() == False)&(no_duplicates_equiv_rot['pole_longitude'].isna() == False)&(no_duplicates_equiv_rot['angle_degrees'].isna() == False),['from_time', 'anchor_plate_id','pole_latitude', 'pole_longitude', 'angle_degrees']]
		#print('sql_1')
		#query records that have similar equivalent_stage_rotation
		#print('execute sql_1')
		#print(sql_1)
		#cur.execute(sql_1)
		#row = cur.fetchone()
		already_examined_rot_records[:] = []
		already_examined_GDUID[:] = []
		for row in records_1.values:
			list_of_polygon_GDU_fts_to_be_considered[:] = []
			list_of_polygon_GDU_fts[:] = []
			#print('row',row)
			from_time = row[0]
			anchor_plate_id = row[1]
			pole_latitude = row[2]
			pole_longitude = row[3]
			angle_degrees = row[4]
			# if (len(already_examined_rot_records) > 0):
				# found_similar_record = False
				# for prev_lat,prev_lon,prev_angle in already_examined_rot_records:
					# #print('prev_lat,prev_lon,prev_angle',prev_lat,prev_lon,prev_angle)
					# if ((round(abs(prev_lat-pole_latitude),number_of_digits_for_rot)<= uncertainity_to_lat_and_lon_of_finite_rot_pole) and (round(abs(prev_lon-pole_longitude),number_of_digits_for_rot) <= uncertainity_to_lat_and_lon_of_finite_rot_pole) and (round(abs(prev_angle-angle_degrees),number_of_digits_for_rot) <= uncertainty_to_rotation_angle)):
						# found_similar_record = True
						# break
				# if (found_similar_record == True):
					# if (pole_latitude == 33.879 and pole_longitude == 13.559 and angle_degrees == 2.778):
						# print('found_similar_record')
						# print('prev_lat,prev_lon,prev_angle',prev_lat,prev_lon,prev_angle)
						# print(round(abs(prev_lat-pole_latitude),number_of_digits_for_rot))
						# print(round(abs(prev_lon-pole_longitude),number_of_digits_for_rot))
						# print(round(abs(prev_angle-angle_degrees),number_of_digits_for_rot))
					# already_examined_rot_records.append((pole_latitude,pole_longitude,angle_degrees))
					# if (pole_latitude == 33.961 and pole_longitude == 13.656 and angle_degrees == 2.779):
						# print('found_similar_record')
						# print('prev_lat,prev_lon,prev_angle',prev_lat,prev_lon,prev_angle)
						# print(round(abs(prev_lat-pole_latitude),number_of_digits_for_rot))
						# print(round(abs(prev_lon-pole_longitude),number_of_digits_for_rot))
						# print(round(abs(prev_angle-angle_degrees),number_of_digits_for_rot))
					# already_examined_rot_records.append((pole_latitude,pole_longitude,angle_degrees))
					# continue #get a new record for rotation
			# already_examined_rot_records.append((pole_latitude,pole_longitude,angle_degrees))
			
			if (len(already_examined_rot_records) > 0):
				found_similar_record = False
				for prev_lat,prev_lon,prev_angle in already_examined_rot_records:
					#print('prev_lat,prev_lon,prev_angle',prev_lat,prev_lon,prev_angle)
					if ((round(abs(prev_lat-pole_latitude),number_of_digits_for_rot)<= uncertainity_to_lat_and_lon_of_finite_rot_pole) and (round(abs(prev_lon-pole_longitude),number_of_digits_for_rot) <= uncertainity_to_lat_and_lon_of_finite_rot_pole) and (round(abs(prev_angle-angle_degrees),number_of_digits_for_rot) <= uncertainty_to_rotation_angle)):
						found_similar_record = True
						break
				if (found_similar_record == True):
					#debug
					# if (pole_latitude == 33.961 and pole_longitude == 13.656 and angle_degrees == 2.779):
						# print('found_similar_record')
						# print('prev_lat,prev_lon,prev_angle',prev_lat,prev_lon,prev_angle)
						# print(round(abs(prev_lat-pole_latitude),number_of_digits_for_rot))
						# print(round(abs(prev_lon-pole_longitude),number_of_digits_for_rot))
						# print(round(abs(prev_angle-angle_degrees),number_of_digits_for_rot))
					#already_examined_rot_records.append((pole_latitude,pole_longitude,angle_degrees))
					
					continue #get a new record for rotation
			already_examined_rot_records.append((pole_latitude,pole_longitude,angle_degrees))
			
			# txt_2 = """ SELECT member_gdu_id 
							# FROM equivalent_stage_rotation
							# WHERE from_time = {from_time}
								# AND to_time = {to_time}
								# AND anchor_plate_id = {anchor_plate_id}
								# AND (ABS (pole_latitude - {input_pole_latitude}) <= {input_uncertainity_to_lat_and_lon_of_finite_rot_pole})
								# AND (ABS (pole_longitude - {input_pole_longitude}) <= {input_uncertainity_to_lat_and_lon_of_finite_rot_pole})
								# AND (ABS (angle_degrees - {input_angle_degrees}) <= {input_uncertainty_to_rotation_angle})"""
			# sql_2 = txt_2.format(from_time = from_time, to_time = reconstruction_time, anchor_plate_id = anchor_plate_id,\
								# input_pole_latitude = pole_latitude, input_pole_longitude = pole_longitude,\
								# input_uncertainity_to_lat_and_lon_of_finite_rot_pole = uncertainity_to_lat_and_lon_of_finite_rot_pole,\
								# input_uncertainty_to_rotation_angle = uncertainty_to_rotation_angle,\
								# input_angle_degrees = angle_degrees)
			# #debug
			# if (pole_latitude == 33.879 and pole_longitude == 13.559 and angle_degrees == 2.778):
				# print('found similar rot record for 14010 from 2320Ma to 2315Ma')
			
			records_2 = equiv_rot.loc[(equiv_rot['from_time']==from_time)&(equiv_rot['to_time']==reconstruction_time)&(equiv_rot['anchor_plate_id']==anchor_plate_id)&(round(abs(equiv_rot['pole_latitude'] - pole_latitude),number_of_digits_for_rot) <= uncertainity_to_lat_and_lon_of_finite_rot_pole)&(round(abs(equiv_rot['pole_longitude'] - pole_longitude),number_of_digits_for_rot) <= uncertainity_to_lat_and_lon_of_finite_rot_pole)&(round(abs(equiv_rot['angle_degrees'] - angle_degrees),number_of_digits_for_rot) <= uncertainty_to_rotation_angle),'member_gdu_id'].unique()
			for gduid in records_2:
				gduid = int(gduid)
				if (gduid not in already_examined_GDUID):
					#if (gduid == 14010):
					#	print('found gduid 14010')
					for gdu_ft in valid_polygon_features_collection:
						if (gdu_ft.get_reconstruction_plate_id() == gduid):
							list_of_polygon_GDU_fts.append(gdu_ft)
			#debug
			#pygplates.FeatureCollection(list_of_polygon_GDU_fts).write('candidate_polygon_GDU_fts_for_'+str(gduid)+'.shp')
			
			# for other_gdu_ft in valid_polygon_features_collection:
				# found_gdu_ft_in_list = False
				# for already_included_gdu_ft in list_of_polygon_GDU_fts:
					# if (already_included_gdu_ft.get_feature_id() == other_gdu_ft.get_feature_id()):
						# found_gdu_ft_in_list = True
						# break
				# if (found_gdu_ft_in_list == False):
					# list_of_polygon_GDU_fts_to_be_considered.append(other_gdu_ft)
			#print('Here is len of list_of_polygon_GDU_fts')
			#print(len(list_of_polygon_GDU_fts))
			#list_of_polygon_GDU_fts = examine_tobeconsidered_gdu_features_with_gdu_features_rotating_together(rotation_model,list_of_polygon_GDU_fts_to_be_considered,list_of_polygon_GDU_fts,threshold_distance_km_to_be_included,reconstruction_time,reference)
			#print('Here is len of list_of_polygon_GDU_fts after')
			#print(len(list_of_polygon_GDU_fts))
			
			signal = False
			while (len(list_of_polygon_GDU_fts) > 0):
				print('len(list_of_polygon_GDU_fts)',len(list_of_polygon_GDU_fts))
				final_reconstructed_union_polygon_fts = None
				final_reconstructed_GDU_polygon_fts = None
				result,list_of_GDU_id,final_reconstructed_union_polygon_fts,list_of_outsider = are_group_of_GDUs_spatially_together_at_reconstruction_time_v2_without_projection(rotation_model, list_of_polygon_GDU_fts, buffer_distance_km, reconstruction_time, interval, reference, modelname, yearmonthday)
				# print('list_of_GDU_id',list_of_GDU_id)
				# if (17300 in list_of_GDU_id):
					# print(result)
					# for each_gduid in list_of_GDU_id:
						# print(each_gduid)
				if (signal == False):
					already_examined_GDUID = already_examined_GDUID + list_of_GDU_id
					signal = True
				#sql = """ INSERT INTO super_GDU_and_members_id (from_time, to_time, Super_GDU_id, GDU_id_member, buffer_distance_km, represent_GDU_id) VALUES(%s,%s,%s,%s,%s,%s)"""
				final_union_polygon_output = None
				#print('result',result)
				already_included_gdu_id[:] = []
				if (result == True):
					#increment Super_GDU_id 
					Super_GDU_id = Super_GDU_id + 1
					print('Super_GDU_id',Super_GDU_id)
					#sort list_of_GDU_id
					list_of_GDU_id.sort()
					already_recorded[:] = []
					reconstructed_GDU_polygon_features[:] = []
					if (reconstruction_time >= 0.00):
						if (reference is not None):
							pygplates.reconstruct(list_of_polygon_GDU_fts,rotation_model,reconstructed_GDU_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(list_of_polygon_GDU_fts,rotation_model,reconstructed_GDU_polygon_features,reconstruction_time,group_with_feature = True)
						final_reconstructed_GDU_polygon_fts = find_final_reconstructed_geometries(reconstructed_GDU_polygon_features,pygplates.PolygonOnSphere)
					final_union_polygon_output = []
					temp_dic_for_dissolved_polygon_fts = {} 
					for union_polygon_ft,union_polygon in final_reconstructed_union_polygon_fts:
						feat_id = union_polygon_ft.get_feature_id().get_string()
						if (len(temp_dic_for_dissolved_polygon_fts) == 0):
							temp_dic_for_dissolved_polygon_fts[feat_id] = (union_polygon_ft,union_polygon)
						else:
							included_in_dic = False
							#print('len(temp_dic)',len(temp_dic))
							#print(temp_dic_for_dissolved_polygon_fts)
							for random_ft_id in temp_dic_for_dissolved_polygon_fts:
								prev_tuple = temp_dic_for_dissolved_polygon_fts[random_ft_id]
								if (prev_tuple is not None):
									prev_polygon = temp_dic_for_dissolved_polygon_fts[random_ft_id][1]
									prev_polygon_ft = temp_dic_for_dissolved_polygon_fts[random_ft_id][0]
									if (prev_polygon.partition(union_polygon) == pygplates.PolygonOnSphere.PartitionResult.inside):
										temp_dic_for_dissolved_polygon_fts[feat_id] = None
										included_in_dic = True
										break
									elif (union_polygon.partition(prev_polygon) == pygplates.PolygonOnSphere.PartitionResult.inside):
										temp_dic_for_dissolved_polygon_fts[random_ft_id] = None
										temp_dic_for_dissolved_polygon_fts[feat_id] = (union_polygon_ft,union_polygon)
										included_in_dic = True
										break
							if (included_in_dic == False):
								temp_dic_for_dissolved_polygon_fts[feat_id] = (union_polygon_ft,union_polygon)
					#print("finished")
					#print(len(temp_dic_for_dissolved_polygon_fts))
					for temp_union_ft_id in temp_dic_for_dissolved_polygon_fts:
						tuple_of_union_feat = temp_dic_for_dissolved_polygon_fts[temp_union_ft_id]
						if (tuple_of_union_feat is not None):
							final_union_polygon_output.append(tuple_of_union_feat)
					list_of_gdu_id_and_polygid = []
					for union_polygon_ft,union_polygon in final_union_polygon_output:
						#from the list of GDU_id members we wan to find the GDU ft which is oldest (do we want oldest or most lasting)
						#we want the GDU member that stays for the longest period of time 
						longest_period,most_lasting_gdu_member = 0.00,None
						#oldest_age,oldest_gdu_member = 0.00,None
						list_of_gdu_id_and_polygid[:] = []
						for GDU_polygon_ft,GDU_polygon in final_reconstructed_GDU_polygon_fts:
							GDU_id = GDU_polygon_ft.get_reconstruction_plate_id()
							polygid = GDU_polygon_ft.get_shapefile_attribute('POLYGID')
							if (union_polygon.partition(GDU_polygon) == pygplates.PolygonOnSphere.PartitionResult.intersecting or\
							union_polygon.partition(GDU_polygon) == pygplates.PolygonOnSphere.PartitionResult.inside or\
							pygplates.GeometryOnSphere.distance(GDU_polygon,union_polygon) == 0.00):
							#if (pygplates.GeometryOnSphere.distance(union_polygon, GDU_polygon) == 0.00):
							#if (are_two_geometries_within_a_threshold_distance_km(union_polygon,GDU_polygon,buffer_distance_km)):
								#we want to find the GDU ft which is oldest
								begin_age_of_member,end_age_of_member = GDU_polygon_ft.get_valid_time()
								#temporary edit the end_age_of_member - to avoid the instant future value in pygplates
								time_instant = pygplates.GeoTimeInstant(end_age_of_member)
								if (time_instant.is_distant_future()):
									end_age_of_member = 0.00
									
								if (most_lasting_gdu_member is None): #have never found any member
									longest_period = abs(begin_age_of_member - end_age_of_member)
									most_lasting_gdu_member = GDU_polygon_ft
								elif (longest_period < abs(begin_age_of_member - end_age_of_member)): #checking which member is more stable
									longest_period = abs(begin_age_of_member - end_age_of_member)
									most_lasting_gdu_member = GDU_polygon_ft
								list_of_gdu_id_and_polygid.append((GDU_id,polygid))
								
								# if (oldest_gdu_member is None): #have never found any member
									# oldest_age = begin_age_of_member
									# oldest_gdu_member = GDU_polygon_ft
								# elif (oldest_age < begin_age_of_member): #checking which member is more stable
									# oldest_age = begin_age_of_member
									# oldest_gdu_member = GDU_polygon_ft	
										
						#set the Super_GDU_id for the union_polygon_ft
						union_polygon_ft.set_name(str(Super_GDU_id))
						if (most_lasting_gdu_member is not None):
							#set the reconstruction plate id of the SuperGDU with the most stable member GDU id
							union_polygon_ft.set_reconstruction_plate_id(most_lasting_gdu_member.get_reconstruction_plate_id())
							if (reference is not None):
								pygplates.reverse_reconstruct(union_polygon_ft,rotation_model,reconstruction_time,reference)
							else:
								pygplates.reverse_reconstruct(union_polygon_ft,rotation_model,reconstruction_time)

							for GDU_id_member,polygid in list_of_gdu_id_and_polygid:
								if (polygid not in already_recorded):
									#execute the insert statement 
									#cur_3.execute(sql, (from_time, reconstruction_time, Super_GDU_id, GDU_id_member, buffer_distance_km, most_lasting_gdu_member.get_reconstruction_plate_id()))
									output_record = (from_time, reconstruction_time, Super_GDU_id, GDU_id_member, polygid, buffer_distance_km, most_lasting_gdu_member.get_reconstruction_plate_id())
									supergdu_and_members_tuples.append(output_record)
									already_recorded.append(polygid)
									already_included_gdu_id.append(GDU_id_member)
						else:
							if (reference is not None):
								pygplates.reverse_reconstruct(union_polygon_ft,rotation_model,reconstruction_time,reference)
							else:
								pygplates.reverse_reconstruct(union_polygon_ft,rotation_model,reconstruction_time)

							for GDU_id_member,polygid in list_of_gdu_id_and_polygid:
								if (polygid not in already_recorded):
									#execute the insert statement 
									#cur_3.execute(sql, (from_time, reconstruction_time, Super_GDU_id, GDU_id_member, buffer_distance_km, most_lasting_gdu_member.get_reconstruction_plate_id()))
									output_record = (from_time, reconstruction_time, Super_GDU_id, GDU_id_member, polygid, buffer_distance_km, most_lasting_gdu_member.get_reconstruction_plate_id())
									supergdu_and_members_tuples.append(output_record)
									already_recorded.append(polygid)
									already_included_gdu_id.append(GDU_id_member)
							suspected_union_polygon_fts.append(union_polygon_ft)
					for union_polygon_ft,union_polygon in final_union_polygon_output:
						union_polygon_fts.append(union_polygon_ft.clone())
				else:
					if final_reconstructed_union_polygon_fts is None:
						print('Error in create_equivalent_rotation_groups')
						print('Error value of final_reconstructed_union_polygon_fts is NONE')
						print('list_of_GDU_id',list_of_GDU_id)
						for gdu_ft in list_of_polygon_GDU_fts:
							print(gdu_ft.get_valid_time())
							print(gdu_ft.get_shapefile_attribute('POLYGID'))
						exit()
					if final_reconstructed_union_polygon_fts is not None:
						list_of_reconstructed_members_gdus = []
						reconstructed_GDU_polygon_features[:] = []
						if (reference is not None):
							pygplates.reconstruct(list_of_polygon_GDU_fts, rotation_model, reconstructed_GDU_polygon_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(list_of_polygon_GDU_fts, rotation_model, reconstructed_GDU_polygon_features, reconstruction_time, group_with_feature = True)
						final_reconstructed_GDU_polygon_fts = find_final_reconstructed_geometries(reconstructed_GDU_polygon_features,pygplates.PolygonOnSphere)
						
						final_union_polygon_output = []
						temp_dic_for_dissolved_polygon_fts = {} 
						for union_polygon_ft,union_polygon in final_reconstructed_union_polygon_fts:
							feat_id = union_polygon_ft.get_feature_id().get_string()
							if (len(temp_dic_for_dissolved_polygon_fts) == 0):
								temp_dic_for_dissolved_polygon_fts[feat_id] = (union_polygon_ft,union_polygon)
							else:
								included_in_dic = False
								#print('len(temp_dic)',len(temp_dic))
								for random_ft_id in temp_dic_for_dissolved_polygon_fts:
									prev_tuple = temp_dic_for_dissolved_polygon_fts[random_ft_id]
									if (prev_tuple is not None):
										prev_polygon = temp_dic_for_dissolved_polygon_fts[random_ft_id][1]
										prev_polygon_ft = temp_dic_for_dissolved_polygon_fts[random_ft_id][0]
										if (prev_polygon.partition(union_polygon) == pygplates.PolygonOnSphere.PartitionResult.inside):
											temp_dic_for_dissolved_polygon_fts[feat_id] = None
											included_in_dic = True
											break
										elif (union_polygon.partition(prev_polygon) == pygplates.PolygonOnSphere.PartitionResult.inside):
											temp_dic_for_dissolved_polygon_fts[random_ft_id] = None
											temp_dic_for_dissolved_polygon_fts[feat_id] = (union_polygon_ft,union_polygon)
											included_in_dic = True
											break
								if (included_in_dic == False):
									temp_dic_for_dissolved_polygon_fts[feat_id] = (union_polygon_ft,union_polygon)
						for temp_union_ft_id in temp_dic_for_dissolved_polygon_fts:
							tuple_of_union_feat = temp_dic_for_dissolved_polygon_fts[temp_union_ft_id]
							if (tuple_of_union_feat is not None):
								final_union_polygon_output.append(tuple_of_union_feat)
						
						already_processed_temp_union_polygon_fts = []
						dictionary_of_temp_sgdu_and_members = {}
						for union_polygon_ft,union_polygon in final_union_polygon_output:
							#increment Super_GDU_id 
							Super_GDU_id = Super_GDU_id + 1
							print('Super_GDU_id',Super_GDU_id)
							already_recorded[:] = []
							list_of_reconstructed_members_gdus[:]=[]
							#from the list of GDU_id members we wan to find the GDU ft which is oldest (do we want oldest or most lasting)
							#we want the GDU member that stays for the longest period of time 
							longest_period,most_lasting_gdu_member = 0.00,None
							#oldest_age,oldest_gdu_member = 0.00,None
							for GDU_polygon_ft,GDU_polygon in final_reconstructed_GDU_polygon_fts:
								if (union_polygon.partition(GDU_polygon) == pygplates.PolygonOnSphere.PartitionResult.intersecting or\
									union_polygon.partition(GDU_polygon) == pygplates.PolygonOnSphere.PartitionResult.inside or\
									pygplates.GeometryOnSphere.distance(GDU_polygon,union_polygon) == 0.00):
								#if (pygplates.GeometryOnSphere.distance(union_polygon, GDU_polygon) == 0.00):
								#if (are_two_geometries_within_a_threshold_distance_km(union_polygon,GDU_polygon,buffer_distance_km)):
									#we want to find the GDU ft which is oldest
									begin_age_of_member,end_age_of_member = GDU_polygon_ft.get_valid_time()
									#temporary edit the end_age_of_member - to avoid the instant future value in pygplates
									time_instant = pygplates.GeoTimeInstant(end_age_of_member)
									if (time_instant.is_distant_future()):
										end_age_of_member = 0.00
									if (most_lasting_gdu_member is None): #have never found any member
										longest_period = abs(begin_age_of_member - end_age_of_member)
										most_lasting_gdu_member = GDU_polygon_ft
									elif (longest_period < abs(begin_age_of_member - end_age_of_member)): #checking which member is more stable
										longest_period = abs(begin_age_of_member - end_age_of_member)
										most_lasting_gdu_member = GDU_polygon_ft
									list_of_reconstructed_members_gdus.append((GDU_polygon_ft,GDU_polygon))
							
							#old method to name SuperGDU features 
							# final_Super_GDU_id_name = None
							# if (len(already_processed_temp_union_polygon_fts) == 0 or union_polygon_ft.get_feature_id() in list_of_outsider):
								# final_Super_GDU_id_name = str(Super_GDU_id)
							# else:
								# for already_processed_temp_union_ft,already_processed_temp_polygon in already_processed_temp_union_polygon_fts:
									# if (already_processed_temp_union_ft.get_feature_id() not in list_of_outsider):
										# temporary_distance_btw_temp_union_polygons,closest_pt_on_temp_polygon,closest_pt_on_union_polygon = pygplates.GeometryOnSphere.distance(already_processed_temp_polygon,union_polygon,return_closest_positions=True)
										# if (temporary_distance_btw_temp_union_polygons == 0.00):
											# final_Super_GDU_id_name = already_processed_temp_union_ft.get_name()
											# break
								# if (final_Super_GDU_id_name is None):
									# final_Super_GDU_id_name = str(Super_GDU_id)
							
							#debug 
							#print('len(already_processed_temp_union_polygon_fts)',len(already_processed_temp_union_polygon_fts))
							#print('is union_polygon_ft.get_feature_id() in list_of_outsider',union_polygon_ft.get_feature_id() in list_of_outsider)
							
							final_Super_GDU_id_name = None
							if (len(already_processed_temp_union_polygon_fts) == 0 or union_polygon_ft.get_feature_id() in list_of_outsider):
								final_Super_GDU_id_name = str(Super_GDU_id)
							else:
								for already_processed_temp_union_ft,already_processed_temp_polygon in already_processed_temp_union_polygon_fts:
									if (already_processed_temp_union_ft.get_feature_id() not in list_of_outsider):
										temporary_distance_btw_temp_union_polygons,closest_pt_on_temp_polygon,closest_pt_on_union_polygon = pygplates.GeometryOnSphere.distance(already_processed_temp_polygon,union_polygon,return_closest_positions=True)
										lat1,lon1 = closest_pt_on_temp_polygon.to_lat_lon()
										lat2,lon2 = closest_pt_on_union_polygon.to_lat_lon()
										temp_haversine_distance = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
										if (temporary_distance_btw_temp_union_polygons == 0.00 or temp_haversine_distance <= buffer_distance_km):
											final_Super_GDU_id_name = already_processed_temp_union_ft.get_name()
											break
								if (final_Super_GDU_id_name is None):
									if (union_polygon_ft.get_feature_id() not in list_of_outsider):
										final_Super_GDU_id_name = str(Super_GDU_id)
								
							if (final_Super_GDU_id_name is None):
								print ('Error final_Super_GDU_id_name is None')
								exit()
							
							#set the Super_GDU_id for the union_polygon_ft
							union_polygon_ft.set_name(final_Super_GDU_id_name)
							if (final_Super_GDU_id_name not in dictionary_of_temp_sgdu_and_members):
								dictionary_of_temp_sgdu_and_members[final_Super_GDU_id_name] = []
							if (most_lasting_gdu_member is not None):
								#set the reconstruction plate id of the SuperGDU with the most stable member GDU id
								union_polygon_ft.set_reconstruction_plate_id(most_lasting_gdu_member.get_reconstruction_plate_id())
								if (reference is not None):
									pygplates.reverse_reconstruct(union_polygon_ft,rotation_model,reconstruction_time,reference)
								else:
									pygplates.reverse_reconstruct(union_polygon_ft,rotation_model,reconstruction_time)
								for GDU_polygon_ft,GDU_polygon in list_of_reconstructed_members_gdus:
									GDU_id = GDU_polygon_ft.get_reconstruction_plate_id()
									polygid = GDU_polygon_ft.get_shapefile_attribute('POLYGID')
									if (polygid not in already_recorded):
										#execute the insert statement 
										#cur_3.execute(sql, (from_time, reconstruction_time, Super_GDU_id, GDU_id, buffer_distance_km, most_lasting_gdu_member.get_reconstruction_plate_id()))
										#output_record = (from_time, reconstruction_time, final_Super_GDU_id_name, GDU_id, polygid, buffer_distance_km, most_lasting_gdu_member.get_reconstruction_plate_id())
										#supergdu_and_members_tuples.append(output_record)
										already_recorded.append(polygid)
										already_included_gdu_id.append(GDU_id)
										dictionary_of_temp_sgdu_and_members[final_Super_GDU_id_name].append((GDU_id, polygid,most_lasting_gdu_member.get_reconstruction_plate_id()))
							else:
								if (reference is not None):
									pygplates.reverse_reconstruct(union_polygon_ft,rotation_model,reconstruction_time,reference)
								else:
									pygplates.reverse_reconstruct(union_polygon_ft,rotation_model,reconstruction_time)
								suspected_union_polygon_fts.append(union_polygon_ft)
								for GDU_polygon_ft,GDU_polygon in final_reconstructed_GDU_polygon_fts:
									GDU_id = GDU_polygon_ft.get_reconstruction_plate_id()
									polygid = GDU_polygon_ft.get_shapefile_attribute('POLYGID')
									if (polygid not in already_recorded):
										#execute the insert statement 
										#cur_3.execute(sql, (from_time, reconstruction_time, Super_GDU_id, GDU_id, buffer_distance_km, None))
										#output_record = (from_time, reconstruction_time, final_Super_GDU_id_name, GDU_id, polygid, buffer_distance_km, None)
										#supergdu_and_members_tuples.append(output_record)
										already_recorded.append(polygid)
										already_included_gdu_id.append(GDU_id)
										dictionary_of_temp_sgdu_and_members[final_Super_GDU_id_name].append((GDU_id, polygid,None))
							already_processed_temp_union_polygon_fts.append((union_polygon_ft,union_polygon))

					already_recorded_gdu_members = []
					# already_examined_temp_union_features = []
					# for union_polygon_ft,union_polygon in final_union_polygon_output:
						# if (union_polygon_ft.get_feature_id() in already_examined_temp_union_features or union_polygon_ft.get_feature_id() in list_of_outsider):
							# continue
						# min_distance = -1.00
						# chosen_other_polygon_ft = None
						# for other_union_polygon_ft,other_union_polygon in final_union_polygon_output:
							# if (union_polygon_ft.get_name() != other_union_polygon_ft.get_name() and other_union_polygon_ft.get_feature_id() not in list_of_outsider):
								# _,closest_pt_on_union_polygon,closest_pt_on_other_polygon = pygplates.GeometryOnSphere.distance(union_polygon,other_union_polygon,return_closest_positions=True)
								# lat1,lon1 = closest_pt_on_union_polygon.to_lat_lon()
								# lat2,lon2 = closest_pt_on_other_polygon.to_lat_lon()
								# dist_haversine_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
								# if (min_distance == -1.00 or min_distance > dist_haversine_km):
									# min_distance = dist_haversine_km
									# chosen_other_polygon_ft = other_union_polygon_ft
						# if (min_distance <= buffer_distance_km and min_distance >= 0.00):
							# if (union_polygon_ft.get_name() not in already_recorded_gdu_members):
								# list_of_tuples_for_members = dictionary_of_temp_sgdu_and_members[union_polygon_ft.get_name()]
								# for GDU_id, polygid, most_lasting_gdu_id_member in list_of_tuples_for_members:
									# output_record = (from_time, reconstruction_time, chosen_other_polygon_ft.get_name(), GDU_id, polygid, buffer_distance_km, most_lasting_gdu_id_member)
									# supergdu_and_members_tuples.append(output_record)
								# already_recorded_gdu_members.append(union_polygon_ft.get_name())
								# del dictionary_of_temp_sgdu_and_members[union_polygon_ft.get_name()]
							# union_polygon_ft.set_name(chosen_other_polygon_ft.get_name())
							# already_examined_temp_union_features.append(union_polygon_ft.get_feature_id())
							# already_examined_temp_union_features.append(chosen_other_polygon_ft.get_feature_id())

					for union_polygon_ft,union_polygon in final_union_polygon_output:
						if (union_polygon_ft.get_name() in dictionary_of_temp_sgdu_and_members):
							if (union_polygon_ft.get_name() not in already_recorded_gdu_members):
								already_recorded_gdu_members.append(union_polygon_ft.get_name())
								list_of_tuples_for_members = dictionary_of_temp_sgdu_and_members[union_polygon_ft.get_name()]
								for GDU_id, polygid, most_lasting_gdu_id_member in list_of_tuples_for_members:
									output_record = (from_time, reconstruction_time, union_polygon_ft.get_name(), GDU_id, polygid, buffer_distance_km, most_lasting_gdu_id_member)
									supergdu_and_members_tuples.append(output_record)
						union_polygon_fts.append(union_polygon_ft.clone())
				
				
				#for potential_gduid in records_2:
				print('already_examined_GDUID')
				for potential_gduid in list_of_GDU_id:
					potential_gduid = int(potential_gduid)
					if ((potential_gduid in already_included_gdu_id) == False):
						suspected_gdu_ids.append((reconstruction_time,potential_gduid))
				
				temp_missing_gdu_feats = []
				for potemtial_missing_gdu_ft, potential_reconstructed_gdu in final_reconstructed_GDU_polygon_fts:
					if (potemtial_missing_gdu_ft.get_reconstruction_plate_id() not in already_included_gdu_id):
						found_sgdu = False
						for union_polygon_ft,union_polygon in final_union_polygon_output:
							if (union_polygon.partition(potential_reconstructed_gdu) == pygplates.PolygonOnSphere.PartitionResult.intersecting or\
								union_polygon.partition(potential_reconstructed_gdu) == pygplates.PolygonOnSphere.PartitionResult.inside or\
								pygplates.GeometryOnSphere.distance(potential_reconstructed_gdu,union_polygon) == 0.00):
								GDU_id = potemtial_missing_gdu_ft.get_reconstruction_plate_id()
								polygid = potemtial_missing_gdu_ft.get_shapefile_attribute('POLYGID')
								if (union_polygon_ft.get_reconstruction_plate_id() != reference and union_polygon_ft.get_reconstruction_plate_id() != 0):
									output_record = (from_time, reconstruction_time, int(union_polygon_ft.get_name()), GDU_id, polygid, buffer_distance_km, union_polygon_ft.get_reconstruction_plate_id())
									supergdu_and_members_tuples.append(output_record)
								else:
									output_record = (from_time, reconstruction_time, int(union_polygon_ft.get_name()), GDU_id, polygid, buffer_distance_km, None)
									supergdu_and_members_tuples.append(output_record)
								found_sgdu = True
								break
						if (found_sgdu == False):
							temp_missing_gdu_feats.append(potemtial_missing_gdu_ft)
				print('len(temp_missing_gdu_feats)',len(temp_missing_gdu_feats))
				list_of_polygon_GDU_fts = temp_missing_gdu_feats

		#record value at every reconstruction_time
		#(from_time, to_time, Super_GDU_id, GDU_id_member, buffer_distance_km, represent_GDU_id)
		output_df = pd.DataFrame(supergdu_and_members_tuples, columns = ['from_time', 'to_time', 'SGDUID', 'GDUID', 'POLYGID','buffer_distance_km', 'repGDUID'])
		output_df.to_csv('supergdu_and_members_gdu_at_'+str(reconstruction_time)+'_for_'+modelname+'_'+yearmonthday+'.csv',sep=';',header=True)
		supergdu_and_members_tuples[:] = []
		
		if (len(suspected_gdu_ids) > 0):
			output_df = pd.DataFrame(suspected_gdu_ids, columns = ['reconstruction_time', 'GDUID'])
			output_df.to_csv('suspected_gdu_ids_'+str(reconstruction_time)+'_for_'+modelname+'_'+yearmonthday+'.csv',sep=';',header=True)
			suspected_gdu_ids[:] = []
		# if (len(missing_gdu_feats) > 0):
			# missing_gdu_feats_collection = pygplates.FeatureCollection(missing_gdu_feats)
			# missing_gdu_feats_collection.write('missing_gdu_feats_collection_'+str(reconstruction_time)+'_for_'+modelname+'_'+yearmonthday+'.shp')
			# missing_gdu_feats[:] = []

		outputFeatureCollection = pygplates.FeatureCollection(union_polygon_fts)
		outputFeatureFile = 'dissolved_polygon_fts_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
		outputFeatureCollection.write(outputFeatureFile)
		outputFeatureFile = 'dissolved_polygon_fts_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
		outputFeatureCollection.write(outputFeatureFile)
		if (len(suspected_union_polygon_fts) > 0):
			outputFeatureCollection = pygplates.FeatureCollection(suspected_union_polygon_fts)
			outputFeatureFile = 'suspected_dissolved_polygon_fts_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
			outputFeatureCollection.write(outputFeatureFile)
			outputFeatureFile = 'suspected_dissolved_polygon_fts_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
			outputFeatureCollection.write(outputFeatureFile)
		union_polygon_fts[:] = []
		suspected_union_polygon_fts[:] = []
				
		# if ((previous_record_time - reconstruction_time)/interval >= 200.00):
			# outputFeatureCollection = pygplates.FeatureCollection(union_polygon_fts)
			# outputFeatureFile = 'dissolved_polygon_fts_from_'+str(previous_record_time)+'_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
			# outputFeatureCollection.write(outputFeatureFile)
			# outputFeatureFile = 'dissolved_polygon_fts_from_'+str(previous_record_time)+'_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
			# outputFeatureCollection.write(outputFeatureFile)
			# outputFeatureCollection = pygplates.FeatureCollection(suspected_union_polygon_fts)
			# outputFeatureFile = 'suspected_dissolved_polygon_fts_from_'+str(previous_record_time)+'_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
			# outputFeatureCollection.write(outputFeatureFile)
			# outputFeatureFile = 'suspected_dissolved_polygon_fts_from_'+str(previous_record_time)+'_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
			# outputFeatureCollection.write(outputFeatureFile)
			
			# union_polygon_fts[:] = []
			# suspected_union_polygon_fts[:] = []
			# previous_record_time = reconstruction_time
			
		#update_reconstruction_time
		reconstruction_time = reconstruction_time - interval

def main():
	rotation_file = r"../T_Rot_Model_PalaeoPlates_20240205.grot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_file = r"1000_0_rotfile_Merdith_et_al_optimised.rot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\1000_0_rotfile_Merdith_et_al.rot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\LiLiuErnst2023\EDRG_90W_2000-540Ma.rot"
	#rotation_file = r"EDRG_90W_2000-540Ma.rot"
	#rotation_file = r"PALEOMAP_PlateModel.rot"
	rotation_model = pygplates.RotationModel(rotation_file)
	#GDU_fts_file = r"../all_gdu_features_w_all_valid_attributes_PalaeoPlatesFeb2024_20240214.shp"
	GDU_fts_file = r"../ASI_cont_gdu_features_w_all_valid_attributes_PalaeoPlatesFeb2024_20240214.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\LomonosovRidge_at_0Ma.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\Valid_EB2021_shape_continents_polygons.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\edit_shapes_continents_Merdith_et_al.gpml"
	#GDU_fts_file = r"edit_shapes_continents_Merdith_et_al.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\LiLiuErnst2023\QGIS_single_parts_valid_and_fixed_Continental_outlines.shp"
	#GDU_fts_file = r"QGIS_single_parts_valid_and_fixed_Continental_outlines.shp
	#GDU_fts_file = r"GPLATES_attributes_features_w_valid_geom_plateid_and_age_from_PALEOMAP_terranes.shp"
	GDU_fts_collection = pygplates.FeatureCollection(GDU_fts_file)
	print ("Here is rotation_file")
	print (rotation_file)
	print ("Here is GDU_fts_file")
	print (GDU_fts_file)
	list_of_members_GDU_IDs = []
	for GDU_ft in GDU_fts_collection:
		GDU_id = GDU_ft.get_reconstruction_plate_id()
		if GDU_id not in list_of_members_GDU_IDs:
			list_of_members_GDU_IDs.append(GDU_id)
	from_time = 3000.00
	to_time = 0.00
	interval = 5.00
	#reference = 0
	reference = 700
	number_of_decimals = 3
	#modelname = "EB2022_w_optimised_rot"
	#modelname = 'Muller_Merdith_optimised_EB2022'
	#modelname = "LiLiuErnst2023_W"
	#modelname = "LomonosovRidge_at_0Ma"
	modelname = "ASI_PalaeoPlatesFeb2024_w_valid_rot_1000km"
	#modelname = "GPLATES_PALEOMAPScotese_w_valid_rot_1000km"
	yearmonthday = "20240829"
	
	equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_ASI_PalaeoPlatesFeb2024_20240829.csv"
	#equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_QGIS_fixed_PalaeoPlatesendJan2023_20230412.csv"
	#equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_LiLiuErnst2023_20230318.csv"
	#equivalent_stage_rotation_csv_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\equivalent_rot_of_each_gdu_with_anchor_EB2021_20221222.csv"
	#equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_EB2022_20230202.csv"
	#equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_GPLATES_attributes_PALEOMAPScotese_20230412.csv"
	buffer_distance_km = 1000.00
	#threshold_distance_km_to_be_included = 500.00
	uncertainity_to_lat_and_lon_of_finite_rot_pole = 0.1000
	uncertainty_to_rotation_angle = 0.5000
	number_of_digits_for_rot = 3
	create_equivalent_rotation_groups_with_uncertainity_for_finite_rotation_without_projection(equivalent_stage_rotation_csv_file, rotation_model, GDU_fts_collection, from_time, to_time, interval, buffer_distance_km, uncertainity_to_lat_and_lon_of_finite_rot_pole, uncertainty_to_rotation_angle, number_of_digits_for_rot, reference, modelname, yearmonthday)

if __name__== '__main__':
	main()
