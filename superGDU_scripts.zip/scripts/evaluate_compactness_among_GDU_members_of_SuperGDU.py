#import os
#import csv
import math
#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.errors import TopologicalError
from shapely.geometry import Point, Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, GeometryCollection, JOIN_STYLE
from shapely.ops import unary_union, transform, cascaded_union, polygonize, polygonize_full, linemerge, triangulate
from functools import partial
from shapely.validation import explain_validity
import pyproj
import find_SuperGDU_geometries as supporting_sgdu


def convert_Polygon_to_PolygonOnSphere_in_pygplates(each_polygon):
	if (each_polygon.is_valid == False or each_polygon.area == 0.00):
		print("Warning about the validity of the shapely POLYGON")
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			#print("lat,lon")
			#print(lat,lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
				print("Warning invalid value of latitude or/and longitude")
				print("value of latitude")
				print(lat)
				print("value of longitude")
				print(lon)
				if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
					if (abs(abs(lat) - 90.00) < 0.500):
						if (lat < -90.00):
							lat = -90.000
						elif (lat > 90.00):
							lat = 90.000
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of latitude")
						print("value of latitude")
						print(lat)					
						exit()
				if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
					if (abs(abs(lon) - 180.00) < 0.500):
						if (lon < -180.00):
							lon = -180.00
						elif (lon > 180.00):
							lon = 180.00
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of longitude")
						print("value of longitude")
						print(lon)					
						exit()
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print("Error in creating polygon in pygplates in conversion module")
			print("Here is a list of lat_lon vertices")
			print(list_of_lat_lon_vertices)
			print("Here is the first vertex and the last vertex:")
			print(list_of_lat_lon_vertices[0])
			print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
			exit()
		return new_polygon
	if (each_polygon.area > 0.00):
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			#print("lat,lon")
			#print(lat,lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
				print("Warning invalid value of latitude or/and longitude")
				print("value of latitude")
				print(lat)
				print("value of longitude")
				print(lon)
				if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
					if (abs(abs(lat) - 90.00) < 0.500):
						if (lat < -90.00):
							lat = -90.000
						elif (lat > 90.00):
							lat = 90.000
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of latitude")
						print("value of latitude")
						print(lat)					
						exit()
				if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
					if (abs(abs(lon) - 180.00) < 0.500):
						if (lon < -180.00):
							lon = -180.00
						elif (lon > 180.00):
							lon = 180.00
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of longitude")
						print("value of longitude")
						print(lon)					
						exit()
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print("Error in creating polygon in pygplates in conversion module")
			print("Here is a list of lat_lon vertices")
			print(list_of_lat_lon_vertices)
			print("Here is the first vertex and the last vertex:")
			print(list_of_lat_lon_vertices[0])
			print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
			exit()
		return new_polygon
	else:
		print("Error in creating polygon in pygplates in conversion module")
		print("Error each_polygon.area <= 0.00")
		print("here is each_polygon")
		print(each_polygon)
		print([(lon,lat) for lon,lat in each_polygon.exterior.coords])
		exit()

def convert_polygon_to_Polygon_in_shapely(each_polygon):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in each_polygon.to_lat_lon_list()]
	new_polygon = Polygon(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating Polygon in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_polygon

def is_crossing_the_DateLine(polygon):
	#new
	date_line_wrapper = pygplates.DateLineWrapper()
	wrapped_polygons = date_line_wrapper.wrap(polygon)
	if (len(wrapped_polygons) >= 2):
		return True
	else:
		return False

def find_convexhull_for_group_of_gdu_members_of_SGDU(rotation_model, list_of_polygon_GDU_fts, reconstruction_time, interval, reference, modelname, yearmonthday, warning_on):
	featType = pygplates.FeatureType.gpml_continental_crust
	_, polygon_fts_and_wrapped_polygons, error_polygon_fts = supporting_sgdu.clean_polygon_features_w_date_line_wrapper(rotation_model, list_of_polygon_GDU_fts, reconstruction_time, reference, modelname, yearmonthday)
	
	polygons_for_unary_union = []
	temporary_wrapped_polygons = []
	reconstructed_dissolved_polygon_features = []
	invalid_polygons_for_later_union = []
	invalid_initial_Shapely_polygons_for_later_union = []
	if (polygon_fts_and_wrapped_polygons is None):
		print ("Error in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
		print ("Error polygon_fts_and_wrapped_polygons is None")
		print ("Here is input list_of_polygon_GDU_fts:")
		print (list_of_polygon_GDU_fts)
		exit()
	if (len(polygon_fts_and_wrapped_polygons) == 0 and len(error_polygon_fts) == 0):
		print ("Suspection in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
		print ("Issue len(polygon_fts_and_wrapped_polygons) == 0")
		print ("Here is input list_of_polygon_GDU_fts:")
		print (list_of_polygon_GDU_fts)
		if (warning_on == True):
			exit()
	
	# if (len(polygon_fts_and_wrapped_polygons) == 0):
		# print ("Suspection in find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time")
		# print ("Issue len(polygon_fts_and_wrapped_polygons) == 0")
		# print ("Here is input list_of_polygon_GDU_fts:")
		# print (list_of_polygon_GDU_fts)
		# if (warning_on == True):
			# exit()
	
			
	#NEW
	print('len(error_polygon_fts)',len(error_polygon_fts))
	polygon_fts_and_wrapped_polygons = polygon_fts_and_wrapped_polygons + error_polygon_fts
	print('len(polygon_fts_and_wrapped_polygons)',len(polygon_fts_and_wrapped_polygons))
	
	closed_to_North_pole = False
	closed_to_South_pole = False
	closed_to_dateline = False
	for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		if (supporting_sgdu.determine_whether_geometry_of_a_feature_closed_to_geo_North_pole(polygon) == True):
			closed_to_North_pole = True
			break
		elif (supporting_sgdu.determine_whether_geometry_of_a_feature_closed_to_geo_South_pole(polygon) == True):
			closed_to_South_pole = True
			break
	for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		check_crossing_the_dateline = is_crossing_the_DateLine(polygon)
		print('is_crossing_the_DateLine(polygon)',check_crossing_the_dateline)
		if (check_crossing_the_dateline == True):
			closed_to_dateline = True
			break
	
	#choose a random representative GDUID: all GDU members have a similar equivalent stage rotation 
	random_repGDUID = polygon_ft.get_reconstruction_plate_id()
	
	finite_rotation = None
	if (closed_to_North_pole == True):
		#project away the North pole: the rotation axis through the pole (0 degree lat, 0 degree lon) and angle of rotation is -90.00
		finite_rotation = pygplates.FiniteRotation((0.00,0.00),math.radians(-90.00))
	elif (closed_to_South_pole == True):
		#project away the South pole: the rotation axis through the pole (0 degree lat, 0 degree lon) and angle of rotation is +90.00
		finite_rotation = pygplates.FiniteRotation((0.00,0.00),math.radians(90.00))
	finite_rotation_2 = None
	if (closed_to_dateline == True):
		finite_rotation_2 = pygplates.FiniteRotation((89.00,0.00),math.radians(180.00))

	if (finite_rotation is not None):
		if (finite_rotation_2 is not None):
			composed_finite_rotation = finite_rotation*finite_rotation_2
			finite_rotation = composed_finite_rotation
	else:
		if (finite_rotation_2 is not None):
			finite_rotation = finite_rotation_2
	
	#print('finite_rotation_2',finite_rotation_2)

	#temporal_rotated_polygon_fts = []
	for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		if (finite_rotation is not None):
			rotated_polygon = finite_rotation*polygon
			polygon = rotated_polygon.clone()
		#old
		# Polygon_in_shapely = convert_polygon_to_Polygon_in_shapely(polygon)
		# if (Polygon_in_shapely.is_valid == False):
			# invalid_polygons_for_later_union.append(polygon.clone())
		# else:
			# temporary_wrapped_polygons.append(Polygon_in_shapely)
		#new
		date_line_wrapper = pygplates.DateLineWrapper()
		wrapped_polygons = date_line_wrapper.wrap(polygon)
		if (len(wrapped_polygons) >= 2):
			for wrapped_polygon in wrapped_polygons:
				new_polygon = pygplates.PolygonOnSphere(wrapped_polygon.get_exterior_points())
				Polygon_in_shapely = supporting_sgdu.convert_polygon_to_Polygon_in_shapely(new_polygon)
				if (Polygon_in_shapely.is_valid == False):
					#don't reverse-rotate anything until after create final output dissolved features
					invalid_polygons_for_later_union.append(new_polygon.clone())
					#invalid_initial_Shapely_polygons_for_later_union.append(Polygon_in_shapely)
					
					# fixed_valid_polygons = fix_invalid_Shapely_polygon(Polygon_in_shapely)
					# if (fixed_valid_polygons.geom_type == "MultiPolygon"):
						# for individual_polygon in fixed_valid_polygons:
							# temporary_wrapped_polygons.append(individual_polygon)
					# elif (fixed_valid_polygons.geom_type == "Polygon"):
						# temporary_wrapped_polygons.append(fixed_valid_polygons)
				else:
					temporary_wrapped_polygons.append(Polygon_in_shapely)
		else:
			Polygon_in_shapely = supporting_sgdu.convert_polygon_to_Polygon_in_shapely(polygon)
			if (Polygon_in_shapely.is_valid == False):
				#don't reverse-rotate anything until after create final output dissolved features
				invalid_polygons_for_later_union.append(polygon.clone())
				#invalid_initial_Shapely_polygons_for_later_union.append(Polygon_in_shapely)

				# fixed_valid_polygons = fix_invalid_Shapely_polygon(Polygon_in_shapely)
				# if (fixed_valid_polygons.geom_type == "MultiPolygon"):
					# for individual_polygon in fixed_valid_polygons:
						# temporary_wrapped_polygons.append(individual_polygon)
				# elif (fixed_valid_polygons.geom_type == "Polygon"):
					# temporary_wrapped_polygons.append(fixed_valid_polygons)
			else:
				temporary_wrapped_polygons.append(Polygon_in_shapely)

	#make sure to remove duplicated Polygon first before peforming convex_hull
	for polygon_1 in temporary_wrapped_polygons:
		if (len(polygons_for_unary_union) == 0):
			polygons_for_unary_union.append(polygon_1)
		else:
			duplicated = False
			for polygon_2 in polygons_for_unary_union:
				if(polygon_1.__eq__(polygon_2)):
					duplicated = True
					break
			if (duplicated == False):
				polygons_for_unary_union.append(polygon_1)
	#perform convex_hull
	#collection_of_geometries = unary_union([polygon for polygon in polygons_for_unary_union])
	result = None
	if (len(invalid_polygons_for_later_union) > 0):
		result = unary_union([polygon for polygon in polygons_for_unary_union])
	else:
		collection_of_geometries = GeometryCollection(polygons_for_unary_union)
		result = collection_of_geometries.convex_hull
	
	#perform map projection to World Mollweide since all geometries are about equatorial region
	# wgs84 = pyproj.CRS('EPSG:4326')
	# World_Mollweide = pyproj.CRS('ESRI:54009')

	# project = pyproj.Transformer.from_crs(wgs84, World_Mollweide, always_xy = True).transform
	# mollweide_geometries = transform(project, collection_of_geometries)
	# reverse_proj = pyproj.Transformer.from_crs(World_Mollweide, wgs84, always_xy = True).transform
	
	#print('number of members for collection_of_geometries',len(collection_of_geometries))
	#result_cvhull = mollweide_geometries.convex_hull
	#result = transform(reverse_proj, result_cvhull)
	
	#result = collection_of_geometries.convex_hull
	print('result.geom_type',result.geom_type)
	if (result.geom_type == 'Polygon'):
		new_PolygonOnSphere = None
		if (result.is_valid):
			#result = result.convex_hull
			#only take the exterior
			#convert the polygon to PolygonOnSphere
			new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(result)
			if (finite_rotation is not None):
				original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
				new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
			#create new Feature in pygplates
			new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='dissolved_polygon_ft_only',valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
			if (reference is not None):
				new_feature.set_reconstruction_plate_id(reference)
			reconstructed_dissolved_polygon_features.append(new_feature)
		else:
			#NEW 
			print("result of unary_union for polygons_for_unary_union is an INVALID POLYGON")
			count = 0
			for polygon_with_issue in invalid_polygons_for_later_union:
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*polygon_with_issue
					polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
				#create new Feature in pygplates
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,polygon_with_issue,name='invalid_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				count = count + 1
			#reverse_reconstruct
			if (reference is not None):
				pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
			else:
				pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
			pygplates.FeatureCollection(reconstructed_dissolved_polygon_features).write("invalid_polygon_features_at_"+str(reconstruction_time)+".shp")
			exit()
		list_of_invalid_polygon_to_created_as_sep_ft = []
		if (len(invalid_polygons_for_later_union) > 0):
			#only take the exterior
			#convert the polygon to PolygonOnSphere
			result = result.convex_hull
			new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(result)
			if (finite_rotation is not None):
				original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
				new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
			count = 0
			for ini_polygon_with_issue in invalid_polygons_for_later_union:
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*ini_polygon_with_issue
					ini_polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
				if (new_PolygonOnSphere.partition(ini_polygon_with_issue) != pygplates.PolygonOnSphere.PartitionResult.inside):
					list_of_invalid_polygon_to_created_as_sep_ft.append(ini_polygon_with_issue)
			for invalid_polygon_to_be_included in list_of_invalid_polygon_to_created_as_sep_ft:
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,invalid_polygon_to_be_included,name='other_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				count = count + 1 
	# elif (result.geom_type == 'MultiPolygon'):
		# result = result.convex_hull
		# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(result)
		# if (finite_rotation is not None):
			# original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
			# new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
		# #list_of_valid_dissolved_polygon.append(new_PolygonOnSphere)
		# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='multi_other_dissolved_polygon_ft_',valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
		# if (reference is not None):
			# new_feature.set_reconstruction_plate_id(reference)
		# reconstructed_dissolved_polygon_features.append(new_feature)
		
		# collection_of_invalid_geometries = GeometryCollection(invalid_polygons_for_later_union)
		# convex_of_invalid_geom = collection_of_invalid_geometries.convex_hull
		# if (convex_of_invalid_geom.geom_type == 'GeometryCollection'):
		# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(convex_of_invalid_geom)
		# if (finite_rotation is not None):
			# original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
			# new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
		# #list_of_valid_dissolved_polygon.append(new_PolygonOnSphere)
		# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='multi_invalid_dissolved_polygon_ft_',valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
		# if (reference is not None):
			# new_feature.set_reconstruction_plate_id(reference)
		# reconstructed_dissolved_polygon_features.append(new_feature)
	
	elif (result.geom_type == 'MultiPolygon'):
		biggest_polygon = None
		final_list_of_valid_polygons = []
		invalid_Shapley_polygons_for_later_union = []
		for polygon in result.geoms:
			if (polygon.is_valid == False):
				invalid_Shapley_polygons_for_later_union.append(polygon)
			else:
				final_list_of_valid_polygons.append(polygon)
		#NEW
		print('invalid_Shapley_polygons_for_later_union',len(invalid_Shapley_polygons_for_later_union))
		if (len(invalid_Shapley_polygons_for_later_union) > 0):
			list_of_invalid_polygon_to_created_as_sep_ft = []
			list_of_valid_dissolved_polygon = []
			count = 0
			#list_of_convex_hull_geometries = []
			for polygon in final_list_of_valid_polygons:
				polygon = polygon.convex_hull
				#list_of_convex_hull_geometries.append(polygon)
				new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
					new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
					
					# shapely_polygon = convert_polygon_to_Polygon_in_shapely(original_coords_for_PolygonOnSphere)
					# convex_hull_polygon = shapely_polygon.convex_hull
					# convex_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(convex_hull_polygon)
					# original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*convex_PolygonOnSphere
					#new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
				
				list_of_valid_dissolved_polygon.append(new_PolygonOnSphere)
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='multi_other_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				count = count + 1
			
			# collection_of_valid_geometries = GeometryCollection(list_of_convex_hull_geometries)
			# valid_convex_hull = collection_of_valid_geometries.convex_hull
			# print('valid_convex_hull',valid_convex_hull.geom_type)
			# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(valid_convex_hull)
			# if (finite_rotation is not None):
				# original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
				# new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
			# list_of_valid_dissolved_polygon.append(new_PolygonOnSphere)
			# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='multi_other_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
			# if (reference is not None):
				# new_feature.set_reconstruction_plate_id(reference)
			# reconstructed_dissolved_polygon_features.append(new_feature)
			# count = count + 1
			
			for polygon_with_issue in invalid_Shapley_polygons_for_later_union:
				polygonOnSphere_w_issue = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon_with_issue)
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*polygonOnSphere_w_issue
					polygonOnSphere_w_issue = original_coords_for_PolygonOnSphere.clone()
				valid_polygonOnSphere_w_issue = True
				for valid_polygonOnSphere in list_of_valid_dissolved_polygon:
					if (valid_polygonOnSphere.partition(polygonOnSphere_w_issue) == pygplates.PolygonOnSphere.PartitionResult.inside):
						valid_polygonOnSphere_w_issue = False
						break
				if (valid_polygonOnSphere_w_issue == True):
					list_of_invalid_polygon_to_created_as_sep_ft.append(polygonOnSphere_w_issue)
			print('len(invalid_polygons_for_later_union)',len(invalid_polygons_for_later_union))
			if (len(invalid_polygons_for_later_union) > 0):
				for ini_polygon_with_issue in invalid_polygons_for_later_union:
					valid_polygonOnSphere_w_issue = True
					if (finite_rotation is not None):
						original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*ini_polygon_with_issue
						ini_polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
					for valid_polygonOnSphere in list_of_valid_dissolved_polygon:
						if (valid_polygonOnSphere.partition(ini_polygon_with_issue) == pygplates.PolygonOnSphere.PartitionResult.inside):
							valid_polygonOnSphere_w_issue = False
							break
					if (valid_polygonOnSphere_w_issue == True):
						list_of_invalid_polygon_to_created_as_sep_ft.append(ini_polygon_with_issue)
			
			for invalid_polygon_to_be_included in list_of_invalid_polygon_to_created_as_sep_ft:
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,invalid_polygon_to_be_included,name='multi_other_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
		
		elif (len(invalid_Shapley_polygons_for_later_union) == 0):
			#print('len(invalid_polygons_for_later_union)',len(invalid_polygons_for_later_union))
			list_of_invalid_polygon_to_created_as_sep_ft = []
			list_of_valid_dissolved_polygon = []
			count = 0
			#list_of_convex_hull_geometries = []
			for polygon in final_list_of_valid_polygons:
				polygon = polygon.convex_hull
				#list_of_convex_hull_geometries.append(polygon)
				new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
				if (finite_rotation is not None):
					original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
					new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
				
					#shapely_polygon = convert_polygon_to_Polygon_in_shapely(original_coords_for_PolygonOnSphere)
					#convex_hull_polygon = shapely_polygon.convex_hull
					#convex_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(convex_hull_polygon)
					#original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*convex_PolygonOnSphere
					#new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='multi_valid_other_dissolved_polygon_ft'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				list_of_valid_dissolved_polygon.append(new_PolygonOnSphere)
				count = count + 1
				
			
			# collection_of_valid_geometries = GeometryCollection(list_of_convex_hull_geometries)
			# valid_convex_hull = collection_of_valid_geometries.convex_hull
			# print('valid_convex_hull',valid_convex_hull.geom_type)
			# new_PolygonOnSphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(valid_convex_hull)
			# if (finite_rotation is not None):
				# original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*new_PolygonOnSphere
				# new_PolygonOnSphere = original_coords_for_PolygonOnSphere.clone()
			# list_of_valid_dissolved_polygon.append(new_PolygonOnSphere)
			# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='multi_other_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
			# if (reference is not None):
				# new_feature.set_reconstruction_plate_id(reference)
			# reconstructed_dissolved_polygon_features.append(new_feature)
			# count = count + 1

			if (len(invalid_polygons_for_later_union) > 0):
				for ini_polygon_with_issue in invalid_polygons_for_later_union:
					valid_polygonOnSphere_w_issue = True
					if (finite_rotation is not None):
						original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*ini_polygon_with_issue
						ini_polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
					for valid_polygonOnSphere in list_of_valid_dissolved_polygon:
						if (valid_polygonOnSphere.partition(ini_polygon_with_issue) == pygplates.PolygonOnSphere.PartitionResult.inside):
							valid_polygonOnSphere_w_issue = False
							#print('valid_polygonOnSphere_w_issue',valid_polygonOnSphere_w_issue)
							break
					if (valid_polygonOnSphere_w_issue == True):
						list_of_invalid_polygon_to_created_as_sep_ft.append(ini_polygon_with_issue)
			#print('len(list_of_invalid_polygon_to_created_as_sep_ft)',len(list_of_invalid_polygon_to_created_as_sep_ft))
			for invalid_polygon_to_be_included in list_of_invalid_polygon_to_created_as_sep_ft:
				new_feature = pygplates.Feature.create_reconstructable_feature(featType,invalid_polygon_to_be_included,name='multi_ini_invalid_other_dissolved_polygon_ft'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
				if (reference is not None):
					new_feature.set_reconstruction_plate_id(reference)
				reconstructed_dissolved_polygon_features.append(new_feature)
				count = count + 1
	if (len(polygons_for_unary_union) == 0 and len(invalid_polygons_for_later_union) > 0):
		count = 0
		for polygon_with_issue in invalid_polygons_for_later_union:
			if (finite_rotation is not None):
				original_coords_for_PolygonOnSphere = finite_rotation.get_inverse()*polygon_with_issue
				polygon_with_issue = original_coords_for_PolygonOnSphere.clone()
			#create new Feature in pygplates
			new_feature = pygplates.Feature.create_reconstructable_feature(featType,polygon_with_issue,name='troubled_dissolved_polygon_ft_'+str(count),valid_time = (reconstruction_time,reconstruction_time - interval + 0.0500),reconstruction_plate_id = 0)
			if (reference is not None):
				new_feature.set_reconstruction_plate_id(reference)
			reconstructed_dissolved_polygon_features.append(new_feature)
			count = count + 1
	#reverse_reconstruct
	if (reference is not None):
		pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
	else:
		pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
	
	# if (reconstruction_time == 130.00):
		# outputFeatureCollection = pygplates.FeatureCollection(reconstructed_dissolved_polygon_features)
		# outputFeatureFile = 'temp_reconstructed_dissolved_polygon_features_'+str(polygon_ft.get_reconstruction_plate_id())+"_"+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
		# outputFeatureCollection.write(outputFeatureFile)
	
	return reconstructed_dissolved_polygon_features

def are_group_of_GDUs_spatially_together_at_reconstruction_time_v2_without_projection(rotation_model, list_of_polygon_GDU_fts, buffer_distance_km, reconstruction_time, time_interval, reference, modelname, yearmonthday):
	reconstructed_polygon_features = []
	final_reconstructed_polygon_features = []
	list_of_transform_polygon = []
	list_of_transform_point = []
	list_of_GDU_id = []
	list_of_left_over_GDUs = []
	list_of_used_GDUs = []
	
	#reconstruct all features to reconstruction_time
	list_of_valid_polygon_fts = [polygon_ft for polygon_ft in list_of_polygon_GDU_fts if polygon_ft.is_valid_at_time(reconstruction_time)]
	
	#found the example 17300
	# found_example_ft = False
	# for example_ft in list_of_valid_polygon_fts:
		# if (example_ft.get_reconstruction_plate_id() == 17300):
			# found_example_ft = True
	
	if (len(list_of_valid_polygon_fts) != len(list_of_polygon_GDU_fts)):
		return [False,list_of_GDU_id,None]
	
	warning_on = True
	fts = find_dissolved_polygon_features_from_polygon_features_without_projection_at_reconstruction_time(rotation_model,list_of_valid_polygon_fts,reconstruction_time,time_interval,reference,modelname,yearmonthday,warning_on)
	#fts = find_dissolved_polygon_features_from_polygon_features_with_laea_proj_at_reconstruction_time(rotation_model,list_of_valid_polygon_fts,reconstruction_time,reference,modelname,yearmonthday,warning_on)

	if (reference is not None):
		#polygon_features
		pygplates.reconstruct(fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	else:
		#polygon_features
		pygplates.reconstruct(fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
	final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
	#this is the flag - it will be turned on when we find any distance among GDU in superGDU > buffer distance 
	valid_superGDU = True
	already_processed_polygon_fts = []
	list_of_outsider = []
	for polygon_ft,polygon in final_reconstructed_polygon_features:
		ft_id_1 = polygon_ft.get_feature_id()
		#find the minimum distance - evaluate on the minimum distance
		min_distance = -1.00
		for other_polygon_ft,other_polygon in final_reconstructed_polygon_features:
			ft_id_2 = other_polygon_ft.get_feature_id()
			if (ft_id_1 != ft_id_2):
				#find the two closest between these two polygons
				distance,point_on_polygon_1,point_on_polygon_2 =  pygplates.GeometryOnSphere.distance(polygon, other_polygon, return_closest_positions=True)
				lat1,lon1 = point_on_polygon_1.to_lat_lon()
				lat2,lon2 = point_on_polygon_2.to_lat_lon()
				distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
				if ((min_distance == -1.00) or (min_distance > -1.00 and distance_in_km < min_distance)):
					min_distance = distance_in_km
				if (min_distance == 0.00):
					break
		if (min_distance > buffer_distance_km):
			valid_superGDU = False
			list_of_outsider.append(polygon_ft.get_feature_id())
	if (valid_superGDU == False):
		return [False,list_of_GDU_id,final_reconstructed_polygon_features,list_of_outsider]
	else:
		list_of_GDU_id = [ft.get_reconstruction_plate_id() for ft in list_of_valid_polygon_fts]
		return [True,list_of_GDU_id,final_reconstructed_polygon_features,list_of_outsider]

def find_convexhull_from_GDU_members_of_each_SuperGDU_within_period(rotation_model, gdu_features, supergdu_features, common_filename_for_temporary_sgdu_and_members_csv, max_reconstruction_time, min_reconstruction_time, time_interval, reference, modelname, yearmonthday):
	output_convexhull_sgdu_features = pygplates.FeatureCollection()
	reconstructed_gdu_features = []
	reconstructed_sgdu_features = []
	final_valid_sgdu_features = []
	final_valid_gdu_features = []
	valid_gdu_features = []
	unique_sgdu_names = []
	reconstruction_time = max_reconstruction_time
	list_of_already_examined_supergdu = []
	dic_of_supergdu_and_gdu_members = {}
	while (reconstruction_time >= min_reconstruction_time):
		print('reconstruction_time',reconstruction_time)
		valid_supergdu_features = [sgdu_ft for sgdu_ft in supergdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
		valid_gdu_features = [gdu_ft for gdu_ft in gdu_features if gdu_ft.is_valid_at_time(reconstruction_time)]
		final_valid_sgdu_features[:] = []
		unique_sgdu_names[:] = []
		reconstructed_sgdu_features[:] = []
		reconstructed_gdu_features[:] = []
		for sgdu_ft in valid_supergdu_features:
			sgdu_name = sgdu_ft.get_name()
			
			# if (sgdu_name not in list_of_already_examined_supergdu):
				# unique_sgdu_names.append(sgdu_name)
				# final_valid_sgdu_features.append(sgdu_ft)
				# list_of_already_examined_supergdu.append(sgdu_name)
			
			if (sgdu_name not in list_of_already_examined_supergdu):
				unique_sgdu_names.append(sgdu_name)
				list_of_already_examined_supergdu.append(sgdu_name)
			
		#old way using gdu features 
		#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
		# temporary_sgdu_and_member_csv_at_time = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
		# temp_sgdu_and_gdu_df = pd.read_csv(temporary_sgdu_and_member_csv_at_time, delimiter = ';', header = 0)
		# for valid_supergdu_ft in final_valid_sgdu_features:
			# final_valid_gdu_features[:] = []
			# sgdu_begin,sgdu_end = valid_supergdu_ft.get_valid_time()
			# sgdu_name = valid_supergdu_ft.get_name()
			# print('sgdu_name',sgdu_name)
			# initial_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(sgdu_begin))
			# #;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			# initial_df = pd.read_csv(initial_sgdu_and_members_csv, delimiter = ';', header = 0)
			# if (sgdu_name not in dic_of_supergdu_and_gdu_members):
				# # unique_sgdus = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['repGDUID'] == valid_supergdu_ft.get_reconstruction_plate_id())|(temp_sgdu_and_gdu_df['GDUID'] == valid_supergdu_ft.get_reconstruction_plate_id()),'SGDUID'].unique()
				# records_of_gdu_members = []
				# # for sgdu in unique_sgdus:
					# # temp_members = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['SGDUID'] == sgdu),'GDUID'].unique()
					# # for temp_mem in temp_members:
						# # if (temp_mem not in records_of_gdu_members):
							# # records_of_gdu_members.append(temp_mem)
				# temp_members = initial_df.loc[(initial_df['SGDUID'] == int(sgdu_name)),'GDUID'].unique()
				# for temp_mem in temp_members:
					# if (temp_mem not in records_of_gdu_members):
						# records_of_gdu_members.append(temp_mem)
				# dic_of_supergdu_and_gdu_members[sgdu_name] = records_of_gdu_members
			# records_of_gduids = dic_of_supergdu_and_gdu_members[sgdu_name]
			# for gduid in records_of_gduids:
				# for gdu_ft in valid_gdu_features:
					# if (gdu_ft.get_reconstruction_plate_id() == gduid):
						# final_valid_gdu_features.append(gdu_ft)
			
			# list_of_same_sgdu_features = []
			
			# if (reference is not None):
				# pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_sgdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				# #pygplates.reconstruct(final_valid_gdu_features,rotation_model,reconstructed_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# else:
				# pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_sgdu_features,reconstruction_time,group_with_feature = True)
				# #pygplates.reconstruct(final_valid_gdu_features,rotation_model,reconstructed_gdu_features,reconstruction_time,group_with_feature = True)
			# final_reconstructed_supergdu_features = supporting_sgdu.find_final_reconstructed_geometries(reconstructed_sgdu_features, pygplates.PolygonOnSphere)
			# #final_reconstructed_gdu_features = find_final_reconstructed_geometries(reconstructed_gdu_features, pygplates.PolygonOnSphere)
			# warning_on = False
			# print('number of gdu features for convex_hull', len(final_valid_gdu_features))
			# # if (sgdu_name == '79757'):
				# # pygplates.FeatureCollection(final_valid_gdu_features).write("gdu_features_for_sgdu_797575.shp")
				# # exit()
				
				
			# convex_hull_sgdu_feats = find_convexhull_for_group_of_gdu_members_of_SGDU(rotation_model, final_valid_gdu_features, reconstruction_time, time_interval, reference, modelname, yearmonthday, warning_on)
			# # if (sgdu_name == '79757'):
				# # exit()
			# #set the reconstruction plate id of the SuperGDU with the most stable member GDU id
			# for convex_hull_ft in convex_hull_sgdu_feats:
				# convex_hull_ft.set_reconstruction_plate_id(valid_supergdu_ft.get_reconstruction_plate_id())
				# convex_hull_ft.set_valid_time(sgdu_begin,sgdu_end)
				# convex_hull_ft.set_name(sgdu_name)
				# if (reference is not None):
					# pygplates.reverse_reconstruct(convex_hull_ft,rotation_model,reconstruction_time,reference)
				# else:
					# pygplates.reverse_reconstruct(convex_hull_ft,rotation_model,reconstruction_time)
				# output_convexhull_sgdu_features.add(convex_hull_ft)
		
		#new way using sgdu features 
		for sgdu_name in unique_sgdu_names:
			sgdu_features_w_same_name = [sgdu_ft for sgdu_ft in valid_supergdu_features if (sgdu_ft.get_name() == sgdu_name)]
			warning_on = False
			print('number of gdu features for convex_hull', len(sgdu_features_w_same_name))
			# if (sgdu_name == '70034'):
				# pygplates.FeatureCollection(sgdu_features_w_same_name).write("gdu_features_for_sgdu_70034.shp")
				# exit()
				
				
			convex_hull_sgdu_feats = find_convexhull_for_group_of_gdu_members_of_SGDU(rotation_model, sgdu_features_w_same_name, reconstruction_time, time_interval, reference, modelname, yearmonthday, warning_on)
			# if (sgdu_name == '79757'):
				# exit()
			valid_supergdu_ft = sgdu_features_w_same_name[0]
			sgdu_begin,sgdu_end = valid_supergdu_ft.get_valid_time()
			sgdu_name = valid_supergdu_ft.get_name()
			#set the reconstruction plate id of the SuperGDU with the most stable member GDU id
			for convex_hull_ft in convex_hull_sgdu_feats:
				convex_hull_ft.set_reconstruction_plate_id(valid_supergdu_ft.get_reconstruction_plate_id())
				convex_hull_ft.set_valid_time(sgdu_begin,sgdu_end)
				convex_hull_ft.set_name(sgdu_name)
				if (reference is not None):
					pygplates.reverse_reconstruct(convex_hull_ft,rotation_model,reconstruction_time,reference)
				else:
					pygplates.reverse_reconstruct(convex_hull_ft,rotation_model,reconstruction_time)
				output_convexhull_sgdu_features.add(convex_hull_ft)
		
		reconstruction_time = reconstruction_time - time_interval
	output_convexhull_sgdu_features.write('convexhull_from_GDU_members_of_each_SuperGDU_within_period_max_'+str(max_reconstruction_time)+'_'+str(min_reconstruction_time)+'_'+modelname+'.shp')

if __name__ == '__main__':
	
	supergdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	#sgdu_features = pygplates.FeatureCollection(supergdu_features_file)
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_model = pygplates.RotationModel(rotation_file)
	gdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	#gdu_features = pygplates.FeatureCollection(gdu_features_file)
	
	sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	gdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	gdu_features = pygplates.FeatureCollection(gdu_features_file)
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	
	common_filename_for_temporary_sgdu_and_members_csv = r"supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	max_reconstruction_time = 3420.0
	min_reconstruction_time = 0.0
	time_interval = 5.00
	reference = 700
	modelname = 'test_8_PalaeoPlatesendJan2023'
	yearmonthday = '20231219'
	find_convexhull_from_GDU_members_of_each_SuperGDU_within_period(rotation_model, gdu_features, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, max_reconstruction_time, min_reconstruction_time, time_interval, reference, modelname, yearmonthday)
