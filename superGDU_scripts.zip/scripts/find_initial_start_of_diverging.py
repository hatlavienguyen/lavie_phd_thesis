import pandas as pd
import os 

def find_initial_start_of_diverging(sgdu_history_csv, common_filename_for_sgdu_and_gdu_members_csv, small_time_interval_to_define_supergdu, modelname, yearmonthday):
	#framework_dic = {'origin_lv':[],'SGDU':[],'parent':[],'from_time':[],'to_time':[],'repGDUID':[]}
	sgdu_history_df = pd.read_csv(sgdu_history_csv, delimiter=',', header = 0)
	output_rift_dic = {'SGDU':[],'start_div':[],'repGDUID':[]}
	#find the time when rifting first starts.
	#Get the unique values for parent: unique_parent_sguds
	unique_parent_sguds = sgdu_history_df['parent'].unique()
	#Iterate through unique_parent_sgdus. 
	#	For each unique_parent in unique_parent_sgdus, find records_of_children that contains these attributes ['SGDU','from_time','to_time','repGDUID']
	#		if there are more than one UNIQUE children SGDU, then 'from_time' value is the start of rifting. 
	for unique_parent in unique_parent_sguds:
		records_of_children = sgdu_history_df.loc[sgdu_history_df['parent'] == unique_parent, 'SGDU']
		unique_sgdu_children = records_of_children.unique()
		if (len(unique_sgdu_children) > 1):
			#divergence
			already_recorded_sgdu = []
			records_of_parents = sgdu_history_df.loc[sgdu_history_df['SGDU'] == unique_parent, ['to_time','repGDUID']]
			for tuple in records_of_parents.itertuples(index=False,name=None):
				to_time,repgduid = tuple
				if (repgduid not in already_recorded_sgdu):
					already_recorded_sgdu.append(repgduid)
					output_rift_dic['SGDU'].append(unique_parent)
					output_rift_dic['start_div'].append(to_time)
					output_rift_dic['repGDUID'].append(repgduid)
	
	output_dataframe = pd.DataFrame.from_dict(output_rift_dic)
	filename = 'start_time_of_div_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)

def main():
	#supergdu_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/final_supergdu_feats_3420.0_0.0_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.shp"
	#supergdu_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.shp"
	#supergdu_features = pygplates.FeatureCollection(supergdu_file)
	#begin_reconstruction_time = 3420.0
	#end_reconstruction_time = 0.0
	#time_interval = 5.00
	common_filename_for_sgdu_and_gdu_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	#common_filename_for_sgdu_and_gdu_members_csv = r"C:\Users\lavie\Desktop\Research\Fall2022\line_topology_qgis_geopandas_shapely\supergdu_and_members\supergdu_and_members_gdu_at_{time}_for_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.csv"
	modelname = "test_14_PalaeoPlatesJan2023"
	yearmonthday = "20231006"
	sgdu_history_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/sgdu_history_for__test_11_PalaeoPlatesJan2023_from_20230425_20231005.csv"
	small_time_interval_to_define_supergdu = 5.00
	find_initial_start_of_diverging(sgdu_history_csv, common_filename_for_sgdu_and_gdu_members_csv, small_time_interval_to_define_supergdu, modelname, yearmonthday)
if __name__=='__main__':
	main()
