#import os
#import csv
import math
#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
#sys.path.insert(1,r'C:\Users\hon686\Research\pygplates_0.36.0_py38_win64\pygplates')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy
# import matplotlib.pyplot as plt
# from shapely.errors import TopologicalError
# from shapely.geometry import Point, Polygon, LineString, MultiPoint, MultiPolygon, LinearRing
# from shapely.ops import unary_union, transform, cascaded_union, polygonize, polygonize_full, linemerge, triangulate 
# from functools import partial
# from shapely.validation import explain_validity
# import pyproj

def final_superGDU_id_with_gdu_members_id(name_of_supergdu_and_members_csv, name_of_summarize_dissolved_polygon_features_shp, from_time, to_time, time_interval, modelname, yearmonthday): 
	#name_of_supergdu_and_members_csv has to be a string with the exact format that we can easily substitue time for the filename 
	#name_of_supergdu_and_members_csv = '{time}.csv'
	conn = None 
	dic = {}
	end_supergdus_dic = {}
	final_supergdus_dic = {'SGDU':[],'from_time':[],'to_time':[]}
	already_included_sgdu = []
	already_included_in_dic = []
	#read the csv file with value of input from_time (the maximum begin age for reconstruction)
	#get the super_gdu_id, to_time and represent_gdu_id
	reconstruction_time = from_time
	while (reconstruction_time >= to_time):
		print("reconstruction_time",reconstruction_time)
		if (reconstruction_time < from_time):
			older_age = reconstruction_time + time_interval
			filename = name_of_supergdu_and_members_csv.format(time = str(older_age))
			df_old = pd.read_csv(filename, delimiter = ';', header = 0) 
			#'from_time', 'to_time', 'SGDUID', 'GDUID', 'buffer_distance_km', 'repGDUID'
			unique_old_sgdu = df_old['SGDUID'].unique()
			old_shp = name_of_summarize_dissolved_polygon_features_shp.format(time=str(older_age))
			old_featurecollection = pygplates.FeatureCollection(old_shp)
			
				
			yng_age = reconstruction_time
			filename = name_of_supergdu_and_members_csv.format(time = str(yng_age))
			df_yng = pd.read_csv(filename, delimiter = ';', header = 0)
			#'from_time', 'to_time', 'SGDUID', 'GDUID', 'buffer_distance_km', 'repGDUID'
			unique_yng_sgdu = df_yng['SGDUID'].unique()
			yng_shp = name_of_summarize_dissolved_polygon_features_shp.format(time=str(yng_age))
			yng_featurecollection = pygplates.FeatureCollection(yng_shp)
			
			dic_old_fts = {}
			dic_yng_fts = {}
			for old_ft in old_featurecollection:
				if (old_ft.get_name() not in dic_old_fts):
					dic_old_fts[old_ft.get_name()] = [old_ft]
				else:
					dic_old_fts[old_ft.get_name()].append(old_ft)
			for yng_ft in yng_featurecollection:
				if (yng_ft.get_name() not in dic_yng_fts):
					dic_yng_fts[yng_ft.get_name()] = [yng_ft]
				else:
					dic_yng_fts[yng_ft.get_name()].append(yng_ft)
			
			for old_sgdu in unique_old_sgdu:
				records_of_members_for_old_sgdu = df_old.loc[df_old['SGDUID'] == old_sgdu, 'GDUID']
				sort_old_sgdu = records_of_members_for_old_sgdu.sort_values()
				#arrary_of_sort_old_sgdu = sort_old_sgdu.to_numpy()
				for yng_sgdu in unique_yng_sgdu:
					records_of_members_for_yng_sgdu = df_yng.loc[df_yng['SGDUID'] == yng_sgdu, 'GDUID']
					sort_yng_sgdu = records_of_members_for_yng_sgdu.sort_values()
					#arrary_of_sort_yng_sgdu = sort_yng_sgdu.to_numpy()
					result = sort_old_sgdu.equals(sort_yng_sgdu)
					#result = numpy.array_equal(arrary_of_sort_old_sgdu,arrary_of_sort_yng_sgdu)
					if (result == True):
						list_of_old_fts = dic_old_fts[str(old_sgdu)]
						list_of_yng_fts = dic_yng_fts[str(yng_sgdu)]
						if (len(list_of_old_fts) == len(list_of_yng_fts)):
							is_diff_sgdu = False
							for old_ft in list_of_old_fts:
								old_geom = old_ft.get_geometry()
								found_similar_geom=False
								for yng_ft in list_of_yng_fts:
									yng_geom = yng_ft.get_geometry()
									if (yng_geom == old_geom):
										found_similar_geom = True
										break
								if (found_similar_geom == False):
									is_diff_sgdu = True
									break
							if (is_diff_sgdu == False):
								dic[str(old_sgdu)] = {str(yng_sgdu):(older_age,yng_age+0.100)}
						#if (reconstruction_time == to_time == 0.00):
						#	already_included_in_dic.append(yng_sgdu)
				if (str(old_sgdu) not in dic):
					end_supergdus_dic[str(old_sgdu)]= (older_age,yng_age+0.100)
			print('older_age',older_age)
			print('yng_age',yng_age)
			
			if (reconstruction_time == to_time == 0.00):
				for yng_sgdu in unique_yng_sgdu:
					if (yng_sgdu not in already_included_in_dic):
						end_supergdus_dic[str(yng_sgdu)]= (yng_age,yng_age)
		#update reconstruction_time
		reconstruction_time = reconstruction_time - time_interval
		#clear up dataframe
		df_old = None
		df_yng = None

	order_of_output = 1
	for current_sgdu in dic:
		current_record = None
		temp_list = None
		current_yng_sgdu = None
		current_from_time, current_to_time = -1.00,-1.00
		oldest_from_time = current_from_time
		# if (current_sgdu not in already_included_sgdu):
			# already_included_sgdu.append(current_sgdu)
			# current_record = dic[current_sgdu]
			# temp_list = list(dic[current_sgdu].keys())
			# current_yng_sgdu = temp_list[0]
			# current_from_time, current_to_time = dic[current_sgdu][current_yng_sgdu]
			# oldest_from_time = current_from_time
			# while (current_yng_sgdu is not None):
				# already_included_sgdu.append(current_yng_sgdu)
				# if (current_yng_sgdu in end_supergdus_dic):
					# _,current_to_time = end_supergdus_dic[current_yng_sgdu]
					# break
				# if (current_yng_sgdu in dic):
					# previous_yng_sgdu = current_yng_sgdu
					# current_record = dic[current_yng_sgdu]
					# temp_list = list(dic[current_yng_sgdu].keys())
					# current_yng_sgdu = temp_list[0]
					# new_from_time, new_to_time = dic[previous_yng_sgdu][current_yng_sgdu]
					# if (new_from_time > oldest_from_time):
						# oldest_from_time = new_from_time
					# if (new_to_time < current_to_time):
						# current_to_time = new_to_time
				# else:
					# current_yng_sgdu = None
		
		if (current_sgdu not in already_included_sgdu):
			already_included_sgdu.append(current_sgdu)
			list_of_same_sgdus = []
			current_record = dic[current_sgdu]
			temp_list = list(dic[current_sgdu].keys())
			current_yng_sgdu = temp_list[0]
			current_from_time, current_to_time = dic[current_sgdu][current_yng_sgdu]
			
			# if (current_to_time == 0.00):
				# list_of_same_sgdus.append((current_from_time, current_to_time, current_sgdu))
				# already_included_sgdu.append(current_yng_sgdu)
				# current_yng_sgdu = None
			# else:
				# list_of_same_sgdus.append((current_from_time, current_to_time+0.100, current_sgdu))
			
			# if (current_from_time == 0.00 and current_to_time == 0.00):
				# list_of_same_sgdus.append((current_from_time, current_to_time, current_sgdu))
				# already_included_sgdu.append(current_yng_sgdu)
				# current_yng_sgdu = None
			# else:
				# list_of_same_sgdus.append((current_from_time, current_to_time+0.100, current_sgdu))
			
			list_of_same_sgdus.append((current_from_time, current_to_time, current_sgdu))
			
			while (current_yng_sgdu is not None):
				already_included_sgdu.append(current_yng_sgdu)
				if (current_yng_sgdu in end_supergdus_dic):
					current_from_time, current_to_time = end_supergdus_dic[current_yng_sgdu]
					# if (current_to_time == 0.00):
						# list_of_same_sgdus.append((current_from_time, current_to_time, current_yng_sgdu))
					# else:
						# list_of_same_sgdus.append((current_from_time, current_to_time+0.100, current_yng_sgdu))
					list_of_same_sgdus.append((current_from_time, current_to_time, current_yng_sgdu))
					break
				if (current_yng_sgdu in dic):
					previous_yng_sgdu = current_yng_sgdu
					current_record = dic[current_yng_sgdu]
					temp_list = list(dic[current_yng_sgdu].keys())
					current_yng_sgdu = temp_list[0]
					current_from_time, current_to_time = dic[previous_yng_sgdu][current_yng_sgdu]
					
					list_of_same_sgdus.append((current_from_time, current_to_time, previous_yng_sgdu))
				else:
					current_yng_sgdu = None
			#sort list based on from_time in the tuple 
			list_of_same_sgdus.sort(reverse = True)
			oldest_from_time, youngest_to_time, final_oldest_sgdu = list_of_same_sgdus[0]
			final_supergdus_dic['SGDU'].append(int(final_oldest_sgdu))
			final_supergdus_dic['from_time'].append(oldest_from_time)
			_, youngest_to_time, _= list_of_same_sgdus[-1]
			final_supergdus_dic['to_time'].append(youngest_to_time)
	
	for key in end_supergdus_dic:
		if (key not in already_included_sgdu):
			final_oldest_sgdu = int(key)
			oldest_from_time, youngest_to_time = end_supergdus_dic[key]
			final_supergdus_dic['SGDU'].append(int(final_oldest_sgdu))
			final_supergdus_dic['from_time'].append(oldest_from_time)
			final_supergdus_dic['to_time'].append(youngest_to_time)
	
	output_df = pd.DataFrame.from_dict(final_supergdus_dic)
	output_df.to_csv('final_supergdus_from_'+str(from_time)+'_'+str(to_time)+'_for_'+modelname+'_'+yearmonthday+'.csv',sep=';',header=True)

def modified_valid_age_of_temporary_SuperGDU_fts_to_create_final_SuperGDU_fts(final_supergdu_csv, common_name_for_temporary_sgdu_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	output_sgdu_features = pygplates.FeatureCollection()
	supergdu_df = pd.read_csv(final_supergdu_csv, header = 0, delimiter = ';')
	#;SGDU;from_time;to_time
	for row in supergdu_df.itertuples(index = False):
		SGDU_int = row[1]
		from_time = float(row[2])
		to_time = float(row[3])
		SGDU_str = str(SGDU_int)
		final_name_for_temporary_sgdu_shp = common_name_for_temporary_sgdu_shp.format(time = str(from_time))
		temp_sgdu_fts = pygplates.FeatureCollection(final_name_for_temporary_sgdu_shp)
		found_sgdu_ft = None
		for ft in temp_sgdu_fts:
			if (ft.get_name() == SGDU_str):
				found_sgdu_ft = ft
				#break 
				#current_from_time, current_to_time = found_sgdu_ft.get_valid_time()
				#print("current_from_time, current_to_time",current_from_time, current_to_time,"to_time",to_time)
				found_sgdu_ft.set_valid_time(from_time, to_time)
				output_sgdu_features.add(found_sgdu_ft)
		if (found_sgdu_ft is None):
			print("Error found_sgdu_ft is None")
			print("final_name_for_temporary_sgdu_shp:",final_name_for_temporary_sgdu_shp)
			print("from_time", from_time, "to_time", to_time)
			print("SGDU_str",SGDU_str)
			exit()
		
			# if (to_time > 0.00):
				# print("Error found_sgdu_ft is None")
				# print("final_name_for_temporary_sgdu_shp:",final_name_for_temporary_sgdu_shp)
				# print("from_time", from_time, "to_time", to_time)
				# print("SGDU_str",SGDU_str)
				# exit()
			# else:
				# secondary_final_name_for_temporary_sgdu_shp = common_name_for_temporary_sgdu_shp.format(time = str(to_time))
				# temp_sgdu_fts = pygplates.FeatureCollection(secondary_final_name_for_temporary_sgdu_shp)
				# found_sgdu_ft = None
				# for ft in temp_sgdu_fts:
					# if (ft.get_name() == SGDU_str):
						# found_sgdu_ft = ft
						# #break 
						# #current_from_time, current_to_time = found_sgdu_ft.get_valid_time()
						# #print("current_from_time, current_to_time",current_from_time, current_to_time,"to_time",to_time)
						# #if (current_from_time == to_time and current_to_time == to_time and current_from_time ==0.00):
						# #	current_from_time = time_interval + current_from_time
						# found_sgdu_ft.set_valid_time(from_time, to_time)
						# output_sgdu_features.add(found_sgdu_ft)
	output_sgdu_features.write("final_supergdu_feats_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")

	

def main():
	name_of_supergdu_and_members_csv = r"supergdu_and_members_gdu_at_{time}_for_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230414.csv"
	name_of_summarize_dissolved_polygon_features_shp = r"dissolved_polygon_fts_from_{time}_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230414.shp"
	#name_of_supergdu_and_members_csv = r"supergdu_and_members_gdu_at_{time}_for_LiLiuErnst2023_W_20230404.csv"
	#name_of_summarize_dissolved_polygon_features_shp = r"dissolved_polygon_fts_from_{time}_LiLiuErnst2023_W_20230404.shp"
	from_time = 3420.0
	to_time = 0.0
	time_interval = 5.0
	modelname = 'QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km'
	#modelname = 'LiLiuErnst2023'
	yearmonthday = '20230414'
	final_superGDU_id_with_gdu_members_id(name_of_supergdu_and_members_csv, name_of_summarize_dissolved_polygon_features_shp, from_time, to_time, time_interval, modelname, yearmonthday)
	
	final_supergdu_csv = r"final_supergdus_from_3420.0_0.0_for_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230414.csv"
	common_name_for_temporary_sgdu_shp = r"dissolved_polygon_fts_from_{time}_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230414.shp"
	modified_valid_age_of_temporary_SuperGDU_fts_to_create_final_SuperGDU_fts(final_supergdu_csv, common_name_for_temporary_sgdu_shp, from_time, to_time, time_interval, modelname, yearmonthday)

if __name__=='__main__':
	main()
			


