#import os
import csv
import math
#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.errors import TopologicalError
from shapely.geometry import Point, Polygon, LineString, MultiPoint, MultiPolygon, LinearRing
from shapely.ops import unary_union, transform, cascaded_union, polygonize, polygonize_full, linemerge, triangulate 
from functools import partial
from shapely.validation import explain_validity
import pyproj

def study_rotation_of_member_with_the_anchor(rotation_model,member_GDU_ID,from_time,to_time,reference):
	#Get the rotation of "other plate" from other_plate_ID from previous_reconstruction_time which is reconstruction_time + interval to reconstruction_time
	equivalent_stage_rotation_ref_plate = None
	if (reference is None):
		equivalent_stage_rotation_ref_plate = rotation_model.get_rotation(float(to_time),member_GDU_ID,float(from_time),anchor_plate_id = 0,use_identity_for_missing_plate_ids = False)
	else:
		equivalent_stage_rotation_ref_plate = rotation_model.get_rotation(float(to_time),member_GDU_ID,float(from_time),anchor_plate_id = reference,use_identity_for_missing_plate_ids = False)
	if (equivalent_stage_rotation_ref_plate is not None):
		pole_latitude, pole_longitude, angle_degrees = equivalent_stage_rotation_ref_plate.get_lat_lon_euler_pole_and_angle_degrees()
		return pole_latitude, pole_longitude, angle_degrees
	else:
		pole_latitude, pole_longitude, angle_degrees = None, None, None 
		return pole_latitude, pole_longitude, angle_degrees
		
def study_equivalent_rotation_of_each_member_with_anchor(rotation_model,GDU_fts_collection,from_time,to_time,interval,reference,number_of_decimals,modelname,yearmonthday):
	reconstruction_time = from_time
	result = []
	conn = None 
	#insert multiple records to the table
	#sql = """ INSERT INTO equivalent_stage_rotation (from_time, to_time, member_GDU_ID, anchor_plate_id, pole_latitude, pole_longitude, angle_degrees) VALUES(%s, %s, %s, %s, %s, %s, %s)"""
	while (reconstruction_time >= to_time):
		list_of_members_GDU_IDs = []
		for gdu_ft in GDU_fts_collection:
			if (gdu_ft.is_valid_at_time(reconstruction_time)):
				GDU_id = gdu_ft.get_reconstruction_plate_id()
				if GDU_id not in list_of_members_GDU_IDs:
					list_of_members_GDU_IDs.append(GDU_id)
		for member_GDU_ID in list_of_members_GDU_IDs:
			#get the rotation relative to the anchor_plate_id
			pole_latitude, pole_longitude, angle_degrees = study_rotation_of_member_with_the_anchor(rotation_model,member_GDU_ID,reconstruction_time + interval,reconstruction_time,reference)
			anchor_plate_id = 0
			if (reference is not None):
				anchor_plate_id = reference
			if (pole_latitude is not None):
				pole_latitude = round(pole_latitude,number_of_decimals)
			if (pole_longitude is not None):
				pole_longitude = round(pole_longitude,number_of_decimals)
			if (angle_degrees is not None):
				angle_degrees = round(angle_degrees,number_of_decimals)
			result.append((reconstruction_time + interval, reconstruction_time, member_GDU_ID, anchor_plate_id, pole_latitude, pole_longitude,angle_degrees))
		#update_reconstruction_time
		reconstruction_time = reconstruction_time - interval
	output_df = pd.DataFrame(result, columns = ['from_time', 'to_time', 'member_gdu_id', 'anchor_plate_id', 'pole_latitude', 'pole_longitude', 'angle_degrees'])
	output_df.to_csv('equivalent_rot_of_each_gdu_with_anchor_'+modelname+'_'+yearmonthday+'.csv',sep=';',header=True)

def main():
	rotation_file = r"../T_Rot_Model_PalaeoPlates_20240205.grot"
	#rotation_file = r r"EDRG_90W_2000-540Ma.rot"
	rotation_model = pygplates.RotationModel(rotation_file)
	#GDU_fts_file = r"../all_gdu_features_w_all_valid_attributes_PalaeoPlatesFeb2024_20240214.shp"
	GDU_fts_file = r"../ASI_cont_gdu_features_w_all_valid_attributes_PalaeoPlatesFeb2024_20240214.shp"
	GDU_fts_collection = pygplates.FeatureCollection(GDU_fts_file)
	print ("Here is rotation_file")
	print (rotation_file)
	print ("Here is GDU_fts_file")
	print (GDU_fts_file)
	# list_of_members_GDU_IDs = []
	# for GDU_ft in GDU_fts_collection:
		# GDU_id = GDU_ft.get_reconstruction_plate_id()
		# if GDU_id not in list_of_members_GDU_IDs:
			# list_of_members_GDU_IDs.append(GDU_id)
	from_time = 3000.00
	to_time = 0.00
	interval = 5.00
	reference = 700
	# from_time = 2000.00
	# to_time = 540.00
	# interval = 5.00
	# reference = 0
	number_of_decimals = 3
	modelname = "ASI_PalaeoPlatesFeb2024"
	yearmonthday = "20240829"
	#study_equivalent_rotation_of_each_member_with_anchor(rotation_model,list_of_members_GDU_IDs,from_time,to_time,interval,reference,number_of_decimals,modelname,yearmonthday)
	study_equivalent_rotation_of_each_member_with_anchor(rotation_model,GDU_fts_collection,from_time,to_time,interval,reference,number_of_decimals,modelname,yearmonthday)
	
if __name__== '__main__':
	main()
