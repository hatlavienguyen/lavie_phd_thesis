import pandas as pd
#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import numpy as np

def find_end_of_converging(final_sgdu_features_file, sgdu_history_csv, common_filename_for_sgdu_and_gdu_members_csv, small_time_interval_to_define_supergdu, begin_reconstruction_time, end_reconstruction_time, modelname, yearmonthday):
	final_sgdu_features_collection = pygplates.FeatureCollection(final_sgdu_features_file)
	sgdu_history_df = pd.read_csv(sgdu_history_csv, delimiter = ',', header = 0)
	#find the time when converging first starts
	output_conv_dic = {'SGDU':[],'end_conv':[],'repGDUID':[]}
	framework_dic = {'origin_lv':[],'SGDU':[],'parent':[],'from_time':[],'to_time':[],'repGDUID':[]}
	#Get the unique values for SGDU: unique_sgdus
	#unique_sgdus = sgdu_history_df['SGDU'].unique()
	unique_sgdus = sgdu_history_df.loc[(sgdu_history_df['from_time']<=begin_reconstruction_time) & (sgdu_history_df['to_time']>=end_reconstruction_time),'SGDU'].unique()
	#Iterate through unique_sgdus.
	for unique_child in unique_sgdus:
		#debug
		if (unique_child == 78601):
			print('unique_child',unique_child)
		records_of_sgdus = sgdu_history_df.loc[(sgdu_history_df['SGDU'] == unique_child) & (sgdu_history_df['parent'] != -1), ['from_time','parent','origin_lv','to_time','repGDUID']]
		already_recorded_sgdu = []
		for tuple in records_of_sgdus.itertuples(index = False,name = None):
			from_time, parent, lvl, to_time, unique_child_repGDUID = tuple
			if (parent == 78543 and unique_child == 78601):
				print('from_time, parent, lvl, to_time, unique_child_repGDUID')
				print(from_time, parent, lvl, to_time, unique_child_repGDUID)
				print('parent not in already_recorded_sgdu',parent not in already_recorded_sgdu)
				
			if (parent not in already_recorded_sgdu):
				# filename_prev_time = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(from_time + small_time_interval_to_define_supergdu))
				# #;from_time;to_time;SGDUID;GDUID;POLYGID;buffer_distance_km;repGDUID
				# temp_sgdu_gdu_df = pd.read_csv(filename_prev_time,header=0,delimiter=';')
				already_recorded_sgdu.append(parent)
				#check to make sure this will be convergence
				children_of_sgdu = sgdu_history_df.loc[(sgdu_history_df['parent'] == parent), 'SGDU'].unique()
				#debug
				if (parent == 78543):
					print('children_of_sgdu',children_of_sgdu)
				filename_current_time = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(from_time))
				temp_sgdu_gdu_current_time_df = pd.read_csv(filename_current_time, header = 0, delimiter = ';')
				is_potentially_convergence = False
				if (len(children_of_sgdu) > 1):
					#not convergence --- take a new child SGDU i.e. goes back to the outermost for-loop of unique_sgdus.
					#....FIX THIS...because it can be convergence too. Use examples of SGDUs:80433 and 80418 at 75Ma
					#obtain the from_time of the parent sgdu to find the sgdu_and_members_gdu_csv_file
					records_of_from_time_for_parent = sgdu_history_df.loc[(sgdu_history_df['SGDU'] == parent), 'from_time'].unique()
					if (len(records_of_from_time_for_parent) != 1):
						print("Error len(records_of_from_time_for_parent) != 1")
						print("len(records_of_from_time_for_parent)",len(records_of_from_time_for_parent))
						print("parent",parent)
						print("records_of_from_time_for_parent",records_of_from_time_for_parent)
						print("from_time, parent, lvl, to_time, unique_child_repGDUID")
						print(from_time, parent, lvl, to_time, unique_child_repGDUID)
						exit()
					from_time_for_parent = records_of_from_time_for_parent[0]
					#load the sgdu and members gdu for the parent sgdu
					filename_for_parent_sgdu = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(from_time_for_parent))
					parent_sgdu_df = pd.read_csv(filename_for_parent_sgdu, header = 0, delimiter = ';')
					children_of_sgdu_containing_parent = parent_sgdu_df.loc[(parent_sgdu_df['SGDUID'] == parent), 'GDUID'].unique()
					#potential sgdu after convergence
					sgdu_containing_repGDU = temp_sgdu_gdu_current_time_df.loc[(temp_sgdu_gdu_current_time_df['GDUID'] == unique_child_repGDUID), 'SGDUID'].unique()
					potential_sgdus_after_convergence = np.intersect1d(sgdu_containing_repGDU,children_of_sgdu)
					if (len(potential_sgdus_after_convergence) > 0):
						#iterate through the array children_of_sgdu to evaluate each child
						for child_sgdu in potential_sgdus_after_convergence:
							#find the child which contains unique_child_repGDUID as one of the member
							children_of_sgdu_containing_repGDU = temp_sgdu_gdu_current_time_df.loc[(temp_sgdu_gdu_current_time_df['SGDUID'] == child_sgdu), 'GDUID'].unique()
							#debug
							if (parent == 78543 and child_sgdu == 78601):
								print('len(children_of_sgdu_containing_parent)',len(children_of_sgdu_containing_parent))
								print('len(children_of_sgdu_containing_repGDU)',len(children_of_sgdu_containing_repGDU))
								#exit()
							if (len(children_of_sgdu_containing_parent) <= len(children_of_sgdu_containing_repGDU)):
								#if the child containing unqiue_child_repGDUID has more GDU members than the parent, then this child sgdu is potentially a result of the convergence
								is_potentially_convergence = True
								break
					if (is_potentially_convergence == False):
						continue
				if ((len(children_of_sgdu) == 1) or (is_potentially_convergence == True)):
					records_of_older_sgdu = sgdu_history_df.loc[(sgdu_history_df['SGDU'] != parent) & (sgdu_history_df['to_time'] > from_time), ['from_time','to_time','SGDU','repGDUID']]
					records_of_parent_sgdu = sgdu_history_df.loc[(sgdu_history_df['SGDU'] == parent) & (sgdu_history_df['to_time'] > from_time), ['to_time','repGDUID']]
					#if (parent == 69672 and unique_child == 69716):
					#	print('records_of_older_sgdu',records_of_older_sgdu)
					if (len(records_of_older_sgdu) > 0):
						filename_prev_time = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(from_time + small_time_interval_to_define_supergdu))
						#;from_time;to_time;SGDUID;GDUID;POLYGID;buffer_distance_km;repGDUID
						temp_sgdu_gdu_df = pd.read_csv(filename_prev_time, header = 0, delimiter = ';')
						sorted_ancestors = records_of_older_sgdu.sort_values('to_time')
						minimum_to_time = -1.00
						list_to_search_potential_parents = []
						for result in sorted_ancestors.itertuples(index = False, name = None):
							#'from_time','to_time','SGDU','repGDUID'
							#ancestor_from_time = result[0]
							ancestor_to_time = result[1]
							if (minimum_to_time == -1.00):
								minimum_to_time = ancestor_to_time
							if (ancestor_to_time <= minimum_to_time):
								# ancestor_sgdu = result[2]
								# ancestor_repgdu = result[3]
								list_to_search_potential_parents.append(result)
							else:
								break
						if (len(list_to_search_potential_parents) > 0):
							found_additional_parents = False
						
							for result in list_to_search_potential_parents:
								ancestor_from_time = result[0]
								ancestor_to_time = result[1]
								ancestor_sgdu = result[2]
								ancestor_repgdu = result[3]
								if (parent == 78053 and unique_child == 78105):
									print('ancestor_from_time','ancestor_to_time','ancestor_sgdu','ancestor_repgdu')
									print(ancestor_from_time,ancestor_to_time,ancestor_sgdu,ancestor_repgdu)
								check_potential_parent = temp_sgdu_gdu_current_time_df.loc[(temp_sgdu_gdu_current_time_df['GDUID'] == int(ancestor_repgdu)) & (temp_sgdu_gdu_current_time_df['SGDUID'] == int(unique_child))]
								if (len(check_potential_parent) > 0):
									records_for_potential_parents = temp_sgdu_gdu_df.loc[(temp_sgdu_gdu_df['GDUID'] == int(ancestor_repgdu))|(temp_sgdu_gdu_df['repGDUID'] == int(ancestor_repgdu)),['SGDUID','repGDUID']]
									unique_potential_parents = records_for_potential_parents['SGDUID'].unique()
									#if (parent == 78053):
									#	print('unique_potential_parents',unique_potential_parents)
									if (len(unique_potential_parents) > 0):
										already_recorded_potential_sgdu = []
										already_recorded_potential_repsgdu = []
										for tuple_of_potential_parent in records_for_potential_parents.itertuples(index=False,name=None):
											additional_sgdu_parent, additional_repgduid = tuple_of_potential_parent
											final_valid_sgdu_features = [final_sgdu_ft for final_sgdu_ft in final_sgdu_features_collection if (final_sgdu_ft.is_valid_at_time(from_time + small_time_interval_to_define_supergdu))]
											if ((additional_sgdu_parent not in already_recorded_potential_sgdu) or (additional_repgduid not in already_recorded_potential_repsgdu)):
												found_valid_additional_parent_sgdu = None
												for sgdu_feature in final_valid_sgdu_features:
													if (sgdu_feature.get_name() == str(additional_sgdu_parent) or sgdu_feature.get_reconstruction_plate_id() == additional_repgduid):
														if (found_valid_additional_parent_sgdu is None):
															found_valid_additional_parent_sgdu = [sgdu_feature.get_name()]
														else:
															found_valid_additional_parent_sgdu.append(sgdu_feature.get_name())
												if (found_valid_additional_parent_sgdu is None):
													# results_of_similar_temp_sgdus = None
													# for sgdu_feature in final_valid_sgdu_features:
														# plateid_of_sgdu_ft = sgdu_feature.get_reconstruction_plate_id()
														# results_of_similar_temp_sgdus = temp_sgdu_gdu_df.loc[(temp_sgdu_gdu_df['GDUID'] == int(additional_repgduid))|(temp_sgdu_gdu_df['GDUID'] == int(plateid_of_sgdu_ft)),'SGDUID']
														# if (len(results_of_similar_temp_sgdus) > 0):
															# unique_sgdus_of_similar_temp_sgdus = results_of_similar_temp_sgdus.unique()
															# if (len(unique_sgdus_of_similar_temp_sgdus) == 1):
																# found_valid_additional_parent_sgdu = sgdu_feature
																# break
													results_of_similar_temp_sgdus = None
													for sgdu_feature in final_valid_sgdu_features:
														plateid_of_sgdu_ft = sgdu_feature.get_reconstruction_plate_id()
														results_of_similar_temp_sgdus_from_additional_repGDU = temp_sgdu_gdu_df.loc[(temp_sgdu_gdu_df['GDUID'] == int(additional_repgduid)),'SGDUID'].unique()
														results_of_similar_temp_sgdus_from_current_plateid = temp_sgdu_gdu_df.loc[(temp_sgdu_gdu_df['GDUID'] == int(plateid_of_sgdu_ft)),'SGDUID'].unique()
														intersecting_sgdu = np.intersect1d(results_of_similar_temp_sgdus_from_additional_repGDU,results_of_similar_temp_sgdus_from_current_plateid)
														if (len(intersecting_sgdu) > 0):
															#unique_sgdus_of_similar_temp_sgdus = results_of_similar_temp_sgdus.unique()
															# if (len(unique_sgdus_of_similar_temp_sgdus) == 1):
																# found_valid_additional_parent_sgdu = sgdu_feature
																# break
															found_valid_additional_parent_sgdu = []
															for same_sgdu in intersecting_sgdu:
																found_valid_additional_parent_sgdu.append(same_sgdu)
												if (found_valid_additional_parent_sgdu is None):
													print("Error could not find additional_parent_sgdu from final_valid_sgdu_features")
													print("from_time",from_time,"to_time",to_time)
													print('additional_sgdu_parent',additional_sgdu_parent)
													print('additional_repgduid',additional_repgduid)
													print('ancestor_from_time',ancestor_from_time)
													print('ancestor_to_time',ancestor_to_time)
													print('ancestor_sgdu',ancestor_sgdu)
													print('ancestor_repgdu',ancestor_repgdu)
													print('results_of_similar_temp_sgdus',results_of_similar_temp_sgdus)
													exit()
												#check to make sure this will be convergence -- cannot perform the check because initially it did not exist in the sgdu_history 
												#children_of_sgdu = sgdu_history_df.loc[(sgdu_history_df['parent'] == int(found_valid_additional_parent_sgdu.get_name())), 'SGDU'].unique()
												#if (len(children_of_sgdu) == 1):
												# new_additional_sgdu_parent = found_valid_additional_parent_sgdu.get_name()
												# old_additional_sgdu_parent = additional_sgdu_parent
												# additional_sgdu_parent = new_additional_sgdu_parent
												# already_recorded_potential_sgdu.append(additional_sgdu_parent)
												# already_recorded_potential_repsgdu.append(additional_repgduid)
											
												# output_conv_dic['SGDU'].append(additional_sgdu_parent)
												# output_conv_dic['end_conv'].append(ancestor_to_time)
												# output_conv_dic['repGDUID'].append(additional_repgduid)
											
												found_additional_parents = True
											
										
												# #additional parents for convergence
												# framework_dic['origin_lv'].append(lvl)
												# framework_dic['SGDU'].append(unique_child)
												# framework_dic['parent'].append(additional_sgdu_parent)
												# framework_dic['from_time'].append(from_time)
												# framework_dic['to_time'].append(to_time)
												# framework_dic['repGDUID'].append(additional_repgduid)
												
												for new_additional_sgdu_parent in found_valid_additional_parent_sgdu:
													old_additional_sgdu_parent = additional_sgdu_parent
													additional_sgdu_parent = new_additional_sgdu_parent
													already_recorded_potential_sgdu.append(additional_sgdu_parent)
													already_recorded_potential_repsgdu.append(additional_repgduid)
											
													output_conv_dic['SGDU'].append(additional_sgdu_parent)
													output_conv_dic['end_conv'].append(ancestor_to_time)
													output_conv_dic['repGDUID'].append(additional_repgduid)
										
													#additional parents for convergence
													framework_dic['origin_lv'].append(lvl)
													framework_dic['SGDU'].append(unique_child)
													framework_dic['parent'].append(additional_sgdu_parent)
													framework_dic['from_time'].append(from_time)
													framework_dic['to_time'].append(to_time)
													framework_dic['repGDUID'].append(additional_repgduid)
												
							if (found_additional_parents == True):
								for parent_tuple in records_of_parent_sgdu.itertuples(index=False,name=None):
									output_conv_dic['SGDU'].append(parent)
									final_conv_end_time = parent_tuple[0]
									unique_child_repGDUID = parent_tuple[1]
									output_conv_dic['end_conv'].append(final_conv_end_time)
									output_conv_dic['repGDUID'].append(unique_child_repGDUID)

	output_dataframe = pd.DataFrame.from_dict(output_conv_dic)
	filename = 'end_time_of_conv_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)
	
	output_dataframe = pd.DataFrame.from_dict(framework_dic)
	filename = 'extra_sgdu_history_for_'+'_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)

def main():
	supergdu_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	#supergdu_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	#supergdu_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.shp"
	supergdu_features = pygplates.FeatureCollection(supergdu_file)
	begin_reconstruction_time = 2000.0
	end_reconstruction_time = 0.0
	#time_interval = 5.00
	common_filename_for_sgdu_and_gdu_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	#common_filename_for_sgdu_and_gdu_members_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	modelname = "test_11_PalaeoPlatesJan2023_sgdu_history_test_6"
	yearmonthday = "20230516"
	sgdu_history_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/sgdu_history_for__test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230426.csv"
	#sgdu_history_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\sgdu_history_for__test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230426.csv"
	#sgdu_history_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\sgdu_history_for__test_2_PalaeoPlatesJan2023_20230401.csv"
	small_time_interval_to_define_supergdu = 5.00
	find_end_of_converging(supergdu_file,sgdu_history_csv, common_filename_for_sgdu_and_gdu_members_csv, small_time_interval_to_define_supergdu, begin_reconstruction_time, end_reconstruction_time, modelname, yearmonthday)
if __name__=='__main__':
	main()