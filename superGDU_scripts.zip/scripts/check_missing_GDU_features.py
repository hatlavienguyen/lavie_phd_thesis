#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import os

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(line):
	if (line.length > 0.00):
		try:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.coords]
		except NotImplementedError as error:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.exterior.coords]
		line_on_sphere = pygplates.PolylineOnSphere(list_of_lat_lon_vertices)
		if (line_on_sphere is None):
			print ("Error to convert convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
			print ("Here is a list_of_lat_lon_vertices")
			print (list_of_lat_lon_vertices)
			print (list_of_lat_lon_vertices)
			exit()
		return line_on_sphere
	else:
		print ("Error in convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
		print ("line.length == 0")
		print ("here are coords for line:")
		print((line.coords))
		print ("here is line")
		print (line)
		exit()

def convert_Polygon_to_PolygonOnSphere_in_pygplates(each_polygon):
	if (each_polygon.area > 0.00):
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			#print("lat,lon")
			#print(lat,lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
				print("Warning invalid value of latitude or/and longitude")
				print("value of latitude")
				print(lat)
				print("value of longitude")
				print(lon)
				if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
					if (abs(abs(lat) - 90.00) < 0.500):
						if (lat < -90.00):
							lat = -90.000
						elif (lat > 90.00):
							lat = 90.000
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of latitude")
						print("value of latitude")
						print(lat)					
						exit()
				if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
					if (abs(abs(lon) - 180.00) < 0.500):
						if (lon < -180.00):
							lon = -180.00
						elif (lon > 180.00):
							lon = 180.00
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of longitude")
						print("value of longitude")
						print(lon)					
						exit()
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print("Error in creating polygon in pygplates in conversion module")
			print("Here is a list of lat_lon vertices")
			print(list_of_lat_lon_vertices)
			print("Here is the first vertex and the last vertex:")
			print(list_of_lat_lon_vertices[0])
			print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
			exit()
		return new_polygon
	else:
		print("Error in creating polygon in pygplates in conversion module")
		print("Error each_polygon.area <= 0.00")
		print("here is each_polygon")
		print(each_polygon)
		print([(lon,lat) for lon,lat in each_polygon.exterior.coords])
		exit()


def convert_polygon_to_Polygon_in_shapely(each_polygon):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in each_polygon.to_lat_lon_list()]
	new_polygon = Polygon(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating Polygon in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_polygon


def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = mean(lat_values)
				mean_lon = mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def study_relative_rotation_btw_gdu1_and_gdu2(rotation_model,gdu1,gdu2,from_time,to_time,reference):
	#Get the rotation of "other plate" from other_plate_ID from previous_reconstruction_time which is reconstruction_time + interval to reconstruction_time
	rel_stage_rotation_ref_plate = None
	if (reference is None):
		rel_stage_rotation_ref_plate = rotation_model.get_rotation(float(to_time),gdu1,float(from_time),fixed_plate_id = gdu2, anchor_plate_id = 0,use_identity_for_missing_plate_ids = False)
	else:
		rel_stage_rotation_ref_plate = rotation_model.get_rotation(float(to_time),gdu1,float(from_time),fixed_plate_id = gdu2, anchor_plate_id = reference,use_identity_for_missing_plate_ids = False)
	if (rel_stage_rotation_ref_plate is not None):
		pole_latitude, pole_longitude, angle_degrees = rel_stage_rotation_ref_plate.get_lat_lon_euler_pole_and_angle_degrees()
		return pole_latitude, pole_longitude, angle_degrees
	else:
		pole_latitude, pole_longitude, angle_degrees = None, None, None 
		return pole_latitude, pole_longitude, angle_degrees

def check_missing_GDU_features_in_relation_to_SuperGDU_features(rotation_file, common_filename_for_missing_gdu_features_shp_file, common_filename_for_sgdu_features_shp_file, begin_reconstruction_time, end_reconstruction_time, time_interval, buffer_distance_km, reference, modelname, yearmonthday):
	rotation_model = pygplates.RotationModel(rotation_file)
	reconstructed_features_geometries = []
	reconstructed_supergdu_features_geometries = []
	#;from_time;to_time;SGDUID;GDUID;POLYGID;buffer_distance_km;repGDUID
	dic_output = {'from_time':[],'to_time':[],'SGDUID':[],'GDUID':[],'POLYGID':[],'buffer_distance_km':[],'repGDUID':[]}
	missing_gdu_dic_output = {'reconstruction_time':[],'GDUID':[],'POLYGID':[]}
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		gdu_features_shp_file = common_filename_for_missing_gdu_features_shp_file.format(time = str(reconstruction_time))
		if (os.path.isfile(gdu_features_shp_file)):
			sgdu_features_shp_file = common_filename_for_sgdu_features_shp_file.format(time=str(reconstruction_time))
			sgdu_features_collection = pygplates.FeatureCollection(sgdu_features_shp_file)
			gdu_features_collection = pygplates.FeatureCollection(gdu_features_shp_file)
			reconstructed_features_geometries[:] = []
			reconstructed_supergdu_features_geometries[:] = []
			valid_supergdu_feats = [sgdu_ft for sgdu_ft in sgdu_features_collection if sgdu_ft.is_valid_at_time(reconstruction_time)]
			valid_gdu_feats = [gdu_ft for gdu_ft in gdu_features_collection if gdu_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(valid_supergdu_feats, rotation_model, reconstructed_supergdu_features_geometries, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(valid_gdu_feats, rotation_model, reconstructed_features_geometries, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_supergdu_feats, rotation_model, reconstructed_supergdu_features_geometries, reconstruction_time, group_with_feature = True)
				pygplates.reconstruct(valid_gdu_feats, rotation_model, reconstructed_features_geometries, reconstruction_time, group_with_feature = True)
			final_reconstructed_sgdu_features = find_final_reconstructed_geometries(reconstructed_supergdu_features_geometries,pygplates.PolygonOnSphere)
			final_reconstructed_gdu_features = find_final_reconstructed_geometries(reconstructed_features_geometries,pygplates.PolygonOnSphere)
			for missing_gdu_ft, missing_gdu in final_reconstructed_gdu_features:
				found_sgdu_ft = None
				for sgdu_ft, sgdu in final_reconstructed_sgdu_features:
					if (pygplates.GeometryOnSphere.distance(missing_gdu, sgdu) == 0.00):
						found_sgdu_ft = sgdu_ft
						#find relative rotation between the repgduid of sgdu and gduid of missing_gdu_ft
						pole_latitude, pole_longitude, angle_degrees = study_relative_rotation_btw_gdu1_and_gdu2(rotation_model,missing_gdu_ft.get_reconstruction_plate_id(),sgdu_ft.get_reconstruction_plate_id(),reconstruction_time+time_interval,reconstruction_time,reference)
						if (angle_degrees is None or angle_degrees <= 0.1000):
							#no relative motion between sgdu and and missing_gdu -- hence missing_gdu is a member of sgdu
							dic_output['from_time'].append(reconstruction_time+time_interval) 
							dic_output['to_time'].append(reconstruction_time)
							dic_output['SGDUID'].append(int(sgdu_ft.get_name()))
							dic_output['GDUID'].append(missing_gdu_ft.get_reconstruction_plate_id())
							dic_output['POLYGID'].append(missing_gdu_ft.get_shapefile_attribute('POLYGID'))
							dic_output['repGDUID'].append(sgdu_ft.get_reconstruction_plate_id())
							dic_output['buffer_distance_km'].append(buffer_distance_km)
						break
				if (found_sgdu_ft is not None):
					break
			if (found_sgdu_ft is None):
				missing_gdu_dic_output['reconstruction_time'].append(reconstruction_time)
				missing_gdu_dic_output['GDUID'].append(missing_gdu_ft.get_reconstruction_plate_id())
				missing_gdu_dic_output['POLYGID'].append(missing_gdu_ft.get_shapefile_attribute('POLYGID'))
		reconstruction_time = reconstruction_time - time_interval
	output_df = pd.DataFrame.from_dict(dic_output)
	output_df.to_csv('finding_sgdus_for_missing_gdus_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.csv')
	missing_output_df = pd.DataFrame.from_dict(missing_gdu_dic_output)
	missing_output_df.to_csv('missing_gdus_after_second_eval_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.csv')

def main():
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_file = r"1000_0_rotfile_Merdith_et_al_optimised.rot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\1000_0_rotfile_Merdith_et_al.rot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\LiLiuErnst2023\EDRG_90W_2000-540Ma.rot"
	rotation_model = pygplates.RotationModel(rotation_file)
	GDU_fts_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\LomonosovRidge_at_0Ma.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\Valid_EB2021_shape_continents_polygons.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\edit_shapes_continents_Merdith_et_al.gpml"
	#GDU_fts_file = r"edit_shapes_continents_Merdith_et_al.shp"
	#GDU_fts_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\LiLiuErnst2023\QGIS_single_parts_valid_and_fixed_Continental_outlines.shp"
	GDU_fts_collection = pygplates.FeatureCollection(GDU_fts_file)
	print ("Here is rotation_file")
	print (rotation_file)
	print ("Here is GDU_fts_file")
	print (GDU_fts_file)
	list_of_members_GDU_IDs = []
	for GDU_ft in GDU_fts_collection:
		GDU_id = GDU_ft.get_reconstruction_plate_id()
		if GDU_id not in list_of_members_GDU_IDs:
			list_of_members_GDU_IDs.append(GDU_id)
	from_time = 3420.00
	to_time = 0.00
	interval = 5.00
	#reference = 0
	reference = 700
	number_of_decimals = 3
	#modelname = "EB2022_w_optimised_rot"
	#modelname = 'Muller_Merdith_optimised_EB2022'
	#modelname = "LiLiuErnst2023_W"
	#modelname = "LomonosovRidge_at_0Ma"
	modelname = "QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km"
	yearmonthday = "20230404"
	
	#equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_PalaeoPlatesendJan2023_20230203.csv"
	equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_QGIS_fixed_PalaeoPlatesendJan2023_20230320.csv"
	#equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_LiLiuErnst2023_20230318.csv"
	#equivalent_stage_rotation_csv_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\equivalent_rot_of_each_gdu_with_anchor_EB2021_20221222.csv"
	#equivalent_stage_rotation_csv_file = r"equivalent_rot_of_each_gdu_with_anchor_EB2022_20230202.csv"
	buffer_distance_km = 500.00
	#threshold_distance_km_to_be_included = 500.00
	uncertainity_to_lat_and_lon_of_finite_rot_pole = 0.1000
	uncertainty_to_rotation_angle = 0.5000
	number_of_digits_for_rot = 3
	#create_equivalent_rotation_groups_with_uncertainity_for_finite_rotation_without_projection(equivalent_stage_rotation_csv_file, rotation_model, GDU_fts_collection, from_time, to_time, interval,buffer_distance_km, uncertainity_to_lat_and_lon_of_finite_rot_pole, uncertainty_to_rotation_angle, number_of_digits_for_rot, reference, modelname, yearmonthday)
	
	common_filename_for_missing_gdu_features_shp_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/missing_gdu_feats_collection_{time}_for_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230404.shp"
	common_filename_for_sgdu_features_shp_file = r"dissolved_polygon_fts_from_{time}_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230404.shp"
	
	check_missing_GDU_features_in_relation_to_SuperGDU_features(rotation_file, common_filename_for_missing_gdu_features_shp_file, common_filename_for_sgdu_features_shp_file, from_time, to_time, interval, buffer_distance_km, reference, modelname, yearmonthday)

if __name__== '__main__':
	main()
