#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd 

def create_SuperGDU_history_records(supergdu_features, common_filename_for_sgdu_and_gdu_members_csv, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	reconstruction_time = begin_reconstruction_time
	framework_dic = {'origin_lv':[],'SGDU':[],'parent':[],'from_time':[],'to_time':[],'repGDUID':[]}
	temp_dic = {}
	while (reconstruction_time > end_reconstruction_time):
		print('reconstruction_time',reconstruction_time)
		valid_SGDU_features = [sgdu_ft for sgdu_ft in supergdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
		for sgdu_ft in valid_SGDU_features:
			sgdu_name = sgdu_ft.get_name()
			sgdu_from_time,sgdu_to_time = sgdu_ft.get_valid_time()
			sgduid = int(sgdu_name)
			repgduid = sgdu_ft.get_reconstruction_plate_id()
			if (reconstruction_time == begin_reconstruction_time):
				if (sgdu_name not in temp_dic):
					temp_dic[sgdu_name] = {'level':0, 'parent':None,'rep':[repgduid],'from_time':sgdu_from_time,'to_time':sgdu_to_time}
				else:
					list_of_repgduid = temp_dic[sgdu_name]['rep']
					if (repgduid not in list_of_repgduid):
						temp_dic[sgdu_name]['rep'].append(repgduid)
			elif (reconstruction_time < begin_reconstruction_time):
				prev_reconstruction_time = reconstruction_time + time_interval
				prev_valid_sgdu_feats = [sgdu_ft for sgdu_ft in supergdu_features if sgdu_ft.is_valid_at_time(prev_reconstruction_time)]
				filename_prev_time = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(prev_reconstruction_time))
				temp_sgdu_gdu_df = pd.read_csv(filename_prev_time,header=0,delimiter=';')
				if (sgdu_name in temp_dic):
					#if (sgdu_from_time <= reconstruction_time): OLD
					list_of_repgduid = temp_dic[sgdu_name]['rep']
					if (repgduid not in list_of_repgduid):
						temp_dic[sgdu_name]['rep'].append(repgduid)
				else:
					prev_reconstruction_time = sgdu_from_time + time_interval
					prev_valid_sgdu_feats = [sgdu_ft for sgdu_ft in supergdu_features if sgdu_ft.is_valid_at_time(prev_reconstruction_time)]
					filename_prev_time = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(prev_reconstruction_time))
					temp_sgdu_gdu_df = pd.read_csv(filename_prev_time,header=0,delimiter=';')
					selected_prev_sgdu_records = temp_sgdu_gdu_df.loc[(temp_sgdu_gdu_df['repGDUID'] == repgduid)|(temp_sgdu_gdu_df['GDUID'] == repgduid),['GDUID','repGDUID']]
					if (len(selected_prev_sgdu_records) > 0):
						#selected the first one to extract the name
						list_of_prev_sgdus = []
						found_prev_sgdu = None
						
						# for i in range(0,len(selected_prev_sgdu_records)):
							# rep_record = selected_prev_sgdu_records[i]
							# found_prev_sgdu = None
							# for prev_sgdu_ft in prev_valid_sgdu_feats:
								# prev_name = prev_sgdu_ft.get_name()
								# if (prev_sgdu_ft.get_reconstruction_plate_id() == rep_record and prev_name in temp_dic):
									# found_prev_sgdu = prev_sgdu_ft
									# break
							# if (found_prev_sgdu is not None):
								# break
						if (found_prev_sgdu is None):
							for member_gduid, possible_repgduid in selected_prev_sgdu_records.itertuples(index = False, name = None):
								for prev_sgdu_ft in prev_valid_sgdu_feats:
									prev_name = prev_sgdu_ft.get_name()
									if (prev_name in temp_dic):
										if (prev_sgdu_ft.get_reconstruction_plate_id() == int(member_gduid) or prev_sgdu_ft.get_reconstruction_plate_id() == int(possible_repgduid)):
											#found_prev_sgdu = prev_sgdu_ft
											#break
											if (prev_name not in list_of_prev_sgdus):
												list_of_prev_sgdus.append(prev_name)
								#if (found_prev_sgdu is not None):
								#	break
						#if (found_prev_sgdu is None):
						array_of_unique_selected_prev_sgdu = temp_sgdu_gdu_df.loc[(temp_sgdu_gdu_df['repGDUID'] == repgduid)|(temp_sgdu_gdu_df['GDUID'] == repgduid),'SGDUID'].unique()
						for unique_selected_prev_sgdu in array_of_unique_selected_prev_sgdu:
							#unique_selected_prev_sgdu = array_of_unique_selected_prev_sgdu[0]
							array_of_gdu_members_for_prev_sgdu = temp_sgdu_gdu_df.loc[(temp_sgdu_gdu_df['SGDUID'] == unique_selected_prev_sgdu),'GDUID'].unique()
							for prev_sgdu_ft in prev_valid_sgdu_feats:
								prev_name = prev_sgdu_ft.get_name()
								if (prev_name in temp_dic):
									if (prev_sgdu_ft.get_reconstruction_plate_id() in array_of_gdu_members_for_prev_sgdu):
										#found_prev_sgdu = prev_sgdu_ft
										#break
										if (prev_name not in list_of_prev_sgdus):
											list_of_prev_sgdus.append(prev_name)
								else:
									print("Error prev_sgdu_name not in temp_dic")
									print("prev_name",prev_name)
									print("reconstruction_time",reconstruction_time)
									exit()
							#if (found_prev_sgdu is not None):
							#	break
						#if (found_prev_sgdu is None):
						if (len(list_of_prev_sgdus) == 0):
							print("Error could not find prev SuperGDU feature with given repGDUID and reconstruction time")
							print(repgduid, reconstruction_time)
							print("currently examined SuperGDU feature", sgdu_name)
							print("sgdu_from_time,sgdu_to_time", sgdu_from_time, sgdu_to_time)
							print("prev_reconstruction_time",prev_reconstruction_time)
							print("unique_selected_prev_sgdu",unique_selected_prev_sgdu)
							print("array_of_gdu_members_for_prev_sgdu",array_of_gdu_members_for_prev_sgdu)
							
							for sgdu_name in temp_dic:
								record_for_sgdu = temp_dic[sgdu_name]
								level = record_for_sgdu['level']
								parent = record_for_sgdu['parent']
								list_of_repgduid = record_for_sgdu['rep']
								sgdu_from_time = record_for_sgdu['from_time']
								sgdu_to_time = record_for_sgdu['to_time']
								for each_repgduid in list_of_repgduid:
									
									if (parent is not None):
										#framework_dic['parent'].append(int(parent))
										for p in parent:
											framework_dic['origin_lv'].append(level)
											framework_dic['SGDU'].append(int(sgdu_name))
											framework_dic['parent'].append(int(p))
											framework_dic['from_time'].append(sgdu_from_time)
											framework_dic['to_time'].append(sgdu_to_time)
											framework_dic['repGDUID'].append(each_repgduid)
									else:
										framework_dic['origin_lv'].append(level)
										framework_dic['SGDU'].append(int(sgdu_name))
										framework_dic['parent'].append(-1)
										framework_dic['from_time'].append(sgdu_from_time)
										framework_dic['to_time'].append(sgdu_to_time)
										framework_dic['repGDUID'].append(each_repgduid)
								output_dataframe = pd.DataFrame.from_dict(framework_dic)
								filename = 'incompleted_sgdu_history_for_'+'_'+modelname+'_'+yearmonthday+'.csv'
								output_dataframe.to_csv(filename,index=False)
							exit()
						for prev_sgdu_name in list_of_prev_sgdus:
							#get prev sgdu 
							#prev_sgdu_name = found_prev_sgdu.get_name()
							record_of_prev_sgdu_in_temp_dic = temp_dic[prev_sgdu_name]
							prev_level = record_of_prev_sgdu_in_temp_dic['level']
							new_level = prev_level + 1
							new_parent = prev_sgdu_name
							if (sgdu_name not in temp_dic):
								temp_dic[sgdu_name] = {'level':new_level, 'parent':[new_parent],'rep':[repgduid],'from_time':sgdu_from_time,'to_time':sgdu_to_time}
							else:
								temp_dic[sgdu_name]['parent'].append(new_parent)
					#else: --- Let's check regardless
					filename_current_time = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(reconstruction_time))
					temp_sgdu_gdu_df_current_time = pd.read_csv(filename_current_time,header=0,delimiter=';')
					list_of_prev_sgdus = []
					for prev_valid_sgdu_ft in prev_valid_sgdu_feats:
						prev_sgdu_id = int(prev_valid_sgdu_ft.get_name())
						prev_repgduid = prev_valid_sgdu_ft.get_reconstruction_plate_id()
						result_of_familiy_rlxn = temp_sgdu_gdu_df_current_time.loc[(temp_sgdu_gdu_df_current_time['SGDUID'] == sgduid)&(temp_sgdu_gdu_df_current_time['GDUID'] == prev_repgduid)]
						if (result_of_familiy_rlxn is not None):
							if (len(result_of_familiy_rlxn) > 0):
								if (prev_sgdu_id not in list_of_prev_sgdus):
									list_of_prev_sgdus.append(prev_sgdu_id)
					if (len(list_of_prev_sgdus) > 0):
						for prev_sgdu_id in list_of_prev_sgdus:
							prev_sgdu_name = str(prev_sgdu_id)
							if (prev_sgdu_name in temp_dic):
								record_of_prev_sgdu_in_temp_dic = temp_dic[prev_sgdu_name]
								prev_level = record_of_prev_sgdu_in_temp_dic['level']
								new_level = prev_level + 1
								new_parent = prev_sgdu_name
								if (sgdu_name not in temp_dic):
									temp_dic[sgdu_name] = {'level':new_level, 'parent':[new_parent],'rep':[repgduid],'from_time':sgdu_from_time,'to_time':sgdu_to_time}
								else:
									temp_dic[sgdu_name]['parent'].append(new_parent)
							else:
								print("Error could not find prev SuperGDU feature with given repGDUID and reconstruction time")
								print(repgduid, reconstruction_time)
								print("currently examined SuperGDU feature", sgdu_name)
								print("sgdu_from_time,sgdu_to_time", sgdu_from_time, sgdu_to_time)
								print("prev_reconstruction_time",prev_reconstruction_time)
								for sgdu_name in temp_dic:
									record_for_sgdu = temp_dic[sgdu_name]
									level = record_for_sgdu['level']
									parent = record_for_sgdu['parent']
									list_of_repgduid = record_for_sgdu['rep']
									sgdu_from_time = record_for_sgdu['from_time']
									sgdu_to_time = record_for_sgdu['to_time']
									for each_repgduid in list_of_repgduid:
										if (parent is not None):
											#framework_dic['parent'].append(int(parent))
											for p in parent:
												framework_dic['origin_lv'].append(level)
												framework_dic['SGDU'].append(int(sgdu_name))
												framework_dic['parent'].append(int(p))
												framework_dic['from_time'].append(sgdu_from_time)
												framework_dic['to_time'].append(sgdu_to_time)
												framework_dic['repGDUID'].append(each_repgduid)
										else:
											framework_dic['origin_lv'].append(level)
											framework_dic['SGDU'].append(int(sgdu_name))
											framework_dic['parent'].append(-1)
											framework_dic['from_time'].append(sgdu_from_time)
											framework_dic['to_time'].append(sgdu_to_time)
											framework_dic['repGDUID'].append(each_repgduid)
									output_dataframe = pd.DataFrame.from_dict(framework_dic)
									filename = 'incompleted_sgdu_history_for_'+'_'+modelname+'_'+yearmonthday+'.csv'
									output_dataframe.to_csv(filename,index=False)
								exit()
					elif (len(list_of_prev_sgdus) == 0 and len(selected_prev_sgdu_records) == 0):
						temp_dic[sgdu_name] = {'level':0, 'parent':None,'rep':[repgduid],'from_time':sgdu_from_time,'to_time':sgdu_to_time}
		reconstruction_time = reconstruction_time - time_interval
	
	#framework_dic = {'origin_lv':[],'SGDU':[],'parent':[],'from_time':[],'to_time':[],'repGDUID':[]}
	for sgdu_name in temp_dic:
		record_for_sgdu = temp_dic[sgdu_name]
		level = record_for_sgdu['level']
		parent = record_for_sgdu['parent']
		list_of_repgduid = record_for_sgdu['rep']
		sgdu_from_time = record_for_sgdu['from_time']
		sgdu_to_time = record_for_sgdu['to_time']
		for each_repgduid in list_of_repgduid:
			if (parent is not None):
				#framework_dic['parent'].append(int(parent))
				for p in parent:
					framework_dic['origin_lv'].append(level)
					framework_dic['SGDU'].append(int(sgdu_name))
					framework_dic['parent'].append(int(p))
					framework_dic['from_time'].append(sgdu_from_time)
					framework_dic['to_time'].append(sgdu_to_time)
					framework_dic['repGDUID'].append(each_repgduid)
			else:
				framework_dic['origin_lv'].append(level)
				framework_dic['SGDU'].append(int(sgdu_name))
				framework_dic['parent'].append(-1)
				framework_dic['from_time'].append(sgdu_from_time)
				framework_dic['to_time'].append(sgdu_to_time)
				framework_dic['repGDUID'].append(each_repgduid)
	output_dataframe = pd.DataFrame.from_dict(framework_dic)
	filename = 'sgdu_history_for_'+'_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)

def main():
	# supergdu_file = r"final_supergdu_feats_995.0_0.0_Merdith_et_al_EB2021_20230428.shp"
	# supergdu_features = pygplates.FeatureCollection(supergdu_file)
	# begin_reconstruction_time = 995.0
	# end_reconstruction_time = 0.0
	# time_interval = 5.00
	# common_filename_for_sgdu_and_gdu_members_csv = r"supergdu_and_members_gdu_at_{time}_for_Merdith_et_al_EB2021_20230428.csv"
	# modelname = "test_3_Merdith_et_al_EB2021"
	# yearmonthday = "20231005"
	# create_SuperGDU_history_records(supergdu_features, common_filename_for_sgdu_and_gdu_members_csv, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)
	
	supergdu_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	supergdu_features = pygplates.FeatureCollection(supergdu_file)
	begin_reconstruction_time = 3420.0
	end_reconstruction_time = 0.0
	time_interval = 5.00
	common_filename_for_sgdu_and_gdu_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	
	modelname = "test_11_PalaeoPlatesJan2023_from_20230425"
	yearmonthday = "20231005"
	create_SuperGDU_history_records(supergdu_features, common_filename_for_sgdu_and_gdu_members_csv, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)
if __name__=='__main__':
	main()