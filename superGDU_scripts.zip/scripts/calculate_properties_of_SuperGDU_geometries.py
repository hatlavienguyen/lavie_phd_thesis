import os
import csv
import math
import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd

def area_of_each_SuperGDU_feature(common_filename_for_supergdu_and_members_csv, final_supergdu_csv, present_date_GDU_features_epsg_4326_shp, crs_in_epsg, field_for_from_age_shp, field_for_to_age_shp, field_for_plateid_or_gduid_or_polygid_shp, is_polygid, is_special_due_to_GPlates, modelname, yearmonthday):
	output_sgdu_and_gdu_dic = {"from_time":[],"to_time":[],"SGDUID":[],"GDUID":[]}
	results = []
	results_of_sgdu_and_repGDU = []
	GDU_gdf = gpd.read_file(present_date_GDU_features_epsg_4326_shp)
	projected_gdf = None
	if (crs_in_epsg is None):
		#by default set crs_in_epsg to ESRI:54009 - World Mollweide
		print("By default set crs_in_epsg to ESRI:54009 - World Mollweide")
		crs_in_epsg = 'ESRI:54009'
		projected_gdf = GDU_gdf.to_crs(crs_in_epsg)
	elif (crs_in_epsg == 'EPSG:4326'):
		#has to project to any projected coordinates, by default set crs_in_epsg to ESRI:54009 - World Mollweide
		print("Has to project to any projected coordinates, by default set crs_in_epsg to ESRI:54009 - World Mollweide")
		crs_in_epsg = 'ESRI:54009'
		projected_gdf = GDU_gdf.to_crs(crs_in_epsg)
	else:
		print("crs_in_epsg",crs_in_epsg)
		projected_gdf = GDU_gdf.to_crs(crs_in_epsg)
	
	area_in_sq_meters = projected_gdf['geometry'].area
	projected_gdf['Sqmeters'] = area_in_sq_meters
	
	txt = """ SELECT DISTINCT gdu_id_member 
			FROM super_GDU_and_members_id 
			WHERE super_gdu_id = {input_super_gdu_id} """
	txt_1 = """ SELECT super_gdu_id
			FROM temp_final_super_gdu_id_2
			WHERE from_time > {input_time} AND to_time <= {input_time} """
	#;SGDU;from_time;to_time
	supergdu_df = pd.read_csv(final_supergdu_csv, header = 0, delimiter = ';')
	already_included_SGDU = []
	dic_of_sgdu = {}
	for row in supergdu_df.itertuples(index = False):
		SGDU_int = row[1]
		if (SGDU_int not in dic_of_sgdu):
			dic_of_sgdu[str(SGDU_int)] = {'from_time':0.0,'to_time':0.0,'area':0.0,'repGDUID':None}
			
		else:
			continue
		from_time = float(row[2])
		to_time = float(row[3])
		dic_of_sgdu[str(SGDU_int)]['from_time'] = from_time
		dic_of_sgdu[str(SGDU_int)]['to_time'] = to_time
		final_name_for_supergdu_and_members_csv = common_filename_for_supergdu_and_members_csv.format(time = str(from_time))
		#'from_time', 'to_time', 'SGDUID', 'GDUID', 'buffer_distance_km', 'repGDUID'
		sgdu_and_members_df = pd.read_csv(final_name_for_supergdu_and_members_csv, header = 0, delimiter = ';')
		records_of_repGDUID = sgdu_and_members_df.loc[sgdu_and_members_df['SGDUID'] == SGDU_int, 'repGDUID'].unique()
		dic_of_sgdu[str(SGDU_int)]['repGDUID'] = records_of_repGDUID
		records_of_members = sgdu_and_members_df.loc[sgdu_and_members_df['SGDUID'] == SGDU_int, 'GDUID'].unique()
		if (is_polygid == True):
			records_of_members = sgdu_and_members_df.loc[sgdu_and_members_df['SGDUID'] == SGDU_int,'POLYGID'].unique()
		total_area_of_sgdu = 0.00 
		for member in records_of_members:
			records_gdu_members = None
			if (is_polygid == True):
				records_gdu_members = projected_gdf.loc[(projected_gdf[field_for_plateid_or_gduid_or_polygid_shp] == member) & (((projected_gdf[field_for_from_age_shp] >= from_time) & (projected_gdf[field_for_to_age_shp] <= from_time))), 'Sqmeters'].to_numpy()
			else:
				records_gdu_members = projected_gdf.loc[(projected_gdf[field_for_plateid_or_gduid_or_polygid_shp] == int(member)) & (((projected_gdf[field_for_from_age_shp] >= from_time) & (projected_gdf[field_for_to_age_shp] <= from_time))), 'Sqmeters'].to_numpy()
			if (is_special_due_to_GPlates == True):
				if (from_time >= 1000.00):
					if (is_polygid == True):
						records_gdu_members = projected_gdf.loc[(projected_gdf[field_for_plateid_or_gduid_or_polygid_shp] == member) & (((projected_gdf[field_for_from_age_shp] >= from_time) & (projected_gdf[field_for_to_age_shp] <= from_time)) | ((abs(projected_gdf[field_for_from_age_shp] - 1000.00) <= 1.000) & (projected_gdf[field_for_to_age_shp] <= from_time))), 'Sqmeters'].to_numpy()
					else:
						records_gdu_members = projected_gdf.loc[(projected_gdf[field_for_plateid_or_gduid_or_polygid_shp] == int(member)) & (((projected_gdf[field_for_from_age_shp] >= from_time) & (projected_gdf[field_for_to_age_shp] <= from_time)) | ((abs(projected_gdf[field_for_from_age_shp] - 1000.00) <= 1.000) & (projected_gdf[field_for_to_age_shp] <= from_time))), 'Sqmeters'].to_numpy()
				else:
					if (is_polygid == True):
						records_gdu_members = projected_gdf.loc[(projected_gdf[field_for_plateid_or_gduid_or_polygid_shp] == member) & ((projected_gdf[field_for_from_age_shp] >= from_time) & (projected_gdf[field_for_to_age_shp] <= from_time)), 'Sqmeters'].to_numpy()
					else:
						records_gdu_members = projected_gdf.loc[(projected_gdf[field_for_plateid_or_gduid_or_polygid_shp] == int(member)) & ((projected_gdf[field_for_from_age_shp] >= from_time) & (projected_gdf[field_for_to_age_shp] <= from_time)), 'Sqmeters'].to_numpy()
			if (len(records_gdu_members) == 0):
				print("Error len(records_gdu_members) == 0")
				print("SGDU",SGDU_int,"member",member,"from_time",from_time)
				exit()
			
			output_sgdu_and_gdu_dic['from_time'].append(from_time)
			output_sgdu_and_gdu_dic['to_time'].append(to_time)
			output_sgdu_and_gdu_dic['SGDUID'].append(SGDU_int)
			output_sgdu_and_gdu_dic['GDUID'].append(member)
			
			for mem_area_in_sq_m in records_gdu_members:
				#print('mem_area_in_sq_m',mem_area_in_sq_m)
				total_area_of_sgdu = total_area_of_sgdu + mem_area_in_sq_m
		print('total_area_of_sgdu',total_area_of_sgdu)
		dic_of_sgdu[str(SGDU_int)]['area'] = total_area_of_sgdu/1000000.00
	for name_of_sgdu in dic_of_sgdu:
		from_time_sgdu = dic_of_sgdu[name_of_sgdu]['from_time']
		to_time_sgdu = dic_of_sgdu[name_of_sgdu]['to_time']
		total_area = dic_of_sgdu[name_of_sgdu]['area']
		results.append((int(name_of_sgdu),from_time_sgdu,to_time_sgdu,total_area))
		collection_of_repgdu = dic_of_sgdu[name_of_sgdu]['repGDUID']
		for rgduid in collection_of_repgdu:
			results_of_sgdu_and_repGDU.append((int(name_of_sgdu),from_time_sgdu,to_time_sgdu,rgduid))
	output_df = pd.DataFrame(results, columns = ['SGDU','from_time','to_time','Area_Sqkm'])
	output_df.to_csv('area_of_each_SuperGDU_feature_'+modelname+'_'+yearmonthday+'.csv',sep=';',header=True)
	
	output_df = pd.DataFrame(results_of_sgdu_and_repGDU, columns = ['SGDU','from_time','to_time','repGDUID'])
	output_df.to_csv('records_of_SuperGDU_features_w_repGDUID_'+modelname+'_'+yearmonthday+'.csv',sep=';',header=True)
	
	output_df = pd.DataFrame.from_dict(output_sgdu_and_gdu_dic)
	output_df.to_csv('records_of_SuperGDU_and_GDU_members_'+modelname+'_'+yearmonthday+'.csv',sep=';',header=True)

def area_of_the_3_biggest_and_total_area_and_total_number_of_SuperGDUs_within_period(supergdu_w_area_csv_file, field_for_area, from_time_input_file, to_time_input_file, interval_input_file, modelname, yearmonthday):
	values = []
	total_area_values = []
	dataframe = pd.read_csv(supergdu_w_area_csv_file, sep = ';', header = 0)
	reconstruction_time = from_time_input_file
	while (reconstruction_time >= to_time_input_file):
		print('reconstruction_time')
		print(reconstruction_time)
		selected_record = []
		
		if (reconstruction_time > 0.00):
			selected_record = dataframe.loc[(dataframe['from_time'] >= reconstruction_time) & (dataframe['to_time'] < reconstruction_time), [field_for_area,'SGDU']]
		else:
			selected_record = dataframe.loc[(dataframe['from_time'] >= reconstruction_time) & (dataframe['to_time'] <= reconstruction_time), [field_for_area,'SGDU']]
		sorted = selected_record.sort_values(by = field_for_area, ascending = False)
		total_number_of_SuperGDUs = len(sorted)
		if (total_number_of_SuperGDUs >= 3):
			values.append((reconstruction_time, sorted.iloc[0,0], sorted.iloc[0,1], sorted.iloc[1,0], sorted.iloc[1,1], sorted.iloc[2,0], sorted.iloc[2,1]))
		elif (total_number_of_SuperGDUs == 2):
			values.append((reconstruction_time, sorted.iloc[0,0], sorted.iloc[0,1], sorted.iloc[1,0], sorted.iloc[1,1], 0.00, 0))
		elif (total_number_of_SuperGDUs == 1):
			values.append((reconstruction_time, sorted.iloc[0,0], sorted.iloc[0,1], 0.00, 0, 0.00, 0))
		
		# if (reconstruction_time > 0.00):
			# selected_record = dataframe.loc[(dataframe['from_time'] >= reconstruction_time) & (dataframe['to_time'] < reconstruction_time), field_for_area]
		# else:
			# selected_record = dataframe.loc[(dataframe['from_time'] >= reconstruction_time) & (dataframe['to_time'] <= reconstruction_time), field_for_area]
		# sorted = selected_record.sort_values(ascending = False)
		# total_number_of_SuperGDUs = len(sorted)
		# if (total_number_of_SuperGDUs >= 3):
			# values.append((reconstruction_time, sorted.iloc[0], sorted.iloc[1], sorted.iloc[2]))
		# elif (total_number_of_SuperGDUs == 2):
			# values.append((reconstruction_time, sorted.iloc[0], sorted.iloc[1], 0.00))
		# elif (total_number_of_SuperGDUs == 1):
			# values.append((reconstruction_time, sorted.iloc[0], 0.00, 0.00))
		sum_area = selected_record[field_for_area].sum()
		total_area_values.append((reconstruction_time,sum_area,total_number_of_SuperGDUs))
		reconstruction_time = reconstruction_time - interval_input_file
	new_dataframe = pd.DataFrame.from_records(values, columns = ['reconstruction_time','first_max_area','SGDU_1','second_max_area','SGDU_2','third_max_area','SGDU_3'])
	print(new_dataframe)
	filename = modelname+'_area_of_3_biggest_SuperGDUs_within_period_'+str(from_time_input_file)+'_'+str(to_time_input_file)+'_'+str(interval_input_file)+"_"+yearmonthday+'.csv'
	new_dataframe.to_csv(filename,index=False)
	
	new_dataframe = pd.DataFrame.from_records(total_area_values, columns = ['reconstruction_time','total_area_of_all_SuperGDUs','total_number_of_SuperGDUs'])
	print(new_dataframe)
	filename = modelname+'_total_area_of_SuperGDUs_within_period_'+str(from_time_input_file)+'_'+str(to_time_input_file)+'_'+str(interval_input_file)+"_"+yearmonthday+'.csv'
	new_dataframe.to_csv(filename,index=False)

def area_of_the_n_biggest_and_total_area_and_total_number_of_SuperGDUs_within_period(number_of_top_biggest_SGDUs, supergdu_w_area_csv_file, field_for_area, from_time_input_file, to_time_input_file, interval_input_file, modelname, yearmonthday):
	values = []
	total_area_values = []
	dataframe = pd.read_csv(supergdu_w_area_csv_file, sep = ';', header = 0)
	reconstruction_time = from_time_input_file
	while (reconstruction_time >= to_time_input_file):
		print('reconstruction_time')
		print(reconstruction_time)
		selected_record = []
		
		if (reconstruction_time > 0.00):
			selected_record = dataframe.loc[(dataframe['from_time'] >= reconstruction_time) & (dataframe['to_time'] < reconstruction_time), [field_for_area,'SGDU']]
		else:
			selected_record = dataframe.loc[(dataframe['from_time'] >= reconstruction_time) & (dataframe['to_time'] <= reconstruction_time), [field_for_area,'SGDU']]
		sorted = selected_record.sort_values(by = field_for_area, ascending = False)
		total_number_of_SuperGDUs = len(sorted)
		#temp_list_for_tuple = []
		# if (total_number_of_SuperGDUs >= number_of_top_biggest_SGDUs):
			# temp_list_for_tuple.append(reconstruction_time)
			# for i in range(number_of_top_biggest_SGDUs):
				# #temp_list_for_tuple.append(reconstruction_time)
				# temp_list_for_tuple.append(sorted.iloc[i,0])
				# temp_list_for_tuple.append(sorted.iloc[i,1])
			# #convert temp_list_for_tuple to tuple
			# #print('len(final_tuple)',len(final_tuple))
			# final_tuple = tuple(temp_list_for_tuple)
			# print('len(final_tuple)',len(final_tuple))
			# values.append(final_tuple)
		# else:
			# temp_list_for_tuple.append(reconstruction_time)
			# for i in range(total_number_of_SuperGDUs):
				# temp_list_for_tuple.append(sorted.iloc[i,0])
				# temp_list_for_tuple.append(sorted.iloc[i,1])
			# number_of_leftover = number_of_top_biggest_SGDUs - total_number_of_SuperGDUs
			# for j in range(number_of_leftover):
				# temp_list_for_tuple.append((0.00,0))
				# temp_list_for_tuple.append((0.00,0))
			# #convert temp_list_for_tuple to tuple
			# final_tuple = tuple(temp_list_for_tuple)
			# print('len(final_tuple)',len(final_tuple))
			# values.append(final_tuple)
		
		if (total_number_of_SuperGDUs >= number_of_top_biggest_SGDUs):
			for i in range(number_of_top_biggest_SGDUs):
				values.append((reconstruction_time,sorted.iloc[i,0],sorted.iloc[i,1]))
		else:
			for i in range(total_number_of_SuperGDUs):
				values.append((reconstruction_time,sorted.iloc[i,0],sorted.iloc[i,1]))
			number_of_leftover = number_of_top_biggest_SGDUs - total_number_of_SuperGDUs
			for j in range(number_of_leftover):
				values.append((reconstruction_time,0.00,0))
		
		# if (reconstruction_time > 0.00):
			# selected_record = dataframe.loc[(dataframe['from_time'] >= reconstruction_time) & (dataframe['to_time'] < reconstruction_time), field_for_area]
		# else:
			# selected_record = dataframe.loc[(dataframe['from_time'] >= reconstruction_time) & (dataframe['to_time'] <= reconstruction_time), field_for_area]
		# sorted = selected_record.sort_values(ascending = False)
		# total_number_of_SuperGDUs = len(sorted)
		# if (total_number_of_SuperGDUs >= 3):
			# values.append((reconstruction_time, sorted.iloc[0], sorted.iloc[1], sorted.iloc[2]))
		# elif (total_number_of_SuperGDUs == 2):
			# values.append((reconstruction_time, sorted.iloc[0], sorted.iloc[1], 0.00))
		# elif (total_number_of_SuperGDUs == 1):
			# values.append((reconstruction_time, sorted.iloc[0], 0.00, 0.00))
		reconstruction_time = reconstruction_time - interval_input_file
	# names_of_columns= ['reconstruction_time']
	# for i in range(number_of_top_biggest_SGDUs):
		# names_of_columns.append(str(i))
		# names_of_columns.append('SGDU_'+str(i))
	# new_dataframe = pd.DataFrame.from_records(values, columns = names_of_columns)
	# print(new_dataframe)
	# filename = modelname+'_area_of_'+str(number_of_top_biggest_SGDUs)+'_biggest_SuperGDUs_within_period_'+str(from_time_input_file)+'_'+str(to_time_input_file)+'_'+str(interval_input_file)+"_"+yearmonthday+'.csv'
	# new_dataframe.to_csv(filename,index=False)
	new_dataframe = pd.DataFrame.from_records(values, columns = ['reconstruction_time','area','SGDU'])
	print(new_dataframe)
	filename = modelname+'_area_of_'+str(number_of_top_biggest_SGDUs)+'_biggest_SuperGDUs_within_period_'+str(from_time_input_file)+'_'+str(to_time_input_file)+'_'+str(interval_input_file)+"_"+yearmonthday+'.csv'
	new_dataframe.to_csv(filename,index=False)

def main():
	# common_filename_for_supergdu_and_members_csv = r"supergdu_and_members_gdu_at_{time}_for_Cao_et_al_2023_1000km_20230907.csv"
	# final_supergdu_csv = r"final_supergdus_from_1800.0_0.0_for_Cao_et_al_2023_1000km_polygid_20230908.csv"
	# present_date_GDU_features_epsg_4326_shp = r"../Lavie_edit_shape_continents_Cao_et_al_2023.shp"
	# crs_in_epsg = "ESRI:54009"
	# field_for_from_age_shp = 'FROMAGE'
	# field_for_to_age_shp = 'TOAGE'
	# field_for_plateid_or_gduid_or_polygid_shp = 'POLYGID'
	# is_polygid = True
	# modelname = 'Cao_et_al_2023_1000km_polygid'
	# yearmonthday = '20230908'
	# area_of_each_SuperGDU_feature(common_filename_for_supergdu_and_members_csv, final_supergdu_csv, present_date_GDU_features_epsg_4326_shp, crs_in_epsg, field_for_from_age_shp, field_for_to_age_shp, field_for_plateid_or_gduid_or_polygid_shp, is_polygid, modelname, yearmonthday)

	# supergdu_w_area_csv_file = r"area_of_each_SuperGDU_feature_Cao_et_al_2023_1000km_polygid_20230908.csv"
	# field_for_area = "Area_Sqkm"
	# from_time_input_file = 1795.0
	# to_time_input_file = 0.0
	# interval_input_file = 5.0
	# area_of_the_3_biggest_and_total_area_and_total_number_of_SuperGDUs_within_period(supergdu_w_area_csv_file, field_for_area, from_time_input_file, to_time_input_file, interval_input_file, modelname, yearmonthday)
	
	# common_filename_for_supergdu_and_members_csv = r"supergdu_and_members_gdu_at_{time}_for_Cao_et_al_2023_1000km_20230907.csv"
	# final_supergdu_csv = r"final_supergdus_from_1800.0_0.0_for_Cao_et_al_2023_1000km_polygid_20230908.csv"
	# present_date_GDU_features_epsg_4326_shp = r"../Lavie_edit_shape_continents_Cao_et_al_2023.shp"
	# crs_in_epsg = "ESRI:54009"
	# field_for_from_age_shp = 'FROMAGE'
	# field_for_to_age_shp = 'TOAGE'
	# field_for_plateid_or_gduid_or_polygid_shp = 'POLYGID'
	# is_polygid = True
	# is_special_due_to_GPlates = True
	#modelname = 'Cao_et_al_2023_1000km_polygid'
	#yearmonthday = '20230908'
	#area_of_each_SuperGDU_feature(common_filename_for_supergdu_and_members_csv, final_supergdu_csv, present_date_GDU_features_epsg_4326_shp, crs_in_epsg, field_for_from_age_shp, field_for_to_age_shp, field_for_plateid_or_gduid_or_polygid_shp, is_polygid, is_special_due_to_GPlates, modelname, yearmonthday)

	supergdu_w_area_csv_file = r"area_of_each_SuperGDU_feature_test_2_Cao_et_al_2023_5000km_polygid_20231222.csv"
	field_for_area = "Area_Sqkm"
	from_time_input_file = 1795.0
	to_time_input_file = 0.0
	interval_input_file = 5.0
	modelname = 'test_2_Cao_et_al_2023_5000km_polygid'
	yearmonthday = '20231227'
	number_of_top_biggest_SGDUs = 5
	#area_of_the_n_biggest_and_total_area_and_total_number_of_SuperGDUs_within_period(number_of_top_biggest_SGDUs, supergdu_w_area_csv_file, field_for_area, from_time_input_file, to_time_input_file, interval_input_file, modelname, yearmonthday)
	
	# supergdu_w_area_csv_file = r"area_of_each_SuperGDU_feature_test_2_Merdith_et_al_2021_5000km_polygid_20231222.csv"
	# field_for_area = "Area_Sqkm"
	# from_time_input_file = 995.0
	# to_time_input_file = 0.0
	# interval_input_file = 5.0
	# modelname = 'test_2_Merdith_et_al_2000km_polygid'
	# yearmonthday = '20231222'
	# number_of_top_biggest_SGDUs = 5
	# area_of_the_n_biggest_and_total_area_and_total_number_of_SuperGDUs_within_period(number_of_top_biggest_SGDUs, supergdu_w_area_csv_file, field_for_area, from_time_input_file, to_time_input_file, interval_input_file, modelname, yearmonthday)
	
	supergdu_w_area_csv_file = r"area_of_each_SuperGDU_feature_test_2_Scotese_PaleoAtlas_v3_2016_5000km_polygid_20231222.csv"
	field_for_area = "Area_Sqkm"
	from_time_input_file = 1095.0
	to_time_input_file = 0.0
	interval_input_file = 5.0
	modelname = 'test_2_PALEOMAP_2016_5000km_polygid'
	yearmonthday = '20231222'
	number_of_top_biggest_SGDUs = 5
	#area_of_the_n_biggest_and_total_area_and_total_number_of_SuperGDUs_within_period(number_of_top_biggest_SGDUs, supergdu_w_area_csv_file, field_for_area, from_time_input_file, to_time_input_file, interval_input_file, modelname, yearmonthday)
	
	supergdu_w_area_csv_file = r"area_of_each_SuperGDU_feature_based_on_polygid_test_9_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_5000km_polygid_20231221.csv"
	field_for_area = "Area_Sqkm"
	from_time_input_file = 3415.0
	to_time_input_file = 0.0
	interval_input_file = 5.0
	modelname = 'test_9_PalaeoPlatesendJan2023_5000km_polygid'
	yearmonthday = '20231221'
	number_of_top_biggest_SGDUs = 5
	#area_of_the_n_biggest_and_total_area_and_total_number_of_SuperGDUs_within_period(number_of_top_biggest_SGDUs, supergdu_w_area_csv_file, field_for_area, from_time_input_file, to_time_input_file, interval_input_file, modelname, yearmonthday)
	
	common_filename_for_supergdu_and_members_csv = r"supergdu_and_members_gdu_at_{time}_for_test_4_PalaeoPlatesFeb2024_w_valid_rot_10000km_20240228.csv"
	final_supergdu_csv = r"final_supergdus_from_3000.0_0.0_for_test_4_PalaeoPlatesFeb2024_w_valid_rot_10000km_polygid_20240228.csv"
	present_date_GDU_features_epsg_4326_shp = r"../all_gdu_features_w_all_valid_attributes_PalaeoPlatesFeb2024_20240214.shp"
	crs_in_epsg = "ESRI:54009"
	field_for_from_age_shp = 'LimOldP'
	field_for_to_age_shp = 'LimYngP'
	field_for_plateid_or_gduid_or_polygid_shp = 'POLYGID'
	is_special_due_to_GPlates = False
	is_polygid = True
	modelname = 'based_on_polygid_test_4_PalaeoPlatesFeb2024_w_valid_rot_10000km_polygid'
	yearmonthday = '20240228'
	area_of_each_SuperGDU_feature(common_filename_for_supergdu_and_members_csv, final_supergdu_csv, present_date_GDU_features_epsg_4326_shp, crs_in_epsg, field_for_from_age_shp, field_for_to_age_shp, field_for_plateid_or_gduid_or_polygid_shp, is_polygid, is_special_due_to_GPlates, modelname, yearmonthday)

	supergdu_w_area_csv_file = r"area_of_each_SuperGDU_feature_based_on_polygid_test_4_PalaeoPlatesFeb2024_w_valid_rot_10000km_polygid_20240228.csv"
	field_for_area = "Area_Sqkm"
	from_time_input_file = 3000.0
	to_time_input_file = 0.0
	interval_input_file = 5.0
	area_of_the_3_biggest_and_total_area_and_total_number_of_SuperGDUs_within_period(supergdu_w_area_csv_file, field_for_area, from_time_input_file, to_time_input_file, interval_input_file, modelname, yearmonthday)
	
if __name__=='__main__':
	main()

