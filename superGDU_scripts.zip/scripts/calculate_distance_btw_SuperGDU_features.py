import os
import csv
import math
#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.errors import TopologicalError
from shapely.geometry import Point, Polygon, LineString, MultiPoint, MultiPolygon, LinearRing
from shapely.ops import unary_union, transform, cascaded_union, polygonize, polygonize_full, linemerge, triangulate 
from functools import partial
from shapely.validation import explain_validity
import pyproj

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def convert_Polygon_to_PolygonOnSphere_in_pygplates(each_polygon):
	if (each_polygon.area > 0.00):
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			#print("lat,lon")
			#print(lat,lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
				print("Warning invalid value of latitude or/and longitude")
				print("value of latitude")
				print(lat)
				print("value of longitude")
				print(lon)
				if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
					if (abs(abs(lat) - 90.00) < 0.500):
						if (lat < -90.00):
							lat = -90.000
						elif (lat > 90.00):
							lat = 90.000
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of latitude")
						print("value of latitude")
						print(lat)					
						exit()
				if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
					if (abs(abs(lon) - 180.00) < 0.500):
						if (lon < -180.00):
							lon = -180.00
						elif (lon > 180.00):
							lon = 180.00
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of longitude")
						print("value of longitude")
						print(lon)					
						exit()
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print("Error in creating polygon in pygplates in conversion module")
			print("Here is a list of lat_lon vertices")
			print(list_of_lat_lon_vertices)
			print("Here is the first vertex and the last vertex:")
			print(list_of_lat_lon_vertices[0])
			print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
			exit()
		return new_polygon
	else:
		print("Error in creating polygon in pygplates in conversion module")
		print("Error each_polygon.area <= 0.00")
		print("here is each_polygon")
		print(each_polygon)
		print([(lon,lat) for lon,lat in each_polygon.exterior.coords])
		exit()


def convert_polygon_to_Polygon_in_shapely(each_polygon):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in each_polygon.to_lat_lon_list()]
	new_polygon = Polygon(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating Polygon in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_polygon


def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = mean(lat_values)
				mean_lon = mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def calculate_distance_between_SuperGDU_features_w_haversine_formula(supergdu_features,begin_reconstruction_time,end_reconstruction_time,time_interval,rotation_model,reference,modelname,yearmonthday):
	results = []
	reconstructed_polygon_features = []
	already_process_pairs_of_supergdus = []
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		reconstructed_polygon_features[:]=[]
		already_process_pairs_of_supergdus[:]=[]
		valid_supergdu_features = [supergdu_ft for supergdu_ft in supergdu_features if supergdu_ft.is_valid_at_time(reconstruction_time)]
		if (reference is not None):
			pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
		final_reconstructed_sgdu_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
		for sgdu_ft_1,sgdu_1 in final_reconstructed_sgdu_features:
			sgdu_1_name = sgdu_ft_1.get_name()
			list_of_sgdu_1 = []
			for temp_sgdu_ft_1,temp_sgdu_1 in final_reconstructed_sgdu_features:
				if (temp_sgdu_ft_1.get_name() == sgdu_1_name):
					list_of_sgdu_1.append(temp_sgdu_1)
			for sgdu_ft_2,sgdu_2 in final_reconstructed_sgdu_features:
				sgdu_2_name = sgdu_ft_2.get_name()
				list_of_sgdu_2 = []
				if (sgdu_1_name == sgdu_2_name):
					continue
				key = sgdu_1_name+'_'+sgdu_2_name
				reverse_key = sgdu_2_name+'_'+sgdu_1_name
				list_of_values_for_distance_btw_sgdus = None
				if (key not in already_process_pairs_of_supergdus and reverse_key not in already_process_pairs_of_supergdus):
					already_process_pairs_of_supergdus.append(key)
					for temp_sgdu_ft_2,temp_sgdu_2 in final_reconstructed_sgdu_features:
						if (temp_sgdu_ft_2.get_name() == sgdu_2_name):
							list_of_sgdu_2.append(temp_sgdu_2)
					list_of_values_for_distance_btw_sgdus = []
					lat1,lon1=None,None
					lat2,lon2=None,None
					for temp_sgdu_1 in list_of_sgdu_1:
						for temp_sgdu_2 in list_of_sgdu_2:
							distance_radians, closest_point_on_sgdu1, closest_point_on_sgdu2 = pygplates.GeometryOnSphere.distance(temp_sgdu_1, temp_sgdu_2, return_closest_positions=True)
							if (distance_radians > 0.00):
								lat1,lon1 = closest_point_on_sgdu1.to_lat_lon()
								lat2,lon2 = closest_point_on_sgdu2.to_lat_lon()
								dist_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
								list_of_values_for_distance_btw_sgdus.append(dist_km)
								#results.append((reconstruction_time,sgdu_1_name,sgdu_2_name,dist_km,lat1,lon1,lat2,lon2))
							else:
								lat1,lon1 = closest_point_on_sgdu1.to_lat_lon()
								lat2,lon2 = closest_point_on_sgdu2.to_lat_lon()
								list_of_values_for_distance_btw_sgdus.append(0.00)
								#results.append((reconstruction_time,sgdu_1_name,sgdu_2_name,0.00,lat1,lon1,lat2,lon2))
				if (list_of_values_for_distance_btw_sgdus is not None):
					list_of_values_for_distance_btw_sgdus.sort()
					smallest_distance = list_of_values_for_distance_btw_sgdus[0]
					results.append((reconstruction_time,sgdu_1_name,sgdu_2_name,smallest_distance,lat1,lon1,lat2,lon2))
		reconstruction_time = reconstruction_time - time_interval
	new_dataframe = pd.DataFrame.from_records(results, columns = ['reconstruction_time','SGDU_1','SGDU_2','dist_km','lat1','lon1','lat2','lon2'])
	print(new_dataframe)
	filename = modelname+'_smallest_dist_km_btw_valid_sgdu_feats_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+str(time_interval)+"_"+yearmonthday+'.csv'
	new_dataframe.to_csv(filename,index=False)

def main():
	supergdu_features_file = r"final_supergdu_feats_3420.0_0.0_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.shp"
	supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
	begin_reconstruction_time = 3420.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	rotation_file = r"../T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	yearmonthday = "20230224"
	modelname ="QGISfixedPalaeoPlatesendJan2023"
	calculate_distance_between_SuperGDU_features_w_haversine_formula(supergdu_features,begin_reconstruction_time,end_reconstruction_time,time_interval,rotation_model,reference,modelname,yearmonthday)

if __name__=='__main__':

	main()
