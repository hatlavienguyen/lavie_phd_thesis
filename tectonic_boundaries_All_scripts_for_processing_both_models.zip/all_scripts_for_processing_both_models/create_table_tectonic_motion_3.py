#!/usr/bin/python
import psycopg2
from config_plate_tectonics import config
def create_table_tectonic_motion():
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE tectonic_motion(
				id SERIAL,
				time NUMERIC,
				ref_GDU_ID INTEGER,
				other_GDU_ID INTEGER,
				ref_ft_id VARCHAR (255) NOT NULL,
				other_ft_id VARCHAR (255) NOT NULL,
				result_from_dist_eval VARCHAR (100) NOT NULL,
				result_from_vec_eval VARCHAR (100) NOT NULL,
				tectonic_motion_for_boundaries VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
def create_table_tectonic_boundaries(): #tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, tectonic_motion)
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE tectonic_boundaries(
				id SERIAL,
				time NUMERIC NOT NULL,
				ref_GDU_ID INTEGER NOT NULL,
				other_GDU_ID INTEGER NOT NULL,
				line_1_ft_id VARCHAR (255) NOT NULL,
				line_2_ft_id VARCHAR (255) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_not_recorded_tectonic_boundaries_during_identification(): #tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, tectonic_motion)
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE not_recorded_tectonic_boundaries_during_identification(
				id SERIAL,
				time NUMERIC NOT NULL,
				ref_GDU_ID INTEGER NOT NULL,
				other_GDU_ID INTEGER NOT NULL,
				line_1_ft_id VARCHAR (255) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_summary_of_not_initially_recorded_tectonic_boundaries(): #tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, tectonic_motion)
	""" create table in the PostgreSQL database """ 
	commands = [
		""" CREATE TABLE summary_of_not_initially_recorded_tectonic_boundaries(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				ref_GDU_ID INTEGER NOT NULL,
				other_GDU_ID INTEGER NOT NULL)
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_summary_of_tectonic_boundaries_and_motion(): #tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, tectonic_motion)
	""" create table in the PostgreSQL database """ 
	commands = [
		""" CREATE TABLE test_final_summary_of_tectonic_boundaries_and_motion(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				ref_gdu_id INTEGER NOT NULL,
				other_gdu_id INTEGER NOT NULL)
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_extended_final_summary_of_tectonic_boundaries_and_motion(): #tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, tectonic_motion)
	""" create table in the PostgreSQL database """ 
	commands = [
		""" CREATE TABLE test_extended_final_summary_of_tectonic_boundaries_and_motion(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				ref_gdu_id INTEGER NOT NULL,
				other_gdu_id INTEGER NOT NULL)
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_not_found_tectonic_boundaries(): 
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE not_found_tectonic_boundaries(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				line_1_ft_id VARCHAR (255) NOT NULL,
				line_2_ft_id VARCHAR (255) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_summary_of_tectonic_boundaries(): 
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE summary_of_tectonic_boundaries(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				line_1_ft_id VARCHAR (255) NOT NULL,
				line_2_ft_id VARCHAR (255) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_not_found_tectonic_boundaries_after_first_run(): 
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE not_found_tectonic_boundaries_after_first_run(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				line_1_ft_id VARCHAR (255) NOT NULL,
				line_2_ft_id VARCHAR (255) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_summary_of_tectonic_boundaries_after_first_run(): 
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE summary_of_tectonic_boundaries_after_first_run(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				line_1_ft_id VARCHAR (255) NOT NULL,
				line_2_ft_id VARCHAR (255) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_not_found_tectonic_boundaries_after_second_run(): 
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE not_found_tectonic_boundaries_after_second_run(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				line_1_ft_id VARCHAR (255) NOT NULL,
				line_2_ft_id VARCHAR (255) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_summary_of_tectonic_boundaries_after_second_run(): 
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE summary_of_tectonic_boundaries_after_second_run(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL,
				line_1_ft_id VARCHAR (255) NOT NULL,
				line_2_ft_id VARCHAR (255) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_tectonic_motion_test():
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE tectonic_motion_test (
				id INTEGER,
				time NUMERIC,
				ref_GDU_ID INTEGER,
				other_GDU_ID INTEGER,
				ref_ft_id VARCHAR (255) NOT NULL,
				other_ft_id VARCHAR (255) NOT NULL,
				result_from_dist_eval VARCHAR (100) NOT NULL,
				result_from_vec_eval VARCHAR (100) NOT NULL,
				tectonic_motion_for_boundaries VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_suspecting_tectonic_motion():
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE suspecting_tectonic_motion (
				id SERIAL,
				time NUMERIC,
				ref_GDU_ID INTEGER,
				other_GDU_ID INTEGER,
				ref_ft_id VARCHAR (255) NOT NULL,
				other_ft_id VARCHAR (255) NOT NULL,
				result_from_dist_eval VARCHAR (100) NOT NULL,
				result_from_vec_eval VARCHAR (100) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_equivalent_stage_rotation(): #from_time, to_time, member_GDU_ID, anchor_plate_id, pole_latitude, pole_longitude, angle_degrees
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE equivalent_stage_rotation (
				from_time NUMERIC,
				to_time NUMERIC,
				member_GDU_ID INTEGER,
				anchor_plate_id INTEGER,
				pole_latitude NUMERIC,
				pole_longitude NUMERIC,
				angle_degrees NUMERIC) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_relative_stage_rotation(): #relative_stage_rotation (from_time, to_time, moving_plate_ID, fixed_plate_ID, anchor_plate_id, pole_latitude, pole_longitude, angle_degrees)
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE relative_stage_rotation (
				from_time NUMERIC,
				to_time NUMERIC,
				moving_plate_ID INTEGER,
				fixed_plate_ID INTEGER,
				anchor_plate_id INTEGER,
				pole_latitude NUMERIC,
				pole_longitude NUMERIC,
				angle_degrees NUMERIC) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_super_GDU_spatial_members(): #time, Super_GDU_id_string, GDU_id, GDU_ft_id
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE super_GDU_spatial_members (
				time NUMERIC,
				Super_GDU_id_string VARCHAR (100),
				GDU_id INTEGER,
				GDU_ft_id VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
def create_table_super_GDU_spatial_members_with_polygons():
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE super_GDU_spatial_members_with_polygons (
				time NUMERIC,
				Super_GDU_id_string VARCHAR (100),
				Super_GDU_ft_id VARCHAR (100),
				GDU_id INTEGER,
				GDU_ft_id VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_super_GDU_spatial_members(): #time, Super_GDU_id_string, GDU_id, GDU_ft_id
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE super_GDU_spatial_members (
				time NUMERIC,
				Super_GDU_id_string VARCHAR (100),
				GDU_id INTEGER,
				GDU_ft_id VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
def create_table_super_GDU_and_members_id():
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE super_GDU_and_members_id (
				from_time NUMERIC,
				to_time NUMERIC,
				Super_GDU_id INTEGER,
				GDU_id_member INTEGER,
				buffer_distance_km NUMERIC)
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_temp_super_GDU_and_members_id():
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE temp_super_GDU_and_members_id (
				from_time NUMERIC,
				to_time NUMERIC,
				Super_GDU_id INTEGER,
				GDU_id_member INTEGER,
				buffer_distance_km NUMERIC,
				represent_gdu_id INTEGER)
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_final_super_GDU():
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE temp_final_super_gdu_id_2 (
				from_time NUMERIC,
				to_time NUMERIC,
				super_gdu_id INTEGER,
				represent_gdu_id INTEGER,
				buffer_distance_km NUMERIC) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_geological_topological_line():
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE geological_topological_line_fts(
				time NUMERIC,
				GDU_ID INTEGER,
				lef_GDU_ID INTEGER,
				right_GDU_ID INTEGER,
				initial_ft_id VARCHAR (255) NOT NULL,
				type_of_line_fts VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
def create_table_summary_of_tectonic_motion():
	""" create table in the PostgreSQL database """ 
	commands = [
		""" CREATE TABLE summary_of_tectonic_motion(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				ref_gdu_id INTEGER NOT NULL,
				other_gdu_id INTEGER NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
			
def create_table_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion():
	""" create table in the PostgreSQL database """
	commands = [""" CREATE TABLE summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				ref_gdu_id INTEGER NOT NULL,
				other_gdu_id INTEGER NOT NULL,
				line_1_ft_name VARCHAR (255) NOT NULL,
				line_2_ft_name VARCHAR (255) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_temporal_output_tectonic_boundaries_during_identification():
	""" create table in the PostgreSQL database """ 
	commands = [
		""" CREATE TABLE temporal_output_tectonic_boundaries_during_identification(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				ref_gdu_id INTEGER NOT NULL,
				other_gdu_id INTEGER NOT NULL,
				left_gdu_id INTEGER NOT NULL,
				right_gdu_id INTEGER NOT NULL,
				line_ft_id VARCHAR(100) NOT NULL,
				line_ft_name VARCHAR(100),
				tectonic_motion VARCHAR (100) NOT NULL,
				type VARCHAR (100) NOT NULL) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_tectonic_motion_at_each_time():#reconstruction_time,reference_feature_id,neighbour_ft_id,tectonic_motion
	""" create table in the PostgreSQL database """
	commands = [
		""" CREATE TABLE tectonic_motion_at_each_time (
				id SERIAL,
				time NUMERIC,
				ref_gdu_id INTEGER,
				neighbour_gdu_id INTEGER,
				ref_ft_id VARCHAR (255) NOT NULL,
				neighbour_ft_id VARCHAR (255) NOT NULL,
				tectonic_motion VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_pairs_of_line_features_at_each_time(is_reversed):
	#time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, first_line_name, second_line_name, first_line_gdu, second_line_gdu, at_angular_radius
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE pairs_of_line_features_at_each_time (
				id SERIAL,
				time NUMERIC,
				first_superGDU_represent_id INTEGER,
				first_superGDU_name VARCHAR(100),
				second_superGDU_represent_id INTEGER,
				second_superGDU_name VARCHAR(100),
				first_line_name VARCHAR (100),
				second_line_name VARCHAR (100),
				first_line_gdu INTEGER,
				second_line_gdu INTEGER,
				at_angular_radius NUMERIC) 
		"""]
	else:
		commands = [
		""" CREATE TABLE pairs_of_line_features_at_each_time_reversed_2 (
				id SERIAL,
				time NUMERIC,
				first_superGDU_represent_id INTEGER,
				first_superGDU_name VARCHAR(100),
				second_superGDU_represent_id INTEGER,
				second_superGDU_name VARCHAR(100),
				first_line_name VARCHAR (100),
				second_line_name VARCHAR (100),
				first_line_gdu INTEGER,
				second_line_gdu INTEGER,
				at_angular_radius NUMERIC) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_rel_pos_vel_vector_motion_at_each_time(is_reversed):
	#time,ref_ft_id,neighbour_ft_id,tectonic_motion
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE rel_pos_vel_vector_motion_at_each_time (
				id SERIAL,
				time NUMERIC,
				ref_ft_id VARCHAR(100),
				neighbour_ft_id VARCHAR(100),
				tectonic_motion VARCHAR (100)) 
		"""]
	else:
		commands = [
		""" CREATE TABLE rel_pos_vel_vector_motion_at_each_time_reversed_2 (
				id SERIAL,
				time NUMERIC,
				ref_ft_id VARCHAR(100),
				neighbour_ft_id VARCHAR(100),
				tectonic_motion VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_closest_boundary_rel_pos_vel_vector_motion_at_each_time(is_reversed):
	#time,ref_ft_id,neighbour_ft_id,tectonic_motion
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE closest_boundary_rel_pos_vel_vector_motion_at_each_time (
				id SERIAL,
				time NUMERIC,
				ref_ft_id VARCHAR(100),
				neighbour_ft_id VARCHAR(100),
				tectonic_motion VARCHAR (100)) 
		"""]
	else:
		commands = [
		""" CREATE TABLE closest_boundary_rel_pos_vel_vector_motion_at_each_time_reversed_2 (
				id SERIAL,
				time NUMERIC,
				ref_ft_id VARCHAR(100),
				neighbour_ft_id VARCHAR(100),
				tectonic_motion VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_summary_of_tectonic_boundaries_from_rel_pos_vect():
	""" create table in the PostgreSQL database """ 
	commands = [
		""" CREATE TABLE summary_of_tectonic_boundaries_from_rel_pos_vect_2(
				id SERIAL,
				from_time NUMERIC NOT NULL,
				to_time NUMERIC NOT NULL,
				tectonic_motion VARCHAR (100) NOT NULL,
				ref_ft_id VARCHAR (255) NOT NULL,
				neighbour_ft_id VARCHAR (255) NOT NULL,
				ref_gdu_id INTEGER NOT NULL,
				neighbour_gdu_id INTEGER NOT NULL)
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_summary_of_tectonic_boundaries_from_rel_pos_vect(is_reversed):
	""" create table in the PostgreSQL database """ 
	if (is_reversed == False):
		commands = [
			""" CREATE TABLE summary_of_tectonic_boundaries_from_rel_pos_vect(
					id SERIAL,
					from_time NUMERIC NOT NULL,
					to_time NUMERIC NOT NULL,
					tectonic_motion VARCHAR (100) NOT NULL,
					ref_ft_id VARCHAR (255) NOT NULL,
					neighbour_ft_id VARCHAR (255) NOT NULL,
					ref_gdu_id INTEGER NOT NULL,
					neighbour_gdu_id INTEGER NOT NULL)
			"""]
	else:
		commands = [
			""" CREATE TABLE summary_of_tectonic_boundaries_from_rel_pos_vect_reversed(
					id SERIAL,
					from_time NUMERIC NOT NULL,
					to_time NUMERIC NOT NULL,
					tectonic_motion VARCHAR (100) NOT NULL,
					ref_ft_id VARCHAR (255) NOT NULL,
					neighbour_ft_id VARCHAR (255) NOT NULL,
					ref_gdu_id INTEGER NOT NULL,
					neighbour_gdu_id INTEGER NOT NULL)
			"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_temp_tectonic_boundaries_from_rel_pos_vect(is_reversed):
	""" create table in the PostgreSQL database """ 
	if (is_reversed == False):
		commands = [
			""" CREATE TABLE temp_tectonic_boundaries_from_rel_pos_vect(
					id SERIAL,
					from_time NUMERIC NOT NULL,
					to_time NUMERIC NOT NULL,
					tectonic_motion VARCHAR (100) NOT NULL,
					ref_ft_id VARCHAR (255) NOT NULL,
					neighbour_ft_id VARCHAR (255) NOT NULL,
					ref_gdu_id INTEGER NOT NULL,
					neighbour_gdu_id INTEGER NOT NULL)
			"""]
	else:
		commands = [
			""" CREATE TABLE temp_tectonic_boundaries_from_rel_pos_vect_reversed(
					id SERIAL,
					from_time NUMERIC NOT NULL,
					to_time NUMERIC NOT NULL,
					tectonic_motion VARCHAR (100) NOT NULL,
					ref_ft_id VARCHAR (255) NOT NULL,
					neighbour_ft_id VARCHAR (255) NOT NULL,
					ref_gdu_id INTEGER NOT NULL,
					neighbour_gdu_id INTEGER NOT NULL)
			"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
def create_table_subsequent_rel_pos_vect(is_reversed):
		#time,ref_ft_id,neighbour_ft_id,tectonic_motion
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE subsequent_rel_pos_vel_vector_motion_at_each_time (
				id SERIAL,
				time NUMERIC,
				ref_ft_id VARCHAR(100),
				neighbour_ft_id VARCHAR(100),
				tectonic_motion VARCHAR (100)) 
		"""]
	else:
		commands = [
		""" CREATE TABLE subsequent_rel_pos_vel_vector_motion_at_each_time_reversed (
				id SERIAL,
				time NUMERIC,
				ref_ft_id VARCHAR(100),
				neighbour_ft_id VARCHAR(100),
				tectonic_motion VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_passive_boundaries(is_reversed):
		#time,ref_ft_id,neighbour_ft_id,tectonic_motion
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE passive_boundaries_from_rel_pos_vel_vector_motion_at_each_time (
				id SERIAL,
				time NUMERIC,
				ref_ft_id VARCHAR(100),
				neighbour_ft_id VARCHAR(100),
				tectonic_motion VARCHAR (100)) 
		"""]
	else:
		commands = [
		""" CREATE TABLE passive_boundaries_from_rel_pos_vel_vector_motion_at_each_time_reversed (
				id SERIAL,
				time NUMERIC,
				ref_ft_id VARCHAR(100),
				neighbour_ft_id VARCHAR(100),
				tectonic_motion VARCHAR (100)) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_MOR_location_fts(is_reversed):
#(time,MOR_ft_id,first_superGDU_represent_id,second_superGDU_represent_id,first_superGDU_name,second_superGDU_name,ref_ft_id,neighbour_ft_id,at_angular_radius)
	#time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, first_line_name, second_line_name, first_line_gdu, second_line_gdu, at_angular_radius
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE MOR_location_fts_at_each_time (
				id SERIAL,
				time NUMERIC,
				MOR_ft_id VARCHAR(100),
				first_superGDU_represent_id INTEGER,
				first_superGDU_name VARCHAR(100),
				second_superGDU_represent_id INTEGER,
				second_superGDU_name VARCHAR(100),
				first_line_name VARCHAR (100),
				second_line_name VARCHAR (100),
				at_angular_radius NUMERIC) 
		"""]
	else:
		commands = [
		""" CREATE TABLE MOR_location_fts_at_each_time_reversed_2 (
				id SERIAL,
				time NUMERIC,
				MOR_ft_id VARCHAR(100),
				first_superGDU_represent_id INTEGER,
				first_superGDU_name VARCHAR(100),
				second_superGDU_represent_id INTEGER,
				second_superGDU_name VARCHAR(100),
				first_line_name VARCHAR (100),
				second_line_name VARCHAR (100),
				at_angular_radius NUMERIC) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_recover_MOR_location_fts(is_reversed):
#(time,MOR_ft_id,first_superGDU_represent_id,second_superGDU_represent_id,first_superGDU_name,second_superGDU_name,ref_ft_id,neighbour_ft_id,at_angular_radius)
	#time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, first_line_name, second_line_name, first_line_gdu, second_line_gdu, at_angular_radius
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE recover_MOR_location_fts_at_each_time (
				id SERIAL,
				time NUMERIC,
				MOR_ft_id VARCHAR(100),
				first_superGDU_represent_id INTEGER,
				first_superGDU_name VARCHAR(100),
				second_superGDU_represent_id INTEGER,
				second_superGDU_name VARCHAR(100),
				first_line_name VARCHAR (100),
				second_line_name VARCHAR (100),
				at_angular_radius NUMERIC) 
		"""]
	else:
		commands = [
		""" CREATE TABLE recover_MOR_location_fts_at_each_time_reversed (
				id SERIAL,
				time NUMERIC,
				MOR_ft_id VARCHAR(100),
				first_superGDU_represent_id INTEGER,
				first_superGDU_name VARCHAR(100),
				second_superGDU_represent_id INTEGER,
				second_superGDU_name VARCHAR(100),
				first_line_name VARCHAR (100),
				second_line_name VARCHAR (100),
				at_angular_radius NUMERIC) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_div_location_fts(is_reversed):#time,MOR_ft_id,left_div_gdu,right_div_gdu,left_div_ft,right_div_ft
#(time,MOR_ft_id,first_superGDU_represent_id,second_superGDU_represent_id,first_superGDU_name,second_superGDU_name,ref_ft_id,neighbour_ft_id,at_angular_radius)
	#time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, first_line_name, second_line_name, first_line_gdu, second_line_gdu, at_angular_radius
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE div_location_fts_at_each_time (
				id SERIAL,
				time NUMERIC,
				MOR_ft_id VARCHAR(100),
				left_div_gdu INTEGER,
				right_div_gdu INTEGER,
				left_div_ft VARCHAR(100),
				right_div_ft VARCHAR (100),
				at_angular_radius NUMERIC) 
		"""]
	else:
		commands = [
		""" CREATE TABLE div_location_fts_at_each_time_reversed_2 (
				id SERIAL,
				time NUMERIC,
				MOR_ft_id VARCHAR(100),
				left_div_gdu INTEGER,
				right_div_gdu INTEGER,
				left_div_ft VARCHAR(100),
				right_div_ft VARCHAR (100),
				at_angular_radius NUMERIC) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
			
def create_table_recover_div_location_fts(is_reversed):#time,MOR_ft_id,left_div_gdu,right_div_gdu,left_div_ft,right_div_ft
#(time,MOR_ft_id,first_superGDU_represent_id,second_superGDU_represent_id,first_superGDU_name,second_superGDU_name,ref_ft_id,neighbour_ft_id,at_angular_radius)
	#time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, first_line_name, second_line_name, first_line_gdu, second_line_gdu, at_angular_radius
	""" create table in the PostgreSQL database """
	commands = None
	if (is_reversed == False):
		commands = [
		""" CREATE TABLE recover_div_location_fts_at_each_time (
				id SERIAL,
				time NUMERIC,
				MOR_ft_id VARCHAR(100),
				left_div_gdu INTEGER,
				right_div_gdu INTEGER,
				left_div_ft VARCHAR(100),
				right_div_ft VARCHAR (100),
				at_angular_radius NUMERIC) 
		"""]
	else:
		commands = [
		""" CREATE TABLE recover_div_location_fts_at_each_time_reversed (
				id SERIAL,
				time NUMERIC,
				MOR_ft_id VARCHAR(100),
				left_div_gdu INTEGER,
				right_div_gdu INTEGER,
				left_div_ft VARCHAR(100),
				right_div_ft VARCHAR (100),
				at_angular_radius NUMERIC) 
		"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()

def create_table_summary_of_MOR_location_fts(is_reversed):#parent_SuperGDUs,from_time,to_time,order,MOR_loc_ft_id
	""" create table in the PostgreSQL database """ 
	if (is_reversed == False):
		commands = [
			""" CREATE TABLE summary_of_MOR_location_fts(
					id SERIAL,
					parent_SuperGDUs VARCHAR (100),
					from_time NUMERIC NOT NULL,
					to_time NUMERIC NOT NULL,
					at_angular_radius NUMERIC NOT NULL,
					ini_mor_ft_id VARCHAR (255) NOT NULL,
					new_mor_ft_id VARCHAR (255) NOT NULL)
			"""]
	else:
		commands = [
			""" CREATE TABLE summary_of_MOR_location_fts_reversed(
					id SERIAL,
					parent_SuperGDUs VARCHAR (100),
					from_time NUMERIC NOT NULL,
					to_time NUMERIC NOT NULL,
					at_angular_radius NUMERIC NOT NULL,
					ini_mor_ft_id VARCHAR (255) NOT NULL,
					new_mor_ft_id VARCHAR (255) NOT NULL)
			"""]
	#print commands
	
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		#create table from the cursor object
		for command in commands:
			print (command)
			cur.execute(command)
		#close communication with the PostgreSQL database
		cur.close()
		#commit the changes
		conn.commit()
	except (Exception, psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
			
if __name__ == '__main__':
	#create_table_rel_pos_vel_vector_motion_at_each_time(True)
	#create_table_closest_boundary_rel_pos_vel_vector_motion_at_each_time(True)
	#create_table_pairs_of_line_features_at_each_time(True)
	#create_table_MOR_location_fts(True)
	#create_table_div_location_fts(True)
	#create_table_recover_div_location_fts(True)
	#create_table_recover_MOR_location_fts(True)
	#create_table_summary_of_tectonic_boundaries_from_rel_pos_vect()
	#create_table_temp_tectonic_boundaries_from_rel_pos_vect(True)
	#create_table_subsequent_rel_pos_vect(True)
	#create_table_passive_boundaries(True)
	create_table_summary_of_MOR_location_fts(True)
	#create_table_tectonic_motion()
	#create_table_tectonic_motion_test()
	#create_table_tectonic_motion_at_each_time()
	#create_table_tectonic_boundaries()
	#create_table_not_found_tectonic_boundaries()
	#create_table_summary_of_tectonic_boundaries()
	#create_table_not_found_tectonic_boundaries_after_first_run()
	#create_table_summary_of_tectonic_boundaries_after_first_run()
	#create_table_not_found_tectonic_boundaries_after_second_run()
	#create_table_summary_of_tectonic_boundaries_after_second_run()
	#create_table_not_recorded_tectonic_boundaries_during_identification()
	#create_table_summary_of_not_initially_recorded_tectonic_boundaries()
	#create_table_summary_of_tectonic_boundaries_and_motion()test_extendted_final_summary_of_tectonic_boundaries_and_motion
	#create_table_extended_final_summary_of_tectonic_boundaries_and_motion()
	#create_table_summary_of_tectonic_motion()
	#create_table_equivalent_stage_rotation()
	#create_table_relative_stage_rotation()
	#create_table_super_GDU_spatial_members()
	#create_table_super_GDU_spatial_members_with_polygons()
	#create_table_super_GDU_and_members_id()
	#create_table_temp_super_GDU_and_members_id()
	#create_table_final_super_GDU()
	#create_table_suspecting_tectonic_motion()
	#create_table_geological_topological_line()
	#create_table_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion()
	#create_table_temporal_output_tectonic_boundaries_during_identification()