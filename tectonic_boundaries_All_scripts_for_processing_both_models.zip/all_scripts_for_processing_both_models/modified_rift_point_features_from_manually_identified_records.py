import pygplates
import create_remnant_of_previous_MOR as create_remnant

def main():
	temp_rift_point_features_file = r"rift_point_features_from_manually_identified_records_PalaeoPlatesendJan2023_20240323.shp"
	temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
	rift_point_features_records_csv = r"manually_approx_rift_point_features.csv"
	conv_and_plate_boundary_zone_boundaries_file = r"all_conv_margin_and_plate_bdn_zone_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240301.shp"
	conv_and_plate_boundary_zone_boundaries = pygplates.FeatureCollection(conv_and_plate_boundary_zone_boundaries_file)
	sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	time_interval = 5.00
	max_reconstruction_time_for_start_div = 2800.0
	min_reconstruction_time_for_start_div = 0.00
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	yearmonthday = "20240324"
	modelname = "test_1_manually_identified_records_for_PalaeoPlatesendJan2023"
	create_remnant.create_isochron_from_temp_rift_point_features(temp_rift_point_features, rift_point_features_records_csv, conv_and_plate_boundary_zone_boundaries, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

if __name__=="__main__":
	main()