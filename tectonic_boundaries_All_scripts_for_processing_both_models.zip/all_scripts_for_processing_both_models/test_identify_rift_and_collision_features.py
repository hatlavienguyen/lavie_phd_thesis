#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import identify_rift_and_collision_features as rift_and_collision
def main():
	con_ocn_line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_26_valid_single_dissolved_merged_POLGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230509.shp"
	con_ocn_line_features = pygplates.FeatureCollection(con_ocn_line_features_file)
	begin_reconstruction_time = 3000.0
	end_reconstruction_time = 0.00
	time_interval = 5.00
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	threshold_prox_distance_km = 50.00
	modelname = 'PalaeoPlatesendJan2023'
	yearmonthday = '20230613'
	rift_and_collision.find_rift_and_collision_line_features(con_ocn_line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, threshold_prox_distance_km, modelname, yearmonthday)

if __name__=='__main__':
	main()