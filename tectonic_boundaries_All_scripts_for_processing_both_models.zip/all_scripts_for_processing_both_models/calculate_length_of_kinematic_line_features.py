import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
#import calculate_properties_of_polygon_features as calculate_prop
import os
import geopandas as gpd
import pandas as pd


def calculate_length_of_line_features_w_Geopandas(input_line_features_shp,epsg_code,name_of_line_features,yearmonthday):
	gdf = gpd.read_file(input_line_features_shp)
	projected_gdf = gdf.to_crs(epsg_code)
	reconstructed_polygon_features = []
	projected_gdf['Lengthm'] = projected_gdf.geometry.length
	projected_gdf['DemoEndAge'] = 0.00
	projected_gdf.to_file('lengthm_w_Geopandas_'+name_of_line_features+'_'+yearmonthday+'.shp')

def reconstruct_line_features_to_each_reconstruction_time_and_calculate_length(line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, epsg_code, name_of_line_features, yearmonthday):
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		valid_line_features = [line_ft for line_ft in line_features if line_ft.is_valid_at_time(reconstruction_time)]
		if (len(valid_line_features) > 0):
			reconstructed_filename = 'reconstructed_line_fts_'+name_of_line_features+'_'+str(reconstruction_time)+'.shp'
			if (reference is not None):
				pygplates.reconstruct(valid_line_features, rotation_model, reconstructed_filename, reconstruction_time, anchor_plate_id = reference)
			else:
				pygplates.reconstruct(valid_line_features, rotation_model, reconstructed_filename, reconstruction_time)
			if (os.path.isfile(reconstructed_filename)):
				output_filename = name_of_line_features+'_'+str(reconstruction_time)
				calculate_length_of_line_features_w_Geopandas(reconstructed_filename,epsg_code,output_filename,yearmonthday)
		#update reconstruction_time 
		reconstruction_time = reconstruction_time - time_interval

def perform_simple_statistics_on_length_of_each_kin_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	output_total_dic = {'reconstruction_time':[],'divergent_bdn':[],'convergent_bdn':[],'transform':[],'plate_bdn_zone':[]}
	output_var_dic = {'reconstruction_time':[],'divergent_bdn':[],'convergent_bdn':[],'transform':[],'plate_bdn_zone':[]}
	output_mean_dic = {'reconstruction_time':[],'divergent_bdn':[],'convergent_bdn':[],'transform':[],'plate_bdn_zone':[]}
	output_median_dic = {'reconstruction_time':[],'divergent_bdn':[],'convergent_bdn':[],'transform':[],'plate_bdn_zone':[]}
	#output_mode_dic = {'reconstruction_time':[],'divergent_bdn':[],'convergent_bdn':[],'transform':[],'plate_bdn_zone':[]}
	
	output_dic = {'reconstruction_time':[],'kin_type':[],'total_m':[], 'mean_m':[], 'median_m':[], 'mode_m':[], 'var':[]}
	
	output_list = []
	
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		shp_filename = common_shp_filename_for_reconstructed_line_feat.format(age = str(reconstruction_time))
		kin_df = gpd.read_file(shp_filename)
		
		total_length_of_div_bdn = kin_df.loc[kin_df['DESCR']=='divergent_margin','Lengthm'].sum()
		total_length_of_conv_bdn = kin_df.loc[kin_df['DESCR']=='convergent_margin','Lengthm'].sum()
		total_length_of_transform = kin_df.loc[kin_df['DESCR']=='transform_fault','Lengthm'].sum()
		total_length_of_plate_bdn_zone = kin_df.loc[kin_df['DESCR']=='plate_boundary_zone','Lengthm'].sum()
		output_total_dic['reconstruction_time'].append(reconstruction_time)
		output_total_dic['divergent_bdn'].append(total_length_of_div_bdn)
		output_total_dic['convergent_bdn'].append(total_length_of_conv_bdn)
		output_total_dic['transform'].append(total_length_of_transform)
		output_total_dic['plate_bdn_zone'].append(total_length_of_plate_bdn_zone)
		
		mean_length_of_div_bdn = kin_df.loc[kin_df['DESCR']=='divergent_margin','Lengthm'].mean()
		mean_length_of_conv_bdn = kin_df.loc[kin_df['DESCR']=='convergent_margin','Lengthm'].mean()
		mean_length_of_transform = kin_df.loc[kin_df['DESCR']=='transform_fault','Lengthm'].mean()
		mean_length_of_plate_bdn_zone = kin_df.loc[kin_df['DESCR']=='plate_boundary_zone','Lengthm'].mean()
		output_mean_dic['reconstruction_time'].append(reconstruction_time)
		output_mean_dic['divergent_bdn'].append(mean_length_of_div_bdn)
		output_mean_dic['convergent_bdn'].append(mean_length_of_conv_bdn)
		output_mean_dic['transform'].append(mean_length_of_transform)
		output_mean_dic['plate_bdn_zone'].append(mean_length_of_plate_bdn_zone)
		
		median_length_of_div_bdn = kin_df.loc[kin_df['DESCR']=='divergent_margin','Lengthm'].median()
		median_length_of_conv_bdn = kin_df.loc[kin_df['DESCR']=='convergent_margin','Lengthm'].median()
		median_length_of_transform = kin_df.loc[kin_df['DESCR']=='transform_fault','Lengthm'].median()
		median_length_of_plate_bdn_zone = kin_df.loc[kin_df['DESCR']=='plate_boundary_zone','Lengthm'].median()
		output_median_dic['reconstruction_time'].append(reconstruction_time)
		output_median_dic['divergent_bdn'].append(median_length_of_div_bdn)
		output_median_dic['convergent_bdn'].append(median_length_of_conv_bdn)
		output_median_dic['transform'].append(median_length_of_transform)
		output_median_dic['plate_bdn_zone'].append(median_length_of_plate_bdn_zone)
		
		# mode_length_of_div_bdn = kin_df.loc[kin_df['DESCR']=='divergent_margin','Lengthm'].mode()
		# mode_length_of_conv_bdn = kin_df.loc[kin_df['DESCR']=='convergent_margin','Lengthm'].mode()
		# mode_length_of_transform = kin_df.loc[kin_df['DESCR']=='transform_fault','Lengthm'].mode()
		# mode_length_of_plate_bdn_zone = kin_df.loc[kin_df['DESCR']=='plate_boundary_zone','Lengthm'].mode()
		# output_mode_dic['reconstruction_time'].append(reconstruction_time)
		# output_mode_dic['divergent_bdn'].append(mode_length_of_div_bdn)
		# output_mode_dic['convergent_bdn'].append(mode_length_of_conv_bdn)
		# output_mode_dic['transform'].append(mode_length_of_transform)
		# output_mode_dic['plate_bdn_zone'].append(mode_length_of_plate_bdn_zone)
		
		var_length_of_div_bdn = kin_df.loc[kin_df['DESCR']=='divergent_margin','Lengthm'].var()
		var_length_of_conv_bdn = kin_df.loc[kin_df['DESCR']=='convergent_margin','Lengthm'].var()
		var_length_of_transform = kin_df.loc[kin_df['DESCR']=='transform_fault','Lengthm'].var()
		var_length_of_plate_bdn_zone = kin_df.loc[kin_df['DESCR']=='plate_boundary_zone','Lengthm'].var()
		output_var_dic['reconstruction_time'].append(reconstruction_time)
		output_var_dic['divergent_bdn'].append(var_length_of_div_bdn)
		output_var_dic['convergent_bdn'].append(var_length_of_conv_bdn)
		output_var_dic['transform'].append(var_length_of_transform)
		output_var_dic['plate_bdn_zone'].append(var_length_of_plate_bdn_zone)
		
		#'reconstruction_time':[],'kin_type':[],'total_m':[], 'mean_m':[], 'median_m':[], 'mode_m':[], 'var':[]
		output_list.append((reconstruction_time, 'divergent_margin', total_length_of_div_bdn, mean_length_of_div_bdn, median_length_of_div_bdn, var_length_of_div_bdn))
		output_list.append((reconstruction_time, 'convergent_margin', total_length_of_conv_bdn, mean_length_of_conv_bdn, median_length_of_conv_bdn, var_length_of_conv_bdn))
		output_list.append((reconstruction_time, 'transform_fault', total_length_of_transform, mean_length_of_transform, median_length_of_transform, var_length_of_transform))
		output_list.append((reconstruction_time, 'plate_boundary_zone', total_length_of_plate_bdn_zone, mean_length_of_plate_bdn_zone, median_length_of_plate_bdn_zone, var_length_of_plate_bdn_zone))
		
		reconstruction_time = reconstruction_time - time_interval
	
	output_median_df = pd.DataFrame.from_dict(output_median_dic)
	output_median_df.to_csv("median_len_for_"+modelname+"_"+yearmonthday+".csv")
	output_mean_df = pd.DataFrame.from_dict(output_mean_dic)
	output_mean_df.to_csv("mean_len_for_"+modelname+"_"+yearmonthday+".csv")
	# output_mode_df = pd.DataFrame.from_dict(output_mode_dic)
	# output_mode_df.to_csv("mode_len_for_"+modelname+"_"+yearmonthday+".csv")
	output_total_df = pd.DataFrame.from_dict(output_total_dic)
	output_total_df.to_csv("total_len_for_"+modelname+"_"+yearmonthday+".csv")
	output_var_df = pd.DataFrame.from_dict(output_var_dic)
	output_var_df.to_csv("variance_len_for_"+modelname+"_"+yearmonthday+".csv")
	
	output_df = pd.DataFrame.from_records(output_list, columns=['reconstruction_time','kin_type','total_m', 'mean_m', 'median_m', 'var'])
	output_df.to_csv("statistics_len_for_kin_"+modelname+"_"+yearmonthday+".csv")

def perform_simple_statistics_on_length_of_same_type_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, name_of_line_feat, modelname, yearmonthday):
	output_dic = {'reconstruction_time':[],'total_len':[],'var_len':[],'mean_len':[],'median_len':[]}
	output_list = []
	
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		shp_filename = common_shp_filename_for_reconstructed_line_feat.format(age = str(reconstruction_time))
		total_length = 0.00
		mean_length = 0.00
		median_length = 0.00
		var_length = 0.00
		if (os.path.isfile(shp_filename)):
			kin_df = gpd.read_file(shp_filename)
			total_length = kin_df['Lengthm'].sum()
			mean_length = kin_df['Lengthm'].mean()
			median_length = kin_df['Lengthm'].median()
			var_length = kin_df['Lengthm'].var()
		
		output_dic['reconstruction_time'].append(reconstruction_time)
		output_dic['total_len'].append(total_length)
		output_dic['mean_len'].append(mean_length)
		output_dic['median_len'].append(median_length)
		output_dic['var_len'].append(var_length)
		
		reconstruction_time = reconstruction_time - time_interval
	output_df = pd.DataFrame.from_dict(output_dic)
	output_df.to_csv("statistics_len_for_"+name_of_line_feat+"_"+modelname+"_"+yearmonthday+".csv")


def main():
	#PalaeoPlatesendJan2023
	#convergent_line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/extract_features_based_on_description_convergent_margin_PalaeoPlatesendJan2023_3420_0Ma_from_test_21_20230713.shp"
	#convergent_line_features_file = r"final_unique_kine_line_feats_test_3_PalaeoPlatesendJan2023_20240402.shp"
	#CON_line_features = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_segment_POLYGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230921.shp"
	#passive_margin_line_features_file = r"passive_margins_from_patterns_of_unique_kin_line_fts_test_3_PalaeoPlatesendJan2023_20240409.shp"
	convergent_line_features_file = r"extract_features_based_on_descriptionconvergent_margin_PalaeoPlatesendJan2023_2800_0Ma_from_both_kin_processes_unique_kin_ft_20240901.shp"
	divergent_line_features_file = r"extract_features_based_on_descriptiondivergent_margin_PalaeoPlatesendJan2023_2800_0Ma_from_both_kin_processes_unique_kin_ft_20240901.shp"
	line_features = pygplates.FeatureCollection(convergent_line_features_file)
	begin_reconstruction_time = 2800.0
	end_reconstruction_time = 0.00
	time_interval = 5.00
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	epsg_code = 'ESRI:54032'
	name_of_line_features = 'convergent_margin'
	modelname = 'PalaeoPlatesendJan2023'
	#yearmonthday = '20240412'
	yearmonthday = '20240903'
	reconstruct_line_features_to_each_reconstruction_time_and_calculate_length(line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, epsg_code, name_of_line_features, yearmonthday)
	
	#common_shp_filename_for_reconstructed_line_feat = r"lengthm_w_Geopandas_CON_OCN_PalaeoPlatesendJan2023_{age}_20240407.shp"
	#for various kinematic types
	#perform_simple_statistics_on_length_of_each_kin_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)
	#for con_ocn line_features
	#name_of_line_feat = 'CON_OCN'
	#perform_simple_statistics_on_length_of_same_type_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, name_of_line_feat, modelname, yearmonthday)
	
	#common_shp_filename_for_reconstructed_line_feat = r"lengthm_w_Geopandas_passive_margin_{age}_20240409.shp"
	#name_of_line_feat = "passive_margin"
	#perform_simple_statistics_on_length_of_same_type_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, name_of_line_feat, modelname, yearmonthday)
	
	common_shp_filename_for_reconstructed_line_feat = r"lengthm_w_Geopandas_convergent_margin_{age}_20240903.shp"
	name_of_line_feat = "convergent_margin"
	perform_simple_statistics_on_length_of_same_type_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, name_of_line_feat, modelname, yearmonthday)
	
	#inactive_divergent_line_features_file = r"inactive_div_margins_from_unique_kin_line_fts_test_3_PalaeoPlatesendJan2023_20240411.shp"
	#line_features = pygplates.FeatureCollection(inactive_divergent_line_features_file)
	begin_reconstruction_time = 2800.0
	end_reconstruction_time = 0.00
	time_interval = 5.00
	#rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	epsg_code = 'ESRI:54032'
	name_of_line_features = 'inactive_div_margin'
	modelname = 'PalaeoPlatesendJan2023'
	yearmonthday = '20240412'
	#reconstruct_line_features_to_each_reconstruction_time_and_calculate_length(line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, epsg_code, name_of_line_features, yearmonthday)

	common_shp_filename_for_reconstructed_line_feat = r"lengthm_w_Geopandas_inactive_div_margin_{age}_20240411.shp"
	name_of_line_feat = "inactive_div_margin"
	#perform_simple_statistics_on_length_of_same_type_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, name_of_line_feat, modelname, yearmonthday)
	
	inactive_convergent_line_features_file = r"inactive_conv_margins_from_unique_kin_line_fts_test_3_PalaeoPlatesendJan2023_20240411.shp"
	#line_features = pygplates.FeatureCollection(inactive_convergent_line_features_file)
	begin_reconstruction_time = 2800.0
	end_reconstruction_time = 0.00
	time_interval = 5.00
	#rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	epsg_code = 'ESRI:54032'
	name_of_line_features = 'inactive_conv_margin'
	modelname = 'PalaeoPlatesendJan2023'
	yearmonthday = '20240412'
	#reconstruct_line_features_to_each_reconstruction_time_and_calculate_length(line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, epsg_code, name_of_line_features, yearmonthday)

	common_shp_filename_for_reconstructed_line_feat = r"lengthm_w_Geopandas_inactive_conv_margin_{age}_20240411.shp"
	name_of_line_feat = "inactive_conv_margin"
	#perform_simple_statistics_on_length_of_same_type_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, name_of_line_feat, modelname, yearmonthday)
#if __name__=="__main__":
	#main()