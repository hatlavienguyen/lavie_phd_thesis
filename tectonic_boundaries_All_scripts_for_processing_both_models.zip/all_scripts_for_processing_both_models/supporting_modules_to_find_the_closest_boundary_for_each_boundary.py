import sys

#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
import psycopg2
from config_plate_tectonics import config

def find_the_closest_boundary_for_each_boundary_from_database_table_tectonic_motion(name_of_table_for_pairs_of_line_features_at_each_time, name_for_table_for_summary_tectonic_boundary, line_features_collection, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time,time_interval, modelname, yearmonthday):
	txt = """SELECT DISTINCT ref_ft_id FROM {input_name_of_table_for_pairs_of_line_features_at_each_time} WHERE time = {input_time}
			 UNION 
			 SELECT DISTINCT neighbour_ft_id FROM {input_name_of_table_for_pairs_of_line_features_at_each_time} WHERE time = {input_time}"""
	txt_1 = """SELECT DISTINCT ref_ft_id, neighbour_ft_id, tectonic_motion FROM {input_name_of_table_for_pairs_of_line_features_at_each_time}
				WHERE ((ref_ft_id = '{input_ft_id}' 
						OR neighbour_ft_id = '{input_ft_id}')
					   AND time = {input_time})"""
	txt_2 = """INSERT INTO {input_name_name_for_table_for_summary_tectonic_boundary}(time, ref_ft_id, neighbour_ft_id, tectonic_motion) VALUES (%s, %s, %s, %s)"""
	already_processed = []
	conn = None
	cur = None
	cur_1 = None
	cur_2 = None
	cur_3 = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		dic = {}
		
		outputFeatureCollection = pygplates.FeatureCollection()
		reconstructed_line_features = []
		reconstruction_time = begin_reconstruction_time
		while (reconstruction_time > (end_reconstruction_time - time_interval)):
			print('reconstruction_time',reconstruction_time)
			already_processed[:] = []
			sql = txt.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time, input_time = reconstruction_time)
			cur.execute(sql)
			row = cur.fetchone()
			while (row is not None):
				reconstructed_line_features[:] = []
				current_ft_id = row[0]
				if (current_ft_id not in already_processed):
					sql_1 = None
					sql_1 = txt_1.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time,input_ft_id = current_ft_id, input_time = reconstruction_time)
					cur_1.execute(sql_1)
					row_1 = cur_1.fetchone()
					min_distance = -1.00
					closest_ft_id = None
					previous_tectonic_motion = None
					current_ft = None
					current_reconstructed_line = None
					while (row_1 is not None):
						reconstructed_line_features[:] = []
						#print(row_1)
						ref_ft_id = row_1[0]
						neighbour_ft_id = row_1[1]
						current_tectonic_motion = row_1[2]
						#print('time_of_tectonic_motion',time_of_tectonic_motion)
						#print('current_tectonic_motion',current_tectonic_motion)
						final_line_ft_1 = None
						final_line_ft_2 = None
						if (ref_ft_id == current_ft_id):
							if (current_ft is None and current_reconstructed_line is None):
								all_line_ft_1 = line_features_collection.get(lambda ft: ft.get_name() == ref_ft_id, pygplates.FeatureReturn.all)
								final_line_ft_1 = None
								for potential_line_ft_1 in all_line_ft_1:
									if (potential_line_ft_1.is_valid_at_time(reconstruction_time)):
										final_line_ft_1 = potential_line_ft_1
										break
							all_line_ft_2 = line_features_collection.get(lambda ft: ft.get_name() == neighbour_ft_id, pygplates.FeatureReturn.all)
							final_line_ft_2 = None
							for potential_line_ft_2 in all_line_ft_2:
								if (potential_line_ft_2.is_valid_at_time(reconstruction_time)):
									final_line_ft_2 = potential_line_ft_2
									break
						elif (neighbour_ft_id == current_ft_id):
							if (current_ft is None and current_reconstructed_line is None):
								all_line_ft_1 = line_features_collection.get(lambda ft: ft.get_name() == neighbour_ft_id, pygplates.FeatureReturn.all)
								final_line_ft_1 = None
								for potential_line_ft_1 in all_line_ft_1:
									if (potential_line_ft_1.is_valid_at_time(reconstruction_time)):
										final_line_ft_1 = potential_line_ft_1
										break
							all_line_ft_2 = line_features_collection.get(lambda ft: ft.get_name() == ref_ft_id, pygplates.FeatureReturn.all)
							final_line_ft_2 = None
							for potential_line_ft_2 in all_line_ft_2:
								if (potential_line_ft_2.is_valid_at_time(reconstruction_time)):
									final_line_ft_2 = potential_line_ft_2
									break
						if (final_line_ft_1 is None and final_line_ft_2 is not None):
							reconstructed_line_features[:] = []
							if (reference is not None):
								pygplates.reconstruct(final_line_ft_2,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(final_line_ft_2,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
							final_reconstructed_line_ft_2 = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
							line_ft_2,line_2 = final_reconstructed_line_ft_2[0]
							line_ft_1,line_1 = current_ft,current_reconstructed_line
							distance = pygplates.GeometryOnSphere.distance(line_2.get_centroid(),line_1.get_centroid())*pygplates.Earth.mean_radius_in_kms
							if (min_distance == -1.00):
								min_distance = distance
								previous_tectonic_motion = current_tectonic_motion
								if (current_ft_id == ref_ft_id):
									closest_ft_id = neighbour_ft_id
								elif (current_ft_id == neighbour_ft_id):
									closest_ft_id = ref_ft_id
							elif (min_distance > 0.00 and distance > min_distance):
								min_distance = distance
								previous_tectonic_motion = current_tectonic_motion
								if (current_ft_id == ref_ft_id):
									closest_ft_id = neighbour_ft_id
								elif (current_ft_id == neighbour_ft_id):
									closest_ft_id = ref_ft_id
						elif (final_line_ft_1 is not None and final_line_ft_2 is not None):
							reconstructed_line_features[:] = []
							if (reference is not None):
								pygplates.reconstruct([final_line_ft_1,final_line_ft_2],rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct([final_line_ft_1,final_line_ft_2],rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
							final_reconstructed_line_fts = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
							line_ft_2,line_2 = final_reconstructed_line_fts[1]
							line_ft_1,line_1 = final_reconstructed_line_fts[0]
							distance = pygplates.GeometryOnSphere.distance(line_2.get_centroid(),line_1.get_centroid())*pygplates.Earth.mean_radius_in_kms
							if (line_ft_1.get_name() == current_ft_id):
								current_ft = line_ft_1
								current_reconstructed_line = line_1
							elif (line_ft_2.get_name() == current_ft_id):
								current_ft = line_ft_2
								current_reconstructed_line = line_2
							if (min_distance == -1.00):
								min_distance = distance
								previous_tectonic_motion = current_tectonic_motion
								if (current_ft_id == ref_ft_id):
									closest_ft_id = neighbour_ft_id
								elif (current_ft_id == neighbour_ft_id):
									closest_ft_id = ref_ft_id
								
							elif (min_distance > 0.00 and distance > min_distance):
								min_distance = distance
								previous_tectonic_motion = current_tectonic_motion
								if (current_ft_id == ref_ft_id):
									closest_ft_id = neighbour_ft_id
								elif (current_ft_id == neighbour_ft_id):
									closest_ft_id = ref_ft_id
						else:
							print("Error in find_the_closest_boundary_for_each_boundary_from_database_table_tectonic_motion")
							print("Unexpected value for final_line_ft_1 and final_line_ft_2")
							print("final_line_ft_1",final_line_ft_1,"final_line_ft_2",final_line_ft_2)
							print('row_1',row_1)
							exit()
						row_1 = cur_1.fetchone()
					sql_2 = txt_2.format(input_name_name_for_table_for_summary_tectonic_boundary = name_for_table_for_summary_tectonic_boundary)
					cur_2.execute(sql_2,(reconstruction_time, current_ft_id, closest_ft_id, previous_tectonic_motion))
					conn.commit()
					already_processed.append(current_ft_id)
					already_processed.append(closest_ft_id)
					
					# sql_3 = txt_1.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time,input_ft_id = closest_ft_id, input_time = reconstruction_time)
					# cur_3.execute(sql_3)
					# row_3 = cur_3.fetchone()
					# min_distance_2 = -1.00
					# closest_ft_id_2 = None
					# previous_tectonic_motion = None
					# current_ft = None
					# current_reconstructed_line = None
					# while (row_3 is not None):
						# reconstructed_line_features[:] = []
						# #print(row_1)
						# ref_ft_id = row_3[0]
						# neighbour_ft_id = row_3[1]
						# current_tectonic_motion = row_3[2]
						# #print('time_of_tectonic_motion',time_of_tectonic_motion)
						# #print('current_tectonic_motion',current_tectonic_motion)
						# final_line_ft_1 = None
						# final_line_ft_2 = None
						# if (ref_ft_id == closest_ft_id):
							# if (current_ft is None and current_reconstructed_line is None):
								# all_line_ft_1 = line_features_collection.get(lambda ft: ft.get_name() == ref_ft_id, pygplates.FeatureReturn.all)
								# final_line_ft_1 = None
								# for potential_line_ft_1 in all_line_ft_1:
									# if (potential_line_ft_1.is_valid_at_time(reconstruction_time)):
										# final_line_ft_1 = potential_line_ft_1
										# break
							# all_line_ft_2 = line_features_collection.get(lambda ft: ft.get_name() == neighbour_ft_id, pygplates.FeatureReturn.all)
							# final_line_ft_2 = None
							# for potential_line_ft_2 in all_line_ft_2:
								# if (potential_line_ft_2.is_valid_at_time(reconstruction_time)):
									# final_line_ft_2 = potential_line_ft_2
									# break
						# elif (neighbour_ft_id == closest_ft_id):
							# if (current_ft is None and current_reconstructed_line is None):
								# all_line_ft_1 = line_features_collection.get(lambda ft: ft.get_name() == neighbour_ft_id, pygplates.FeatureReturn.all)
								# final_line_ft_1 = None
								# for potential_line_ft_1 in all_line_ft_1:
									# if (potential_line_ft_1.is_valid_at_time(reconstruction_time)):
										# final_line_ft_1 = potential_line_ft_1
										# break
							# all_line_ft_2 = line_features_collection.get(lambda ft: ft.get_name() == ref_ft_id, pygplates.FeatureReturn.all)
							# final_line_ft_2 = None
							# for potential_line_ft_2 in all_line_ft_2:
								# if (potential_line_ft_2.is_valid_at_time(reconstruction_time)):
									# final_line_ft_2 = potential_line_ft_2
									# break
						# if (final_line_ft_1 is None and final_line_ft_2 is not None):
							# reconstructed_line_features[:] = []
							# if (reference is not None):
								# pygplates.reconstruct(final_line_ft_2,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							# else:
								# pygplates.reconstruct(final_line_ft_2,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
							# final_reconstructed_line_ft_2 = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
							# line_ft_2,line_2 = final_reconstructed_line_ft_2[0]
							# line_ft_1,line_1 = current_ft,current_reconstructed_line
							# distance = pygplates.GeometryOnSphere.distance(line_2.get_centroid(),line_1.get_centroid())*pygplates.Earth.mean_radius_in_kms
							# if (min_distance_2 == -1.00):
								# min_distance_2 = distance
								# previous_tectonic_motion = current_tectonic_motion
								# if (closest_ft_id == ref_ft_id):
									# closest_ft_id_2 = neighbour_ft_id
								# elif (closest_ft_id == neighbour_ft_id):
									# closest_ft_id_2 = ref_ft_id
							# elif (min_distance_2 > 0.00 and distance > min_distance_2):
								# min_distance_2 = distance
								# previous_tectonic_motion = current_tectonic_motion
								# if (closest_ft_id == ref_ft_id):
									# closest_ft_id_2 = neighbour_ft_id
								# elif (closest_ft_id == neighbour_ft_id):
									# closest_ft_id_2 = ref_ft_id
						# elif (final_line_ft_1 is not None and final_line_ft_2 is not None):
							# reconstructed_line_features[:] = []
							# if (reference is not None):
								# pygplates.reconstruct([final_line_ft_1,final_line_ft_2],rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							# else:
								# pygplates.reconstruct([final_line_ft_1,final_line_ft_2],rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
							# final_reconstructed_line_fts = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
							# line_ft_2,line_2 = final_reconstructed_line_fts[1]
							# line_ft_1,line_1 = final_reconstructed_line_fts[0]
							# distance = pygplates.GeometryOnSphere.distance(line_2.get_centroid(),line_1.get_centroid())*pygplates.Earth.mean_radius_in_kms
							# if (line_ft_1.get_name() == closest_ft_id):
								# current_ft = line_ft_1
								# current_reconstructed_line = line_1
							# elif (line_ft_2.get_name() == closest_ft_id):
								# current_ft = line_ft_2
								# current_reconstructed_line = line_2
							# if (min_distance_2 == -1.00):
								# min_distance_2 = distance
								# previous_tectonic_motion = current_tectonic_motion
								# if (closest_ft_id == ref_ft_id):
									# closest_ft_id_2 = neighbour_ft_id
								# elif (closest_ft_id == neighbour_ft_id):
									# closest_ft_id_2 = ref_ft_id
								
							# elif (min_distance_2 > 0.00 and distance > min_distance_2):
								# min_distance_2 = distance
								# previous_tectonic_motion = current_tectonic_motion
								# if (closest_ft_id == ref_ft_id):
									# closest_ft_id_2 = neighbour_ft_id
								# elif (closest_ft_id == neighbour_ft_id):
									# closest_ft_id_2 = ref_ft_id
						# else:
							# print("Error in find_the_closest_boundary_for_each_boundary_from_database_table_tectonic_motion")
							# print("Unexpected value for final_line_ft_1 and final_line_ft_2")
							# print("final_line_ft_1",final_line_ft_1,"final_line_ft_2",final_line_ft_2)
							# print('row_3',row_3)
							# exit()
						# row_3 = cur_3.fetchone()
					
					# if (current_ft_id == closest_ft_id_2):
						# sql_2 = txt_2.format(input_name_name_for_table_for_summary_tectonic_boundary = name_for_table_for_summary_tectonic_boundary)
						# cur_2.execute(sql_2,(reconstruction_time, current_ft_id, closest_ft_id, previous_tectonic_motion))
						# conn.commit()
						# already_processed.append(current_ft_id)
						# already_processed.append(closest_ft_id)
				row = cur.fetchone()
			reconstruction_time = reconstruction_time - time_interval
	except (psycopg2.DatabaseError) as error:
		print("Error in find_the_closest_boundary_for_each_boundary_from_database_table_tectonic_motion")
		print(error)