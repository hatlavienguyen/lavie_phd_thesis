import pygplates
import create_topological_isochron_and_estimate_MOR as create_topological

def main():

	div_margin_features_file = r"all_div_margin_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240304.shp"
	div_margin_features = pygplates.FeatureCollection(div_margin_features_file)
	
	left_input_point_features_file = r"isochron_left_point_features_test_1_manually_identified_records_for_PalaeoPlatesendJan2023_20240324.shp"
	left_input_point_features = pygplates.FeatureCollection(left_input_point_features_file)
	
	right_input_point_features_file = r"isochron_right_point_features_test_1_manually_identified_records_for_PalaeoPlatesendJan2023_20240324.shp"
	right_input_point_features = pygplates.FeatureCollection(right_input_point_features_file)
	
	temp_rift_point_features_file = r"rift_point_features_from_manually_identified_records_PalaeoPlatesendJan2023_20240323.shp"
	temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
	rift_point_features_records_csv = r"manually_approx_rift_point_features.csv"
	#conv_and_plate_boundary_zone_boundaries_file = r"all_conv_margin_and_plate_bdn_zone_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240301.shp"
	#conv_and_plate_boundary_zone_boundaries = pygplates.FeatureCollection(conv_and_plate_boundary_zone_boundaries_file)
	sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	age_interval_for_isochron_fts = 5.00
	maximum_reconstruction_time = 2800.0
	minimum_reconstruction_time = 0.00
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	yearmonthday = "20240414"
	modelname = "test_1_manually_identified_records_for_PalaeoPlatesendJan2023"
	#create_topological.create_oceanic_crust_from_rift_and_isochron_point_features_w_distinct_pairs_of_sgdus(div_margin_features, left_input_point_features, right_input_point_features, temp_rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday)
	
	#oceanic_crust_features_files = r"oceanic_crust_for_gdus_from_rift_and_isochron_feats_with_max_star_div_age_2800.0_min_0.0_test_1_manually_identified_records_for_PalaeoPlatesendJan2023_20240324.shp"
	#oceanic_crust_features = pygplates.FeatureCollection(oceanic_crust_features_files)
	#create_topological.modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features(common_filename_for_temporary_sgdu_and_members_csv, rift_point_features_records_csv, oceanic_crust_features, sgdu_features, rotation_model, reference, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, modelname, yearmonthday)
	

if __name__=="__main__":
	main()