import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import evaluate_tectonic_motion as tectonic_motion
import identify_kinematic_boundaries as div_bdn
import identify_convergent_boundaries as conv_bdn
import rotation_utility


def find_rift_and_collision_line_features(con_ocn_line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, threshold_prox_distance_km, modelname, yearmonthday):
	reconstruction_time = begin_reconstruction_time
	output_line_feats_for_rift = pygplates.FeatureCollection()
	output_line_feats_for_collision = pygplates.FeatureCollection()
	output_rift_point_features = pygplates.FeatureCollection()
	dic_of_collision_feats = {}
	dic_of_rift_feats = {}
	unsure_topology_for_rift_point = []
	list_of_ordered_pairs_gdu_fts = []
	previous_diverging_line_feats = []
	while(reconstruction_time >= end_reconstruction_time):
		#list_of_line_feats_to_be_examined_for_rift = []
		#list_of_line_feats_to_be_examined_for_collision = []
		for line_ft in con_ocn_line_features:
			if (line_ft.is_valid_at_time(reconstruction_time) == True):
				if (line_ft.is_valid_at_time(reconstruction_time + time_interval) == False):
					#list_of_line_feats_to_be_examined_for_rift.append(line_ft)
					clone = line_ft.clone()
					clone.set_description('rift')
					current_begin_time,current_end_time = line_ft.get_valid_time()
					if (current_begin_time >= reconstruction_time):
						clone.set_valid_time(reconstruction_time,(reconstruction_time-time_interval)+0.100)
					elif (reconstruction_time == current_end_time):
						clone.set_valid_time(current_end_time,current_end_time)
					output_line_feats_for_rift.add(clone)
			elif (line_ft.is_valid_at_time(reconstruction_time) == False):
				if (line_ft.is_valid_at_time(reconstruction_time + time_interval) == True):
					#list_of_line_feats_to_be_examined_for_collision.append(line_ft)
					clone = line_ft.clone()
					clone.set_description('collision')
					current_begin_time,current_end_time = line_ft.get_valid_time()
					clone.set_valid_time(reconstruction_time + time_interval,reconstruction_time+0.100)
					output_line_feats_for_collision.add(clone)
		reconstruction_time = reconstruction_time - time_interval
	output_line_feats_for_rift.write('line_fts_for_rifting_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
	output_line_feats_for_collision.write('line_fts_for_collision_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def find_divergent_line_features(div_line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, threshold_prox_distance_km, modelname, yearmonthday):
	reconstruction_time = begin_reconstruction_time
	output_line_feats_for_rift = pygplates.FeatureCollection()
	output_line_feats_for_collision = pygplates.FeatureCollection()
	output_rift_point_features = pygplates.FeatureCollection()
	dic_of_convergent_feats = {}
	dic_of_divergent_feats = {}
	unsure_topology_for_rift_point = []
	list_of_ordered_pairs_gdu_fts = []
	previous_diverging_line_feats = []
	while(reconstruction_time >= end_reconstruction_time):
		list_of_line_feats_to_be_examined_for_rift = [line_ft for line_ft in div_line_features if line_ft.is_valid_at_time(reconstruction_time)]
		if (len(list_of_line_feats_to_be_examined_for_rift) > 1):
			#reconstruct line features and examine them 
			reconstructed_line_features = []
			if (reference is not None):
				pygplates.reconstruct(list_of_line_feats_to_be_examined_for_rift, rotation_model, reconstructed_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_line_feats_to_be_examined_for_rift, rotation_model, reconstructed_line_features, reconstruction_time, group_with_feature = True)
			final_reconstructed_line_features = div_bdn.find_final_reconstructed_geometries(reconstructed_line_features, pygplates.PolylineOnSphere)
			dic_of_divergent_feats.clear()
			for line_ft_1, line_1 in final_reconstructed_line_features:
				polylid_1 = line_ft_1.get_name()
				line_ft_1_gplateid = line_ft_1.get_feature_id()
				gdu_id_1 = line_ft_1.get_reconstruction_plate_id()
				for line_ft_2, line_2 in final_reconstructed_line_features:
					polylid_2 = line_ft_2.get_name()
					line_ft_2_gplateid = line_ft_2.get_feature_id()
					if (line_ft_1_gplateid != line_ft_2_gplateid and polylid_1 != polylid_2):
						name_of_pair = polylid_1+'_'+polylid_2
						rev_name_of_pair = polylid_2+'_'+polylid_1
						if (name_of_pair not in dic_of_divergent_feats and rev_name_of_pair not in dic_of_divergent_feats):
							key = name_of_pair
							gdu_id_2 = line_ft_2.get_reconstruction_plate_id()
							centroid_1 = line_1.get_centroid()
							centroid_2 = line_2.get_centroid()
							total_relative_reconstruction_rotation = div_bdn.find_total_relative_reconstruction_rotation_(rotation_model, gdu_id_1, gdu_id_2, float(reconstruction_time), reference)
							total_stage_rel_rot_of_1_to_2 = div_bdn.find_stage_relative_reconstruction_rotation_(rotation_model,gdu_id_1,gdu_id_2,float(reconstruction_time)+time_interval,float(reconstruction_time),reference)
							total_stage_rel_rot_of_2_to_1 = div_bdn.find_stage_relative_reconstruction_rotation_(rotation_model,gdu_id_2,gdu_id_1,float(reconstruction_time)+time_interval,float(reconstruction_time),reference)
							cur_lat1,cur_lon1 = centroid_1.to_lat_lon()
							cur_lat2,cur_lon2 = centroid_2.to_lat_lon()
							at_current_time_distance_in_km_btw_1_and_2 = div_bdn.calculate_distance_km_between_two_points_from_haversine_formula(cur_lat1,cur_lon1,cur_lat2,cur_lon1)
							if (total_relative_reconstruction_rotation is not None and at_current_time_distance_in_km_btw_1_and_2 <= threshold_prox_distance_km):
								if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
									E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
									stage_rel_E_pole = None
									if (total_stage_rel_rot_of_1_to_2 is not None):
										if (total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == False):
											stage_rel_E_pole,_ = total_stage_rel_rot_of_1_to_2.get_euler_pole_and_angle()
									elif (total_stage_rel_rot_of_2_to_1 is not None):
										if (total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == False):
											stage_rel_E_pole,_ = total_stage_rel_rot_of_2_to_1.get_euler_pole_and_angle()
									if (stage_rel_E_pole is None):
										stage_rel_E_pole = E_pole
									result_of_tectonic_motion = None
									
									if (total_stage_rel_rot_of_1_to_2 is not None and total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == False):
										result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_2, centroid_1, stage_rel_E_pole)
									elif (total_stage_rel_rot_of_2_to_1 is not None and total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == False):
										result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_1, centroid_2, stage_rel_E_pole)
									else:
										result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_2, centroid_1, stage_rel_E_pole)
									if (result_of_tectonic_motion != 'D'):
										if (total_stage_rel_rot_of_1_to_2 is not None and total_stage_rel_rot_of_2_to_1 is not None):
											stage_rel_E_pole,_ = total_stage_rel_rot_of_2_to_1.get_euler_pole_and_angle()
											result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_1, centroid_2, stage_rel_E_pole)
										else:
											stage_rel_E_pole = E_pole
											result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_2, centroid_1, stage_rel_E_pole)
									if (result_of_tectonic_motion is not None):
										if (result_of_tectonic_motion == 'D'):
											div_line_feature_1,div_line_feature_2 = None,None
											smallest_circle_angular_radius_degrees = 178.00
											while (smallest_circle_angular_radius_degrees > 0.00):
												small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
												approx_rad_closest_dist_neighbour,closest_point_on_gdu1,_ = pygplates.GeometryOnSphere.distance(line_1, small_circle_boundary,return_closest_positions = True)
												approx_rad_closest_dist_ref,closest_point_on_gdu2,_= pygplates.GeometryOnSphere.distance(line_2, small_circle_boundary,return_closest_positions = True)
												if (approx_rad_closest_dist_neighbour == approx_rad_closest_dist_ref == 0.00):
													approx_mid_point = div_bdn.find_the_mid_of_two_PointOnSphere(closest_point_on_gdu1,closest_point_on_gdu2)
													left_gduid, right_gduid = None,None
													if (approx_mid_point != closest_point_on_gdu1 and approx_mid_point != closest_point_on_gdu2):
														#create an arc
														temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
														normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
														left_gduid, right_gduid = div_bdn.identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, closest_point_on_gdu1, closest_point_on_gdu2, gdu_id_1, gdu_id_2)
													#create point feature
													#name = 'R'+str(child_1)+'_'+str(child_2)+'_'+str(smallest_circle_angular_radius_degrees)
													name = 'R'+key+'_'+str(smallest_circle_angular_radius_degrees)
													rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, approx_mid_point, name = name, valid_time = (reconstruction_time,0.00))
													if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
														rift_point_ft.set_left_plate(line_ft_1.get_reconstruction_plate_id())
														rift_point_ft.set_right_plate(line_ft_2.get_reconstruction_plate_id())
													else:
														rift_point_ft.set_left_plate(left_gduid)
														rift_point_ft.set_right_plate(right_gduid)
													rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
													rift_point_ft.set_description(str(smallest_circle_angular_radius_degrees))
													if (reference is None):
														pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
													else:
														pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
													output_rift_point_features.add(rift_point_ft)
													if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
														unsure_topology_for_rift_point.add(rift_point_ft)
													if ((left_gduid == gdu_id_1 and right_gduid == gdu_id_2) or (left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
														list_of_ordered_pairs_gdu_fts.append((reconstruction_time,'R'+key,smallest_circle_angular_radius_degrees, line_ft_1.get_shapefile_attribute('POLYLID'), gdu_id_1, line_ft_2.get_shapefile_attribute('POLYLID'), gdu_id_2))
													else:
														list_of_ordered_pairs_gdu_fts.append((reconstruction_time,'R'+key,smallest_circle_angular_radius_degrees, line_ft_2.get_shapefile_attribute('POLYLID'), gdu_id_2, line_ft_1.get_shapefile_attribute('POLYLID'), gdu_id_1))
													#create pair of line features associated with the rift point ft
													_,con_ocn_to_time = line_ft_1.get_valid_time()
													div_line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=gdu_line_ft_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
													div_line_feature_1.set_reconstruction_plate_id(gdu_id_1)
													div_line_feature_1.set_conjugate_plate_id(gdu_id_2)
													div_line_feature_1.set_description('divergent_margin')
													_,con_ocn_to_time = line_ft_2.get_valid_time()
													div_line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=gdu_line_ft_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
													div_line_feature_2.set_reconstruction_plate_id(gdu_id_2)
													div_line_feature_2.set_conjugate_plate_id(gdu_id_1)
													div_line_feature_2.set_description('divergent_margin')
													if (reference is None):
														pygplates.reverse_reconstruct([div_line_feature_1,div_line_feature_2],rotation_model,reconstruction_time)
													else:
														pygplates.reverse_reconstruct([div_line_feature_1,div_line_feature_2],rotation_model,reconstruction_time,reference)
													dic_of_divergent_feats[key] = (div_line_feature_1,div_line_feature_2)
													previous_diverging_line_feats.append((div_line_feature_1,div_line_feature_2,reconstruction_time,at_current_time_distance_in_km_btw_1_and_2))
													break
												smallest_circle_angular_radius_degrees= smallest_circle_angular_radius_degrees - 1.00
											if (div_line_feature_1 is None and div_line_feature_2 is None):
												_,con_ocn_to_time = line_ft_1.get_valid_time()
												div_line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=gdu_line_ft_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
												div_line_feature_1.set_reconstruction_plate_id(gdu_id_1)
												div_line_feature_1.set_conjugate_plate_id(gdu_id_2)
												div_line_feature_1.set_description('transform_fault')
												_,con_ocn_to_time = line_ft_2.get_valid_time()
												div_line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=gdu_line_ft_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
												div_line_feature_2.set_reconstruction_plate_id(gdu_id_2)
												div_line_feature_2.set_conjugate_plate_id(gdu_id_1)
												div_line_feature_2.set_description('transform_fault')
												if (reference is None):
													pygplates.reverse_reconstruct([div_line_feature_1,div_line_feature_2],rotation_model,reconstruction_time)
												else:
													pygplates.reverse_reconstruct([div_line_feature_1,div_line_feature_2],rotation_model,reconstruction_time,reference)
												dic_of_divergent_feats[key] = (div_line_feature_1,div_line_feature_2)
												previous_diverging_line_feats.append((div_line_feature_1,div_line_feature_2,reconstruction_time,at_current_time_distance_in_km_btw_1_and_2))
										elif (result_of_tectonic_motion == 'T'):
											_,con_ocn_to_time = line_ft_1.get_valid_time()
											div_line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=gdu_line_ft_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
											div_line_feature_1.set_reconstruction_plate_id(gdu_id_1)
											div_line_feature_1.set_conjugate_plate_id(gdu_id_2)
											div_line_feature_1.set_description('transform_fault')
											_,con_ocn_to_time = line_ft_2.get_valid_time()
											div_line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=gdu_line_ft_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
											div_line_feature_2.set_reconstruction_plate_id(gdu_id_2)
											div_line_feature_2.set_conjugate_plate_id(gdu_id_1)
											div_line_feature_2.set_description('transform_fault')
											if (reference is None):
												pygplates.reverse_reconstruct([div_line_feature_1,div_line_feature_2],rotation_model,reconstruction_time)
											else:
												pygplates.reverse_reconstruct([div_line_feature_1,div_line_feature_2],rotation_model,reconstruction_time,reference)
											dic_of_divergent_feats[key] = (div_line_feature_1,div_line_feature_2)
											previous_diverging_line_feats.append((div_line_feature_1,div_line_feature_2,reconstruction_time,at_current_time_distance_in_km_btw_1_and_2))
		#update reconstruction_time
		reconstruction_time = reconstruction_time - time_interval

def find_conv_line_features(conv_line_features, sgdu_features, temporary_sgdu_and_member_csv_at_time, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, threshold_prox_distance_km, modelname, yearmonthday):
	reconstructed_sgdu_features = []
	reconstructed_line_features = []
	dic_of_convergent_feats = {}
	previous_converging_line_feats = []
	reconstruction_time = begin_reconstruction_time
	while(reconstruction_time >= end_reconstruction_time):
		reconstructed_sgdu_features[:] = []
		reconstructed_line_features[:] = []
		dic_of_convergent_feats.clear()
		valid_sgdu_features = [sgdu_ft for sgdu_ft in sgdu_features if (sgdu_ft.is_valid_at_time(reconstruction_time))]
		# #8ii) Reconstruct sgdu features to reconstruction time
		if (reference is not None):
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_sgdu_features = conv_bdn.find_final_reconstructed_geometries(reconstructed_sgdu_features, pygplates.PolygonOnSphere)
		#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
		temporary_sgdu_and_member_csv_at_time = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
		temp_sgdu_and_gdu_df = pd.read_csv(temporary_sgdu_and_member_csv_at_time, delimiter = ';', header = 0)
		list_of_line_feats_to_be_examined_for_collision = [line_ft for line_ft in conv_line_features if line_ft.is_valid_at_time(reconstruction_time)]
		if (len(list_of_line_feats_to_be_examined_for_collision) > 1):
			#reconstruct line features and examine them 
			reconstructed_line_features = []
			if (reference is not None):
				pygplates.reconstruct(output_line_feats_for_collision, rotation_model, reconstructed_line_features, reconstruction_time+time_interval, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(output_line_feats_for_collision, rotation_model, reconstructed_line_features, reconstruction_time+time_interval, group_with_feature = True)
			final_reconstructed_line_features = conv_bdn.find_final_reconstructed_geometries(reconstructed_line_features, pygplates.PolylineOnSphere)
			dic_of_convergent_feats.clear()
			for line_ft_1, line_1 in final_reconstructed_line_features:
				polylid_1 = line_ft_1.get_name()
				line_ft_1_gplateid = line_ft_1.get_feature_id()
				gdu_id_1 = line_ft_1.get_reconstruction_plate_id()
				for line_ft_2, line_2 in final_reconstructed_line_features:
					polylid_2 = line_ft_2.get_name()
					line_ft_2_gplateid = line_ft_2.get_feature_id()
					if (line_ft_1_gplateid != line_ft_2_gplateid and polylid_1 != polylid_2):
						name_of_pair = polylid_1+'_'+polylid_2
						rev_name_of_pair = polylid_2+'_'+polylid_1
						if (name_of_pair not in dic_of_divergent_feats and rev_name_of_pair not in dic_of_divergent_feats):
							key = name_of_pair
							gdu_id_2 = line_ft_2.get_reconstruction_plate_id()
							centroid_1 = line_1.get_centroid()
							centroid_2 = line_2.get_centroid()
							total_relative_reconstruction_rotation = conv_bdn.find_total_relative_reconstruction_rotation_(rotation_model, gdu_id_1, gdu_id_2, float(reconstruction_time)+time_interval, reference)
							total_stage_rel_rot_of_1_to_2 = conv_bdn.find_stage_relative_reconstruction_rotation_(rotation_model,gdu_id_1,gdu_id_2,float(reconstruction_time)+time_interval,float(reconstruction_time),reference)
							total_stage_rel_rot_of_2_to_1 = conv_bdn.find_stage_relative_reconstruction_rotation_(rotation_model,gdu_id_2,gdu_id_1,float(reconstruction_time)+time_interval,float(reconstruction_time),reference)
							cur_lat1,cur_lon1 = centroid_1.to_lat_lon()
							cur_lat2,cur_lon2 = centroid_2.to_lat_lon()
							at_current_time_distance_in_km_btw_1_and_2 = conv_bdn.calculate_distance_km_between_two_points_from_haversine_formula(cur_lat1,cur_lon1,cur_lat2,cur_lon1)
							if (total_relative_reconstruction_rotation is not None and at_current_time_distance_in_km_btw_1_and_2 <= threshold_prox_distance_km):
								if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
									E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
									stage_rel_E_pole = None
									if (total_stage_rel_rot_of_1_to_2 is not None):
										if (total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == False):
											stage_rel_E_pole,_ = total_stage_rel_rot_of_1_to_2.get_euler_pole_and_angle()
									elif (total_stage_rel_rot_of_2_to_1 is not None):
										if (total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == False):
											stage_rel_E_pole,_ = total_stage_rel_rot_of_2_to_1.get_euler_pole_and_angle()
									if (stage_rel_E_pole is None):
										stage_rel_E_pole = E_pole
									result_of_tectonic_motion = None
									if (total_stage_rel_rot_of_1_to_2 is not None and total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == False):
										result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_2, centroid_1, stage_rel_E_pole)
									elif (total_stage_rel_rot_of_2_to_1 is not None and total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == False):
										result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_1, centroid_2, stage_rel_E_pole)
									else:
										result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_2, centroid_1, stage_rel_E_pole)
									if (result_of_tectonic_motion != 'C'):
										if (total_stage_rel_rot_of_1_to_2 is not None and total_stage_rel_rot_of_2_to_1 is not None):
											stage_rel_E_pole,_ = total_stage_rel_rot_of_2_to_1.get_euler_pole_and_angle()
											result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_1, centroid_2, stage_rel_E_pole)
										else:
											stage_rel_E_pole = E_pole
											result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_2, centroid_1, stage_rel_E_pole)
									if (result_of_tectonic_motion is not None):
										if (result_of_tectonic_motion == 'C'):
											conv_line_feature_1, conv_line_feature_2 = None, None
											are_lines_similar = conv_bdn.are_two_PolylineOnSphere_similar(line_1,line_2)
											if (are_lines_similar == True or at_current_time_distance_in_km_btw_1_and_2 == 0.00):
												#create pair of line features associated with the rift point ft
												_,con_ocn_to_time = line_ft_1.get_valid_time()
												conv_line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=gdu_line_ft_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
												conv_line_feature_1.set_reconstruction_plate_id(gdu_id_1)
												conv_line_feature_1.set_conjugate_plate_id(gdu_id_2)
												conv_line_feature_1.set_description('convergent_margin')
												_,con_ocn_to_time = line_ft_2.get_valid_time()
												conv_line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=gdu_line_ft_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
												conv_line_feature_2.set_reconstruction_plate_id(gdu_id_2)
												conv_line_feature_2.set_conjugate_plate_id(gdu_id_1)
												conv_line_feature_2.set_description('convergent_margin')
												if (reference is None):
													pygplates.reverse_reconstruct([conv_line_feature_1,conv_line_feature_2],rotation_model,reconstruction_time)
												else:
													pygplates.reverse_reconstruct([conv_line_feature_1,conv_line_feature_2],rotation_model,reconstruction_time,reference)
												dic_of_convergent_feats[key] = (conv_line_feature_1,conv_line_feature_2)
												previous_converging_line_feats.append((conv_line_feature_1,conv_line_feature_2,reconstruction_time,at_current_time_distance_in_km_btw_1_and_2))
											elif (line_ft_1.is_valid_at_time(reconstruction_time_time - time_interval) == False or line_ft_2.is_valid_at_time(reconstruction_time_time - time_interval) == False):
												#create pair of line features associated with the rift point ft
												_,con_ocn_to_time = line_ft_1.get_valid_time()
												conv_line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=gdu_line_ft_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
												conv_line_feature_1.set_reconstruction_plate_id(gdu_id_1)
												conv_line_feature_1.set_conjugate_plate_id(gdu_id_2)
												conv_line_feature_1.set_description('convergent_margin')
												_,con_ocn_to_time = line_ft_2.get_valid_time()
												conv_line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=gdu_line_ft_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
												conv_line_feature_2.set_reconstruction_plate_id(gdu_id_2)
												conv_line_feature_2.set_conjugate_plate_id(gdu_id_1)
												conv_line_feature_2.set_description('convergent_margin')
												if (reference is None):
													pygplates.reverse_reconstruct([conv_line_feature_1,conv_line_feature_2],rotation_model,reconstruction_time)
												else:
													pygplates.reverse_reconstruct([conv_line_feature_1,conv_line_feature_2],rotation_model,reconstruction_time,reference)
												dic_of_convergent_feats[key] = (conv_line_feature_1,conv_line_feature_2)
												previous_converging_line_feats.append((conv_line_feature_1,conv_line_feature_2,reconstruction_time,at_current_time_distance_in_km_btw_1_and_2))
											else:
												SGDUID_for_line_ft_1 = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == line_feature_1.get_reconstruction_plate_id(),'SGDUID'].unique()
												SGDUID_for_line_ft_2 = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == line_feature_2.get_reconstruction_plate_id(),'SGDUID'].unique()
												is_valid_pair_of_line_fts = True
												for reconstructed_sgdu_ft_at_reconstruction_time, reconstructed_sgdu_at_reconstruction_time in final_reconstructed_sgdu_features:
													SGDUID_of_reconstructed_sgdu_ft = int(reconstructed_sgdu_ft_at_reconstruction_time.get_name())
													SGDUID_for_rand_sgdu_ft = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == SGDUID_of_reconstructed_sgdu_ft.get_reconstruction_plate_id(),'SGDUID'].unique()
													# #find the same value between SGDUID_for_gdu_ft and SGDUID_for_line_ft_1; SGDUID_for_gdu_ft and SGDUID_for_line_ft_2
													intersection_w_line_ft_1 = np.intersect1d(SGDUID_for_rand_sgdu_ft, SGDUID_for_line_ft_1)
													intersection_w_line_ft_2 = np.intersect1d(SGDUID_for_rand_sgdu_ft, SGDUID_for_line_ft_2)
													if ((SGDUID_of_reconstructed_sgdu_ft not in SGDUID_for_line_ft_1) and (SGDUID_of_reconstructed_sgdu_ft not in SGDUID_for_line_ft_2)):
														temporary_line_connecting_A_and_B = pygplates.PolylineOnSphere([reconstructed_point_A_at_to_time,reconstructed_point_B_at_to_time])
														if (reconstructed_sgdu_at_reconstruction_time.partition(temporary_line_connecting_A_and_B) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
															is_valid_pair_of_line_fts = False
															break
												if (is_valid_pair_of_line_fts == True):
													approx_rad_closest_dist_neighbour,closest_point_on_gdu1,closest_point_on_gdu2 = pygplates.GeometryOnSphere.distance(line_1, line_2, return_closest_positions = True)
													approx_mid_point = div_bdn.find_the_mid_of_two_PointOnSphere(closest_point_on_gdu1,closest_point_on_gdu2)
													left_gduid, right_gduid = None,None
													if (approx_mid_point != closest_point_on_gdu1 and approx_mid_point != closest_point_on_gdu2):
														#create an arc
														temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
														normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
														left_gduid, right_gduid = div_bdn.identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, closest_point_on_gdu1, closest_point_on_gdu2, gdu_id_1, gdu_id_2)
													#create pair of line features associated with the rift point ft
													_,con_ocn_to_time = line_ft_1.get_valid_time()
													conv_line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=gdu_line_ft_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
													conv_line_feature_1.set_reconstruction_plate_id(gdu_id_1)
													conv_line_feature_1.set_conjugate_plate_id(gdu_id_2)
													conv_line_feature_1.set_description('convergent_margin')
													_,con_ocn_to_time = line_ft_2.get_valid_time()
													conv_line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=gdu_line_ft_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
													conv_line_feature_2.set_reconstruction_plate_id(gdu_id_2)
													conv_line_feature_2.set_conjugate_plate_id(gdu_id_1)
													conv_line_feature_2.set_description('convergent_margin')
													if (reference is None):
														pygplates.reverse_reconstruct([conv_line_feature_1,conv_line_feature_2],rotation_model,reconstruction_time)
													else:
														pygplates.reverse_reconstruct([conv_line_feature_1,conv_line_feature_2],rotation_model,reconstruction_time,reference)
													dic_of_convergent_feats[key] = (conv_line_feature_1,conv_line_feature_2)
													previous_converging_line_feats.append((conv_line_feature_1,conv_line_feature_2,reconstruction_time,at_current_time_distance_in_km_btw_1_and_2))
		#update reconstruction_time
		reconstruction_time = reconstruction_time - time_interval