import sys
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import psycopg2
from config_plate_tectonics import config
import supporting_modules_to_be_converted as supporting
import supporting_topological_modules as tm
import supporting_topological_modules_for_MOR as MOR_topology
import supporting_modules_to_be_converted_2 as supporting_2
import rotation_utility

def recover_MOR_div_features_from_database_tables(name_of_table_for_MOR_features,name_of_database_table_for_tectonic_motion,name_of_table_for_recover_MOR_features,name_of_table_for_recover_div_features,line_features_collection,rotation_model,begin_reconstruction_time,end_reconstruction_time,interval,reference,modelname,yearmonthday):
	conn = None
	try:
		params = config()
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		MOR_record_cursor = conn.cursor()
		div_record_cursor = conn.cursor()
		cur_2 = conn.cursor()
		already_processed = []
		outputPointFeatureCollection = pygplates.FeatureCollection()
		outputPointFeatureCollection_2 = pygplates.FeatureCollection()
		outputPointFeatureCollection_All = pygplates.FeatureCollection()
		outputPointFeatureCollection_2_All = pygplates.FeatureCollection()
		reconstruction_time = begin_reconstruction_time
		reconstructed_line_features = []
		while(reconstruction_time > (end_reconstruction_time - interval)):
			already_processed[:] = [] #have to clear up at every reconstruction_time
			txt_1 = """SELECT MOR_ft_id,first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,first_line_name,second_line_name,at_angular_radius
					   FROM {input_name_of_table_for_MOR_features}
					   WHERE time = {input_time}"""
			sql_1 = txt_1.format(input_name_of_table_for_MOR_features = name_of_table_for_MOR_features, input_time = reconstruction_time)
			txt_2 = """SELECT * FROM {input_name_of_table_for_rel_pos_line_features}
						WHERE ((ref_ft_id = '{input_ref_ft_id}' and neighbour_ft_id = '{input_neighbour_ft_id}') or (ref_ft_id = '{input_neighbour_ft_id}' and neighbour_ft_id = '{input_ref_ft_id}'))
								AND time = {input_time}
								AND (tectonic_motion = 'Divergence' or tectonic_motion = 'Oblique_divergence')"""
			first_line_ft = None
			second_line_ft = None
			cur_1.execute(sql_1)
			row_1 = cur_1.fetchone()
			while(row_1 is not None):
				first_line_ft = None
				second_line_ft = None
				current_mor_ft_id = row_1[0]
				current_first_superGDU_represent_id = int(row_1[1])
				current_first_superGDU_name = str(row_1[2])
				current_second_superGDU_represent_id = int(row_1[3])
				current_second_superGDU_name = str(row_1[4])
				current_first_line_name = str(row_1[5])
				current_second_line_name = str(row_1[6])
				current_angular_deg = float(row_1[7])
				key = current_first_line_name+"_"+current_second_line_name+"$"+str(current_angular_deg)
				inversed_key = current_second_line_name+"_"+current_first_line_name+"$"+str(current_angular_deg)
				sql_2 = txt_2.format(input_name_of_table_for_rel_pos_line_features = name_of_database_table_for_tectonic_motion, input_ref_ft_id = current_first_line_name, input_neighbour_ft_id = current_second_line_name, input_time = reconstruction_time)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				
				if (key not in already_processed and inversed_key not in already_processed and row_2 is not None):
					already_processed.append(key)
					for line_ft in line_features_collection:
						if (line_ft.is_valid_at_time(reconstruction_time) and line_ft.get_name() == current_first_line_name):
							first_line_ft = line_ft
						if (line_ft.is_valid_at_time(reconstruction_time) and line_ft.get_name() == current_second_line_name):
							second_line_ft = line_ft
						if (first_line_ft is not None and second_line_ft is not None):
							break
					total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,current_first_superGDU_represent_id,current_second_superGDU_represent_id, reconstruction_time, reference)
					E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
					small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,current_angular_deg)
					#reconstruct line_features 
					reconstructed_line_features[:] = []
					if (reference is not None):
						pygplates.reconstruct(first_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
					else:
						pygplates.reconstruct(first_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
					final_reconstructed_first_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
					reconstructed_line_features[:] = []
					if (reference is not None):
						pygplates.reconstruct(second_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
					else:
						pygplates.reconstruct(second_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
					final_reconstructed_second_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
					temp_line_fts_collection = pygplates.FeatureCollection([first_line_ft,second_line_ft])
					list_of_centroid_ft = supporting_2.find_centroid_features_from_line_features(temp_line_fts_collection,False,None)
					first_centroid_ft = list_of_centroid_ft[0]
					second_centroid_ft = list_of_centroid_ft[1]
					most_appropriate_first_line = final_reconstructed_first_line_features[0][1]
					most_appropriate_second_line = final_reconstructed_second_line_features[0][1]
					_,chosen_pt_1,_ = pygplates.GeometryOnSphere.distance(most_appropriate_first_line,small_circle_boundary,return_closest_positions=True)
					_,chosen_pt_2,_ = pygplates.GeometryOnSphere.distance(most_appropriate_second_line,small_circle_boundary,return_closest_positions=True)
					#find MOR location
					MOR_location = tm.find_the_mid_of_two_PointOnSphere(chosen_pt_1,chosen_pt_2)
					great_circle_arc = pygplates.GreatCircleArc(MOR_location,E_pole)
					normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
					MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, MOR_location, valid_time = (reconstruction_time,0.00))
					MOR_location_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
					#MOR_location_ft.set_name(key)
					side_1 = MOR_topology.classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1)
					side_2 = MOR_topology.classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2)
					if (side_1 == 'left' and side_2 == 'right'):
						#MOR_location_ft.set_left_plate(current_first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
						#MOR_location_ft.set_right_plate(current_second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
						MOR_location_ft.set_left_plate(first_line_ft.get_reconstruction_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
						MOR_location_ft.set_right_plate(second_line_ft.get_reconstruction_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
						#name = 'name_of_SuperGDU_left_side'_'name_of_SuperGDU_right_side'$'represent_gduid_of_SuperGDU_left_side'_'represent_gduid_of_SuperGDU_right_side'
						MOR_location_ft.set_name(str(current_first_superGDU_name)+'_'+str(current_second_superGDU_name)+'$'+str(current_first_superGDU_represent_id)+'_'+str(current_second_superGDU_represent_id))
					elif (side_1 == 'right' and side_2 == 'left'):
						MOR_location_ft.set_left_plate(second_line_ft.get_reconstruction_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
						MOR_location_ft.set_right_plate(first_line_ft.get_reconstruction_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
						#name = 'name_of_SuperGDU_left_side'_'name_of_SuperGDU_right_side'$'represent_gduid_of_SuperGDU_left_side'_'represent_gduid_of_SuperGDU_right_side'
						MOR_location_ft.set_name(str(current_second_superGDU_name)+'_'+str(current_first_superGDU_name)+'$'+str(current_second_superGDU_represent_id)+'_'+str(current_first_superGDU_represent_id))
					else:
						print("Error unexpected values for side_1 and side_2")
						print("side_1, side_2", side_1, side_2)
						print(MOR_topology.calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1))
						print(MOR_topology.calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2))
						exit()
					MOR_location_ft.set_description(str(current_angular_deg))
					MOR_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,first_line_name,second_line_name,at_angular_radius) VALUES(%s, %s, %s, %s, %s, %s, %s, %s,%s)"""
					MOR_record_sql = MOR_record_txt.format(input_name_of_database_table = name_of_table_for_recover_MOR_features)
					print(MOR_record_sql)
					#print((reconstruction_time,MOR_location_ft.get_feature_id().get_string(),first_superGDU_represent_id,second_superGDU_represent_id,first_superGDU_name,second_superGDU_name,most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(), smallest_circle_angular_radius_degrees))
					MOR_record_cursor.execute(MOR_record_sql,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),current_first_superGDU_represent_id,current_first_superGDU_name,current_second_superGDU_represent_id,current_second_superGDU_name,current_first_line_name, current_second_line_name,current_angular_deg))
					
					#list_of_MOR_locations.append((at_age,MOR_location_ft.get_feature_id().get_string(),MOR_location_ft.get_left_plate(),MOR_location_ft.get_right_plate(),smallest_circle_angular_radius_degrees))
					outputPointFeatureCollection.add(MOR_location_ft)
					outputPointFeatureCollection_All.add(MOR_location_ft)
					#output chosen_pt_1 and chosen_pt_2
					pt1_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, chosen_pt_1, valid_time = (reconstruction_time,0.00))
					if (side_1 == 'left' and side_2 == 'right'):
						pt1_location_ft.set_left_plate(current_first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
						pt1_location_ft.set_right_plate(current_second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
					elif (side_1 == 'right' and side_2 == 'left'):
						pt1_location_ft.set_left_plate(current_second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
						pt1_location_ft.set_right_plate(current_first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
					pt1_location_ft.set_description(str(current_angular_deg))
					pt1_location_ft.set_reconstruction_plate_id(current_first_superGDU_represent_id)
					pt1_location_ft.set_name(str(current_first_superGDU_represent_id)+"_"+str(current_second_superGDU_represent_id))
					outputPointFeatureCollection_2.add(pt1_location_ft)
					outputPointFeatureCollection_2_All.add(pt1_location_ft)

					pt2_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, chosen_pt_2, valid_time = (reconstruction_time,0.00))
					if (side_1 == 'left' and side_2 == 'right'):
						pt2_location_ft.set_left_plate(current_first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
						pt2_location_ft.set_right_plate(current_second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
					elif (side_1 == 'right' and side_2 == 'left'):
						pt2_location_ft.set_left_plate(current_second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
						pt2_location_ft.set_right_plate(current_first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
					pt2_location_ft.set_description(str(current_angular_deg))
					pt2_location_ft.set_reconstruction_plate_id(current_second_superGDU_represent_id)
					pt2_location_ft.set_name(str(current_first_superGDU_represent_id)+"_"+str(current_second_superGDU_represent_id))
					outputPointFeatureCollection_2.add(pt2_location_ft)
					outputPointFeatureCollection_2_All.add(pt2_location_ft)
					
					if (side_1 == 'left' and side_2 == 'right'):
						div_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,left_div_gdu,right_div_gdu,left_div_ft,right_div_ft,at_angular_radius) VALUES(%s, %s, %s, %s, %s, %s, %s)"""
						div_record_sql = div_record_txt.format(input_name_of_database_table = name_of_table_for_recover_div_features)
						div_record_cursor.execute(div_record_sql,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),first_line_ft.get_reconstruction_plate_id(),second_line_ft.get_reconstruction_plate_id(),pt1_location_ft.get_feature_id().get_string(),pt2_location_ft.get_feature_id().get_string(), current_angular_deg))
						
					elif (side_1 == 'right' and side_2 == 'left'):
						div_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,left_div_gdu,right_div_gdu,left_div_ft,right_div_ft,at_angular_radius) VALUES(%s, %s, %s, %s, %s, %s, %s)"""
						div_record_sql = div_record_txt.format(input_name_of_database_table = name_of_table_for_recover_div_features)
						div_record_cursor.execute(div_record_sql,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),second_line_ft.get_reconstruction_plate_id(),first_line_ft.get_reconstruction_plate_id(),pt2_location_ft.get_feature_id().get_string(),pt1_location_ft.get_feature_id().get_string(), current_angular_deg))
					
					conn.commit()
				row_1 = cur_1.fetchone()
			if (len(outputPointFeatureCollection) > 0):
				if (reference is not None):
					pygplates.reverse_reconstruct(outputPointFeatureCollection,rotation_model,reconstruction_time,reference)
					pygplates.reverse_reconstruct(outputPointFeatureCollection_2,rotation_model,reconstruction_time,reference)
				else:
					pygplates.reverse_reconstruct(outputPointFeatureCollection,rotation_model,reconstruction_time)
					pygplates.reverse_reconstruct(outputPointFeatureCollection_2,rotation_model,reconstruction_time)
			
			if (len(outputPointFeatureCollection) > 0):
				outputPointFeatureCollection.write(r"C:\\Users\\Lavie\Desktop\\Research\\Winter2022\\tectonic_boundaries\\recover_oceanic_crust_features\\test_5_recover_MOR_location_features_from_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
				outputPointFeatureCollection_2.write(r"C:\\Users\\Lavie\Desktop\\Research\\Winter2022\\tectonic_boundaries\\recover_oceanic_crust_features\\test_5_recover_div_location_features_from_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
				outputPointFeatureCollection = pygplates.FeatureCollection()
				outputPointFeatureCollection_2 = pygplates.FeatureCollection()
			#update reconstruction_time
			reconstruction_time = reconstruction_time - interval
		if (len(outputPointFeatureCollection_All) > 0):
			outputPointFeatureCollection_All.write(r"C:\\Users\\Lavie\Desktop\\Research\\Winter2022\\tectonic_boundaries\\test_5_recover_MOR_location_features_from_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
			outputPointFeatureCollection_2_All.write(r"C:\\Users\\Lavie\Desktop\\Research\\Winter2022\\tectonic_boundaries\\test_5_recover_div_location_features_from_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
			# outputPointFeatureCollection = pygplates.FeatureCollection()
			# outputPointFeatureCollection_2 = pygplates.FeatureCollection()
	except(psycopg2.DatabaseError) as error:
		print("Error in recover_MOR_div_features_from_database_tables related to Database")
		print(error)
		exit()
	finally:
		conn.close()
