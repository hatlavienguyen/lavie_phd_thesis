import sys
import copy
import gc
import os
import csv
import enum
import math
import pandas as pd
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
import supporting_modules_to_be_converted_2 as supporting_2
import supporting_topological_modules as tm
import rotation_utility
import numpy as np
from functools import partial
import psycopg2
from config_plate_tectonics import config

def re_validate_pairs_of_line_features_for_tectonic_motion(name_of_table_for_initial_rel_pos_vector_motion,name_of_table_for_pairs_of_SuperGDUs_and_GDUs,line_features_collection,super_gdu_features_collection,rotation_model,begin_reconstruction_time,end_reconstruction_time,interval,reference,modelname,yearmonthday,is_for_subsequent_tectonic_motion):
	conn = None
	try:
		params = config()
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		update_record_cursor = conn.cursor()
		already_processed = []
		reconstruction_time = begin_reconstruction_time
		reconstructed_line_features = []
		reconstructed_super_gdu_features = []
		while(reconstruction_time > (end_reconstruction_time - interval)):
			already_processed[:] = [] #have to clear up at every reconstruction_time
			sql_1 = None
			if (is_for_subsequent_tectonic_motion == False):
				txt_1 = """SELECT p.first_superGDU_represent_id, p.second_superGDU_represent_id, m.ref_ft_id, m. neighbour_ft_id, m.tectonic_motion, p.at_angular_radius
					   FROM {input_name_of_table_for_initial_rel_pos_vector_motion} m
					   INNER JOIN {input_name_of_table_for_pairs_of_SuperGDUs_and_GDUs} p
					   ON (((m.ref_ft_id = p.first_line_name AND m.neighbour_ft_id = p.second_line_name) OR (m.ref_ft_id = p.second_line_name AND m.neighbour_ft_id = p.first_line_name))
							AND m.time = p.time)
					   WHERE m.time = {input_time} AND m.tectonic_motion != 'Invalid'"""
				sql_1 = txt_1.format(input_name_of_table_for_initial_rel_pos_vector_motion = name_of_table_for_initial_rel_pos_vector_motion, input_name_of_table_for_pairs_of_SuperGDUs_and_GDUs = name_of_table_for_pairs_of_SuperGDUs_and_GDUs, input_time = reconstruction_time)
			else:
				txt_1 = """SELECT p.first_superGDU_represent_id, p.second_superGDU_represent_id, m.ref_ft_id, m. neighbour_ft_id, m.tectonic_motion, p.at_angular_radius
					   FROM {input_name_of_table_for_initial_rel_pos_vector_motion} m
					   INNER JOIN {input_name_of_table_for_pairs_of_SuperGDUs_and_GDUs} p
					   ON (((m.ref_ft_id = p.first_line_name AND m.neighbour_ft_id = p.second_line_name) OR (m.ref_ft_id = p.second_line_name AND m.neighbour_ft_id = p.first_line_name))
							AND m.time = p.time - {input_time_interval})
					   WHERE m.time = {input_time} AND m.tectonic_motion != 'Invalid'"""
				sql_1 = txt_1.format(input_name_of_table_for_initial_rel_pos_vector_motion = name_of_table_for_initial_rel_pos_vector_motion, input_name_of_table_for_pairs_of_SuperGDUs_and_GDUs = name_of_table_for_pairs_of_SuperGDUs_and_GDUs, input_time = reconstruction_time, input_time_interval = interval)
			# if (is_for_subsequent_tectonic_motion == True):
				# sql_1 = txt_1.format(input_name_of_table_for_initial_rel_pos_vector_motion = name_of_table_for_initial_rel_pos_vector_motion, input_name_of_table_for_pairs_of_SuperGDUs_and_GDUs = name_of_table_for_pairs_of_SuperGDUs_and_GDUs, input_time = reconstruction_time-interval)
			# else:
				# sql_1 = txt_1.format(input_name_of_table_for_initial_rel_pos_vector_motion = name_of_table_for_initial_rel_pos_vector_motion, input_name_of_table_for_pairs_of_SuperGDUs_and_GDUs = name_of_table_for_pairs_of_SuperGDUs_and_GDUs, input_time = reconstruction_time)
			cur_1.execute(sql_1)
			row_1 = cur_1.fetchone()
			while(row_1 is not None):
				print("reconstruction_time",reconstruction_time)
				current_first_superGDU_represent_id = int(row_1[0])
				current_second_superGDU_represent_id = int(row_1[1])
				current_first_line_name = str(row_1[2])
				current_second_line_name = str(row_1[3])
				current_tectonic_motion = str(row_1[4])
				current_angular_deg = float(row_1[5])
				print("current_first_line_name",current_first_line_name,"current_second_line_name",current_second_line_name)
				print("current_angular_deg",current_angular_deg)
				key = current_first_line_name+"_"+current_second_line_name
				inversed_key = current_second_line_name+"_"+current_first_line_name
				first_line_ft = None
				second_line_ft = None
				if (key not in already_processed and inversed_key not in already_processed):
					already_processed.append(key)
					for line_ft in line_features_collection:
						if (is_for_subsequent_tectonic_motion == False):
							if (line_ft.is_valid_at_time(reconstruction_time) and line_ft.get_name() == current_first_line_name):
								first_line_ft = line_ft
							if (line_ft.is_valid_at_time(reconstruction_time) and line_ft.get_name() == current_second_line_name):
								second_line_ft = line_ft
						else:
							if (line_ft.is_valid_at_time(reconstruction_time-interval) and line_ft.get_name() == current_first_line_name):
								first_line_ft = line_ft
							if (line_ft.is_valid_at_time(reconstruction_time-interval) and line_ft.get_name() == current_second_line_name):
								second_line_ft = line_ft
						if (first_line_ft is not None and second_line_ft is not None):
							break
					if (first_line_ft is not None and second_line_ft is not None and is_for_subsequent_tectonic_motion == True):
						total_relative_reconstruction_rotation = None
						
						total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,current_first_superGDU_represent_id,current_second_superGDU_represent_id, reconstruction_time-interval, reference)
						E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
						small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,current_angular_deg)
						reconstructed_super_gdu_features[:] = []
						
						valid_SuperGDU_features = [superGDU_ft for superGDU_ft in super_gdu_features_collection if superGDU_ft.is_valid_at_time(reconstruction_time-interval)]
						#reconstructed features
						
						if (reference is not None):
							pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time-interval,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time-interval,group_with_feature = True)
						final_reconstructed_polygon_features = supporting.find_final_reconstructed_geometries(reconstructed_super_gdu_features,pygplates.PolygonOnSphere)
						#reconstruct line_features 
						reconstructed_line_features[:] = []
						
						if (reference is not None):
							pygplates.reconstruct(first_line_ft,rotation_model,reconstructed_line_features,reconstruction_time-interval,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(first_line_ft,rotation_model,reconstructed_line_features,reconstruction_time-interval,group_with_feature = True)
						final_reconstructed_first_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
						reconstructed_line_features[:] = []
						
						if (reference is not None):
							pygplates.reconstruct(second_line_ft,rotation_model,reconstructed_line_features,reconstruction_time-interval,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(second_line_ft,rotation_model,reconstructed_line_features,reconstruction_time-interval,group_with_feature = True)
						final_reconstructed_second_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
						first_line_ft, first_line = final_reconstructed_first_line_features[0]
						second_line_ft, second_line = final_reconstructed_second_line_features[0]
						first_SuperGDU = None
						second_SuperGDU = None
						first_SuperGDU_ft = None
						second_SuperGDU_ft = None
						centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
						centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
						for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
							if (pygplates.GeometryOnSphere.distance(SuperGDU,centroid_of_first_line) == 0.00 and pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU) == 0.00):
								first_SuperGDU = SuperGDU
								first_SuperGDU_ft = SuperGDU_ft
							if (pygplates.GeometryOnSphere.distance(SuperGDU,centroid_of_second_line) == 0.00 and pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU) == 0.00):
								second_SuperGDU = SuperGDU
								second_SuperGDU_ft = SuperGDU_ft
							if (first_SuperGDU_ft is not None and second_SuperGDU_ft is not None):
								break
						if (first_SuperGDU_ft is None):
							for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
								if (pygplates.GeometryOnSphere.distance(SuperGDU,first_line) == 0.00 and pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU) == 0.00):
									first_SuperGDU = SuperGDU
									first_SuperGDU_ft = SuperGDU_ft
									break
						if (second_SuperGDU_ft is None):
							for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
								if (pygplates.GeometryOnSphere.distance(SuperGDU,second_line) == 0.00 and pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU) == 0.00):
									second_SuperGDU = SuperGDU
									second_SuperGDU_ft = SuperGDU_ft
									break
						print("first_SuperGDU_ft",first_SuperGDU_ft,"second_SuperGDU_ft",second_SuperGDU_ft,"second_line_ft.get_reconstruction_plate_id()",second_line_ft.get_reconstruction_plate_id())
						print("first_line_ft.get_name()",first_line_ft.get_name())
						print("second_line_ft.get_name()",second_line_ft.get_name())
						print("reconstruction_time",reconstruction_time-interval)
						
						temp_ft_collection = pygplates.FeatureCollection()
						is_pair_of_lines_valid = True
						if (first_SuperGDU_ft is None or second_SuperGDU_ft is None):
							is_pair_of_lines_valid = False
						else:
							for in_btw_SuperGDU_ft,in_btw_SuperGDU in final_reconstructed_polygon_features:
								if (in_btw_SuperGDU_ft.get_feature_id() != first_SuperGDU_ft.get_feature_id() and in_btw_SuperGDU_ft.get_feature_id() != second_SuperGDU_ft.get_feature_id()):
									if (pygplates.GeometryOnSphere.distance(in_btw_SuperGDU,small_circle_boundary) == 0.00):
										result = supporting_2.is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_line, second_line, in_btw_SuperGDU)
										if (result == True):
											is_pair_of_lines_valid = False
											break
						if (is_pair_of_lines_valid == False):
							update_record_txt = """ UPDATE {input_name_of_database_table} 
												SET tectonic_motion = 'Invalid' WHERE time = {input_time} 
																				AND ((ref_ft_id = '{input_first_line_name}' AND neighbour_ft_id = '{input_second_line_name}') 
																						OR (ref_ft_id = '{input_second_line_name}' AND neighbour_ft_id = '{input_first_line_name}'))"""
							if (is_for_subsequent_tectonic_motion == False):
								update_record_sql = update_record_txt.format(input_name_of_database_table = name_of_table_for_initial_rel_pos_vector_motion, input_time = reconstruction_time, input_first_line_name = current_first_line_name, input_second_line_name = current_second_line_name)
								update_record_cursor.execute(update_record_sql)
							else:
								update_record_sql = update_record_txt.format(input_name_of_database_table = name_of_table_for_initial_rel_pos_vector_motion, input_time = reconstruction_time-interval, input_first_line_name = current_first_line_name, input_second_line_name = current_second_line_name)
								update_record_cursor.execute(update_record_sql)
					elif (first_line_ft is not None and second_line_ft is not None and is_for_subsequent_tectonic_motion == False):
						total_relative_reconstruction_rotation = None
						total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,current_first_superGDU_represent_id,current_second_superGDU_represent_id, reconstruction_time, reference)
						E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
						small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,current_angular_deg)
						reconstructed_super_gdu_features[:] = []
						valid_SuperGDU_features = [superGDU_ft for superGDU_ft in super_gdu_features_collection if superGDU_ft.is_valid_at_time(reconstruction_time)]
						#reconstructed features
						if (reference is not None):
							pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,group_with_feature = True)
						final_reconstructed_polygon_features = supporting.find_final_reconstructed_geometries(reconstructed_super_gdu_features,pygplates.PolygonOnSphere)
						#reconstruct line_features 
						reconstructed_line_features[:] = []
						if (reference is not None):
							pygplates.reconstruct(first_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(first_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
						final_reconstructed_first_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
						reconstructed_line_features[:] = []
						if (reference is not None):
							pygplates.reconstruct(second_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(second_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
						final_reconstructed_second_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
						first_line_ft, first_line = final_reconstructed_first_line_features[0]
						second_line_ft, second_line = final_reconstructed_second_line_features[0]
						first_SuperGDU = None
						second_SuperGDU = None
						first_SuperGDU_ft = None
						second_SuperGDU_ft = None
						centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
						centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
						for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
							if (pygplates.GeometryOnSphere.distance(SuperGDU,centroid_of_first_line) == 0.00 and pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU) == 0.00):
								first_SuperGDU = SuperGDU
								first_SuperGDU_ft = SuperGDU_ft
							if (pygplates.GeometryOnSphere.distance(SuperGDU,centroid_of_second_line) == 0.00 and pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU) == 0.00):
								second_SuperGDU = SuperGDU
								second_SuperGDU_ft = SuperGDU_ft
							if (first_SuperGDU_ft is not None and second_SuperGDU_ft is not None):
								break
						if (first_SuperGDU_ft is None):
							for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
								if (pygplates.GeometryOnSphere.distance(SuperGDU,first_line) == 0.00 and pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU) == 0.00):
									first_SuperGDU = SuperGDU
									first_SuperGDU_ft = SuperGDU_ft
									break
						if (second_SuperGDU_ft is None):
							for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
								if (pygplates.GeometryOnSphere.distance(SuperGDU,second_line) == 0.00  and pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU) == 0.00):
									second_SuperGDU = SuperGDU
									second_SuperGDU_ft = SuperGDU_ft
									break
						print("distance",pygplates.GeometryOnSphere.distance(small_circle_boundary,SuperGDU))
						print("first_SuperGDU_ft",first_SuperGDU_ft,"second_SuperGDU_ft",second_SuperGDU_ft)
						temp_ft_collection = pygplates.FeatureCollection()
						is_pair_of_lines_valid = True
						for in_btw_SuperGDU_ft,in_btw_SuperGDU in final_reconstructed_polygon_features:
							if (in_btw_SuperGDU_ft.get_feature_id() != first_SuperGDU_ft.get_feature_id() and in_btw_SuperGDU_ft.get_feature_id() != second_SuperGDU_ft.get_feature_id()):
								if (pygplates.GeometryOnSphere.distance(in_btw_SuperGDU,small_circle_boundary) == 0.00):
									result = supporting_2.is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_line, second_line, in_btw_SuperGDU)
									if (result == True):
										is_pair_of_lines_valid = False
										break
						if (is_pair_of_lines_valid == False):
							update_record_txt = """ UPDATE {input_name_of_database_table} 
												SET tectonic_motion = 'Invalid' WHERE time = {input_time} 
																				AND ((ref_ft_id = '{input_first_line_name}' AND neighbour_ft_id = '{input_second_line_name}') 
																						OR (ref_ft_id = '{input_second_line_name}' AND neighbour_ft_id = '{input_first_line_name}'))"""
							if (is_for_subsequent_tectonic_motion == False):
								update_record_sql = update_record_txt.format(input_name_of_database_table = name_of_table_for_initial_rel_pos_vector_motion, input_time = reconstruction_time, input_first_line_name = current_first_line_name, input_second_line_name = current_second_line_name)
								update_record_cursor.execute(update_record_sql)
							else:
								update_record_sql = update_record_txt.format(input_name_of_database_table = name_of_table_for_initial_rel_pos_vector_motion, input_time = reconstruction_time-interval, input_first_line_name = current_first_line_name, input_second_line_name = current_second_line_name)
								update_record_cursor.execute(update_record_sql)
					conn.commit()
				row_1 = cur_1.fetchone()
			#update reconstruction_time
			reconstruction_time = reconstruction_time - interval
	except(psycopg2.DatabaseError) as error:
		print("Error in re_validate_pairs_of_line_features_for_tectonic_motion related to Database")
		print(error)
		exit()
	finally:
		conn.close()

# def update_the_invalid_status_to_the_subsequent_tectonic_motion(name_of_table_for_main_rel_pos_vector_motion,name_for_table_for_subsequent_tectonic_motion,begin_reconstruction_time,end_reconstruction_time,interval):
	# conn = None
	# try:
		# params = config()
		# conn = psycopg2.connect(**params)
		# cur_1 = conn.cursor()
		# update_record_cursor = conn.cursor()
		# already_processed = []
		# reconstruction_time = begin_reconstruction_time
		# reconstructed_line_features = []
		# reconstructed_super_gdu_features = []
		# while(reconstruction_time > (end_reconstruction_time - interval)):
			# already_processed[:] = [] #have to clear up at every reconstruction_time
			# txt_1 = """SELECT ref_ft_id, neighbour_ft_id
					   # FROM {input_name_for_table_for_subsequent_tectonic_motion} m
					   # INNER JOIN {input_name_of_table_for_pairs_of_SuperGDUs_and_GDUs} p
					   # ON ((m.ref_ft_id = p.first_line_name AND m.neighbour_ft_id = p.second_line_name) OR (m.ref_ft_id = p.second_line_name AND m.neighbour_ft_id = p.first_line_name))
					   # WHERE m.time = {input_time} AND m.tectonic_motion != 'Invalid'"""
			# sql_1 = txt_1.format(input_name_of_table_for_initial_rel_pos_vector_motion = name_of_table_for_main_rel_pos_vector_motion, input_name_of_table_for_pairs_of_SuperGDUs_and_GDUs = name_of_table_for_pairs_of_SuperGDUs_and_GDUs, input_time = reconstruction_time)
			# cur_1.execute(sql_1)
			# row_1 = cur_1.fetchone()
			# while(row_1 is not None):
				# current_first_superGDU_represent_id = int(row_1[0])
				# current_second_superGDU_represent_id = int(row_1[1])
				# current_first_line_name = str(row_1[2])
				# current_second_line_name = str(row_1[3])
				# current_tectonic_motion = str(row_1[4])
				# current_angular_deg = float(row_1[5])
				# key = current_first_line_name+"_"+current_second_line_name
				# inversed_key = current_second_line_name+"_"+current_first_line_name
				# first_line_ft = None
				# second_line_ft = None
				# if (key not in already_processed and inversed_key not in already_processed):
					# already_processed.append(key)
					# for line_ft in line_features_collection:
						# if (line_ft.is_valid_at_time(reconstruction_time) and line_ft.get_name() == current_first_line_name):
							# first_line_ft = line_ft
						# if (line_ft.is_valid_at_time(reconstruction_time) and line_ft.get_name() == current_second_line_name):
							# second_line_ft = line_ft
						# if (first_line_ft is not None and second_line_ft is not None):
							# break
					# total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,current_first_superGDU_represent_id,current_second_superGDU_represent_id, reconstruction_time, reference)
					# E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
					# small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,current_angular_deg)
					# reconstructed_super_gdu_features[:] = []
					# valid_SuperGDU_features = [superGDU_ft for superGDU_ft in super_gdu_features_collection if superGDU_ft.is_valid_at_time(reconstruction_time)]
					# #reconstructed features
					# if (reference is not None):
						# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
					# else:
						# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,group_with_feature = True)
					# final_reconstructed_polygon_features = supporting.find_final_reconstructed_geometries(reconstructed_super_gdu_features,pygplates.PolygonOnSphere)
					# #reconstruct line_features 
					# reconstructed_line_features[:] = []
					# if (reference is not None):
						# pygplates.reconstruct(first_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
					# else:
						# pygplates.reconstruct(first_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
					# final_reconstructed_first_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
					# reconstructed_line_features[:] = []
					# if (reference is not None):
						# pygplates.reconstruct(second_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
					# else:
						# pygplates.reconstruct(second_line_ft,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
					# final_reconstructed_second_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
					# first_line_ft, first_line = final_reconstructed_first_line_features[0]
					# second_line_ft, second_line = final_reconstructed_second_line_features[0]
					# first_SuperGDU = None
					# second_SuperGDU = None
					# first_SuperGDU_ft = None
					# second_SuperGDU_ft = None
					# centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
					# centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
					# for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
						# if (pygplates.GeometryOnSphere.distance(SuperGDU,centroid_of_first_line) == 0.00):
							# first_SuperGDU = SuperGDU
							# first_SuperGDU_ft = SuperGDU_ft
						# if (pygplates.GeometryOnSphere.distance(SuperGDU,centroid_of_second_line) == 0.00):
							# second_SuperGDU = SuperGDU
							# second_SuperGDU_ft = SuperGDU_ft
						# if (first_SuperGDU_ft is not None and second_SuperGDU_ft is not None):
							# break
					# if (first_SuperGDU_ft is None):
						# for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
							# if (pygplates.GeometryOnSphere.distance(SuperGDU,first_line) == 0.00):
								# first_SuperGDU = SuperGDU
								# first_SuperGDU_ft = SuperGDU_ft
								# break
					# if (second_SuperGDU_ft is None):
						# for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
							# if (pygplates.GeometryOnSphere.distance(SuperGDU,second_line) == 0.00):
								# second_SuperGDU = SuperGDU
								# second_SuperGDU_ft = SuperGDU_ft
								# break
					# print("first_SuperGDU_ft",first_SuperGDU_ft,"second_SuperGDU_ft",second_SuperGDU_ft)
					# temp_ft_collection = pygplates.FeatureCollection()
					# is_pair_of_lines_valid = True
					# for in_btw_SuperGDU_ft,in_btw_SuperGDU in final_reconstructed_polygon_features:
						# if (in_btw_SuperGDU_ft.get_feature_id() != first_SuperGDU_ft.get_feature_id() and in_btw_SuperGDU_ft.get_feature_id() != second_SuperGDU_ft.get_feature_id()):
							# if (pygplates.GeometryOnSphere.distance(in_btw_SuperGDU,small_circle_boundary) == 0.00):
								# result = supporting_2.is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_line, second_line, in_btw_SuperGDU)
								# if (result == True):
									# is_pair_of_lines_valid = False
									# break
					# if (is_pair_of_lines_valid == False):
						# update_record_txt = """ UPDATE {input_name_of_database_table} 
												# SET tectonic_motion = 'Invalid' WHERE time = {input_time} 
																				# AND ((ref_ft_id = '{input_first_line_name}' AND neighbour_ft_id = '{input_second_line_name}') 
																						# OR (ref_ft_id = '{input_second_line_name}' AND neighbour_ft_id = '{input_first_line_name}'))"""
						# update_record_sql = update_record_txt.format(input_name_of_database_table = name_of_table_for_initial_rel_pos_vector_motion, input_time = reconstruction_time, input_first_line_name = current_first_line_name, input_second_line_name = current_second_line_name)
						# update_record_cursor.execute(update_record_sql)
					# conn.commit()
				# row_1 = cur_1.fetchone()
			# #update reconstruction_time
			# reconstruction_time = reconstruction_time - interval
	# except(psycopg2.DatabaseError) as error:
		# print("Error in re_validate_pairs_of_line_features_for_tectonic_motion related to Database")
		# print(error)
		# exit()
	# finally:
		# conn.close()