#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
import estimate_tectonic_plates as estimate
from multiprocessing import Pool
from os import environ
from time import sleep
import identify_kinematic_boundaries as identify_kin

#ncpus = int(environ['SLURM_CPUS_PER_TASK'])

def main():
	common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	gdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	gdu_features = pygplates.FeatureCollection(gdu_features_file)
	#line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_26_valid_single_dissolved_merged_POLGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230509.shp"
	line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_segment_POLYGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230921.shp"
	#line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/AFR_NAM_SAM_CON_OCN_from_test_32_PalaeoPlatesJan2023_20230628.shp"
	line_features_collection = pygplates.FeatureCollection(line_features_file)
	
	
	# common_filename_for_temporary_sgdu_and_members_csv = r"/home/hon686/projects/def-bre255/hon686/Geology/Research/Fall2023/PalaeoPlates/superGDU/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	# sgdu_features_file = r"/home/hon686/projects/def-bre255/hon686/Geology/Research/Fall2023/PalaeoPlates/superGDU/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	# gdu_features_file = r"/home/hon686/projects/def-bre255/hon686/Geology/Research/Fall2023/PalaeoPlates/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	# gdu_features = pygplates.FeatureCollection(gdu_features_file)
	# # #line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_26_valid_single_dissolved_merged_POLGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230509.shp"
	# line_features_file = r"/home/hon686/projects/def-bre255/hon686/Geology/Research/Fall2023/PalaeoPlates/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_valid_single_line_fts_All_PalaeoPlatesJan2023_20230628.shp"
	# # line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/AFR_NAM_SAM_CON_OCN_from_test_32_PalaeoPlatesJan2023_20230628.shp"
	# line_features_collection = pygplates.FeatureCollection(line_features_file)
	
	# line_feats_from_div_process_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/diverging_line_features_for_2800.0_5.0_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	# line_feats_from_div_process = pygplates.FeatureCollection(line_feats_from_div_process_file)
	# line_feats_from_conv_process_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/converging_line_features_for_2800.0_0.0_test_30_short_conv_PalaeoPlatesJan2023_20231023.shp"
	# line_feats_from_conv_process = pygplates.FeatureCollection(line_feats_from_conv_process_file)
	# plate_boundary_zone_feats_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
	# plate_boundary_zone_feats = pygplates.FeatureCollection(plate_boundary_zone_feats_file)
	# modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	# modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
	rift_csv_file = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	max_reconstruction_time_for_start_div = 250.00
	min_reconstruction_time_for_start_div = 195.00
	time_interval = 5.00
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_file = r"/home/hon686/projects/def-bre255/hon686/Geology/Research/Fall2023/PalaeoPlates/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	yearmonthday = '20240117'
	modelname = 'PalaeoPlatesendJan2023'
	threshold_diff_small_circle = 0.500

	identify_kin.find_additional_rift_point_features_from_initial_rift_point_features(threshold_diff_small_circle,rift_csv_file, line_features_collection, sgdu_features, gdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

if __name__ == '__main__':
	main()