import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import math
import pandas as pd
import geopandas as gpd

def merge_csv_file_of_pair_of_kine_line_features(pair_of_kin_line_from_conv_process_csv, pair_of_kin_line_from_div_process_csv, modelname, yearmonthday):
	pair_div_df = pd.read_csv(pair_of_kin_line_from_div_process_csv, header = 0)
	pair_conv_df = pd.read_csv(pair_of_kin_line_from_conv_process_csv, header = 0)
	final_pair_kin_df = pd.concat([pair_div_df, pair_conv_df], ignore_index=True)
	final_pair_kin_df.to_csv("all_pair_of_kinematic_line_features_"+modelname+"_"+yearmonthday+".csv")

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def find_lower_margin_of_convergent_margins(convergent_margins_w_upper_margins_shp, pair_of_conv_line_features_csv, modelname, yearmonthday):
	temporay_dic = {}
	dic_output = {'from_age':[],'to_age':[],'upper_margin':[],'lower_margin':[],'fid':[], 'upper_buffer_IPQ':[],'lower_buffer_IPQ':[]}
	pair_kin_df = pd.read_csv(pair_of_conv_line_features_csv)
	convergent_df = pair_kin_df.loc[pair_kin_df['type_kin'] == 'convergent_margin']
	convergent_margin_gdf = gpd.read_file(convergent_margins_w_upper_margins_shp)
	#unique_margin_gdf = gpd.read_file(all_unique_kin_line_shp)
	#upper_margin_records = convergent_margin_gdf.loc[convergent_margin_gdf['DESCR'] == 'upper_plate_margin',['FROMAGE','TOAGE','NAME','FEATURE_ID','buffer_IPQ']]
	
	upper_margin_records = convergent_margin_gdf.loc[(convergent_margin_gdf['buffer_IPQ'] <= 0.300) & (convergent_margin_gdf['buffer_IPQ'] > -1.00),['FROMAGE','TOAGE','NAME','FEATURE_ID','buffer_IPQ']]
	
	#convergent_margin_records = unique_margin_gdf.loc[unique_margin_gdf['DESCR'] == 'convergent_margin',['FROMAGE','TOAGE','NAME','FEATURE_ID']]
	#convergent_margin_records = convergent_margin_gdf.loc[convergent_margin_gdf['DESCR'] == 'convergent_margin',['FROMAGE','TOAGE','NAME','FEATURE_ID','buffer_IPQ']]
	convergent_margin_records = convergent_margin_gdf[['FROMAGE','TOAGE','NAME','FEATURE_ID','buffer_IPQ']]
	convergent_margin_records[['FROMAGE', 'TOAGE']] = convergent_margin_records[['FROMAGE', 'TOAGE']].astype('float64')
	for upper_from_age,upper_to_age,name,upper_fid,upper_ipq in upper_margin_records.itertuples(index = False, name = None):
		result = convergent_df.loc[((convergent_df['polylid1'] == name)|(convergent_df['polylid2'] == name)) & (convergent_df['from_time']>= upper_from_age) & (convergent_df['to_time'] <= upper_to_age), ['polylid1','polylid2']]
		if (len(result) > 0):
			for polylid1,polylid2 in result.itertuples(index = False, name = None):
				if (polylid1 == name):
					lower_margin_record = convergent_margin_records.loc[(convergent_margin_records['NAME'] == polylid2) & (convergent_margin_records['FROMAGE'] >= upper_from_age) & (convergent_margin_records['TOAGE'] <= upper_to_age),['FEATURE_ID','buffer_IPQ']]
					#lower_margin_record = convergent_margin_records.loc[(convergent_margin_records['NAME'] == polylid2) & (convergent_margin_records['FROMAGE'] >= upper_from_age) & (convergent_margin_records['TOAGE'] <= upper_to_age),['FROMAGE','TOAGE','FEATURE_ID']]
					if (len(lower_margin_record) > 0):
						for found_fid, buffer_IPQ in lower_margin_record.itertuples(index = False, name = None):
							print('found_fid',found_fid)
							dic_output['from_age'].append(upper_from_age)
							dic_output['to_age'].append(upper_to_age)
							dic_output['upper_margin'].append(name)
							dic_output['lower_margin'].append(polylid2)
							dic_output['fid'].append(found_fid)
							dic_output['upper_buffer_IPQ'].append(upper_ipq)
							dic_output['lower_buffer_IPQ'].append(buffer_IPQ)
						## for lower_from_age,lower_to_age,found_fid in lower_margin_record.itertuples(index = False, name = None):
							# if not(lower_from_age < upper_to_age or lower_to_age > upper_from_age):
								# print('found_fid',found_fid)
								# dic_output['from_age'].append(upper_from_age)
								# dic_output['to_age'].append(upper_to_age)
								# dic_output['upper_margin'].append(name)
								# dic_output['lower_margin'].append(polylid2)
								# dic_output['fid'].append(found_fid)
						
				elif (polylid2 == name):
					lower_margin_record = convergent_margin_records.loc[(convergent_margin_records['NAME'] == polylid1) & (convergent_margin_records['FROMAGE'] >= upper_from_age) & (convergent_margin_records['TOAGE'] <= upper_to_age),['FEATURE_ID','buffer_IPQ']]
					#lower_margin_record = convergent_margin_records.loc[(convergent_margin_records['NAME'] == polylid1) & (convergent_margin_records['FROMAGE'] >= upper_from_age) & (convergent_margin_records['TOAGE'] <= upper_to_age),['FROMAGE','TOAGE','FEATURE_ID']]
					if (len(lower_margin_record) > 0):
						for found_fid, buffer_IPQ in lower_margin_record.itertuples(index = False, name = None):
							print('found_fid',found_fid)
							dic_output['from_age'].append(upper_from_age)
							dic_output['to_age'].append(upper_to_age)
							dic_output['upper_margin'].append(name)
							dic_output['lower_margin'].append(polylid1)
							dic_output['fid'].append(found_fid)
							dic_output['upper_buffer_IPQ'].append(upper_ipq)
							dic_output['lower_buffer_IPQ'].append(buffer_IPQ)
						## for lower_from_age,lower_to_age,found_fid in lower_margin_record.itertuples(index = False, name = None):
							# if not(lower_from_age < upper_to_age or lower_to_age > upper_from_age):
								# print('found_fid',found_fid)
								# dic_output['from_age'].append(upper_from_age)
								# dic_output['to_age'].append(upper_to_age)
								# dic_output['upper_margin'].append(name)
								# dic_output['lower_margin'].append(polylid1)
								# dic_output['fid'].append(found_fid)
	
	df_output = pd.DataFrame.from_dict(dic_output)
	filename = 'upper_lower_margin_'+modelname+'_'+yearmonthday+'.csv'
	df_output.to_csv(filename, index = False)

def distinguish_upper_and_lower_margins_for_every_pair_of_convergent_margins_use_geometry_index(convergent_margins_w_geometry_index_shp, pair_of_conv_line_features_csv, csv_of_constrained_sub_zone_w_geometry_index, geometry_index, diff_btw_geometry_index, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, modelname, yearmonthday):
	convergent_features = pygplates.FeatureCollection(convergent_margins_w_geometry_index_shp)
	pair_kin_df = pd.read_csv(pair_of_conv_line_features_csv)
	constrained_csv_df = pd.read_csv(csv_of_constrained_sub_zone_w_geometry_index) #reconstruction_time,polylid,conv_fid,buffer_fid,buffer_IPQ
	convergent_df = pair_kin_df.loc[pair_kin_df['type_kin'] == 'convergent_margin'] #,from_time,to_time,type_kin,polylid1,polylid2,fid1,fid2
	output_upper_and_lower_fts = pygplates.FeatureCollection()
	output_unknown_conv_fts = pygplates.FeatureCollection()
	reconstructed_line_features = []
	
	dic = {}
	
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		valid_convergent_features = [conv_ft for conv_ft in convergent_features if conv_ft.is_valid_at_time(reconstruction_time)]
		print('reconstruction_time',reconstruction_time)
		#check each convergent feature and its conjugate feature
		#reconstructed_line_features[:] = []
		#if (reference is not None):
		#	pygplates.reconstruct(valid_convergent_features, rotation_model, reconstructed_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		#else:
		#	pygplates.reconstruct(valid_convergent_features, rotation_model, reconstructed_line_features, reconstruction_time, group_with_feature = True)
		#final_reconstructed_line_feats = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
		#for conv_line_ft, conv_line in final_reconstructed_line_feats:
		
		for conv_line_ft in valid_convergent_features:
			conv_fid = conv_line_ft.get_feature_id().get_string()
			conv_geometry_index = conv_line_ft.get_shapefile_attribute(geometry_index)
			
			conv_geometry_index_records = constrained_csv_df.loc[(constrained_csv_df['conv_fid'] == conv_fid) & (constrained_csv_df['reconstruction_time'] == reconstruction_time),geometry_index]
			if (len(conv_geometry_index_records) == 0):
				conv_geometry_index = -1.00
			else:
				conv_geometry_index = conv_geometry_index_records.values[0]
			#find its conjugate
			records = convergent_df.loc[(convergent_df['from_time'] >= reconstruction_time) & (convergent_df['to_time'] <= reconstruction_time) & ((convergent_df['fid1'] == conv_fid)|(convergent_df['fid2'] == conv_fid)),['fid1','fid2','from_time','to_time']]
			print('number of records',len(records))
			if (len(records) > 0):
				for fid1, fid2, from_time, to_time in records.itertuples(index = False, name = None):
					print('fid1, fid2, from_time, to_time',fid1, fid2, from_time, to_time)
					if (fid1 == conv_fid):
						#for conjugate_line_ft, conjugate_line in final_reconstructed_line_feats:
						for conjugate_line_ft in valid_convergent_features:
							conjugate_fid = conjugate_line_ft.get_feature_id().get_string()
							if (conjugate_fid == fid2):
								conjugate_geometry_index = conjugate_line_ft.get_shapefile_attribute(geometry_index)
								conjugate_geometry_index_records = constrained_csv_df.loc[(constrained_csv_df['conv_fid'] == conjugate_fid) & (constrained_csv_df['reconstruction_time'] == reconstruction_time),geometry_index]
								if (len(conjugate_geometry_index_records) == 0):
									conjugate_geometry_index = -1.00
								else:
									conjugate_geometry_index = conjugate_geometry_index_records.values[0]
								print('conjugate_geometry_index',conjugate_geometry_index)
								if ((conv_geometry_index > 0.00 and conjugate_geometry_index < 0.00) or (conv_geometry_index > 0.00 and conjugate_geometry_index > 0.00 and conjugate_geometry_index > conv_geometry_index and (conjugate_geometry_index - conv_geometry_index) >= diff_btw_geometry_index)):
									upper_ft = conv_line_ft.clone()
									upper_ft.set_description('upper_plate_margin')
									upper_ft.set_valid_time(reconstruction_time,to_time)
									upper_ft.set_shapefile_attribute('conj_fid',conjugate_fid)
									lower_ft = conjugate_line_ft.clone()
									lower_ft.set_description('lower_plate_margin')
									lower_ft.set_valid_time(reconstruction_time,to_time)
									lower_ft.set_shapefile_attribute('conj_fid',conv_fid)
									if (conv_fid in dic):
										prev_ft = dic[conv_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										# if (prev_ft.get_description() != 'upper_plate_margin'):
											# if (prev_ft.get_shapefile_attribute('conj_fid') ! = conjugate_fid):
												# dic[conv_fid] = upper_ft
										dic[conv_fid] = upper_ft
									else:
										dic[conv_fid] = upper_ft
									if (conjugate_fid in dic):
										prev_ft = dic[conjugate_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										# if (prev_ft.get_description() != 'lower_plate_margin'):
											# if (prev_ft.get_shapefile_attribute('conj_fid') ! = conv_fid):
												# dic[conjugate_fid] = lower_ft
										dic[conjugate_fid] = lower_ft
									else:
										dic[conjugate_fid] = lower_ft
									# output_upper_and_lower_fts.add(upper_ft)
									# output_upper_and_lower_fts.add(lower_ft)
								elif ((conv_geometry_index < 0.00 and conjugate_geometry_index > 0.00) or (conv_geometry_index > 0.00 and conjugate_geometry_index > 0.00 and conjugate_geometry_index < conv_geometry_index and (conv_geometry_index - conjugate_geometry_index) >= diff_btw_geometry_index)):
									lower_ft = conv_line_ft.clone()
									lower_ft.set_description('lower_plate_margin')
									lower_ft.set_valid_time(reconstruction_time,to_time)
									lower_ft.set_shapefile_attribute('conj_fid',conjugate_fid)
									upper_ft = conjugate_line_ft.clone()
									upper_ft.set_description('upper_plate_margin')
									upper_ft.set_shapefile_attribute('conj_fid',conv_fid)
									upper_ft.set_valid_time(reconstruction_time,to_time)
									
									#output_upper_and_lower_fts.add(upper_ft)
									#output_upper_and_lower_fts.add(lower_ft)
									
									if (conv_fid in dic):
										prev_ft = dic[conv_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conv_fid] = lower_ft
										# if (prev_ft.get_description() != 'lower_plate_margin'):
											# if (prev_ft.get_shapefile_attribute('conj_fid') ! = conjugate_fid):
												# dic[conv_fid] = lower_ft
									else:
										dic[conv_fid] = lower_ft
									if (conjugate_fid in dic):
										prev_ft = dic[conjugate_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conjugate_fid] = upper_ft
										# if (prev_ft.get_description() != 'upper_plate_margin'):
											# if (prev_ft.get_shapefile_attribute('conj_fid') ! = conv_fid):
												# dic[conjugate_fid] = upper_ft
									else:
										dic[conjugate_fid] = upper_ft
								else:
									conv_ft_1 = conv_line_ft.clone()
									conv_ft_1.set_shapefile_attribute('conj_fid',conjugate_fid)
									conv_ft_2 = conjugate_line_ft.clone()
									conv_ft_2.set_shapefile_attribute('conj_fid',conv_fid)
									
									if (conv_fid in dic):
										prev_ft = dic[conv_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conv_fid] = conv_ft_1
									else:
										dic[conv_fid] = conv_ft_1
									if (conjugate_fid in dic):
										prev_ft = dic[conjugate_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conjugate_fid] = conv_ft_2
									else:
										dic[conjugate_fid] = conv_ft_2
									# output_unknown_conv_fts.add(conv_ft_1)
									# output_unknown_conv_fts.add(conv_ft_2)
								
					elif (fid2 == conv_fid):
						#for conjugate_line_ft, conjugate_line in final_reconstructed_line_feats:
						for conjugate_line_ft in valid_convergent_features:
							conjugate_fid = conjugate_line_ft.get_feature_id().get_string()
							if (conjugate_fid == fid1):
								conjugate_geometry_index = conjugate_line_ft.get_shapefile_attribute(geometry_index)
								conjugate_geometry_index_records = constrained_csv_df.loc[(constrained_csv_df['conv_fid'] == conjugate_fid) & (constrained_csv_df['reconstruction_time'] == reconstruction_time),geometry_index]
								if (len(conjugate_geometry_index_records) == 0):
									conjugate_geometry_index = -1.00
								else:
									conjugate_geometry_index = conjugate_geometry_index_records.values[0]
								print('conjugate_geometry_index',conjugate_geometry_index)
								if ((conv_geometry_index > 0.00 and conjugate_geometry_index < 0.00) or (conv_geometry_index > 0.00 and conjugate_geometry_index > 0.00 and conjugate_geometry_index > conv_geometry_index and (conjugate_geometry_index - conv_geometry_index) >= diff_btw_geometry_index)):
									upper_ft = conv_line_ft.clone()
									upper_ft.set_description('upper_plate_margin')
									upper_ft.set_shapefile_attribute('conj_fid',conjugate_fid)
									upper_ft.set_valid_time(reconstruction_time,to_time)
									lower_ft = conjugate_line_ft.clone()
									lower_ft.set_description('lower_plate_margin')
									lower_ft.set_shapefile_attribute('conj_fid',conv_fid)
									lower_ft.set_valid_time(reconstruction_time,to_time)
									
									#output_upper_and_lower_fts.add(upper_ft)
									#output_upper_and_lower_fts.add(lower_ft)
									
									if (conv_fid in dic):
										prev_ft = dic[conv_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conv_fid] = upper_ft
										# if (prev_ft.get_description() != 'upper_plate_margin'):
											# if (prev_ft.get_shapefile_attribute('conj_fid') ! = conjugate_fid):
												# dic[conv_fid] = upper_ft
									else:
										dic[conv_fid] = upper_ft
									if (conjugate_fid in dic):
										prev_ft = dic[conjugate_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conjugate_fid] = lower_ft
										# if (prev_ft.get_description() != 'lower_plate_margin'):
											# if (prev_ft.get_shapefile_attribute('conj_fid') ! = conv_fid):
												# dic[conjugate_fid] = lower_ft
									else:
										dic[conjugate_fid] = lower_ft 
								elif ((conv_geometry_index < 0.00 and conjugate_geometry_index > 0.00) or (conv_geometry_index > 0.00 and conjugate_geometry_index > 0.00 and conjugate_geometry_index < conv_geometry_index and (conv_geometry_index - conjugate_geometry_index) >= diff_btw_geometry_index)):
									lower_ft = conv_line_ft.clone()
									lower_ft.set_description('lower_plate_margin')
									lower_ft.set_shapefile_attribute('conj_fid',conjugate_fid)
									lower_ft.set_valid_time(reconstruction_time,to_time)
									upper_ft = conjugate_line_ft.clone()
									upper_ft.set_description('upper_plate_margin')
									upper_ft.set_shapefile_attribute('conj_fid',conv_fid)
									upper_ft.set_valid_time(reconstruction_time,to_time)
									# output_upper_and_lower_fts.add(upper_ft)
									# output_upper_and_lower_fts.add(lower_ft)
									
									if (conv_fid in dic):
										prev_ft = dic[conv_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conv_fid] = lower_ft
										# if (prev_ft.get_description() != 'lower_plate_margin'):
											# if (prev_ft.get_shapefile_attribute('conj_fid') ! = conjugate_fid):
												# dic[conv_fid] = lower_ft
									else:
										dic[conv_fid] = lower_ft
									if (conjugate_fid in dic):
										prev_ft = dic[conjugate_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conjugate_fid] = upper_ft
										# if (prev_ft.get_description() != 'upper_plate_margin'):
											# if (prev_ft.get_shapefile_attribute('conj_fid') ! = conv_fid):
												# dic[conjugate_fid] = upper_ft
									else:
										dic[conjugate_fid] = upper_ft
								else:
									conv_ft_1 = conv_line_ft.clone()
									conv_ft_1.set_shapefile_attribute('conj_fid',conjugate_fid)
									conv_ft_2 = conjugate_line_ft.clone()
									conv_ft_2.set_shapefile_attribute('conj_fid',conv_fid)
									# output_unknown_conv_fts.add(conv_ft_1)
									# output_unknown_conv_fts.add(conv_ft_2)
									
									if (conv_fid in dic):
										prev_ft = dic[conv_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conv_fid] = conv_ft_1
									else:
										dic[conv_fid] = conv_ft_1
									if (conjugate_fid in dic):
										prev_ft = dic[conjugate_fid]
										prev_from_time,prev_to_time = prev_ft.get_valid_time()
										if (prev_to_time >= reconstruction_time):
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										elif (prev_to_time < reconstruction_time):
											prev_ft.set_valid_time(prev_from_time,reconstruction_time)
											if (prev_ft.get_description() != 'convergent_margin'):
												output_upper_and_lower_fts.add(prev_ft)
											else:
												output_unknown_conv_fts.add(prev_ft)
										dic[conjugate_fid] = conv_ft_2
									else:
										dic[conjugate_fid] = conv_ft_2
			else:
				print("Error:could not find conjugate features")
				print("reconstruction_time",reconstruction_time)
				print(conv_fid)
				print(conv_line_ft.get_name())
		reconstruction_time = reconstruction_time - time_interval
	
	for fid in dic:
		ft = dic[fid]
		if (ft.get_description() != 'convergent_margin'):
			output_upper_and_lower_fts.add(ft)
	output_upper_and_lower_fts.write('upper_and_lower_margins_for_pairs_of_convergent_margins_use_'+geometry_index+'_'+str(diff_btw_geometry_index)+'_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
	
	for fid in dic:
		ft = dic[fid]
		if (ft.get_description() == 'convergent_margin'):
			output_unknown_conv_fts.add(ft)
	output_unknown_conv_fts.write('unconstrained_pairs_of_convergent_margins_use_'+geometry_index+'_'+str(diff_btw_geometry_index)+'_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

if __name__=='__main__':
	pair_of_kin_line_from_conv_process_csv = r'pairs_of_kin_line_fts_from_conv_bdn_process_for_test_30_short_conv_PalaeoPlatesJan2023_20231023.csv'
	pair_of_kin_line_from_div_process_csv = r'pairs_of_kin_line_fts_from_div_bdn_process_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv'
	modelname = 'PalaeoPlatesendJan2023'
	#yearmonthday = '20241007'
	yearmonthday = '20241201'
	#merge_csv_file_of_pair_of_kine_line_features(pair_of_kin_line_from_conv_process_csv, pair_of_kin_line_from_div_process_csv, modelname, yearmonthday)
	pair_of_conv_line_features_csv = r'all_pair_of_kinematic_line_features_PalaeoPlatesendJan2023_20240902.csv'
	
	all_unique_kin_line_shp = r'final_unique_kine_line_feats_test_3_PalaeoPlatesendJan2023_20240402.shp'
	#convergent_margins_w_upper_margins_shp = r'constrained_conv_margins_from_unique_v3_test_29_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.2.shp'
	#convergent_margins_w_upper_margins_shp = r'D:\Dell_Latitude_Backup\Research_Sept_2024\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_test_5_both_kin_processes_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.35.shp'
	#convergent_margins_w_upper_margins_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_v3_test_29_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.0.shp"
	
	convergent_margins_w_upper_margins_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_v3_test_29_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.0_v2.shp"
	#find_lower_margin_of_convergent_margins(convergent_margins_w_upper_margins_shp, pair_of_conv_line_features_csv, modelname, yearmonthday)
	
	csv_of_constrained_sub_zone_w_geometry_index = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\records_of_constrained_subduction_zone_features_w_dissolved_buffered_IPQ_0.0_2800.0_0.0_PalaeoPlatesendJan2023_20240903.csv"
	#convergent_margins_w_geometry_index_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_v3_test_29_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.0_v2.shp"
	convergent_margins_w_geometry_index_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_kin_margins_for_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_20241201.shp"
	
	geometry_index = 'buffer_IPQ'
	diff_btw_geometry_index = 0.0100
	begin_reconstruction_time = 2800.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	reference = 700
	#distinguish_upper_and_lower_margins_for_every_pair_of_convergent_margins_use_geometry_index(convergent_margins_w_geometry_index_shp, pair_of_conv_line_features_csv, csv_of_constrained_sub_zone_w_geometry_index, geometry_index, diff_btw_geometry_index, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, modelname, yearmonthday)
	
	
	pair_of_kin_line_from_conv_process_csv = r'pairs_of_kin_line_fts_from_conv_bdn_process_for_test_12_EB2022_20231023.csv'
	pair_of_kin_line_from_div_process_csv = r'pairs_of_kin_line_fts_from_div_bdn_process_for_test_8_EB2022_20231020.csv'
	modelname = 'Merdith_et_al_2021'
	yearmonthday = '20241127'
	merge_csv_file_of_pair_of_kine_line_features(pair_of_kin_line_from_conv_process_csv, pair_of_kin_line_from_div_process_csv, modelname, yearmonthday)
	pair_of_conv_line_features_csv = r'all_pair_of_kinematic_line_features_Merdith_et_al_2021_20241127.csv'
	
	all_unique_kin_line_shp = r'final_unique_kine_line_feats_test_3_PalaeoPlatesendJan2023_20240402.shp'
	#convergent_margins_w_upper_margins_shp = r'constrained_conv_margins_from_unique_v3_test_29_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.2.shp'
	#convergent_margins_w_upper_margins_shp = r'D:\Dell_Latitude_Backup\Research_Sept_2024\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_test_5_both_kin_processes_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.35.shp'
	#convergent_margins_w_upper_margins_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_v3_test_29_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.0.shp"
	
	#convergent_margins_w_upper_margins_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_v3_test_29_PalaeoPlatesendJan2023_XYCrystAll_polygons_IPQ_0.0_v2.shp"
	#find_lower_margin_of_convergent_margins(convergent_margins_w_upper_margins_shp, pair_of_conv_line_features_csv, modelname, yearmonthday)
	
	csv_of_constrained_sub_zone_w_geometry_index = r"C:\Users\lavie\Desktop\Research\Summer2023\buffer_zones_for_point_features\records_of_constrained_subduction_zone_features_w_dissolved_buffered_IPQ_0.0_995.0_0.0_Merdith_et_al_2021_20241126.csv"
	convergent_margins_w_geometry_index_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\constrained_conv_margins_from_unique_test_3_Merdith_et_al_2021_XYCrystAll_polygons_IPQ_20241127.shp"
	
	geometry_index = 'buffer_IPQ'
	diff_btw_geometry_index = 0.0100
	begin_reconstruction_time = 995.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	reference = 0
	distinguish_upper_and_lower_margins_for_every_pair_of_convergent_margins_use_geometry_index(convergent_margins_w_geometry_index_shp, pair_of_conv_line_features_csv, csv_of_constrained_sub_zone_w_geometry_index, geometry_index, diff_btw_geometry_index, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, modelname, yearmonthday)