import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates

def reconstruct_features_to_reconstruction_time(features, reconstruction_time, rotation_model, reference):
	valid_feats = [ft for ft in features if ft.is_valid_at_time(reconstruction_time)]
	if (len(valid_feats) > 0):
		reconstructed_results = []
		if (reference is not None):
			pygplates.reconstruct(valid_feats, rotation_model, reconstructed_results, reconstruction_time, anchor_plate_id = reference,group_with_feature = True)
		else:
			pygplates.reconstruct(valid_feats, rotation_model, reconstructed_results, reconstruction_time,group_with_feature = True)
		if (len(reconstructed_results) > 0):
			for reconstr_ft,reconstructed_ft_geometries in reconstructed_results:
				if (len(reconstructed_ft_geometries) > 1):
					print('number of reconstructed_ft_geometries',len(reconstructed_ft_geometries))
					for ft_geometry in reconstructed_ft_geometries:
						print('reconstr_ft',reconstr_ft.get_feature_id().get_string())
						print('plate_id',reconstr_ft.get_reconstruction_plate_id())
						print('valid_time',reconstr_ft.get_valid_time())
						geom = ft_geometry.get_reconstructed_geometry()
						if (type(geom) == pygplates.PolygonOnSphere or type(geom) == pygplates.PolylineOnSphere):
							print('geom',geom.to_lat_lon_list())
							print('number of points',len(geom.to_lat_lon_list()))
						else:
							print('geom',geom.to_lat_lon())

def main():
	features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	features = pygplates.FeatureCollection(features_file)
	reconstruction_time = 100.00
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	reconstruct_features_to_reconstruction_time(features, reconstruction_time, rotation_model, reference)

if __name__=='__main__':
	main()