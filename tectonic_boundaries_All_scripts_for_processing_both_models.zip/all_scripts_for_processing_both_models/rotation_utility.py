#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
import pygplates
import numpy as np
import math 

def create_3D_rotation_matrix_about_x_axis(a):
	"""
		work in progress
	"""
	

def create_3D_rotation_matrix_about_y_axis(a):
	"""
		work in progress
	"""

def create_3D_rotation_matrix_about_z_axis(a):
	"""
		work in progress
	"""

def find_small_circle_feature(small_circle_latitude,small_circle_longitude,small_circle_angular_radius_degrees,small_circle_reconstruction_plate_id,small_circle_name,small_circle_begin_time,small_circle_end_time): #all credits to John Cannon from EarthByte
	# Small circle parameters.
	small_circle_latitude = 22.41
	small_circle_longitude = -80.57
	small_circle_angular_radius_degrees = 5.0
	small_circle_reconstruction_plate_id = 700
	small_circle_name = 'Small Circle'
	small_circle_begin_time = 140.0
	small_circle_end_time = 135.0

	# Create empty small circle feature.
	small_circle_feature_type = pygplates.FeatureType.create_gpml('SmallCircle')
	small_circle_feature = pygplates.Feature(small_circle_feature_type)

	# Small circle centre point.
	small_circle_centre = pygplates.PointOnSphere(small_circle_latitude, small_circle_longitude)

	# Add parameters to small circle feature.
	small_circle_feature.set_geometry(small_circle_centre)
	small_circle_feature.set_reconstruction_plate_id(small_circle_reconstruction_plate_id)
	small_circle_feature.set_name(small_circle_name)
	small_circle_feature.set_valid_time(small_circle_begin_time, small_circle_end_time)
	# Setting the angular radius parameter is more complicated:
	# 1) You need to explicitly specify the property name 'gpml:angularRadius'.
	#    This is because there's no common function like 'small_circle_feature.set_angular_radius()'.
	# 2) You need to turn off validation with the GPlates Geological Information Model (GPGIM).
	#    This is because the GPGIM expects the property to be a GpmlMeasure
	#    (which we don't have in pyGPlates). Instead we create essentially the same thing
	#    (an XsDouble property) using 'small_circle_feature.set_double()'.
	#    But we have to tell the GPGIM to disregard this.
	small_circle_feature.set_double(pygplates.PropertyName.create_gpml('angularRadius'),small_circle_angular_radius_degrees,pygplates.VerifyInformationModel.no)
	return small_circle_feature

def get_any_perpendicular(point_on_sphere):
	"""
	Find any point perpendicular to 'point_on_sphere'.
	In other words any point on the great circle that is 90 degrees away from 'point_on_sphere'.
	"""
	# The vector cross product of 'point_on_sphere' with any point that is not coincident with it will point
	# in a direction that is perpendicular to 'point_on_sphere'.
	unnormalised_perp = pygplates.Vector3D.cross(pygplates.Vector3D.x_axis, point_on_sphere.to_xyz())
	if unnormalised_perp.is_zero_magnitude():
		# Oops, seems the 'point_on_sphere' is along the x-axis, so pick the y-axis instead.
		unnormalised_perp = pygplates.Vector3D.cross(pygplates.Vector3D.y_axis, point_on_sphere.to_xyz())
	
	#Points on the sphere are unit length (normalisation will make it unit length).
	return pygplates.PointOnSphere(unnormalised_perp.to_normalised().to_xyz())


def tessellate_small_circle(
	centre_point_on_sphere,
	angular_radius_degrees,
	num_points):
	"""
	Generate 'num_points' points (pygplates.PointOnSphere) for the small circle with specified centre and angular radius.
	"""
	# Get any point on the small circle.
	# This will be our starting point for generating the remaining small circle points.
	#
	# The start point is obtained by taking any rotation axis perpendicular to the small circle centre and
	# rotating the small circle centre, using that rotation axis, by the small circle angular radius.
	start_point_rotation_axis = get_any_perpendicular(centre_point_on_sphere)
	start_point_rotation = pygplates.FiniteRotation(
		start_point_rotation_axis,
		math.radians(angular_radius_degrees))
	start_point = start_point_rotation * centre_point_on_sphere
	
	# Get the rotation that generates the next tessellated point in the small circle (from the previous point).
	tessellate_angle_radians = 2 * math.pi / num_points
	tessellate_rotation = pygplates.FiniteRotation(
		centre_point_on_sphere,
		tessellate_angle_radians)
	
	small_circle_points = []
	
	# Starting  with the start point (on the small circle) generate all 'num_points' points on the small circle.
	small_circle_point = start_point
	for n in range(num_points):
		small_circle_point = tessellate_rotation * small_circle_point
		small_circle_points.append(small_circle_point)
	
	return small_circle_points

def create_small_circle_PolygonOnSphere_feature(small_circle_centre,small_circle_angular_radius_degrees,small_circle_reconstruction_plate_id,small_circle_begin_time,small_circle_end_time):
	num_points_in_small_circle = 100
	#print(get_any_perpendicular(small_circle_centre).to_lat_lon())
	small_circle_points = tessellate_small_circle(
		small_circle_centre,
		small_circle_angular_radius_degrees,
		num_points_in_small_circle)

	# Create a small circle feature, but of type 'UnclassifiedFeature' since type 'SmallCircle'
	# is expecting a centre *point* and angular radius. But we're giving it a polygon
	# (tessellated small circle). Note that the polygon is just to join the dots of our
	# tessellated small circle (each segment/arc of the polygon is actually a *great* circle arc,
	# but when you have enough points you don't notice this).
	small_circle_polygon = pygplates.PolygonOnSphere(small_circle_points)
	small_circle_tessellated_feature = pygplates.Feature.create_reconstructable_feature(
			pygplates.FeatureType.gpml_unclassified_feature,
			small_circle_polygon,
			name='small_circle',
			valid_time=(small_circle_begin_time, small_circle_end_time),
			reconstruction_plate_id=small_circle_reconstruction_plate_id)
	return small_circle_tessellated_feature

def create_small_circle_PolygonOnSphere(small_circle_centre,small_circle_angular_radius_degrees):
	num_points_in_small_circle = 100
	#print(get_any_perpendicular(small_circle_centre).to_lat_lon())
	small_circle_points = tessellate_small_circle(
		small_circle_centre,
		small_circle_angular_radius_degrees,
		num_points_in_small_circle)

	# Create a small circle feature, but of type 'UnclassifiedFeature' since type 'SmallCircle'
	# is expecting a centre *point* and angular radius. But we're giving it a polygon
	# (tessellated small circle). Note that the polygon is just to join the dots of our
	# tessellated small circle (each segment/arc of the polygon is actually a *great* circle arc,
	# but when you have enough points you don't notice this).
	small_circle_polygon = pygplates.PolygonOnSphere(small_circle_points)
	return small_circle_polygon

def create_small_circle_PolylineOnSphere(small_circle_centre,small_circle_angular_radius_degrees):
	num_points_in_small_circle = 100
	#print(get_any_perpendicular(small_circle_centre).to_lat_lon())
	small_circle_points = tessellate_small_circle(
		small_circle_centre,
		small_circle_angular_radius_degrees,
		num_points_in_small_circle)

	# Create a small circle feature, but of type 'UnclassifiedFeature' since type 'SmallCircle'
	# is expecting a centre *point* and angular radius. But we're giving it a polygon
	# (tessellated small circle). Note that the polygon is just to join the dots of our
	# tessellated small circle (each segment/arc of the polygon is actually a *great* circle arc,
	# but when you have enough points you don't notice this).
	small_circle_line = pygplates.PolylineOnSphere(small_circle_points)
	return small_circle_line