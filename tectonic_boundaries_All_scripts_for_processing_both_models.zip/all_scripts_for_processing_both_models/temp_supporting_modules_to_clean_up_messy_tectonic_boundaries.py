import sys
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
import supporting_topological_modules as supporting_topology
import rotation_utility
import psycopg2
from config_plate_tectonics import config
import math
import pandas as pd


def is_two_time_periods_overlapping(begin_1,end_1,begin_2,end_2,specialized_for_possible_subduction_zone_valid,interval_time_for_kin_eval,verbose):
	'''
		This function is designed to check whether any two time periods overlapping with each other
		begin_1,end_1: the first time period
		begin_2,end_2: the second time period
		specialized_for_possible_subduction_zone_valid: is a boolean flag to tell us whether or not; the result is for evaluating possible subduction zone
		interval_time_for_kin_eval: if the boolean flag is True, we will do the special check.
			Rather than simply using the original time begin and end time, we will check whether the difference between these two time interval is greater than interval_time_for_kin_eval
	'''
	if (specialized_for_possible_subduction_zone_valid == False):
		if (end_1 >= begin_2 or end_2 >= begin_1):
			return False
		else:
			return True
	else:
		if(verbose == True):
			print('begin_1,end_1')
			print(begin_1,end_1)
			print('begin_2,end_2')
			print(begin_2,end_2)
			print(abs(end_1 - begin_2) > interval_time_for_kin_eval)
			print(abs(end_2 - begin_1) > interval_time_for_kin_eval)
		if (end_1 >= begin_2):
			if (abs(end_1 - begin_2) > interval_time_for_kin_eval):
				return False
			else:
				return True
		elif (end_2 >= begin_1):
			if (abs(end_2 - begin_1) > interval_time_for_kin_eval):
				return True
			else:
				return False 
		else:
			return True

def find_pairs_of_tectonic_boundaries(tectonic_boundaries_features):
	dic = {}
	for tectonic_bdn_ft in tectonic_boundaries_features:
		initial_bdn_ft_id = tectonic_bdn_ft.get_name()
		begin_age_1,end_age_1 = tectonic_bdn_ft.get_valid_time()
		for other_tectonic_bdn_ft in tectonic_boundaries_features:
			other_initial_bdn_ft_id = other_tectonic_bdn_ft.get_name()
			key_for_dic = initial_bdn_ft_id+"_"+other_initial_bdn_ft_id+"_"+str(begin_age_1)
			reverse_key_for_dic = other_initial_bdn_ft_id+"_"+initial_bdn_ft_id+"_"+str(begin_age_1)
			if (key_for_dic not in dic and reverse_key_for_dic not in dic):
				left_plate_id_1 = tectonic_bdn_ft.get_left_plate()
				right_plate_id_1 = tectonic_bdn_ft.get_right_plate()
				feature_type_1 = tectonic_bdn_ft.get_feature_type()
				
				left_plate_id_2 = other_tectonic_bdn_ft.get_left_plate()
				right_plate_id_2 = other_tectonic_bdn_ft.get_right_plate()
				begin_age_2,end_age_2 = other_tectonic_bdn_ft.get_valid_time()
				feature_type_2 = other_tectonic_bdn_ft.get_feature_type()
				if (feature_type_1 == feature_type_2 and left_plate_id_1 == left_plate_id_2 and right_plate_id_1 == right_plate_id_2 and begin_age_1 == begin_age_2 and end_age_1 == end_age_2):
					dic[key_for_dic] = (tectonic_bdn_ft,other_tectonic_bdn_ft,begin_age_1,end_age_1)
	return dic
def clean_up_messy_tectonic_boundaries_based_on_euler_poles(messy_tectonic_boundaries_feature, rotation_model, reference ,test_number, modelname, yearmonthday):
	outputLinesFeatureCollection = pygplates.FeatureCollection()
	tectonic_bdn_fts = []
	reconstructed_tectonic_bdn_fts = []
	dic = find_pairs_of_tectonic_boundaries(messy_tectonic_boundaries_feature)
	possible_rift_features = pygplates.FeatureCollection()
	for key in dic:
		tuple = dic[key]
		tectonic_bdn_ft_1 = tuple[0] 
		tectonic_bdn_ft_2 = tuple[1]
		begin_age = tuple[2]
		end_age = tuple[3]
		at_age = float(begin_age - end_age)/2.00
		temp_left_id = tectonic_boundary_ft.get_left_plate()
		temp_right_id = tectonic_boundary_ft.get_right_plate()
		relative_stage_rotation_from_begin_to_mid_age = supporting_topology.find_stage_relative_reconstruction_rotation(temp_left_id,temp_right_id,)
		relative_stage_rotation_from_mid_to_end_age = supporting_topology.find_stage_relative_reconstruction_rotation(temp_left_id,temp_right_id,)
		if (relative_stage_rotation.represents_identity_rotation() == False and relative_stage_rotation_from_mid_to_end_age.represents_identity_rotation() == False):
			E_pole,angle_rads = relative_stage_rotation.get_euler_pole_and_angle()
			first_bdn_1 = relative_stage_rotation_from_begin_to_mid_age*tectonic_bdn_ft_1.get_geometry() 
			first_bdn_2 = relative_stage_rotation_from_mid_to_end_age*tectonic_bdn_ft_1.get_geometry() 
			second_bdn_1 = relative_stage_rotation_from_begin_to_mid_age*tectonic_bdn_ft_2.get_geometry() 
			second_bdn_2 = relative_stage_rotation_from_mid_to_end_age*tectonic_bdn_ft_2.get_geometry()
			mid_first_bdn = first_bdn_1.get_centroid()
			mid_second_bdn = second_bdn_1.get_centroid()
			middle_btw_two_lines = supporting_topology.find_the_mid_of_two_PointOnSphere(mid_first_bdn,mid_second_bdn)
			#construct an arc between E_pole and middle_btw_two_lines
			great_circle_arc_from_mid_point_to_E_pole = pygplates.GreatCircleArc(middle_btw_two_lines,E_pole)
			arc_mid_point_direction_to_E = great_circle_arc_from_mid_point_to_E_pole.get_arc_direction(0.500)
			_,azimuth_to_E_pole,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(middle_btw_two_lines,arc_mid_point_direction_to_E)
			#convert azimuth to degree
			azimuth_to_E_pole_deg = np.rad2deg(azimuth_to_E_pole)
			great_circle_arc_from_first_to_sec_mid_points = pygplates.GreatCircleArc(mid_first_bdn,mid_second_bdn)
			arc_mid_point_direction = great_circle_arc_from_first_to_sec_mid_points.get_arc_direction(0.500)
			_,azimuth,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(middle_btw_two_lines,arc_mid_point_direction)
			azimuth_line_deg = np.rad2deg(azimuth)
			diff = -1.00
			final_azim_line_deg = -1.00
			if ((azimuth_line_deg == 180.00 and azimuth_to_E_pole_deg == 0.00)):
				final_azim_line_deg = 0.00
			elif ((azimuth_line_deg == 0.00 and azimuth_to_E_pole_deg == 180.00)):
				final_azim_line_deg = 180.00
			elif (azimuth_line_deg > 180.00 and azimuth_to_E_pole_deg <= 180.00):
				final_azim_line_deg = azimuth_line_deg - 180.00
			elif (azimuth_line_deg < 180.00 and azimuth_to_E_pole_deg >= 180.00):
				final_azim_line_deg = azimuth_line_deg + 180
			else:
				final_azim_line_deg = azimuth_line_deg
			diff = abs(azimuth_to_E_pole_deg - final_azim_line_deg)
			if (diff > 90.000):
				final_diff = abs(180.00 - diff)
			else:
				final_diff = diff
			tectonic_bdn_ft_1_name = tectonic_bdn_ft_1.get_name()
			tectonic_bdn_ft_2_name = tectonic_bdn_ft_2.get_name()
			if (final_diff >= 75.00 and final_diff <= 90.00):
				record = (begin_age,end_age,azimuth_to_E_pole_deg,final_azim_line_deg,final_diff,tectonic_bdn_ft_1_name,tectonic_bdn_ft_2_name,'convergence_or_divergence')
				#print(record)
				results.append(record)
				tectonic_bdn_ft_type = tectonic_bdn_ft_1.get_feature_type()
				temp_left_id = tectonic_bdn_ft_1.get_left_plate()
				temp_right_id = tectonic_bdn_ft_1.get_right_plate()
				if (tectonic_bdn_ft_type == pygplates.FeatureType.gpml_passive_continental_boundary or tectonic_bdn_ft_type == pygplates.FeatureType.gpml_subduction_zone):
					#create mid point feature
					new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_rift,middle_btw_two_lines, name = key, valid_time = (begin_age, end_age))
					new_ft.set_left_plate(temp_left_id)
					new_ft.set_right_plate(temp_right_id)
					new_ft.set_reconstruction_method('HalfStageRotationVersion2')
					if (reference is not None):
						pygplates.reverse_reconstruct(new_ft,rotation_model,reconstruction_time,reference)
					else:
						pygplates.reverse_reconstruct(new_ft,rotation_model,reconstruction_time)
					possible_rift_features.add(new_ft)
					outputLinesFeatureCollection.add(tectonic_bdn_ft_1)
					outputLinesFeatureCollection.add(tectonic_bdn_ft_2)
				else:
					#study the distance between two lines
					if (pygplates.GeometryOnSphere.distance(first_bdn_1,second_bdn_1) > pygplates.GeometryOnSphere.distance(first_bdn_2,second_bdn_2)):
						new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,tectonic_bdn_ft_1.get_geometry(), name = tectonic_bdn_ft_1.get_name(), description = "divergent_margin", valid_time = (begin_age, end_age), reconstruction_plate_id = tectonic_bdn_ft_1.get_reconstruction_plate_id())
						new_tectonic_bdn_ft.set_left_plate(temp_left_id)
						new_tectonic_bdn_ft.set_right_plate(temp_right_id)
						outputLinesFeatureCollection.add(new_tectonic_bdn_ft)
						
						new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,tectonic_bdn_ft_2.get_geometry(), name = tectonic_bdn_ft_2.get_name(), description = "divergent_margin", valid_time = (begin_age, end_age), reconstruction_plate_id = tectonic_bdn_ft_2.get_reconstruction_plate_id())
						new_tectonic_bdn_ft.set_left_plate(temp_left_id)
						new_tectonic_bdn_ft.set_right_plate(temp_right_id)
						outputLinesFeatureCollection.add(new_tectonic_bdn_ft)
						
						#create mid point feature
						new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_rift, middle_btw_two_lines, name = key, valid_time = (begin_age, end_age))
						new_ft.set_left_plate(temp_left_id)
						new_ft.set_right_plate(temp_right_id)
						new_ft.set_reconstruction_method('HalfStageRotationVersion2')
						if (reference is not None):
							pygplates.reverse_reconstruct(new_ft,rotation_model,at_age,reference)
						else:
							pygplates.reverse_reconstruct(new_ft,rotation_model,at_age)
						possible_rift_features.add(new_ft)
					elif (pygplates.GeometryOnSphere.distance(first_bdn_1,second_bdn_1) <= pygplates.GeometryOnSphere.distance(first_bdn_2,second_bdn_2)):
						new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, tectonic_bdn_ft_1.get_geometry(), name = tectonic_bdn_ft_1.get_name(), description = "unknown_convergent_margin", valid_time = (begin_age, end_age), reconstruction_plate_id = tectonic_bdn_ft_1.get_reconstruction_plate_id())
						new_tectonic_bdn_ft.set_left_plate(temp_left_id)
						new_tectonic_bdn_ft.set_right_plate(temp_right_id)
						outputLinesFeatureCollection.add(new_tectonic_bdn_ft)
						
						new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, tectonic_bdn_ft_2.get_geometry(), name = tectonic_bdn_ft_2.get_name(), description = "unknown_convergent_margin", valid_time = (begin_age, end_age), reconstruction_plate_id = tectonic_bdn_ft_2.get_reconstruction_plate_id())
						new_tectonic_bdn_ft.set_left_plate(temp_left_id)
						new_tectonic_bdn_ft.set_right_plate(temp_right_id)
						outputLinesFeatureCollection.add(new_tectonic_bdn_ft)
						
						#create mid point feature
						new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_rift, middle_btw_two_lines, name = key, valid_time = (begin_age, end_age))
						new_ft.set_left_plate(temp_left_id)
						new_ft.set_right_plate(temp_right_id)
						new_ft.set_reconstruction_method('HalfStageRotationVersion2')
						if (reference is not None):
							pygplates.reverse_reconstruct(new_ft,rotation_model,at_age,reference)
						else:
							pygplates.reverse_reconstruct(new_ft,rotation_model,at_age)
						possible_rift_features.add(new_ft)
			elif (final_diff > 15.00 and final_diff < 75.00):
				record = (begin_age,end_age,azimuth_to_E_pole_deg,final_azim_line_deg,final_diff,tectonic_bdn_ft_1_name,tectonic_bdn_ft_2_name,'unsure')
				#print(record)
				results.append(record)
				#new_point_feature.set_description('unsure')
			elif (final_diff >= 0.00 and final_diff <= 15.00):
				record = (begin_age,end_age,azimuth_to_E_pole_deg,final_azim_line_deg,final_diff,tectonic_bdn_ft_1_name,tectonic_bdn_ft_2_name,'transform')
				#print(record)
				results.append(record)
				if (tectonic_bdn_ft_type.get_feature_type() == pygplates.FeatureType.gpml_transform):
					outputLinesFeatureCollection.add(tectonic_bdn_ft_1)
					outputLinesFeatureCollection.add(tectonic_bdn_ft_2)
				else:
					new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, tectonic_bdn_ft_1.get_geometry(), name = tectonic_bdn_ft_1.get_name(), description = "transform_fault", valid_time = (begin_age, end_age), reconstruction_plate_id = tectonic_bdn_ft_1.get_reconstruction_plate_id())
					new_tectonic_bdn_ft.set_left_plate(temp_left_id)
					new_tectonic_bdn_ft.set_right_plate(temp_right_id)
					outputLinesFeatureCollection.add(new_tectonic_bdn_ft)
						
					new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, tectonic_bdn_ft_2.get_geometry(), name = tectonic_bdn_ft_2.get_name(), description = "transform_fault", valid_time = (begin_age, end_age), reconstruction_plate_id = tectonic_bdn_ft_2.get_reconstruction_plate_id())
					new_tectonic_bdn_ft.set_left_plate(temp_left_id)
					new_tectonic_bdn_ft.set_right_plate(temp_right_id)
					outputLinesFeatureCollection.add(new_tectonic_bdn_ft)
			else:
				print("Error: Unexpected angle")
				print("azimuth_line_deg", azimuth_line_deg)
				print("final_azim_line_deg",final_azim_line_deg)
				print("closest_bdn_azimuth_deg",closest_bdn_azimuth_deg)
				print("final_diff",final_diff)
	outputLinesFeatureCollection.write("clean_up_messy_tectonic_boundaries_based_on_euler_poles"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")
	possible_rift_features.write("possible_rift_features_from_cleaning_up_messy_bdn"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def check_validity_of_every_pair_of_GDUs_based_on_SuperGDU(rotation_model, messy_tectonic_boundaries_features, SuperGDU_fts, reference ,test_number, modelname, yearmonthday):
	sql = """SELECT DISTINCT ref_gdu_id, other_gdu_id, from_time, to_time FROM test_summary_of_tectonic_motion WHERE tectonic_motion <> 'Unknown_same_motion' ORDER BY from_time DESC"""
	txt = """SELECT super_gdu_id FROM super_gdu_and_members_id WHERE gdu_id_member = {input_ref_gdu_id} 
				AND (from_time > {at_time} and to_time <= {at_time})
			 INTERSECT
			 SELECT super_gdu_id FROM super_gdu_and_members_id WHERE gdu_id_member = {input_other_gdu_id} 
				AND (from_time > {at_time} and to_time <= {at_time})"""
	txt_8 = """UPDATE test_summary_of_tectonic_motion
			   SET validity = {input_validity}
			   WHERE ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id} and from_time = {input_from_time} and to_time = {input_to_time}"""
	cur = None
	cur_1 = None
	cur_2 = None
	cur_3 = None
	cur_8 = None
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_8 = conn.cursor()
		cur.execute(sql)
		row = cur.fetchone()
		while(row is not None):
			print(row)
			ref_gdu_id = row[0]
			other_gdu_id = row[1]
			from_time = float(row[2])
			to_time = float(row[3])
			if ((from_time < to_time) and (to_time - from_time) <= 5.50):
				t = from_time
				from_time = to_time
				to_time = t
			mid_time = (from_time + to_time)/2.00
			sql_1 = txt.format(input_ref_gdu_id = ref_gdu_id, at_time = from_time, input_other_gdu_id = other_gdu_id)
			cur_1.execute(sql_1)
			row_1 = cur_1.fetchone()
			if (row_1 is None):
				sql_2 = txt.format(input_ref_gdu_id = ref_gdu_id, at_time = mid_time, input_other_gdu_id = other_gdu_id)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				if (row_2 is None):
					sql_3 = txt.format(input_ref_gdu_id = ref_gdu_id, at_time = to_time, input_other_gdu_id = other_gdu_id)
					cur_3.execute(sql_3)
					row_3 = cur_3.fetchone()
					if (row_3 is None):
						ref_gdu_fts = []
						other_gdu_fts = []
						cur_4 = conn.cursor()
						txt_4 = """SELECT line_1_ft_name, line_2_ft_name, from_time, to_time
								   FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion
								   WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))
									AND ((from_time = {input_from_time} and to_time = {input_to_time}) or (from_time = to_time and from_time = {input_from_time}))"""
						sql_4 = txt_4.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
						cur_4.execute(sql_4)
						row_4 = cur_4.fetchone()
						if (row_4 is not None):
							txt_5 = """SELECT temp_final_super_gdu_id_2.super_gdu_id, temp_final_super_gdu_id_2.from_time, temp_final_super_gdu_id_2.to_time 
									   FROM temp_final_super_gdu_id_2
											INNER JOIN super_gdu_and_members_id
											ON	temp_final_super_gdu_id_2.super_gdu_id = super_gdu_and_members_id.super_gdu_id
									   WHERE (super_gdu_and_members_id.gdu_id_member = {input_gdu_id} 
												AND temp_final_super_gdu_id_2.from_time > {at_time} and temp_final_super_gdu_id_2.to_time <= {at_time})"""
							sql_5 = txt_5.format(input_gdu_id = ref_gdu_id, at_time = from_time)
							cur_5 = conn.cursor()
							cur_5.execute(sql_5)
							row_5 = cur_5.fetchone()
							SuperGDU_for_ref = int(row_5[0])
							
							cur_6 = conn.cursor()
							sql_6 = txt_5.format(input_gdu_id = other_gdu_id, at_time = from_time)
							cur_6.execute(sql_6)
							row_6 = cur_6.fetchone()
							SuperGDU_for_other = int(row_6[0])
							
							line_1_ft_name = row_4[0]
							line_2_ft_name = row_4[1]
							all_line_1_fts = []
							all_line_2_fts = []
							valid_SuperGDU_fts = []
							for ft in messy_tectonic_boundaries_features:
								if (ft.get_name() == line_1_ft_name):
									if ((ft.get_reconstruction_plate_id() == ref_gdu_id or ft.get_reconstruction_plate_id() == other_gdu_id) and ft.is_valid_at_time(from_time)):
										all_line_1_fts.append(ft)
								elif (ft.get_name() == line_2_ft_name):
									if ((ft.get_reconstruction_plate_id() == ref_gdu_id or ft.get_reconstruction_plate_id() == other_gdu_id) and ft.is_valid_at_time(from_time)):
										all_line_2_fts.append(ft)
							for ft in SuperGDU_fts:
								if (ft.is_valid_at_time(from_time) == True):
									valid_SuperGDU_fts.append(ft)
							reconstructed_fts_1 = []
							reconstructed_fts_2 = []
							reconstructed_SuperGDU = []
							#reconstruct all features
							if (reference is not None):
								pygplates.reconstruct(all_line_1_fts,rotation_model,reconstructed_fts_1,from_time,anchor_plate_id = reference, group_with_feature = True)
								pygplates.reconstruct(all_line_2_fts,rotation_model,reconstructed_fts_2,from_time,anchor_plate_id = reference, group_with_feature = True)
								pygplates.reconstruct(valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU,from_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(all_line_1_fts,rotation_model,reconstructed_fts_1,from_time,group_with_feature = True)
								pygplates.reconstruct(all_line_2_fts,rotation_model,reconstructed_fts_2,from_time,group_with_feature = True)
								pygplates.reconstruct(valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU,from_time,group_with_feature = True)
							final_reconstructed_line_fts_1 = supporting.find_final_reconstructed_geometries(reconstructed_fts_1,pygplates.PolylineOnSphere)
							final_reconstructed_line_fts_2 = supporting.find_final_reconstructed_geometries(reconstructed_fts_2,pygplates.PolylineOnSphere)
							final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU,pygplates.PolygonOnSphere)
							is_valid = True
							for line_ft_1, line_1 in final_reconstructed_line_fts_1:
								centroid_1 = line_1.get_centroid()
								for line_ft_2, line_2 in final_reconstructed_line_fts_2:
									centroid_2 = line_2.get_centroid()
									line_connecting_centroids = pygplates.PolylineOnSphere([centroid_1, centroid_2])
									for SuperGDU_ft, SuperGDU in final_reconstructed_SuperGDU_fts:
										if not (SuperGDU.partition(line_connecting_centroids) == pygplates.PolygonOnSphere.PartitionResult.outside):
											if (int(SuperGDU_ft.get_name()) != SuperGDU_for_ref and int(SuperGDU_ft.get_name()) != SuperGDU_for_other):
												sql_8 = txt_8.format(input_validity = '\'Invalid\'',input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
												cur_8.execute(sql_8)
												is_valid = False
												break
									if (is_valid == False):
										break
								if (is_valid == False):
									break
							if (is_valid == True):
								sql_8 = txt_8.format(input_validity = '\'Valid\'',input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
								cur_8.execute(sql_8)
						# else:
							# print("Error something wrong - there is a tectonic motion but no associated line boundaries recorded")
							# print("ref_gdu_id, other_gdu_id, from_time, to_time", ref_gdu_id, other_gdu_id, from_time, to_time)
							# print("sql_4", sql_4)
							# exit()
					else:
						"""Invalid"""
						sql_8 = txt_8.format(input_validity = '\'Invalid\'',input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
						cur_8.execute(sql_8)
				else:
					"""Invalid"""
					sql_8 = txt_8.format(input_validity = '\'Invalid\'',input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
					cur_8.execute(sql_8)
			else:
				"""Invalid"""
				sql_8 = txt_8.format(input_validity = '\'Invalid\'',input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
				cur_8.execute(sql_8)
			#commit the changes to the database
			conn.commit()
			row = cur.fetchone()
	except (Exception, psycopg2.DatabaseError) as error:
		print("Error in identify_new_lines_for_feats before enter While-loop")
		print(error)
	

def create_tectonic_margin_according_to_tectonic_motion(tectonic_motion,line,initial_name,tectonic_from_time,tectonic_to_time,gdu_id,ref_gdu_id,other_gdu_id):
	plate_tectonic_margin_ft_1 = None
	if (tectonic_motion == "Convergence"):
		plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,line, name = initial_name, description = "unknown_convergent_margin", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
		plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
		plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
	elif (tectonic_motion == "Divergence"):
		plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line, name = initial_name, description = "divergent_margin", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
		plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
		plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
	elif (tectonic_motion == "Transform"):
		plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,line, name = initial_name, description = "transform_fault", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
		plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
		plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
	elif (tectonic_motion == 'Unknown'):
		plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line, name = initial_name, description = "unknown", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
		plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
		plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
	elif (tectonic_motion == 'Unknown_fluct_motion'):
		plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line, name = initial_name, description = "unknown_fluct_motion", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
		plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
		plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
	elif (tectonic_motion == 'Unknown_rapid_fluct_motion'):
		plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line, name = initial_name, description = "unknown_rapid_fluct_motion", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
		plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
		plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
	elif (tectonic_motion == 'Unknown_same_motion'):
		plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line, name = initial_name, description = "unknown_same_motion", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
		plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
		plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
	return plate_tectonic_margin_ft_1

def determine_the_dominant_tectonic_motion_for_CON_OCN_line_fts(rotation_model,CON_OCN_line_feats, max_begin_age, min_end_age, SuperGDU_features,reference,modelname,yearmonthday):
	outputTectonicMargins = pygplates.FeatureCollection()
	sql = """SELECT DISTINCT ref_gdu_id FROM test_summary_of_tectonic_motion WHERE validity = 'Valid'
				UNION
			 SELECT DISTINCT other_gdu_id FROM test_summary_of_tectonic_motion WHERE validity = 'Valid'
				ORDER BY ref_gdu_id DESC;"""
	cur = None
	cur_1 = None
	cur_2 = None
	cur_3 = None
	cur_8 = None
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur.execute(sql)
		row = cur.fetchone()
		while(row is not None):
			gdu_id = int(row[0])
			txt_1 = """SELECT from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id 
						FROM test_summary_of_tectonic_motion
						WHERE ref_gdu_id = {input_gdu_id} or other_gdu_id = {input_gdu_id}
						AND from_time <= {input_from_time} AND to_time >= {input_to_time}
						ORDER BY from_time DESC"""
			for line_ft in CON_OCN_line_feats:
				if (line_ft.get_reconstruction_plate_id() == gdu_id):
					valid_begin_age,valid_end_age = line_ft.get_valid_time()
					if (is_two_time_periods_overlapping(valid_begin_age,valid_end_age, max_begin_age, min_end_age,False,0.00,False)):
						min_distance = -1.00
						closest_neighbour = -1
						final_tectonic_motion = None
						reconstructed_line = None
						from_time_of_final_motion = -1.00 
						to_time_of_final_motion = -1.00
						final_ref_gdu_id = -1
						final_other_gdu_id = -1
						sql_1 = txt_1.format(input_gdu_id = gdu_id, input_from_time = valid_begin_age, input_to_time = valid_end_age)
						cur_1.execute(sql_1)
						row_1 = cur_1.fetchone()
						while(row_1 is not None):
							from_time_of_motion = float(row_1[0]) 
							to_time_of_motion = float(row_1[1])
							tectonic_motion = row_1[2]
							ref_gdu_id = int(row_1[3])
							other_gdu_id = int(row_1[4])
							txt_2 = """SELECT temp_final_super_gdu_id_2.super_gdu_id, temp_final_super_gdu_id_2.from_time, temp_final_super_gdu_id_2.to_time 
									   FROM temp_final_super_gdu_id_2
											INNER JOIN super_gdu_and_members_id
											ON	temp_final_super_gdu_id_2.super_gdu_id = super_gdu_and_members_id.super_gdu_id
									   WHERE (super_gdu_and_members_id.gdu_id_member = {input_gdu_id} 
												and temp_final_super_gdu_id_2.from_time > {at_time} and temp_final_super_gdu_id_2.to_time <= {at_time})"""
							if (ref_gdu_id == gdu_id):
								sql_2 = txt_2.format(input_gdu_id = other_gdu_id, at_time = from_time_of_motion)
							elif (other_gdu_id == gdu_id):
								sql_2 = txt_2.format(input_gdu_id = ref_gdu_id, at_time = from_time_of_motion)
							cur_2 = conn.cursor()
							cur_2.execute(sql_2)
							row_2 = cur_2.fetchone()
							SuperGDU_for_other = int(row_2[0])
							for SuperGDU_ft in SuperGDU_features:
								if(int(SuperGDU_ft.get_name()) == SuperGDU_for_other):
									reconstructed_line_fts = []
									reconstructed_SuperGDU = []
									#reconstruct all features
									if (reference is not None):
										pygplates.reconstruct(line_ft,rotation_model,reconstructed_line_fts,from_time_of_motion,anchor_plate_id = reference, group_with_feature = True)
										pygplates.reconstruct(SuperGDU_ft,rotation_model,reconstructed_SuperGDU,from_time_of_motion,anchor_plate_id = reference, group_with_feature = True)
									else:
										pygplates.reconstruct(line_ft,rotation_model,reconstructed_line_fts,from_time_of_motion,group_with_feature = True)
										pygplates.reconstruct(SuperGDU_ft,rotation_model,reconstructed_SuperGDU,from_time_of_motion,group_with_feature = True)
									final_reconstructed_line_fts = supporting.find_final_reconstructed_geometries(reconstructed_line_fts,pygplates.PolylineOnSphere)
									final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU,pygplates.PolygonOnSphere)
									reconstructed_line_ft,line = final_reconstructed_line_fts[0]
									reconstructed_SuperGDU_ft,SuperGDU = final_reconstructed_SuperGDU_fts[0]
									distance = pygplates.GeometryOnSphere.distance(line.get_centroid(),SuperGDU)
									if (min_distance == -1.00):
										min_distance = distance
										if (ref_gdu_id == gdu_id):
											closest_neighbour = other_gdu_id
										elif (other_gdu_id == gdu_id):
											closest_neighbour = ref_gdu_id
										final_tectonic_motion = tectonic_motion
										reconstructed_line = line
										from_time_of_final_motion = from_time_of_motion
										to_time_of_final_motion = to_time_of_motion
										final_ref_gdu_id = ref_gdu_id
										final_other_gdu_id = other_gdu_id
									elif (min_distance > -1.00 and distance < min_distance):
										min_distance = distance
										if (ref_gdu_id == gdu_id):
											closest_neighbour = other_gdu_id
										elif (other_gdu_id == gdu_id):
											closest_neighbour = ref_gdu_id
										final_tectonic_motion = tectonic_motion
										reconstructed_line = line
										from_time_of_final_motion = from_time_of_motion
										to_time_of_final_motion = to_time_of_motion
										final_ref_gdu_id = ref_gdu_id
										final_other_gdu_id = other_gdu_id
							row_1 = cur_1.fetchone()
						#create tectonic bdn ft
						reconstructed_final_tectonic_margin_ft = create_tectonic_margin_according_to_tectonic_motion(final_tectonic_motion,reconstructed_line,initial_name,from_time_of_final_motion,to_time_of_final_motion,gdu_id,final_ref_gdu_id,final_other_gdu_id)
						if (reference is not None):
							pygplates.reverse_reconstruct(reconstructed_final_tectonic_margin_ft,rotation_model,from_time_of_final_motion,reference)
						else:
							pygplates.reverse_reconstruct(reconstructed_final_tectonic_margin_ft,rotation_model,from_time_of_final_motion)
						outputTectonicMargins.add(reconstructed_final_tectonic_margin_ft)
			row = cur.fetchone()
	except (psycopg2.DatabaseError) as error:
		print("Error in identify_new_lines_for_feats before enter While-loop")
		print(error)
	outputTectonicMargins.write("dominant_tectonic_motion_for_CON_OCN_line_fts_"+str(max_begin_age)+"_"+str(min_end_age)+"_"+modelname+"_"+yearmonthday+".gpml")
	outputTectonicMargins.write("dominant_tectonic_motion_for_CON_OCN_line_fts_"+str(max_begin_age)+"_"+str(min_end_age)+"_"+modelname+"_"+yearmonthday+".shp")
	








def classify_left_or_right_for_line(normal_unit_vector,rift_point_location,mid_point_line_1,normal_unit_vector_of_line_1):
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	#identify left and right
	#vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	arc = pygplates.GreatCircleArc(rift_point_location,mid_point_line_1)
	vector_to_line_1 = arc.get_arc_direction(0.500)
	normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	# _,azimuth_normal,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,normal_unit_vector)
	# _,azimuth_normal_to_line_1,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,normal_unit_vector_of_line_1)
	# azimuth_normal_deg = abs(math.degrees(azimuth_normal))
	# azimuth_normal_to_line_1_deg = abs(math.degrees(azimuth_normal_to_line_1))
	# is_line_1_reversed_order = False
	# if (abs(azimuth_normal_deg - azimuth_normal_to_line_1_deg) < 45.00): #the order of start and end points for each line is not the same relative to each other
		# is_line_1_reversed_order = False
	# elif (abs(azimuth_normal_deg - azimuth_normal_to_line_1_deg) > 135.00): #the order of start and end points for each line is not the same relative to each other
		# is_line_1_reversed_order = True
	# else:
		# return 'invalid'
	is_line_1_reversed_order = False
	angle_btw_rads = pygplates.Vector3D.angle_between(normal_unit_vector_of_line_1,normal_unit_vector)
	angle_btw_degs = abs(math.degrees(angle_btw_rads))
	if (angle_btw_degs <= 60.00): #the order of start and end points for each line is the same relative to each other
		is_line_1_reversed_order = False
	elif (angle_btw_degs > 60.00 and angle_btw_degs <= 120.00):
		return 'invalid'
	elif (angle_btw_degs > 120.00 and angle_btw_degs <= 180.00): #the order of start and end points for each line is not the same relative to each other
		is_line_1_reversed_order = True
		
	#_,azimuth_line_1,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,normalized_vector_to_line_1)
	angle_btw_rads = pygplates.Vector3D.angle_between(normal_unit_vector,normalized_vector_to_line_1)
	angle_btw_degs = abs(math.degrees(angle_btw_rads))
	# if (angle_btw_degs <= 60.00):
		# if (is_line_1_reversed_order == False):
			# return 'left'
		# else:
			# return 'right'
	# elif (angle_btw_degs > 60.00 and angle_btw_degs <= 120.00):
		# return 'invalid'
	# elif (angle_btw_degs > 120.00 and angle_btw_degs <= 180.00):
		# if (is_line_1_reversed_order == False):
			# return 'right'
		# else:
			# return 'left'
	
	if (angle_btw_degs <= 90.00):
		if (is_line_1_reversed_order == False):
			return 'left'
		else:
			return 'right'
	else:
		if (is_line_1_reversed_order == False):
			return 'right'
		else:
			return 'left'
	# azimuth_line_1_deg = abs(math.degrees(azimuth_line_1))
	# if (abs(azimuth_normal_deg - azimuth_line_1_deg) < 90.00):
		# if (is_line_1_reversed_order == False):
			# return 'left'
		# else:
			# return 'right'
	# else:
		# if (is_line_1_reversed_order == False):
			# return 'right'
		# else:
			# return 'left'

def calculate_angle_from_three_diff_points(point_1,point_2,point_3):
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	x1,y1,z1 = point_1.to_xyz()
	x2,y2,z2 = point_2.to_xyz()
	x3,y3,z3 = point_3.to_xyz()
	from_p2_to_p1 = pygplates.Vector3D([(x1-x2),(y1-y2),(z1-z2)])
	normalized_vector_from_2_to_1 = from_p2_to_p1.to_normalised()
	from_p2_to_p3 = pygplates.Vector3D([(x3-x2),(y3-y2),(z3-z2)])
	normalized_vector_from_3_to_1 = from_p2_to_p3.to_normalised()
	angle_btw_rads = pygplates.Vector3D.angle_between(normalized_vector_from_2_to_1,normalized_vector_from_3_to_1)
	angle_btw_degs = math.degrees(angle_btw_rads)
	return angle_btw_degs

# def is_possible_neighbour_from_90_degrees_away(start_point,azimuth_unit_vector,mid_point_of_possible_neighbour, possible_line):
	# start_x,start_y,start_z = start_point.to_xyz()
	# azim_x,azim_y,azim_z = azimuth_unit_vector.to_xyz()
	# print('azimuth_unit_vector.to_normalised()',azimuth_unit_vector.to_normalised())
	# print('start_x,start_y,start_z',start_x,start_y,start_z)
	# print('azim_x,azim_y,azim_z',azim_x,azim_y,azim_z)
	# exit()
	# first_estimated_distance_km = -1.00
	# new_point_x = start_x + azim_x*0.00100
	# new_point_y = start_y + azim_y*0.00100
	# new_point_z = start_z + azim_z*0.00100
	# new_point_vector = pygplates.Vector3D((new_point_x,new_point_y,new_point_z))
	# new_point_vector_normalized = new_point_vector.to_normalised()
	# new_point = pygplates.PointOnSphere((new_point_vector_normalized.get_x(),new_point_vector_normalized.get_y(),new_point_vector_normalized.get_z()))
	# #approx_dist = pygplates.GeometryOnSphere.distance(start_point,new_point)*pygplates.Earth.mean_radius_in_kms
	# threshold_distance_in_km = pygplates.GeometryOnSphere.distance(start_point,mid_point_of_possible_neighbour)*pygplates.Earth.mean_radius_in_kms
	# #distance_btw_new_point_and_neighbour = pygplates.GeometryOnSphere.distance(new_point,mid_point_of_possible_neighbour)*pygplates.Earth.mean_radius_in_kms
	# new_line = pygplates.PolylineOnSphere([start_point,new_point])
	# distance_btw_two_lines =	pygplates.GeometryOnSphere.distance(new_line,possible_line)*pygplates.Earth.mean_radius_in_kms
	# if (distance_btw_two_lines == 0.00):
		# return True
	# else:
		# if (distance_btw_two_lines >=	 threshold_distance_in_km):
			# return False
		# else:
			# times = 1.00
			# while ((distance_btw_two_lines != 0.00) and (distance_btw_two_lines < threshold_distance_in_km)):
				# new_point_x = new_point_x + azim_x
				# new_point_y = new_point_y + azim_y
				# new_point_z = new_point_z + azim_z
				# new_point_vector = pygplates.Vector3D((new_point_x,new_point_y,new_point_z))
				# print(new_point_vector,new_point_vector)
				# new_point_vector_normalized = new_point_vector.to_normalised()
				# new_point = pygplates.PointOnSphere((new_point_vector_normalized.get_x(),new_point_vector_normalized.get_y(),new_point_vector_normalized.get_z()))
				# new_line = pygplates.PolylineOnSphere([start_point,new_point])
				# distance_btw_two_lines =	pygplates.GeometryOnSphere.distance(new_line,possible_line)*pygplates.Earth.mean_radius_in_kms
				# print("distance_btw_two_lines",distance_btw_two_lines)
				# print("threshold_distance_in_km",threshold_distance_in_km)
				# #times = times + 1
			# if (distance_btw_two_lines == 0.00):
				# return True
			# else:
				# return False

def is_possible_neighbour(rotation_model,gdu_id_1,gdu_id_2,at_age,reference,start_point,mid_point_of_possible_neighbour):

	threshold_distance_in_km = pygplates.GeometryOnSphere.distance(start_point,mid_point_of_possible_neighbour)*pygplates.Earth.mean_radius_in_kms
	if (threshold_distance_in_km == 0.00):
		return True
	else:
		total_relative_reconstruction_rotation = supporting_topology.find_total_relative_reconstruction_rotation_(rotation_model,gdu_id_1,gdu_id_2, at_age, reference)
		#print("total_relative_reconstruction_rotation.represents_identity_rotation()",total_relative_reconstruction_rotation.represents_identity_rotation())
		if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
			E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
			smallest_circle_angular_radians_degrees = pygplates.GeometryOnSphere.distance(E_pole,start_point)
			smallest_circle_angular_radius_degrees = math.degrees(smallest_circle_angular_radians_degrees)
			max_smallest_circle_angular_radius_degrees = 179.00
			min_smallest_circle_angular_radius_degrees = 1.00
			current_smallest_circle_angular_radius_degrees = max_smallest_circle_angular_radius_degrees
			
			wanted_small_circle = None
			while (current_smallest_circle_angular_radius_degrees >= min_smallest_circle_angular_radius_degrees):
				small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,current_smallest_circle_angular_radius_degrees)
				#print("current_smallest_circle_angular_radius_degrees",current_smallest_circle_angular_radius_degrees)
				#print("pygplates.GeometryOnSphere.distance(small_circle_boundary,start_point)",pygplates.GeometryOnSphere.distance(small_circle_boundary,start_point))
				if (pygplates.GeometryOnSphere.distance(small_circle_boundary,start_point) == 0.00):
					wanted_small_circle = small_circle_boundary
					break
				current_smallest_circle_angular_radius_degrees = current_smallest_circle_angular_radius_degrees - 1.00
			if (wanted_small_circle is None):
				return False
			else:
				if (pygplates.GeometryOnSphere.distance(wanted_small_circle,mid_point_of_possible_neighbour) == 0.00):
				   return True
				else:
					return False

def use_azimuth_direction_to_find_the_closest_neighbour(rotation_model,messy_tectonic_boundaries_features,reference):
	sql = """SELECT DISTINCT line_1_ft_name
				FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion
				UNION
			   SELECT DISTINCT line_2_ft_name
			   FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion"""
	cur = None
	cur_1 = None
	cur_2 = None
	cur_3 = None
	cur_4 = None
	cur_5 = None
	cur_6 = None
	cur_9 = None
	list_of_already_processed = []
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		cur_5 = conn.cursor()
		cur_6 = conn.cursor()
		cur_9 = conn.cursor()
		output_dic = {}
		cur.execute(sql)
		row = cur.fetchone()
		while(row is not None):
			print(row)
			current_line_ft_name = row[0]
			continue_to_process_line_ft = False
			upper_limit_for_from_time_for_line_ft = -1.00
			if (current_line_ft_name not in list_of_already_processed):
				continue_to_process_line_ft = True
			else:
				txt_5  = """SELECT from_time,to_time FROM test_final_summary_of_tectonic_boundaries_and_motion 
							WHERE (line_1_ft_name = '{input_line_ft_name}'
							OR line_2_ft_name = '{input_line_ft_name}')
							ORDER BY to_time ASC"""
				sql_5 = txt_5.format(input_line_ft_name = current_line_ft_name)
				cur_5.execute(sql_5)
				row_5 = cur_5.fetchone()
				if (row_5 is not None):
					smallest_to_time = float(row_5[1])
					txt_6 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion
						   WHERE from_time <= {input_time}
						   AND (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}')
						   ORDER BY from_time DESC """
					sql_6 = txt_6.format(input_time = smallest_to_time , input_line_ft_name = current_line_ft_name)
					cur_6.execute(sql_6)
					row_6 = cur_6.fetchone()
					if (row_6 is not None):
						upper_limit_for_from_time_for_line_ft = smallest_to_time
						continue_to_process_line_ft = True
			if (continue_to_process_line_ft == True):
				list_of_already_processed.append(current_line_ft_name)
				txt_2 = """SELECT from_time, to_time, gdu_id, lef_gdu_id, right_gdu_id
							   FROM tectonic_topological_line_fts
							   WHERE type_of_line_fts = 'CON_OCN' AND (initial_ft_id = '{input_line_ft_name}' or name = '{input_line_ft_name}')"""
				sql_2 = txt_2.format(input_line_ft_name = current_line_ft_name)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				print(sql_2)
				CON_OCN_from_time = float(row_2[0])
				CON_OCN_to_time = float(row_2[1])
				gdu_id_of_line_ft = int(row_2[2])
				left_gdu_id_of_line_ft = int(row_2[3])
				right_gdu_id_of_line_ft = int(row_2[4])
				txt_1 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion
						   WHERE from_time <= {input_CON_OCN_from_time} AND to_time >= {input_CON_OCN_to_time} 
						   AND (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}')
						   ORDER BY from_time DESC"""
				if (upper_limit_for_from_time_for_line_ft == -1.00):
					sql_1 = txt_1.format(input_CON_OCN_from_time = CON_OCN_from_time, input_CON_OCN_to_time = CON_OCN_to_time,input_line_ft_name = current_line_ft_name)
					cur_1.execute(sql_1)
				elif (upper_limit_for_from_time_for_line_ft > -1.00):
					sql_1 = txt_1.format(input_CON_OCN_from_time = upper_limit_for_from_time_for_line_ft, input_CON_OCN_to_time = CON_OCN_to_time,input_line_ft_name = current_line_ft_name)
					cur_1.execute(sql_1)
				row_1 = cur_1.fetchone()
				current_dominant_neighbour = None
				previous_from_time = -1.00
				previous_to_time = -1.00
				previous_ref_gdu_id = -1.00
				previous_other_gdu_id = -1.00
				previous_tectonic_motion = None
				main_tectonic_bdn_ft = None
				while (row_1 is not None):
					print(row_1)

					ref_gdu_id = int(row_1[0])
					other_gdu_id = int(row_1[1])
					line_1_ft_name = row_1[2] 
					line_2_ft_name = row_1[3]
					from_time = row_1[4]
					to_time = row_1[5]
					tectonic_motion = row_1[6]
					if (previous_from_time == -1.00 and previous_to_time == -1.00):
						txt_9 = """SELECT * FROM test_summary_of_tectonic_motion
						   WHERE (ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id})
							AND (from_time = {input_from_time} and to_time = {input_to_time})
							AND validity = 'Invalid'"""
						sql_9 =	 txt_9.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
						cur_9.execute(sql_9)
						row_9 = cur_9.fetchone()
						if (row_9 is None):
							
							if (line_1_ft_name == current_line_ft_name):
								current_dominant_neighbour = line_2_ft_name
							else:
								current_dominant_neighbour = line_1_ft_name
							previous_from_time = from_time
							previous_to_time = to_time
							previous_ref_gdu_id = ref_gdu_id
							previous_other_gdu_id = other_gdu_id
							previous_tectonic_motion = tectonic_motion
					else:
						is_valid_check = False
						txt_9 = """SELECT * FROM test_summary_of_tectonic_motion
						   WHERE (ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id})
							AND (from_time = {input_from_time} and to_time = {input_to_time})
							AND validity = 'Invalid'"""
						sql_9 =	 txt_9.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
						cur_9.execute(sql_9)
						row_9 = cur_9.fetchone()
						if (row_9 is None):
							is_valid_check = True
						if (previous_to_time > from_time and is_valid_check == True): #because we order records by from_time so we don't need to worry about previous_from_time < to_time
							#insert the previous_record to the finally summary database table
							#final_summary_of_tectonic_boundaries_and_motion
							sql_3 = """INSERT INTO test_final_summary_of_tectonic_boundaries_and_motion (from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s,%s,%s,%s,%s,%s,%s) """
							cur_3.execute(sql_3,(previous_from_time,previous_to_time,previous_tectonic_motion,current_line_ft_name,current_dominant_neighbour,previous_ref_gdu_id,previous_other_gdu_id))
							list_of_already_processed.append(current_dominant_neighbour)
							if (line_1_ft_name == current_line_ft_name):
								current_dominant_neighbour = line_2_ft_name
							else:
								current_dominant_neighbour = line_1_ft_name
							
							previous_from_time = from_time
							previous_to_time = to_time
							previous_ref_gdu_id = ref_gdu_id
							previous_other_gdu_id = other_gdu_id
							previous_tectonic_motion = tectonic_motion
						elif (is_valid_check == True):
							reconstructed_other_tectonic_bdn_fts = []
							reconstructed_main_tectonic_bdn_fts = []
							other_tectonic_bdn_fts = []
							at_age = -1.00
							if (from_time == previous_from_time):
								at_age = float(from_time)
							else:
								list_of_time = [previous_from_time,previous_to_time,from_time,to_time]
								list_of_time.sort(reverse = True) #descending order
								#choose the second element
								at_age = float(list_of_time[1])
							main_tectonic_bdn_ft = None
							if (line_1_ft_name == current_line_ft_name):
								for bdn_ft in messy_tectonic_boundaries_features:
									if (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(at_age)):
										if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
											main_tectonic_bdn_ft = bdn_ft
									if (main_tectonic_bdn_ft is not None):
										break
							elif (line_2_ft_name == current_line_ft_name):
								for bdn_ft in messy_tectonic_boundaries_features:
									if (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(at_age)):
										if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
											main_tectonic_bdn_ft = bdn_ft
									if (main_tectonic_bdn_ft is not None):
										break
							if (line_1_ft_name == current_line_ft_name):
								for bdn_ft in messy_tectonic_boundaries_features:
									if (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(at_age)):
										if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
											other_tectonic_bdn_fts.append(bdn_ft)
									elif (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
										if ((bdn_ft.get_left_plate() == previous_ref_gdu_id and bdn_ft.get_right_plate() == previous_other_gdu_id) or (bdn_ft.get_left_plate() == previous_other_gdu_id and bdn_ft.get_right_plate() == previous_ref_gdu_id)):
											other_tectonic_bdn_fts.append(bdn_ft)
							elif (line_2_ft_name == current_line_ft_name):
								for bdn_ft in messy_tectonic_boundaries_features:
									if (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(at_age)):
										if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
											other_tectonic_bdn_fts.append(bdn_ft)
									elif (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
										if ((bdn_ft.get_left_plate() == previous_ref_gdu_id and bdn_ft.get_right_plate() == previous_other_gdu_id) or (bdn_ft.get_left_plate() == previous_other_gdu_id and bdn_ft.get_right_plate() == previous_ref_gdu_id)):
											other_tectonic_bdn_fts.append(bdn_ft)
							#reconstruct all tectonic bdn fts to at_age
							print("at_age",at_age)
							print("previous_from_time,previous_to_time,from_time,to_time",previous_from_time,previous_to_time,from_time,to_time)
							#print("main_tectonic_bdn_ft.get_valid_time()",main_tectonic_bdn_ft.get_valid_time())
							#print(main_tectonic_bdn_ft.get_name())
							if (main_tectonic_bdn_ft is not None and len(other_tectonic_bdn_fts) >= 2):
								# for bdn_ft in messy_tectonic_boundaries_features:
									# if (bdn_ft.get_name() == current_line_ft_name and bdn_ft.is_valid_at_time(at_age)):
										# main_tectonic_bdn_ft = bdn_ft.clone()
										# # print(bdn_ft.get_valid_time())
										# # print(bdn_ft.get_feature_type())
								# # exit()
								# print(main_tectonic_bdn_ft.get_left_plate(),main_tectonic_bdn_ft.get_right_plate())
								# print("len(other_tectonic_bdn_fts)",len(other_tectonic_bdn_fts))
								# for other_bdn_ft in other_tectonic_bdn_fts:
									# print("other_bdn_ft.get_name",other_bdn_ft.get_name())
									# print("other_bdn_ft.get_feature_type",other_bdn_ft.get_feature_type())
									# print("other_bdn_ft.get_valid_time",other_bdn_ft.get_valid_time())
									# print("other_bdn_ft.get_left_plate,right_plate",other_bdn_ft.get_left_plate(),other_bdn_ft.get_right_plate())
								#print("rotation_model",other_tectonic_bdn_fts)
								if (reference is not None):
									pygplates.reconstruct(other_tectonic_bdn_fts,rotation_model,reconstructed_other_tectonic_bdn_fts,float(at_age),anchor_plate_id = reference, group_with_feature = True)
									pygplates.reconstruct(main_tectonic_bdn_ft,rotation_model,reconstructed_main_tectonic_bdn_fts,float(at_age),anchor_plate_id = reference, group_with_feature = True)
								else:
									pygplates.reconstruct(other_tectonic_bdn_fts,rotation_model,reconstructed_other_tectonic_bdn_fts,float(at_age),group_with_feature = True)
									pygplates.reconstruct(main_tectonic_bdn_ft,rotation_model,reconstructed_main_tectonic_bdn_fts,float(at_age),group_with_feature = True)
								final_reconstructed_other_tectonic_bdn_fts = supporting.find_final_reconstructed_geometries(reconstructed_other_tectonic_bdn_fts,pygplates.PolylineOnSphere) 
								final_reconstructed_main_tectonic_bdn_ft = supporting.find_final_reconstructed_geometries(reconstructed_main_tectonic_bdn_fts,pygplates.PolylineOnSphere)
								reconstr_main_bdn_ft,reconstr_main_bdn = final_reconstructed_main_tectonic_bdn_ft[0]
								main_centroid = reconstr_main_bdn.get_centroid()
								first_candidate_ft,first_candidate_bdn = final_reconstructed_other_tectonic_bdn_fts[0]
								second_candidate_ft,second_candidate_bdn = final_reconstructed_other_tectonic_bdn_fts[1]
								first_point_of_main_line = reconstr_main_bdn[0]
								end_point_of_main_line = reconstr_main_bdn[-1]
								great_circle_arc = pygplates.GreatCircleArc(first_point_of_main_line,end_point_of_main_line)
								normal_unit_vector = great_circle_arc.get_great_circle_normal()
								great_circle_arc_for_first_candidate = pygplates.GreatCircleArc(first_candidate_bdn[0],first_candidate_bdn[-1])
								normal_unit_vector_for_first_candidate = great_circle_arc_for_first_candidate.get_great_circle_normal()
								great_circle_arc_for_second_candidate = pygplates.GreatCircleArc(second_candidate_bdn[0],second_candidate_bdn[-1])
								normal_unit_vector_for_second_candidate = great_circle_arc_for_second_candidate.get_great_circle_normal()
								if (left_gdu_id_of_line_ft > 0 ): #then we need to look for the right side of the original line ft
									result_1 = classify_left_or_right_for_line(normal_unit_vector,main_centroid,first_candidate_bdn.get_centroid(),normal_unit_vector_for_first_candidate)
									result_2 = classify_left_or_right_for_line(normal_unit_vector,main_centroid,second_candidate_bdn.get_centroid(),normal_unit_vector_for_second_candidate)
									if (result_1 == result_2 == 'right'):
										angle_1 = calculate_angle_from_three_diff_points(end_point_of_main_line,main_centroid,first_candidate_bdn.get_centroid())
										angle_2 = calculate_angle_from_three_diff_points(end_point_of_main_line,main_centroid,second_candidate_bdn.get_centroid())
										
										
										diff_angle_1 = abs(angle_1 - 90.00)
										diff_angle_2 = abs(angle_2 - 90.00)
										distance_1 = pygplates.GeometryOnSphere.distance(main_centroid,first_candidate_bdn.get_centroid())
										distance_2 = pygplates.GeometryOnSphere.distance(main_centroid,second_candidate_bdn.get_centroid())
										if (diff_angle_1 <= 5.00 and diff_angle_2 <= 5.00):
											if (distance_1 < distance_2):
												result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,first_candidate_bdn.get_centroid())
												
												if (result_1 == True and first_candidate_ft.get_name() != current_dominant_neighbour):
													previous_from_time = from_time
													previous_to_time = to_time
													previous_ref_gdu_id = ref_gdu_id
													previous_other_gdu_id = other_gdu_id
													previous_tectonic_motion = tectonic_motion
													current_dominant_neighbour = first_candidate_ft.get_name()
											else:
												result_2 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),second_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,second_candidate_bdn.get_centroid())
												if (result_2 == True and second_candidate_ft.get_name() != current_dominant_neighbour):
													previous_from_time = from_time
													previous_to_time = to_time
													previous_ref_gdu_id = ref_gdu_id
													previous_other_gdu_id = other_gdu_id
													previous_tectonic_motion = tectonic_motion
													current_dominant_neighbour = second_candidate_ft.get_name()
										else:
											if (diff_angle_1 > 5.00 and diff_angle_2 <= 5.00):
												result_2 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),second_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,second_candidate_bdn.get_centroid())
												if (result_2 == True and second_candidate_ft.get_name() != current_dominant_neighbour):
													previous_from_time = from_time
													previous_to_time = to_time
													previous_ref_gdu_id = ref_gdu_id
													previous_other_gdu_id = other_gdu_id
													previous_tectonic_motion = tectonic_motion
													current_dominant_neighbour = second_candidate_ft.get_name()
											elif (diff_angle_1 <= 5.00 and diff_angle_2 > 5.00):
												result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,first_candidate_bdn.get_centroid())
												
												if (result_1 == True and first_candidate_ft.get_name() != current_dominant_neighbour):
													previous_from_time = from_time
													previous_to_time = to_time
													previous_ref_gdu_id = ref_gdu_id
													previous_other_gdu_id = other_gdu_id
													previous_tectonic_motion = tectonic_motion
													current_dominant_neighbour = first_candidate_ft.get_name()
									elif (result_1 == 'right'):
										result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,first_candidate_bdn.get_centroid())
										if (result_1 == True and first_candidate_ft.get_name() != current_dominant_neighbour):
											previous_from_time = from_time
											previous_to_time = to_time
											previous_ref_gdu_id = ref_gdu_id
											previous_other_gdu_id = other_gdu_id
											previous_tectonic_motion = tectonic_motion
											current_dominant_neighbour = first_candidate_ft.get_name()
									elif (result_2 == 'right'):
										result_2 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),second_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,second_candidate_bdn.get_centroid())
										if (result_2 == True and second_candidate_ft.get_name() != current_dominant_neighbour):
											previous_from_time = from_time
											previous_to_time = to_time
											previous_ref_gdu_id = ref_gdu_id
											previous_other_gdu_id = other_gdu_id
											previous_tectonic_motion = tectonic_motion
											current_dominant_neighbour = second_candidate_ft.get_name()
								elif (right_gdu_id_of_line_ft > 0):#then we need to look for the left side of the original line ft
									result_1 = classify_left_or_right_for_line(normal_unit_vector,main_centroid,first_candidate_bdn.get_centroid(),normal_unit_vector_for_first_candidate)
									result_2 = classify_left_or_right_for_line(normal_unit_vector,main_centroid,second_candidate_bdn.get_centroid(),normal_unit_vector_for_second_candidate)
									if (result_1 == result_2 == 'left'):
										
										angle_1 = calculate_angle_from_three_diff_points(end_point_of_main_line,main_centroid,first_candidate_bdn.get_centroid())
										angle_2 = calculate_angle_from_three_diff_points(end_point_of_main_line,main_centroid,second_candidate_bdn.get_centroid())
										diff_angle_1 = abs(angle_1 - 90.00)
										diff_angle_2 = abs(angle_2 - 90.00)
										if (diff_angle_1 <= 5.00 and diff_angle_2 <= 5.00):
											distance_1 = pygplates.GeometryOnSphere.distance(main_centroid,first_candidate_bdn.get_centroid())
											distance_2 = pygplates.GeometryOnSphere.distance(main_centroid,second_candidate_bdn.get_centroid())
											if (distance_1 < distance_2):
												result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,first_candidate_bdn.get_centroid())
												if (result_1 == True and first_candidate_ft.get_name() != current_dominant_neighbour):
													previous_from_time = from_time
													previous_to_time = to_time
													previous_ref_gdu_id = ref_gdu_id
													previous_other_gdu_id = other_gdu_id
													previous_tectonic_motion = tectonic_motion
													current_dominant_neighbour = first_candidate_ft.get_name()
											else:
												result_2 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),second_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,second_candidate_bdn.get_centroid())
												if (result_2 == True and second_candidate_ft.get_name() != current_dominant_neighbour):
													previous_from_time = from_time
													previous_to_time = to_time
													previous_ref_gdu_id = ref_gdu_id
													previous_other_gdu_id = other_gdu_id
													previous_tectonic_motion = tectonic_motion
													current_dominant_neighbour = second_candidate_ft.get_name()
										else:
											if (diff_angle_1 > 5.00 and diff_angle_2 <= 5.00):
												result_2 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),second_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,second_candidate_bdn.get_centroid())
												if (result_2 == True and second_candidate_ft.get_name() != current_dominant_neighbour):
													previous_from_time = from_time
													previous_to_time = to_time
													previous_ref_gdu_id = ref_gdu_id
													previous_other_gdu_id = other_gdu_id
													previous_tectonic_motion = tectonic_motion
													current_dominant_neighbour = second_candidate_ft.get_name()
											elif (diff_angle_1 <= 5.00 and diff_angle_2 > 5.00):
												result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,first_candidate_bdn.get_centroid())
												if (result_1 == True and first_candidate_ft.get_name() != current_dominant_neighbour):
													previous_from_time = from_time
													previous_to_time = to_time
													previous_ref_gdu_id = ref_gdu_id
													previous_other_gdu_id = other_gdu_id
													previous_tectonic_motion = tectonic_motion
													current_dominant_neighbour = first_candidate_ft.get_name()
									elif (result_1 == 'left'):
										result_1  = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,first_candidate_bdn.get_centroid())
										if (result_1 == True and first_candidate_ft.get_name() != current_dominant_neighbour):
											previous_from_time = from_time
											previous_to_time = to_time
											previous_ref_gdu_id = ref_gdu_id
											previous_other_gdu_id = other_gdu_id
											previous_tectonic_motion = tectonic_motion
											current_dominant_neighbour = first_candidate_ft.get_name()
									elif (result_2 == 'left'):
										result_2 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),second_candidate_ft.get_reconstruction_plate_id(),at_age,reference,main_centroid,second_candidate_bdn.get_centroid())
										if (result_2 == True and second_candidate_ft.get_name() != current_dominant_neighbour):
											previous_from_time = from_time
											previous_to_time = to_time
											previous_ref_gdu_id = ref_gdu_id
											previous_other_gdu_id = other_gdu_id
											previous_tectonic_motion = tectonic_motion
											current_dominant_neighbour = second_candidate_ft.get_name()
					row_1 = cur_1.fetchone()
				
				#double check to see whether the previous record has been recorded properly
				txt_4  = """SELECT * FROM test_final_summary_of_tectonic_boundaries_and_motion 
							WHERE from_time = {input_from_time}
							AND to_time = {input_to_time}
							AND tectonic_motion = '{input_tectonic_motion}'
							AND line_1_ft_name = '{input_line_1_ft_name}'
							AND line_2_ft_name = '{input_line_2_ft_name}'
							AND ref_gdu_id = {input_ref_gdu_id}
							AND other_gdu_id = {input_other_gdu_id}"""
				sql_4 = txt_4.format(input_from_time = previous_from_time, input_to_time = previous_to_time, input_tectonic_motion = previous_tectonic_motion, input_line_1_ft_name = current_line_ft_name, input_line_2_ft_name = current_dominant_neighbour, input_ref_gdu_id = previous_ref_gdu_id, input_other_gdu_id = previous_other_gdu_id)
				cur_4.execute(sql_4)
				row_4 = cur_4.fetchone()
				if (row_4 is None):
					if (previous_from_time > -1 and previous_to_time > -1 and previous_tectonic_motion is not None):
						sql_3 = """INSERT INTO test_final_summary_of_tectonic_boundaries_and_motion (from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s,%s,%s,%s,%s,%s,%s) """
						cur_3.execute(sql_3,(previous_from_time,previous_to_time,previous_tectonic_motion,current_line_ft_name,current_dominant_neighbour,previous_ref_gdu_id,previous_other_gdu_id))
						list_of_already_processed.append(current_dominant_neighbour)
			conn.commit()
			row = cur.fetchone()
	except (psycopg2.DatabaseError) as error:
		print("Error realted to the database use_azimuth_direction_to_find_the_closest_neighbour")
		print(error)

def check_validity_of_pair_of_line_fts(rotation_model, reference, main_tectonic_bdn_ft, other_tectonic_bdn_fts, at_age, left_gdu_id_of_original_CON_OCN_for_main, right_gdu_id_of_original_CON_OCN_for_main):
	reconstructed_other_tectonic_bdn_fts = []
	reconstructed_main_tectonic_bdn_fts = []
	if (reference is not None):
		pygplates.reconstruct(other_tectonic_bdn_fts,rotation_model,reconstructed_other_tectonic_bdn_fts,float(at_age),anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(main_tectonic_bdn_ft,rotation_model,reconstructed_main_tectonic_bdn_fts,float(at_age),anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(other_tectonic_bdn_fts,rotation_model,reconstructed_other_tectonic_bdn_fts,float(at_age),group_with_feature = True)
		pygplates.reconstruct(main_tectonic_bdn_ft,rotation_model,reconstructed_main_tectonic_bdn_fts,float(at_age),group_with_feature = True)
	final_reconstructed_other_tectonic_bdn_fts = supporting.find_final_reconstructed_geometries(reconstructed_other_tectonic_bdn_fts,pygplates.PolylineOnSphere) 
	final_reconstructed_main_tectonic_bdn_ft = supporting.find_final_reconstructed_geometries(reconstructed_main_tectonic_bdn_fts,pygplates.PolylineOnSphere)
	reconstr_main_bdn_ft,reconstr_main_bdn = final_reconstructed_main_tectonic_bdn_ft[0]
	first_point_of_main_line = reconstr_main_bdn[0]
	end_point_of_main_line = reconstr_main_bdn[-1]
	great_circle_arc = pygplates.GreatCircleArc(first_point_of_main_line,end_point_of_main_line)
	main_centroid = great_circle_arc.get_arc_point(0.500)
	main_arc_direction = great_circle_arc.get_arc_direction(0.500)
	normal_unit_vector = great_circle_arc.get_great_circle_normal()
	
	first_candidate_ft,first_candidate_bdn = final_reconstructed_other_tectonic_bdn_fts[0]
	great_circle_arc_for_first_candidate = pygplates.GreatCircleArc(first_candidate_bdn[0],first_candidate_bdn[-1])
	first_candidate_bdn_centroid = great_circle_arc_for_first_candidate.get_arc_point(0.500)
	first_candidate_arc_direction = great_circle_arc_for_first_candidate.get_arc_direction(0.500)
	normal_unit_vector_for_first_candidate = great_circle_arc_for_first_candidate.get_great_circle_normal()
	#print(len(final_reconstructed_other_tectonic_bdn_fts))
	#print("left_gdu_id_of_original_CON_OCN_for_main",left_gdu_id_of_original_CON_OCN_for_main)
	#print("right_gdu_id_of_original_CON_OCN_for_main",right_gdu_id_of_original_CON_OCN_for_main)
	
	#calculate angle between two vectors pointing directions of two arcs
	is_line_1_reversed_order = False
	angle_btw_rads = pygplates.Vector3D.angle_between(main_arc_direction,first_candidate_arc_direction)
	angle_btw_degs = math.degrees(angle_btw_rads)
	if (angle_btw_degs <= 75.00): #the order of start and end points for each line is the same relative to each other
		is_line_1_reversed_order = False
	elif (angle_btw_degs > 75.00 and angle_btw_degs <= 105.00):
		return 'invalid'
	elif (angle_btw_degs > 105.00 and angle_btw_degs <= 180.00): #the order of start and end points for each line is not the same relative to each other
		is_line_1_reversed_order = True
	
	if (is_line_1_reversed_order == True):
		first_candidate_arc_direction = first_candidate_arc_direction*(-1.00)
	
	_,local_azimuth_rads,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(main_centroid,first_candidate_arc_direction)
	local_azimuth_degs = math.degrees(local_azimuth_rads)
	#print("local_azimuth_degs",local_azimuth_degs)
	result = None
	if ((local_azimuth_degs >= 0.00 and local_azimuth_degs <= 180.00)):
		result = "right"
	else:
		result = "left"
	#print("result",result)
	if (len(final_reconstructed_other_tectonic_bdn_fts) == 1):
		if (left_gdu_id_of_original_CON_OCN_for_main > 0 ): #then we need to look for the right side of the original line ft
			# result_1 = classify_left_or_right_for_line(normal_unit_vector,main_centroid,first_candidate_bdn_centroid,normal_unit_vector_for_first_candidate)
			# print("result_1",result_1)
			# if (result_1	== 'right'):
				# #angle_1 = calculate_angle_from_three_diff_points(end_point_of_main_line,main_centroid,first_candidate_bdn.get_centroid())
				# # result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,reconstr_main_bdn,first_candidate_bdn)
				# # if (result_1 == True):
					# # return 'Valid'
				# return 'Valid'
			if (result	== 'right'):
				#angle_1 = calculate_angle_from_three_diff_points(end_point_of_main_line,main_centroid,first_candidate_bdn.get_centroid())
				result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,reconstr_main_bdn,first_candidate_bdn)
				if (result_1 == True):
					return 'Valid'
				#return 'Valid'
		elif (right_gdu_id_of_original_CON_OCN_for_main > 0):#then we need to look for the left side of the original line ft
			# result_1 = classify_left_or_right_for_line(normal_unit_vector,main_centroid,first_candidate_bdn_centroid,normal_unit_vector_for_first_candidate)
			# print("result_1",result_1)
			# if (result_1 == 'left'):
				# # result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,reconstr_main_bdn,first_candidate_bdn)
				# # if (result_1 == True):
				# return 'Valid'
			if (result	== 'left'):
				#angle_1 = calculate_angle_from_three_diff_points(end_point_of_main_line,main_centroid,first_candidate_bdn.get_centroid())
				result_1 = is_possible_neighbour(rotation_model,main_tectonic_bdn_ft.get_reconstruction_plate_id(),first_candidate_ft.get_reconstruction_plate_id(),at_age,reference,reconstr_main_bdn,first_candidate_bdn)
				if (result_1 == True):
					return 'Valid'
				#return 'Valid'
	else:
		print("Error in check_validity_of_pair_of_line_fts")
		print("len(final_reconstructed_other_tectonic_bdn_fts)!=1")
		print("len(final_reconstructed_other_tectonic_bdn_fts)",len(final_reconstructed_other_tectonic_bdn_fts))
		print("main_tectonic_bdn_ft",main_tectonic_bdn_ft.get_name(),main_tectonic_bdn_ft.get_reconstruction_plate_id(),main_tectonic_bdn_ft.get_valid_time())
		print("other_tectonic_bdn_ft",other_tectonic_bdn_ft.get_name(),other_tectonic_bdn_ft.get_reconstruction_plate_id(),other_tectonic_bdn_ft.get_valid_time())
		print("at_age",at_age)
		exit()
		
	return None

def use_azimuth_direction_to_find_the_closest_neighbour_2(rotation_model,messy_tectonic_boundaries_features,CON_OCN_line_feats,reference):
	sql = """SELECT DISTINCT line_1_ft_name
				FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion
				UNION
			SELECT DISTINCT line_2_ft_name
			FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion"""
	cur = None
	cur_1 = None
	cur_2 = None
	cur_3 = None
	cur_4 = None
	cur_5 = None
	cur_6 = None
	cur_9 = None
	cur_10 = None
	cur_11 = None
	cur_12 = None
	cur_13 = None
	list_of_already_processed = []
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		cur_5 = conn.cursor()
		cur_6 = conn.cursor()
		cur_9 = conn.cursor()
		cur_10 = conn.cursor()
		cur_11 = conn.cursor()
		cur_12 = conn.cursor()
		cur_13 = conn.cursor()
		output_dic = {}
		cur.execute(sql)
		row = cur.fetchone()
		while(row is not None):
			print('row',row)
			current_line_ft_name = row[0]
			continue_to_process_line_ft = False
			upper_limit_for_from_time_for_line_ft = -1.00
			if (current_line_ft_name not in list_of_already_processed):
				continue_to_process_line_ft = True
			else:
				txt_5  = """SELECT from_time,to_time FROM test_final_summary_of_tectonic_boundaries_and_motion 
							WHERE (line_1_ft_name = '{input_line_ft_name}'
							OR line_2_ft_name = '{input_line_ft_name}')
							ORDER BY to_time ASC"""
				sql_5 = txt_5.format(input_line_ft_name = current_line_ft_name)
				cur_5.execute(sql_5)
				row_5 = cur_5.fetchone()
				if (row_5 is not None):
					smallest_to_time = float(row_5[1])
					txt_6 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion
						   WHERE from_time <= {input_time}
						   AND (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}')
						   ORDER BY from_time DESC """
					sql_6 = txt_6.format(input_time = smallest_to_time , input_line_ft_name = current_line_ft_name)
					cur_6.execute(sql_6)
					row_6 = cur_6.fetchone()
					if (row_6 is not None):
						upper_limit_for_from_time_for_line_ft = smallest_to_time
						continue_to_process_line_ft = True
			if (continue_to_process_line_ft == True):
				list_of_already_processed.append(current_line_ft_name)
				txt_2 = """SELECT from_time, to_time, gdu_id, lef_gdu_id, right_gdu_id
							   FROM tectonic_topological_line_fts
							   WHERE type_of_line_fts = 'CON_OCN' AND (initial_ft_id = '{input_line_ft_name}' or name = '{input_line_ft_name}')"""
				sql_2 = txt_2.format(input_line_ft_name = current_line_ft_name)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				print(sql_2)
				CON_OCN_from_time = float(row_2[0])
				CON_OCN_to_time = float(row_2[1])
				gdu_id_of_line_ft = int(row_2[2])
				left_gdu_id_of_line_ft = int(row_2[3])
				right_gdu_id_of_line_ft = int(row_2[4])
				txt_1 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion
						   WHERE from_time <= {input_CON_OCN_from_time} AND to_time >= {input_CON_OCN_to_time} 
						   AND (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}')
						   ORDER BY from_time DESC"""
				if (upper_limit_for_from_time_for_line_ft == -1.00):
					sql_1 = txt_1.format(input_CON_OCN_from_time = CON_OCN_from_time, input_CON_OCN_to_time = CON_OCN_to_time,input_line_ft_name = current_line_ft_name)
					print(sql_1)
					cur_1.execute(sql_1)
				elif (upper_limit_for_from_time_for_line_ft > -1.00):
					sql_1 = txt_1.format(input_CON_OCN_from_time = upper_limit_for_from_time_for_line_ft, input_CON_OCN_to_time = CON_OCN_to_time,input_line_ft_name = current_line_ft_name)
					print(sql_1)
					cur_1.execute(sql_1)
				row_1 = cur_1.fetchone()
				while ((row_1 is None) and (row_2 is not None)):
					row_2 = cur_2.fetchone()
					if (row_2 is not None):
						CON_OCN_from_time = float(row_2[0])
						CON_OCN_to_time = float(row_2[1])
						gdu_id_of_line_ft = int(row_2[2])
						left_gdu_id_of_line_ft = int(row_2[3])
						right_gdu_id_of_line_ft = int(row_2[4])
						if (upper_limit_for_from_time_for_line_ft == -1.00):
							sql_1 = txt_1.format(input_CON_OCN_from_time = CON_OCN_from_time, input_CON_OCN_to_time = CON_OCN_to_time,input_line_ft_name = current_line_ft_name)
							print(sql_1)
							cur_1.execute(sql_1)
						elif (upper_limit_for_from_time_for_line_ft > -1.00):
							sql_1 = txt_1.format(input_CON_OCN_from_time = upper_limit_for_from_time_for_line_ft, input_CON_OCN_to_time = CON_OCN_to_time,input_line_ft_name = current_line_ft_name)
							print(sql_1)
							cur_1.execute(sql_1)
						row_1 = cur_1.fetchone()
				current_dominant_neighbour = None
				previous_from_time = -1.00
				previous_to_time = -1.00
				previous_ref_gdu_id = -1.00
				previous_other_gdu_id = -1.00
				previous_tectonic_motion = None
				main_tectonic_bdn_ft = None
				substitute_candidate_line_fts = []
				substitute_main_line_fts = []
				previous_valid_candidate = False
				previous_candidate_tectonic_ft = None
				previous_main_tectonic_ft = None
				is_valid_candidate = False
				while (row_1 is not None):
					print("row_1",row_1)
					substitute_candidate_line_fts[:] = []
					ref_gdu_id = int(row_1[0])
					other_gdu_id = int(row_1[1])
					line_1_ft_name = row_1[2] 
					line_2_ft_name = row_1[3]
					tectonic_motion = row_1[6]
					other_line_ft_name = None
					if (line_1_ft_name == current_line_ft_name):
						other_line_ft_name = line_2_ft_name
					else:
						other_line_ft_name = line_1_ft_name
					from_time = float(row_1[4])
					to_time = float(row_1[5])
					txt_13 = """SELECT from_time,to_time FROM test_final_summary_of_tectonic_boundaries_and_motion 
							WHERE (line_1_ft_name = '{input_other_line_ft_name}'
									OR line_2_ft_name = '{input_other_line_ft_name}')
							AND (NOT((to_time > {input_from_time}) OR (from_time < {input_to_time}))) """
					sql_13 = txt_13.format(input_other_line_ft_name = other_line_ft_name, input_from_time = from_time, input_to_time = to_time)
					cur_13.execute(sql_13)
					row_13 = cur_13.fetchone()
					while ((row_13 is not None) and (row_1 is not None)):
						row_1 = cur_1.fetchone()
						if (row_1 is not None):
							ref_gdu_id = int(row_1[0])
							other_gdu_id = int(row_1[1])
							line_1_ft_name = row_1[2] 
							line_2_ft_name = row_1[3]
							tectonic_motion = row_1[6]
							other_line_ft_name = None
							if (line_1_ft_name == current_line_ft_name):
								other_line_ft_name = line_2_ft_name
							else:
								other_line_ft_name = line_1_ft_name
							from_time = float(row_1[4])
							to_time = float(row_1[5])
							sql_13 = txt_13.format(input_other_line_ft_name = other_line_ft_name, input_from_time = from_time, input_to_time = to_time)
							cur_13.execute(sql_13)
							row_13 = cur_13.fetchone()
					if (row_1 is None):
						break
						
					temp_at_age = -1.00
					if (previous_candidate_tectonic_ft is not None):
						if (from_time == previous_from_time):
							temp_at_age = float(from_time)
						elif (previous_to_time >= from_time):
							temp_at_age = float(from_time) 
						else:
							list_of_time = [previous_from_time,previous_to_time,from_time,to_time]
							list_of_time.sort(reverse = True) #descending order
							#choose the second element
							temp_at_age = float(list_of_time[1])
					else:
						temp_at_age = float(from_time + to_time)/2.00
					txt_12 = """SELECT from_time, to_time, gdu_id, lef_gdu_id, right_gdu_id
							   FROM tectonic_topological_line_fts
							   WHERE type_of_line_fts = 'CON_OCN' 
							   AND (initial_ft_id = '{input_line_ft_name}' or name = '{input_line_ft_name}')
							   AND from_time >= {input_tectonic_from_time} AND to_time <= {input_tectonic_to_time}
							   INTERSECT
							   SELECT from_time, to_time, gdu_id, lef_gdu_id, right_gdu_id
							   FROM tectonic_topological_line_fts
							   WHERE type_of_line_fts = 'CON_OCN' 
							   AND (initial_ft_id = '{input_line_ft_name}' or name = '{input_line_ft_name}')
							   AND from_time >= {input_temp_age} AND to_time <= {input_temp_age}"""
					sql_12 = txt_12.format(input_line_ft_name = other_line_ft_name, input_tectonic_from_time = from_time, input_tectonic_to_time = to_time, input_temp_age = temp_at_age)
					cur_12.execute(sql_12)
					row_12 = cur_12.fetchone()
					txt_9 = """SELECT * FROM test_summary_of_tectonic_motion
						   WHERE (ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id})
							AND (from_time = {input_from_time} and to_time = {input_to_time})
							AND validity = 'Invalid'"""
					sql_9 =	 txt_9.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
					cur_9.execute(sql_9)
					row_9 = cur_9.fetchone()
					while ((row_9 is not None) or (row_12 is None)):
						row_1 = cur_1.fetchone()
						if (row_1 is not None):
							ref_gdu_id = int(row_1[0])
							other_gdu_id = int(row_1[1])
							line_1_ft_name = row_1[2] 
							line_2_ft_name = row_1[3]
							from_time = row_1[4]
							to_time = row_1[5]
							tectonic_motion = row_1[6]
							sql_9 =	 txt_9.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
							cur_9.execute(sql_9)
							row_9 = cur_9.fetchone()
						else:
							break
					if (row_1 is None):
						break
					
					if (previous_candidate_tectonic_ft is not None):
						if (from_time == previous_from_time):
							temp_at_age = float(from_time)
						elif (previous_to_time >= from_time):
							temp_at_age = float(from_time) 
						else:
							list_of_time = [previous_from_time,previous_to_time,from_time,to_time]
							list_of_time.sort(reverse = True) #descending order
							#choose the second element
							temp_at_age = float(list_of_time[1])
					else:
						temp_at_age = float(from_time + to_time)/2.00
					print("temp_at_age",temp_at_age)
					print("to line 1381")
					temp_main_tectonic_bdn_ft = None
					temp_other_tectonic_bdn_ft = None
					#looking for temp_main_tectonic_bdn_ft
					if (previous_main_tectonic_ft is not None):
						if (previous_main_tectonic_ft.is_valid_at_time(temp_at_age) == False):
							if (line_1_ft_name == current_line_ft_name):
								for bdn_ft in messy_tectonic_boundaries_features:
									if (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
										if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
											temp_main_tectonic_bdn_ft = bdn_ft
									if (temp_main_tectonic_bdn_ft is not None):
										break
							elif (line_2_ft_name == current_line_ft_name):
								for bdn_ft in messy_tectonic_boundaries_features:
									if (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
										if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
											temp_main_tectonic_bdn_ft = bdn_ft
									if (temp_main_tectonic_bdn_ft is not None):
										break
						else:
							temp_main_tectonic_bdn_ft = previous_main_tectonic_ft
					else:
						if (line_1_ft_name == current_line_ft_name):
							for bdn_ft in messy_tectonic_boundaries_features:
								if (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
									if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
										temp_main_tectonic_bdn_ft = bdn_ft
								if (temp_main_tectonic_bdn_ft is not None):
									break
						elif (line_2_ft_name == current_line_ft_name):
							for bdn_ft in messy_tectonic_boundaries_features:
								if (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
									if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
										temp_main_tectonic_bdn_ft = bdn_ft
								if (temp_main_tectonic_bdn_ft is not None):
									break
					#looking for temp_other_tectonic_bdn_ft
					if (line_1_ft_name == current_line_ft_name):
						for bdn_ft in messy_tectonic_boundaries_features:
							if (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
								if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
									temp_other_tectonic_bdn_ft = bdn_ft
							if (temp_other_tectonic_bdn_ft is not None):
								break
					elif (line_2_ft_name == current_line_ft_name):
						for bdn_ft in messy_tectonic_boundaries_features:
							if (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
								if ((bdn_ft.get_left_plate() == ref_gdu_id and bdn_ft.get_right_plate() == other_gdu_id) or (bdn_ft.get_left_plate() == other_gdu_id and bdn_ft.get_right_plate() == ref_gdu_id)):
									temp_other_tectonic_bdn_ft = bdn_ft
							if (temp_other_tectonic_bdn_ft is not None):
								break
					print("temp_main_tectonic_bdn_ft",temp_main_tectonic_bdn_ft)
					print("temp_other_tectonic_bdn_ft",temp_other_tectonic_bdn_ft)
					#reset valid_candidate for the new candidate
					is_valid_candidate = False
					if (temp_main_tectonic_bdn_ft is not None and temp_other_tectonic_bdn_ft is not None):
						temp_result = check_validity_of_pair_of_line_fts(rotation_model, reference, temp_main_tectonic_bdn_ft, temp_other_tectonic_bdn_ft, temp_at_age, left_gdu_id_of_line_ft, right_gdu_id_of_line_ft)
						print(temp_result)
						if (temp_result == 'Valid'):
							is_valid_candidate = True
						else:
							substitute_candidate_line_fts[:] = []
							for temp_CON_OCN_ft in CON_OCN_line_feats:
								if (temp_CON_OCN_ft.is_valid_at_time(temp_at_age) and temp_CON_OCN_ft.get_name() != current_dominant_neighbour):
									if (temp_main_tectonic_bdn_ft.get_reconstruction_plate_id() == ref_gdu_id):
										if (temp_CON_OCN_ft.get_reconstruction_plate_id() == other_gdu_id):
											substitute_candidate_line_fts.append(temp_CON_OCN_ft)
									elif (temp_main_tectonic_bdn_ft.get_reconstruction_plate_id() == other_gdu_id):
										if (temp_CON_OCN_ft.get_reconstruction_plate_id() == ref_gdu_id):
											substitute_candidate_line_fts.append(temp_CON_OCN_ft)
							temp_other_tectonic_bdn_ft = None
							for temp_other_tectonic_bdn_ft in substitute_candidate_line_fts:
								temp_result = check_validity_of_pair_of_line_fts(rotation_model, reference, temp_main_tectonic_bdn_ft, temp_other_tectonic_bdn_ft, temp_at_age, left_gdu_id_of_line_ft, right_gdu_id_of_line_ft)
								if (temp_result == 'Valid'):
									is_valid_candidate = True
									if (line_1_ft_name == current_line_ft_name):
										line_2_ft_name = temp_other_tectonic_bdn_ft.get_name()
									else:
										line_1_ft_name = temp_other_tectonic_bdn_ft.get_name()
									break
					else:
						if (temp_main_tectonic_bdn_ft is not None and temp_other_tectonic_bdn_ft is None):
							substitute_candidate_line_fts[:] = []
							for temp_CON_OCN_ft in CON_OCN_line_feats:
								if (temp_CON_OCN_ft.is_valid_at_time(temp_at_age) and temp_CON_OCN_ft.get_name() != current_dominant_neighbour):
									if (temp_main_tectonic_bdn_ft.get_reconstruction_plate_id() == ref_gdu_id):
										if (temp_CON_OCN_ft.get_reconstruction_plate_id() == other_gdu_id):
											substitute_candidate_line_fts.append(temp_CON_OCN_ft)
									elif (temp_main_tectonic_bdn_ft.get_reconstruction_plate_id() == other_gdu_id):
										if (temp_CON_OCN_ft.get_reconstruction_plate_id() == ref_gdu_id):
											substitute_candidate_line_fts.append(temp_CON_OCN_ft)
							temp_other_tectonic_bdn_ft = None
							for temp_other_tectonic_bdn_ft in substitute_candidate_line_fts:
								temp_result = check_validity_of_pair_of_line_fts(rotation_model, reference, temp_main_tectonic_bdn_ft, temp_other_tectonic_bdn_ft, temp_at_age, left_gdu_id_of_line_ft, right_gdu_id_of_line_ft)
								if (temp_result == 'Valid'):
									is_valid_candidate = True
									if (line_1_ft_name == current_line_ft_name):
										line_2_ft_name = temp_other_tectonic_bdn_ft.get_name()
									else:
										line_1_ft_name = temp_other_tectonic_bdn_ft.get_name()
									break
						elif (temp_main_tectonic_bdn_ft is None and temp_other_tectonic_bdn_ft is not None):
							substitute_main_line_fts = []
							for temp_CON_OCN_ft in CON_OCN_line_feats:
								if (temp_CON_OCN_ft.is_valid_at_time(temp_at_age) and temp_CON_OCN_ft.get_name() != current_dominant_neighbour and temp_CON_OCN_ft.get_name() == current_line_ft_name):
									if (temp_other_tectonic_bdn_ft.get_reconstruction_plate_id() == ref_gdu_id):
										if (temp_CON_OCN_ft.get_reconstruction_plate_id() == other_gdu_id):
											substitute_main_line_fts.append(temp_CON_OCN_ft)
									elif (temp_other_tectonic_bdn_ft.get_reconstruction_plate_id() == other_gdu_id):
										if (temp_CON_OCN_ft.get_reconstruction_plate_id() == ref_gdu_id):
											substitute_main_line_fts.append(temp_CON_OCN_ft)
							temp_main_tectonic_bdn_ft = None
							for temp_main_tectonic_bdn_ft in substitute_main_line_fts:
								temp_result = check_validity_of_pair_of_line_fts(rotation_model, reference, temp_main_tectonic_bdn_ft, temp_other_tectonic_bdn_ft, temp_at_age, left_gdu_id_of_line_ft, right_gdu_id_of_line_ft)
								if (temp_result == 'Valid'):
									is_valid_candidate = True
									if (line_1_ft_name == current_line_ft_name):
										line_2_ft_name = temp_other_tectonic_bdn_ft.get_name()
									else:
										line_1_ft_name = temp_other_tectonic_bdn_ft.get_name()
									break
					if (is_valid_candidate == False):
						substitute_candidate_line_fts[:] = []
						substitute_main_line_fts[:] = []
						for temp_CON_OCN_ft in CON_OCN_line_feats:
							if (temp_CON_OCN_ft.is_valid_at_time(temp_at_age)):
								if (temp_CON_OCN_ft.get_reconstruction_plate_id() == ref_gdu_id):
									substitute_main_line_fts.append(temp_CON_OCN_ft)
						for temp_CON_OCN_ft in CON_OCN_line_feats:
							if (temp_CON_OCN_ft.is_valid_at_time(temp_at_age)):
								if (temp_CON_OCN_ft.get_reconstruction_plate_id() == other_gdu_id):
									substitute_candidate_line_fts.append(temp_CON_OCN_ft)
						temp_result = None
						for temp_main_tectonic_bdn_ft in substitute_main_line_fts:
							for temp_other_tectonic_bdn_ft in substitute_candidate_line_fts:
								temp_result = check_validity_of_pair_of_line_fts(rotation_model, reference, temp_main_tectonic_bdn_ft, temp_other_tectonic_bdn_ft, temp_at_age, left_gdu_id_of_line_ft, right_gdu_id_of_line_ft)
								if (temp_result == 'Valid'):
									#update everything, if only not record yet
									txt_11 = """SELECT * FROM test_new_candidates_tectonic_boundaries_and_motion
												WHERE from_time = {input_from_time} AND to_time = {input_to_time}
												AND ref_gdu_id = {input_ref_gdu_id} AND other_gdu_id = {input_other_gdu_id}
												AND ((line_1_ft_name = '{input_line_1_ft_name}' AND line_2_ft_name = '{input_line_2_ft_name}')
													OR (line_1_ft_name = '{input_line_2_ft_name}' AND line_2_ft_name = '{input_line_1_ft_name}'))"""
									sql_11 = txt_11.format(input_from_time = from_time, input_to_time = to_time, input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_line_1_ft_name = temp_main_tectonic_bdn_ft.get_name(), input_line_2_ft_name = temp_other_tectonic_bdn_ft.get_name())
									cur_11.execute(sql_11)
									if (cur_11.fetchone() is None):
										sql_10 = """INSERT into test_new_candidates_tectonic_boundaries_and_motion(from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id, line_1_ft_name, line_2_ft_name) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
										cur_10.execute(sql_10,(from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id, temp_main_tectonic_bdn_ft.get_name(), temp_other_tectonic_bdn_ft.get_name()))
										#conn.commit()
									#regardless we have already found the substitute valid pair so we can break from the for loops
									break
							if (temp_result == 'Valid'):
								break
						temp_main_tectonic_bdn_ft = None
						temp_other_tectonic_bdn_ft = None
						is_valid_candidate = False #because for two completely two different line features
					if (previous_from_time == -1.00 and previous_to_time == -1.00 and is_valid_candidate == True):
						if (row_9 is None):
							
							if (line_1_ft_name == current_line_ft_name):
								current_dominant_neighbour = line_2_ft_name
							else:
								current_dominant_neighbour = line_1_ft_name
							previous_from_time = from_time
							previous_to_time = to_time
							previous_ref_gdu_id = ref_gdu_id
							previous_other_gdu_id = other_gdu_id
							previous_tectonic_motion = tectonic_motion
							#update the state of valid 
							previous_valid_candidate = is_valid_candidate
							previous_candidate_tectonic_ft = temp_other_tectonic_bdn_ft
							previous_main_tectonic_ft = temp_main_tectonic_bdn_ft
					elif (previous_candidate_tectonic_ft is not None and previous_main_tectonic_ft is not None):
						#is_valid_check = False
						# txt_9 = """SELECT * FROM test_summary_of_tectonic_motion
						   # WHERE (ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id})
							# AND (from_time = {input_from_time} and to_time = {input_to_time})
							# AND validity = 'Invalid'"""
						# sql_9 =	 txt_9.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
						# cur_9.execute(sql_9)
						# row_9 = cur_9.fetchone()
						# # if (row_9 is None and is_valid_candidate == True):
							# # is_valid_check = True
						if ((previous_from_time == from_time) and (previous_to_time == to_time) and ((current_dominant_neighbour == line_1_ft_name) or (current_dominant_neighbour == line_2_ft_name))):
							if (from_time - to_time <= 1.00):
								if ((previous_tectonic_motion == 'Transform') and (tectonic_motion == 'Convergence' or tectonic_motion == 'Divergence')):
									previous_tectonic_motion = 'Transform'
								elif ((tectonic_motion == 'Transform') and (previous_tectonic_motion == 'Convergence' or previous_tectonic_motion == 'Divergence')):
									previous_tectonic_motion = 'Transform'
								elif (previous_tectonic_motion == 'Unknown_same_motion' and tectonic_motion != 'Unknown_same_motion'):
									previous_tectonic_motion = tectonic_motion
								elif (tectonic_motion == 'Unknown_same_motion' and previous_tectonic_motion != 'Unknown_same_motion'):
									previous_tectonic_motion = previous_tectonic_motion
						elif ((previous_to_time >= from_time) and (previous_valid_candidate == True)): #because we order records by from_time so we don't need to worry about previous_from_time < to_time
							#insert the previous_record to the finally summary database table
							#final_summary_of_tectonic_boundaries_and_motion
							sql_3 = """INSERT INTO test_final_summary_of_tectonic_boundaries_and_motion (from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s,%s,%s,%s,%s,%s,%s) """
							cur_3.execute(sql_3,(previous_from_time,previous_to_time,previous_tectonic_motion,current_line_ft_name,current_dominant_neighbour,previous_ref_gdu_id,previous_other_gdu_id))
							list_of_already_processed.append(current_dominant_neighbour)
							if (is_valid_candidate == True):
								if (line_1_ft_name == current_line_ft_name):
									current_dominant_neighbour = line_2_ft_name
								else:
									current_dominant_neighbour = line_1_ft_name
								previous_from_time = from_time
								previous_to_time = to_time
								previous_ref_gdu_id = ref_gdu_id
								previous_other_gdu_id = other_gdu_id
								previous_tectonic_motion = tectonic_motion
								#update the state of valid 
								previous_valid_candidate = is_valid_candidate
								previous_candidate_tectonic_ft = temp_other_tectonic_bdn_ft
								previous_main_tectonic_ft = temp_main_tectonic_bdn_ft
							else:
								current_dominant_neighbour = None
								previous_from_time = -1.00
								previous_to_time = -1.00
								previous_ref_gdu_id = -1.00
								previous_other_gdu_id = -1.00
								previous_tectonic_motion = None
								main_tectonic_bdn_ft = None
								substitute_candidate_line_fts[:] = []
								substitute_main_line_fts[:] = []
								previous_valid_candidate = False
								previous_candidate_tectonic_ft = None
								previous_main_tectonic_ft = None
						elif (is_valid_candidate == True):
							reconstructed_other_tectonic_bdn_fts = []
							reconstructed_main_tectonic_bdn_fts = []
							other_tectonic_bdn_fts = []
							at_age = temp_at_age
							main_tectonic_bdn_ft = temp_main_tectonic_bdn_ft

							found_current_dominant_neighour_ft = None
							found_new_neighbour_ft = temp_other_tectonic_bdn_ft
							if (previous_candidate_tectonic_ft is not None):
								if (previous_candidate_tectonic_ft.is_valid_at_time(at_age)):
									found_current_dominant_neighour_ft = previous_candidate_tectonic_ft
								else:
									if (line_1_ft_name == current_line_ft_name):
										for bdn_ft in messy_tectonic_boundaries_features:
											if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
												if ((bdn_ft.get_left_plate() == previous_ref_gdu_id and bdn_ft.get_right_plate() == previous_other_gdu_id) or (bdn_ft.get_left_plate() == previous_other_gdu_id and bdn_ft.get_right_plate() == previous_ref_gdu_id)):
													found_current_dominant_neighour_ft = bdn_ft
									elif (line_2_ft_name == current_line_ft_name):
										for bdn_ft in messy_tectonic_boundaries_features:
											if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
												if ((bdn_ft.get_left_plate() == previous_ref_gdu_id and bdn_ft.get_right_plate() == previous_other_gdu_id) or (bdn_ft.get_left_plate() == previous_other_gdu_id and bdn_ft.get_right_plate() == previous_ref_gdu_id)):
													found_current_dominant_neighour_ft = bdn_ft
							
							if (found_current_dominant_neighour_ft is not None):
								other_tectonic_bdn_fts.append(found_current_dominant_neighour_ft)
								print('found_current_dominant_neighour_ft',found_current_dominant_neighour_ft.get_name())
							else:
								for bdn_ft in CON_OCN_line_feats:
									if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
										found_current_dominant_neighour_ft = bdn_ft
										other_tectonic_bdn_fts.append(bdn_ft)
										break
							if (found_new_neighbour_ft is not None):
								other_tectonic_bdn_fts.append(found_new_neighbour_ft)
								print('found_new_neighbour_ft',found_new_neighbour_ft.get_name())
							print('len(other_tectonic_bdn_fts)',len(other_tectonic_bdn_fts))
							print('line_1_ft_name',line_1_ft_name,'line_2_ft_name',line_2_ft_name)
							print('current_dominant_neighbour',current_dominant_neighbour)
							print('current_line_ft_name',current_line_ft_name)
							# if (len(other_tectonic_bdn_fts) < 2):
								# if (len(other_tectonic_bdn_fts) == 1):
									# current_existed_ft = other_tectonic_bdn_fts[0]
									# if (line_1_ft_name == current_line_ft_name):
										# if (current_existed_ft.get_name() == line_2_ft_name):
											# for bdn_ft in CON_OCN_line_feats:
												# if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
													# other_tectonic_bdn_fts.append(bdn_ft)
													# break
										# elif (current_existed_ft.get_name() == current_dominant_neighbour):
											# for bdn_ft in CON_OCN_line_feats:
												# if (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(at_age)):
													# other_tectonic_bdn_fts.append(bdn_ft)
													# break
									# elif (line_2_ft_name == current_line_ft_name):
										# if (current_existed_ft.get_name() == line_1_ft_name):
											# for bdn_ft in CON_OCN_line_feats:
												# if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
													# other_tectonic_bdn_fts.append(bdn_ft)
													# break
										# elif (current_existed_ft.get_name() == current_dominant_neighbour):
											# for bdn_ft in CON_OCN_line_feats:
												# if (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(at_age)):
													# other_tectonic_bdn_fts.append(bdn_ft)
													# break
								# elif (len(other_tectonic_bdn_fts) == 0):
									# found_current_dominant_neighour_ft = None
									# found_new_neighbour_ft = None
									# if (line_1_ft_name == current_line_ft_name):
										# for bdn_ft in CON_OCN_line_feats:
											# if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
												# found_current_dominant_neighour_ft = bdn_ft
											# elif (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(at_age)):
												# found_new_neighbour_ft = bdn_ft
											# if (found_current_dominant_neighour_ft is not None and found_new_neighbour_ft is not None):
												# other_tectonic_bdn_fts.append(found_current_dominant_neighour_ft)
												# other_tectonic_bdn_fts.append(found_new_neighbour_ft)
												# break
									# elif (line_2_ft_name == current_line_ft_name):
										# for bdn_ft in CON_OCN_line_feats:
											# if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
												# found_current_dominant_neighour_ft = bdn_ft
											# elif (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(at_age)):
												# found_new_neighbour_ft = bdn_ft
											# if (found_current_dominant_neighour_ft is not None and found_new_neighbour_ft is not None):
												# other_tectonic_bdn_fts.append(found_current_dominant_neighour_ft)
												# other_tectonic_bdn_fts.append(found_new_neighbour_ft)
												# break
									
							#reconstruct all tectonic bdn fts to at_age
							print("at_age",at_age)
							print("previous_from_time,previous_to_time,from_time,to_time",previous_from_time,previous_to_time,from_time,to_time)
							#print("main_tectonic_bdn_ft.get_valid_time()",main_tectonic_bdn_ft.get_valid_time())
							#print(main_tectonic_bdn_ft.get_name())
							if (main_tectonic_bdn_ft is not None and len(other_tectonic_bdn_fts) >= 2):#first check
								print("found_current_dominant_neighour_ft",found_current_dominant_neighour_ft)
								print("found_new_neighbour_ft",found_new_neighbour_ft)
								if (found_current_dominant_neighour_ft.get_name() == found_new_neighbour_ft.get_name() == current_dominant_neighbour):
									#keep previous_from_time because we already performed a query by from_time ORDER BY DESC
									#only update previous_to_time,if it is required
									if (to_time < previous_to_time):
										previous_to_time = to_time
									other_tectonic_bdn_fts[:] = []
							if (main_tectonic_bdn_ft is not None and len(other_tectonic_bdn_fts) >= 2):#second check
								# for bdn_ft in messy_tectonic_boundaries_features:
									# if (bdn_ft.get_name() == current_line_ft_name and bdn_ft.is_valid_at_time(at_age)):
										# main_tectonic_bdn_ft = bdn_ft.clone()
										# # print(bdn_ft.get_valid_time())
										# # print(bdn_ft.get_feature_type())
								# # exit()
								# print(main_tectonic_bdn_ft.get_left_plate(),main_tectonic_bdn_ft.get_right_plate())
								print("len(other_tectonic_bdn_fts)",len(other_tectonic_bdn_fts))
								for other_bdn_ft in other_tectonic_bdn_fts:
									print("other_bdn_ft.get_name",other_bdn_ft.get_name())
									# print("other_bdn_ft.get_feature_type",other_bdn_ft.get_feature_type())
									print("other_bdn_ft.get_valid_time",other_bdn_ft.get_valid_time())
									for geom in other_bdn_ft.get_geometries():
										print(geom.to_lat_lon_list())
									# print("other_bdn_ft.get_left_plate,right_plate",other_bdn_ft.get_left_plate(),other_bdn_ft.get_right_plate())
								#print("rotation_model",other_tectonic_bdn_fts)
								if (reference is not None):
									pygplates.reconstruct(other_tectonic_bdn_fts,rotation_model,reconstructed_other_tectonic_bdn_fts,float(at_age),anchor_plate_id = reference, group_with_feature = True)
									pygplates.reconstruct(main_tectonic_bdn_ft,rotation_model,reconstructed_main_tectonic_bdn_fts,float(at_age),anchor_plate_id = reference, group_with_feature = True)
								else:
									pygplates.reconstruct(other_tectonic_bdn_fts,rotation_model,reconstructed_other_tectonic_bdn_fts,float(at_age),group_with_feature = True)
									pygplates.reconstruct(main_tectonic_bdn_ft,rotation_model,reconstructed_main_tectonic_bdn_fts,float(at_age),group_with_feature = True)
								final_reconstructed_other_tectonic_bdn_fts = supporting.find_final_reconstructed_geometries(reconstructed_other_tectonic_bdn_fts,pygplates.PolylineOnSphere) 
								final_reconstructed_main_tectonic_bdn_ft = supporting.find_final_reconstructed_geometries(reconstructed_main_tectonic_bdn_fts,pygplates.PolylineOnSphere)
								reconstr_main_bdn_ft,reconstr_main_bdn = final_reconstructed_main_tectonic_bdn_ft[0]
								main_centroid = reconstr_main_bdn.get_centroid()
								first_candidate_ft,first_candidate_bdn = final_reconstructed_other_tectonic_bdn_fts[0]
								second_candidate_ft,second_candidate_bdn = final_reconstructed_other_tectonic_bdn_fts[1]
								# first_point_of_main_line = reconstr_main_bdn[0]
								# end_point_of_main_line = reconstr_main_bdn[-1]
								# great_circle_arc = pygplates.GreatCircleArc(first_point_of_main_line,end_point_of_main_line)
								# normal_unit_vector = great_circle_arc.get_great_circle_normal()
								# great_circle_arc_for_first_candidate = pygplates.GreatCircleArc(first_candidate_bdn[0],first_candidate_bdn[-1])
								# normal_unit_vector_for_first_candidate = great_circle_arc_for_first_candidate.get_great_circle_normal()
								# great_circle_arc_for_second_candidate = pygplates.GreatCircleArc(second_candidate_bdn[0],second_candidate_bdn[-1])
								# normal_unit_vector_for_second_candidate = great_circle_arc_for_second_candidate.get_great_circle_normal()
								distance_1 = pygplates.GeometryOnSphere.distance(main_centroid,first_candidate_bdn.get_centroid())
								distance_2 = pygplates.GeometryOnSphere.distance(main_centroid,second_candidate_bdn.get_centroid())
								if (distance_1 < distance_2):
									if ( first_candidate_ft.get_name() != current_dominant_neighbour):
										previous_from_time = from_time
										previous_to_time = to_time
										previous_ref_gdu_id = ref_gdu_id
										previous_other_gdu_id = other_gdu_id
										previous_tectonic_motion = tectonic_motion
										current_dominant_neighbour = first_candidate_ft.get_name()
										#update the state of valid 
										previous_valid_candidate = is_valid_candidate
										#update previous tectonic ft = 
										previous_candidate_tectonic_ft = first_candidate_ft
										previous_main_tectonic_ft = temp_main_tectonic_bdn_ft
								else:
									if (second_candidate_ft.get_name() != current_dominant_neighbour):
										previous_from_time = from_time
										previous_to_time = to_time
										previous_ref_gdu_id = ref_gdu_id
										previous_other_gdu_id = other_gdu_id
										previous_tectonic_motion = tectonic_motion
										current_dominant_neighbour = second_candidate_ft.get_name()
										#update the state of valid 
										previous_valid_candidate = is_valid_candidate
										#update previous tectonic ft = 
										previous_candidate_tectonic_ft = second_candidate_ft
										previous_main_tectonic_ft = temp_main_tectonic_bdn_ft
					row_1 = cur_1.fetchone()
				
				#double check to see whether the previous record has been recorded properly
				txt_4  = """SELECT * FROM test_final_summary_of_tectonic_boundaries_and_motion 
							WHERE from_time = {input_from_time}
							AND to_time = {input_to_time}
							AND tectonic_motion = '{input_tectonic_motion}'
							AND line_1_ft_name = '{input_line_1_ft_name}'
							AND line_2_ft_name = '{input_line_2_ft_name}'
							AND ref_gdu_id = {input_ref_gdu_id}
							AND other_gdu_id = {input_other_gdu_id}"""
				sql_4 = txt_4.format(input_from_time = previous_from_time, input_to_time = previous_to_time, input_tectonic_motion = previous_tectonic_motion, input_line_1_ft_name = current_line_ft_name, input_line_2_ft_name = current_dominant_neighbour, input_ref_gdu_id = previous_ref_gdu_id, input_other_gdu_id = previous_other_gdu_id)
				cur_4.execute(sql_4)
				row_4 = cur_4.fetchone()
				if (row_4 is None):
					if (previous_from_time > -1 and previous_to_time > -1 and previous_tectonic_motion is not None):
						sql_3 = """INSERT INTO test_final_summary_of_tectonic_boundaries_and_motion (from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s,%s,%s,%s,%s,%s,%s) """
						cur_3.execute(sql_3,(previous_from_time,previous_to_time,previous_tectonic_motion,current_line_ft_name,current_dominant_neighbour,previous_ref_gdu_id,previous_other_gdu_id))
						list_of_already_processed.append(current_dominant_neighbour)
			conn.commit()
			row = cur.fetchone()
	except (psycopg2.DatabaseError) as error:
		print("Error realted to the database use_azimuth_direction_to_find_the_closest_neighbour")
		print(error)

def use_azimuth_direction_to_find_the_closest_neighbour_for_new_candiates(rotation_model,CON_OCN_line_feats,reference):
	sql = """SELECT DISTINCT line_1_ft_name
				FROM test_new_candidates_tectonic_boundaries_and_motion
				UNION
			   SELECT DISTINCT line_2_ft_name
			   FROM test_new_candidates_tectonic_boundaries_and_motion"""
	cur = None
	cur_1 = None
	cur_2 = None
	cur_3 = None
	cur_4 = None
	cur_5 = None
	cur_6 = None
	cur_9 = None
	cur_10 = None
	cur_11 = None
	cur_12 = None
	cur_13 = None
	list_of_already_processed = []
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		cur_5 = conn.cursor()
		cur_6 = conn.cursor()
		cur_9 = conn.cursor()
		cur_10 = conn.cursor()
		cur_11 = conn.cursor()
		cur_12 = conn.cursor()
		cur_13 = conn.cursor()
		output_dic = {}
		cur.execute(sql)
		row = cur.fetchone()
		while(row is not None):
			print('row',row)
			current_line_ft_name = row[0]
			continue_to_process_line_ft = False
			upper_limit_for_from_time_for_line_ft = -1.00
			if (current_line_ft_name not in list_of_already_processed):
				continue_to_process_line_ft = True
			else:
				txt_5  = """SELECT from_time,to_time FROM test_final_summary_of_tectonic_boundaries_and_motion 
							WHERE (line_1_ft_name = '{input_line_ft_name}'
							OR line_2_ft_name = '{input_line_ft_name}')
							ORDER BY to_time ASC"""
				sql_5 = txt_5.format(input_line_ft_name = current_line_ft_name)
				cur_5.execute(sql_5)
				row_5 = cur_5.fetchone()
				if (row_5 is not None):
					smallest_to_time = float(row_5[1])
					txt_6 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_new_candidates_tectonic_boundaries_and_motion
						   WHERE from_time <= {input_time}
						   AND (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}')
						   ORDER BY from_time DESC """
					sql_6 = txt_6.format(input_time = smallest_to_time , input_line_ft_name = current_line_ft_name)
					cur_6.execute(sql_6)
					row_6 = cur_6.fetchone()
					if (row_6 is not None):
						upper_limit_for_from_time_for_line_ft = smallest_to_time
						continue_to_process_line_ft = True
			if (continue_to_process_line_ft == True):
				list_of_already_processed.append(current_line_ft_name)
				txt_2 = """SELECT from_time, to_time, gdu_id, lef_gdu_id, right_gdu_id
							   FROM tectonic_topological_line_fts
							   WHERE type_of_line_fts = 'CON_OCN' AND (initial_ft_id = '{input_line_ft_name}' or name = '{input_line_ft_name}')"""
				sql_2 = txt_2.format(input_line_ft_name = current_line_ft_name)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				print(sql_2)
				CON_OCN_from_time = float(row_2[0])
				CON_OCN_to_time = float(row_2[1])
				gdu_id_of_line_ft = int(row_2[2])
				left_gdu_id_of_line_ft = int(row_2[3])
				right_gdu_id_of_line_ft = int(row_2[4])
				txt_1 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_new_candidates_tectonic_boundaries_and_motion
						   WHERE from_time <= {input_CON_OCN_from_time} AND to_time >= {input_CON_OCN_to_time} 
						   AND (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}')
						   ORDER BY from_time DESC"""
				if (upper_limit_for_from_time_for_line_ft == -1.00):
					sql_1 = txt_1.format(input_CON_OCN_from_time = CON_OCN_from_time, input_CON_OCN_to_time = CON_OCN_to_time,input_line_ft_name = current_line_ft_name)
					cur_1.execute(sql_1)
				elif (upper_limit_for_from_time_for_line_ft > -1.00):
					sql_1 = txt_1.format(input_CON_OCN_from_time = upper_limit_for_from_time_for_line_ft, input_CON_OCN_to_time = CON_OCN_to_time,input_line_ft_name = current_line_ft_name)
					cur_1.execute(sql_1)
				row_1 = cur_1.fetchone()
				current_dominant_neighbour = None
				previous_from_time = -1.00
				previous_to_time = -1.00
				previous_ref_gdu_id = -1.00
				previous_other_gdu_id = -1.00
				previous_tectonic_motion = None
				main_tectonic_bdn_ft = None
				substitute_candidate_line_fts = []
				substitute_main_line_fts = []
				previous_valid_candidate = False
				previous_candidate_tectonic_ft = None
				previous_main_tectonic_ft = None
				is_valid_candidate = False
				while (row_1 is not None):
					print("row_1",row_1)
					substitute_candidate_line_fts[:] = []
					ref_gdu_id = int(row_1[0])
					other_gdu_id = int(row_1[1])
					line_1_ft_name = row_1[2] 
					line_2_ft_name = row_1[3]
					other_line_ft_name = None
					if (line_1_ft_name == current_line_ft_name):
						other_line_ft_name = line_2_ft_name
					else:
						other_line_ft_name = line_1_ft_name
					from_time = float(row_1[4])
					to_time = float(row_1[5])
					tectonic_motion = row_1[6]
					other_line_ft_name = None
					if (line_1_ft_name == current_line_ft_name):
						other_line_ft_name = line_2_ft_name
					else:
						other_line_ft_name = line_1_ft_name
					from_time = float(row_1[4])
					to_time = float(row_1[5])
					txt_13 = """SELECT from_time,to_time FROM test_final_summary_of_tectonic_boundaries_and_motion 
							WHERE (line_1_ft_name = '{input_other_line_ft_name}'
									OR line_2_ft_name = '{input_other_line_ft_name}')
							AND (NOT((to_time > {input_from_time}) OR (from_time < {input_to_time}))) """
					sql_13 = txt_13.format(input_other_line_ft_name = other_line_ft_name, input_from_time = from_time, input_to_time = to_time)
					cur_13.execute(sql_13)
					row_13 = cur_13.fetchone()
					while ((row_13 is not None) and (row_1 is not None)):
						row_1 = cur_1.fetchone()
						if (row_1 is not None):
							ref_gdu_id = int(row_1[0])
							other_gdu_id = int(row_1[1])
							line_1_ft_name = row_1[2] 
							line_2_ft_name = row_1[3]
							tectonic_motion = row_1[6]
							other_line_ft_name = None
							if (line_1_ft_name == current_line_ft_name):
								other_line_ft_name = line_2_ft_name
							else:
								other_line_ft_name = line_1_ft_name
							from_time = float(row_1[4])
							to_time = float(row_1[5])
							sql_13 = txt_13.format(input_other_line_ft_name = other_line_ft_name, input_from_time = from_time, input_to_time = to_time)
							cur_13.execute(sql_13)
							row_13 = cur_13.fetchone()
					if (row_1 is None):
						break
						
					temp_at_age = -1.00
					if (previous_candidate_tectonic_ft is not None):
						if (from_time == previous_from_time):
							temp_at_age = float(from_time)
						elif (previous_to_time >= from_time):
							temp_at_age = float(from_time) 
						else:
							list_of_time = [previous_from_time,previous_to_time,from_time,to_time]
							list_of_time.sort(reverse = True) #descending order
							#choose the second element
							temp_at_age = float(list_of_time[1])
					else:
						temp_at_age = float(from_time + to_time)/2.00
					txt_12 = """SELECT from_time, to_time, gdu_id, lef_gdu_id, right_gdu_id
							   FROM tectonic_topological_line_fts
							   WHERE type_of_line_fts = 'CON_OCN' 
							   AND (initial_ft_id = '{input_line_ft_name}' or name = '{input_line_ft_name}')
							   AND from_time >= {input_tectonic_from_time} AND to_time <= {input_tectonic_to_time}
							   INTERSECT
							   SELECT from_time, to_time, gdu_id, lef_gdu_id, right_gdu_id
							   FROM tectonic_topological_line_fts
							   WHERE type_of_line_fts = 'CON_OCN' 
							   AND (initial_ft_id = '{input_line_ft_name}' or name = '{input_line_ft_name}')
							   AND from_time >= {input_temp_age} AND to_time <= {input_temp_age}"""
					sql_12 = txt_12.format(input_line_ft_name = other_line_ft_name, input_tectonic_from_time = from_time, input_tectonic_to_time = to_time, input_temp_age = temp_at_age)
					cur_12.execute(sql_12)
					row_12 = cur_12.fetchone()
					txt_9 = """SELECT * FROM test_summary_of_tectonic_motion
						   WHERE (ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id})
							AND (from_time = {input_from_time} and to_time = {input_to_time})
							AND validity = 'Invalid'"""
					sql_9 =	 txt_9.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
					cur_9.execute(sql_9)
					row_9 = cur_9.fetchone()
					while ((row_9 is not None) or (row_12 is None)):
						row_1 = cur_1.fetchone()
						if (row_1 is not None):
							ref_gdu_id = int(row_1[0])
							other_gdu_id = int(row_1[1])
							line_1_ft_name = row_1[2] 
							line_2_ft_name = row_1[3]
							from_time = float(row_1[4])
							to_time = float(row_1[5])
							tectonic_motion = row_1[6]
							sql_9 =	 txt_9.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time)
							cur_9.execute(sql_9)
							row_9 = cur_9.fetchone()
						else:
							break
					if (row_1 is None):
						break
					
					
					
					if (previous_candidate_tectonic_ft is not None):
						if (from_time == previous_from_time):
							temp_at_age = float(from_time)
						elif (previous_to_time >= from_time):
							temp_at_age = float(from_time) 
						else:
							list_of_time = [previous_from_time,previous_to_time,from_time,to_time]
							list_of_time.sort(reverse = True) #descending order
							#choose the second element
							temp_at_age = float(list_of_time[1])
					else:
						temp_at_age = float(from_time + to_time)/2.00
					print("temp_at_age",temp_at_age)
					temp_main_tectonic_bdn_ft = None
					temp_other_tectonic_bdn_ft = None
					#looking for temp_main_tectonic_bdn_ft
					if (previous_main_tectonic_ft is not None):
						temp_main_tectonic_bdn_ft = previous_main_tectonic_ft
					else:
						if (line_1_ft_name == current_line_ft_name):
							for bdn_ft in CON_OCN_line_feats:
								if (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
									temp_main_tectonic_bdn_ft = bdn_ft
								if (temp_main_tectonic_bdn_ft is not None):
									break
						elif (line_2_ft_name == current_line_ft_name):
							for bdn_ft in CON_OCN_line_feats:
								if (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
									temp_main_tectonic_bdn_ft = bdn_ft
								if (temp_main_tectonic_bdn_ft is not None):
									break
					#looking for temp_other_tectonic_bdn_ft
					if (line_1_ft_name == current_line_ft_name):
						for bdn_ft in CON_OCN_line_feats:
							if (bdn_ft.get_name() == line_2_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
								temp_other_tectonic_bdn_ft = bdn_ft
								if (temp_other_tectonic_bdn_ft is not None):
									break
					elif (line_2_ft_name == current_line_ft_name):
						for bdn_ft in CON_OCN_line_feats:
							if (bdn_ft.get_name() == line_1_ft_name and bdn_ft.is_valid_at_time(temp_at_age)):
								temp_other_tectonic_bdn_ft = bdn_ft
								if (temp_other_tectonic_bdn_ft is not None):
									break
					print("temp_main_tectonic_bdn_ft",temp_main_tectonic_bdn_ft)
					print("temp_other_tectonic_bdn_ft",temp_other_tectonic_bdn_ft)
					#reset valid_candidate for the new candidate
					is_valid_candidate = False
					if (temp_main_tectonic_bdn_ft is not None and temp_other_tectonic_bdn_ft is not None):
						is_valid_candidate = True
					else:
						print("Error in use_azimuth_direction_to_find_the_closest_neighbour_for_new_candiates")
						print("temp_main_tectonic_bdn_ft",temp_main_tectonic_bdn_ft)
						print("temp_other_tectonic_bdn_ft",temp_other_tectonic_bdn_ft)
						print("temp_at_age",temp_at_age)
						exit()
					if (previous_from_time == -1.00 and previous_to_time == -1.00 and is_valid_candidate == True):
						if (row_9 is None):
							
							if (line_1_ft_name == current_line_ft_name):
								current_dominant_neighbour = line_2_ft_name
							else:
								current_dominant_neighbour = line_1_ft_name
							previous_from_time = from_time
							previous_to_time = to_time
							previous_ref_gdu_id = ref_gdu_id
							previous_other_gdu_id = other_gdu_id
							previous_tectonic_motion = tectonic_motion
							#update the state of valid 
							previous_valid_candidate = is_valid_candidate
							previous_candidate_tectonic_ft = temp_other_tectonic_bdn_ft
							previous_main_tectonic_ft = temp_main_tectonic_bdn_ft
					elif (previous_candidate_tectonic_ft is not None and previous_main_tectonic_ft is not None):
						if ((previous_from_time == from_time) and (previous_to_time == to_time) and ((current_dominant_neighbour == line_1_ft_name) or (current_dominant_neighbour == line_2_ft_name))):
							if (from_time - to_time <= 1.00):
								if ((previous_tectonic_motion == 'Transform') and (tectonic_motion == 'Convergence' or tectonic_motion == 'Divergence')):
									previous_tectonic_motion = 'Transform'
								elif ((tectonic_motion == 'Transform') and (previous_tectonic_motion == 'Convergence' or previous_tectonic_motion == 'Divergence')):
									previous_tectonic_motion = 'Transform'
								elif (previous_tectonic_motion == 'Unknown_same_motion' and tectonic_motion != 'Unknown_same_motion'):
									previous_tectonic_motion = tectonic_motion
								elif (tectonic_motion == 'Unknown_same_motion' and previous_tectonic_motion != 'Unknown_same_motion'):
									previous_tectonic_motion = previous_tectonic_motion
						elif ((previous_to_time >= from_time) and (previous_valid_candidate == True)): #because we order records by from_time so we don't need to worry about previous_from_time < to_time
							#insert the previous_record to the finally summary database table
							#final_summary_of_tectonic_boundaries_and_motion
							sql_3 = """INSERT INTO test_final_summary_of_tectonic_boundaries_and_motion (from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s,%s,%s,%s,%s,%s,%s) """
							cur_3.execute(sql_3,(previous_from_time,previous_to_time,previous_tectonic_motion,current_line_ft_name,current_dominant_neighbour,previous_ref_gdu_id,previous_other_gdu_id))
							list_of_already_processed.append(current_dominant_neighbour)
							if (is_valid_candidate == True):
								if (line_1_ft_name == current_line_ft_name):
									current_dominant_neighbour = line_2_ft_name
								else:
									current_dominant_neighbour = line_1_ft_name
								previous_from_time = from_time
								previous_to_time = to_time
								previous_ref_gdu_id = ref_gdu_id
								previous_other_gdu_id = other_gdu_id
								previous_tectonic_motion = tectonic_motion
								#update the state of valid 
								previous_valid_candidate = is_valid_candidate
								previous_candidate_tectonic_ft = temp_other_tectonic_bdn_ft
								previous_main_tectonic_ft = temp_main_tectonic_bdn_ft
							else:
								current_dominant_neighbour = None
								previous_from_time = -1.00
								previous_to_time = -1.00
								previous_ref_gdu_id = -1.00
								previous_other_gdu_id = -1.00
								previous_tectonic_motion = None
								main_tectonic_bdn_ft = None
								substitute_candidate_line_fts[:] = []
								substitute_main_line_fts[:] = []
								previous_valid_candidate = False
								previous_candidate_tectonic_ft = None
								previous_main_tectonic_ft = None
						elif (is_valid_candidate == True):
							reconstructed_other_tectonic_bdn_fts = []
							reconstructed_main_tectonic_bdn_fts = []
							other_tectonic_bdn_fts = []
							at_age = temp_at_age
							main_tectonic_bdn_ft = temp_main_tectonic_bdn_ft

							found_current_dominant_neighour_ft = None
							found_new_neighbour_ft = temp_other_tectonic_bdn_ft
							if (previous_candidate_tectonic_ft is not None):
								if (previous_candidate_tectonic_ft.is_valid_at_time(at_age)):
									found_current_dominant_neighour_ft = previous_candidate_tectonic_ft
								else:
									if (line_1_ft_name == current_line_ft_name):
										for bdn_ft in CON_OCN_line_feats:
											if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
												if ((bdn_ft.get_left_plate() == previous_ref_gdu_id and bdn_ft.get_right_plate() == previous_other_gdu_id) or (bdn_ft.get_left_plate() == previous_other_gdu_id and bdn_ft.get_right_plate() == previous_ref_gdu_id)):
													found_current_dominant_neighour_ft = bdn_ft
									elif (line_2_ft_name == current_line_ft_name):
										for bdn_ft in CON_OCN_line_feats:
											if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
												if ((bdn_ft.get_left_plate() == previous_ref_gdu_id and bdn_ft.get_right_plate() == previous_other_gdu_id) or (bdn_ft.get_left_plate() == previous_other_gdu_id and bdn_ft.get_right_plate() == previous_ref_gdu_id)):
													found_current_dominant_neighour_ft = bdn_ft
							
							if (found_current_dominant_neighour_ft is not None):
								other_tectonic_bdn_fts.append(found_current_dominant_neighour_ft)
								print('found_current_dominant_neighour_ft',found_current_dominant_neighour_ft.get_name())
							else:
								for bdn_ft in CON_OCN_line_feats:
									if (bdn_ft.get_name() == current_dominant_neighbour and bdn_ft.is_valid_at_time(at_age)):
										found_current_dominant_neighour_ft = bdn_ft
										other_tectonic_bdn_fts.append(bdn_ft)
										break
							if (found_new_neighbour_ft is not None):
								other_tectonic_bdn_fts.append(found_new_neighbour_ft)
								print('found_new_neighbour_ft',found_new_neighbour_ft.get_name())
							print('len(other_tectonic_bdn_fts)',len(other_tectonic_bdn_fts))
							print('line_1_ft_name',line_1_ft_name,'line_2_ft_name',line_2_ft_name)
							print('current_dominant_neighbour',current_dominant_neighbour)
							print('current_line_ft_name',current_line_ft_name)

							#reconstruct all tectonic bdn fts to at_age
							print("at_age",at_age)
							print("previous_from_time,previous_to_time,from_time,to_time",previous_from_time,previous_to_time,from_time,to_time)
							#print("main_tectonic_bdn_ft.get_valid_time()",main_tectonic_bdn_ft.get_valid_time())
							#print(main_tectonic_bdn_ft.get_name())
							if (main_tectonic_bdn_ft is not None and len(other_tectonic_bdn_fts) >= 2):#first check
								print("found_current_dominant_neighour_ft",found_current_dominant_neighour_ft)
								print("found_new_neighbour_ft",found_new_neighbour_ft)
								if (found_current_dominant_neighour_ft.get_name() == found_new_neighbour_ft.get_name() == current_dominant_neighbour):
									#keep previous_from_time because we already performed a query by from_time ORDER BY DESC
									#only update previous_to_time,if it is required
									if (to_time < previous_to_time):
										previous_to_time = to_time
									other_tectonic_bdn_fts[:] = []
							if (main_tectonic_bdn_ft is not None and len(other_tectonic_bdn_fts) >= 2):#second check
								# for bdn_ft in messy_tectonic_boundaries_features:
									# if (bdn_ft.get_name() == current_line_ft_name and bdn_ft.is_valid_at_time(at_age)):
										# main_tectonic_bdn_ft = bdn_ft.clone()
										# # print(bdn_ft.get_valid_time())
										# # print(bdn_ft.get_feature_type())
								# # exit()
								# print(main_tectonic_bdn_ft.get_left_plate(),main_tectonic_bdn_ft.get_right_plate())
								print("len(other_tectonic_bdn_fts)",len(other_tectonic_bdn_fts))
								for other_bdn_ft in other_tectonic_bdn_fts:
									print("other_bdn_ft.get_name",other_bdn_ft.get_name())
									# print("other_bdn_ft.get_feature_type",other_bdn_ft.get_feature_type())
									print("other_bdn_ft.get_valid_time",other_bdn_ft.get_valid_time())
									for geom in other_bdn_ft.get_geometries():
										print(geom.to_lat_lon_list())
									# print("other_bdn_ft.get_left_plate,right_plate",other_bdn_ft.get_left_plate(),other_bdn_ft.get_right_plate())
								#print("rotation_model",other_tectonic_bdn_fts)
								if (reference is not None):
									pygplates.reconstruct(other_tectonic_bdn_fts,rotation_model,reconstructed_other_tectonic_bdn_fts,float(at_age),anchor_plate_id = reference, group_with_feature = True)
									pygplates.reconstruct(main_tectonic_bdn_ft,rotation_model,reconstructed_main_tectonic_bdn_fts,float(at_age),anchor_plate_id = reference, group_with_feature = True)
								else:
									pygplates.reconstruct(other_tectonic_bdn_fts,rotation_model,reconstructed_other_tectonic_bdn_fts,float(at_age),group_with_feature = True)
									pygplates.reconstruct(main_tectonic_bdn_ft,rotation_model,reconstructed_main_tectonic_bdn_fts,float(at_age),group_with_feature = True)
								final_reconstructed_other_tectonic_bdn_fts = supporting.find_final_reconstructed_geometries(reconstructed_other_tectonic_bdn_fts,pygplates.PolylineOnSphere) 
								final_reconstructed_main_tectonic_bdn_ft = supporting.find_final_reconstructed_geometries(reconstructed_main_tectonic_bdn_fts,pygplates.PolylineOnSphere)
								reconstr_main_bdn_ft,reconstr_main_bdn = final_reconstructed_main_tectonic_bdn_ft[0]
								main_centroid = reconstr_main_bdn.get_centroid()
								first_candidate_ft,first_candidate_bdn = final_reconstructed_other_tectonic_bdn_fts[0]
								second_candidate_ft,second_candidate_bdn = final_reconstructed_other_tectonic_bdn_fts[1]
								# first_point_of_main_line = reconstr_main_bdn[0]
								# end_point_of_main_line = reconstr_main_bdn[-1]
								# great_circle_arc = pygplates.GreatCircleArc(first_point_of_main_line,end_point_of_main_line)
								# normal_unit_vector = great_circle_arc.get_great_circle_normal()
								# great_circle_arc_for_first_candidate = pygplates.GreatCircleArc(first_candidate_bdn[0],first_candidate_bdn[-1])
								# normal_unit_vector_for_first_candidate = great_circle_arc_for_first_candidate.get_great_circle_normal()
								# great_circle_arc_for_second_candidate = pygplates.GreatCircleArc(second_candidate_bdn[0],second_candidate_bdn[-1])
								# normal_unit_vector_for_second_candidate = great_circle_arc_for_second_candidate.get_great_circle_normal()
								distance_1 = pygplates.GeometryOnSphere.distance(main_centroid,first_candidate_bdn.get_centroid())
								distance_2 = pygplates.GeometryOnSphere.distance(main_centroid,second_candidate_bdn.get_centroid())
								if (distance_1 < distance_2):
									if ( first_candidate_ft.get_name() != current_dominant_neighbour):
										previous_from_time = from_time
										previous_to_time = to_time
										previous_ref_gdu_id = ref_gdu_id
										previous_other_gdu_id = other_gdu_id
										previous_tectonic_motion = tectonic_motion
										current_dominant_neighbour = first_candidate_ft.get_name()
										#update the state of valid 
										previous_valid_candidate = is_valid_candidate
										#update previous tectonic ft = 
										previous_candidate_tectonic_ft = first_candidate_ft
										previous_main_tectonic_ft = temp_main_tectonic_bdn_ft
								else:
									if (second_candidate_ft.get_name() != current_dominant_neighbour):
										previous_from_time = from_time
										previous_to_time = to_time
										previous_ref_gdu_id = ref_gdu_id
										previous_other_gdu_id = other_gdu_id
										previous_tectonic_motion = tectonic_motion
										current_dominant_neighbour = second_candidate_ft.get_name()
										#update the state of valid 
										previous_valid_candidate = is_valid_candidate
										#update previous tectonic ft = 
										previous_candidate_tectonic_ft = second_candidate_ft
										previous_main_tectonic_ft = temp_main_tectonic_bdn_ft
					row_1 = cur_1.fetchone()
				
				#double check to see whether the previous record has been recorded properly
				txt_4  = """SELECT * FROM test_final_summary_of_tectonic_boundaries_and_motion 
							WHERE from_time = {input_from_time}
							AND to_time = {input_to_time}
							AND tectonic_motion = '{input_tectonic_motion}'
							AND line_1_ft_name = '{input_line_1_ft_name}'
							AND line_2_ft_name = '{input_line_2_ft_name}'
							AND ref_gdu_id = {input_ref_gdu_id}
							AND other_gdu_id = {input_other_gdu_id}"""
				sql_4 = txt_4.format(input_from_time = previous_from_time, input_to_time = previous_to_time, input_tectonic_motion = previous_tectonic_motion, input_line_1_ft_name = current_line_ft_name, input_line_2_ft_name = current_dominant_neighbour, input_ref_gdu_id = previous_ref_gdu_id, input_other_gdu_id = previous_other_gdu_id)
				cur_4.execute(sql_4)
				row_4 = cur_4.fetchone()
				if (row_4 is None):
					if (previous_from_time > -1 and previous_to_time > -1 and previous_tectonic_motion is not None):
						sql_3 = """INSERT INTO test_final_summary_of_tectonic_boundaries_and_motion (from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s,%s,%s,%s,%s,%s,%s) """
						cur_3.execute(sql_3,(previous_from_time,previous_to_time,previous_tectonic_motion,current_line_ft_name,current_dominant_neighbour,previous_ref_gdu_id,previous_other_gdu_id))
						list_of_already_processed.append(current_dominant_neighbour)
			conn.commit()
			row = cur.fetchone()
	except (psycopg2.DatabaseError) as error:
		print("Error realted to the database use_azimuth_direction_to_find_the_closest_neighbour")
		print(error)

def create_tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion(messy_tectonic_boundaries_features,modelname,yearmonthday):
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	sql_1 = """SELECT line_1_ft_name, line_2_ft_name, tectonic_motion, ref_gdu_id, other_gdu_id, from_time, to_time FROM test_final_summary_of_tectonic_boundaries_and_motion"""
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur_1.execute(sql_1)
		row_1 = cur_1.fetchone()
		while (row_1 is not None):
			line_1_ft_name = row_1[0]
			line_2_ft_name = row_1[1]
			tectonic_motion = row_1[2]
			ref_gdu_id = row_1[3]
			other_gdu_id = row_1[4]
			from_time = float(row_1[5])
			to_time = float(row_1[6])
			at_age = (from_time + to_time)/2.00
			all_line_fts_1 = messy_tectonic_boundaries_features.get(lambda ft: ft.get_name() == line_1_ft_name and ft.is_valid_at_time(at_age), pygplates.FeatureReturn.all)
			all_line_fts_2 = messy_tectonic_boundaries_features.get(lambda ft: ft.get_name() == line_2_ft_name and ft.is_valid_at_time(at_age), pygplates.FeatureReturn.all)
			final_line_ft_1,final_line_ft_2 = None,None
			for candidate_ft in all_line_fts_1:
				if (tectonic_motion == "Divergence" or tectonic_motion == "Unknown_same_motion"):
					if (candidate_ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
						if ((candidate_ft.get_left_plate() == ref_gdu_id and candidate_ft.get_right_plate() == other_gdu_id) or (candidate_ft.get_left_plate() == other_gdu_id and candidate_ft.get_right_plate() == ref_gdu_id)):
							output_plate_tectonic_margin_fts.add(candidate_ft)
				elif (tectonic_motion == "Transform"):
					if (candidate_ft.get_feature_type() == pygplates.FeatureType.gpml_transform):
						if ((candidate_ft.get_left_plate() == ref_gdu_id and candidate_ft.get_right_plate() == other_gdu_id) or (candidate_ft.get_left_plate() == other_gdu_id and candidate_ft.get_right_plate() == ref_gdu_id)):
							output_plate_tectonic_margin_fts.add(candidate_ft)
				elif (tectonic_motion == "Convergence"):
					if (candidate_ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone):
						if ((candidate_ft.get_left_plate() == ref_gdu_id and candidate_ft.get_right_plate() == other_gdu_id) or (candidate_ft.get_left_plate() == other_gdu_id and candidate_ft.get_right_plate() == ref_gdu_id)):
							output_plate_tectonic_margin_fts.add(candidate_ft)
			for candidate_ft in all_line_fts_2:
				if (tectonic_motion == "Divergence" or tectonic_motion == "Unknown_same_motion"):
					if (candidate_ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
						if ((candidate_ft.get_left_plate() == ref_gdu_id and candidate_ft.get_right_plate() == other_gdu_id) or (candidate_ft.get_left_plate() == other_gdu_id and candidate_ft.get_right_plate() == ref_gdu_id)):
							output_plate_tectonic_margin_fts.add(candidate_ft)
				elif (tectonic_motion == "Transform"):
					if (candidate_ft.get_feature_type() == pygplates.FeatureType.gpml_transform):
						if ((candidate_ft.get_left_plate() == ref_gdu_id and candidate_ft.get_right_plate() == other_gdu_id) or (candidate_ft.get_left_plate() == other_gdu_id and candidate_ft.get_right_plate() == ref_gdu_id)):
							output_plate_tectonic_margin_fts.add(candidate_ft)
				elif (tectonic_motion == "Convergence"):
					if (candidate_ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone):
						if ((candidate_ft.get_left_plate() == ref_gdu_id and candidate_ft.get_right_plate() == other_gdu_id) or (candidate_ft.get_left_plate() == other_gdu_id and candidate_ft.get_right_plate() == ref_gdu_id)):
							output_plate_tectonic_margin_fts.add(candidate_ft)
			
			row_1 = cur_1.fetchone()
	except (psycopg2.DatabaseError) as error:
		print("Error in create_tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion")
		print(error)
	
	
	output_plate_tectonic_margin_fts.write("tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion_"+modelname+"_"+yearmonthday+".gpml")
	output_plate_tectonic_margin_fts.write("tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion_"+modelname+"_"+yearmonthday+".shp")
	
	
def create_tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion_2(initial_CON_OCN_geological_topological_line_feature,modelname,yearmonthday):	 
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	sql_1 = """SELECT line_1_ft_name, line_2_ft_name, tectonic_motion, ref_gdu_id, other_gdu_id, from_time, to_time FROM test_final_summary_of_tectonic_boundaries_and_motion"""
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur_1.execute(sql_1)
		row_1 = cur_1.fetchone()
		all_line_ft_1 = []
		all_line_ft_2 = []
		list_of_warning_records = []
		while (row_1 is not None):
			line_1_ft_name = row_1[0]
			line_2_ft_name = row_1[1]
			#print('line_1_ft_name',line_1_ft_name)
			#print('line_2_ft_name',line_2_ft_name)
			tectonic_motion = row_1[2]
			ref_gdu_id = row_1[3]
			other_gdu_id = row_1[4]
			from_time = float(row_1[5])
			to_time = float(row_1[6])
			at_age = (from_time + to_time)/2.00
			print(at_age)
			#all_line_ft_1 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_name() == line_1_ft_name or ft.get_feature_id().get_string() == line_1_ft_name, pygplates.FeatureReturn.all)
			all_line_ft_1[:] = []
			print('line_1_ft_name',line_1_ft_name)
			for bdn_ft in initial_CON_OCN_geological_topological_line_feature:
				if (bdn_ft.get_name() == line_1_ft_name or bdn_ft.get_feature_id().get_string() == line_1_ft_name):
					all_line_ft_1.append(bdn_ft)
			final_line_ft_1 = None
			for potential_line_ft_1 in all_line_ft_1:
				if (potential_line_ft_1.is_valid_at_time(at_age)):
					final_line_ft_1 = potential_line_ft_1
					break
			all_line_ft_2[:] = []
			#all_line_ft_2 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_name() == line_2_ft_name or ft.get_feature_id().get_string() == line_2_ft_name, pygplates.FeatureReturn.all)
			print('line_2_ft_name',line_2_ft_name)
			for bdn_ft in initial_CON_OCN_geological_topological_line_feature:
				if (bdn_ft.get_name() == line_2_ft_name or bdn_ft.get_feature_id().get_string() == line_2_ft_name):
					all_line_ft_2.append(bdn_ft)
			final_line_ft_2 = None 
			for potential_line_ft_2 in all_line_ft_2:
				if (potential_line_ft_2.is_valid_at_time(at_age)):
					final_line_ft_2 = potential_line_ft_2
					break
			if (final_line_ft_1 is not None and final_line_ft_2 is not None):
				#I have no idea why and how there are multiple geometries for the line ft.
				#Since it is possible for a ft to have a multiple geometry for a line ft, take the line has the longest length (approx in rads)
				line_1,line_2 = None,None
				len_of_current_geom = -1.0
				for geom in final_line_ft_1.get_geometries():
					if (geom.get_arc_length() > len_of_current_geom):
						len_of_current_geom = geom.get_arc_length()
						line_1 = geom
				len_of_current_geom = -1.0
				for geom in final_line_ft_2.get_geometries():
					if (geom.get_arc_length() > len_of_current_geom):
						len_of_current_geom = geom.get_arc_length()
						line_2 = geom
				if (tectonic_motion == "Convergence"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_1, name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
					plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
					
					
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_2, name = line_2_ft_name, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
					plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
				elif (tectonic_motion == "Divergence"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = line_1_ft_name, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
					plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
					
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = line_2_ft_name, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
					plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
				elif (tectonic_motion == "Transform"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_1, name = line_1_ft_name, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
					plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
					
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_2, name = line_2_ft_name, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
					plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
				elif (tectonic_motion == 'Unknown_same_motion'):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = line_1_ft_name, description = "unknown_same_motion", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
					plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
					
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = line_2_ft_name, description = "unknown_same_motion", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
					plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
			else:
				print("Warning in create_tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion_2")
				print("Either final_line_ft_1 is None or final_line_ft_2 is None")
				print(final_line_ft_1, final_line_ft_2)
				print("row_1")
				print(row_1)
				print("all_line_1_fts",all_line_ft_1)
				print("all_line_2_fts",all_line_ft_2)
				list_of_warning_records.append((from_time,to_time,tectonic_motion,line_1_ft_name,line_2_ft_name,ref_gdu_id,other_gdu_id))
				#exit()
			row_1 = cur_1.fetchone()
		output_plate_tectonic_margin_fts.write("tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion_"+modelname+"_"+yearmonthday+".gpml")
		output_plate_tectonic_margin_fts.write("tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion_"+modelname+"_"+yearmonthday+".shp")
		new_dataframe = pd.DataFrame.from_records(list_of_warning_records, columns = ['from_time','to_time','tectonic_motion','line_1_ft_name','line_2_ft_name','ref_gdu_id','other_gdu_id'])
		print("new_dataframe")
		print(new_dataframe)
		new_dataframe.to_csv('warning_records_from_'+modelname+"_"+yearmonthday+".csv",index=False)
	except (psycopg2.DatabaseError) as error:
		print("Error in create_tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion")
		print(error)