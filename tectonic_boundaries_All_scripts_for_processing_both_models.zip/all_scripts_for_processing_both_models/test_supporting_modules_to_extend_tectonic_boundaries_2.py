import sys
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_extend_tectonic_boundaries_2 as supporting_extend

def main():
	CON_OCN_line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\utility\check_and_assign_ft_id_str_in_GPlates_format_to_ft_name_CON_OCN_line_features_PalaeoPlatesNov2021_20220224.gpml"
	CON_OCN_line_features = pygplates.FeatureCollection(CON_OCN_line_features_file)
	modelname = "test_1_PalaeoPlatesNov2021_350_0Ma_from_test_22_final_summary_of_tectonic_boundaries_and_motion"
	yearmonthday = '20220419'
	supporting_extend.extend_current_valid_and_recorded_tectonic_boundaries_from_table_final_summary_of_tectonic_boundaries_and_motion(CON_OCN_line_features, modelname, yearmonthday)

if __name__=="__main__":
	main()