import pygplates
import create_topological_isochron_and_estimate_MOR as topological

def main():
	# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# rift_point_features_records_csv = r"rift_point_features_records_for_test_21_short_PalaeoPlatesendJan2023_w_1_deg_20230713.csv"
	# div_margin_feats_file = r"diverging_line_features_for__3410.0_5.0_test_21_short_PalaeoPlatesendJan2023_w_1_deg_20230713.shp"
	# div_margin_features = pygplates.FeatureCollection(div_margin_feats_file)
	# rift_point_features_file = r"modified_end_age_of_rift_point_features_for_3420_0Ma_test_25_short_PalaeoPlatesendJan2023_w_1_deg_20230804.shp"
	# rift_point_features = pygplates.FeatureCollection(rift_point_features_file)
	# modelname = "isochron_test_26_PalaeoPlatesJan2023_fts_from_late_July"
	
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	rift_point_features_records_csv = r"rift_point_features_records_for_test_21_short_PalaeoPlatesendJan2023_w_1_deg_20230713.csv"
	div_margin_feats_file = r"diverging_line_features_for__3410.0_5.0_test_21_short_PalaeoPlatesendJan2023_w_1_deg_20230713.shp"
	div_margin_features = pygplates.FeatureCollection(div_margin_feats_file)
	rift_point_features_file = r"modified_end_age_of_rift_point_features_for_3420_0Ma_test_25_short_PalaeoPlatesendJan2023_w_1_deg_20230804.shp"
	rift_point_features = pygplates.FeatureCollection(rift_point_features_file)
	modelname = "isochron_test_26_PalaeoPlatesJan2023_fts_from_late_July"
	
	
	yearmonthday = "20230906"
	reference = 700
	
	final_maximum_reconstruction_time = 3410.00
	final_minimum_reconstruction_time = 0.00
	reconstruction_interval = 155.00
	max_min_rec_time_list = []
	value = final_maximum_reconstruction_time
	while (value > final_minimum_reconstruction_time):
		min_recon = value - reconstruction_interval
		max_min_rec_time_list.append((value,min_recon))
		value = min_recon
	
	for maximum_reconstruction_time,minimum_reconstruction_time in max_min_rec_time_list:
		print('maximum_reconstruction_time,minimum_reconstruction_time',maximum_reconstruction_time,minimum_reconstruction_time)
		common_input_point_features_filename = r"isochron_right_point_features_test_26_PalaeoPlatesJan2023_fts_from_late_July_max_{max_time}_{min_time}_20230802.shp"
		input_point_features_file = common_input_point_features_filename.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
		right_input_point_features = pygplates.FeatureCollection(input_point_features_file)
	
		common_input_point_features_filename = r"isochron_left_point_features_test_26_PalaeoPlatesJan2023_fts_from_late_July_max_{max_time}_{min_time}_20230802.shp"
		input_point_features_file = common_input_point_features_filename.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
		left_input_point_features = pygplates.FeatureCollection(input_point_features_file)
	
		age_interval_for_isochron_fts = 5.00
		topological.create_oceanic_crust_from_rift_and_isochron_point_features(div_margin_features, left_input_point_features, right_input_point_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday)

if __name__ == '__main__':
	main()