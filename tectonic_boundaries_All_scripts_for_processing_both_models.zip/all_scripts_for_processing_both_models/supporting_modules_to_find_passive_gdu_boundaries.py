import sys

#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
import supporting_modules_to_be_converted_2 as supporting_2
import psycopg2
from config_plate_tectonics import config

def find_unclassified_passive_boundaries_from_all_classified_line_fts_database_table(name_of_table_for_tectonic_motion_of_all_pairs_of_line_features, name_for_table_for_passive_boundaries, line_features_collection, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	txt = """SELECT * 
				FROM {input_name_of_table_for_tectonic_motion_of_all_pairs_of_line_features} 
				WHERE time = {input_time} AND (ref_ft_id = '{input_line_name}' or neighbour_ft_id = '{input_line_name}')"""
	txt_B = """INSERT INTO {input_name_for_table_for_passive_boundaries}(time, ref_ft_id, neighbour_ft_id, tectonic_motion) VALUES (%s, %s, %s, %s)"""
	already_processed = []
	conn = None
	cur = None
	cur_1 = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		reconstruction_time = begin_reconstruction_time
		cur = conn.cursor()
		cur_1 = conn.cursor()
		dic = {}
		reconstruction_time = begin_reconstruction_time
		while (reconstruction_time > (end_reconstruction_time - time_interval)):
			valid_line_features = [line_ft for line_ft in line_features_collection if line_ft.is_valid_at_time(reconstruction_time)]
			for CON_OCN_line_ft in valid_line_features:
				line_name = CON_OCN_line_ft.get_name()
				sql = txt.format(input_name_of_table_for_tectonic_motion_of_all_pairs_of_line_features = name_of_table_for_tectonic_motion_of_all_pairs_of_line_features, input_line_name = line_name, input_time = reconstruction_time)
				cur.execute(sql)
				row = cur.fetchone()
				if (row is None):
					sql_1 = txt_B.format(input_name_for_table_for_passive_boundaries = name_for_table_for_passive_boundaries)
					cur_1.execute(sql_1,(reconstruction_time,line_name,None,'Passive'))
			#commit changes to database
			conn.commit()
			#update reconstruction_time
			reconstruction_time = reconstruction_time - time_interval 
	except (psycopg2.DatabaseError) as error:
		print("Error in find_unclassified_passive_boundaries_from_all_classified_line_fts_database_table")
		print(error)