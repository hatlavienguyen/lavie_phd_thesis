#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import math
import pandas as pd
import numpy as np
import create_remnant_of_previous_MOR as create_remnant
def check_and_modify_end_age_of_rift_point_feats_based_on_conv_records():
	#the main rift point features
	modelname = "v3_test_29_PalaeoPlatesendJan2023_fts"
	#modelname = "test_2_additional_rift_with_sgdu_PalaeoPlatesendJan2023_fts_max_"
	#filename_for_temp_rift_point_features = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/utility/modified_end_age_additional_rift_point_features_2_PalaeoPlatesendJan2023_fts_2800_0_20240207.shp"
	filename_for_temp_rift_point_features = r"rift_point_features_for_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	temp_rift_point_features_for_interval = pygplates.FeatureCollection(filename_for_temp_rift_point_features)
	records_of_kin_line_feats_from_conv = r"pairs_of_kin_line_fts_from_conv_bdn_process_for_test_30_short_conv_PalaeoPlatesJan2023_20231023.csv"
	records_of_kin_line_feats_from_div = r"pairs_of_kin_line_fts_from_div_bdn_process_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	
	#the additional rift point features (from 2800Ma to 1800Ma)
	#modelname = "subseq_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023"
	#filename_for_temp_rift_point_features = r"subseq_rift_point_features_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.shp"
	#temp_rift_point_features_for_interval = pygplates.FeatureCollection(filename_for_temp_rift_point_features)
	#records_of_kin_line_feats_from_conv = None
	#records_of_kin_line_feats_from_div = r"pairs_of_kin_line_fts_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.csv"
	#rift_point_features_records_csv = r"subseq_rift_point_features_records_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.csv"
	
	#the additional rift point features (from 1800Ma to 120Ma)
	# modelname = "subseq_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023"
	# filename_for_temp_rift_point_features = r"subseq_rift_point_features_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.shp"
	# temp_rift_point_features_for_interval = pygplates.FeatureCollection(filename_for_temp_rift_point_features)
	# records_of_kin_line_feats_from_conv = None
	# records_of_kin_line_feats_from_div = r"pairs_of_kin_line_fts_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.csv"
	# rift_point_features_records_csv = r"subseq_rift_point_features_records_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.csv"
	
	#sgdu_features_file = r"/home/hon686/projects/def-bre255/hon686/Geology/Research/Fall2023/PalaeoPlates/superGDU/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	#sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	
	time_interval = 5.00
	
	maximum_reconstruction_time= 2800.00
	minimum_reconstruction_time= 0.00
	
	rotation_file = r"../T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	
	reference = 700
	yearmonthday = "20240407"
	
	create_remnant.modified_end_age_of_rift_point_features_based_on_kinematic_records(rift_point_features_records_csv,temp_rift_point_features_for_interval,records_of_kin_line_feats_from_conv,records_of_kin_line_feats_from_div,maximum_reconstruction_time,minimum_reconstruction_time,time_interval,modelname,yearmonthday)

def main():
	check_and_modify_end_age_of_rift_point_feats_based_on_conv_records()

if __name__=="__main__":
	main()