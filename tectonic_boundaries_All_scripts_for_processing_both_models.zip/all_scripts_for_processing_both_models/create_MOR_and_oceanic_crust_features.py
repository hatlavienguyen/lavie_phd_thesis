import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import os
import pandas as pd
import psycopg2
from config_plate_tectonics import config
import supporting_modules_to_be_converted as supporting
import supporting_topological_modules_for_MOR as supporting_MOR

def create_MOR_linear_features_from_temporal_MOR_location_features(name_of_table_for_summary_of_tectonic_motion, name_of_table_for_temporal_MOR_location_feats, name_of_table_for_recover_temporal_MOR_location_feats, name_of_table_for_summary_of_MOR_location_fts, max_begin_reconstruction_time, modelname, yearmonthday):
	try:
		params = config()
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		txt = """SELECT from_time, ref_ft_id, neighbour_ft_id FROM {input_name_of_table_for_summary_of_tectonic_motion} 
						WHERE (tectonic_motion = 'Divergence' OR tectonic_motion = 'Oblique_divergence') and from_time <= {input_time} ORDER BY from_time DESC """
		txt_1 = """SELECT mor.mor_ft_id, sum.from_time, sum.to_time, mor.first_supergdu_represent_id, mor.second_supergdu_represent_id, mor.at_angular_radius
					FROM {input_name_of_table_for_temporal_MOR_location_feats} mor
					INNER JOIN {input_name_of_table_for_summary_of_tectonic_motion} sum
					ON (((mor.first_line_name = sum.ref_ft_id AND mor.second_line_name = sum.neighbour_ft_id) 
						OR (mor.first_line_name = sum.neighbour_ft_id AND mor.second_line_name = sum.ref_ft_id))
						AND mor.time = sum.from_time)
					WHERE sum.ref_ft_id = '{input_ref_ft_id}' and sum.neighbour_ft_id = '{input_neighbour_ft_id}' and sum.from_time = {input_time}
					ORDER BY mor.at_angular_radius DESC"""
		txt_2 = """INSERT INTO {input_name_of_table_for_summary_of_MOR_location_fts} (parent_SuperGDUs,from_time,to_time,at_angular_radius,MOR_loc_ft_id) VALUES(%s, %s, %s, %s, %s)"""
		dic = {}
		temp_feature_collection = pygplates.FeatureCollection()
		sql = txt.format(input_name_of_table_for_summary_of_tectonic_motion = name_of_table_for_summary_of_tectonic_motion, input_time = max_begin_reconstruction_time)
		cur.execute(sql)
		row = cur.fetchone()
		while (row is not None):
			from_time = float(row[0])
			ref_ft_id = str(row[1])
			neighbour_ft_id = str(row[2])
			sql_1 = txt_1.format(input_name_of_table_for_temporal_MOR_location_feats = name_of_table_for_temporal_MOR_location_feats, input_name_of_table_for_summary_of_tectonic_motion = name_of_table_for_summary_of_tectonic_motion, input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id, input_time = from_time)
			cur_1.execute(sql_1)
			row_1 = cur_1.fetchone()
			while(row_1 is not None):
				name_of_temporal_MOR_locations_feats_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\MOR_location_features\MOR_location_features_from_"+str(from_time)+"_test_11_reversed_Nuna_PalaeoPlatesNov2021_20220619.shp"
				mor_ft_id = row_1[0]
				summary_from_time = float(row_1[1])
				summary_to_time = float(row_1[2])
				first_supergdu_represent_id = int(row_1[3])
				second_supergdu_represent_id = int(row_1[4])
				order = float(row_1[5])
				is_recovered = False
				if (os.path.exists(name_of_temporal_MOR_locations_feats_file) == False):
					name_of_temporal_MOR_locations_feats_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\MOR_location_features\MOR_location_features_from_"+str(from_time)+"_test_11_reversed_Rodinia_PalaeoPlatesNov2021_20220620.shp"
					if (os.path.exists(name_of_temporal_MOR_locations_feats_file) == False):
						name_of_temporal_MOR_locations_feats_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\recover_oceanic_crust_features\recover_MOR_location_features_from_"+str(from_time)+"_test_11_oceanic_crust_PalaeoPlatesNov2021_20220619.shp"
						is_recovered = True
				temp_location_feats = pygplates.FeatureCollection(name_of_temporal_MOR_locations_feats_file)
				wanted_mor_ft = None
				if (is_recovered == False):
					for location_ft in temp_location_feats:
						if (location_ft.get_feature_id().get_string() == mor_ft_id):
							wanted_mor_ft = location_ft
							break
				else:
					txt_3 = """SELECT mor.mor_ft_id
					FROM {input_name_of_table_for_temporal_MOR_location_feats} mor
					INNER JOIN {input_name_of_table_for_summary_of_tectonic_motion} sum
					ON (((mor.first_line_name = sum.ref_ft_id AND mor.second_line_name = sum.neighbour_ft_id) 
						OR (mor.first_line_name = sum.neighbour_ft_id AND mor.second_line_name = sum.ref_ft_id))
						AND mor.time = sum.from_time)
					WHERE sum.ref_ft_id = '{input_ref_ft_id}' and sum.neighbour_ft_id = '{input_neighbour_ft_id}' and sum.from_time = {input_time} and mor.at_angular_radius = {input_order}
					ORDER BY mor.at_angular_radius DESC"""
					sql_3 = txt_3.format(input_name_of_table_for_temporal_MOR_location_feats = name_of_table_for_recover_temporal_MOR_location_feats, input_name_of_table_for_summary_of_tectonic_motion = name_of_table_for_summary_of_tectonic_motion, input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id, input_time = from_time, input_order = order)
					cur_3.execute(sql_3)
					rows_3 = cur_3.fetchall()
					for value in rows_3:
						mor_ft_id = value[0]
						for location_ft in temp_location_feats:
							if (location_ft.get_feature_id().get_string() == mor_ft_id):
								wanted_mor_ft = location_ft
								break
						if (wanted_mor_ft is not None):
							break
				if (wanted_mor_ft is None):
					print("Error cannot find wanted_mor_ft")
					print("sql_1",sql_1)
					print("sql_3",sql_3)
					print("name_of_temporal_MOR_locations_feats_file",name_of_temporal_MOR_locations_feats_file)
					exit()
				key = None
				if (first_supergdu_represent_id > second_supergdu_represent_id):
					key = str(first_supergdu_represent_id)+"$"+str(second_supergdu_represent_id)
				else:
					key = str(second_supergdu_represent_id)+"$"+str(first_supergdu_represent_id)
				wanted_mor_ft.set_valid_time(summary_from_time,summary_to_time)
				temp_feature_collection.add(wanted_mor_ft)
				if (key in dic):
					dic[key].append((summary_from_time,summary_to_time,order,wanted_mor_ft))
				else:
					dic[key] = [(summary_from_time,summary_to_time,order,wanted_mor_ft)]
				row_1 = cur_1.fetchone()
			row = cur.fetchone()
		for key in dic:
			list_of_MOR_tuples = dic[key]
			for t in list_of_MOR_tuples:
				parent_SuperGDUs = key
				from_time = t[0]
				to_time = t[1]
				order = t[2]
				mor = t[3].get_feature_id().get_string()
				sql_2 = txt_2.format(input_name_of_table_for_summary_of_MOR_location_fts = name_of_table_for_summary_of_MOR_location_fts)
				cur_2.execute(sql_2,(parent_SuperGDUs, from_time, to_time, order, mor))
			conn.commit()
		temp_feature_collection.write("summary_of_MOR_location_features_for_"+modelname+"_"+yearmonthday+".shp")
	except(psycopg2.DatabaseError) as error:
		print("Error in create_MOR_linear_features_from_temporal_MOR_location_features related to the Database")
		print(error)
	finally:
		conn.close()

def summarize_temporal_MOR_location_features_no_inner_join_query(name_of_table_for_summary_of_tectonic_motion, name_of_table_for_temporal_MOR_location_feats, name_of_table_for_recover_temporal_MOR_location_feats, name_of_table_for_summary_of_MOR_location_fts, max_begin_reconstruction_time, modelname, yearmonthday):
	try:
		params = config()
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		txt = """SELECT from_time, to_time, ref_ft_id, neighbour_ft_id FROM {input_name_of_table_for_summary_of_tectonic_motion} 
						WHERE (tectonic_motion = 'Divergence' OR tectonic_motion = 'Oblique_divergence') and from_time <= {input_time} ORDER BY from_time DESC """
		txt_1 = """SELECT mor_ft_id, first_supergdu_represent_id, second_supergdu_represent_id, at_angular_radius, time
						FROM {input_name_of_table_for_temporal_MOR_location_feats}
						WHERE ((first_line_name = '{input_ref_ft_id}' AND second_line_name = '{input_neighbour_ft_id}')
								OR (first_line_name = '{input_neighbour_ft_id}' AND second_line_name = '{input_ref_ft_id}'))
							AND time = {input_from_time}
							
						ORDER BY time DESC"""
		txt_2 = """INSERT INTO {input_name_of_table_for_summary_of_MOR_location_fts} (parent_SuperGDUs,from_time,to_time,at_angular_radius,ini_mor_ft_id, new_mor_ft_id) VALUES(%s, %s, %s, %s, %s, %s)"""
		dic = {}
		temp_feature_collection = pygplates.FeatureCollection()
		sql = txt.format(input_name_of_table_for_summary_of_tectonic_motion = name_of_table_for_summary_of_tectonic_motion, input_time = max_begin_reconstruction_time)
		cur.execute(sql)
		row = cur.fetchone()
		while (row is not None):
			from_time = float(row[0])
			to_time = float(row[1])
			ref_ft_id = str(row[2])
			neighbour_ft_id = str(row[3])
			sql_1 = txt_1.format(input_name_of_table_for_temporal_MOR_location_feats = name_of_table_for_temporal_MOR_location_feats, input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id, input_from_time = from_time)
			cur_1.execute(sql_1)
			row_1 = cur_1.fetchone()
			current_time = -1.00
			while(row_1 is not None):
				mor_ft_id = row_1[0]
				first_supergdu_represent_id = int(row_1[1])
				second_supergdu_represent_id = int(row_1[2])
				order = float(row_1[3])
				current_time = float(row_1[4])
				print ("from_time",from_time,"to_time",to_time,"current_time",current_time)
				name_of_temporal_MOR_locations_feats_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\MOR_location_features\test_4_MOR_location_features_from_"+str(from_time)+"_test_11_reversed_Nuna_PalaeoPlatesNov2021_20220619.shp"
				is_recovered = False
				if (os.path.exists(name_of_temporal_MOR_locations_feats_file) == False):
					name_of_temporal_MOR_locations_feats_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\MOR_location_features\test_4_MOR_location_features_from_"+str(from_time)+"_test_11_reversed_Rodinia_PalaeoPlatesNov2021_20220620.shp"
					if (os.path.exists(name_of_temporal_MOR_locations_feats_file) == False):
						name_of_temporal_MOR_locations_feats_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\recover_oceanic_crust_features\test_4_recover_MOR_location_features_from_"+str(from_time)+"_recover_MOR_PalaeoPlatesNov2021_20220708.shp"
						is_recovered = True
				temp_location_feats = pygplates.FeatureCollection(name_of_temporal_MOR_locations_feats_file)
				wanted_mor_ft = None
				if (is_recovered == False):
					for location_ft in temp_location_feats:
						if (location_ft.get_feature_id().get_string() == mor_ft_id):
							wanted_mor_ft = location_ft
							break
				else:
					txt_3 = """SELECT mor_ft_id
						FROM {input_name_of_table_for_temporal_MOR_location_feats}
						WHERE ((first_line_name = '{input_ref_ft_id}' AND second_line_name = '{input_neighbour_ft_id}')
								OR (first_line_name = '{input_neighbour_ft_id}' AND second_line_name = '{input_ref_ft_id}'))
							AND time = {input_time}
							AND at_angular_radius = {input_order}"""
					sql_3 = txt_3.format(input_name_of_table_for_temporal_MOR_location_feats = name_of_table_for_recover_temporal_MOR_location_feats , input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id, input_time = from_time, input_order = order)
					cur_3.execute(sql_3)
					rows_3 = cur_3.fetchall()
					for value in rows_3:
						mor_ft_id = value[0]
						for location_ft in temp_location_feats:
							if (location_ft.get_feature_id().get_string() == mor_ft_id):
								wanted_mor_ft = location_ft
								break
						if (wanted_mor_ft is not None):
							break
				if (wanted_mor_ft is None):
					print("Error cannot find wanted_mor_ft")
					print("sql_1",sql_1)
					print("sql_3",sql_3)
					print("name_of_temporal_MOR_locations_feats_file",name_of_temporal_MOR_locations_feats_file)
					exit()
				clone_MOR_ft = wanted_mor_ft.clone()
				#initial_MOR_begin,initial_MOR_end = wanted_mor_ft.get_valid_time()
				clone_MOR_ft.set_valid_time(from_time,to_time)
				clone_MOR_ft.set_name(wanted_mor_ft.get_feature_id().get_string())
				temp_feature_collection.add(clone_MOR_ft)
				key = None
				if (first_supergdu_represent_id > second_supergdu_represent_id):
					key = str(first_supergdu_represent_id)+"$"+str(second_supergdu_represent_id)
				else:
					key = str(second_supergdu_represent_id)+"$"+str(first_supergdu_represent_id)
				if (key in dic):
					dic[key].append((from_time,to_time,order,clone_MOR_ft))
				else:
					dic[key] = [(from_time,to_time,order,clone_MOR_ft)]
				row_1 = cur_1.fetchone()
			row = cur.fetchone()
		for key in dic:
			list_of_MOR_tuples = dic[key]
			for t in list_of_MOR_tuples:
				parent_SuperGDUs = key
				from_time = t[0]
				to_time = t[1]
				order = t[2]
				ini_mor_ft_id = t[3].get_name()
				new_mor_ft_id = t[3].get_feature_id().get_string()
				sql_2 = txt_2.format(input_name_of_table_for_summary_of_MOR_location_fts = name_of_table_for_summary_of_MOR_location_fts)
				cur_2.execute(sql_2,(parent_SuperGDUs, from_time, to_time, order, ini_mor_ft_id, new_mor_ft_id))
			conn.commit()
		temp_feature_collection.write("summary_of_temporal_MOR_location_features_for_"+modelname+"_"+yearmonthday+".shp")
	except(psycopg2.DatabaseError) as error:
		print("Error in create_MOR_linear_features_from_temporal_MOR_location_features related to the Database")
		print(error)
	finally:
		conn.close()
		

# # def create_MOR_linear_features_from_summary_of_MOR_location_features_no_inner_join_query(name_of_table_for_summary_of_tectonic_motion, name_of_table_for_summary_of_MOR_location_fts, summary_of_temp_MOR_location_fts, threshold_degrees, max_begin_reconstruction_time, interval, rotation_model, reference, modelname, yearmonthday):
	# # try:
		# # params = config()
		# # conn = psycopg2.connect(**params)
		# # cur = conn.cursor()
		# # cur_1 = conn.cursor()
		# # cur_2 = conn.cursor()

	# # except(psycopg2.DatabaseError) as error:
		# # print("Error in create_MOR_linear_features_from_summary_of_MOR_location_features_no_inner_join_query related to the database")
		# # print(error)
	# # finally:
		# # conn.close()
	

def create_MOR_linear_features_from_summary_of_MOR_location_features_no_inner_join_query_2(name_of_table_for_summary_of_MOR_location_fts, name_of_table_for_linear_MOR_feats, summary_of_temp_MOR_location_fts, threshold_degrees, interval, rotation_model, reference, modelname, yearmonthday):
	try:
		params = config()
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		
		txt = """SELECT DISTINCT parent_SuperGDUs FROM {input_name_of_table_for_summary_of_MOR_location_fts}"""
		txt_1 = """SELECT MAX (from_time) FROM {input_name_of_table_for_summary_of_MOR_location_fts}"""
		txt_2 = """SELECT MIN (to_time) FROM {input_name_of_table_for_summary_of_MOR_location_fts}"""
		txt_3 = """SELECT new_mor_ft_id, at_angular_radius FROM {input_name_of_table_for_summary_of_MOR_location_fts}
					WHERE parent_SuperGDUs = '{input_parent_SuperGDUs}' AND {input_time} <= from_time and {input_time} >= to_time"""
		#when we figure out the better workflow we might not need to include parent_SuperGDUs and at_angular_radius for table linear_MOR_feat 
		txt_4 = """INSERT INTO {input_name_of_table_for_linear_MOR_fts} (time, parent_SuperGDUs, linear_mor_ft_id, point_mor_ft_id, at_angular_radius) VALUES(%s, %s, %s, %s, %s) """

		output_linear_MOR_feature_collection = pygplates.FeatureCollection()
		output_previous_MOR_ft_colleciton = pygplates.FeatureCollection()
		sql = txt.format(input_name_of_table_for_summary_of_MOR_location_fts = name_of_table_for_summary_of_MOR_location_fts)
		cur.execute(sql)
		row = cur.fetchone()
		while (row is not None):
			parent_SuperGDUs = row[0]
			deconstruct_parent_SuperGDUs = parent_SuperGDUs.split('$')
			first_supergdu_represent_id = int(deconstruct_parent_SuperGDUs[0])
			second_supergdu_represent_id = int(deconstruct_parent_SuperGDUs[1])
			sql_1 = txt_1.format(input_name_of_table_for_summary_of_MOR_location_fts = name_of_table_for_summary_of_MOR_location_fts)
			cur_1.execute(sql_1)
			row_1 = cur_1.fetchone()
			max_from_time = float(row_1[0])
			sql_2 = txt_2.format(input_name_of_table_for_summary_of_MOR_location_fts = name_of_table_for_summary_of_MOR_location_fts)
			cur_2.execute(sql_2)
			row_2 = cur_2.fetchone()
			min_to_time = float(row_2[0])
			temp_time = max_from_time
			list_of_order_and_MOR_fts = []
			already_included_order = []
			while (temp_time > (min_to_time - interval)):
				list_of_order_and_MOR_fts[:] = []
				already_included_order[:] = []
				sql_3 = txt_3.format(input_name_of_table_for_summary_of_MOR_location_fts = name_of_table_for_summary_of_MOR_location_fts, input_parent_SuperGDUs = parent_SuperGDUs ,input_time = temp_time)
				print("sql_3",sql_3)
				cur_3.execute(sql_3)
				row_3 = cur_3.fetchone()
				if (row_3 is not None):
					wanted_mor_ft = None
					while (row_3 is not None):
						wanted_mor_ft_id = str(row_3[0])
						order = float(row_3[1])
						for ft in summary_of_temp_MOR_location_fts:
							if (ft.get_feature_id().get_string() == wanted_mor_ft_id):
								if (order not in already_included_order):
									wanted_mor_ft = ft
									list_of_order_and_MOR_fts.append((order,wanted_mor_ft))
									already_included_order.append(order)
								break
						row_3 = cur_3.fetchone()
					# #sort list_of_MOR_fts
					list_of_order_and_MOR_fts.sort(reverse = True) #descending order
					is_ridge_and_transform = False
					print("list_of_order_and_MOR_fts",list_of_order_and_MOR_fts)
					storage_lists_of_ordered_MOR_fts = []
					if (len(list_of_order_and_MOR_fts) > 1):
						list_of_order,list_of_ordered_MOR_fts = zip(*list_of_order_and_MOR_fts)
						#debug
						for initial_MOR_ft in list_of_ordered_MOR_fts:
							print('initial_MOR_ft order',initial_MOR_ft.get_description())
						if (len(list_of_ordered_MOR_fts) > 1):
							reconstructed_MOR_features = []
							if (reference is not None):
								pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,temp_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,temp_time,group_with_feature = True)
				
							final_reconstructed_MOR_fts = supporting.find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
				
							MOR_features,reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
						
							#later on we have to query this properly from initial MOR_features database table 
							#left_plate_id = MOR_features[0].get_left_plate()
							#right_plate_id = MOR_features[0].get_right_plate()
			
							if (len(final_reconstructed_MOR_fts) > 0):
								featurecollection_final_linear_for_entire_MOR_ft,previous_MOR_transform_fts_collections = supporting_MOR.create_temporal_linear_MOR_feature_for_parent_SuperGDUs(parent_SuperGDUs,final_reconstructed_MOR_fts, temp_time, (temp_time - interval)+(interval*0.100), threshold_degrees, rotation_model, reference)
								for MOR_line_feature in featurecollection_final_linear_for_entire_MOR_ft:
									output_linear_MOR_feature_collection.add(MOR_line_feature)
									
								for previous_MOR_ft in previous_MOR_transform_fts_collections:
									output_previous_MOR_ft_colleciton.add(previous_MOR_ft)

						# storage_lists_of_ordered_MOR_fts = supporting_MOR.create_list_of_ordered_MOR_or_div_locations_fts(list_of_MOR_fts, 1.00, "desc",is_ridge_and_transform)
					# if (len(storage_lists_of_ordered_MOR_fts) > 0):
						# for list_of_ordered_MOR_fts in storage_lists_of_ordered_MOR_fts:
							# print ('list_of_ordered_MOR_fts',list_of_ordered_MOR_fts)
							 # #debug
							# for initial_ordered_MOR_ft in list_of_ordered_MOR_fts:
								# print('initial_ordered_MOR_ft order',initial_ordered_MOR_ft.get_description())
							
							# if (len(list_of_ordered_MOR_fts) > 1):
								# reconstructed_MOR_features = []
								# if (reference is not None):
									# pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,temp_time,anchor_plate_id = reference, group_with_feature = True)
								# else:
									# pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,temp_time,group_with_feature = True)
				
								# final_reconstructed_MOR_fts = supporting.find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
				
								# MOR_features,reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
						
							# #later on we have to query this properly from initial MOR_features database table 
							# #left_plate_id = MOR_features[0].get_left_plate()
							# #right_plate_id = MOR_features[0].get_right_plate()
			
								# if (len(final_reconstructed_MOR_fts) > 0):
									# featurecollection_final_linear_for_entire_MOR_ft,previous_MOR_transform_fts_collections = supporting_MOR.create_temporal_linear_MOR_feature_for_parent_SuperGDUs(parent_SuperGDUs,final_reconstructed_MOR_fts, temp_time, (temp_time - interval)+(interval*0.100), threshold_degrees, rotation_model, reference)
									# for MOR_line_feature in featurecollection_final_linear_for_entire_MOR_ft:
										# output_linear_MOR_feature_collection.add(MOR_line_feature)
										# # number_of_MOR_point_features = len(MOR_line_feature.get_geometry().to_lat_lon_list())
										# # for index_of_pt in range(previous_starting_pt_index,number_of_MOR_point_features)
											# # ordered_pt_ft,_ = previous_MOR_transform_fts_collections
										# # sql_4 = txt_4.format(input_name_of_table_for_linear_MOR_fts = name_of_table_for_linear_MOR_feats)
										# # #time, parent_SuperGDUs, linear_mor_ft_id, point_mor_ft_id, at_angular_radius
										# # cur_4.execute(sql_4,(temp_time,parent_SuperGDUs, final_linear_for_entire_MOR_ft.get_feature_id().get_string(), ordered_pt_ft.get_name(), ordered_pt_ft.get_description()))
									# for previous_MOR_ft in previous_MOR_transform_fts_collections:
										# output_previous_MOR_ft_colleciton.add(previous_MOR_ft)
									
				temp_time = temp_time - interval
				conn.commit()
			row = cur.fetchone()
		output_linear_MOR_feature_collection.write("linear_MOR_features_"+modelname+"_"+yearmonthday+".shp")
		output_previous_MOR_ft_colleciton.write("previous_MOR_point_features_"+modelname+"_"+yearmonthday+".shp")
	except(psycopg2.DatabaseError) as error:
		print("Error in create_MOR_linear_features_from_summary_of_MOR_location_features_no_inner_join_query related to the database")
		print(error)
	finally:
		conn.close()

