import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates

print ('at time t1')

point_A = pygplates.PointOnSphere((0.00,0.00))
point_B = pygplates.PointOnSphere((0.00,180.00))

Ax,Ay,Az = point_A.to_xyz()
print('Ax,Ay,Az',Ax,Ay,Az)
Bx,By,Bz = point_B.to_xyz()
print('Bx,By,Bz',Bx,By,Bz)
vec_r_A = pygplates.Vector3D((Ax,Ay,Az))
vec_r_B = pygplates.Vector3D((Bx,By,Bz))
vec_r_AB = vec_r_B - vec_r_A
print('vec_r_AB', vec_r_AB)
print('vec_r_AB mag ', vec_r_AB.get_magnitude())
print('dot_btw_vec_r_A_and_vec_r_B', pygplates.Vector3D.dot(vec_r_A,vec_r_B))

print ('at time t2')

point_A = pygplates.PointOnSphere((0.00,0.00))
point_B = pygplates.PointOnSphere((0.00,-170.00))

Ax,Ay,Az = point_A.to_xyz()
print('Ax,Ay,Az',Ax,Ay,Az)
Bx,By,Bz = point_B.to_xyz()
print('Bx,By,Bz',Bx,By,Bz)
vec_r_A = pygplates.Vector3D((Ax,Ay,Az))
vec_r_B = pygplates.Vector3D((Bx,By,Bz))
vec_r_AB = vec_r_B - vec_r_A
print('vec_r_AB', vec_r_AB)
print('vec_r_AB mag ', vec_r_AB.get_magnitude())
print('dot_btw_vec_r_A_and_vec_r_B', pygplates.Vector3D.dot(vec_r_A,vec_r_B))
