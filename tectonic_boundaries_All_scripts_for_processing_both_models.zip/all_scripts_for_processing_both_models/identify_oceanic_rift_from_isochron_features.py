import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import math
import pandas as pd
import numpy as np
import rotation_utility
import evaluate_tectonic_motion as tectonic_motion

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def find_total_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,reconstruction_time,reference_frame):
	"""
	Total reconstruction is a reconstruction relative to the present (in time) and relative to any reference frame (spin axis or mantle or anything else)
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		# print('moving_plate_id')
		# print(moving_plate_id)
		# print('fixed_plate_id')
		# print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		#print("Euler_pole,angle_rads")
		#print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		#print("lat,lon,angle_degrees")
		#print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity in total_relative_reconstruction_rotation")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		#print("Euler_pole,angle_rads")
		#print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		#print("lat,lon,angle_degrees")
		#print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_stage_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,from_time,to_time,reference_frame):
	"""
	Relative stage reconstruction is a reconstruction from any from_time to any to_time between any two GDUIDS
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("from_time,to_time")
		print(from_time,to_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_the_mid_of_two_PointOnSphere(p1,p2):
	"""
		p1 and p2: pygplates.PointOnSphere
		Return: a mid point between p1 and p2 in the datatype pygplates.PointOnSphere
		
		p1 and p2 can be expressed as (x,y,z) coordinates in pygplates. Thus, mid_point(x,y,z) = (x1+x2/2.0, y1+y2/2.0, z1+z2/2.0)
	"""
	x1,y1,z1 = p1.to_xyz()
	x2,y2,z2 = p2.to_xyz()
	mid_point_x = (x1+x2)/2.00
	mid_point_y = (y1+y2)/2.00
	mid_point_z = (z1+z2)/2.00
	
	vector = pygplates.Vector3D([mid_point_x, mid_point_y, mid_point_z])
	normalized_vector = vector.to_normalised()
	
	mid_point = pygplates.PointOnSphere(normalized_vector.to_xyz())
	return mid_point

def quickly_derive_mid_point_and_order_of_mid_point_from_two_divergent_points(pt_1,pt_2,Euler_pole):
	approx_mid_point = find_the_mid_of_two_PointOnSphere(pt_1,pt_2)
	vec_E_pole = pygplates.Vector3D(Euler_pole.to_xyz())
	vec_mid_point = pygplates.Vector3D(approx_mid_point.to_xyz())
	angle_rads = pygplates.Vector3D.angle_between(vec_mid_point,vec_E_pole)
	#convert angle_rads to degrees
	theta_degrees = math.degrees(angle_rads)
	return (approx_mid_point,theta_degrees)

def identify_left_gdu_and_right_gdu(normal_unit_vector, rift_point_location, mid_point_line_1, mid_point_line_2, plate_id_1, plate_id_2):
	#Method 1:
	opposite_unit_vector = normal_unit_vector*(-1.00)
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z = mid_point_line_2.to_xyz()
	
	#identify left and right
	vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	vector_to_line_2 = pygplates.Vector3D([(mid_point_line_2_x-rift_point_location_x),(mid_point_line_2_y-rift_point_location_y),(mid_point_line_2_z-rift_point_location_z)])
	normalized_vector_to_line_2 = vector_to_line_2.to_normalised()
	
	left = None
	right = None 

	if (pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,opposite_unit_vector) > 0):
		left = plate_id_1
		right = plate_id_2
	elif (pygplates.Vector3D.dot(normalized_vector_to_line_1,opposite_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector) > 0):
		left = plate_id_2
		right = plate_id_1
	
	if (left is not None and right is not None):
		return (left,right)

	magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z)
	if (azimuth <= math.pi or azimuth == 2*math.pi):
		right = plate_id_1
	elif (azimuth > math.pi):
		left = plate_id_1
	magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z)
	if (azimuth <= math.pi or azimuth == 2*math.pi):
		right = plate_id_2
	elif (azimuth > math.pi):
		left = plate_id_2
	return (left,right)

def identify_rift_point_features_from_isochron_features(isochron_features, rift_point_features_records_csv, rotation_model, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, time_interval, reference, modelname, yearmonthday):
	list_of_ordered_pairs_gdu_fts = []
	output_rift_point_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (max_reconstruction_time_for_start_div is not None):
		selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] <= max_reconstruction_time_for_start_div]
	if (min_reconstruction_time_for_start_div is not None):
		new_selected_rift_history_df = None
		if (selected_rift_history_df is not None):
			new_selected_rift_history_df = selected_rift_history_df.loc[selected_rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		else:
			new_selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		if (new_selected_rift_history_df is not None):
			selected_rift_history_df = new_selected_rift_history_df
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		descending_order_array = np.flip(sorted_array_of_start_div)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		#NEW
		start_div = descending_order_array[0]
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		list_of_wanted_isochron_point_features = []
		valid_isochron_features = []
		reconstruction_time = start_div
		while (reconstruction_time > min_reconstruction_time_for_start_div):
			list_of_wanted_isochron_point_features[:] = []
			valid_isochron_features[:] = []
			for isochron_ft in isochron_features:
				if (isochron_ft.is_valid_at_time(reconstruction_time) and isochron_ft.is_valid_at_time(reconstruction_time-time_interval)):
					valid_isochron_features.append(isochron_ft)
			temp_dic_of_isochron_feats = {}
			for order in array_of_order_for_rift_points:
				name_of_rift_point_ft = rift_name+'_'+str(order)
				if (name_of_rift_point_ft not in temp_dic_of_isochron_feats):
					temp_dic_of_isochron_feats[name_of_rift_point_ft] = None
				found_point_ft = None
				for isochron_point_ft in valid_isochron_features:
					if (isochron_point_ft.get_name() == name_of_rift_point_ft):
						found_point_ft = isochron_point_ft
						break
				if (found_point_ft is not None):
					if (temp_dic_of_isochron_feats[name_of_rift_point_ft] is not None):
						temp_dic_of_isochron_feats[name_of_rift_point_ft].append(found_point_ft)
					else:
						temp_dic_of_isochron_feats[name_of_rift_point_ft] = [found_point_ft]
			for isochron_first_name in temp_dic_of_isochron_feats:
				list_of_isochron_ft_w_first_name = temp_dic_of_isochron_feats[isochron_first_name]
				if (list_of_isochron_ft_w_first_name is not None):
					for isochron_second_name in temp_dic_of_isochron_feats:
						if (isochron_first_name != isochron_second_name):
							list_of_isochron_ft_w_second_name = temp_dic_of_isochron_feats[isochron_second_name]
							if (list_of_isochron_ft_w_second_name is not None):
								rep_isochron_pt_ft_w_first_name = list_of_isochron_ft_w_first_name[0]
								rep_isochron_pt_ft_w_second_name = list_of_isochron_ft_w_second_name[0]
								#check relative rotation between the two 
								gduid_1 = rep_isochron_pt_ft_w_first_name.get_reconstruction_plate_id()
								gduid_2 = rep_isochron_pt_ft_w_second_name.get_reconstruction_plate_id()
								stage_relative_reconstruction_rotation = find_stage_relative_reconstruction_rotation_(rotation_model,gduid_1,gduid_2,float(reconstruction_time),float(reconstruction_time)-time_interval,reference)
								if (stage_relative_reconstruction_rotation is not None):
									if (stage_relative_reconstruction_rotation.represents_identity_rotation() == False):
										Euler_pole_lat, Euler_pole_lon, angle_degrees = stage_relative_reconstruction_rotation.get_lat_lon_euler_pole_and_angle_degrees()
										if (angle_degrees > 0.00100):
											#definite relative motion
											reconstructed_features_w_first_name = []
											reconstructed_features_w_second_name = []
											if (len(list_of_isochron_ft_w_first_name) > 0 and len(list_of_isochron_ft_w_second_name) > 0):
												if (reference is not None):
													pygplates.reconstruct(list_of_isochron_ft_w_first_name,rotation_model,reconstructed_features_w_first_name,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
													pygplates.reconstruct(list_of_isochron_ft_w_second_name,rotation_model,reconstructed_features_w_second_name,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
												else:
													pygplates.reconstruct(list_of_isochron_ft_w_first_name,rotation_model,reconstructed_features_w_first_name,reconstruction_time,group_with_feature = True)
													pygplates.reconstruct(list_of_isochron_ft_w_second_name,rotation_model,reconstructed_features_w_second_name,reconstruction_time,group_with_feature = True)
												final_reconstructed_point_fts_w_first_name = find_final_reconstructed_geometries(reconstructed_features_w_first_name,pygplates.PointOnSphere)
												final_reconstructed_point_fts_w_second_name = find_final_reconstructed_geometries(reconstructed_features_w_second_name,pygplates.PointOnSphere)
												#find the closest pair of pt features
												min_dist = -1.00
												final_pair = None
												for first_pt_ft,first_pt in final_reconstructed_point_fts_w_first_name:
													for second_pt_ft,second_pt in final_reconstructed_point_fts_w_second_name:
														dist = pygplates.GeometryOnSphere.distance(first_pt,second_pt)
														if (min_dist == -1.00):
															min_dist = dist
															final_pair = (first_pt_ft,first_pt,second_pt_ft,second_pt)
														else:
															if (min_dist > 0.00 and dist > 0.00 and dist < min_dist):
																min_dist = dist
																final_pair = (first_pt_ft,first_pt,second_pt_ft,second_pt)
												if (final_pair is not None):
													final_first_pt_ft = final_pair[0]
													final_first_pt = final_pair[1]
													final_second_pt_ft = final_pair[2]
													final_second_pt = final_pair[3]
													reconstructed_features_ynger = []
													if (reference is not None):
														pygplates.reconstruct([final_first_pt_ft,final_second_pt_ft], rotation_model, reconstructed_features_ynger, reconstruction_time-time_interval, anchor_plate_id = reference, group_with_feature = True)
													else:
														pygplates.reconstruct([final_first_pt_ft,final_second_pt_ft], rotation_model, reconstructed_features_ynger, reconstruction_time-time_interval, group_with_feature = True)
													final_reconstructed_point_fts_ynger = find_final_reconstructed_geometries(reconstructed_features_ynger, pygplates.PointOnSphere)
													first_ynger_pair = final_reconstructed_point_fts_ynger[0]
													first_ynger_pt = first_ynger_pair[1]
													second_ynger_pair = final_reconstructed_point_fts_ynger[1]
													second_ynger_pt = second_ynger_pair[1]
													result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_pos_and_angular_vel_vec(final_first_pt, first_ynger_pt, final_second_pt, second_ynger_pt, reconstruction_time, reconstruction_time-time_interval)
													if (result_of_tectonic_motion == 'D'):
														#quickly find mid-point feature
														total_relative_reconstruction_rotation = find_total_relative_reconstruction_rotation_(rotation_model, gduid_1, gduid_2, reconstruction_time, reference)
														if (total_relative_reconstruction_rotation is not None):
															if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
																#find mid point
																E_pole,_ = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
																quick_mid_pt,mid_pt_order = quickly_derive_mid_point_and_order_of_mid_point_from_two_divergent_points(final_first_pt,final_second_pt,E_pole)
																mid_pt_order = round(mid_pt_order,2)
																#create rift point ft
																# #create an arc
																temporary_GreatCircleArc = pygplates.GreatCircleArc(quick_mid_pt,E_pole)
																normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
																left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, quick_mid_pt, final_first_pt, final_second_pt, gduid_1, gduid_2)
																#create point feature
																name = rift_name+'_'+str(mid_pt_order)
																rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, quick_mid_pt, name = name, valid_time = (reconstruction_time,0.00))
																if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
																	rift_point_ft.set_left_plate(gduid_1)
																	rift_point_ft.set_right_plate(gduid_2)
																else:
																	rift_point_ft.set_left_plate(left_gduid)
																	rift_point_ft.set_right_plate(right_gduid)
																rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
																rift_point_ft.set_description(str(mid_pt_order))
																if (reference is None):
																	pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
																else:
																	pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
																output_rift_point_features.add(rift_point_ft)
																if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
																	if ((left_gduid == gduid_1 and right_gduid == gduid_2) or (left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
																		list_of_ordered_pairs_gdu_fts.append((reconstruction_time, rift_name, mid_pt_order, final_first_pt_ft.get_name(), gduid_1, gduid_1, final_second_pt_ft.get_name(), gduid_2, gduid_2))
																	else:
																		list_of_ordered_pairs_gdu_fts.append((reconstruction_time, rift_name, mid_pt_order, final_second_pt_ft.get_name(), gduid_2, gduid_2, final_first_pt_ft.get_name(), gduid_1, gduid_1))
			reconstruction_time = reconstruction_time - time_interval
	#output rift point features
	output_rift_point_features.write('rift_point_features_from_isochron_features_for_'+modelname+'_'+yearmonthday+'.shp')
	#list_of_ordered_pairs_gdu_fts.append((start_div,name,smallest_circle_angular_radius_degrees, gdu_line_ft_2.get_shapefile_attribute('POLYLID'), gdu_line_ft_2.get_reconstruction_plate_id(), child_repgduid_2, gdu_line_ft_1.get_shapefile_attribute('POLYLID'), gdu_line_ft_1.get_reconstruction_plate_id(), child_repgduid_1))
	output_dataframe = pd.DataFrame.from_records(list_of_ordered_pairs_gdu_fts, columns = ['start_div','rift_name','order','lpolylid','left_gdu','lrepgduid','rpolylid','right_gdu','rrepgduid'])
	filename = 'records_of_rift_point_features_records_from_from_isochron_features_'+str(max_reconstruction_time_for_start_div)+'_'+str(min_reconstruction_time_for_start_div)+'_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)
	
def main():
	isochron_features_file = r"isochron_left_point_features_test_29_PalaeoPlatesendJan2023_fts_from_2800.0_20240302.shp"
	isochron_features = pygplates.FeatureCollection(isochron_features_file)
	rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	max_reconstruction_time_for_start_div = 130.00
	min_reconstruction_time_for_start_div = 105.00
	time_interval = 5.00
	reference = 700
	modelname = "PalaeoPlatesendJan2023"
	yearmonthday = "20240406"
	identify_rift_point_features_from_isochron_features(isochron_features, rift_point_features_records_csv, rotation_model, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, time_interval, reference, modelname, yearmonthday)

if __name__ == "__main__":
	main()