import sys
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_extract_information_from_database_tables as supporting
def main():
	time_interval = 5.00
	#supporting.extract_plate_tectonic_motion_from_database_table_tectonic_motion(time_interval)
	initial_CON_OCN_geological_topological_line_feature_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\utility\check_and_assign_ft_id_str_in_GPlates_format_to_ft_name_CON_OCN_line_features_PalaeoPlatesNov2021_20220224.gpml"
	uncertainty_time_difference = 15.0
	modelname = "PalaeoPlatesNov2021_temp_2000_0Ma"
	test_number = 1
	yearmonthday = "20220327"
	supporting.extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_motion_and_tectonic_boundaries_and_CON_OCN_line_features(initial_CON_OCN_geological_topological_line_feature_file, uncertainty_time_difference, modelname, test_number, yearmonthday)

if __name__ == '__main__':
	main()