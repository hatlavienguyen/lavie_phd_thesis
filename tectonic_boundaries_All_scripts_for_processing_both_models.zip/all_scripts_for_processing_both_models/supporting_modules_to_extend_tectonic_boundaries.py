import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
from shapely.geometry import Point, Polygon, LineString, MultiPoint, MultiPolygon, LinearRing
from shapely.ops import unary_union, transform, cascaded_union, polygonize, polygonize_full, linemerge, triangulate 
from shapely.validation import explain_validity 
import pyproj
from functools import partial
from config_plate_tectonics import config
import psycopg2

def find_other_features_w_similar_geometry(given_ft,other_features):
	list_of_similar_fts = []
	geometry = given_ft.get_geometry()
	geometry_in_Shapely = None
	if (type(geometry) == pygplates.PolylineOnSphere):
		geometry_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(geometry)
	elif(type(geometry) == pygplates.PointOnSphere):
		lat,lon = geometry.to_lat_lon()
		geometry_in_Shapely = Point(lat,lon)
	for other_ft in other_features:
		if (given_ft.get_feature_id() != other_ft.get_feature_id()):
			other_geometry = other_ft.get_geometry()
			if (other_geometry is None):
				print("Error in finalize_tectonic_boundary_features_from_multiple_output_files")
				print("other_ft.get_geometry() is None")
				print("other_ft.get_feature_id()")
				print(other_ft.get_feature_id().get_string())
				print("other_ft.get_reconstruction_plate_id()")
				print(other_ft.get_reconstruction_plate_id())
				exit()
			other_geometry_in_Shapely = None
			if (type(other_geometry) == pygplates.PolylineOnSphere):
				other_geometry_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(other_geometry)
			elif (type(other_geometry) == pygplates.PointOnSphere):
				lat,lon = other_geometry.to_lat_lon()
				other_geometry_in_Shapely = Point(lat,lon)
			if (other_geometry_in_Shapely.almost_equals(geometry_in_Shapely,decimal = 4)):
				list_of_similar_fts.append(other_ft)
	list_of_similar_fts.append(given_ft)
	return list_of_similar_fts

def finalize_tectonic_boundary_feature_from_multiple_similar_fts_w_same_geometry(list_of_fts_w_same_geometry):					
	current_final_feature = None
	list_of_final_fts = []
	oldest_begin_age,youngest_end_age = -1.00,-1.00
	for ft_w_similar_geometry in list_of_fts_w_same_geometry:
		if (current_final_feature is None):
			current_final_feature = ft_w_similar_geometry
			oldest_begin_age,youngest_end_age = ft_w_similar_geometry.get_valid_time()
		elif (current_final_feature.get_feature_id() != ft_w_similar_geometry.get_feature_id()):
			new_begin_age,new_end_age = ft_w_similar_geometry.get_valid_time()
			if (new_begin_age == oldest_begin_age):
				if (new_end_age < youngest_end_age):
					current_final_feature = ft_w_similar_geometry
					oldest_begin_age,youngest_end_age = new_begin_age,new_end_age
			else:
				list_of_final_fts.append(ft_w_similar_geometry)
	if (current_final_feature is not None):
		include_current_final_ft = True
		if (len(list_of_final_fts) > 0):
			for feat in list_of_final_fts:
				if (feat.get_feature_id() == current_final_feature.get_feature_id()):
					include_current_final_ft = False
					break
		if (include_current_final_ft == True):
			list_of_final_fts.append(current_final_feature.clone())
	return list_of_final_fts

def finalize_tectonic_boundary_feature_from_duplicates(list_of_fts_w_same_geometry):					
	current_final_feature = None
	list_of_final_fts = []
	oldest_begin_age,youngest_end_age = -1.00,-1.00
	for ft_w_similar_geometry in list_of_fts_w_same_geometry:
		if (current_final_feature is None):
			current_final_feature = ft_w_similar_geometry
			oldest_begin_age,youngest_end_age = ft_w_similar_geometry.get_valid_time()
		elif (current_final_feature.get_feature_id() != ft_w_similar_geometry.get_feature_id()):
			new_begin_age,new_end_age = ft_w_similar_geometry.get_valid_time()
			current_final_feature_left_gdu = current_final_feature.get_left_plate()
			current_final_feature_right_gdu = current_final_feature.get_right_plate()
			new_left_gdu = ft_w_similar_geometry.get_left_plate()
			new_right_gdu = ft_w_similar_geometry.get_right_plate()
			if (new_right_gdu == current_final_feature_right_gdu and new_left_gdu == current_final_feature_left_gdu):
				if (new_begin_age == oldest_begin_age and new_end_age == youngest_end_age):
					current_final_feature = ft_w_similar_geometry
					oldest_begin_age,youngest_end_age = new_begin_age,new_end_age
				else:
					list_of_final_fts.append(ft_w_similar_geometry)
			else:
				list_of_final_fts.append(ft_w_similar_geometry)
	if (current_final_feature is not None):
		include_current_final_ft = True
		if (len(list_of_final_fts) > 0):
			for feat in list_of_final_fts:
				if (feat.get_feature_id() == current_final_feature.get_feature_id()):
					include_current_final_ft = False
					break
		if (include_current_final_ft == True):
			list_of_final_fts.append(current_final_feature.clone())
	return list_of_final_fts

def is_two_time_periods_overlapping(begin_1,end_1,begin_2,end_2,specialized_for_possible_subduction_zone_valid,interval_time_for_kin_eval,verbose):
	'''
		This function is designed to check whether any two time periods overlapping with each other
		begin_1,end_1: the first time period
		begin_2,end_2: the second time period
		specialized_for_possible_subduction_zone_valid: is a boolean flag to tell us whether or not; the result is for evaluating possible subduction zone
		interval_time_for_kin_eval: if the boolean flag is True, we will do the special check.
			Rather than simply using the original time begin and end time, we will check whether the difference between these two time interval is greater than interval_time_for_kin_eval
	'''
	if (specialized_for_possible_subduction_zone_valid == False):
		if (end_1 >= begin_2 or end_2 >= begin_1):
			return False
		else:
			return True
	else:
		if(verbose == True):
			print('begin_1,end_1')
			print(begin_1,end_1)
			print('begin_2,end_2')
			print(begin_2,end_2)
			print(abs(end_1 - begin_2) > interval_time_for_kin_eval)
			print(abs(end_2 - begin_1) > interval_time_for_kin_eval)
		if (end_1 >= begin_2):
			if (abs(end_1 - begin_2) > interval_time_for_kin_eval):
				return False
			else:
				return True
		elif (end_2 >= begin_1):
			if (abs(end_2 - begin_1) > interval_time_for_kin_eval):
				return True
			else:
				return False 
		else:
			return True

def extend_valid_age_of_tectonic_boundary_feature_from_multiple_similar_fts_w_same_geometry(list_of_fts_w_same_geometry, interval_time_for_kin_eval):					
	current_final_feature = None
	list_of_final_fts = []
	list_of_fts_w_overlapping_periods = []
	oldest_begin_age,youngest_end_age = -1.00,-1.00
	for ft_w_similar_geometry in list_of_fts_w_same_geometry:
		ft_begin_age,ft_end_age = ft_w_similar_geometry.get_valid_time()
		# #debug
		# if (ft_w_similar_geometry.get_reconstruction_plate_id() == 10448):
			# print('ft_begin_age,ft_end_age')
			# print(ft_begin_age,ft_end_age)
		for other_ft in list_of_fts_w_same_geometry:
			if (other_ft.get_feature_id() != ft_w_similar_geometry.get_feature_id()):
				new_begin_age,new_end_age = other_ft.get_valid_time()
				# #debug
				# if (ft_w_similar_geometry.get_reconstruction_plate_id() == 10448 and other_ft.get_reconstruction_plate_id() == 10448):
					# print('other_ft begin_age, other_ft end_age')
					# print(new_begin_age,new_end_age)
				result = is_two_time_periods_overlapping(ft_begin_age,ft_end_age,new_begin_age,new_end_age,True,interval_time_for_kin_eval,False)
				print('result value')
				print(result)
				if (result == True):
					# #debug
					# if (ft_w_similar_geometry.get_reconstruction_plate_id() == 10448 and other_ft.get_reconstruction_plate_id() == 10448):
						# print('found ft overlapping in valid time')
						# exit()
					if (ft_w_similar_geometry not in list_of_fts_w_overlapping_periods):
						list_of_fts_w_overlapping_periods.append(ft_w_similar_geometry)
					break
			
	if (len(list_of_fts_w_overlapping_periods) > 0):
		#debug 
		t = list_of_fts_w_overlapping_periods[0]
		if (t.get_reconstruction_plate_id() == 10448):
			print('len(list_of_fts_w_overlapping_periods)')
			print(len(list_of_fts_w_overlapping_periods))
			#exit()
			
		for ft in list_of_fts_w_overlapping_periods:
			if (oldest_begin_age == -1.00 and youngest_end_age == -1.00):
				oldest_begin_age,youngest_end_age = ft.get_valid_time()
			else:
				new_begin_age,new_end_age = ft.get_valid_time()
				#update oldest_begin_age and youngest_end_age
				if (oldest_begin_age < new_begin_age):
					oldest_begin_age = new_begin_age
				if (youngest_end_age > new_end_age):
					youngest_end_age = new_end_age
		current_final_feature = list_of_fts_w_overlapping_periods[0].clone()
		current_final_feature.set_valid_time(oldest_begin_age,youngest_end_age)
		list_of_final_fts.append(current_final_feature.clone())
	for ft in list_of_fts_w_same_geometry:
		if (ft not in list_of_fts_w_overlapping_periods):
			list_of_final_fts.append(ft.clone())
	return list_of_final_fts

def finalize_tectonic_boundary_features_from_multiple_output_files(common_name_for_output_files,modelname,threshold,yyyymmdd,begin,end,interval,output_freq,fileformat):
	time = begin
	list_of_filename = []
	list_of_temporal_fts = []
	list_of_final_fts = []
	already_proccessed_ft = []
	output_features = []
	while (time > end):
		print('time')
		print(time)
		next_time = time - (interval * output_freq)
		if (next_time < end):
			next_time = end 
		print('next_time')
		print(next_time)
		#tectonic_boundaries_features_test_5_for_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_800km__170.0_150.0_5Ma_20210204.gpml
		txt = """{input_common_name_for_output_files}_{input_modelname}_{input_threshold}km__{input_begin}_{input_end}_{input_interval}Ma_{input_yyyymmdd}.{input_fileformat}"""
		final_filename = txt.format(input_common_name_for_output_files = common_name_for_output_files, input_modelname = modelname, input_threshold = threshold, input_begin = str(time), input_end = str(next_time), input_interval = str(interval), input_yyyymmdd = yyyymmdd, input_fileformat = fileformat)
		print('final_filename')
		print(final_filename)
		list_of_filename.append(final_filename)
		
		time = next_time
		
	multiple_feature_collection = pygplates.FeatureCollection.read(list_of_filename)
	print('multiple_feature_collection')
	print(multiple_feature_collection)
	
	list_of_features = []
	for collection in multiple_feature_collection:
		for ft in collection:
			list_of_features.append(ft)
	
	feature_collection = pygplates.FeatureCollection(list_of_features)
	print('number of features in feature_collection')
	print(len(feature_collection))
	dic = {}
	#maybe create a another sub module to find features having similar geometry
	for ft in feature_collection:
		print('len(already_proccessed_ft)')
		print(len(already_proccessed_ft))
		name_of_ft = ft.get_name()
		featType_of_ft = ft.get_feature_type()
		ft_id = ft.get_feature_id().get_string()
		if (ft_id not in already_proccessed_ft):
			other_features = [other_ft for other_ft in feature_collection if (ft.get_feature_id() != other_ft.get_feature_id() and ft.get_name() == other_ft.get_name() and ft.get_feature_type() == other_ft.get_feature_type())]
			list_of_temporal_fts = find_other_features_w_similar_geometry(ft,other_features)
			for similar_ft in list_of_temporal_fts:
				already_proccessed_ft.append(similar_ft.get_feature_id().get_string())
			dic[ft_id] = list_of_temporal_fts
	print('number_of_fts in dic')
	print(len(dic))
	for represent_ft_id in dic.keys():
		list_of_same_geometry_ft = dic[represent_ft_id]
		list_of_final_fts = finalize_tectonic_boundary_feature_from_multiple_similar_fts_w_same_geometry(list_of_same_geometry_ft)
		print('len(list_of_final_fts)')
		print(len(list_of_final_fts))
		#debug
		temp_ft_from_final_fts = list_of_final_fts[0]
		if (temp_ft_from_final_fts.get_reconstruction_plate_id() == 10389):
			print('here is len of list_of_final_fts')
			print(len(list_of_final_fts))
		for final_tectonic_ft in list_of_final_fts:	
			output_features.append(final_tectonic_ft)
	print('number of features in output_features')
	print(len(output_features))
	
	outputFeatureCollection = pygplates.FeatureCollection(output_features)
	outputFeatureFile = 'test_5_combine_and_finalize_tectonic_features_from_'+str(begin)+'_'+str(end)+'_'+str(interval)+'_'+modelname+'_'+yyyymmdd+'.shp'
	outputFeatureCollection.write(outputFeatureFile)
	outputFeatureFile = 'test_5_combine_and_finalize_tectonic_features_from_'+str(begin)+'_'+str(end)+'_'+str(interval)+'_'+modelname+'_'+yyyymmdd+'.gpml'
	outputFeatureCollection.write(outputFeatureFile)

def exam_and_modify_end_age_of_possible_subduction_margin_features(subduction_margin_features, begin, end, interval, modelname, test_number, yyyymmdd):
	initial_feature_collection = pygplates.FeatureCollection(subduction_margin_features)
	feature_collection = []
	for ft in initial_feature_collection:
		ft_begin_age,ft_end_age = ft.get_valid_time()
		if (is_two_time_periods_overlapping(ft_begin_age,ft_end_age,begin,end,False,-1.00,False)):
			feature_collection.append(ft)
	print('number of features in feature_collection')
	print(len(feature_collection))
	dic = {}
	already_proccessed_ft = []
	output_features = []
	#maybe create a another sub module to find features having similar geometry
	for ft in feature_collection:
		print('len(already_proccessed_ft)')
		print(len(already_proccessed_ft))
		name_of_ft = ft.get_name()
		featType_of_ft = ft.get_feature_type()
		ft_id = ft.get_feature_id().get_string()
		if (ft_id not in already_proccessed_ft):
			other_features = [other_ft for other_ft in feature_collection if (ft.get_feature_id() != other_ft.get_feature_id() and ft.get_name() == other_ft.get_name() and ft.get_feature_type() == other_ft.get_feature_type())]
			list_of_temporal_fts = find_other_features_w_similar_geometry(ft,other_features)
			for similar_ft in list_of_temporal_fts:
				already_proccessed_ft.append(similar_ft.get_feature_id().get_string())
			dic[ft_id] = list_of_temporal_fts
	print('number_of_fts in dic')
	print(len(dic))
	for represent_ft_id in dic.keys():
		list_of_same_geometry_ft = dic[represent_ft_id]
		list_of_final_fts = extend_valid_age_of_tectonic_boundary_feature_from_multiple_similar_fts_w_same_geometry(list_of_same_geometry_ft,interval)
		print('represent_ft_id')
		print(represent_ft_id)
		print('len(list_of_final_fts)')
		print(len(list_of_final_fts))
		
		for final_tectonic_ft in list_of_final_fts:	
			output_features.append(final_tectonic_ft)
	print('number of features in output_features')
	print(len(output_features))
	
	outputFeatureCollection = pygplates.FeatureCollection(output_features)
	outputFeatureFile = 'test_'+str(test_number)+'_combine_and_finalize_subduction_margin_features_from_'+str(begin)+'_'+str(end)+'_'+str(interval)+'_'+modelname+'_'+yyyymmdd+'.shp'
	outputFeatureCollection.write(outputFeatureFile)
	outputFeatureFile = 'test_'+str(test_number)+'_combine_and_finalize_subduction_margin_features_from_'+str(begin)+'_'+str(end)+'_'+str(interval)+'_'+modelname+'_'+yyyymmdd+'.gpml'
	outputFeatureCollection.write(outputFeatureFile)
	
def clean_polygon_features_w_date_line_wrapper(rotation_model,list_of_polygon_GDU_fts,reconstruction_time,reference,modelname,yearmonthday):
	reconstructed_polygon_features = []
	final_reconstructed_polygon_features = []
	reconstructed_dissolved_polygon_features = []
	reconstructed_line_features = []
	reconstructed_dangles_cuts = []
	distant_future = pygplates.GeoTimeInstant.create_distant_future()
	#reconstruct all features to reconstruction_time
	list_of_valid_polygon_fts = [polygon_ft for polygon_ft in list_of_polygon_GDU_fts if polygon_ft.is_valid_at_time(reconstruction_time)]
	if (reference is not None):
		#polygon_features
		pygplates.reconstruct(list_of_valid_polygon_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	else:
		#polygon_features
		pygplates.reconstruct(list_of_valid_polygon_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
	final_reconstructed_polygon_features = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
	error_polygon_fts = []
	
	polygon_fts_and_wrapped_polygons = []
	polygon_fts_clean_polygons = []
	
	for polygon_ft,polygon in final_reconstructed_polygon_features:
		#wrap polygon with the DateLineWrapper
		date_line_wrapper = pygplates.DateLineWrapper()
		wrapped_polygons = date_line_wrapper.wrap(polygon)
		for wrapped_polygon in wrapped_polygons:
			new_polygon = pygplates.PolygonOnSphere(wrapped_polygon.get_exterior_points())
			
			clone_feature = polygon_ft.clone()
			clone_feature.set_geometry(new_polygon)
			clone_feature.set_name('wrapped_polygon_ft_'+polygon_ft.get_name())
			polygon_fts_and_wrapped_polygons.append((clone_feature,new_polygon))
			
	for polygon_ft,polygon in polygon_fts_and_wrapped_polygons:
		featType = polygon_ft.get_feature_type()
		#original_name = polygon_ft.get_name()
		#convert polygon to the list of lat lon tuples
		list_of_lon_lat_vertices = [(lon,lat) for lat,lon in polygon.to_lat_lon_list()]
		Polygon_in_shapely = Polygon(list_of_lon_lat_vertices)
		print('Polygon_in_shapely')
		print(Polygon_in_shapely)
		new_feature = None
		if (Polygon_in_shapely.is_valid):
			#convert the polygon to PolygonOnSphere
			new_PolygonOnSphere = supporting.convert_Polygon_to_PolygonOnSphere_in_pygplates(Polygon_in_shapely)
			#create new Feature in pygplates
			#new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='wrapped_polygon_ft_'+original_name,valid_time = polygon_ft.get_valid_time(),reconstruction_plate_id = polygon_ft.get_reconstruction_plate_id())
			if (polygon_ft is not None):
				reconstructed_dissolved_polygon_features.append(polygon_ft)
			polygon_fts_clean_polygons.append((polygon_ft,polygon))
		else:
			error_polygon_fts.append(polygon_ft)
			original_list_of_lon_lat = [(lon,lat) for lat,lon in polygon.to_lat_lon_list()]
			#print(original_list_of_lon_lat)
			#using list comprehension + enumerate() 
			#to remove duplicated  
			#from list	-- reference: https://www.geeksforgeeks.org/python-ways-to-remove-duplicates-from-list/
			res = [i for n, i in enumerate(original_list_of_lon_lat) if i not in original_list_of_lon_lat[:n]] 
			
			new_LineString = LineString(res[:]+res[0:1])
			# print("new_LineString.is_simple")
			# print(new_LineString.is_simple)
			new_Polygon = Polygon(res)
			if (new_Polygon.is_valid):
				#convert the polygon to PolygonOnSphere
				new_PolygonOnSphere = supporting.convert_Polygon_to_PolygonOnSphere_in_pygplates(new_Polygon)
				clone_feature = polygon_ft.clone()
				clone_feature.set_geometry(new_PolygonOnSphere)
				clone_feature.set_name("fixed_polygon_ft_with_dateline_wrapper_remove_duplicate_points"+polygon_ft.get_name())
				if (clone_feature is not None):
					reconstructed_dissolved_polygon_features.append(clone_feature)
				polygon_fts_clean_polygons.append((clone_feature,new_PolygonOnSphere))
			else:
				# print(explain_validity(new_Polygon))
				new_MultiLineString = unary_union(new_LineString)
				for l in new_MultiLineString:
					list_of_lat_lon_points = [pygplates.PointOnSphere((lat,lon)) for lon,lat in l.coords]
					new_LineOnSphere = pygplates.PolylineOnSphere(list_of_lat_lon_points)
					#create new Feature in pygplates
					new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_LineOnSphere,name='line_ft_with_new_LineString',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
					new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
					if (new_feature is not None):
						reconstructed_line_features.append(new_feature)
			
				result, dangles, cuts, invalids = polygonize_full(new_MultiLineString)
				if (result.geom_type == "GeometryCollection"):
					for polygon in result:
						# print("valid polygon in result")
						# print(polygon.is_valid)
						# print(explain_validity(result))
						
						#convert the polygon to PolygonOnSphere
						new_PolygonOnSphere = supporting.convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
						
						#create new Feature in pygplates
						# new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='cleaned_polygon_ft',valid_time = (reconstruction_time,distant_future),reconstruction_plate_id = 0)
						# new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
						# if (new_feature is not None):
							# reconstructed_dissolved_polygon_features.append(new_feature)
						if (new_PolygonOnSphere.get_area() > 0.00):
							clone_feature = polygon_ft.clone()
							clone_feature.set_geometry(new_PolygonOnSphere)
							clone_feature.set_name("fixed_polygon_ft_with_dateline_wrapper_and_polygonize"+polygon_ft.get_name())
							if (clone_feature is not None):
								reconstructed_dissolved_polygon_features.append(clone_feature)
							polygon_fts_clean_polygons.append((clone_feature,new_PolygonOnSphere))
				else:
					#print(new_LineString)
					#print(new_LineString.buffer(0))
					print("result")
					print(result)
					print(result.geom_type)
					print(explain_validity(result))
					exit()
			
				#if (dangles.is_empty == False or cuts.is_empty == False or invalids.is_empty == False):
				if (invalids.is_empty == False):
					print("Error in clean_polygon_features")
					print("dangles, cuts, invalids")
					print(dangles, cuts, invalids)
					invalid_reconstruced_polygon_fts = []
					#simplify invalids with unary_union
					union_geometries = unary_union(invalids)
					for polygon in polygonize(invalids):
						print (polygon.is_valid)
						#convert the polygon to PolygonOnSphere
						new_PolygonOnSphere = supporting.convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
						#create new Feature in pygplates
						new_feature = pygplates.Feature.create_reconstructable_feature(featType,new_PolygonOnSphere,name='invalid_polygon_ft',valid_time = (reconstruction_time,0.00),reconstruction_plate_id = 0)
						new_feature.set_reconstruction_plate_id(polygon_ft.get_reconstruction_plate_id())
						if (new_feature is not None):
							invalid_reconstruced_polygon_fts.append(new_feature)
					#reverse_reconstruct
					if (reference is not None):
						pygplates.reverse_reconstruct(invalid_reconstruced_polygon_fts,rotation_model,reconstruction_time,reference)
					else:
						pygplates.reverse_reconstruct(invalid_reconstruced_polygon_fts,rotation_model,reconstruction_time)
					
					outputFeatureCollection = pygplates.FeatureCollection(invalid_reconstruced_polygon_fts)
					outputFeatureFile = 'invalid_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
					outputFeatureCollection.write(outputFeatureFile)
					outputFeatureFile = 'invalid_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
					outputFeatureCollection.write(outputFeatureFile)
					
					#reverse_reconstruct
					if (reference is not None):
						pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time,reference)
						pygplates.reverse_reconstruct(error_polygon_fts,rotation_model,reconstruction_time,reference)
					else:
						pygplates.reverse_reconstruct(reconstructed_dissolved_polygon_features,rotation_model,reconstruction_time)
						pygplates.reverse_reconstruct(error_polygon_fts,rotation_model,reconstruction_time)
	
					polygon_fts_with_dateline_wrapper = pre_process_polygon_features_from_shp_file(reconstructed_dissolved_polygon_features,modelname,yearmonthday,False)
	
					outputFeatureCollection = pygplates.FeatureCollection(polygon_fts_with_dateline_wrapper)
					outputFeatureFile = 'fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
					outputFeatureCollection.write(outputFeatureFile)
					outputFeatureFile = 'fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
					outputFeatureCollection.write(outputFeatureFile)
	
					outputFeatureCollection = pygplates.FeatureCollection(error_polygon_fts)
					outputFeatureFile = 'required_to_be_fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp'
					outputFeatureCollection.write(outputFeatureFile)
					outputFeatureFile = 'required_to_be_fixed_polygon_fts_from_date_line_wrapper_from_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml'
					outputFeatureCollection.write(outputFeatureFile)

					exit()

	return(polygon_fts_clean_polygons)

def clean_up_messy_tectonic_boundaries(rotation_model, SuperGDU_features, tectonic_features, line_features, only_check_inferred_fts, begin, end, interval, reference, modelname, yyyymmdd):
	"""
	Messy tectonic boundaries are boundaries which are NOT CON-OCN. Edit the valid time for these boundaries.
	Parameters:
		rotation_model (pygplates.RotationModel): A pygplates rotation model generated from .rot file
		SuperGDU_features (pygplates.FeatureCollection or list of features): SuperGDU features that are generated for the same model used for tectonic features
		tectonic_features (pygplates.FeatureCollection or list of features)
		line_features (pygplates.FeatureCollection or list of features): line_features making up ONLY the margins of GDUs CON-OCN line features
		only_check_inferred_fts: a boolean flag to check whether we only check the validity of inferred features
		begin, end, interval (float): period of time and the time step
		reference (int): a value that we use in rotation file as a reference frame - like spin axis or mantle
	"""
	print("number of original tectonic_features")
	print(len(tectonic_features))
	reconstruction_time = begin
	reconstructed_tectonic_features = [] 
	reconstructed_line_features = []
	reconstructed_polygon_features = []
	modified_tectonic_features = []
	features_to_be_modified = []
	already_used_line_features = []
	output_tectonic_features = [] 
	polygon_fts_and_wrapped_polygons = []
	list_of_valid_SuperGDU_fts = []
	list_of_valid_tectonic_fts = []
	while (reconstruction_time > (end - interval)):
		print("reconstruction_time")
		print(reconstruction_time)
		reconstructed_tectonic_features[:] = []
		reconstructed_line_features[:] = []
		reconstructed_polygon_features[:] = []
		list_of_valid_tectonic_fts[:] = []
		if (only_check_inferred_fts == False):
			list_of_valid_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time) and ft.get_feature_id() not in modified_tectonic_features]
		else:
			for ft in tectonic_features:
				if (ft.is_valid_at_time(reconstruction_time) and ft.get_feature_id() not in modified_tectonic_features):
					ft_name = ft.get_name()
					splited_name = ft_name.split('_')
					if (splited_name[0] == 'inferred'):
						list_of_valid_tectonic_fts.append(ft)
		list_of_valid_SuperGDU_fts[:] = []
		for SuperGDU_ft in SuperGDU_features:
			begin_age_SuperGDU_ft, end_age_SuperGDU_ft = SuperGDU_ft.get_valid_time()
			if (begin_age_SuperGDU_ft >= reconstruction_time and end_age_SuperGDU_ft < reconstruction_time):
				list_of_valid_SuperGDU_fts.append(SuperGDU_ft)
		list_of_valid_line_fts = [ft for ft in line_features if ft.is_valid_at_time(reconstruction_time) and ft.get_feature_id() not in already_used_line_features]
		if (reference is not None):
			#tectonic_features
			pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			#line features
			pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			#SuperGDU features
			pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		else:
			#tectonic_features
			pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,group_with_feature = True)
			#line features
			pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
			#SuperGDU features
			pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
		print("number of valid line features")
		print(len(list_of_valid_tectonic_fts))
		final_reconstructed_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_tectonic_features, pygplates.PolylineOnSphere)
		print("number of final_reconstructed_tectonic_features")
		print(len(final_reconstructed_tectonic_features))
		final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features, pygplates.PolylineOnSphere)
		final_reconstructed_SuperGDU_ft_polygons = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features, pygplates.PolygonOnSphere)
		#polygon_fts_clean_polygons = clean_polygon_features_w_date_line_wrapper(rotation_model,list_of_valid_SuperGDU_fts,reconstruction_time,reference,modelname,yyyymmdd)
		for tectonic_ft, tectonic_line in final_reconstructed_tectonic_features:
			tectonic_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely_without_roundup_coords(tectonic_line)
			#for SuperGDU_ft, SuperGDU_polygon in polygon_fts_clean_polygons:
			for SuperGDU_ft, SuperGDU_polygon in final_reconstructed_SuperGDU_ft_polygons:
				# print('SuperGDU_polygon.get_area()')
				# print(SuperGDU_polygon.get_area())
				#SuperGDU_in_Shapely = supporting.convert_polygon_to_Polygon_in_shapely(SuperGDU_polygon)
				# if (SuperGDU_in_Shapely is None):
					# print ("Error in clean_up_messy_tectonic_boundaries")
					# print ("Error try to convert PolygonOnSphere to Polygon in Shapely")
					# print ("Error Polygon in Shapely is invalid")
					# list_of_lon_lat_vertices = [(lon,lat) for lat,lon in SuperGDU_polygon.to_lat_lon_list()]
					# new_polygon = Polygon(list_of_lon_lat_vertices)
					# print (explain_validity(new_polygon))
					# exit()
				# if (tectonic_line_in_Shapely.within(SuperGDU_in_Shapely)):
					# #invalid line ft --- need to modify
					# modified_tectonic_features.append(tectonic_ft.get_feature_id())
					# break
				
				#temporary working technique 
				# dilation_small = SuperGDU_in_Shapely.boundary.buffer(0.0000100)
				# if (tectonic_line_in_Shapely.crosses(dilation_small) == True):
					# dilation_big = SuperGDU_in_Shapely.boundary.buffer(0.500000)
					# if (tectonic_line_in_Shapely.crosses(dilation_big) == True):
						# #debug
						# # if (tectonic_ft.get_reconstruction_plate_id() == 10752 and tectonic_ft.get_name() == 'continental_rift_10752_10911' and reconstruction_time < 120.00):
							# # print('Error to identify continental_rift_10752_10911 having issue')
							# # print('SuperGDU_ft boundary that the line was crossing dilation')
							# # print(SuperGDU_ft.get_reconstruction_plate_id())
							# # print(SuperGDU_ft.get_name())
							# # print('At reconstruction_time')
							# # print(reconstruction_time)
							# # exit()
						
						# #invalid line ft --- need to modify
						# features_to_be_modified.append(tectonic_ft.get_feature_id())
						# modified_tectonic_features.append(tectonic_ft.get_feature_id())
						# break
				# elif (tectonic_line_in_Shapely.within(SuperGDU_in_Shapely)):
					# if (SuperGDU_polygon.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.inside):
						# #print('PolygonOnSphere.PartitionResult.inside')
						# #invalid line ft --- need to modify
						# features_to_be_modified.append(tectonic_ft.get_feature_id())
						# modified_tectonic_features.append(tectonic_ft.get_feature_id())
						
						# #debug
						# # if (tectonic_ft.get_reconstruction_plate_id() == 10752 and tectonic_ft.get_name() == 'continental_rift_10752_10911' and reconstruction_time < 120.00):
							# # print('Error to identify continental_rift_10752_10911 having issue')
							# # print('SuperGDU_ft boundary that the line was crossing')
							# # print(SuperGDU_ft.get_reconstruction_plate_id())
							# # print(SuperGDU_ft.get_name())
							# # print('At reconstruction_time')
							# # print(reconstruction_time)
							# # exit()

						# break	
				
				#testing technique only using PolygonOnSphere
				if (SuperGDU_polygon.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.inside):
						#print('PolygonOnSphere.PartitionResult.inside')
						#invalid line ft --- need to modify
						features_to_be_modified.append(tectonic_ft.get_feature_id())
						modified_tectonic_features.append(tectonic_ft.get_feature_id())
						break
		print("number of line features need to be modified")
		print(len(features_to_be_modified))
		for tectonic_ft in list_of_valid_tectonic_fts:
			if (tectonic_ft.get_feature_id() in features_to_be_modified):
				current_begin_age, current_end_age = tectonic_ft.get_valid_time()
				modified_ft = tectonic_ft.clone()
				print("current begin age")
				print(current_begin_age)
				print("current end age")
				print(current_end_age)
				print("reconstruction_time")
				print(reconstruction_time)
				if (current_begin_age > reconstruction_time):
					modified_ft.set_valid_time(current_begin_age, reconstruction_time + 0.0500)
					output_tectonic_features.append(modified_ft)
				if (current_end_age < reconstruction_time):
					found_ft = False
					#print("Enter the for-loop to find the new line feature")
					for line_ft, line in final_reconstructed_line_features:
						if (line_ft.get_reconstruction_plate_id() == tectonic_ft.get_reconstruction_plate_id()):
							line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely_without_roundup_coords(line)
							#for SuperGDU_ft, SuperGDU_polygon in polygon_fts_clean_polygons:
							for SuperGDU_ft, SuperGDU_polygon in final_reconstructed_SuperGDU_ft_polygons:
								#SuperGDU_in_Shapely = supporting.convert_polygon_to_Polygon_in_shapely(SuperGDU_polygon)
								#dilation = SuperGDU_in_Shapely.boundary.buffer(0.500000)
								#if (line_in_Shapely.within(dilation) == True and SuperGDU_polygon.partition(line) != pygplates.PolygonOnSphere.PartitionResult.inside):
								if (SuperGDU_polygon.partition(line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
									new_tectonic_ft = tectonic_ft.clone()
									# if (reference is not None):
										# pygplates.reverse_reconstruct(new_tectonic_ft,rotation_model,reconstruction_time,reference)
									# else:
										# pygplates.reverse_reconstruct(new_tectonic_ft,rotation_model,reconstruction_time)
									new_tectonic_ft.set_valid_time(reconstruction_time, current_end_age)
									tectonic_features.append(new_tectonic_ft)
									found_ft = True
									print("found new_tectonic_ft with dilation of boundary contains line_in_Shapely")
									break
						if (found_ft == True):
							already_used_line_features.append(line_ft.get_feature_id())
							break				
					if (found_ft == False):
						if ((reconstruction_time - interval)> current_end_age):
							new_ft = tectonic_ft.clone()
							new_ft.set_valid_time(reconstruction_time - interval, current_end_age)
							tectonic_features.append(new_ft)
		#clean up all features_to_be_modified at the reconstruction time to be ready for the next time
		features_to_be_modified[:] = []
		#update reconstruction_time
		reconstruction_time = reconstruction_time - interval
	valid_tectonic_fts = [ft for ft in tectonic_features if ft.get_feature_id() not in modified_tectonic_features]
	print("final number of modified_tectonic_features")
	print(len(modified_tectonic_features))
	print("number of final tectonic_features")
	print(len(tectonic_features))
	print("number of valid_tectonic_fts")
	print(len(valid_tectonic_fts))
	print("number of output_tectonic_features before adding valid features")
	print(len(output_tectonic_features))
	for valid_ft in valid_tectonic_fts:
		output_tectonic_features.append(valid_ft)
	print("number of output_tectonic_features")
	print(len(output_tectonic_features))
	outputLinesFeatureCollection = pygplates.FeatureCollection(output_tectonic_features)
	outputLinesFile = "output_valid_tectonic_features_"+str(begin)+"_"+str(end)+"_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "output_valid_tectonic_features_"+str(begin)+"_"+str(end)+"_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)	

def filter_features_with_valid_period_smaller_than_thresold(feature_collection,threshold_period,name_of_outputfile,included_shp,yyyymmdd):
	final_output_features = []
	for ft in feature_collection:
		ft_begin_age, ft_end_age = ft.get_valid_time()
		if (ft_begin_age - ft_end_age >= threshold_period):
			final_output_features.append(ft)
	outputFeatureCollection = pygplates.FeatureCollection(final_output_features)
	outputFeatureCollection.write(name_of_outputfile+"_"+yyyymmdd+".gpml")
	if (included_shp == True):
		outputFeatureCollection.write(name_of_outputfile+"_"+yyyymmdd+".shp")

def filter_features_with_duplicates(feature_collection, begin, end, interval, modelname, yyyymmdd, test_number):
	already_proccessed_ft = []
	output_features = []
	dic = {}
	other_features = []
	#maybe create a another sub module to find features having similar geometry
	for ft in feature_collection:
		print('len(already_proccessed_ft)')
		print(len(already_proccessed_ft))
		name_of_ft = ft.get_name()
		featType_of_ft = ft.get_feature_type()
		ft_id = ft.get_feature_id().get_string()
		if (ft_id not in already_proccessed_ft):
			other_features = [other_ft for other_ft in feature_collection if (ft.get_feature_id() != other_ft.get_feature_id() and ft.get_name() == other_ft.get_name() and ft.get_description() == other_ft.get_description())]
			list_of_temporal_fts = find_other_features_w_similar_geometry(ft,other_features)
			for similar_ft in list_of_temporal_fts:
				already_proccessed_ft.append(similar_ft.get_feature_id().get_string())
			dic[ft_id] = list_of_temporal_fts
	print('number_of_fts in dic')
	print(len(dic))
	for represent_ft_id in dic.keys():
		print('represent_ft_id')
		print(represent_ft_id)
		list_of_same_geometry_ft = dic[represent_ft_id]
		print('len(list_of_same_geometry_ft)')
		print(len(list_of_same_geometry_ft))
		list_of_final_fts = finalize_tectonic_boundary_feature_from_duplicates(list_of_same_geometry_ft)
		print('len(list_of_final_fts)')
		print(len(list_of_final_fts))
		# #debug
		# temp_ft_from_final_fts = list_of_final_fts[0]
		# if (temp_ft_from_final_fts.get_reconstruction_plate_id() == 10389):
			# print('here is len of list_of_final_fts')
			# print(len(list_of_final_fts))
		for final_tectonic_ft in list_of_final_fts:	
			output_features.append(final_tectonic_ft)
	print('number of features in output_features')
	print(len(output_features))
	
	outputFeatureCollection = pygplates.FeatureCollection(output_features)
	outputFeatureFile = "test_"+str(test_number)+'_filter_features_with_duplicates_'+str(begin)+'_'+str(end)+'_'+str(interval)+'_'+modelname+'_'+yyyymmdd+'.shp'
	outputFeatureCollection.write(outputFeatureFile)
	outputFeatureFile = "test_"+str(test_number)+'_filter_features_with_duplicates'+str(begin)+'_'+str(end)+'_'+str(interval)+'_'+modelname+'_'+yyyymmdd+'.gpml'
	outputFeatureCollection.write(outputFeatureFile)

def resolve_uncertain_tectonic_boundaries(rotation_model, tectonic_features, GDU_fts, reference, modelname, yyyymmdd, test_number, included_shp):
	convergent_features = []
	divergent_features = []
	reconstructed_fts_1 = []
	reconstructed_fts_2 = []
	final_output_features_w_no_confusion = []
	already_included_in_final = []
	for feature in tectonic_features:
		if (feature.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
			divergent_features.append(feature)
		elif (feature.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone):
			convergent_features.append(feature)
	already_proccessed_ft = []
	dic = {}
	if (len(convergent_features) > len(divergent_features)):
		for each_convergent_ft in convergent_features:
			if (each_convergent_ft.get_feature_id().get_string() not in dic):
				if (each_convergent_ft.get_feature_id() not in already_proccessed_ft):
					similar_fts = find_other_features_w_similar_geometry(each_convergent_ft,divergent_features)
					dic[each_convergent_ft.get_feature_id().get_string()] = []
					for s in similar_fts:
						already_proccessed_ft.append(s.get_feature_id().get_string())
						dic[each_convergent_ft.get_feature_id().get_string()].append(s.clone())
		for each_divergent_ft in divergent_features:
			if (each_divergent_ft.get_feature_id().get_string() not in already_proccessed_ft):
				final_output_features_w_no_confusion.append(each_divergent_ft.clone())
				
	else:
		for each_divergent_ft in divergent_features:
			if (each_divergent_ft.get_feature_id().get_string() not in dic):
				if (each_divergent_ft.get_feature_id() not in already_proccessed_ft):
					similar_fts = find_other_features_w_similar_geometry(each_divergent_ft,convergent_features)
					dic[each_divergent_ft.get_feature_id().get_string()] = []
					for s in similar_ft:
						already_proccessed_ft.append(s.get_feature_id().get_string())
						dic[each_divergent_ft.get_feature_id().get_string()].append(s.clone())
		for each_convergent_ft in convergent_features:
			if (each_convergent_ft.get_feature_id().get_string() not in already_proccessed_ft):
				final_output_features_w_no_confusion.append(each_convergent_ft.clone())
	
	eliminated_features = []
	for key in dic.keys():
		similar_fts = dic[key]
		for ft_1 in similar_fts:
			for ft_2 in similar_fts:
				if (ft_1.get_feature_id() != ft_2.get_feature_id()):
					if (ft_1.get_feature_type() != ft_2.get_feature_type()):
						#begin_1,end_1,begin_2,end_2,specialized_for_possible_subduction_zone_valid,interval_time_for_kin_eval,verbose
						begin_1,end_1 = ft_1.get_valid_time()
						begin_2,end_2 = ft_2.get_valid_time()
						if(is_two_time_periods_overlapping(begin_1,end_1,begin_2,end_2,False,5.00,False)):
							if ((ft_1.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone and ft_2.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary) or \
								(ft_2.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone and ft_1.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary)):
								if (ft_1.get_description() == 'upper_plate_margin' or ft_2.get_description() == 'upper_plate_margin'):
									reconstruction_time = 0.00
									if (end_1 < begin_2):
										#reconstruct to begin_2 age
										reconstruction_time = begin_2
									elif (end_2 < begin_1):
										#reconstruct to begin_1 age
										reconstruction_time = begin_1
									temp_left_ft_1 = None
									temp_right_ft_1 = None
									for gdu_ft in GDU_fts:
										if (gdu_ft.get_reconstruction_plate_id() == ft_1.get_left_plate()):
											temp_left_ft_1 = gdu_ft
										elif (gdu_ft.get_reconstruction_plate_id() == ft_1.get_right_plate()):
											temp_right_ft_1 = gdu_ft
										if (temp_left_ft_1 is not None and temp_right_ft_1 is not None):
											break
									distance_1 = -1.00
									reconstructed_fts_1[:] = [] 
									if (reference is not None):
										pygplates.reconstruct([temp_left_ft_1,temp_right_ft_1],rotation_model,reconstructed_fts_1,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
										final_reconstructed_fts_1 = supporting.find_final_reconstructed_geometries(reconstructed_fts_1,pygplates.PolylineOnSphere)
										_,left_polygon_1 = final_reconstructed_fts_1[0]
										_,right_polygon_1 = final_reconstructed_fts_1[1]
										distance_1 = pygplates.GeometryOnSphere.distance(left_polygon_1,right_polygon_1)
									else:
										pygplates.reconstruct([temp_left_ft_1,temp_right_ft_1],rotation_model,reconstructed_fts_1,reconstruction_time,group_with_feature = True)
										final_reconstructed_fts_1 = supporting.find_final_reconstructed_geometries(reconstructed_fts_1,pygplates.PolylineOnSphere)
										_,left_polygon_1 = final_reconstructed_fts_1[0]
										_,right_polygon_1 = final_reconstructed_fts_1[1]
										distance_1 = pygplates.GeometryOnSphere.distance(left_polygon_1,right_polygon_1)
									temp_right_ft_2 = None
									temp_left_ft_2 = None 
									for gdu_ft in GDU_fts:
										if (gdu_ft.get_reconstruction_plate_id() == ft_2.get_left_plate()):
											temp_left_ft_2 = gdu_ft
										elif (gdu_ft.get_reconstruction_plate_id() == ft_2.get_right_plate()):
											temp_right_ft_2 = gdu_ft
										if (temp_left_ft_2 is not None and temp_right_ft_2 is not None):
											break
									distance_2 = -1.00
									reconstructed_fts_2[:] = []
									if (reference is not None):
										pygplates.reconstruct([temp_left_ft_2,temp_right_ft_2],rotation_model,reconstructed_fts_2,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
										final_reconstructed_fts_2 = supporting.find_final_reconstructed_geometries(reconstructed_fts_2,pygplates.PolylineOnSphere)
										_,left_polygon_2 = final_reconstructed_fts_2[0]
										_,right_polygon_2 = final_reconstructed_fts_2[1]
										distance_2 = pygplates.GeometryOnSphere.distance(left_polygon_2,right_polygon_2)
									else:
										pygplates.reconstruct([temp_left_ft_2,temp_right_ft_2],rotation_model,reconstructed_fts_2,reconstruction_time, group_with_feature = True)
										final_reconstructed_fts_2 = supporting.find_final_reconstructed_geometries(reconstructed_fts_2,pygplates.PolylineOnSphere)
										_,left_polygon_2 = final_reconstructed_fts_2[0]
										_,right_polygon_2 = final_reconstructed_fts_2[1]
										distance_2 = pygplates.GeometryOnSphere.distance(left_polygon_2,right_polygon_2)
									if (distance_1 > distance_2):
										if (ft_2.get_feature_id().get_string() not in already_included_in_final):
											final_output_features_w_no_confusion.append(ft_2.clone())
											already_included_in_final.append(ft_2.get_feature_id().get_string())
											eliminated_features.append(ft_1.get_feature_id().get_string())
									else:
										if (ft_1.get_feature_id().get_string() not in already_included_in_final):
											final_output_features_w_no_confusion.append(ft_1.clone())
											already_included_in_final.append(ft_1.get_feature_id().get_string())
											eliminated_features.append(ft_2.get_feature_id().get_string())
								else:
									if (ft_1.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
										final_output_features_w_no_confusion.append(ft_1.clone())
										already_included_in_final.append(ft_1.get_feature_id().get_string())
									elif (ft_2.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
										final_output_features_w_no_confusion.append(ft_2.clone())
										already_included_in_final.append(ft_2.get_feature_id().get_string())
				else:
					if (len(similar_fts) == 1):
						already_included_in_final.append(ft_1.get_feature_id().get_string())
						final_output_features_w_no_confusion.append(ft_1.clone())	
		for ft in similar_fts:
			if (ft.get_feature_id().get_string() not in eliminated_features and ft.get_feature_id().get_string() not in already_included_in_final):
				final_output_features_w_no_confusion.append(ft.clone())
	
	outputLinesFeatureCollection = pygplates.FeatureCollection(final_output_features_w_no_confusion)
	if (included_shp == True):
		outputLinesFile = str(test_number)+"_final_output_features_w_no_confusion"+modelname+"_"+yyyymmdd+".shp"
		outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = str(test_number)+"_final_output_features_w_no_confusion"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)
				
def resolve_uncertain_tectonic_boundaries_withouth_inferred_convergent_margins(rotation_model, tectonic_features, GDU_fts, reference, modelname, yyyymmdd, test_number, included_shp):
	convergent_features = []
	divergent_features = []
	reconstructed_fts_1 = []
	reconstructed_fts_2 = []
	final_output_features_w_no_confusion = []
	already_included_in_final = []
	for feature in tectonic_features:
		if (feature.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
			divergent_features.append(feature)
		elif (feature.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone):
			convergent_features.append(feature)
	already_proccessed_ft = []
	dic = {}
	if (len(convergent_features) > len(divergent_features)):
		for each_convergent_ft in convergent_features:
			if (each_convergent_ft.get_feature_id().get_string() not in dic):
				if (each_convergent_ft.get_feature_id() not in already_proccessed_ft):
					similar_fts = find_other_features_w_similar_geometry(each_convergent_ft,divergent_features)
					dic[each_convergent_ft.get_feature_id().get_string()] = []
					for s in similar_fts:
						already_proccessed_ft.append(s.get_feature_id().get_string())
						dic[each_convergent_ft.get_feature_id().get_string()].append(s.clone())
		for each_divergent_ft in divergent_features:
			if (each_divergent_ft.get_feature_id().get_string() not in already_proccessed_ft):
				final_output_features_w_no_confusion.append(each_divergent_ft.clone())	
	else:
		for each_divergent_ft in divergent_features:
			if (each_divergent_ft.get_feature_id().get_string() not in dic):
				if (each_divergent_ft.get_feature_id() not in already_proccessed_ft):
					similar_fts = find_other_features_w_similar_geometry(each_divergent_ft,convergent_features)
					dic[each_divergent_ft.get_feature_id().get_string()] = []
					for s in similar_ft:
						already_proccessed_ft.append(s.get_feature_id().get_string())
						dic[each_divergent_ft.get_feature_id().get_string()].append(s.clone())
		for each_convergent_ft in convergent_features:
			if (each_convergent_ft.get_feature_id().get_string() not in already_proccessed_ft):
				final_output_features_w_no_confusion.append(each_convergent_ft.clone())
	
	eliminated_features = []
	for key in dic.keys():
		similar_fts = dic[key]
		for ft_1 in similar_fts:
			for ft_2 in similar_fts:
				if (ft_1.get_feature_id() != ft_2.get_feature_id()):
					if (ft_1.get_feature_type() != ft_2.get_feature_type()):
						#begin_1,end_1,begin_2,end_2,specialized_for_possible_subduction_zone_valid,interval_time_for_kin_eval,verbose
						begin_1,end_1 = ft_1.get_valid_time()
						begin_2,end_2 = ft_2.get_valid_time()
						if(is_two_time_periods_overlapping(begin_1,end_1,begin_2,end_2,False,5.00,False)):
							if ((ft_1.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone and ft_2.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary) or \
								(ft_2.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone and ft_1.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary)):
								if (ft_1.get_description() == 'upper_plate_margin' or ft_2.get_description() == 'upper_plate_margin'):
									reconstruction_time = 0.00
									if (end_1 < begin_2):
										#reconstruct to begin_2 age
										reconstruction_time = begin_2
									elif (end_2 < begin_1):
										#reconstruct to begin_1 age
										reconstruction_time = begin_1
									temp_left_ft_1 = None
									temp_right_ft_1 = None
									for gdu_ft in GDU_fts:
										if (gdu_ft.get_reconstruction_plate_id() == ft_1.get_left_plate()):
											temp_left_ft_1 = gdu_ft
										elif (gdu_ft.get_reconstruction_plate_id() == ft_1.get_right_plate()):
											temp_right_ft_1 = gdu_ft
										if (temp_left_ft_1 is not None and temp_right_ft_1 is not None):
											break
									distance_1 = -1.00
									reconstructed_fts_1[:] = [] 
									if (reference is not None):
										pygplates.reconstruct([temp_left_ft_1,temp_right_ft_1],rotation_model,reconstructed_fts_1,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
										final_reconstructed_fts_1 = supporting.find_final_reconstructed_geometries(reconstructed_fts_1,pygplates.PolylineOnSphere)
										_,left_polygon_1 = final_reconstructed_fts_1[0]
										_,right_polygon_1 = final_reconstructed_fts_1[1]
										distance_1 = pygplates.GeometryOnSphere.distance(left_polygon_1,right_polygon_1)
									else:
										pygplates.reconstruct([temp_left_ft_1,temp_right_ft_1],rotation_model,reconstructed_fts_1,reconstruction_time,group_with_feature = True)
										final_reconstructed_fts_1 = supporting.find_final_reconstructed_geometries(reconstructed_fts_1,pygplates.PolylineOnSphere)
										_,left_polygon_1 = final_reconstructed_fts_1[0]
										_,right_polygon_1 = final_reconstructed_fts_1[1]
										distance_1 = pygplates.GeometryOnSphere.distance(left_polygon_1,right_polygon_1)
									temp_right_ft_2 = None
									temp_left_ft_2 = None 
									for gdu_ft in GDU_fts:
										if (gdu_ft.get_reconstruction_plate_id() == ft_2.get_left_plate()):
											temp_left_ft_2 = gdu_ft
										elif (gdu_ft.get_reconstruction_plate_id() == ft_2.get_right_plate()):
											temp_right_ft_2 = gdu_ft
										if (temp_left_ft_2 is not None and temp_right_ft_2 is not None):
											break
									distance_2 = -1.00
									reconstructed_fts_2[:] = []
									if (reference is not None):
										pygplates.reconstruct([temp_left_ft_2,temp_right_ft_2],rotation_model,reconstructed_fts_2,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
										final_reconstructed_fts_2 = supporting.find_final_reconstructed_geometries(reconstructed_fts_2,pygplates.PolylineOnSphere)
										_,left_polygon_2 = final_reconstructed_fts_2[0]
										_,right_polygon_2 = final_reconstructed_fts_2[1]
										distance_2 = pygplates.GeometryOnSphere.distance(left_polygon_2,right_polygon_2)
									else:
										pygplates.reconstruct([temp_left_ft_2,temp_right_ft_2],rotation_model,reconstructed_fts_2,reconstruction_time, group_with_feature = True)
										final_reconstructed_fts_2 = supporting.find_final_reconstructed_geometries(reconstructed_fts_2,pygplates.PolylineOnSphere)
										_,left_polygon_2 = final_reconstructed_fts_2[0]
										_,right_polygon_2 = final_reconstructed_fts_2[1]
										distance_2 = pygplates.GeometryOnSphere.distance(left_polygon_2,right_polygon_2)
									if (distance_1 > distance_2):
										if (ft_2.get_feature_id().get_string() not in already_included_in_final):
											final_output_features_w_no_confusion.append(ft_2.clone())
											already_included_in_final.append(ft_2.get_feature_id().get_string())
											eliminated_features.append(ft_1.get_feature_id().get_string())
									else:
										if (ft_1.get_feature_id().get_string() not in already_included_in_final):
											final_output_features_w_no_confusion.append(ft_1.clone())
											already_included_in_final.append(ft_1.get_feature_id().get_string())
											eliminated_features.append(ft_2.get_feature_id().get_string())
								else:
									if (ft_1.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
										final_output_features_w_no_confusion.append(ft_1.clone())
										already_included_in_final.append(ft_1.get_feature_id().get_string())
									elif (ft_2.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
										final_output_features_w_no_confusion.append(ft_2.clone())
										already_included_in_final.append(ft_2.get_feature_id().get_string())
				else:
					if (len(similar_fts) == 1):
						already_included_in_final.append(ft_1.get_feature_id().get_string())
						final_output_features_w_no_confusion.append(ft_1.clone())	
		for ft in similar_fts:
			if (ft.get_feature_id().get_string() not in eliminated_features and ft.get_feature_id().get_string() not in already_included_in_final):
				final_output_features_w_no_confusion.append(ft.clone())
	
	outputLinesFeatureCollection = pygplates.FeatureCollection(final_output_features_w_no_confusion)
	if (included_shp == True):
		outputLinesFile = str(test_number)+"_final_output_features_w_no_confusion"+modelname+"_"+yyyymmdd+".shp"
		outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = str(test_number)+"_final_output_features_w_no_confusion"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)
	
def obtain_features_not_yet_been_classified_as_any_type_of_tectonic_boundary_from_candidate_features_at_age(at_age, classified_tectonic_feature_collection, candidate_tectonic_feature_collection):
	features_not_yet_been_classified = []
	valid_candidate_tectonic_feature = [candidate_ft for candidate_ft in candidate_tectonic_feature_collection if candidate_ft.is_valid_at_time(at_age)]
	valid_classified_tectonic_feature_collection = [classified_ft for classified_ft in classified_tectonic_feature_collection if classified_ft.is_valid_at_time(at_age)]
	for candidate_ft in valid_candidate_tectonic_feature:
		candidate_geometry = candidate_ft.get_geometry()
		if (candidate_geometry is None):
			print("Error in obtain_features_not_yet_been_classified_as_any_type_of_tectonic_boundary_from_candidate_features")
			print("candidate_ft.get_geometry() returns None")
			print("candidate_ft.get_geometries()")
			print(candidate_ft.get_geometries())
			print("candidate_ft.get_reconstruction_plate_id()")
			print(candidate_ft.get_reconstruction_plate_id())
			print("candidate_ft.get_name()")
			print(candidate_ft.get_name())
			exit()
		candidate_geometry_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(candidate_geometry)
		already_classified_candidate_geometry = False
		for classified_ft in valid_classified_tectonic_feature_collection:
			classified_geometry = classified_ft.get_geometry()
			if (classified_geometry is None):
				print("Error in obtain_features_not_yet_been_classified_as_any_type_of_tectonic_boundary_from_candidate_features")
				print("classified_ft.get_geometry() returns None")
				print("classified_ft.get_geometries()")
				print(classified_ft.get_geometries())
				print("classified_ft.get_reconstruction_plate_id()")
				print(classified_ft.get_reconstruction_plate_id())
				print("classified_ft.get_name()")
				print(classified_ft.get_name())
				exit()
			classified_geometry_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(classified_geometry)
			if (candidate_geometry_in_Shapely.almost_equals(classified_geometry_in_Shapely, decimal = 4)):
				already_classified_candidate_geometry = True
				break
		if (already_classified_candidate_geometry == False):
			features_not_yet_been_classified.append(candidate_ft)
	return features_not_yet_been_classified
			
def obtain_features_not_yet_been_classified_as_any_type_of_tectonic_boundary_from_candidate_features_within_age_period(modelname,from_age, to_age, age_interval, classified_tectonic_feature_collection, candidate_tectonic_feature_collection):
	at_age = from_age
	outputFeatureCollection = pygplates.FeatureCollection()
	while (at_age > (to_age - age_interval)):
		print('at_age')
		print(at_age)
		list_of_candidate_fts = obtain_features_not_yet_been_classified_as_any_type_of_tectonic_boundary_from_candidate_features_at_age(at_age, classified_tectonic_feature_collection, candidate_tectonic_feature_collection)
		temp_feature_collection = pygplates.FeatureCollection(list_of_candidate_fts)
		outputFeatureCollection.add(temp_feature_collection)
		at_age = at_age - age_interval
	outputFeatureFile = modelname+"_features_not_yet_been_classified_as_any_type_of_tectonic_boundary_within_age_period_"+str(from_age)+"_"+str(to_age)+"_"+str(age_interval)+".gpml"
	outputFeatureCollection.write(outputFeatureFile)

def identify_new_lines_for_feats_v1(input_featType,rotation_model, margin_line_features, tectonic_features, begin,end,interval,reference, only_single_gap, modelname,yyyymmdd):
	"""
	Find new passive_margin or upper_plate_margin feature to fill the gap between two known passive_margin or upper_plate_margin features
		Parameters:
			input_featType (pygplates.FeatureType)
			rot_file (str): A path included a rotation filename 
			margin_line_features (pygplates.FeatureCollection or list of features): line_features making up ONLY the margins of GDUs CON-OCN line features
			tectonic_features (pygplates.FeatureCollection or list of features): upper_plate_margin or passive margin features
			begin, end, interval (float): period of time and the time step 
			reference (int): a value that we use in rotation file as a reference frame - like spin axis or mantle
			only_single_gap (bool): a Boolean value from the user - find only a single gap between two tectonic features or multiple gaps
	"""
	rad_cutoff_prox_connecting_in_km = 1000.00
	reconstruction_time = begin
	
	final_candidate_lines = []
	list_of_ft_testing = []
	
	reconstructed_line_features = []
	reconstructed_tectonic_features = []
	final_line_fts = []
	final_tectonic_fts = []
	candidate_refs = []
	
	candidate_subduction_margins = []
	final_subduction_margins = []
	final_left_right_margins = []

	all_fts = []
	reconstructed_features = []
	#loop through reconstruction_time
	while(reconstruction_time > (end-interval)):
		print ("Here is reconstruction_time")
		print (reconstruction_time)
		list_of_valid_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time)]
		list_of_valid_line_fts = [ft for ft in margin_line_features if ft.is_valid_at_time(reconstruction_time)]
		
		reconstructed_line_features[:] = []
		reconstructed_tectonic_features[:] = [] 
		final_line_fts[:] = []
		final_tectonic_fts[:] = []

		candidate_refs[:] = []
		all_fts[:] = []
		
		if (len(list_of_valid_line_fts) > 0):
			if (reference is not None):
				#line_features
				pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				#line_features
				pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time, group_with_feature = True)
				
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time, group_with_feature = True)
			
			final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			final_reconstructed_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_tectonic_features,pygplates.PolylineOnSphere)
			
			#remove duplicates in terms of the geometries for both CON-OCN line features and tectonic_features
			for ft,line in final_reconstructed_line_features:
				#check for duplicates
				line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				if (len(final_line_fts) == 0):
					final_line_fts.append((ft,line))
				else:
					already_included = False
					for ft_2,line_2 in final_line_fts:
						if (ft_2.get_feature_id() != ft.get_feature_id()):
							line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
								already_included = True
								break
							else:
								already_included = False
					if (already_included == False):
						final_line_fts.append((ft,line))
			print('len(final_line_fts)')
			print(len(final_line_fts))
			for ft,line in final_reconstructed_tectonic_features:
				#check for duplicates
				line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				if (len(final_tectonic_fts) == 0):
					final_tectonic_fts.append((ft,line))
				else:
					already_included = False
					for ft_2,line_2 in final_tectonic_fts:
						if (ft_2.get_feature_id() != ft.get_feature_id()):
							line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
								already_included = True
								break
							else:
								already_included = False
					if (already_included == False):
						final_tectonic_fts.append((ft,line))
			print('len(final_tectonic_fts)')
			print(len(final_tectonic_fts))
			for line_ft,line in final_line_fts:
				plateID_of_line = line_ft.get_reconstruction_plate_id()
				line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				first_point_of_line = supporting.get_first_point_of_line(line)
				first_point_of_line_Shapely = Point(first_point_of_line.to_lat_lon())
				last_point_of_line = supporting.get_last_point_of_line(line)
				last_point_of_line_Shapely = Point(last_point_of_line.to_lat_lon())
				#we don't want to take points making a loop
				if (first_point_of_line_Shapely.almost_equals(last_point_of_line_Shapely, decimal = 4) == False):
					first_connected = None
					last_connected = None 
					valid  = True 
					#to make sure we don't duplicate already identified convergent feature 
					for subduction_margin_ft,subduction_margin_line in final_tectonic_fts:
						#calculate only the distance 
						subduction_margin_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(subduction_margin_line)
						#debug
						if (line_in_Shapely.almost_equals(subduction_margin_line_in_Shapely, decimal = 4)):
							valid = False
							featType = line_ft.get_feature_type()
							ft = pygplates.Feature.create_reconstructable_feature(featType,line,valid_time = (reconstruction_time,reconstruction_time-interval),reconstruction_plate_id = plateID_of_line)
							pygplates.reverse_reconstruct(ft,rotation_model,reconstruction_time,reference)
							list_of_ft_testing.append(ft)
							break
					#to find the two subduction_margin_ft between any two subduction_margin_fts
					if (valid == True):
						candidate_refs[:] = []
						candidate_subduction_margins[:] = []
						for subduction_margin_ft,subduction_margin_line in final_tectonic_fts:
							subduction_margin_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(subduction_margin_line)
							distance, p_line, p_margin = supporting.calculate_distance_between_end_nodes_in_km(line, subduction_margin_line)
							p_line_in_Shapely = Point(p_line.to_lat_lon())
							p_margin_in_Shapely = Point(p_margin.to_lat_lon())
							if (distance <= rad_cutoff_prox_connecting_in_km):
								# print('value of distance:')
								# print(distance)
								print('len(candidate_subduction_margins)')
								print(len(candidate_subduction_margins))
								if (len(candidate_subduction_margins) == 0):
									if (p_line_in_Shapely.almost_equals(p_margin_in_Shapely, decimal = 4)):
									#if (subduction_margin_line_in_Shapely.intersects(line_in_Shapely)):
										print('subduction_margin_line_in_Shapely.intersects(line_in_Shapely)')
										if (p_line_in_Shapely.almost_equals(first_point_of_line_Shapely, decimal = 4)):
											first_connected = first_point_of_line
										elif (p_line_in_Shapely.almost_equals(last_point_of_line_Shapely, decimal = 4)):
											last_connected = last_point_of_line
										else:
											print ("Error value of p_line is not equal to either first_point_of_line or last_point_of_line")
											exit()
										candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
										candidate_refs.append(subduction_margin_ft.get_feature_id())
								else:
									print('value of first_connected and last_connected:')
									print(first_connected,last_connected)
									if (first_connected == first_point_of_line and last_connected is None):
										if (p_line_in_Shapely.almost_equals(last_point_of_line_Shapely, decimal = 4)):
											if (only_single_gap == True):
												if (subduction_margin_line_in_Shapely.touches(line_in_Shapely)):
													if not (subduction_margin_ft.get_feature_id() in candidate_refs):
														if (valid == True):
															last_connected = last_point_of_line
															if (first_connected == last_connected):
																print ("Error first_connected == last_connected (1)")
																exit()
														candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
														candidate_refs.append(subduction_margin_ft.get_feature_id())
											else:
												if not (subduction_margin_ft.get_feature_id() in candidate_refs):
													if (valid == True):
														last_connected = last_point_of_line
														if (first_connected == last_connected):
															print ("Error first_connected == last_connected (1)")
															exit()
													candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
													candidate_refs.append(subduction_margin_ft.get_feature_id())

										#debug
										if (first_connected is not None and last_connected is not None):
											if (first_connected == last_connected):
												print ("Error first_connected == last_connected")
												exit()				
									elif (last_connected == last_point_of_line and first_connected is None):
										if (p_line_in_Shapely.almost_equals(first_point_of_line_Shapely, decimal = 4)):
											if (only_single_gap == True):
												if (subduction_margin_line_in_Shapely.touches(line_in_Shapely)):
													if not (subduction_margin_ft.get_feature_id() in candidate_refs):
														if (valid == True):
															first_connected = first_point_of_line
															if (first_connected == last_connected):
																print ("Error first_connected == last_connected (2)")
																exit()
															candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
															candidate_refs.append(subduction_margin_ft.get_feature_id())
											else:
												if not (subduction_margin_ft.get_feature_id() in candidate_refs):
													if (valid == True):
														first_connected = first_point_of_line
														if (first_connected == last_connected):
															print ("Error first_connected == last_connected (2)")
															exit()
														candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
														candidate_refs.append(subduction_margin_ft.get_feature_id())
										#debug
										if (first_connected is not None and last_connected is not None):
											if (first_connected == last_connected):
												print ("Error first_connected == last_connected")
												exit()
									elif (last_connected == first_point_of_line and first_connected is None):
										if (p_line_in_Shapely.almost_equals(last_point_of_line_Shapely, decimal = 4)):
											if (only_single_gap == True):
												if (subduction_margin_line_in_Shapely.touches(line_in_Shapely)):
													if not (subduction_margin_ft.get_feature_id() in candidate_refs):
														if (valid == True):
															first_connected = last_point_of_line
															if (first_connected == last_connected):
																print ("Error first_connected == last_connected (3)")
																exit()
															candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
															candidate_refs.append(subduction_margin_ft.get_feature_id())
											else:
												if not (subduction_margin_ft.get_feature_id() in candidate_refs):
													if (valid == True):
														first_connected = last_point_of_line
														if (first_connected == last_connected):
															print ("Error first_connected == last_connected (3)")
															exit()
														candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
														candidate_refs.append(subduction_margin_ft.get_feature_id())
										#debug
										if (first_connected is not None and last_connected is not None):
											if (first_connected == last_connected):
												print ("Error first_connected == last_connected")
												exit()
									elif (first_connected == last_point_of_line and last_connected is None):
										if (p_line_in_Shapely.almost_equals(first_point_of_line_Shapely,decimal = 4)):
											if (only_single_gap == True):
												if (subduction_margin_line_in_Shapely.touches(line_in_Shapely)):
													if not (subduction_margin_ft.get_feature_id() in candidate_refs):
														if (valid == True):
															last_connected = first_point_of_line
															if (first_connected == last_connected):
																print ("Error first_connected == last_connected (4)")
																exit()
															candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
															candidate_refs.append(subduction_margin_ft.get_feature_id())
											else:
												if not (subduction_margin_ft.get_feature_id() in candidate_refs):
													if (valid == True):
														last_connected = first_point_of_line
														if (first_connected == last_connected):
															print ("Error first_connected == last_connected (4)")
															exit()
														candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
														candidate_refs.append(subduction_margin_ft.get_feature_id())
										#debug
										if (first_connected is not None and last_connected is not None):
											if (first_connected == last_connected):
												print ("Error first_connected == last_connected")
												exit()
							if (len(candidate_subduction_margins) == 2):				
								break
				if (len(candidate_subduction_margins) > 1):
					if (first_connected is not None and last_connected is not None):
						first_connected_Shapely = Point(first_connected.to_lat_lon())
						last_connected_Shapely = Point(last_connected.to_lat_lon())
						subduction_margin_line_1 = candidate_subduction_margins[0][1]
						subduction_margin_line_2 = candidate_subduction_margins[1][1]
						subduction_margin_line_1_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(subduction_margin_line_1)
						subduction_margin_line_2_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(subduction_margin_line_2)
						if (only_single_gap == True):
							if ((subduction_margin_line_1_Shapely.touches(first_connected_Shapely) or subduction_margin_line_1_Shapely.touches(last_connected_Shapely))\
								and (subduction_margin_line_2_Shapely.touches(last_connected_Shapely) or subduction_margin_line_2_Shapely.touches(first_connected_Shapely))):
									max_age = -1.00
									oldest_ft = None
									min_age = -1.00
									for temp_ft,_ in candidate_subduction_margins:
										temp_max,temp_min = temp_ft.get_valid_time()
										if (temp_max > max_age):
											max_age = temp_max
											oldest_ft = temp_ft
										if (pygplates.GeoTimeInstant(temp_min).is_distant_future()):
											temp_min = 0.00
										if (min_age == -1.00 or (min_age > -1.00 and min_age > temp_min)):
											min_age = temp_min
									#create a new passive_margin ft from the two candidate_passive_margins features
									new_subduction_ft = pygplates.Feature.create_reconstructable_feature(input_featType,line,name= "inferred_tectonic_features_"+str(plateID_of_line),valid_time = (max_age,min_age),reconstruction_plate_id = plateID_of_line)
									left_id = oldest_ft.get_left_plate()
									right_id = oldest_ft.get_right_plate()
									if (oldest_ft.get_reconstruction_plate_id() == left_id):
										new_subduction_ft.set_left_plate(plateID_of_line)
										new_subduction_ft.set_right_plate(right_id)
									elif (oldest_ft.get_reconstruction_plate_id() == right_id):
										new_subduction_ft.set_right_plate(plateID_of_line)
										new_subduction_ft.set_left_plate(left_id)
									else:
										print("Suspecting left_id and right_id. None is the same as reconstruction_plate_id.")
										print(oldest_ft.get_reconstruction_plate_id())
										print('left,right')
										print(left_id,right_id)
									#reverse_reconstruct
									if (reference is None):
										pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time)
									else:
										pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time,reference)
									final_subduction_margins.append(new_subduction_ft)
						else:
							max_age = -1.00
							oldest_ft = None
							min_age = -1.00
							for temp_ft,_ in candidate_subduction_margins:
								temp_max,temp_min = temp_ft.get_valid_time()
								if (temp_max > max_age):
									max_age = temp_max
									oldest_ft = temp_ft
								if (pygplates.GeoTimeInstant(temp_min).is_distant_future()):
									temp_min = 0.00
								if (min_age == -1.00 or (min_age > -1.00 and min_age > temp_min)):
									min_age = temp_min
							#create a new passive_margin ft from the two candidate_passive_margins features
							new_subduction_ft = pygplates.Feature.create_reconstructable_feature(input_featType,line,name= "inferred_tectonic_features_"+str(plateID_of_line),valid_time = (max_age,min_age),reconstruction_plate_id = plateID_of_line)
							left_id = oldest_ft.get_left_plate()
							right_id = oldest_ft.get_right_plate()
							if (oldest_ft.get_reconstruction_plate_id() == left_id):
								new_subduction_ft.set_left_plate(plateID_of_line)
								new_subduction_ft.set_right_plate(right_id)
							elif (oldest_ft.get_reconstruction_plate_id() == right_id):
								new_subduction_ft.set_right_plate(plateID_of_line)
								new_subduction_ft.set_left_plate(left_id)
							else:
								print("Suspecting left_id and right_id. None is the same as reconstruction_plate_id.")
								print(oldest_ft.get_reconstruction_plate_id())
								print('left,right')
								print(left_id,right_id)
							#reverse_reconstruct
							if (reference is None):
								pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time)
							else:
								pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time,reference)
							final_subduction_margins.append(new_subduction_ft)
						candidate_subduction_margins[:] = []
						#reset first_connected and last_connected
						first_connected = None
						last_connected = None
					else:
						print("Error in identify_new_lines_for_feats")
						print("Error len(candidate_subduction_margins) > 1 but first_connected or last_connected is None")
						exit()
				# if (len(candidate_subduction_margins) == 1):
					# if (first_connected is not None or last_connected is not None):
						# max_age = -1.00
						# oldest_ft = None
						# min_age = -1.00
						# for temp_ft,_ in candidate_subduction_margins:
							# temp_max,temp_min = temp_ft.get_valid_time()
							# if (temp_max > max_age):
								# max_age = temp_max
								# oldest_ft = temp_ft
							# if (pygplates.GeoTimeInstant(temp_min).is_distant_future()):
								# temp_min = 0.00
							# if (min_age == -1.00 or (min_age > -1.00 and min_age > temp_min)):
								# min_age = temp_min
						# #create a new passive_margin ft from the two candidate_passive_margins features
						# new_subduction_ft = pygplates.Feature.create_reconstructable_feature(input_featType,line,name= "inferred_tectonic_features_"+str(plateID_of_line),valid_time = (max_age,min_age),reconstruction_plate_id = plateID_of_line)
						# left_id = oldest_ft.get_left_plate()
						# right_id = oldest_ft.get_right_plate()
						# if (oldest_ft.get_reconstruction_plate_id() == left_id):
							# new_subduction_ft.set_left_plate(plateID_of_line)
							# new_subduction_ft.set_right_plate(right_id)
						# elif (oldest_ft.get_reconstruction_plate_id() == right_id):
							# new_subduction_ft.set_right_plate(plateID_of_line)
							# new_subduction_ft.set_left_plate(left_id)
						# else:
							# print("Suspecting left_id and right_id. None is the same as reconstruction_plate_id.")
							# print(oldest_ft.get_reconstruction_plate_id())
							# print('left,right')
							# print(left_id,right_id)
						# #reverse_reconstruct
						# if (reference is None):
							# pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time)
						# else:
							# pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time,reference)
						# final_subduction_margins.append(new_subduction_ft)
						# candidate_subduction_margins[:] = []
						# #reset first_connected and last_connected
						# first_connected = None
						# last_connected = None
					# else:
						# print("Error in identify_new_lines_for_feats")
						# print("Error len(candidate_subduction_margins) == 1 but first_connected and last_connected are None")
						# exit()
		#update reconstruction_time
		reconstruction_time = reconstruction_time-interval
		
	print('number of new features')
	print(len(final_subduction_margins))
	#combine all tectonic_features together 
	list_of_all_tectonic_features = []
	for ft in final_subduction_margins:
		list_of_all_tectonic_features.append(ft)
	for ft in tectonic_features:
		list_of_all_tectonic_features.append(ft)
	
		
	outputLinesFeatureCollection = pygplates.FeatureCollection(final_subduction_margins)
	outputLinesFile = "new_approx_tectonic_features_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "new_approx_tectonic_features_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)
	
	outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_all_tectonic_features)
	outputLinesFile = "combined_all_tectonic_features_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "combined_all_tectonic_features_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)
	
	outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_ft_testing)
	outputLinesFile = "failed_line_features_for_examining_plate_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_ft_testing)
	outputLinesFile = "failed_line_features_for_examining_plate_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)

def identify_new_lines_for_feats_v2(input_featType,rotation_model, margin_line_features, tectonic_features, begin,end,interval,reference, only_single_gap, modelname,yyyymmdd):
	"""
	Find new passive_margin or upper_plate_margin feature to fill the gap between two known passive_margin or upper_plate_margin features
		Parameters:
			input_featType (pygplates.FeatureType)
			rot_file (str): A path included a rotation filename 
			margin_line_features (pygplates.FeatureCollection or list of features): line_features making up ONLY the margins of GDUs CON-OCN line features
			tectonic_features (pygplates.FeatureCollection or list of features): upper_plate_margin or passive margin features
			begin, end, interval (float): period of time and the time step 
			reference (int): a value that we use in rotation file as a reference frame - like spin axis or mantle
			only_single_gap (bool): a Boolean value from the user - find only a single gap between two tectonic features or multiple gaps
	"""
	rad_cutoff_prox_connecting_in_km = 1000.00
	reconstruction_time = begin
	
	final_candidate_lines = []
	list_of_ft_testing = []
	
	reconstructed_line_features = []
	reconstructed_tectonic_features = []
	final_line_fts = []
	final_tectonic_fts = []
	candidate_refs = []
	candidate_subduction_margins = []
	
	final_subduction_margins = []

	all_fts = []
	reconstructed_features = []
	#loop through reconstruction_time
	while(reconstruction_time > (end-interval)):
		print ("Here is reconstruction_time")
		print (reconstruction_time)
		list_of_valid_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time)]
		list_of_valid_line_fts = [ft for ft in margin_line_features if ft.is_valid_at_time(reconstruction_time)]
		
		reconstructed_line_features[:] = []
		reconstructed_tectonic_features[:] = [] 
		final_line_fts[:] = []
		final_tectonic_fts[:] = []

		candidate_refs[:] = []
		
		if (len(list_of_valid_line_fts) > 0):
			if (reference is not None):
				#line_features
				pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				#line_features
				pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time, group_with_feature = True)
				
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time, group_with_feature = True)
			
			final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			final_reconstructed_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_tectonic_features,pygplates.PolylineOnSphere)
			
			#remove duplicates in terms of the geometries for both CON-OCN line features and tectonic_features
			for ft,line in final_reconstructed_line_features:
				#check for duplicates
				line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				if (len(final_line_fts) == 0):
					final_line_fts.append((ft,line))
				else:
					already_included = False
					for ft_2,line_2 in final_line_fts:
						if (ft_2.get_feature_id() != ft.get_feature_id()):
							line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
								already_included = True
								break
							else:
								already_included = False
					if (already_included == False):
						final_line_fts.append((ft,line))
			print('len(final_line_fts)')
			print(len(final_line_fts))
			for ft,line in final_reconstructed_tectonic_features:
				#check for duplicates
				line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				if (len(final_tectonic_fts) == 0):
					final_tectonic_fts.append((ft,line))
				else:
					already_included = False
					for ft_2,line_2 in final_tectonic_fts:
						if (ft_2.get_feature_id() != ft.get_feature_id()):
							line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
								already_included = True
								break
							else:
								already_included = False
					if (already_included == False):
						final_tectonic_fts.append((ft,line))
			print('len(final_tectonic_fts)')
			print(len(final_tectonic_fts))
			for line_ft,line in final_line_fts:
				plateID_of_line = line_ft.get_reconstruction_plate_id()
				line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				first_point_of_line = supporting.get_first_point_of_line(line)
				first_point_of_line_Shapely = Point(first_point_of_line.to_lat_lon())
				last_point_of_line = supporting.get_last_point_of_line(line)
				last_point_of_line_Shapely = Point(last_point_of_line.to_lat_lon())
				#we don't want to take points making a loop
				if (first_point_of_line_Shapely.almost_equals(last_point_of_line_Shapely, decimal = 4) == False):
					valid  = True 
					#to make sure we don't duplicate already identified convergent feature 
					for subduction_margin_ft,subduction_margin_line in final_tectonic_fts:
						#calculate only the distance 
						subduction_margin_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(subduction_margin_line)
						#debug
						if (line_in_Shapely.almost_equals(subduction_margin_line_in_Shapely, decimal = 4)):
							valid = False
							featType = line_ft.get_feature_type()
							ft = pygplates.Feature.create_reconstructable_feature(featType,line,valid_time = (reconstruction_time,reconstruction_time-interval),reconstruction_plate_id = plateID_of_line)
							pygplates.reverse_reconstruct(ft,rotation_model,reconstruction_time,reference)
							list_of_ft_testing.append(ft)
							break
					#to find the two subduction_margin_ft between any two subduction_margin_fts
					if (valid == True):
						candidate_refs[:] = []
						candidate_subduction_margins[:] = []
						for subduction_margin_ft,subduction_margin_line in final_tectonic_fts:
							subduction_margin_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(subduction_margin_line)
							distance, p_line, p_margin = supporting.calculate_distance_between_end_nodes_in_km(line, subduction_margin_line)
							if (len(candidate_refs) == 0):
								if (line_in_Shapely.touches(subduction_margin_line_in_Shapely)):
									if (subduction_margin_ft.get_feature_id() not in candidate_refs):
										candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
										candidate_refs.append(subduction_margin_ft.get_feature_id())
							elif (len(candidate_refs) == 1):
								if (line_in_Shapely.touches(subduction_margin_line_in_Shapely) or distance <= rad_cutoff_prox_connecting_in_km):
									current_subduction_margin_line = candidate_subduction_margins[0][1]
									current_subduction_margin_line_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(current_subduction_margin_line)
									if (current_subduction_margin_line_Shapely.disjoint(subduction_margin_line_in_Shapely)):
										candidate_subduction_margins.append((subduction_margin_ft,subduction_margin_line))
										candidate_refs.append(subduction_margin_ft.get_feature_id())
							if(len(candidate_refs) == 2):
								break
						if (len(candidate_refs) == 2):
							max_age = -1.00
							oldest_ft = None
							min_age = -1.00
							for temp_ft,_ in candidate_subduction_margins:
								temp_max,temp_min = temp_ft.get_valid_time()
								if (temp_max > max_age):
									max_age = temp_max
									oldest_ft = temp_ft
								if (pygplates.GeoTimeInstant(temp_min).is_distant_future()):
									temp_min = 0.00
								if (min_age == -1.00 or (min_age > -1.00 and min_age > temp_min)):
									min_age = temp_min
							#create a new passive_margin ft from the two candidate_passive_margins features
							new_subduction_ft = pygplates.Feature.create_reconstructable_feature(input_featType,line,name= "inferred_tectonic_features_"+str(plateID_of_line),valid_time = (max_age,min_age),reconstruction_plate_id = plateID_of_line)
							left_id = oldest_ft.get_left_plate()
							right_id = oldest_ft.get_right_plate()
							if (oldest_ft.get_reconstruction_plate_id() == left_id):
								new_subduction_ft.set_left_plate(plateID_of_line)
								new_subduction_ft.set_right_plate(right_id)
							elif (oldest_ft.get_reconstruction_plate_id() == right_id):
								new_subduction_ft.set_right_plate(plateID_of_line)
								new_subduction_ft.set_left_plate(left_id)
							else:
								print("Suspecting left_id and right_id. None is the same as reconstruction_plate_id.")
								print(oldest_ft.get_reconstruction_plate_id())
								print('left,right')
								print(left_id,right_id)
							#reverse_reconstruct
							if (reference is None):
								pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time)
							else:
								pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time,reference)
							final_subduction_margins.append(new_subduction_ft)
							#update new_subduction_ft
							new_list_of_valid_tectonic_fts = [ft for ft in list_of_valid_tectonic_fts if ft.get_feature_id() not in candidate_refs]
							new_list_of_valid_tectonic_fts.append(new_subduction_ft)
							reconstructed_tectonic_features[:] = []
							final_tectonic_fts[:] = []
							if (reference is not None):
								#tectonic_features
								pygplates.reconstruct(new_list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								#tectonic_features
								pygplates.reconstruct(new_list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time, group_with_feature = True)
							final_reconstructed_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_tectonic_features,pygplates.PolylineOnSphere)
							for ft,line in final_reconstructed_tectonic_features:
								#check for duplicates
								line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
								if (len(final_tectonic_fts) == 0):
									final_tectonic_fts.append((ft,line))
								else:
									already_included = False
									for ft_2,line_2 in final_tectonic_fts:
										if (ft_2.get_feature_id() != ft.get_feature_id()):
											line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
											if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
												already_included = True
												break
											else:
												already_included = False
									if (already_included == False):
										final_tectonic_fts.append((ft,line))
							print('len(final_tectonic_fts)')
							print(len(final_tectonic_fts))
						candidate_subduction_margins[:] = []
						candidate_refs[:] = []
		#update reconstruction_time
		reconstruction_time = reconstruction_time-interval
		
	print('number of new features')
	print(len(final_subduction_margins))
	#combine all tectonic_features together 
	list_of_all_tectonic_features = []
	for ft in final_subduction_margins:
		list_of_all_tectonic_features.append(ft)
	for ft in tectonic_features:
		list_of_all_tectonic_features.append(ft)
	
		
	outputLinesFeatureCollection = pygplates.FeatureCollection(final_subduction_margins)
	outputLinesFile = "new_approx_tectonic_features_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "new_approx_tectonic_features_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)
	
	outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_all_tectonic_features)
	outputLinesFile = "combined_all_tectonic_features_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "combined_all_tectonic_features_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)
	
	outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_ft_testing)
	outputLinesFile = "failed_line_features_for_examining_plate_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_ft_testing)
	outputLinesFile = "failed_line_features_for_examining_plate_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)

def identify_new_lines_for_feats_V3(input_featType,rotation_model, margin_line_features, tectonic_features, begin,end,interval,reference, only_single_gap, modelname,yyyymmdd):
	"""
	Find new passive_margin or upper_plate_margin feature to fill the gap between two known passive_margin or upper_plate_margin features
		Parameters:
			input_featType (pygplates.FeatureType)
			rot_file (str): A path included a rotation filename 
			margin_line_features (pygplates.FeatureCollection or list of features): line_features making up ONLY the margins of GDUs CON-OCN line features
			tectonic_features (pygplates.FeatureCollection or list of features): upper_plate_margin or passive margin features
			begin, end, interval (float): period of time and the time step 
			reference (int): a value that we use in rotation file as a reference frame - like spin axis or mantle
			only_single_gap (bool): a Boolean value from the user - find only a single gap between two tectonic features or multiple gaps
	"""
	rad_cutoff_prox_connecting_in_km = 1000.00
	reconstruction_time = begin
	
	final_candidate_lines = []
	list_of_ft_testing = []
	
	reconstructed_line_features = []
	reconstructed_tectonic_features = []
	final_line_fts = []
	final_line_fts_2 = []
	possible_line_fts = []
	final_tectonic_fts = []
	final_tectonic_fts_2 = []
	dic = {}
	candidate_refs = []
	temp_candidate_refs = []
	candidate_subduction_margins = []
	
	final_subduction_margins = []
	
	final_pair_of_tectonic_fts = []
	
	final_fts = []

	all_fts = []
	reconstructed_features = []
	already_included_tectonic_ft_1 = []
	#loop through reconstruction_time
	while(reconstruction_time > (end-interval)):
		print ("Here is reconstruction_time")
		print (reconstruction_time)
		list_of_valid_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time)]
		list_of_valid_line_fts = [ft for ft in margin_line_features if ft.is_valid_at_time(reconstruction_time)]
		
		reconstructed_line_features[:] = []
		reconstructed_tectonic_features[:] = [] 
		final_line_fts[:] = []
		final_line_fts_2[:] = []
		final_tectonic_fts[:] = []
		final_tectonic_fts_2[:] = []

		candidate_refs[:] = []
		
		final_pair_of_tectonic_fts[:] = []
		
		if (len(list_of_valid_line_fts) > 0):
			if (reference is not None):
				#line_features
				pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				#line_features
				pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time, group_with_feature = True)
				
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time, group_with_feature = True)
			
			final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			final_reconstructed_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_tectonic_features,pygplates.PolylineOnSphere)
			
			#remove duplicates in terms of the geometries for both CON-OCN line features and tectonic_features
			for ft,line in final_reconstructed_line_features:
				#check for duplicates
				line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				if (len(final_line_fts) == 0):
					final_line_fts.append((ft,line))
				else:
					already_included = False
					for ft_2,line_2 in final_line_fts:
						if (ft_2.get_feature_id() != ft.get_feature_id()):
							line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
								already_included = True
								break
							else:
								already_included = False
					if (already_included == False):
						final_line_fts.append((ft,line))
			print('len(final_line_fts)')
			print(len(final_line_fts))
			
			for ft,line in final_reconstructed_tectonic_features:
				#check for duplicates
				line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				if (len(final_tectonic_fts) == 0):
					final_tectonic_fts.append((ft,line))
				else:
					already_included = False
					for ft_2,line_2 in final_tectonic_fts:
						if (ft_2.get_feature_id() != ft.get_feature_id()):
							line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
								already_included = True
								break
							else:
								already_included = False
					if (already_included == False):
						final_tectonic_fts.append((ft,line))
			print('len(final_tectonic_fts)')
			print(len(final_tectonic_fts))
			
			for line_ft,line in final_line_fts:
				plateID_of_line = line_ft.get_reconstruction_plate_id()
				line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				first_point_of_line = supporting.get_first_point_of_line(line)
				first_point_of_line_Shapely = Point(first_point_of_line.to_lat_lon())
				last_point_of_line = supporting.get_last_point_of_line(line)
				last_point_of_line_Shapely = Point(last_point_of_line.to_lat_lon())
				#we don't want to take points making a loop
				if (first_point_of_line_Shapely.almost_equals(last_point_of_line_Shapely, decimal = 4) == False):
					valid  = True 
					#to make sure we don't duplicate already identified convergent feature 
					for subduction_margin_ft,subduction_margin_line in final_tectonic_fts:
						subduction_margin_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(subduction_margin_line)
						if (line_in_Shapely.almost_equals(subduction_margin_line_in_Shapely, decimal = 4)):
							valid = False
							break
					if (valid == True):
						final_line_fts_2.append((line_ft,line))
			print('len(final_line_fts_2)')
			print(len(final_line_fts_2))
			
			already_included_tectonic_ft_1[:] = []
			for tectonic_ft_1,tectonic_line_1 in final_tectonic_fts:
				if (tectonic_ft_1.get_feature_id() not in already_included_tectonic_ft_1):
					first_node = supporting.get_first_point_of_line(tectonic_line_1)
					lat_1,lon_1 = first_node.to_lat_lon()
					first_node_in_Shapely = Point((lon_1,lat_1))
					last_node = supporting.get_last_point_of_line(tectonic_line_1)
					lat_2,lon_2 = last_node.to_lat_lon()
					last_node_in_Shapely = Point((lon_2,lat_2))
					tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(tectonic_line_1) 
					current_joint_tectonic_ft_1 = None
					current_joint_tectonic_ft_2 = None
					for tectonic_ft_2,tectonic_line_2 in final_tectonic_fts:
						if (tectonic_ft_1.get_feature_id() != tectonic_ft_2.get_feature_id()):
							tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(tectonic_line_2)
							if (tectonic_line_2_in_Shapely.touches(first_node_in_Shapely) == True): 
								if (current_joint_tectonic_ft_1 is None):
									current_joint_tectonic_ft_1 = tectonic_ft_2
							if (tectonic_line_2_in_Shapely.touches(last_node_in_Shapely) == True):
								if (current_joint_tectonic_ft_2 is None):
									current_joint_tectonic_ft_2 = tectonic_ft_2
					if (current_joint_tectonic_ft_1 is not None and current_joint_tectonic_ft_2 is None):
						final_tectonic_fts_2.append((tectonic_ft_1,tectonic_line_1,1))
						already_included_tectonic_ft_1.append(tectonic_ft_1.get_feature_id())
					elif (current_joint_tectonic_ft_1 is None and current_joint_tectonic_ft_2 is not None):
						final_tectonic_fts_2.append((tectonic_ft_1,tectonic_line_1,1))
						already_included_tectonic_ft_1.append(tectonic_ft_1.get_feature_id())
					elif (current_joint_tectonic_ft_1 is None and current_joint_tectonic_ft_2 is None):
						final_tectonic_fts_2.append((tectonic_ft_1,tectonic_line_1,2))
						already_included_tectonic_ft_1.append(tectonic_ft_1.get_feature_id())
			print('len(final_tectonic_fts_2)')
			print(len(final_tectonic_fts_2))
			
			#debug
			# for ft,line,number_of_pairs in final_tectonic_fts_2:
				# final_fts.append(ft)
				
			dic.clear()
			for ft_1,line_1,number_of_pairs in final_tectonic_fts_2:
				if (number_of_pairs == 1):
					min_distance = -1.00
					current_closest_ft, current_closest_line = None, None
					key = None
					reverse_key = None
					for ft_2,line_2,_ in final_tectonic_fts_2:
						if (ft_1.get_feature_id() != ft_2.get_feature_id()):
							distance,p_line_1,p_line_2 = supporting.calculate_distance_between_end_nodes_in_km(line_1,line_2)
							tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_1)
							tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							if (tectonic_line_1_in_Shapely.disjoint(tectonic_line_2_in_Shapely) and distance <= rad_cutoff_prox_connecting_in_km): 
								print('min_distance')
								print(min_distance)
								print('distance')
								print(distance)
								if (min_distance == -1.00):
									min_distance = distance
									current_closest_ft, current_closest_line = ft_2, line_2
								elif (min_distance > 0.00 and min_distance > distance):
									min_distance = distance
									current_closest_ft, current_closest_line = ft_2, line_2
					if (current_closest_ft is not None and current_closest_line is not None):
						#update dictionary 
						print("update dictionary")
						key = ft_1.get_feature_id().get_string()+"_"+current_closest_ft.get_feature_id().get_string()
						reverse_key = current_closest_ft.get_feature_id().get_string()+"_"+ft_1.get_feature_id().get_string()
						print(ft_1.get_feature_id().get_string())
						print(current_closest_ft.get_feature_id().get_string())
						print(key)
						print(reverse_key)
						if (key not in dic and reverse_key not in dic):
							clone_ft_1 = ft_1.clone()
							clone_current_closest_ft = current_closest_ft.clone()
							clone_ft_1.set_name(key)
							clone_current_closest_ft.set_name(key)
							dic[key] = (clone_ft_1,line_1.clone(),clone_current_closest_ft, current_closest_line.clone())
				elif (number_of_pairs == 2):
					#first pair
					min_distance = -1.00
					current_closest_ft, current_closest_line = None, None
					key = None
					reverse_key = None
					for ft_2,line_2,_ in final_tectonic_fts_2:
						if (ft_1.get_feature_id() != ft_2.get_feature_id()):
							distance,p_line_1,p_line_2 = supporting.calculate_distance_between_end_nodes_in_km(line_1,line_2)
							tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_1)
							tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							if (tectonic_line_1_in_Shapely.disjoint(tectonic_line_2_in_Shapely) and distance <= rad_cutoff_prox_connecting_in_km): 
								if (min_distance == -1.00):
									min_distance = distance
									current_closest_ft, current_closest_line = ft_2, line_2
								elif (min_distance > 0.00 and min_distance > distance):
									min_distance = distance
									current_closest_ft, current_closest_line = ft_2, line_2
					if (current_closest_ft is not None and current_closest_line is not None):
						#update dictionary 
						key = ft_1.get_feature_id().get_string()+"_"+current_closest_ft.get_feature_id().get_string()
						reverse_key = current_closest_ft.get_feature_id().get_string()+"_"+ft_1.get_feature_id().get_string()
						if (key not in dic and reverse_key not in dic):
							#second pair
							min_distance = -1.00
							current_closest_ft_2, current_closest_line_2 = None, None
							key_2 = None
							reverse_key_2 = None
							for ft_3,line_3,_ in final_tectonic_fts_2:
								if (ft_1.get_feature_id() != ft_3.get_feature_id() and ft_3.get_feature_id() != current_closest_ft.get_feature_id()):
									distance,p_line_1,p_line_2 = supporting.calculate_distance_between_end_nodes_in_km(line_1,line_3)
									tectonic_line_3_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_3)
									tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_1)
									tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(current_closest_line)
									if (tectonic_line_3_in_Shapely.disjoint(tectonic_line_2_in_Shapely)):
										if (tectonic_line_1_in_Shapely.disjoint(tectonic_line_3_in_Shapely) and distance <= rad_cutoff_prox_connecting_in_km): 
											if (min_distance == -1.00):
												min_distance = distance
												current_closest_ft_2, current_closest_line_2 = ft_3, line_3
											elif (min_distance > 0.00 and min_distance > distance):
												min_distance = distance
												current_closest_ft_2, current_closest_line_2 = ft_3, line_3
							if (current_closest_ft_2 is not None and current_closest_line_2 is not None):
								#update dictionary 
								print("update dictionary 2")
								key_2 = ft_1.get_feature_id().get_string()+"_"+current_closest_ft_2.get_feature_id().get_string()
								reverse_key_2 = current_closest_ft_2.get_feature_id().get_string()+"_"+ft_1.get_feature_id().get_string()
								print(ft_1.get_feature_id().get_string())
								print(current_closest_ft_2.get_feature_id().get_string())
								print(key_2)
								print(reverse_key_2)
								if (key_2 not in dic and reverse_key_2 not in dic):
									clone_ft_1 = ft_1.clone()
									clone_ft_1.set_name(key_2)
									clone_current_closest_ft_2 = current_closest_ft_2.clone()
									clone_current_closest_ft_2.set_name(key)
									dic[key_2] = (clone_ft_1,line_1.clone(),clone_current_closest_ft_2, current_closest_line_2.clone())
									
								print("update dictionary 1")
								print(ft_1.get_feature_id().get_string())
								print(current_closest_ft.get_feature_id().get_string())
								print(key)
								print(reverse_key)
								clone_ft_1 = ft_1.clone()
								clone_ft_1.set_name(key)
								clone_current_closest_ft = current_closest_ft.clone()
								clone_current_closest_ft.set_name(key)
								dic[key] = (clone_ft_1, line_1.clone(), clone_current_closest_ft, current_closest_line.clone())
							
			print("number of pairs in dictionary")
			print(len(dic.values()))
			
			for key in dic.keys():
				ft_1,line_1,ft_2,line_2 = dic[key]
				#find line features possibly between 2 tectonic boundaries
				possible_line_fts[:] = []
				for line_ft,line in final_line_fts_2:
					distance_btw_candidate_tectonic_1,_,_ = supporting.calculate_distance_between_end_nodes_in_km(line,line_1)
					distance_btw_candidate_tectonic_2,_,_ = supporting.calculate_distance_between_end_nodes_in_km(line,line_2)
					if (distance_btw_candidate_tectonic_1 < rad_cutoff_prox_connecting_in_km and distance_btw_candidate_tectonic_2 < rad_cutoff_prox_connecting_in_km):
						possible_line_fts.append((line_ft,line))
				#find all line features between these two tectonic_features:
				candidate_refs[:] = []
				candidate_subduction_margins[:] = [] 
				temp_candidate_refs[:] = []
				number_of_possible_line_fts = len(possible_line_fts)
				print("number_of_possible_line_fts")
				print(number_of_possible_line_fts)
				count = 0 
				completed = False 
				tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_1)
				tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
				while (count <= number_of_possible_line_fts):
					print("value of tectonic_line_1_in_Shapely, tectonic_line_2_in_Shapely")
					print(tectonic_line_1_in_Shapely,tectonic_line_2_in_Shapely)
					count = count + 1
					for line_ft,line in possible_line_fts:
						line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
						distance_btw_candidate_tectonic_1,point_1_from_candidate,point_1_from_tectonic_1 = supporting.calculate_distance_between_end_nodes_in_km(line,line_1)
						distance_btw_candidate_tectonic_2,point_2_from_candidate,point_2_fromt_tectonic_2 = supporting.calculate_distance_between_end_nodes_in_km(line,line_2)
						if (len(temp_candidate_refs) == 0):
							if (line_in_Shapely.touches(tectonic_line_1_in_Shapely)):
								if (line_in_Shapely.touches(tectonic_line_2_in_Shapely)):
									candidate_refs.append(line_ft.get_feature_id())
									temp_candidate_refs.append(line_ft.get_feature_id())
									candidate_subduction_margins.append((line_ft,line))
									completed = True
								elif (distance_btw_candidate_tectonic_2 < rad_cutoff_prox_connecting_in_km):
									candidate_refs.append(line_ft.get_feature_id())
									temp_candidate_refs.append(line_ft.get_feature_id())
									candidate_subduction_margins.append((line_ft,line))
							elif (line_in_Shapely.touches(tectonic_line_2_in_Shapely)):
								if (line_in_Shapely.touches(tectonic_line_1_in_Shapely)):
									candidate_refs.append(line_ft.get_feature_id())
									temp_candidate_refs.append(line_ft.get_feature_id())
									candidate_subduction_margins.append((line_ft,line))
									completed = True
								elif (distance_btw_candidate_tectonic_1 < rad_cutoff_prox_connecting_in_km):
									candidate_refs.append(line_ft.get_feature_id())
									temp_candidate_refs.append(line_ft.get_feature_id())
									candidate_subduction_margins.append((line_ft,line))
						elif (len(temp_candidate_refs) == 1):
							print('candidate_subduction_margins')
							print(candidate_subduction_margins)
							previous_ft,previous_line = candidate_subduction_margins[0]
							previous_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(previous_line)
							if (previous_line_in_Shapely.touches(tectonic_line_1_in_Shapely)):
								if (line_in_Shapely.touches(tectonic_line_2_in_Shapely) and line_ft.get_feature_id() not in candidate_refs):
									if (line_in_Shapely.touches(previous_line_in_Shapely)):
										candidate_refs.append(line_ft.get_feature_id())
										temp_candidate_refs.append(line_ft.get_feature_id())
										candidate_subduction_margins.append((line_ft,line))
										completed = True
									#have to calculate distance between end nodes
									elif (distance_btw_candidate_tectonic_1 < rad_cutoff_prox_connecting_in_km and line_ft.get_feature_id() not in candidate_refs):
										candidate_refs.append(line_ft.get_feature_id())
										temp_candidate_refs.append(line_ft.get_feature_id())
										candidate_subduction_margins.append((line_ft,line))
							elif (previous_line_in_Shapely.touches(tectonic_line_2_in_Shapely)):
								if (line_in_Shapely.touches(tectonic_line_1_in_Shapely) and line_ft.get_feature_id() not in candidate_refs):
									if (line_in_Shapely.touches(previous_line_in_Shapely)):
										candidate_refs.append(line_ft.get_feature_id())
										temp_candidate_refs.append(line_ft.get_feature_id())
										candidate_subduction_margins.append((line_ft,line))
										completed = True
									#have to calculate distance between end nodes
									elif (distance_btw_candidate_tectonic_2 < rad_cutoff_prox_connecting_in_km and line_ft.get_feature_id() not in candidate_refs):
										candidate_refs.append(line_ft.get_feature_id())
										temp_candidate_refs.append(line_ft.get_feature_id())
										candidate_subduction_margins.append((line_ft,line))
						n = len(candidate_subduction_margins)
						print("number of tuple in candidate_subduction_margins")
						print(n)
						if (temp_candidate_refs == 2):
							temp_ft_1,temp_line_1 = candidate_subduction_margins[n-2]
							temp_ft_2,temp_line_2 = candidate_subduction_margins[n-1]
							tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(temp_line_1.clone())
							tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(temp_line_2.clone()) 
							line_1 = temp_line_1.clone()
							line_2 = temp_line_2.clone()
							#have to calculate distance between candidate line and updated line_1 and line_2
							temp_candidate_refs[:] = []
						if (completed == True):
							break
					if (completed == True):
						break
				print ('value of completed')
				print (completed)
				if (completed == True):
					max_age = -1.00
					oldest_ft = None
					min_age = -1.00
					temp_list_of_fts = [ft_1,ft_2]
					for temp_ft in temp_list_of_fts:
						temp_max,temp_min = temp_ft.get_valid_time()
						if (temp_max > max_age):
							max_age = temp_max
							oldest_ft = temp_ft
						if (pygplates.GeoTimeInstant(temp_min).is_distant_future()):
							temp_min = 0.00
						if (min_age == -1.00 or (min_age > -1.00 and min_age > temp_min)):
							min_age = temp_min
					for candidate_ft,candidate_line in candidate_subduction_margins:
						#create a new passive_margin ft from the two candidate_passive_margins features
						plateID_of_line = candidate_ft.get_reconstruction_plate_id()
						new_subduction_ft = pygplates.Feature.create_reconstructable_feature(input_featType,candidate_line,name= "inferred_tectonic_features_"+str(plateID_of_line),valid_time = (max_age,min_age),reconstruction_plate_id = plateID_of_line)
						left_id = oldest_ft.get_left_plate()
						right_id = oldest_ft.get_right_plate()
						if (oldest_ft.get_reconstruction_plate_id() == left_id):
							new_subduction_ft.set_left_plate(plateID_of_line)
							new_subduction_ft.set_right_plate(right_id)
						elif (oldest_ft.get_reconstruction_plate_id() == right_id):
							new_subduction_ft.set_right_plate(plateID_of_line)
							new_subduction_ft.set_left_plate(left_id)
						else:
							print("Suspecting left_id and right_id. None is the same as reconstruction_plate_id.")
							print(oldest_ft.get_reconstruction_plate_id())
							print('left,right')
							print(left_id,right_id)
						#reverse_reconstruct
						if (reference is None):
							pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time)
						else:
							pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time,reference)
						final_subduction_margins.append(new_subduction_ft)
				candidate_refs[:] = []
				candidate_subduction_margins[:] = [] 
		reconstruction_time = reconstruction_time-interval
		
	outputLinesFeatureCollection = pygplates.FeatureCollection(final_subduction_margins)
	outputLinesFile = "new_approx_tectonic_features_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "new_approx_tectonic_features_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)
	
	# outputLinesFeatureCollection = pygplates.FeatureCollection(final_pair_of_tectonic_fts)
	# # outputLinesFile = "final_pair_of_tectonic_fts"+modelname+"_"+yyyymmdd+".shp"
	# # outputLinesFeatureCollection.write(outputLinesFile)
	# outputLinesFile = "final_pair_of_tectonic_fts"+modelname+"_"+yyyymmdd+".gpml"
	# outputLinesFeatureCollection.write(outputLinesFile)

def identify_new_lines_for_feats_v4(input_featType,rotation_model, SuperGDU_features, margin_line_features, tectonic_features, begin,end,interval,reference, only_single_gap, modelname,yyyymmdd):
	"""
	Find new passive_margin or upper_plate_margin feature to fill the gap between two known passive_margin or upper_plate_margin features
		Parameters:
			input_featType (pygplates.FeatureType)
			rotation_model (pygplates.RotationModel) 
			SuperGDU_features (pygplates.FeatureCollection or list of features): SuperGDU features that are generated for the same model used for tectonic features
			margin_line_features (pygplates.FeatureCollection or list of features): line_features making up ONLY the margins of GDUs CON-OCN line features
			tectonic_features (pygplates.FeatureCollection or list of features): upper_plate_margin or passive margin features
			begin, end, interval (float): period of time and the time step 
			reference (int): a value that we use in rotation file as a reference frame - like spin axis or mantle
			only_single_gap (bool): a Boolean value from the user - find only a single gap between two tectonic features or multiple gaps
	"""
	rad_cutoff_prox_connecting_in_km = 1000.00
	reconstruction_time = begin
	
	final_candidate_lines = []
	list_of_ft_testing = []
	list_of_valid_SuperGDU_fts = []
	
	reconstructed_line_features = []
	reconstructed_tectonic_features = []
	reconstructed_polygon_features = []
	final_line_fts = []
	final_line_fts_2 = []
	possible_line_fts = []
	final_tectonic_fts = []
	final_tectonic_fts_2 = []
	dic = {}
	candidate_refs = []
	already_included_cont_line = []
	temp_candidate_refs = []
	candidate_subduction_margins = []
	candidate_line_features_from_line_1 = []
	connecting_line_fts_from_start_line = []
	final_connecting_line_fts_from_start_line = []
	
	final_subduction_margins = []
	
	final_pair_of_tectonic_fts = []
	
	final_fts = []

	all_fts = []
	reconstructed_features = []
	already_included_tectonic_ft_1 = []
	#loop through reconstruction_time
	while(reconstruction_time > (end-interval)):
		print ("Here is reconstruction_time")
		print (reconstruction_time)
		list_of_valid_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time)]
		list_of_valid_line_fts = [ft for ft in margin_line_features if ft.is_valid_at_time(reconstruction_time)]
		
		reconstructed_line_features[:] = []
		reconstructed_tectonic_features[:] = []
		reconstructed_polygon_features[:] = []
		final_line_fts[:] = []
		final_line_fts_2[:] = []
		final_tectonic_fts[:] = []
		final_tectonic_fts_2[:] = []
		already_included_cont_line[:] = []
		candidate_refs[:] = []
		
		final_pair_of_tectonic_fts[:] = []
		
		list_of_valid_SuperGDU_fts[:] = []
		for SuperGDU_ft in SuperGDU_features:
			begin_age_SuperGDU_ft, end_age_SuperGDU_ft = SuperGDU_ft.get_valid_time()
			if (begin_age_SuperGDU_ft >= reconstruction_time and end_age_SuperGDU_ft < reconstruction_time):
				list_of_valid_SuperGDU_fts.append(SuperGDU_ft)
		#polygon_fts_clean_polygons = clean_polygon_features_w_date_line_wrapper(rotation_model,list_of_valid_SuperGDU_fts,reconstruction_time,reference,modelname,yyyymmdd)
		if (len(list_of_valid_line_fts) > 0):
			if (reference is not None):
				#line_features
				pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				#SuperGDU_features
				pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				#line_features
				pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time, group_with_feature = True)
				#SuperGDU_features
				pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time, group_with_feature = True)
			
			final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			final_reconstructed_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_tectonic_features,pygplates.PolylineOnSphere)
			final_reconstructed_SuperGDU_ft_polygons = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
			
			#remove duplicates in terms of the geometries for both CON-OCN line features and tectonic_features
			# for ft,line in final_reconstructed_line_features:
				# #check for duplicates
				# line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				# if (len(final_line_fts) == 0):
					# final_line_fts.append((ft,line))
				# else:
					# already_included = False
					# for ft_2,line_2 in final_line_fts:
						# if (ft_2.get_feature_id() != ft.get_feature_id()):
							# line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							# if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
								# already_included = True
								# break
							# else:
								# already_included = False
					# if (already_included == False):
						# final_line_fts.append((ft,line))
			# print('len(final_line_fts)')
			# print(len(final_line_fts))
			
			# for ft,line in final_reconstructed_tectonic_features:
				# #check for duplicates
				# line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				# if (len(final_tectonic_fts) == 0):
					# final_tectonic_fts.append((ft,line))
				# else:
					# already_included = False
					# for ft_2,line_2 in final_tectonic_fts:
						# if (ft_2.get_feature_id() != ft.get_feature_id()):
							# line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							# if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
								# already_included = True
								# break
							# else:
								# already_included = False
					# if (already_included == False):
						# final_tectonic_fts.append((ft,line))
			# print('len(final_tectonic_fts)')
			# print(len(final_tectonic_fts))
			
			# for line_ft,line in final_line_fts:
				# plateID_of_line = line_ft.get_reconstruction_plate_id()
				# line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
				# first_point_of_line = supporting.get_first_point_of_line(line)
				# first_point_of_line_Shapely = Point(first_point_of_line.to_lat_lon())
				# last_point_of_line = supporting.get_last_point_of_line(line)
				# last_point_of_line_Shapely = Point(last_point_of_line.to_lat_lon())
				# #we don't want to take points making a loop
				# if (first_point_of_line_Shapely.almost_equals(last_point_of_line_Shapely, decimal = 4) == False):
					# valid	 = True 
					# #to make sure we don't duplicate already identified convergent feature 
					# for subduction_margin_ft,subduction_margin_line in final_tectonic_fts:
						# subduction_margin_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(subduction_margin_line)
						# if (line_in_Shapely.almost_equals(subduction_margin_line_in_Shapely, decimal = 4)):
							# valid = False
							# break
					# if (valid == True):
						# final_line_fts_2.append((line_ft,line))
			# print('len(final_line_fts_2)')
			# print(len(final_line_fts_2))
			
			#debug
			# temp_final_line_fts_2 = [ft for ft,_ in final_line_fts_2]
			# outputLinesFeatureCollection = pygplates.FeatureCollection(temp_final_line_fts_2)
			# outputLinesFile = "temp_final_line_fts_2"+modelname+"_"+yyyymmdd+".gpml"
			# outputLinesFeatureCollection.write(outputLinesFile)
			#exit()
			
			final_line_fts_2 = final_reconstructed_line_features
			final_tectonic_fts = final_reconstructed_tectonic_features
			
			
			already_included_tectonic_ft_1[:] = []
			for tectonic_ft_1,tectonic_line_1 in final_tectonic_fts:
				if (tectonic_ft_1.get_feature_id() not in already_included_tectonic_ft_1):
					first_node = supporting.get_first_point_of_line(tectonic_line_1)
					lat_1,lon_1 = first_node.to_lat_lon()
					first_node_in_Shapely = Point((lon_1,lat_1))
					last_node = supporting.get_last_point_of_line(tectonic_line_1)
					lat_2,lon_2 = last_node.to_lat_lon()
					last_node_in_Shapely = Point((lon_2,lat_2))
					tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(tectonic_line_1) 
					current_joint_tectonic_ft_1 = None
					current_joint_tectonic_ft_2 = None
					for tectonic_ft_2,tectonic_line_2 in final_tectonic_fts:
						if (tectonic_ft_1.get_feature_id() != tectonic_ft_2.get_feature_id()):
							tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(tectonic_line_2)
							if (tectonic_line_2_in_Shapely.touches(first_node_in_Shapely) == True): 
								if (current_joint_tectonic_ft_1 is None):
									current_joint_tectonic_ft_1 = tectonic_ft_2
							elif (tectonic_line_2_in_Shapely.touches(last_node_in_Shapely) == True):
								if (current_joint_tectonic_ft_2 is None):
									current_joint_tectonic_ft_2 = tectonic_ft_2
					if (current_joint_tectonic_ft_1 is not None and current_joint_tectonic_ft_2 is None):
						final_tectonic_fts_2.append((tectonic_ft_1,tectonic_line_1,1))
						already_included_tectonic_ft_1.append(tectonic_ft_1.get_feature_id())
					elif (current_joint_tectonic_ft_1 is None and current_joint_tectonic_ft_2 is not None):
						final_tectonic_fts_2.append((tectonic_ft_1,tectonic_line_1,1))
						already_included_tectonic_ft_1.append(tectonic_ft_1.get_feature_id())
					elif (current_joint_tectonic_ft_1 is None and current_joint_tectonic_ft_2 is None):
						final_tectonic_fts_2.append((tectonic_ft_1,tectonic_line_1,2))
						already_included_tectonic_ft_1.append(tectonic_ft_1.get_feature_id())
			print('len(final_tectonic_fts_2)')
			print(len(final_tectonic_fts_2))
			
			#debug
			# for ft,line,number_of_pairs in final_tectonic_fts_2:
				# final_fts.append(ft)
				
			dic.clear()
			for ft_1,line_1,_ in final_tectonic_fts_2:
				key = None
				reverse_key = None
				temporary_tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely_without_roundup_coords(line_1)
				SuperGDU_polygon_dilation = None
				#for SuperGDU_ft, SuperGDU_polygon in polygon_fts_clean_polygons:
				for SuperGDU_ft, SuperGDU_polygon in final_reconstructed_SuperGDU_ft_polygons:
					# SuperGDU_in_Shapely = supporting.convert_polygon_to_Polygon_in_shapely(SuperGDU_polygon)
					# dilation = SuperGDU_in_Shapely.boundary.buffer(0.100000)
					# if (temporary_tectonic_line_1_in_Shapely.within(dilation) == True):
						# SuperGDU_polygon_dilation = dilation
						# break
					if (SuperGDU_polygon.partition(line_1) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
						SuperGDU_polygon_dilation = SuperGDU_polygon
						break
				if (SuperGDU_polygon_dilation is not None):
					for ft_2,line_2,_ in final_tectonic_fts_2:
						if (ft_1.get_feature_id() != ft_2.get_feature_id()):
							distance,p_line_1,p_line_2 = supporting.calculate_distance_between_end_nodes_in_km(line_1,line_2)
							tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
							temporary_tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely_without_roundup_coords(line_2)
							#if (temporary_tectonic_line_2_in_Shapely.disjoint(temporary_tectonic_line_1_in_Shapely) and temporary_tectonic_line_2_in_Shapely.within(SuperGDU_polygon_dilation)):
							if (temporary_tectonic_line_2_in_Shapely.disjoint(temporary_tectonic_line_1_in_Shapely) and SuperGDU_polygon_dilation.partition(line_2) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
								if (distance <= rad_cutoff_prox_connecting_in_km): 
									#update dictionary 
									#print("update dictionary")
									key = ft_1.get_feature_id().get_string()+"_"+ft_2.get_feature_id().get_string()
									reverse_key = ft_2.get_feature_id().get_string()+"_"+ft_1.get_feature_id().get_string()	
									if (key not in dic and reverse_key not in dic):
										clone_ft_1 = ft_1.clone()
										clone_ft_2 = ft_2.clone()
										# name_of_Tectonic_ft_1_ft_2 = ft_1.get_name()+"_"+ft_2.get_name()
										# clone_ft_1.set_name(name_of_Tectonic_ft_1_ft_2)
										# clone_ft_2.set_name(name_of_Tectonic_ft_1_ft_2)
										dic[key] = [(clone_ft_1,line_1.clone(),clone_ft_2, line_2.clone())]
									elif (key in dic):
										clone_ft_1 = ft_1.clone()
										clone_ft_2 = ft_2.clone()
										# name_of_Tectonic_ft_1_ft_2 = ft_1.get_name()+"_"+ft_2.get_name()
										# clone_ft_1.set_name(name_of_Tectonic_ft_1_ft_2)
										# clone_ft_2.set_name(name_of_Tectonic_ft_1_ft_2)
										dic[key].append((clone_ft_1,line_1.clone(),clone_ft_2, line_2.clone()))
									elif (reverse_key in dic):
										clone_ft_1 = ft_1.clone()
										clone_ft_2 = ft_2.clone()
										# name_of_Tectonic_ft_1_ft_2 = ft_1.get_name()+"_"+ft_2.get_name()
										# clone_ft_1.set_name(name_of_Tectonic_ft_1_ft_2)
										# clone_ft_2.set_name(name_of_Tectonic_ft_1_ft_2)
										dic[reverse_key].append((clone_ft_1,line_1.clone(),clone_ft_2, line_2.clone()))

			print("number of pairs in dictionary")
			print(len(dic.values()))
			
			for key in dic.keys():
				list_of_tuples_for_key = dic[key]
				for ft_1,line_1,ft_2,line_2 in list_of_tuples_for_key:
					print("name_of_Tectonic_ft_1_ft_2")
					print(ft_1.get_name())
					#find line features possibly between 2 tectonic boundaries
					possible_line_fts[:] = []
					for line_ft,line in final_line_fts_2:
						distance_btw_candidate_tectonic_1,_,_ = supporting.calculate_distance_between_end_nodes_in_km(line,line_1)
						distance_btw_candidate_tectonic_2,_,_ = supporting.calculate_distance_between_end_nodes_in_km(line,line_2)
						distance_btw_tectonic_1_tectonic_2,_,_	= supporting.calculate_distance_between_end_nodes_in_km(line_1,line_2)
						#if (distance_btw_tectonic_1_tectonic_2 > distance_btw_candidate_tectonic_1 and distance_btw_tectonic_1_tectonic_2 > distance_btw_candidate_tectonic_2):
						# if (ft_1.get_reconstruction_plate_id() == 10761 and ft_2.get_reconstruction_plate_id() == 10761):
							# print('distance_btw_candidate_tectonic_1')
							# print(distance_btw_candidate_tectonic_1)
							# print('distance_btw_candidate_tectonic_2')
							# print(distance_btw_candidate_tectonic_2)
						if (distance_btw_candidate_tectonic_1 < rad_cutoff_prox_connecting_in_km and distance_btw_candidate_tectonic_2 < rad_cutoff_prox_connecting_in_km):	
							possible_line_fts.append((line_ft,line))
					#find all line features between these two tectonic_features:
					# number_of_possible_line_fts = len(possible_line_fts)
					# print("number_of_possible_line_fts")
					# print(number_of_possible_line_fts)
					tectonic_line_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_1)
					dilation_of_tectonic_line_1_in_Shapely = tectonic_line_1_in_Shapely.buffer(0.1000)
					tectonic_line_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
					
					#debug
					# if (ft_1.get_reconstruction_plate_id() == 10761 and ft_2.get_reconstruction_plate_id() == 10761):
					if ((ft_1.get_name() == 'continental_rift_10452_10389' and ft_2.get_name() == 'continental_rift_10389_10447') or (ft_2.get_name() == 'continental_rift_10452_10389' and ft_1.get_name() == 'continental_rift_10389_10447')):
						number_of_possible_line_fts = len(possible_line_fts)
						print("number_of_possible_line_fts")
						print(number_of_possible_line_fts)
						temp_possible_line_fts = [ft for ft,_ in possible_line_fts]
						outputLinesFeatureCollection = pygplates.FeatureCollection(temp_possible_line_fts)
						outputLinesFile = "possible_line_fts"+modelname+"_"+yyyymmdd+".gpml"
						outputLinesFeatureCollection.write(outputLinesFile)
						temp_ft_1 = pygplates.Feature.create_reconstructable_feature(input_featType,line_1,name= "temp_1_tectonic_features_10761",valid_time = (reconstruction_time,reconstruction_time - interval),reconstruction_plate_id = 10761)
						temp_ft_2 = pygplates.Feature.create_reconstructable_feature(input_featType,line_2,name= "temp_2_tectonic_features_10761",valid_time = (reconstruction_time,reconstruction_time - interval),reconstruction_plate_id = 10761)
						#reverse_reconstruct
						if (reference is None):
							pygplates.reverse_reconstruct([temp_ft_1,temp_ft_2],rotation_model,reconstruction_time)
						else:
							pygplates.reverse_reconstruct([temp_ft_1,temp_ft_2],rotation_model,reconstruction_time,reference)
						output_tectonic_ft_1_2 = [temp_ft_1,temp_ft_2]
						outputLinesFeatureCollection = pygplates.FeatureCollection(output_tectonic_ft_1_2)
						outputLinesFile = "output_tectonic_ft_1_2_10761"+modelname+"_"+yyyymmdd+".gpml"
						outputLinesFeatureCollection.write(outputLinesFile)
						temp_final_line_fts_2 = [ft for ft,_ in final_line_fts_2]
						outputLinesFeatureCollection = pygplates.FeatureCollection(temp_final_line_fts_2)
						outputLinesFile = "temp_final_line_fts_2"+modelname+"_"+yyyymmdd+".gpml"
						outputLinesFeatureCollection.write(outputLinesFile)
						
					#find one or two line connecting to tectonic_line_1_in_Shapely	
					candidate_line_features_from_line_1[:] = []
					for candidate_start_ft, candidate_start_line in possible_line_fts:
						line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(candidate_start_line)
						if (line_in_Shapely.touches(tectonic_line_1_in_Shapely) or line_in_Shapely.crosses(tectonic_line_1_in_Shapely)):
						#if (line_in_Shapely.within(dilation_of_tectonic_line_1_in_Shapely)):
							candidate_line_features_from_line_1.append((candidate_start_ft,candidate_start_line))
					#debug
					if ((ft_1.get_name() == 'continental_rift_10452_10389' and ft_2.get_name() == 'continental_rift_10389_10447') or (ft_2.get_name() == 'continental_rift_10452_10389' and ft_1.get_name() == 'continental_rift_10389_10447')):
						print("number of line features in candidate_line_features_from_line_1")
						temp_candidate_line_features_from_line_1 = [ft for ft,_ in candidate_line_features_from_line_1]
						outputLinesFeatureCollection = pygplates.FeatureCollection(temp_candidate_line_features_from_line_1)
						outputLinesFile = "candidate_line_features_from_line_1"+modelname+"_"+yyyymmdd+".shp"
						outputLinesFeatureCollection.write(outputLinesFile)
						outputLinesFile = "candidate_line_features_from_line_1"+modelname+"_"+yyyymmdd+".gpml"
						outputLinesFeatureCollection.write(outputLinesFile)
							#exit()

					final_connecting_line_fts_from_start_line[:] = []
					min_total_length_of_all_lines = 0
					
					#debug
					print("number of candidate line features from line_1")
					print(len(candidate_line_features_from_line_1))
					count_candidate = 0
					
					for possible_start_line_ft,possible_start_line in candidate_line_features_from_line_1:
						#debug
						count_candidate = count_candidate + 1
						print('count_candidate')
						print(count_candidate)
						if ((ft_1.get_name() == 'continental_rift_10452_10389' and ft_2.get_name() == 'continental_rift_10389_10447') or (ft_2.get_name() == 'continental_rift_10452_10389' and ft_1.get_name() == 'continental_rift_10389_10447')):
							print(possible_start_line_ft.get_reconstruction_plate_id())
							print(possible_start_line.to_lat_lon_list())
						
						#try a new start line ft from tectonic_line_1
						possible_start_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(possible_start_line)
						completed = False
						connecting_line_fts_from_start_line[:] = []
						already_included_cont_line[:] = []
						total_length_of_all_lines = possible_start_line_in_Shapely.length
						#the special case --- fill one single gap between two lines 
						if (possible_start_line_in_Shapely.touches(tectonic_line_2_in_Shapely)):
							completed = True
						previous_cont_line = None
						current_cont_line = None
						found_cont_line = True
						number_of_possible_line_fts = len(possible_line_fts)
						if ((ft_1.get_name() == 'continental_rift_10452_10389' and ft_2.get_name() == 'continental_rift_10389_10447') or (ft_2.get_name() == 'continental_rift_10452_10389' and ft_1.get_name() == 'continental_rift_10389_10447')):
							print('number_of_possible_line_fts')
							print(number_of_possible_line_fts)
						while (completed == False):
							if (current_cont_line is not None and previous_cont_line is None):
								previous_cont_line = current_cont_line.clone()
							elif (current_cont_line is not None and previous_cont_line is not None):
								previous_cont_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(previous_cont_line)
								current_cont_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(current_cont_line)
								if (previous_cont_line_in_Shapely.almost_equals(current_cont_line_in_Shapely, decimal = 4)):
									break
								else:
									previous_cont_line = current_cont_line.clone()
							for cont_line_ft,cont_line in possible_line_fts:
								if ((ft_1.get_name() == 'continental_rift_10452_10389' and ft_2.get_name() == 'continental_rift_10389_10447') or (ft_2.get_name() == 'continental_rift_10452_10389' and ft_1.get_name() == 'continental_rift_10389_10447')):
									# print('current_cont_line')
									# print(current_cont_line)
									# if (current_cont_line is not None):
										# print(current_cont_line.to_lat_lon_list())
									# print('previous_cont_line')
									# print(previous_cont_line)
									# if (previous_cont_line is not None):
										# print(previous_cont_line.to_lat_lon_list())
									print('cont_line')
									print(cont_line_ft.get_reconstruction_plate_id())
									print(cont_line.to_lat_lon_list())
								# print('value of total_length_of_all_lines')
								# print(total_length_of_all_lines)
								if ((possible_start_line_ft.get_feature_id() != cont_line_ft.get_feature_id()) and (cont_line_ft.get_feature_id() not in already_included_cont_line)):
									cont_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(cont_line)
									if(current_cont_line is None):
										# if ((ft_1.get_name() == 'continental_rift_10600_10761' and ft_2.get_name() == 'continental_rift_10761_11320') or (ft_2.get_name() == 'continental_rift_10600_10761' and ft_1.get_name() == 'continental_rift_10761_11320')):
											# print('cont_line_in_Shapely.touches(possible_start_line_in_Shapely)')
											# print(cont_line_in_Shapely.touches(possible_start_line_in_Shapely))
											# print('cont_line_in_Shapely.crosses(possible_start_line_in_Shapely)')
											# print(cont_line_in_Shapely.crosses(possible_start_line_in_Shapely))
										if (cont_line_in_Shapely.touches(possible_start_line_in_Shapely) or cont_line_in_Shapely.crosses(possible_start_line_in_Shapely)):
											already_included_cont_line.append(cont_line_ft.get_feature_id())
											total_length_of_all_lines = total_length_of_all_lines + cont_line_in_Shapely.length
											connecting_line_fts_from_start_line.append((cont_line_ft,cont_line))
											current_cont_line = cont_line.clone()
											if (cont_line_in_Shapely.touches(tectonic_line_2_in_Shapely)):
												completed = True
									else:
										# if ((ft_1.get_name() == 'continental_rift_10600_10761' and ft_2.get_name() == 'continental_rift_10761_11320') or (ft_2.get_name() == 'continental_rift_10600_10761' and ft_1.get_name() == 'continental_rift_10761_11320')):
											# print(cont_line_ft.get_reconstruction_plate_id())
											# print(current_cont_line.to_lat_lon_list())
										current_cont_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(current_cont_line)
										# if ((ft_1.get_name() == 'continental_rift_10600_10761' and ft_2.get_name() == 'continental_rift_10761_11320') or (ft_2.get_name() == 'continental_rift_10600_10761' and ft_1.get_name() == 'continental_rift_10761_11320')):
											# print('cont_line_in_Shapely.touches(current_cont_line_in_Shapely)')
											# print(cont_line_in_Shapely.touches(current_cont_line_in_Shapely))
											# print('cont_line_in_Shapely.crosses(current_cont_line_in_Shapely)')
											# print(cont_line_in_Shapely.crosses(current_cont_line_in_Shapely))
										if (cont_line_in_Shapely.touches(current_cont_line_in_Shapely) or cont_line_in_Shapely.crosses(current_cont_line_in_Shapely)):
											already_included_cont_line.append(cont_line_ft.get_feature_id())
											total_length_of_all_lines = total_length_of_all_lines + cont_line_in_Shapely.length
											connecting_line_fts_from_start_line.append((cont_line_ft,cont_line))
											current_cont_line = cont_line.clone()
											if (cont_line_in_Shapely.touches(tectonic_line_2_in_Shapely)):
												completed = True
								if (completed == True):
									break		
							if (completed == True or current_cont_line is None):
								break
						if (completed == True):
							if ((min_total_length_of_all_lines == 0) or (total_length_of_all_lines < min_total_length_of_all_lines and min_total_length_of_all_lines > 0)):
								min_total_length_of_all_lines = total_length_of_all_lines
								final_connecting_line_fts_from_start_line[:] = []
								final_connecting_line_fts_from_start_line.append((possible_start_line_ft.clone(),possible_start_line.clone()))
								for connecting_line_ft, connecting_line in connecting_line_fts_from_start_line:
									final_connecting_line_fts_from_start_line.append((connecting_line_ft.clone(), connecting_line.clone()))
						if ((ft_1.get_name() == 'continental_rift_10452_10389' and ft_2.get_name() == 'continental_rift_10389_10447') or (ft_2.get_name() == 'continental_rift_10452_10389' and ft_1.get_name() == 'continental_rift_10389_10447')):
							print('complete value')
							print(completed)
							print('current_cont_line')
							print(current_cont_line)
							print('previous_cont_line')
							print(previous_cont_line)
							if (current_cont_line is not None and previous_cont_line is not None): 
								previous_cont_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(previous_cont_line)
								current_cont_line_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(current_cont_line)
								print(previous_cont_line_in_Shapely.almost_equals(current_cont_line_in_Shapely, decimal = 4))
					#debug
					if ((ft_1.get_name() == 'continental_rift_10452_10389' and ft_2.get_name() == 'continental_rift_10389_10447') or (ft_2.get_name() == 'continental_rift_10452_10389' and ft_1.get_name() == 'continental_rift_10389_10447')):
						print('len(final_connecting_line_fts_from_start_line)')
						print(len(final_connecting_line_fts_from_start_line))
						#exit()
					
					if (len(final_connecting_line_fts_from_start_line) > 0):
						max_age = -1.00
						oldest_ft = None
						min_age = -1.00
						temp_list_of_fts = [ft_1,ft_2]
						for temp_ft in temp_list_of_fts:
							temp_max,temp_min = temp_ft.get_valid_time()
							if (temp_max > max_age):
								max_age = temp_max
								oldest_ft = temp_ft
							if (pygplates.GeoTimeInstant(temp_min).is_distant_future()):
								temp_min = 0.00
							if (min_age == -1.00 or (min_age > -1.00 and min_age > temp_min)):
								min_age = temp_min
						for candidate_ft,candidate_line in final_connecting_line_fts_from_start_line:
							#create a new passive_margin ft from the two candidate_passive_margins features
							plateID_of_line = candidate_ft.get_reconstruction_plate_id()
							new_subduction_ft = pygplates.Feature.create_reconstructable_feature(input_featType,candidate_line,name= "inferred_tectonic_features_"+str(plateID_of_line),valid_time = (max_age,min_age),reconstruction_plate_id = plateID_of_line)
							new_subduction_ft.set_description(ft_1.get_name()+"_"+ft_2.get_name())
							left_id = oldest_ft.get_left_plate()
							right_id = oldest_ft.get_right_plate()
							if (oldest_ft.get_reconstruction_plate_id() == left_id):
								new_subduction_ft.set_left_plate(plateID_of_line)
								new_subduction_ft.set_right_plate(right_id)
							elif (oldest_ft.get_reconstruction_plate_id() == right_id):
								new_subduction_ft.set_right_plate(plateID_of_line)
								new_subduction_ft.set_left_plate(left_id)
							else:
								print("Suspecting left_id and right_id. None is the same as reconstruction_plate_id.")
								print(oldest_ft.get_reconstruction_plate_id())
								print('left,right')
								print(left_id,right_id)
							#reverse_reconstruct
							if (reference is None):
								pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time)
							else:
								pygplates.reverse_reconstruct(new_subduction_ft,rotation_model,reconstruction_time,reference)
							final_subduction_margins.append(new_subduction_ft)

		reconstruction_time = reconstruction_time-interval
		
	outputLinesFeatureCollection = pygplates.FeatureCollection(final_subduction_margins)
	outputLinesFile = "new_approx_tectonic_features_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "new_approx_tectonic_features_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)

#credits to: Mike T. https://gis.stackexchange.com/questions/289044/creating-buffer-circle-x-kilometers-from-point-using-python
#more information for proj=aqed: https://proj.org/operations/projections/aeqd.html
#lat_0 and lon_0 are latitude and longitude of projection center
#x_0 and y_0 are false easting and false northing - the origin of xy coordinates
def geodesic_point_buffer(lat, lon, km):
	proj_wgs84 = pyproj.Proj('+proj=longlat +datum=WGS84')
	# Azimuthal equidistant projection
	aeqd_proj = '+proj=aeqd +lat_0={lat} +lon_0={lon} +x_0=0 +y_0=0 +ellps=WGS84'
	project = partial(pyproj.transform, pyproj.Proj(aeqd_proj.format(lat = lat,lon = lon)), proj_wgs84)
	buf = Point(0, 0).buffer(km * 1000) #distance in metres
	return transform(project, buf).exterior.coords[:]

def find_unique_features_from_two_feature_collections(features_1,features_2):
	"""
		Given two feature collections, features_1 and features_2, find all unique features in features_1 but not in features_2
	"""
	unique_fts = []
	for ft_1 in features_1:
		ft_1_id = ft_1.get_feature_id()
		ft_1_geom = ft_1.get_geometry()
		unique = True
		for ft_2 in features_2:
			ft_2_id = ft_2.get_feature_id()
			ft_2_geom = ft_2.get_geometry()
			if (ft_1_geom == ft_2_geom):
				unique = False
				break
		if (unique == True):
			unique_fts.append(ft_1)
	return unique_fts

def find_features_with_similar_geometry_from_two_feature_collections(features_1,features_2):
	"""
		Given two feature collections, features_1 and features_2, find features with similar geometry in features_1 and in features_2
	"""
	same_geometry_fts = []
	if (len(features_1) > len(features_2)):
		for ft_1 in features_1:
			ft_1_id = ft_1.get_feature_id()
			ft_1_geom = ft_1.get_geometry()
			unique = True
			for ft_2 in features_2:
				ft_2_id = ft_2.get_feature_id()
				ft_2_geom = ft_2.get_geometry()
				if (ft_1_id != ft_2_id and ft_1_geom == ft_2_geom):
					unique = False
					break
			if (unique == False):
				same_geometry_fts.append(ft_1)
	else:
		for ft_2 in features_2:
			ft_2_id = ft_2.get_feature_id()
			ft_2_geom = ft_2.get_geometry()
			unique = True
			for ft_1 in features_1:
				ft_1_id = ft_1.get_feature_id()
				ft_1_geom = ft_1.get_geometry()
				if (ft_1_id != ft_2_id and ft_1_geom == ft_2_geom):
					unique = False
					break
			if (unique == False):
				same_geometry_fts.append(ft_2)
	return same_geometry_fts
	
def identify_new_lines_for_feats(rotation_model, margin_line_features, tectonic_features, buffer_distance_km, begin, end, interval, reference, modelname, yyyymmdd):
	"""
		Using buffer zone and SuperGDU relationship to infer a tectonic boundary for margin features that were not classified
	"""
	already_proccessed_ft = []
	reconstructed_line_features = []
	reconstructed_tectonic_features = []
	neighbour_features_and_geometries = []
	inferred_tectonic_features = []
	
	#txt for SQL to check whether unclassified_ft and tectonic_ft in the same SuperGDU
	txt = """SELECT DISTINCT represent_gdu_id
			FROM super_gdu_and_members_id
			WHERE gdu_id_member = {gdu_id_1} AND from_time = {input_from_time_1} AND to_time = {input_to_time_1}
			EXCEPT 
			SELECT DISTINCT represent_gdu_id
			FROM super_gdu_and_members_id
			WHERE gdu_id_member = {gdu_id_2} AND from_time = {input_from_time_1} AND to_time = {input_to_time_1} """
	conn = None
	cur = None
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
	except (Exception, psycopg2.DatabaseError) as error:
		print("Error in identify_new_lines_for_feats before enter While-loop")
		print(error)
			
	reconstruction_time = begin
	outputLinesFeatureCollection = pygplates.FeatureCollection()
	while (reconstruction_time > (end - interval)):
		print('reconstruction_time')
		print(reconstruction_time)
		#clean up the storages
		reconstructed_line_features[:] = []
		reconstructed_tectonic_features[:] = []
		list_of_valid_line_fts = [ft for ft in margin_line_features if ft.is_valid_at_time(reconstruction_time) and ft.get_feature_id().get_string() not in already_proccessed_ft]
		list_of_valid_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time) and (ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary or ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone)]
		list_of_unclassified_fts = find_unique_features_from_two_feature_collections(list_of_valid_line_fts,list_of_valid_tectonic_fts)
		if (len(list_of_unclassified_fts) > 0):
			if (reference is not None):
				#line_features
				pygplates.reconstruct(list_of_unclassified_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				#line_features
				pygplates.reconstruct(list_of_unclassified_fts,rotation_model,reconstructed_line_features,reconstruction_time, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time, group_with_feature = True)
			final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			final_reconstructed_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_tectonic_features,pygplates.PolylineOnSphere)
			for unclassified_ft,unclassified_line in final_reconstructed_line_features:
				#find the centroid of the unclassified_line
				centroid = unclassified_line.get_centroid()
				lat,lon = centroid.to_lat_lon()
				#find the buffer based on the centroid
				buffer = geodesic_point_buffer(lat, lon, buffer_distance_km)
				buffer_polygon = Polygon(buffer)
				# print(buffer)
				# print(buffer_polygon)
				#convert Polygon to PolygonOnSphere
				buffer_PolygonOnSphere = supporting.convert_Polygon_to_PolygonOnSphere_in_pygplates(buffer_polygon)
				neighbour_features_and_geometries[:] = []
				number_of_convergent_fts = 0 
				number_of_divergent_fts = 0
				closest_div_feature = None
				closest_div_distance = -1.00
				closest_conv_feature = None
				closest_conv_distance = -1.00
				unclassified_ft_GDU_id = unclassified_ft.get_reconstruction_plate_id()
				for tectonic_ft,tectonic_line in final_reconstructed_tectonic_features:
					#check whether tectonic_ft GDU_id and unclassified_ft GDU_id in the same SuperGDU
					tectonic_ft_GDU_id = tectonic_ft.get_reconstruction_plate_id()
					sql = txt.format(gdu_id_1 = unclassified_ft_GDU_id, gdu_id_2 = tectonic_ft_GDU_id,\
									input_from_time_1 = reconstruction_time, input_to_time_1 = reconstruction_time - interval)
					cur.execute(sql)
					row = cur.fetchone()
					same_superGDU = False
					if (row is None):
						same_superGDU = True
					if (same_superGDU == True and (buffer_PolygonOnSphere.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting or buffer_PolygonOnSphere.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.inside)):
						neighbour_features_and_geometries.append((tectonic_ft,tectonic_line))
						centroid_of_line_lat,centroid_of_line_lon = tectonic_line.get_centroid().to_lat_lon()
						dist = supporting.calculate_distance_km_between_two_points_from_haversine_formula(lat,lon,centroid_of_line_lat,centroid_of_line_lon)
						#obtain the feature type of tectonic ft
						featureType = tectonic_ft.get_feature_type()
						if (featureType == pygplates.FeatureType.gpml_subduction_zone):
							number_of_convergent_fts = number_of_convergent_fts + 1
							if (closest_conv_distance == -1.00 and closest_conv_feature is None):
								closest_conv_distance = dist
								closest_conv_feature = tectonic_ft
							elif (closest_conv_distance > -1.00 and dist < closest_conv_distance):
								closest_conv_distance = dist
								closest_conv_feature = tectonic_ft
						elif (featureType == pygplates.FeatureType.gpml_passive_continental_boundary):
							number_of_divergent_fts = number_of_divergent_fts + 1
							if (closest_div_distance == -1.00 and closest_div_feature is None):
								closest_div_distance = dist
								closest_div_feature = tectonic_ft
							elif (closest_div_distance > -1.00 and dist < closest_div_distance):
								closest_div_distance = dist
								closest_div_feature = tectonic_ft
				if (number_of_divergent_fts > number_of_convergent_fts):
					# unclassified_ft is divergent_feature
					left = closest_div_feature.get_left_plate()
					right = closest_div_feature.get_right_plate()
					final_left = -1
					final_right = -1
					if (left == closest_div_feature.get_reconstruction_plate_id()):
						if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_left = unclassified_ft.get_reconstruction_plate_id()
							final_right = right
						elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_right = unclassified_ft.get_reconstruction_plate_id()
							final_left = right
					elif (right == closest_div_feature.get_reconstruction_plate_id()):
						if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_left = unclassified_ft.get_reconstruction_plate_id()
							final_right = left
						elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_right = unclassified_ft.get_reconstruction_plate_id()
							final_left = left
					valid_time = closest_div_feature.get_valid_time()
					new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,unclassified_line,name='inferred_divergent_ft_from_'+str(closest_div_feature.get_reconstruction_plate_id()),valid_time = valid_time,reconstruction_plate_id = unclassified_ft.get_reconstruction_plate_id())
					try:
						new_ft.set_left_plate(final_left)					
						new_ft.set_right_plate(final_right)
					except (Exception):
						print('left')
						print(left)
						print('right')
						print(right)
						print('closest_div_feature.get_reconstruction_plate_id()')
						print(closest_div_feature.get_reconstruction_plate_id())
						print('unclassified_ft.get_reconstruction_plate_id()')
						print(unclassified_ft.get_reconstruction_plate_id())
						print('unclassified_ft.get_left_plate()')
						print(unclassified_ft.get_left_plate())
						print('unclassified_ft.get_right_plate()')
						print(unclassified_ft.get_right_plate())
					inferred_tectonic_features.append(new_ft)
					already_proccessed_ft.append(unclassified_ft.get_feature_id().get_string())
				elif (number_of_divergent_fts < number_of_convergent_fts):
					# unclassified_ft is convergent_feature
					left = closest_conv_feature.get_left_plate()
					right = closest_conv_feature.get_right_plate()
					final_left = -1
					final_right = -1
					if (left == closest_conv_feature.get_reconstruction_plate_id()):
						if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_left = unclassified_ft.get_reconstruction_plate_id()
							final_right = right
						elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_right = unclassified_ft.get_reconstruction_plate_id()
							final_left = right
					elif (right == closest_conv_feature.get_reconstruction_plate_id()):
						if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_left = unclassified_ft.get_reconstruction_plate_id()
							final_right = left
						elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_right = unclassified_ft.get_reconstruction_plate_id()
							final_left = left
					valid_time = closest_conv_feature.get_valid_time()
					new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name='inferred_convergent_ft_from_'+str(closest_conv_feature.get_reconstruction_plate_id()),valid_time = valid_time,reconstruction_plate_id = unclassified_ft.get_reconstruction_plate_id())
					try:
						new_ft.set_left_plate(final_left)					
						new_ft.set_right_plate(final_right)
					except (Exception):
						print('left')
						print(left)
						print('right')
						print(right)
						print('closest_conv_feature.get_reconstruction_plate_id()')
						print(closest_conv_feature.get_reconstruction_plate_id())
						print('unclassified_ft.get_reconstruction_plate_id()')
						print(unclassified_ft.get_reconstruction_plate_id())
						print('unclassified_ft.get_left_plate()')
						print(unclassified_ft.get_left_plate())
						print('unclassified_ft.get_right_plate()')
						print(unclassified_ft.get_right_plate())
					inferred_tectonic_features.append(new_ft)
					already_proccessed_ft.append(unclassified_ft.get_feature_id().get_string())
				else:
					#have to find which is the closer one
					if (closest_conv_distance > -1.00 and closest_div_distance > -1.00 and closest_conv_distance > closest_div_distance):
						# unclassified_ft is divergent_feature
						left = closest_div_feature.get_left_plate()
						right = closest_div_feature.get_right_plate()
						final_left = -1
						final_right = -1
						if (left == closest_div_feature.get_reconstruction_plate_id()):
							if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_left = unclassified_ft.get_reconstruction_plate_id()
								final_right = right
							elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_right = unclassified_ft.get_reconstruction_plate_id()
								final_left = right
						elif (right == closest_div_feature.get_reconstruction_plate_id()):
							if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_left = unclassified_ft.get_reconstruction_plate_id()
								final_right = left
							elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_right = unclassified_ft.get_reconstruction_plate_id()
								final_left = left
						valid_time = closest_div_feature.get_valid_time()
						new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,unclassified_line,name='inferred_divergent_ft_from_'+str(closest_div_feature.get_reconstruction_plate_id()),valid_time = valid_time,reconstruction_plate_id = unclassified_ft.get_reconstruction_plate_id())
						new_ft.set_description(closest_div_feature.get_description())
						try:
							new_ft.set_left_plate(final_left)					
							new_ft.set_right_plate(final_right)
						except (Exception):
							print('left')
							print(left)
							print('right')
							print(right)
							print('closest_div_feature.get_reconstruction_plate_id()')
							print(closest_div_feature.get_reconstruction_plate_id())
							print('unclassified_ft.get_reconstruction_plate_id()')
							print(unclassified_ft.get_reconstruction_plate_id())
							print('unclassified_ft.get_left_plate()')
							print(unclassified_ft.get_left_plate())
							print('unclassified_ft.get_right_plate()')
							print(unclassified_ft.get_right_plate())
						inferred_tectonic_features.append(new_ft)
						already_proccessed_ft.append(unclassified_ft.get_feature_id().get_string())
					elif (closest_conv_distance > -1.00 and closest_div_distance > -1.00 and closest_conv_distance <= closest_div_distance):
						# unclassified_ft is convergent_feature
						left = closest_conv_feature.get_left_plate()
						right = closest_conv_feature.get_right_plate()
						final_left = -1
						final_right = -1
						if (left == closest_conv_feature.get_reconstruction_plate_id()):
							if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_left = unclassified_ft.get_reconstruction_plate_id()
								final_right = right
							elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_right = unclassified_ft.get_reconstruction_plate_id()
								final_left = right
						elif (right == closest_conv_feature.get_reconstruction_plate_id()):
							if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_left = unclassified_ft.get_reconstruction_plate_id()
								final_right = left
							elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_right = unclassified_ft.get_reconstruction_plate_id()
								final_left = left
						valid_time = closest_conv_feature.get_valid_time()
						new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name='inferred_convergent_ft_from_'+str(closest_conv_feature.get_reconstruction_plate_id()),valid_time = valid_time,reconstruction_plate_id = unclassified_ft.get_reconstruction_plate_id())
						new_ft.set_description(closest_conv_feature.get_description())
						try:
							new_ft.set_left_plate(final_left)					
							new_ft.set_right_plate(final_right)
						except (Exception):
							print('left')
							print(left)
							print('right')
							print(right)
							print('closest_conv_feature.get_reconstruction_plate_id()')
							print(closest_conv_feature.get_reconstruction_plate_id())
							print('unclassified_ft.get_reconstruction_plate_id()')
							print(unclassified_ft.get_reconstruction_plate_id())
							print('unclassified_ft.get_left_plate()')
							print(unclassified_ft.get_left_plate())
							print('unclassified_ft.get_right_plate()')
							print(unclassified_ft.get_right_plate())
						inferred_tectonic_features.append(new_ft)
						already_proccessed_ft.append(unclassified_ft.get_feature_id().get_string())
			#reverse_reconstruct
			if (reference is not None):
				pygplates.reverse_reconstruct(inferred_tectonic_features,rotation_model,reconstruction_time,reference)
			else:
				pygplates.reverse_reconstruct(inferred_tectonic_features,rotation_model,reconstruction_time)
			#collect inferred tectonic_features in outputFeatureCollection
			for inferred_ft in inferred_tectonic_features:
				outputLinesFeatureCollection.add(inferred_ft.clone())
				#not so sure 'great idea'
				tectonic_features.add(inferred_ft.clone())
			#clean up inferred_tectonic_features for next reconstruction_time
			inferred_tectonic_features[:] = []
		#update reconstruction_time
		reconstruction_time = reconstruction_time-interval
	
	if conn is not None:
		conn.close()
	
	outputLinesFile = "new_inferred_tectonic_features_within_proximal_dist_km_"+str(buffer_distance_km)+"_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "new_inferred_tectonic_features_within_proximal_dist_km_"+str(buffer_distance_km)+"_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)

def identify_new_lines_for_feats_without_SuperGDU(rotation_model, margin_line_features, tectonic_features, buffer_distance_km, begin, end, interval, reference, modelname, yyyymmdd):
	"""
		Using buffer zone to infer a tectonic boundary for margin features that were not classified
	"""
	already_proccessed_ft = []
	reconstructed_line_features = []
	reconstructed_tectonic_features = []
	neighbour_features_and_geometries = []
	inferred_tectonic_features = []
	
	reconstruction_time = begin
	outputLinesFeatureCollection = pygplates.FeatureCollection()
	while (reconstruction_time > (end - interval)):
		print('reconstruction_time')
		print(reconstruction_time)
		#clean up the storages
		reconstructed_line_features[:] = []
		reconstructed_tectonic_features[:] = []
		list_of_valid_line_fts = [ft for ft in margin_line_features if ft.is_valid_at_time(reconstruction_time) and ft.get_feature_id().get_string() not in already_proccessed_ft]
		list_of_valid_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time) and (ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary or ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone)]
		list_of_unclassified_fts = find_unique_features_from_two_feature_collections(list_of_valid_line_fts,list_of_valid_tectonic_fts)
		if (len(list_of_unclassified_fts) > 0):
			if (reference is not None):
				#line_features
				pygplates.reconstruct(list_of_unclassified_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				#line_features
				pygplates.reconstruct(list_of_unclassified_fts,rotation_model,reconstructed_line_features,reconstruction_time, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_tectonic_fts,rotation_model,reconstructed_tectonic_features,reconstruction_time, group_with_feature = True)
			final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			final_reconstructed_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_tectonic_features,pygplates.PolylineOnSphere)
			for unclassified_ft,unclassified_line in final_reconstructed_line_features:
				#find the centroid of the unclassified_line
				centroid = unclassified_line.get_centroid()
				lat,lon = centroid.to_lat_lon()
				#find the buffer based on the centroid
				buffer = geodesic_point_buffer(lat, lon, buffer_distance_km)
				buffer_polygon = Polygon(buffer)
				# print(buffer)
				# print(buffer_polygon)
				#convert Polygon to PolygonOnSphere
				buffer_PolygonOnSphere = supporting.convert_Polygon_to_PolygonOnSphere_in_pygplates(buffer_polygon)
				neighbour_features_and_geometries[:] = []
				number_of_convergent_fts = 0 
				number_of_divergent_fts = 0
				closest_div_feature = None
				closest_div_distance = -1.00
				closest_conv_feature = None
				closest_conv_distance = -1.00
				unclassified_ft_GDU_id = unclassified_ft.get_reconstruction_plate_id()
				for tectonic_ft,tectonic_line in final_reconstructed_tectonic_features:
					if ((buffer_PolygonOnSphere.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting or buffer_PolygonOnSphere.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.inside)):
						neighbour_features_and_geometries.append((tectonic_ft,tectonic_line))
						centroid_of_line_lat,centroid_of_line_lon = tectonic_line.get_centroid().to_lat_lon()
						dist = supporting.calculate_distance_km_between_two_points_from_haversine_formula(lat,lon,centroid_of_line_lat,centroid_of_line_lon)
						#obtain the feature type of tectonic ft
						featureType = tectonic_ft.get_feature_type()
						if (featureType == pygplates.FeatureType.gpml_subduction_zone):
							number_of_convergent_fts = number_of_convergent_fts + 1
							if (closest_conv_distance == -1.00 and closest_conv_feature is None):
								closest_conv_distance = dist
								closest_conv_feature = tectonic_ft
							elif (closest_conv_distance > -1.00 and dist < closest_conv_distance):
								closest_conv_distance = dist
								closest_conv_feature = tectonic_ft
						elif (featureType == pygplates.FeatureType.gpml_passive_continental_boundary):
							number_of_divergent_fts = number_of_divergent_fts + 1
							if (closest_div_distance == -1.00 and closest_div_feature is None):
								closest_div_distance = dist
								closest_div_feature = tectonic_ft
							elif (closest_div_distance > -1.00 and dist < closest_div_distance):
								closest_div_distance = dist
								closest_div_feature = tectonic_ft
				if (number_of_divergent_fts > number_of_convergent_fts):
					# unclassified_ft is divergent_feature
					left = closest_div_feature.get_left_plate()
					right = closest_div_feature.get_right_plate()
					final_left = -1
					final_right = -1
					if (left == closest_div_feature.get_reconstruction_plate_id()):
						if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_left = unclassified_ft.get_reconstruction_plate_id()
							final_right = right
						elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_right = unclassified_ft.get_reconstruction_plate_id()
							final_left = right
					elif (right == closest_div_feature.get_reconstruction_plate_id()):
						if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_left = unclassified_ft.get_reconstruction_plate_id()
							final_right = left
						elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_right = unclassified_ft.get_reconstruction_plate_id()
							final_left = left
					valid_time = closest_div_feature.get_valid_time()
					new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,unclassified_line,name='inferred_divergent_ft_from_'+str(closest_div_feature.get_reconstruction_plate_id()),valid_time = valid_time,reconstruction_plate_id = unclassified_ft.get_reconstruction_plate_id())
					try:
						new_ft.set_left_plate(final_left)					
						new_ft.set_right_plate(final_right)
					except (Exception):
						print('left')
						print(left)
						print('right')
						print(right)
						print('closest_div_feature.get_reconstruction_plate_id()')
						print(closest_div_feature.get_reconstruction_plate_id())
						print('unclassified_ft.get_reconstruction_plate_id()')
						print(unclassified_ft.get_reconstruction_plate_id())
						print('unclassified_ft.get_left_plate()')
						print(unclassified_ft.get_left_plate())
						print('unclassified_ft.get_right_plate()')
						print(unclassified_ft.get_right_plate())
					inferred_tectonic_features.append(new_ft)
					already_proccessed_ft.append(unclassified_ft.get_feature_id().get_string())
				elif (number_of_divergent_fts < number_of_convergent_fts):
					# unclassified_ft is convergent_feature
					left = closest_conv_feature.get_left_plate()
					right = closest_conv_feature.get_right_plate()
					final_left = -1
					final_right = -1
					if (left == closest_conv_feature.get_reconstruction_plate_id()):
						if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_left = unclassified_ft.get_reconstruction_plate_id()
							final_right = right
						elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_right = unclassified_ft.get_reconstruction_plate_id()
							final_left = right
					elif (right == closest_conv_feature.get_reconstruction_plate_id()):
						if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_left = unclassified_ft.get_reconstruction_plate_id()
							final_right = left
						elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
							final_right = unclassified_ft.get_reconstruction_plate_id()
							final_left = left
					valid_time = closest_conv_feature.get_valid_time()
					new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name='inferred_convergent_ft_from_'+str(closest_conv_feature.get_reconstruction_plate_id()),valid_time = valid_time,reconstruction_plate_id = unclassified_ft.get_reconstruction_plate_id())
					try:
						new_ft.set_left_plate(final_left)					
						new_ft.set_right_plate(final_right)
					except (Exception):
						print('left')
						print(left)
						print('right')
						print(right)
						print('closest_conv_feature.get_reconstruction_plate_id()')
						print(closest_conv_feature.get_reconstruction_plate_id())
						print('unclassified_ft.get_reconstruction_plate_id()')
						print(unclassified_ft.get_reconstruction_plate_id())
						print('unclassified_ft.get_left_plate()')
						print(unclassified_ft.get_left_plate())
						print('unclassified_ft.get_right_plate()')
						print(unclassified_ft.get_right_plate())
					inferred_tectonic_features.append(new_ft)
					already_proccessed_ft.append(unclassified_ft.get_feature_id().get_string())
				else:
					#have to find which is the closer one
					if (closest_conv_distance > -1.00 and closest_div_distance > -1.00 and closest_conv_distance > closest_div_distance):
						# unclassified_ft is divergent_feature
						left = closest_div_feature.get_left_plate()
						right = closest_div_feature.get_right_plate()
						final_left = -1
						final_right = -1
						if (left == closest_div_feature.get_reconstruction_plate_id()):
							if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_left = unclassified_ft.get_reconstruction_plate_id()
								final_right = right
							elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_right = unclassified_ft.get_reconstruction_plate_id()
								final_left = right
						elif (right == closest_div_feature.get_reconstruction_plate_id()):
							if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_left = unclassified_ft.get_reconstruction_plate_id()
								final_right = left
							elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_right = unclassified_ft.get_reconstruction_plate_id()
								final_left = left
						valid_time = closest_div_feature.get_valid_time()
						new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,unclassified_line,name='inferred_divergent_ft_from_'+str(closest_div_feature.get_reconstruction_plate_id()),valid_time = valid_time,reconstruction_plate_id = unclassified_ft.get_reconstruction_plate_id())
						new_ft.set_description(closest_div_feature.get_description())
						try:
							new_ft.set_left_plate(final_left)					
							new_ft.set_right_plate(final_right)
						except (Exception):
							print('left')
							print(left)
							print('right')
							print(right)
							print('closest_div_feature.get_reconstruction_plate_id()')
							print(closest_div_feature.get_reconstruction_plate_id())
							print('unclassified_ft.get_reconstruction_plate_id()')
							print(unclassified_ft.get_reconstruction_plate_id())
							print('unclassified_ft.get_left_plate()')
							print(unclassified_ft.get_left_plate())
							print('unclassified_ft.get_right_plate()')
							print(unclassified_ft.get_right_plate())
						inferred_tectonic_features.append(new_ft)
						already_proccessed_ft.append(unclassified_ft.get_feature_id().get_string())
					elif (closest_conv_distance > -1.00 and closest_div_distance > -1.00 and closest_conv_distance <= closest_div_distance):
						# unclassified_ft is convergent_feature
						left = closest_conv_feature.get_left_plate()
						right = closest_conv_feature.get_right_plate()
						final_left = -1
						final_right = -1
						if (left == closest_conv_feature.get_reconstruction_plate_id()):
							if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_left = unclassified_ft.get_reconstruction_plate_id()
								final_right = right
							elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_right = unclassified_ft.get_reconstruction_plate_id()
								final_left = right
						elif (right == closest_conv_feature.get_reconstruction_plate_id()):
							if (unclassified_ft.get_left_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_left = unclassified_ft.get_reconstruction_plate_id()
								final_right = left
							elif (unclassified_ft.get_right_plate() == unclassified_ft.get_reconstruction_plate_id()):
								final_right = unclassified_ft.get_reconstruction_plate_id()
								final_left = left
						valid_time = closest_conv_feature.get_valid_time()
						new_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name='inferred_convergent_ft_from_'+str(closest_conv_feature.get_reconstruction_plate_id()),valid_time = valid_time,reconstruction_plate_id = unclassified_ft.get_reconstruction_plate_id())
						new_ft.set_description(closest_conv_feature.get_description())
						try:
							new_ft.set_left_plate(final_left)					
							new_ft.set_right_plate(final_right)
						except (Exception):
							print('left')
							print(left)
							print('right')
							print(right)
							print('closest_conv_feature.get_reconstruction_plate_id()')
							print(closest_conv_feature.get_reconstruction_plate_id())
							print('unclassified_ft.get_reconstruction_plate_id()')
							print(unclassified_ft.get_reconstruction_plate_id())
							print('unclassified_ft.get_left_plate()')
							print(unclassified_ft.get_left_plate())
							print('unclassified_ft.get_right_plate()')
							print(unclassified_ft.get_right_plate())
						inferred_tectonic_features.append(new_ft)
						already_proccessed_ft.append(unclassified_ft.get_feature_id().get_string())
			#reverse_reconstruct
			if (reference is not None):
				pygplates.reverse_reconstruct(inferred_tectonic_features,rotation_model,reconstruction_time,reference)
			else:
				pygplates.reverse_reconstruct(inferred_tectonic_features,rotation_model,reconstruction_time)
			#collect inferred tectonic_features in outputFeatureCollection
			for inferred_ft in inferred_tectonic_features:
				outputLinesFeatureCollection.add(inferred_ft.clone())
				#not so sure 'great idea'
				tectonic_features.add(inferred_ft.clone())
			#clean up inferred_tectonic_features for next reconstruction_time
			inferred_tectonic_features[:] = []
		#update reconstruction_time
		reconstruction_time = reconstruction_time-interval
	
	# if conn is not None:
		# conn.close()
	
	outputLinesFile = "new_inferred_tectonic_features_within_proximal_dist_km_"+str(buffer_distance_km)+"_"+modelname+"_"+yyyymmdd+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFile = "new_inferred_tectonic_features_within_proximal_dist_km_"+str(buffer_distance_km)+"_"+modelname+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)

def resolve_controversial_tectonic_boundaries_features_without_SuperGDU(rotation_model, tectonic_features, buffer_distance_km, begin, end, interval, reference, modelname, yyyymmdd):
	"""
		Using buffer zone to find neighbours and decide the type of a tectonic boundary that was classified as convergent and divergent margin
	"""
	reconstructed_line_features = []
	reconstructed_div_tectonic_features = []
	reconstructed_conv_tectonic_features = []
	neighbour_features_and_geometries = []
	
	reconstruction_time = begin
	outputLinesFeatureCollection = pygplates.FeatureCollection()
	while (reconstruction_time > (end - interval)):
		print('reconstruction_time')
		print(reconstruction_time)
		#clean up the storages
		reconstructed_line_features[:] = []
		reconstructed_div_tectonic_features[:] = []
		reconstructed_conv_tectonic_features[:] = []
		list_of_valid_divergent_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time) and (ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary)]
		list_of_valid_convergent_tectonic_fts = [ft for ft in tectonic_features if ft.is_valid_at_time(reconstruction_time) and (ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone)]
		#debug
		print ('len(list_of_valid_divergent_tectonic_fts)')
		print(len(list_of_valid_divergent_tectonic_fts))
		print('len(list_of_valid_convergent_tectonic_fts)')
		print(len(list_of_valid_convergent_tectonic_fts))
		list_of_controversial_fts = find_features_with_similar_geometry_from_two_feature_collections(list_of_valid_divergent_tectonic_fts,list_of_valid_convergent_tectonic_fts)
		
		#debug
		# for controversial_ft in list_of_controversial_fts:
			# print('featType of controversial_ft')
			# print(controversial_ft.get_feature_type())
			# print('featType description')
			# print(controversial_ft.get_description())
		
		print('number of controversial_fts')
		print(len(list_of_controversial_fts))
		if (len(list_of_controversial_fts) > 0):
			if (reference is not None):
				#line_features
				pygplates.reconstruct(list_of_controversial_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_divergent_tectonic_fts,rotation_model,reconstructed_div_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(list_of_valid_convergent_tectonic_fts,rotation_model,reconstructed_conv_tectonic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				#line_features
				pygplates.reconstruct(list_of_controversial_fts,rotation_model,reconstructed_line_features,reconstruction_time, group_with_feature = True)
				#tectonic_features
				pygplates.reconstruct(list_of_valid_divergent_tectonic_fts,rotation_model,reconstructed_div_tectonic_features,reconstruction_time, group_with_feature = True)
				pygplates.reconstruct(list_of_valid_convergent_tectonic_fts,rotation_model,reconstructed_conv_tectonic_features,reconstruction_time, group_with_feature = True)
			final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			final_reconstructed_div_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_div_tectonic_features,pygplates.PolylineOnSphere)
			final_reconstructed_conv_tectonic_features = supporting.find_final_reconstructed_geometries(reconstructed_conv_tectonic_features,pygplates.PolylineOnSphere)
			final_reconstructed_tectonic_features = final_reconstructed_div_tectonic_features + final_reconstructed_conv_tectonic_features
			for unclassified_ft,unclassified_line in final_reconstructed_line_features:
				#find the centroid of the unclassified_line
				centroid = unclassified_line.get_centroid()
				lat,lon = centroid.to_lat_lon()
				#find the buffer based on the centroid
				buffer = geodesic_point_buffer(lat, lon, buffer_distance_km)
				buffer_polygon = Polygon(buffer)
				# print(buffer)
				# print(buffer_polygon)
				#convert Polygon to PolygonOnSphere
				buffer_PolygonOnSphere = supporting.convert_Polygon_to_PolygonOnSphere_in_pygplates(buffer_polygon)
				neighbour_features_and_geometries[:] = []
				number_of_convergent_fts = 0 
				number_of_divergent_fts = 0
				closest_div_feature = None
				closest_div_distance = -1.00
				closest_conv_feature = None
				closest_conv_distance = -1.00
				unclassified_ft_GDU_id = unclassified_ft.get_reconstruction_plate_id()
				
				#debug
				number_of_convergent_fts_in_final_reconstructed_tectonic_features = 0
				for tectonic_ft,tectonic_line in final_reconstructed_tectonic_features:
					#debug
					if (tectonic_ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone):
						number_of_convergent_fts_in_final_reconstructed_tectonic_features = number_of_convergent_fts_in_final_reconstructed_tectonic_features + 1
					
					if ((buffer_PolygonOnSphere.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting or buffer_PolygonOnSphere.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.inside) or pygplates.GeometryOnSphere.distance(tectonic_line,unclassified_line) == 0.00):
						neighbour_features_and_geometries.append((tectonic_ft,tectonic_line))
						centroid_of_line_lat,centroid_of_line_lon = tectonic_line.get_centroid().to_lat_lon()
						dist = supporting.calculate_distance_km_between_two_points_from_haversine_formula(lat,lon,centroid_of_line_lat,centroid_of_line_lon)
						#obtain the feature type of tectonic ft
						featureType = tectonic_ft.get_feature_type()
						#print(featureType)
						if (featureType == pygplates.FeatureType.gpml_subduction_zone):
							number_of_convergent_fts = number_of_convergent_fts + 1
							if (closest_conv_distance == -1.00 and closest_conv_feature is None):
								closest_conv_distance = dist
								closest_conv_feature = tectonic_ft
							elif (closest_conv_distance > -1.00 and dist < closest_conv_distance):
								closest_conv_distance = dist
								closest_conv_feature = tectonic_ft
						elif (featureType == pygplates.FeatureType.gpml_passive_continental_boundary):
							number_of_divergent_fts = number_of_divergent_fts + 1
							if (closest_div_distance == -1.00 and closest_div_feature is None):
								closest_div_distance = dist
								closest_div_feature = tectonic_ft
							elif (closest_div_distance > -1.00 and dist < closest_div_distance):
								closest_div_distance = dist
								closest_div_feature = tectonic_ft
				print('number_of_convergent_fts_in_final_reconstructed_tectonic_features',number_of_convergent_fts_in_final_reconstructed_tectonic_features)
				print('number_of_divergent_fts',number_of_divergent_fts)
				print('number_of_convergent_fts',number_of_convergent_fts)
				if (number_of_divergent_fts > number_of_convergent_fts and number_of_divergent_fts > 0 and number_of_convergent_fts > 0):
					current_begin_age,current_end_age = closest_conv_feature.get_valid_time()
					if (current_begin_age == reconstruction_time):
						if ((current_begin_age - interval) == current_end_age):
							tectonic_features.remove(closest_conv_feature.get_feature_id())
						elif ((current_begin_age - interval) > current_end_age):
							closest_conv_feature.set_valid_time(current_begin_age - interval, current_end_age)
							tectonic_features.add(closest_conv_feature.clone())
							tectonic_features.remove(closest_conv_feature.get_feature_id())
					elif (current_begin_age > reconstruction_time and current_end_age < reconstruction_time):
						closest_conv_feature.set_valid_time(current_begin_age, reconstruction_time)
						tectonic_features.add(closest_conv_feature.clone())
						tectonic_features.remove(closest_conv_feature.get_feature_id())
				elif (number_of_divergent_fts < number_of_convergent_fts and number_of_divergent_fts > 0 and number_of_convergent_fts > 0):
					current_begin_age,current_end_age = closest_div_feature.get_valid_time()
					if (current_begin_age == reconstruction_time):
						if ((current_begin_age - interval) == current_end_age):
							tectonic_features.remove(closest_div_feature.get_feature_id())
						elif ((current_begin_age - interval) > current_end_age):
							closest_div_feature.set_valid_time(current_begin_age - interval, current_end_age)
							tectonic_features.add(closest_div_feature.clone())
							tectonic_features.remove(closest_div_feature.get_feature_id())
					elif (current_begin_age > reconstruction_time and current_end_age < reconstruction_time):
						closest_div_feature.set_valid_time(current_begin_age, reconstruction_time)
						tectonic_features.add(closest_div_feature.clone())
						tectonic_features.remove(closest_div_feature.get_feature_id())
				else:
					#have to find which is the closer one
					if (closest_conv_distance > -1.00 and closest_div_distance > -1.00 and closest_conv_distance > closest_div_distance and number_of_divergent_fts > 0 and number_of_convergent_fts > 0):
						# remove convergent_feature
						current_begin_age,current_end_age = closest_conv_feature.get_valid_time()
						if (current_begin_age == reconstruction_time):
							if ((current_begin_age - interval) == current_end_age):
								tectonic_features.remove(closest_conv_feature.get_feature_id())
							elif ((current_begin_age - interval) > current_end_age):
								closest_conv_feature.set_valid_time(current_begin_age - interval, current_end_age)
								tectonic_features.add(closest_conv_feature.clone())
								tectonic_features.remove(closest_conv_feature.get_feature_id())
						elif (current_begin_age > reconstruction_time and current_end_age < reconstruction_time):
							closest_conv_feature.set_valid_time(current_begin_age, reconstruction_time)
							tectonic_features.add(closest_conv_feature.clone())
							tectonic_features.remove(closest_conv_feature.get_feature_id())
					elif (closest_conv_distance > -1.00 and closest_div_distance > -1.00 and closest_conv_distance <= closest_div_distance and number_of_divergent_fts > 0 and number_of_convergent_fts > 0):
						# remove divergent_feature
						current_begin_age,current_end_age = closest_div_feature.get_valid_time()
						if (current_begin_age == reconstruction_time):
							if ((current_begin_age - interval) == current_end_age):
								tectonic_features.remove(closest_div_feature.get_feature_id())
							elif ((current_begin_age - interval) > current_end_age):
								closest_div_feature.set_valid_time(current_begin_age - interval, current_end_age)
								tectonic_features.add(closest_div_feature.clone())
								tectonic_features.remove(closest_div_feature.get_feature_id())
						elif (current_begin_age > reconstruction_time and current_end_age < reconstruction_time):
							closest_div_feature.set_valid_time(current_begin_age, reconstruction_time)
							tectonic_features.add(closest_div_feature.clone())
							tectonic_features.remove(closest_div_feature.get_feature_id())
		#update reconstruction_time
		reconstruction_time = reconstruction_time-interval
	
	# if conn is not None:
		# conn.close()
	
	outputLinesFile = "resolved_controversial_tectonic_features_without_SuperGDU_within_proximal_dist_km_"+str(buffer_distance_km)+"_"+modelname+"_"+yyyymmdd+".shp"
	tectonic_features.write(outputLinesFile)
	outputLinesFile = "resolved_controversial_tectonic_features_without_SuperGDU_within_proximal_dist_km_"+str(buffer_distance_km)+"_"+modelname+"_"+yyyymmdd+".gpml"
	tectonic_features.write(outputLinesFile)

def clean_up_messy_tectonic_boundaries_based_on_geological_topology(messy_tectonic_boundaries_feature, time_interval_uncertainty ,test_number, modelname, yearmonthday):
	outputLinesFeatureCollection = pygplates.FeatureCollection()
	conn = None
	cur = None
	cur_1 = None
	cur_3 = None	
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		for tectonic_boundary_ft in messy_tectonic_boundaries_feature:
			tectonic_boundary_descr = tectonic_boundary_ft.get_description()
			initial_line_ft_id = tectonic_boundary_ft.get_name()
			begin_age, end_age = tectonic_boundary_ft.get_valid_time()
			temp_left_id = tectonic_boundary_ft.get_left_plate()
			temp_right_id = tectonic_boundary_ft.get_right_plate()
			txt = """SELECT from_time, to_time FROM tectonic_topological_line_fts WHERE initial_ft_id = {input_initial_line_ft_id} AND type_of_line_fts = 'CON_OCN' ORDER BY from_time DESC"""
			#txt_1 = """SELECT from_time, to_time FROM tectonic_topological_line_fts WHERE to_time = (SELECT MIN(to_time) FROM tectonic_topological_line_fts WHERE initial_ft_id = {input_initial_line_ft_id} AND type_of_line_fts = 'CON_OCN') and initial_ft_id = {input_initial_line_ft_id} and type_of_line_fts = 'CON_OCN' ORDER BY from_time DESC """
			txt_1 = """SELECT from_time, to_time FROM tectonic_topological_line_fts WHERE initial_ft_id = {input_initial_line_ft_id} 
						AND ((to_time < {input_from_time} and from_time >= {input_from_time} and to_time < {input_to_time})
							  OR (to_time <= {input_to_time} and from_time > {input_to_time} and from_time <= {input_from_time})) 
						AND type_of_line_fts = 'CON_OCN' ORDER BY from_time DESC """
			txt_3 = """SELECT tectonic_motion FROM test_summary_of_tectonic_motion WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id})) and to_time - {input_begin} <= {input_interval} """
			txt_4 = """SELECT COUNT (*) FROM temporal_output_tectonic_boundaries_during_identification
						WHERE to_time <= {input_time} and (ref_gdu_id = {input_gdu_id} or other_gdu_id = {input_gdu_id}) and tectonic_motion = 'Convergence'; """
			txt_5 = """SELECT COUNT (*) FROM temporal_output_tectonic_boundaries_during_identification
						WHERE to_time <= {input_time} and (ref_gdu_id = {input_gdu_id} or other_gdu_id = {input_gdu_id}) and tectonic_motion = 'Divergence'; """
			txt_6 = """SELECT COUNT (*) FROM temporal_output_tectonic_boundaries_during_identification
						WHERE to_time <= {input_time} and (ref_gdu_id = {input_gdu_id} or other_gdu_id = {input_gdu_id}) and tectonic_motion = 'Transform'; """
			sql = txt.format(input_initial_line_ft_id = '\''+initial_line_ft_id+'\'')
			cur.execute(sql)
			rows = cur.fetchall()
			#print(sql)
			#print(rows)
			chosen_from_time,chosen_to_time = -1.00,-1.00
			if(len(rows) > 0):
				print("number of records CON-OCN for line ft w id:", initial_line_ft_id, len(rows))
				for r in rows:
					from_time = float(r[0])
					to_time = float(r[1])
					if ((from_time >= begin_age and to_time <= end_age) or (from_time >= begin_age and to_time == 0.00 and end_age < 0.00)):
						# chosen_from_time = begin_age
						# chosen_to_time = end_age
						if (tectonic_boundary_descr == 'unknown'):
							chosen_to_time = to_time
						else:
							chosen_to_time = end_age
						break
				if (chosen_from_time == -1.00 or chosen_to_time == -1.00):
					sql_1 = txt_1.format(input_initial_line_ft_id = '\''+initial_line_ft_id+'\'', input_to_time = end_age, input_from_time = begin_age, input_uncertainty = time_interval_uncertainty)
					cur_1.execute(sql_1)
					min_difference = -1.00
					
					row_1 = cur_1.fetchone()
					while (row_1 is not None):
						pos_from_time = float(row_1[0])
						pos_to_time = float(row_1[1])
						diff_begin_age = abs(pos_from_time - begin_age)
						diff_end_age = abs(pos_to_time - end_age)
						if (diff_begin_age > diff_end_age):
							if (min_difference == -1.00 or (min_difference > -1.00 and min_difference > diff_end_age)):
								min_difference = diff_end_age
								chosen_from_time = pos_from_time
								chosen_to_time = pos_to_time
						else:
							if (min_difference == -1.00 or (min_difference > -1.00 and min_difference > diff_begin_age)):
								min_difference = diff_begin_age
								chosen_from_time = pos_from_time
								chosen_to_time = pos_to_time
						row_1 = cur_1.fetchone()
				print('chosen_from_time,chosen_to_time')
				print(chosen_from_time,chosen_to_time)
				print(temp_left_id)
				print(temp_right_id)
				if (chosen_from_time != -1.00 and chosen_to_time != -1.00):
					# tectonic_boundary_ft.set_valid_time(chosen_from_time,chosen_to_time)
					# outputLinesFeatureCollection.add(tectonic_boundary_ft)
					if (tectonic_boundary_descr == 'unknown'): 
						sql_3 = txt_3.format(input_ref_gdu_id = temp_left_id, input_other_gdu_id = temp_right_id , input_begin = begin_age, input_interval = time_interval_uncertainty)
						cur_3.execute(sql_3)
						row_3 = cur_3.fetchone()
						new_tectonic_bdn_ft = None
						if (row_3 is not None):
							last_tectonic_boundary_descr = row_3[0]
							if (last_tectonic_boundary_descr == "Convergence"):
								new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,tectonic_boundary_ft.get_geometry(), name = tectonic_boundary_ft.get_name(), description = "unknown_convergent_margin", valid_time = (chosen_from_time, chosen_to_time), reconstruction_plate_id = tectonic_boundary_ft.get_reconstruction_plate_id())
								new_tectonic_bdn_ft.set_left_plate(temp_left_id)
								new_tectonic_bdn_ft.set_right_plate(temp_right_id)
							elif (last_tectonic_boundary_descr == "Divergence"):
								new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,tectonic_boundary_ft.get_geometry(), name = tectonic_boundary_ft.get_name(), description = "divergent_margin", valid_time = (chosen_from_time, chosen_to_time), reconstruction_plate_id = tectonic_boundary_ft.get_reconstruction_plate_id())
								new_tectonic_bdn_ft.set_left_plate(temp_left_id)
								new_tectonic_bdn_ft.set_right_plate(temp_right_id)
							elif (last_tectonic_boundary_descr == "Transform"):
								new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,tectonic_boundary_ft.get_geometry(), name = tectonic_boundary_ft.get_name(), description = "transform_fault", valid_time = (chosen_from_time, chosen_to_time), reconstruction_plate_id = tectonic_boundary_ft.get_reconstruction_plate_id())
								new_tectonic_bdn_ft.set_left_plate(temp_left_id)
								new_tectonic_bdn_ft.set_right_plate(temp_right_id)
						if (new_tectonic_bdn_ft is None):
							tectonic_boundary_ft.set_valid_time(chosen_from_time,chosen_to_time)
							outputLinesFeatureCollection.add(tectonic_boundary_ft)
						else:
							outputLinesFeatureCollection.add(new_tectonic_bdn_ft)
					else:
						tectonic_boundary_ft.set_valid_time(chosen_from_time,chosen_to_time)
						outputLinesFeatureCollection.add(tectonic_boundary_ft)
				
			else:#summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion(from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id, line_1_ft_name, line_2_ft_name)
				print("Warning: no records of CON-OCN line features for tectonic_bdn_ft with id:",initial_line_ft_id,"within period",begin_age,end_age)
				
				# txt_2 = """SELECT line_1_ft_name, line_2_ft_name 
				# FROM summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion
				# WHERE from_time = {input_from_age} AND to_time = {input_to_age} 
				# AND ((ref_gdu_id = {input_ref_gdu_id} AND other_gdu_id = {input_other_gdu_id}) or (ref_gdu_id = {input_other_gdu_id} AND other_gdu_id = {input_ref_gdu_id})) 
				# AND tectonic_motion = {input_tectonic_motion}"""
				# in_tectonic_motion = None
				# if (tectonic_boundary_ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone):
					# in_tectonic_motion = "Convergence"
				# elif (tectonic_boundary_ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary):
					# in_tectonic_motion = "Divergence"
				# elif (tectonic_boundary_ft.get_feature_type() == pygplates.FeatureType.gpml_transform):
					# in_tectonic_motion = "Transform"
				# sql_2 = txt_2.format(input_from_age = begin_age, input_to_age = end_age, input_ref_gdu_id = tectonic_boundary_ft.get_left_plate(), input_other_gdu_id = tectonic_boundary_ft.get_right_plate(), input_tectonic_motion = '\''+in_tectonic_motion+'\'')
				# cur_2.execute(sql_2)
				# rows_2 = cur_2.fetchall()
				# if (len(rows_2) > 1):
					# print("Warning: there are more than one record satisfies from_time, to_time, ref_gdu_id, other_gdu_id, tectonic_motion", begin_age, end_age,tectonic_boundary_ft.get_left_plate(),tectonic_boundary_ft.get_right_plate_plate(),in_tectonic_motion)
				# row_2 = rows_2[0]
				# initial_line_ft_id = row_2[0]
				# sql = txt.format(input_initial_line_ft_id = '\''+initial_line_ft_id+'\'')
				# cur.execute(sql)
				# rows = cur.fetchall()
				# #print(sql)
				# #print(rows)
				# chosen_from_time,chosen_to_time = -1.00,-1.00
				# if(len(rows) > 0):
					# print("number of records CON-OCN for line ft w id:", initial_line_ft_id, len(rows))
					# for r in rows:
						# from_time = float(r[0])
						# to_time = float(r[1])
						# if (from_time >= begin_age and to_time <= end_age):
							# chosen_from_time = from_time
							# chosen_to_time = to_time
							# break
					# if (chosen_from_time == -1.00 or chosen_to_time == -1.00):
						# sql_1 = txt_1.format(input_initial_line_ft_id = '\''+initial_line_ft_id+'\'')
						# cur_1.execute(sql_1)
						# row_1 = cur_1.fetchone()
						# chosen_from_time = float(row_1[0])
						# chosen_to_time = float(row_1[0])
					# tectonic_boundary_ft.set_valid_time(chosen_from_time,chosen_to_time)
					# tectonic_boundary_ft.set_name(initial_line_ft_id)
					# outputLinesFeatureCollection.add(tectonic_boundary_ft)
				# else:
					# print("Warning: no records of CON-OCN line features for tectonic_bdn_ft with id:",initial_line_ft_id,"within period",begin_age,end_age,"after performing second query")
				# initial_line_ft_id = row_2[1]
				# sql = txt.format(input_initial_line_ft_id = '\''+initial_line_ft_id+'\'')
				# cur.execute(sql)
				# rows = cur.fetchall()
				# #print(sql)
				# #print(rows)
				# chosen_from_time,chosen_to_time = -1.00,-1.00
				# if(len(rows) > 0):
					# print("number of records CON-OCN for line ft w id:", initial_line_ft_id, len(rows))
					# for r in rows:
						# from_time = float(r[0])
						# to_time = float(r[1])
						# if (from_time >= begin_age and to_time <= end_age):
							# chosen_from_time = from_time
							# chosen_to_time = to_time
							# break
					# if (chosen_from_time == -1.00 or chosen_to_time == -1.00):
						# sql_1 = txt_1.format(input_initial_line_ft_id = '\''+initial_line_ft_id+'\'')
						# cur_1.execute(sql_1)
						# row_1 = cur_1.fetchone()
						# chosen_from_time = float(row_1[0])
						# chosen_to_time = float(row_1[0])
					# tectonic_boundary_ft.set_valid_time(chosen_from_time,chosen_to_time)
					# tectonic_boundary_ft.set_name(initial_line_ft_id)
					# outputLinesFeatureCollection.add(tectonic_boundary_ft)
				# else:
					# print("Warning: no records of CON-OCN line features for tectonic_bdn_ft with id:",initial_line_ft_id,"within period",begin_age,end_age,"after performing second query")
	except (psycopg2.DatabaseError) as error:
		print("Error in clean_up_messy_tectonic_boundaries_based_on_geological_topology")
		print(error)
	outputLinesFeatureCollection.write("clean_up_messy_tectonic_boundaries_based_on_geological_topology_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def clean_up_messy_tectonic_boundaries_based_on_geol_topology_temp_bdn(messy_tectonic_boundaries_feature, time_interval_uncertainty ,test_number, modelname, yearmonthday):
	outputLinesFeatureCollection = pygplates.FeatureCollection()
	conn = None
	cur = None
	cur_1 = None
	cur_3 = None	
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		cur_5 = conn.cursor()
		cur_6 = conn.cursor()
		#dic = {}
		for tectonic_boundary_ft in messy_tectonic_boundaries_feature:
			tectonic_boundary_descr = tectonic_boundary_ft.get_description()
			initial_line_ft_id = tectonic_boundary_ft.get_name()
			begin_age, end_age = tectonic_boundary_ft.get_valid_time()
			temp_left_id = tectonic_boundary_ft.get_left_plate()
			temp_right_id = tectonic_boundary_ft.get_right_plate()
			txt = """SELECT from_time, to_time FROM tectonic_topological_line_fts WHERE initial_ft_id = {input_initial_line_ft_id} AND type_of_line_fts = 'CON_OCN' ORDER BY from_time DESC"""
			#txt_1 = """SELECT from_time, to_time FROM tectonic_topological_line_fts WHERE to_time = (SELECT MIN(to_time) FROM tectonic_topological_line_fts WHERE initial_ft_id = {input_initial_line_ft_id} AND type_of_line_fts = 'CON_OCN') and initial_ft_id = {input_initial_line_ft_id} and type_of_line_fts = 'CON_OCN' ORDER BY from_time DESC """
			txt_1 = """SELECT from_time, to_time FROM tectonic_topological_line_fts WHERE initial_ft_id = {input_initial_line_ft_id} 
					AND ((to_time < {input_from_time} and from_time >= {input_from_time} and to_time < {input_to_time})
							  OR (to_time <= {input_to_time} and from_time > {input_to_time} and from_time <= {input_from_time})) 
						AND type_of_line_fts = 'CON_OCN' ORDER BY from_time DESC """
			txt_4 = """SELECT COUNT (*) FROM temporal_output_tectonic_boundaries_during_identification
						WHERE to_time <= {input_time} and abs(from_time - {input_time}) <= {input_time_interval} and (ref_gdu_id = {input_gdu_id} or other_gdu_id = {input_gdu_id}) and tectonic_motion = 'Convergence'; """
			txt_5 = """SELECT COUNT (*) FROM temporal_output_tectonic_boundaries_during_identification
						WHERE to_time <= {input_time} and abs(from_time - {input_time}) <= {input_time_interval} and (ref_gdu_id = {input_gdu_id} or other_gdu_id = {input_gdu_id}) and tectonic_motion = 'Divergence'; """
			txt_6 = """SELECT COUNT (*) FROM temporal_output_tectonic_boundaries_during_identification
						WHERE to_time <= {input_time} and abs(from_time - {input_time}) <= {input_time_interval} and (ref_gdu_id = {input_gdu_id} or other_gdu_id = {input_gdu_id}) and tectonic_motion = 'Transform'; """
			sql = txt.format(input_initial_line_ft_id = '\''+initial_line_ft_id+'\'')
			cur.execute(sql)
			rows = cur.fetchall()
				#print(sql)
				#print(rows)
			chosen_from_time,chosen_to_time = -1.00,-1.00
			chosen_from_time = begin_age
			if(len(rows) > 0):
				print("number of records CON-OCN for line ft w id:", initial_line_ft_id, len(rows)) 
				for r in rows:
					from_time = float(r[0])
					to_time = float(r[1])
					if ((from_time >= begin_age and to_time <= end_age) or (from_time >= begin_age and to_time == 0.00 and end_age < 0.00)):
						# chosen_from_time = begin_age
						chosen_to_time = end_age
						# if (tectonic_boundary_descr == 'unknown'):
							# chosen_to_time = to_time
						# else:
							# chosen_to_time = end_age
						break
				if (chosen_to_time == -1.00):
					sql_1 = txt_1.format(input_initial_line_ft_id = '\''+initial_line_ft_id+'\'', input_to_time = end_age, input_from_time = begin_age, input_uncertainty = time_interval_uncertainty)
					cur_1.execute(sql_1)
					min_difference = -1.00
					row_1 = cur_1.fetchone()
					while (row_1 is not None):
						pos_from_time = float(row_1[0])
						pos_to_time = float(row_1[1])
						diff_begin_age = abs(pos_from_time - begin_age)
						diff_end_age = abs(pos_to_time - end_age)
						if (diff_begin_age > diff_end_age):
							if (min_difference == -1.00 or (min_difference > -1.00 and min_difference > diff_end_age)):
								min_difference = diff_end_age
								if (pos_from_time > begin_age):
									chosen_from_time = begin_age
								else:
									chosen_from_time = pos_from_time
								if (pos_to_time > end_age):
									chosen_to_time = pos_to_time
								else:
									chosen_to_time = end_age
						else:
							if (min_difference == -1.00 or (min_difference > -1.00 and min_difference > diff_begin_age)):
								min_difference = diff_begin_age
								if (pos_from_time > begin_age):
									chosen_from_time = begin_age
								else:
									chosen_from_time = pos_from_time
								if (pos_to_time > end_age):
									chosen_to_time = pos_to_time
								else:
									chosen_to_time = end_age
						row_1 = cur_1.fetchone()
				print('chosen_from_time,chosen_to_time')
				print(chosen_from_time,chosen_to_time)
				print(temp_left_id)
				print(temp_right_id)
				if (chosen_from_time != -1.00 and chosen_to_time != -1.00):
					# tectonic_boundary_ft.set_valid_time(chosen_from_time,chosen_to_time)
					# outputLinesFeatureCollection.add(tectonic_boundary_ft)
					if (tectonic_boundary_descr == 'unknown'): 
						num_convergence = -1
						num_divergence = -1
						num_transform = -1
						sql_4 = txt_4.format(input_time = float(chosen_from_time - chosen_to_time)/2.00, input_time_interval = time_interval_uncertainty,input_gdu_id = tectonic_boundary_ft.get_reconstruction_plate_id())
						cur_4.execute(sql_4)
						row_4 = cur_4.fetchone()
						if (row_4 is not None):
							num_convergence = int(row_4[0])
						sql_5 = txt_5.format(input_time = float(chosen_from_time - chosen_to_time)/2.00, input_time_interval = time_interval_uncertainty, input_gdu_id = tectonic_boundary_ft.get_reconstruction_plate_id())
						cur_5.execute(sql_5)
						row_5 = cur_5.fetchone()
						if (row_5 is not None):
							num_divergence = int(row_5[0])
						sql_6 = txt_6.format(input_time = float(chosen_from_time - chosen_to_time)/2.00, input_time_interval = time_interval_uncertainty, input_gdu_id = tectonic_boundary_ft.get_reconstruction_plate_id())
						cur_6.execute(sql_6)
						row_6 = cur_6.fetchone()
						if (row_6 is not None):
							num_transform = int(row_6[0])
						new_tectonic_bdn_ft = None
						last_tectonic_boundary_descr = None
						max_num = -1
						max_num = max(num_convergence,num_divergence,num_transform)
						if (max_num == num_convergence):
							last_tectonic_boundary_descr == "Convergence"
						elif (max_num == num_divergence):
							last_tectonic_boundary_descr == "Divergence"
						elif (max_num == num_transform):
							last_tectonic_boundary_descr == "Transform"
						if (max_num > -1):
							if (last_tectonic_boundary_descr == "Convergence"):
								new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,tectonic_boundary_ft.get_geometry(), name = tectonic_boundary_ft.get_name(), description = "unknown_convergent_margin", valid_time = (chosen_from_time, chosen_to_time), reconstruction_plate_id = tectonic_boundary_ft.get_reconstruction_plate_id())
								new_tectonic_bdn_ft.set_left_plate(temp_left_id)
								new_tectonic_bdn_ft.set_right_plate(temp_right_id)
							elif (last_tectonic_boundary_descr == "Divergence"):
								new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,tectonic_boundary_ft.get_geometry(), name = tectonic_boundary_ft.get_name(), description = "divergent_margin", valid_time = (chosen_from_time, chosen_to_time), reconstruction_plate_id = tectonic_boundary_ft.get_reconstruction_plate_id())
								new_tectonic_bdn_ft.set_left_plate(temp_left_id)
								new_tectonic_bdn_ft.set_right_plate(temp_right_id)
							elif (last_tectonic_boundary_descr == "Transform"):
								new_tectonic_bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,tectonic_boundary_ft.get_geometry(), name = tectonic_boundary_ft.get_name(), description = "transform_fault", valid_time = (chosen_from_time, chosen_to_time), reconstruction_plate_id = tectonic_boundary_ft.get_reconstruction_plate_id())
								new_tectonic_bdn_ft.set_left_plate(temp_left_id)
								new_tectonic_bdn_ft.set_right_plate(temp_right_id)
						if (new_tectonic_bdn_ft is None):
							tectonic_boundary_ft.set_valid_time(chosen_from_time,chosen_to_time)
							outputLinesFeatureCollection.add(tectonic_boundary_ft)
							#dic[initial_line_ft_id] = None
						else:
							outputLinesFeatureCollection.add(new_tectonic_bdn_ft)
							#dic[initial_line_ft_id] = None
					else:
						tectonic_boundary_ft.set_valid_time(chosen_from_time,chosen_to_time)
						outputLinesFeatureCollection.add(tectonic_boundary_ft)
						#dic[initial_line_ft_id] = None
			else:#summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion(from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id, line_1_ft_name, line_2_ft_name)
				print("Warning: no records of CON-OCN line features for tectonic_bdn_ft with id:",initial_line_ft_id,"within period",begin_age,end_age)
	except (psycopg2.DatabaseError) as error:
		print("Error in clean_up_messy_tectonic_boundaries_based_on_geological_topology")
		print(error)
	outputLinesFeatureCollection.write("clean_up_messy_tectonic_boundaries_based_on_geol_topology_temp_bdn_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")
	
def identify_upper_plate_margins_from_porphyry_VMS_and_igneous_activities_approximated_plate_tectonic_margins(approximated_plate_tectonic_margins, possible_line_fts_for_subduction_zone_deposits, possible_line_fts_for_subduction_zone_igneous, modelname, test_number, yearmonthday):
	candidate_for_upper_and_lower_plate_fts = [ft for ft in approximated_plate_tectonic_margins if ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone]
	#possible_line_fts_for_subduction_zone_deposits_file = r"C:\Users\Lavie\Desktop\Research\Summer2021\utility\combined_filespossible_convergent_boundaries_from_deposits_data_PalaeoPlatesJune2021_20210812.gpml"
	#possible_line_fts_for_subduction_zone_igneous_file = r"C:\Users\Lavie\Desktop\Research\Summer2021\tectonic_boundaries\possible_subduction_zones_for_future_convergence_consider_all_buffersPalaeoPlates_June2021_test_1_from_igneous_DateView_only_2000_0_5Ma_20210812.gpml"
	outputLinesFeatureCollection = pygplates.FeatureCollection()
	for candidate_ft in candidate_for_upper_and_lower_plate_fts:
		ft_id = candidate_ft.get_name()
		upper_plate_margin_ft = None
		for possible_line_ft in possible_line_fts_for_subduction_zone_deposits:
			if (possible_line_ft.get_name() == ft_id):
				upper_plate_margin_ft = candidate_ft.clone()
				upper_plate_margin_ft.set_description("upper_plate_margin")
				outputLinesFeatureCollection.add(upper_plate_margin_ft)
				break
		if (upper_plate_margin_ft is None):
			for possible_line_ft in possible_line_fts_for_subduction_zone_igneous:
				if (possible_line_ft.get_name() == ft_id):
					upper_plate_margin_ft = candidate_ft.clone()
					upper_plate_margin_ft.set_description("upper_plate_margin")
					outputLinesFeatureCollection.add(upper_plate_margin_ft)
					break
			if (upper_plate_margin_ft is None):
				lower_plate_margin_ft = candidate_ft.clone()
				lower_plate_margin_ft.set_description("lower_plate_margin")
				outputLinesFeatureCollection.add(lower_plate_margin_ft)
	fts_not_subduction_zone = [ft for ft in approximated_plate_tectonic_margins if ft.get_feature_type() != pygplates.FeatureType.gpml_subduction_zone]
	for non_candidate_ft in fts_not_subduction_zone:
		outputLinesFeatureCollection.add(non_candidate_ft)
	outputLinesFeatureCollection.write("informed_tectonic_boundaries_with_upper_and_lower_margins_from_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def identify_upper_plate_margins_from_porphyry_VMS_and_igneous_activities_approximated_plate_tectonic_margins_with_buffer(rotation_model,unknown_convergent_margin_line_features,deposits_or_geochron_buffer_features,interval,reference,modelname,yearmonthday):
	list_of_candidate_line_fts = []
	reconstructed_line_features = []
	final_reconstructed_line_features = []
	reconstructed_buffer_features = []
	final_reconstructed_buffer_features = []
	#create a new property
	xsi_number_of_points = pygplates.PropertyName.create_xsi('number_of_points')
	#create a new property
	xsi_number_of_buffers = pygplates.PropertyName.create_xsi('number_of_buffers')
	final_list_of_line_fts = []
	last_output_shp = 0.00
	for ft in unknown_convergent_margin_line_features:
		ft_begin_age,ft_end_age = ft.get_valid_time()
		temp_reconstruction_time = ft_begin_age
		if (ft.get_description() == "unknown_convergent_margin" or ft.get_description() == "lower_plate_margin"):
			while (temp_reconstruction_time >= ft_end_age):
				#filtering buffer features 
				list_of_buffer_features = [ft for ft in deposits_or_geochron_buffer_features if ft.is_valid_at_time(temp_reconstruction_time)]
				print('len(list_of_buffer_features)')
				print(len(list_of_buffer_features))
				#reconstruct all features
				if (reference is not None):
					pygplates.reconstruct(list_of_buffer_features,rotation_model,reconstructed_buffer_features,ft_begin_age,anchor_plate_id = reference, group_with_feature = True)
					pygplates.reconstruct([ft],rotation_model,reconstructed_line_features,ft_begin_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_buffer_features,rotation_model,reconstructed_buffer_features,ft_begin_age, group_with_feature = True)
					pygplates.reconstruct([ft],rotation_model,reconstructed_line_features,ft_begin_age, group_with_feature = True)
				final_reconstructed_line_features[:] = []
				final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
				final_reconstructed_buffer_features[:] = []
				final_reconstructed_buffer_features = supporting.find_final_reconstructed_geometries(reconstructed_buffer_features,pygplates.PolygonOnSphere)
				#clearing lists
				reconstructed_line_features[:] = []
				reconstructed_buffer_features[:] = []
		
				line_ft,line = final_reconstructed_line_features[0]
				#obtain the plate id 
				plate_id = line_ft.get_reconstruction_plate_id()
			
				#list_of_associated_buffers = [(buffer_ft,buffer) for (buffer_ft,buffer) in final_reconstructed_buffer_features if (buffer_ft.get_reconstruction_plate_id() == plate_id)]
				list_of_associated_buffers = final_reconstructed_buffer_features
				#check to see how many buffers having a spatial relationship with line_ft
				count_buffers = 0
				count_points = 0
				for buffer_ft,buffer in final_reconstructed_buffer_features:
					if (buffer.partition(line) == pygplates.PolygonOnSphere.PartitionResult.intersecting or buffer.partition(line) == pygplates.PolygonOnSphere.PartitionResult.inside):
						count_buffers = count_buffers + 1
						count_points = count_points + int(buffer_ft.get_description())
				if (count_buffers > 0 and (ft.get_description() == "unknown_convergent_margin" or ft.get_description() == "lower_plate_margin")):
					#in the future when the new GPlates released we will create 2 new properties - for now we will use description field
					line_ft.set_description("upper_plate_margin")
					integer_property = pygplates.XsInteger(int(count_buffers))
					property_added = line_ft.add(xsi_number_of_buffers,integer_property,pygplates.VerifyInformationModel.no)
					integer_property = pygplates.XsInteger(int(count_points))
					property_added = line_ft.add(xsi_number_of_points,integer_property,pygplates.VerifyInformationModel.no)
					break
				temp_reconstruction_time = temp_reconstruction_time - interval
			if (ft.get_description() != "upper_plate_margin"):
				line_ft.set_description("lower_plate_margin")
				integer_property = pygplates.XsInteger(0)
				property_added = line_ft.add(xsi_number_of_buffers,integer_property,pygplates.VerifyInformationModel.no)
				integer_property = pygplates.XsInteger(0)
				property_added = line_ft.add(xsi_number_of_points,integer_property,pygplates.VerifyInformationModel.no)
		final_list_of_line_fts.append(line_ft)

	print("number of candidates in final_list_of_line_fts")
	print(len(final_list_of_line_fts))
	outputLinesFeatureCollection = pygplates.FeatureCollection(final_list_of_line_fts)
	outputLinesFile = "upper_plate_margins_"+modelname+"_"+str(interval)+"Ma_"+yearmonthday+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)

### I am thinking to write a new module to derive upper GDU boundaries
### for each unknown_convergent_margin find its partner from the database table
### reconstruct both features to the begin age of the convergence along with valid buffer zones 
### compare which margin feature intersecting buffer zones of porphyry, VMS or igneous database
### if both featurs intersect buffer zones, then I compare the count

### but the very best way is to identify which convergent margin feature associates with older oceanic crust