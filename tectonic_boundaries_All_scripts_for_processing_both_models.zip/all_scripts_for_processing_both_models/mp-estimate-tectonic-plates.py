import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
import estimate_tectonic_plates as estimate
from multiprocessing import Pool
from os import environ
from time import sleep

ncpus = int(environ['SLURM_CPUS_PER_TASK'])


all_supergdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
all_supergdu_features = pygplates.FeatureCollection(all_supergdu_features_file)
line_feats_from_div_process_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/diverging_line_features_for_2800.0_5.0_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
line_feats_from_div_process = pygplates.FeatureCollection(line_feats_from_div_process_file)
line_feats_from_conv_process_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/converging_line_features_for_2800.0_0.0_test_30_short_conv_PalaeoPlatesJan2023_20231023.shp"
line_feats_from_conv_process = pygplates.FeatureCollection(line_feats_from_conv_process_file)
plate_boundary_zone_feats_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
plate_boundary_zone_feats = pygplates.FeatureCollection(plate_boundary_zone_feats_file)
modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
rift_csv_file = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)
time_interval = 5.00
reference = 700
yearmonthday = '20231125'

def generate_list_of_filenames(start_order,end_order,common_filename_for_sgdu_features_file):
	list_of_filenames = []
	value = start_order
	while (value <= end_order):
		current_filename = common_filename_for_sgdu_features_file.format(file_order = str(value))
		list_of_filenames.append(current_filename)
		value = value + 1
	return list_of_filenames

def create_topological_sgdu_to_be_foundation_for_tectonic_plate(order_to_connect_lines_csv):
	splitted_string = order_to_connect_lines_csv.split('_')
	order_of_input_file = splitted_string[12]
	modelname = order_of_input_file+'_PalaeoPlatesendJan2023'
	#this is what we will do but for testing we can choose one SGDU at the time
	#select SuperGDU features from the csv file of order to connect CON-OCN line features 
	df_order = pd.read_csv(order_to_connect_lines_csv)
	unique_sgdu_name = df_order['sgdu'].unique()
	supergdu_features = pygplates.FeatureCollection()
	for sgdu_ft in all_supergdu_features:
		sgdu_name = sgdu_ft.get_name()
		if (np.isin(sgdu_name,unique_sgdu_name)):
			supergdu_features.add(sgdu_ft)
	#find begin_reconstruction_time
	begin_reconstruction_time = -1.00
	end_reconstruction_time = 99999.999
	for sgdu_ft in supergdu_features:
		sgdu_begin, sgdu_end = sgdu_ft.get_valid_time()
		if (begin_reconstruction_time == -1.00):
			begin_reconstruction_time = sgdu_begin
		elif (begin_reconstruction_time > 0.00 and begin_reconstruction_time < sgdu_begin):
			begin_reconstruction_time = sgdu_begin
		if (end_reconstruction_time == 99999.999):
			end_reconstruction_time = sgdu_begin
		elif (end_reconstruction_time > sgdu_end):
			end_reconstruction_time = sgdu_end
	estimate.create_tectonic_plates(order_to_connect_lines_csv, supergdu_features, line_feats_from_div_process, line_feats_from_conv_process, plate_boundary_zone_feats, modified_rift_point_features, rift_csv_file, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday)

if __name__ == '__main__':
	# common_filename_for_sgdu_features_file = r"temp_{file_order}_final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_20230425.shp"
	# start_order = 0
	# end_order = 39
	# list_of_filenames = generate_list_of_filenames(start_order,end_order,common_filename_for_sgdu_features_file)
	# print('list_of_filenames',list_of_filenames)
	# with Pool(ncpus) as pool:
		# #find isochrons
		# #results = pool.starmap(find_order_to_connect_complete_bdn_of_sgdu_feats_within_a_period, max_min_rec_time_list)
		# results = pool.map(find_order_to_connect_complete_bdn_of_sgdu_feats, list_of_filenames)
		# print(results)
	
	common_filename_for_sgdu_features_file = r"all_records_to_connect_con_ocn_line_feats_for_each_sgdu_temp_{file_order}_SGDUS_PalaeoPlatesendJan2023_from_max_time_2800.0_20231125.csv"
	start_order = 0
	end_order = 39
	list_of_filenames = generate_list_of_filenames(start_order,end_order,common_filename_for_sgdu_features_file)
	print('list_of_filenames',list_of_filenames)
	with Pool(ncpus) as pool:
		#find isochrons
		#results = pool.starmap(find_order_to_connect_complete_bdn_of_sgdu_feats_within_a_period, max_min_rec_time_list)
		results = pool.map(create_topological_sgdu_to_be_foundation_for_tectonic_plate, list_of_filenames)
		print(results)