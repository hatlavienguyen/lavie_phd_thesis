import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
def select_eliminate_duplicated_kinematic_line_features(rift_point_features_records_csv, rift_point_features, line_features, divergent_line_features, convergent_line_features, continental_arc_features, transform_features, plate_bdn_zone_features, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	reconstruction_time = begin_reconstruction_time
	valid_rift_point_features = []
	valid_line_features = []
	valid_div_line_features = []
	valid_conv_line_features = []
	valid_cont_arc_line_features = []
	valid_plate_bdn_line_features = []
	valid_transform_features = []
	dic_valid_line_feats = {}
	output_kin_line_feats = pygplates.FeatureCollection()
	while (reconstruction_time >= end_reconstruction_time):
		valid_rift_point_features[:] = []
		valid_line_features[:] = []
		valid_div_line_features[:] = []
		valid_conv_line_features[:] = []
		valid_cont_arc_line_features[:] = []
		valid_plate_bdn_line_features[:] = []
		valid_transform_features[:] = []
		
		for pt_ft in rift_point_features:
			if (pt_ft.is_valid_at_time(reconstruction_time)):
				valid_rift_point_features.append(pt_ft)
		for line_ft in line_features:
			if (line_ft.is_valid_at_time(reconstruction_time)):
				valid_line_features.append(line_ft)
		for div_line_ft in divergent_line_features:
			if (div_line_ft.is_valid_at_time(reconstruction_time)):
				valid_div_line_features.append(div_line_ft)
		for conv_line_ft in convergent_line_features:
			if (conv_line_ft.is_valid_at_time(reconstruction_time)):
				valid_conv_line_features.append(conv_line_ft)
		for plate_bdn_line_ft in plate_bdn_zone_features:
			if (plate_bdn_line_ft.is_valid_at_time(reconstruction_time)):
				valid_plate_bdn_line_features.append(plate_bdn_line_ft)
		for transform_ft in transform_features:
			if (transform_ft.is_valid_at_time(reconstruction_time)):
				valid_transform_features.append(plate_bdn_line_ft)
		if (continental_arc_features is not None):
			for continental_arc_ft in continental_arc_features:
				if (continental_arc_ft.is_valid_at_time(reconstruction_time)):
					valid_cont_arc_line_features.append(continental_arc_ft)
		#check and reset dic_valid_line_feats
		if (len(dic_valid_line_feats) > 0):
			for polylid in dic_valid_line_feats:
				if (dic_valid_line_feats[polylid] is not None):
					current_line_ft = dic_valid_line_feats[polylid]
					if (current_line_ft.is_valid_at_time(reconstruction_time) == False):
						output_kin_line_feats.add(current_line_ft)
						dic_valid_line_feats[polylid] = None
		for valid_line_ft in valid_line_features:
			polylid = valid_line_ft.get_name()
			if (polylid not in dic_valid_line_feats):
				dic_valid_line_feats[polylid] = None
		
		#find valid kinematic line features
		for rift_point_ft in valid_rift_point_features:
			#split rift_pt_name to get rift_name 
			rift_point_ft_name = rift_point_ft.get_name()
			list_of_splits = rift_point_ft_name.split("_")
			rift_name = list_of_splits[0]+'_'+list_of_splits[1]
			order = float(rift_point_ft.get_description())
			line_fts_df = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['order'] == order),['rpolylid','lpolylid','right_gdu','left_gdu']]
			if (len(line_fts_df) > 0):
				for rpolylid, lpolylid, right_gdu, left_gdu in line_fts_df.itertuples(index = False, name = None):
					if (rpolylid in dic_valid_line_feats):
						if (dic_valid_line_feats[rpolylid] is None):
							for div_line_ft in valid_div_line_features:
								if (div_line_ft.get_name() == rpolylid and div_line_ft.get_reconstruction_plate_id() == right_gdu and div_line_ft.get_conjugate_plate_id() == left_gdu):
									dic_valid_line_feats[rpolylid] = div_line_ft
									break
					else:
						for div_line_ft in valid_div_line_features:
							if (div_line_ft.get_name() == rpolylid and div_line_ft.get_reconstruction_plate_id() == right_gdu and div_line_ft.get_conjugate_plate_id() == left_gdu):
								dic_valid_line_feats[rpolylid] = div_line_ft
								break
					if (lpolylid in dic_valid_line_feats):
						if (dic_valid_line_feats[lpolylid] is None):
							for div_line_ft in valid_div_line_features:
								if (div_line_ft.get_name() == lpolylid and div_line_ft.get_reconstruction_plate_id() == left_gdu and div_line_ft.get_conjugate_plate_id() == right_gdu):
									dic_valid_line_feats[lpolylid] = div_line_ft
									break
					else:
						for div_line_ft in valid_div_line_features:
							if (div_line_ft.get_name() == lpolylid and div_line_ft.get_reconstruction_plate_id() == left_gdu and div_line_ft.get_conjugate_plate_id() == right_gdu):
								dic_valid_line_feats[lpolylid] = div_line_ft
								break
		for polylid in dic_valid_line_feats:
			current_line_ft = dic_valid_line_feats[polylid]
			if (current_line_ft is None):
				for conv_line_ft in valid_conv_line_features:
					if (conv_line_ft.get_name() == polylid):
						found_cont_arc = False
						for cont_arc_line_ft in valid_cont_arc_line_features:
							if (cont_arc_line_ft.get_name() == polylid):
								found_cont_arc = True
								dic_valid_line_feats[polylid] = cont_arc_line_ft
								break
						if (found_cont_arc == False):
							dic_valid_line_feats[polylid] = conv_line_ft
						break
				updated_current_line_ft = dic_valid_line_feats[polylid]
				if (updated_current_line_ft is None):
					for transform_ft in valid_transform_features:
						if (transform_ft.get_name() == polylid):
							dic_valid_line_feats[polylid] = transform_ft
							break
				second_update_current_line_ft = dic_valid_line_feats[polylid]
				if (second_update_current_line_ft is None):
					for div_line_ft in valid_div_line_features:
						if (div_line_ft.get_name() == polylid):
							dic_valid_line_feats[polylid] = div_line_ft
							break
				# semi_final_current_line_ft = dic_valid_line_feats[polylid]
				# if (semi_final_current_line_ft is None):
					# for cont_arc_line_ft in valid_cont_arc_line_features: #UNRELIABLE way to find continental arc and ultimately subduction zone
						# if (cont_arc_line_ft.get_name() == polylid):
							# #div_line_ft.set_description("inactive_div_margin")
							# dic_valid_line_feats[polylid] = cont_arc_line_ft
							# break
				final_current_line_ft = dic_valid_line_feats[polylid]
				if (final_current_line_ft is None):
					for plate_bdn_zone_ft in valid_plate_bdn_line_features:
						if (plate_bdn_zone_ft.get_name() == polylid):
							#div_line_ft.set_description("inactive_div_margin")
							dic_valid_line_feats[polylid] = plate_bdn_zone_ft
							break
		reconstruction_time = reconstruction_time - time_interval
	for final_polylid in dic_valid_line_feats:
		current_line_ft = dic_valid_line_feats[final_polylid]
		if (current_line_ft is not None):
			output_kin_line_feats.add(current_line_ft)
	output_kin_line_feats.write("final_unique_kine_line_feats_"+modelname+"_"+yearmonthday+".shp")

def identify_passive_margins_from_patterns_of_unique_kinematic_line_features(unique_kin_line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	reconstruction_time = begin_reconstruction_time
	valid_div_line_features = []
	valid_conv_line_features = []
	valid_cont_arc_line_features = []
	valid_plate_bdn_line_features = []
	dic_valid_line_feats = {}
	output_passive_fts = pygplates.FeatureCollection()
	while (reconstruction_time >= end_reconstruction_time):
		valid_div_line_features[:] = []
		valid_conv_line_features[:] = []
		valid_cont_arc_line_features[:] = []
		valid_plate_bdn_line_features[:] = []

		for div_line_ft in unique_kin_line_features:
			if (div_line_ft.is_valid_at_time(reconstruction_time)):
				if (div_line_ft.get_description() == "divergent_margin"):
					valid_div_line_features.append(div_line_ft)
		for conv_line_ft in unique_kin_line_features:
			if (conv_line_ft.is_valid_at_time(reconstruction_time)):
				if (conv_line_ft.get_description() == "convergent_margin"):
					valid_conv_line_features.append(conv_line_ft)
		for plate_bdn_line_ft in unique_kin_line_features:
			if (plate_bdn_line_ft.is_valid_at_time(reconstruction_time)):
				if (plate_bdn_line_ft.get_description() == "plate_boundary_zone"):
					valid_plate_bdn_line_features.append(plate_bdn_line_ft)
		for continental_arc_ft in unique_kin_line_features:
			if (continental_arc_ft.is_valid_at_time(reconstruction_time)):
				if (continental_arc_ft.get_description() == "upper_plate_margin" or continental_arc_ft.get_description() == "subduction_zone"):
					valid_cont_arc_line_features.append(continental_arc_ft)
		
		#check and reset dic_valid_line_feats
		if (len(dic_valid_line_feats) > 0):
			for polylid in dic_valid_line_feats:
				if (dic_valid_line_feats[polylid] is not None):
					current_line_ft = dic_valid_line_feats[polylid]
					if (current_line_ft.is_valid_at_time(reconstruction_time) == False):
						# if (current_line_ft.get_description() == 'passive_margin'):
							# output_passive_fts.add(current_line_ft)
						dic_valid_line_feats[polylid] = None
		#fill-in dic_valid_line_feats with only kinematic line features: div or conv
		for div_line_ft in valid_div_line_features:
			polylid = div_line_ft.get_name()
			if (polylid not in dic_valid_line_feats):
				dic_valid_line_feats[polylid] = div_line_ft
			else:
				current_line_ft = dic_valid_line_feats[polylid]
				if (current_line_ft is None):
					dic_valid_line_feats[polylid] = div_line_ft
		for cont_arc_line_ft in valid_cont_arc_line_features:
			polylid = cont_arc_line_ft.get_name()
			if (polylid not in dic_valid_line_feats):
				dic_valid_line_feats[polylid] = cont_arc_line_ft
			else:
				current_line_ft = dic_valid_line_feats[polylid]
				if (current_line_ft is None):
					dic_valid_line_feats[polylid] = cont_arc_line_ft
		for conv_arc_line_ft in valid_conv_line_features:
			polylid = conv_arc_line_ft.get_name()
			if (polylid not in dic_valid_line_feats):
				dic_valid_line_feats[polylid] = conv_arc_line_ft
			else:
				current_line_ft = dic_valid_line_feats[polylid]
				if (current_line_ft is None):
					dic_valid_line_feats[polylid] = conv_arc_line_ft

		#pattern to identify transform fault: divergent_margin -> plate boundary zone -> convergent_margin; convergent_margin -> plate boundary zone -> divergent_margin
		for plate_bdn_line_ft in valid_plate_bdn_line_features:
			polylid = plate_bdn_line_ft.get_name()
			if (polylid in dic_valid_line_feats):
				current_line_ft = dic_valid_line_feats[polylid]
				if (current_line_ft is None):
					# if (reconstruction_time == begin_reconstruction_time):
						# dic_valid_line_feats[polylid] = plate_bdn_line_ft
					# else:
					passive_ft = plate_bdn_line_ft.clone()
					passive_ft.set_description("passive_margin")
					#dic_valid_line_feats[polylid] = passive_ft
					output_passive_fts.add(passive_ft)
		reconstruction_time = reconstruction_time - time_interval
	output_passive_fts.write("passive_margins_from_patterns_of_unique_kin_line_fts_"+modelname+"_"+yearmonthday+".shp")

def identify_inactive_div_margin_from_unique_kinematic_line_features(unique_kin_line_features,begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	reconstruction_time = begin_reconstruction_time
	valid_div_line_features = []
	valid_plate_bdn_line_features = []
	dic_valid_line_feats = {}
	output_passive_fts = pygplates.FeatureCollection()
	while (reconstruction_time >= end_reconstruction_time):
		valid_div_line_features[:] = []
		valid_plate_bdn_line_features[:] = []

		for div_line_ft in unique_kin_line_features:
			if (div_line_ft.is_valid_at_time(reconstruction_time)):
				if (div_line_ft.get_description() == "divergent_margin"):
					valid_div_line_features.append(div_line_ft)
		for plate_bdn_line_ft in unique_kin_line_features:
			if (plate_bdn_line_ft.is_valid_at_time(reconstruction_time)):
				if (plate_bdn_line_ft.get_description() == "plate_boundary_zone"):
					valid_plate_bdn_line_features.append(plate_bdn_line_ft)
		
		#check and reset dic_valid_line_feats
		if (len(dic_valid_line_feats) > 0):
			for polylid in dic_valid_line_feats:
				current_line_ft, _ = dic_valid_line_feats[polylid]
				if (current_line_ft is not None):
					if (current_line_ft.is_valid_at_time(reconstruction_time) == False):
						if (current_line_ft.get_description() == 'inactive_div_margin'):
							output_passive_fts.add(current_line_ft)
							dic_valid_line_feats[polylid] = (None,'inactive_div_margin')
						else:
							dic_valid_line_feats[polylid] = (None,'divergent_margin')
		#fill-in dic_valid_line_feats with only kinematic line features: div or conv
		for div_line_ft in valid_div_line_features:
			polylid = div_line_ft.get_name()
			if (polylid not in dic_valid_line_feats):
				dic_valid_line_feats[polylid] = (div_line_ft, 'divergent_margin')
			else:
				current_line_ft, _ = dic_valid_line_feats[polylid]
				if (current_line_ft is None):
					dic_valid_line_feats[polylid] = (div_line_ft,'divergent_margin')
		
		#pattern to identify inactive_div_margin: divergent_margin -> plate boundary zone
		for plate_bdn_line_ft in valid_plate_bdn_line_features:
			polylid = plate_bdn_line_ft.get_name()
			if (polylid in dic_valid_line_feats):
				current_line_ft, current_descrp = dic_valid_line_feats[polylid]
				if (current_line_ft is None):
					# if (reconstruction_time == begin_reconstruction_time):
						# dic_valid_line_feats[polylid] = plate_bdn_line_ft
					# else:
					if (current_descrp == 'divergent_margin'):
						passive_ft = plate_bdn_line_ft.clone()
						passive_ft.set_description("inactive_div_margin")
						dic_valid_line_feats[polylid] = (passive_ft,"inactive_div_margin")
						
						#output_passive_fts.add(passive_ft)
		reconstruction_time = reconstruction_time - time_interval
	output_passive_fts.write("inactive_div_margins_from_unique_kin_line_fts_"+modelname+"_"+yearmonthday+".shp")

def identify_inactive_conv_margin_from_unique_kinematic_line_features(unique_kin_line_features,begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	reconstruction_time = begin_reconstruction_time
	valid_conv_line_features = []
	valid_plate_bdn_line_features = []
	dic_valid_line_feats = {}
	output_passive_fts = pygplates.FeatureCollection()
	while (reconstruction_time >= end_reconstruction_time):
		valid_conv_line_features[:] = []
		valid_plate_bdn_line_features[:] = []

		for conv_line_ft in unique_kin_line_features:
			if (conv_line_ft.is_valid_at_time(reconstruction_time)):
				if (conv_line_ft.get_description() == "convergent_margin"):
					valid_conv_line_features.append(conv_line_ft)
		for plate_bdn_line_ft in unique_kin_line_features:
			if (plate_bdn_line_ft.is_valid_at_time(reconstruction_time)):
				if (plate_bdn_line_ft.get_description() == "plate_boundary_zone"):
					valid_plate_bdn_line_features.append(plate_bdn_line_ft)
		
		#check and reset dic_valid_line_feats
		if (len(dic_valid_line_feats) > 0):
			for polylid in dic_valid_line_feats:
				current_line_ft, _ = dic_valid_line_feats[polylid]
				if (current_line_ft is not None):
					if (current_line_ft.is_valid_at_time(reconstruction_time) == False):
						if (current_line_ft.get_description() == 'inactive_conv_margin'):
							output_passive_fts.add(current_line_ft)
							dic_valid_line_feats[polylid] = (None, 'inactive_conv_margin')
						else:
							dic_valid_line_feats[polylid] = (None, 'convergent_margin')
		#fill-in dic_valid_line_feats with only kinematic line features: div or conv
		for conv_line_ft in valid_conv_line_features:
			polylid = conv_line_ft.get_name()
			if (polylid not in dic_valid_line_feats):
				dic_valid_line_feats[polylid] = (conv_line_ft, 'convergent_margin')
			else:
				current_line_ft, _ = dic_valid_line_feats[polylid]
				if (current_line_ft is None):
					dic_valid_line_feats[polylid] = (conv_line_ft, 'convergent_margin')
		
		#pattern to identify inactive_div_margin: divergent_margin -> plate boundary zone
		for plate_bdn_line_ft in valid_plate_bdn_line_features:
			polylid = plate_bdn_line_ft.get_name()
			if (polylid in dic_valid_line_feats):
				current_line_ft, current_descrp = dic_valid_line_feats[polylid]
				if (current_line_ft is None):
					# if (reconstruction_time == begin_reconstruction_time):
						# dic_valid_line_feats[polylid] = plate_bdn_line_ft
					# else:
					if (current_descrp == 'convergent_margin'):
						passive_ft = plate_bdn_line_ft.clone()
						passive_ft.set_description("inactive_conv_margin")
						dic_valid_line_feats[polylid] = (passive_ft, "inactive_conv_margin")
						
						#output_passive_fts.add(passive_ft)
		reconstruction_time = reconstruction_time - time_interval
	output_passive_fts.write("inactive_conv_margins_from_unique_kin_line_fts_"+modelname+"_"+yearmonthday+".shp")

if __name__ == "__main__":
	# rift_point_features_records_csv = r"rift_point_features_records_for_test_8_EB2022_20231020.csv"
	# rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kin_records_and_sgdu_2800.0_v3_test_29_PalaeoPlatesendJan2023_fts_20240407.shp"
	# rift_point_features = pygplates.FeatureCollection(rift_point_features_file)
	# line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_segment_POLYGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230921.shp"
	# line_features = pygplates.FeatureCollection(line_features_file)
	# divergent_line_features_file = r"all_div_margin_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240304.shp"
	# divergent_line_features = pygplates.FeatureCollection(divergent_line_features_file)
	# convergent_line_features_file = r"all_conv_margin_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240301.shp"
	# convergent_line_features = pygplates.FeatureCollection(convergent_line_features_file)
	# continental_arc_features_file = r"subduction_zone_features_test_29_PalaeoPlatesendJan2023_fts_max_from_2800.0_20240302.shp"
	# continental_arc_features = pygplates.FeatureCollection(continental_arc_features_file)
	# plate_bdn_zone_features_file = r"all_plate_bdn_zone_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240301.shp"
	# plate_bdn_zone_features = pygplates.FeatureCollection(plate_bdn_zone_features_file)
	# transform_features_file = r"extract_features_based_on_description_transform_fault_PalaeoPlatesendJan2023_from_test_29_identify_kin_bdn_20240111.shp"
	# transform_features = pygplates.FeatureCollection(transform_features_file)
	# begin_reconstruction_time = 2800.00
	# end_reconstruction_time = 0.00
	# time_interval = 5.00
	# yearmonthday = "20240409"
	# modelname = "test_5_PalaeoPlatesendJan2023"
	#select.select_eliminate_duplicated_kinematic_line_features(rift_point_features_records_csv, rift_point_features, line_features, divergent_line_features, convergent_line_features, continental_arc_features, transform_features, plate_bdn_zone_features, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)
	#only from both kin processes
	select.select_eliminate_duplicated_kinematic_line_features(rift_point_features_records_csv, rift_point_features, line_features, divergent_line_features, convergent_line_features, continental_arc_features, transform_features, plate_bdn_zone_features, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)
	
	
	rift_point_features_records_csv = r"rift_point_features_records_for_test_8_EB2022_20231020.csv"
	rift_point_features_file = r"C:\Users\lavie\Dropbox\PC\tectonic_boundaries\Merdith_et_al_2021\modified_end_age_of_rift_point_features_with_connected_records_for_end_age_features_v2_test_8_div_test_12_conv_EB2022_fts_20240806.shp"
	rift_point_features = pygplates.FeatureCollection(rift_point_features_file)
	line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\CON_OCN_w_temp_neighbours_for_test_1_original_and_new_single_POLYGID_joined_line_fts_995.0_0.0_Merdith_et_al_EB2021_20230930.shp"
	line_features = pygplates.FeatureCollection(line_features_file)
	divergent_line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\manually_modified_all_div_bdn_EB2021_from_test_8_div_test_12_conv_20240805.shp"
	divergent_line_features = pygplates.FeatureCollection(divergent_line_features_file)
	convergent_line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\manually_modified_all_conv_EB2021_from_test_8_div_test_12_conv_20240805.shp"
	convergent_line_features = pygplates.FeatureCollection(convergent_line_features_file)
	# continental_arc_features_file = r"subduction_zone_features_test_29_PalaeoPlatesendJan2023_fts_max_from_2800.0_20240302.shp"
	# continental_arc_features = pygplates.FeatureCollection(continental_arc_features_file)
	continental_arc_features = None
	plate_bdn_zone_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\all_plate_bdn_zone_EB2021_from_all_kin_eval_test_8_div_test_12_conv_20240810.shp"
	plate_bdn_zone_features = pygplates.FeatureCollection(plate_bdn_zone_features_file)
	transform_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\extract_features_based_on_descriptiontransform_fault_EB2022_995_0Ma_from_test_8_identify_div_bdn_20240805.shp"
	transform_features = pygplates.FeatureCollection(transform_features_file)
	begin_reconstruction_time = 995.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	yearmonthday = "20240811"
	modelname = "test_1_EB2022"
	select_eliminate_duplicated_kinematic_line_features(rift_point_features_records_csv, rift_point_features, line_features, divergent_line_features, convergent_line_features, continental_arc_features, transform_features, plate_bdn_zone_features, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)