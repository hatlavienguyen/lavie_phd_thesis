import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_extend_tectonic_boundaries as supporting

# def main(approximated_plate_tectonic_margins_shp_or_gpml, possible_line_fts_for_subduction_zone_deposits_shp_or_gpml, possible_line_fts_for_subduction_zone_igneous_shp_or_gpml, modelname, test_number, yearmonthday):
	# approximated_plate_tectonic_margins = pygplates.FeatureCollection(approximated_plate_tectonic_margins_shp_or_gpml)
	# possible_line_fts_for_subduction_zone_deposits = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_deposits_shp_or_gpml)
	# possible_line_fts_for_subduction_zone_igneous = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_igneous_shp_or_gpml)
	# supporting.identify_upper_plate_margins_from_porphyry_VMS_and_igneous_activities_approximated_plate_tectonic_margins(approximated_plate_tectonic_margins, possible_line_fts_for_subduction_zone_deposits, possible_line_fts_for_subduction_zone_igneous, modelname, test_number, yearmonthday)

def main(rotation_file, approximated_plate_tectonic_margins_shp_or_gpml, deposits_or_geochron_buffer_features_file, interval,reference,modelname,yearmonthday):
	rotation_model = pygplates.RotationModel(rotation_file)
	approximated_plate_tectonic_margins = pygplates.FeatureCollection(approximated_plate_tectonic_margins_shp_or_gpml)
	unknown_convergent_margin_line_features = [ft for ft in approximated_plate_tectonic_margins if (ft.get_feature_type() == pygplates.FeatureType.gpml_subduction_zone)]
	print("number of convergent line features as input:",len(unknown_convergent_margin_line_features))
	#exit()
	deposits_or_geochron_buffer_features = pygplates.FeatureCollection(deposits_or_geochron_buffer_features_file)
	supporting.identify_upper_plate_margins_from_porphyry_VMS_and_igneous_activities_approximated_plate_tectonic_margins_with_buffer(rotation_model,unknown_convergent_margin_line_features,deposits_or_geochron_buffer_features,interval,reference,modelname,yearmonthday)

if __name__ == "__main__":
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	#approximated_plate_tectonic_margins_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Fall2021\tectonic_boundaries\clean_up_messy_tectonic_boundaries_based_on_geol_topology_temp_bdn_PalaeoPlatesJune2021_uncertainty_15Ma__5_20211130.gpml"
	approximated_plate_tectonic_margins_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\upper_plate_margins_PalaeoPlatesNov2021_porphyry_StratDB_Oct2021_5.0Ma_20220627.shp"
	deposits_or_geochron_buffer_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\buffer_zones_for_point_features\test_4_valid_age_VMS_StratDB_Oct2021_dissolved_buffer_300.0_2000.0_0.0_5.0Ma_15.0_time_wdn_reconstructed_SuperGDU_PalaeoPlatesNov_2021_20220406.shp"
	modelname = "PalaeoPlatesNov2021_porphyry_VMS_StratDB_Oct2021"
	test_number = 1
	yearmonthday = "20220627"
	interval = 5.00
	reference = 700
	main(rotation_file, approximated_plate_tectonic_margins_shp_or_gpml, deposits_or_geochron_buffer_features_file, interval,reference,modelname,yearmonthday)