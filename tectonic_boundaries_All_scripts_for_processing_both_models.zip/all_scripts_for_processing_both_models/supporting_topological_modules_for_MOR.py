import sys 
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import math
import supporting_topological_modules as tm
import rotation_utility 
import psycopg2
from config_plate_tectonics import config
import supporting_modules_to_be_converted as supporting
import pandas as pd
import geopandas as gpd
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing
import os
def classify_left_or_right(normal_unit_vector,rift_point_location,mid_point_line_1):
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	#identify left and right
	vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	normalized_vector_to_line_1 = None
	try:
		normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	except (Exception) as error:
		print(error)
		print("rift_point_location_x,rift_point_location_y,rift_point_location_z",rift_point_location_x,rift_point_location_y,rift_point_location_z)
		print("mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z",mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z)
		exit()
	angle_btw_rads = pygplates.Vector3D.angle_between(normal_unit_vector,normalized_vector_to_line_1)
	angle_btw_degs = abs(math.degrees(angle_btw_rads))
	if (angle_btw_degs < 90.00):
		return 'left'
	else:
		return 'right'

def calculate_angle_for_classifying_left_or_right(normal_unit_vector,rift_point_location,mid_point_line_1):
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	#identify left and right
	vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	angle_btw_rads = pygplates.Vector3D.angle_between(normal_unit_vector,normalized_vector_to_line_1)
	angle_btw_degs = math.degrees(angle_btw_rads)
	return angle_btw_degs
def find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2(list_of_passive_margin_fts, SuperGDU_features, at_age, interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output):
	"""
	Find and connect locations where rifts/MOR ocurrs at age 
		list_of_passive_margin_fts: a list or a list-like structure that contains CON_OCN margin features which were previously identified from first approximated tectonic motion evaluation
		at_age: interpreted in Ma - float
		rotation_model: pygplates.RotationModel from .rot or grot file
		reference: None or any other value to be used as the reference_frame for the plate tectonic reconstruction
		test_number: int to keep track for testing the module
		modelname: str name of the plate tectonic model that we evaluate
		yyyymmdd: str year - month - day 
	Return:
		a list of: 
			locations of rifts/MOR
			topological line features connecting rifts/MOR locations
	"""
	
	output_geometry = []
	outputPointFeatureCollection = pygplates.FeatureCollection()
	temp_output_points_fts = pygplates.FeatureCollection()
	output_SuperGDU_fts = pygplates.FeatureCollection()
	list_of_MOR_locations = []
	dic = {}
	temp_left_passive_margin_fts = []
	temp_right_passive_margin_fts = []
	reconstructed_passive_margin_features = []
	output_small_circle_fts = []
	passive_margin_fts = [ft for ft in list_of_passive_margin_fts if ft.is_valid_at_time(at_age)]
	final_fts = []
	left_features = []
	right_features = []
	list_of_ordered_middle_fts = []
	final_list_of_middle_fts = []
	final_list_of_middle_polygon_fts = []
	final_list_of_oceanic_crust = []
	final_list_of_surface_oceanic_crust = []
	estimated_final_list_of_oceanic_crust = []
	estimated_final_list_of_surface_oceanic_crust = []	  
	list_of_ordered_left_fts = []
	final_list_of_left_fts = []
	list_of_ordered_right_fts = []
	final_list_of_right_fts = []
	list_of_ordered_middle_fts_for_left = []
	list_of_ordered_middle_fts_for_right = []
	list_of_valid_SuperGDU_fts = [SuperGDU_ft for SuperGDU_ft in SuperGDU_features if SuperGDU_ft.is_valid_at_time(at_age)]
	reconstructed_SuperGDU_fts = []
	SuperGDU_polygons = [] 
	temp_list_of_left_features = []
	temp_list_of_right_features = []
	list_of_points_intersecting_left = []
	list_of_points_intersecting_right = [] 
	line_features_for_SuperGDU_2 = [] 
	line_features_for_SuperGDU_1 = []
	outputPointFeatureCollection = pygplates.FeatureCollection()
	outputPointFeatureCollection_2 = pygplates.FeatureCollection()
	outputSmallCirlceFeatureCollection = pygplates.FeatureCollection()
	
	if (reference is not None):
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,group_with_feature = True)
	final_reconstructed_passive_margin_fts = supporting.find_final_reconstructed_geometries(reconstructed_passive_margin_features,pygplates.PolylineOnSphere)
	final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU_fts, pygplates.PolygonOnSphere)
	SuperGDU_polygons[:] = []
	for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
		SuperGDU_polygons.append(SuperGDU_polygon.clone())

	print('find pairs of GDUs_id and associated divergent continental-oceanic divergent margins to find relative stage E poles')
	txt = """SELECT super_gdu_id, represent_gdu_id FROM super_gdu_and_members_id WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}"""
	txt_3 = """SELECT DISTINCT represent_gdu_id,super_gdu_id FROM temp_final_super_gdu_id_2
					WHERE from_time > {input_time} and to_time <= {input_time} AND represent_gdu_id in 
						(SELECT DISTINCT gdu_id_member from super_gdu_and_members_id 
							WHERE super_gdu_id in
								(SELECT DISTINCT super_gdu_id FROM super_gdu_and_members_id 
										WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}))"""
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_2 = conn.cursor()
		cur_4 = conn.cursor()
		# temp_left_passive_margin_fts[:] = []
		# temp_right_passive_margin_fts[:] = []
		# for passive_margin_ft, passive_margin in final_reconstructed_passive_margin_fts:
			# if (passive_margin_ft.get_left_plate() == passive_margin_ft.get_reconstruction_plate_id()):
				# temp_left_passive_margin_fts.append((passive_margin_ft, passive_margin))
			# elif (passive_margin_ft.get_right_plate() == passive_margin_ft.get_reconstruction_plate_id()):
				# temp_right_passive_margin_fts.append((passive_margin_ft, passive_margin))
			# else:
				# print("Error in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2")
				# print("Error neither left_plate_ID or right_plate_ID associated with passive_margin_ft is the same as reconstruction_plate_id for passive_margin_ft")
				# exit()
		# if (len(temp_left_passive_margin_fts) != len(temp_right_passive_margin_fts)):
			# print("Error in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2")
			# print("Error len(temp_left_passive_margin_fts) != len(temp_right_passive_margin_fts)")
			# print("len(temp_left_passive_margin_fts)",len(temp_left_passive_margin_fts))
			# print("len(temp_right_passive_margin_fts)",len(temp_right_passive_margin_fts))
			# exit()
		already_included = []
		for passive_margin_ft_1, passive_margin_1 in final_reconstructed_passive_margin_fts:
			if (passive_margin_ft_1.get_feature_id().get_string() not in already_included):
				#already_included.append(passive_margin_ft_1.get_feature_id().get_string())
				# left_plate_ID = passive_margin_ft_1.get_left_plate()
				# right_plate_ID = passive_margin_ft_1.get_right_plate()
				left_plate_ID = passive_margin_ft_1.get_reconstruction_plate_id()
				right_plate_ID = passive_margin_ft_1.get_conjugate_plate_id()
				sql = txt.format(input_member_id = left_plate_ID, input_time = at_age)
				cur.execute(sql)
				row = cur.fetchone()
				SuperGDU_id_1 = -1
				SuperGDU_id_2 = -1
				represent_gdu_id_1 = -1
				represent_gdu_id_2 = -1
				if (row is None):
					print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
					print("Warning cannot find SuperGDU id associated with member GDU id:")
					print(left_plate_ID)
					print("at age")
					print(at_age)
					print(sql)
					exit()
				else:
					SuperGDU_id_1 = row[0]
					represent_gdu_id_1 = row[1]
				sql_2 = txt.format(input_member_id = right_plate_ID, input_time = at_age)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				if (row_2 is None):
					print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
					print("Warning cannot find SuperGDU id associated with member GDU id:")
					print(right_plate_ID)
					print("at age")
					print(at_age)
					print(sql_2)
					exit()
				else:
					SuperGDU_id_2 = row_2[0]
					represent_gdu_id_2 = row_2[1]
				if (row is not None and row_2 is not None):
					key = str(represent_gdu_id_1)+"_"+str(represent_gdu_id_2)
					reverse_key = str(represent_gdu_id_2)+"_"+str(represent_gdu_id_1)
					if (key not in dic and reverse_key not in dic):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										if ((passive_margin_ft_2.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
										or (passive_margin_ft_2.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
											sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
											cur_4.execute(sql_4)
											row_4 = cur_4.fetchone()
											if (row_4 is None):
												print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
												print("Warning cannot find SuperGDU id associated with member GDU id:")
												print(passive_margin_ft_2.get_reconstruction_plate_id())
												print("at age")
												print(at_age)
												print(sql_4)
												exit()
											else:
												temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
												temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
												if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
													dic[key] = {str(represent_gdu_id_1): [(passive_margin_ft_1.clone(), passive_margin_1.clone())], str(represent_gdu_id_2): [(passive_margin_ft_2.clone(), passive_margin_2.clone())]} 
													already_included.append(passive_margin_ft_1.get_feature_id().get_string())
													already_included.append(passive_margin_ft_2.get_feature_id().get_string())
					elif (key in dic):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							# if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								# if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									# if ((passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
									# or (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
										# dic[key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										# dic[key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
							if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										if ((passive_margin_ft_2.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
										or (passive_margin_ft_2.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
											sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
											cur_4.execute(sql_4)
											row_4 = cur_4.fetchone()
											if (row_4 is None):
												print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
												print("Warning cannot find SuperGDU id associated with member GDU id:")
												print(passive_margin_ft_2.get_reconstruction_plate_id())
												print("at age")
												print(at_age)
												print(sql_4)
												exit()
											else:
												temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
												temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
												if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
													dic[key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
													dic[key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
													already_included.append(passive_margin_ft_2.get_feature_id().get_string())
													already_included.append(passive_margin_ft_1.get_feature_id().get_string())
					# elif (reverse_key in dic):
						# for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							# # if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								# # if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									# # if ((passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
									# # or (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
										# # dic[reverse_key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										# # dic[reverse_key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone())
						   # if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								# already_included.append(passive_margin_ft_2.get_feature_id().get_string())
								# if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									# if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										# if (passive_margin_ft_2.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
											# sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
											# cur_4.execute(sql_4)
											# row_4 = cur_4.fetchone()
											# if (row_4 is None):
												# print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
												# print("Warning cannot find SuperGDU id associated with member GDU id:")
												# print(passive_margin_ft_2.get_reconstruction_plate_id())
												# print("at age")
												# print(at_age)
												# print(sql_4)
												# exit()
											# else:
												# temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
												# temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
												# if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
													# dic[reverse_key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
													# dic[reverse_key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
		for passive_margin_ft_1, passive_margin_1 in final_reconstructed_passive_margin_fts:
			if (passive_margin_ft_1.get_feature_id().get_string() not in already_included):
				#already_included.append(passive_margin_ft_1.get_feature_id().get_string())
				left_plate_ID = passive_margin_ft_1.get_left_plate()
				right_plate_ID = passive_margin_ft_1.get_right_plate()
				sql = txt.format(input_member_id = right_plate_ID, input_time = at_age)
				cur.execute(sql)
				row = cur.fetchone()
				SuperGDU_id_1 = -1
				SuperGDU_id_2 = -1
				represent_gdu_id_1 = -1
				represent_gdu_id_2 = -1
				if (row is None):
					print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
					print("Warning cannot find SuperGDU id associated with member GDU id:")
					print(right_plate_ID)
					print("at age")
					print(at_age)
					print(sql)
					exit()
				else:
					SuperGDU_id_1 = row[0]
					represent_gdu_id_1 = row[1]
				sql_2 = txt.format(input_member_id = left_plate_ID, input_time = at_age)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				if (row_2 is None):
					print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
					print("Warning cannot find SuperGDU id associated with member GDU id:")
					print(left_plate_ID)
					print("at age")
					print(at_age)
					print(sql_2)
					exit()
				else:
					SuperGDU_id_2 = row_2[0]
					represent_gdu_id_2 = row_2[1]
				if (row is not None and row_2 is not None):
					key = str(represent_gdu_id_1)+"_"+str(represent_gdu_id_2)
					reverse_key = str(represent_gdu_id_2)+"_"+str(represent_gdu_id_1)
					if (key not in dic and reverse_key not in dic):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										if ((passive_margin_ft_2.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
											or (passive_margin_ft_2.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
											sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
											cur_4.execute(sql_4)
											row_4 = cur_4.fetchone()
											if (row_4 is None):
												print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
												print("Warning cannot find SuperGDU id associated with member GDU id:")
												print(passive_margin_ft_2.get_reconstruction_plate_id())
												print("at age")
												print(at_age)
												print(sql_4)
												exit()
											else:
												temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
												temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
												if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
													dic[key] = {str(represent_gdu_id_1): [(passive_margin_ft_1.clone(), passive_margin_1.clone())], str(represent_gdu_id_2): [(passive_margin_ft_2.clone(), passive_margin_2.clone())]} 
													already_included.append(passive_margin_ft_1.get_feature_id().get_string())
													already_included.append(passive_margin_ft_2.get_feature_id().get_string())
					elif (key in dic):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							# if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								# if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									# if ((passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
									# or (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
										# dic[key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										# dic[key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
							if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										if ((passive_margin_ft_2.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
										or (passive_margin_ft_2.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_2.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
											sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
											cur_4.execute(sql_4)
											row_4 = cur_4.fetchone()
											if (row_4 is None):
												print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
												print("Warning cannot find SuperGDU id associated with member GDU id:")
												print(passive_margin_ft_2.get_reconstruction_plate_id())
												print("at age")
												print(at_age)
												print(sql_4)
												exit()
											else:
												temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
												temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
												if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
													dic[key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
													dic[key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
													already_included.append(passive_margin_ft_2.get_feature_id().get_string())
													already_included.append(passive_margin_ft_1.get_feature_id().get_string())
	except (psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
	#find small circles for each E pole
	# print('find small circles for each E pole')
	print('number of pairs of GDUs_id')
	print(len(dic.keys()))
	#debug
	if (("10953_10439" in dic) or ("10439_10953" in dic)):
		if (("10953_10439" in dic)):
			print("10953_10439")
			list_of_fts_1 = dic["10953_10439"]["10953"]
			ft_collection_1 = pygplates.FeatureCollection()
			print("10953")
			for ft,_ in list_of_fts_1:
				print("ft.get_reconstruction_plate_id()")
				print("ft.get_left_plate()",ft.get_left_plate())
				print("ft.get_right_plate()",ft.get_right_plate())
				
				ft_collection_1.add(ft)
			ft_collection_1.write("ft_collection_1_for_10953_10439_for_10953_50ma.gpml")
			list_of_fts_2 = dic["10953_10439"]["10439"]
			ft_collection_2 = pygplates.FeatureCollection()
			print("10439")
			for ft,_ in list_of_fts_2:
				print("ft.get_reconstruction_plate_id()")
				print("ft.get_left_plate()",ft.get_left_plate())
				print("ft.get_right_plate()",ft.get_right_plate())
				ft_collection_2.add(ft)
			ft_collection_2.write("ft_collection_2_for_10953_10439_for_10439_50ma.gpml")
		else:
			print("10439_10953")
			list_of_fts_1 = dic["10439_10953"]["10439"]
			ft_collection_1 = pygplates.FeatureCollection()
			print("10439")
			for ft,_ in list_of_fts_1:
				print("ft.get_reconstruction_plate_id()")
				print("ft.get_left_plate()",ft.get_left_plate())
				print("ft.get_right_plate()",ft.get_right_plate())
				ft_collection_1.add(ft)
			ft_collection_1.write("ft_collection_1_for_10439_10953_for_10439_50ma.gpml")
			list_of_fts_2 = dic["10439_10953"]["10953"]
			ft_collection_2 = pygplates.FeatureCollection()
			print("10953")
			for ft,_ in list_of_fts_2:
				print("ft.get_reconstruction_plate_id()")
				print("ft.get_left_plate()",ft.get_left_plate())
				print("ft.get_right_plate()",ft.get_right_plate())
				
				ft_collection_2.add(ft)
			ft_collection_2.write("ft_collection_2_for_10439_10953_for_10953_50ma.gpml")
		# for key in dic.keys():
			# count_locations_of_MOR = 0
			# pairs_GDU_id = key.split('_')
			# plate_id_1 = int(pairs_GDU_id[0])
			# plate_id_2 = int(pairs_GDU_id[1])
			# initial_plate_id_1 = plate_id_1
			# initial_plate_id_2 = plate_id_2
			# print("plate_id_1,plate_id_2", plate_id_1, plate_id_2)
			# print("key",key)
		#exit()
	
	
	conn = None
	cur_3 = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_3 = conn.cursor()
	except (psycopg2.DatabaseError) as error:
		print (error)
		exit()
	for key in dic.keys():
		count_locations_of_MOR = 0
		pairs_GDU_id = key.split('_')
		plate_id_1 = int(pairs_GDU_id[0])
		plate_id_2 = int(pairs_GDU_id[1])
		initial_plate_id_1 = plate_id_1
		initial_plate_id_2 = plate_id_2
		print("plate_id_1,plate_id_2", plate_id_1, plate_id_2)
		print("key",key)
		SuperGDU_1 = None 
		SuperGDU_2 = None
		SuperGDU_1_size = 0.00
		SuperGDU_2_size = 0.00
		for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
			if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1):
				if (SuperGDU_1_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_1_size):
					SuperGDU_1_size = SuperGDU_polygon.get_area()
					SuperGDU_1 = SuperGDU_polygon
			elif (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2):
				if (SuperGDU_2_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_2_size):
					SuperGDU_2_size = SuperGDU_polygon.get_area()
					SuperGDU_2 = SuperGDU_polygon
		if (SuperGDU_1 is None):
			sql_3 = txt_3.format(input_member_id = plate_id_1 , input_time = at_age)
			cur_3.execute(sql_3)
			row_3 = cur_3.fetchone()
			if (row_3 is None):
				print('Error find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2')
				print('sql_3')
				print(sql_3)
				exit()
			plate_id_1 = int(row_3[0])
			SuperGDU_1_name = row_3[1]
			SuperGDU_1 = None 
			SuperGDU_1_size = 0.00
			for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1 or int(SuperGDU_ft.get_name()) == SuperGDU_1_name):
					if (SuperGDU_1_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_1_size):
						SuperGDU_1_size = SuperGDU_polygon.get_area()
						SuperGDU_1 = SuperGDU_polygon
		if (SuperGDU_1 is None):
			print("Error SuperGDU_1 is None")
			print("plate_id_1,SuperGDU_1_name", plate_id_1, SuperGDU_1_name)
			for ft in SuperGDU_features:
				if (ft.get_reconstruction_plate_id() == plate_id_1 or int(SuperGDU_ft.get_name()) == SuperGDU_1_name):
					print(ft.get_reconstruction_plate_id())
					print(ft.get_name())
					print(ft.get_valid_time())
			exit()
		if (SuperGDU_2 is None):
			sql_3 = txt_3.format(input_member_id = plate_id_2 , input_time = at_age)
			cur_3.execute(sql_3)
			row_3 = cur_3.fetchone()
			if (row_3 is None):
				print('Error find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2')
				print('sql_3')
				print(sql_3)
				exit()
			plate_id_2 = int(row_3[0])
			SuperGDU_2 = None 
			SuperGDU_2_size = 0.00
			SuperGDU_2_name = row_3[1]
			for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2 or int(SuperGDU_ft.get_name()) == SuperGDU_2_name):
					if (SuperGDU_2_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_2_size):
						SuperGDU_2_size = SuperGDU_polygon.get_area()
						SuperGDU_2 = SuperGDU_polygon
		if (SuperGDU_2 is None):
			print("Error SuperGDU_2 is None")
			print("plate_id_2,SuperGDU_2_name", plate_id_2, SuperGDU_2_name)
			for ft in SuperGDU_features:
				if (ft.get_reconstruction_plate_id() == plate_id_2 or int(SuperGDU_ft.get_name()) == SuperGDU_2_name):
					print(ft.get_reconstruction_plate_id())
					print(ft.get_name())
					print(ft.get_valid_time())
			exit()
		
		#debug
		# if ((initial_plate_id_1 == 10953 and initial_plate_id_2 == 10473) or (initial_plate_id_1 == 10473 and initial_plate_id_2 == 10953)):
			# chosen_SuperGDU_1_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, SuperGDU_1, valid_time = (at_age,0.00))
			# chosen_SuperGDU_1_ft.set_reconstruction_plate_id(initial_plate_id_1)
			# chosen_SuperGDU_1_ft.set_name(str(initial_plate_id_1))
			
			# chosen_SuperGDU_2_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, SuperGDU_2, valid_time = (at_age,0.00))
			# chosen_SuperGDU_2_ft.set_reconstruction_plate_id(initial_plate_id_2)
			# chosen_SuperGDU_2_ft.set_name(str(initial_plate_id_2))
			# if (reference is not None):
				# pygplates.reverse_reconstruct([chosen_SuperGDU_1_ft,chosen_SuperGDU_2_ft],rotation_model,at_age,reference)
			# else:
				# pygplates.reverse_reconstruct([chosen_SuperGDU_1_ft,chosen_SuperGDU_2_ft],rotation_model,at_age)
			# output_SuperGDU_fts.add(chosen_SuperGDU_1_ft)
			# output_SuperGDU_fts.add(chosen_SuperGDU_2_ft)
		
		#stage_relative_reconstruction_rotation = tm.find_stage_relative_reconstruction_rotation_(rotation_model,initial_plate_id_1,initial_plate_id_2, at_age, interval)
		#if (stage_relative_reconstruction_rotation.represents_identity_rotation() == False):
		total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,initial_plate_id_1,initial_plate_id_2, at_age, reference)
		if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
			list_of_points_for_SuperGDU_1 = []
			list_of_points_for_SuperGDU_2 = []
			E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
			smallest_circle_angular_radius_degrees = 179.00
			#smallest_circle_angular_radius_degrees = 90.00
			#final_left_plate_id and final_right_plate_id to assign oceanic crust
			final_left_plate_id, final_right_plate_id = -1,-1
			while (smallest_circle_angular_radius_degrees > 0.00):
				#print('value of smallest_circle_angular_radius_degrees')
				#print(smallest_circle_angular_radius_degrees)
				#debug
				if ((initial_plate_id_1 == 10953 and initial_plate_id_2 == 10439) or (initial_plate_id_1 == 10439 and initial_plate_id_2 == 10953)):
					small_circle_ft = None
					small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
					small_circle_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, small_circle_boundary, valid_time = (at_age,0.00))
					#small_circle_ft.set_description(str(smallest_circle_angular_radius_degrees))
					small_circle_ft.set_name(str(smallest_circle_angular_radius_degrees))
					outputSmallCirlceFeatureCollection.add(small_circle_ft)
					#pygplates.reverse_reconstruct(outputSmallCirlceFeatureCollection, rotation_model, at_age, initial_plate_id_1)
				small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
				list_of_points_for_SuperGDU_1[:] = []
				list_of_points_for_SuperGDU_2[:] = []
				for passive_margin_ft, passive_margin in dic[key][str(initial_plate_id_1)]:
					approx_rad_closest_dist, point_on_margin, _ = pygplates.GeometryOnSphere.distance(passive_margin, small_circle_boundary, return_closest_positions = True)
					if (approx_rad_closest_dist == 0.00):
						# new_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,point_on_SuperGDU_1,valid_time = (at_age,0.00))
						# new_feature.set_reconstruction_plate_id(initial_plate_id_1)
						temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, point_on_margin, valid_time = (at_age,0.00))
						temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_1)
						temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
						temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
						temp_output_points_fts.add(temp_pt_ft)
						
						
						if (reference is not None):
							pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age,reference)
						else:
							pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age)
						list_of_points_for_SuperGDU_1.append((temp_pt_ft, point_on_margin))
						
					#find interesections between SuperGDU_1 and small_circle_boundary
					# small_circle_boundary_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
					# SuperGDU_1_line_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(passive_margin)
					# small_circle_boundary_shapely = LinearRing(small_circle_boundary.to_lat_lon_list())
					# SuperGDU_1_line_shapely = LineString(passive_margin.to_lat_lon_list())
					# s1 = gpd.GeoSeries(small_circle_boundary_shapely)
					# s1.set_crs('EPSG:4326')
					# s2 = gpd.GeoSeries(SuperGDU_1_line_shapely)
					# s2.set_crs('EPSG:4326')
					# if (s1.intersects(s2, align = True).all() == True):
						# result = s1.intersection(s2)
						# if ((initial_plate_id_1 == 10953 and initial_plate_id_2 == 10439) or (initial_plate_id_1 == 10439 and initial_plate_id_2 == 10953)):
							# if (smallest_circle_angular_radius_degrees > 120.00):
								# print(result)
								# output_geometry.append((at_age,0.00,initial_plate_id_1,smallest_circle_angular_radius_degrees,result))
					# if (small_circle_boundary_shapely.intersects(SuperGDU_1_line_shapely) == True):
						# intersections_geom =small_circle_boundary_shapely.intersection(SuperGDU_1_line_shapely)
						# if (intersections_geom.geom_type == "MultiPoint"):
							# #print("number of intersections",len(intersections_geom))
							# for point in intersections_geom:
								# x_coord = point.x
								# y_coord = point.y 
								# new_PointOnSphere = pygplates.PointOnSphere((y_coord, x_coord))
								# temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, new_PointOnSphere, valid_time = (at_age,0.00))
								# temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_1)
								# temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
								# temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
								# temp_output_points_fts.add(temp_pt_ft)
								# list_of_points_for_SuperGDU_1.append((temp_pt_ft, new_PointOnSphere))
							# #print("final minimum_dist_btw",minimum_dist_btw)
						# elif (intersections_geom.geom_type == "Point"):
							# point = intersections_geom
							# x_coord = point.x
							# y_coord = point.y 
							# new_PointOnSphere = pygplates.PointOnSphere((y_coord, x_coord))
							# temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, new_PointOnSphere, valid_time = (at_age,0.00))
							# temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_1)
							# temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
							# temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
							# temp_output_points_fts.add(temp_pt_ft)
							# list_of_points_for_SuperGDU_1.append((temp_pt_ft, new_PointOnSphere))
							
				for passive_margin_ft, passive_margin in dic[key][str(initial_plate_id_2)]:		
					approx_rad_closest_dist, point_on_margin, _ = pygplates.GeometryOnSphere.distance(passive_margin, small_circle_boundary, return_closest_positions = True)
					if (approx_rad_closest_dist == 0.00):
						temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, point_on_margin, valid_time = (at_age,0.00))
						temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_2)
						temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
						temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
						temp_output_points_fts.add(temp_pt_ft)
						
						
						if (reference is not None):
							pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age,reference)
						else:
							pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age)
						list_of_points_for_SuperGDU_2.append((temp_pt_ft, point_on_margin))
				
					#find interesections between SuperGDU_1 and small_circle_boundary
					# small_circle_boundary_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
					# SuperGDU_2_line_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(passive_margin)
					# small_circle_boundary_shapely = LinearRing(small_circle_boundary.to_lat_lon_list())
					# SuperGDU_2_line_shapely = LineString(passive_margin.to_lat_lon_list())
					# s1 = gpd.GeoSeries(small_circle_boundary_shapely)
					# s1.set_crs('EPSG:4326')
					# s2 = gpd.GeoSeries(SuperGDU_2_line_shapely)
					# s2.set_crs('EPSG:4326')
					# if (s1.intersects(s2, align = True).all() == True):
						# result = s1.intersection(s2)
						# if ((initial_plate_id_1 == 10953 and initial_plate_id_2 == 10439) or (initial_plate_id_1 == 10439 and initial_plate_id_2 == 10953)):
							# if (smallest_circle_angular_radius_degrees > 120.00):
								# print(result)
								# output_geometry.append((at_age,0.00,initial_plate_id_2,smallest_circle_angular_radius_degrees,result))
					# if (small_circle_boundary_shapely.intersects(SuperGDU_2_line_shapely) == True):
						# intersections_geom =small_circle_boundary_shapely.intersection(SuperGDU_2_line_shapely)
						# if (intersections_geom.geom_type == "MultiPoint"):
							# print("number of intersections",len(intersections_geom))
							# for point in intersections_geom:
								# x_coord = point.x
								# y_coord = point.y 
								# new_PointOnSphere = pygplates.PointOnSphere((y_coord, x_coord))
								# temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, new_PointOnSphere, valid_time = (at_age,0.00))
								# temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_2)
								# temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
								# temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
								# temp_output_points_fts.add(temp_pt_ft)
								# list_of_points_for_SuperGDU_2.append((temp_pt_ft, new_PointOnSphere))
							# #print("final minimum_dist_btw",minimum_dist_btw)
						# elif (intersections_geom.geom_type == "Point"):
							# point = intersections_geom
							# x_coord = point.x
							# y_coord = point.y 
							# new_PointOnSphere = pygplates.PointOnSphere((y_coord, x_coord))
							# temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, new_PointOnSphere, valid_time = (at_age,0.00))
							# temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_2)
							# temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
							# temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
							# temp_output_points_fts.add(temp_pt_ft)
							# list_of_points_for_SuperGDU_2.append((temp_pt_ft, new_PointOnSphere))
				# print("len(list_of_points_for_SuperGDU_1)", len(list_of_points_for_SuperGDU_1))
				# print("len(list_of_points_for_SuperGDU_2)", len(list_of_points_for_SuperGDU_2))
				#print("key",key,"smallest_circle_angular_radius_degrees",smallest_circle_angular_radius_degrees)
				
				# if ((initial_plate_id_1 == 10439 and initial_plate_id_2 == 10953) or (initial_plate_id_1 == 10439 and initial_plate_id_2 == 10953)):
					# print("initial_plate_id_1", initial_plate_id_1, "initial_plate_id_2", initial_plate_id_2)
					# for pt_ft,_ in list_of_points_for_SuperGDU_1:
						# print(pt_ft.get_reconstruction_plate_id())
					# for pt_ft,_ in line_features_for_SuperGDU_2:
						# print(pt_ft.get_reconstruction_plate_id())
					# exit()
				if (len(list_of_points_for_SuperGDU_1) > 0 and len(list_of_points_for_SuperGDU_2) == 0):
					# #find interesections between SuperGDU_2 and small_circle_boundary
					# small_circle_boundary_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
					SuperGDU_2_PolylineOnSphere = pygplates.PolylineOnSphere(SuperGDU_2.to_lat_lon_list())
					for segment in SuperGDU_2_PolylineOnSphere.get_segments():
						start_point = segment.get_start_point()						   
						end_point = segment.get_end_point()
						small_line = pygplates.PolylineOnSphere([start_point,end_point])
						approx_rad_closest_dist, point_on_margin, _ = pygplates.GeometryOnSphere.distance(small_line, small_circle_boundary, return_closest_positions = True)
						if (approx_rad_closest_dist == 0.00):
							temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, point_on_margin, valid_time = (at_age,0.00))
							temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_2)
							temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
							temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2)+"_SuperGDU")
							temp_output_points_fts.add(temp_pt_ft)
							if (reference is not None):
								pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age,reference)
							else:
								pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age)
							list_of_points_for_SuperGDU_2.append((temp_pt_ft, point_on_margin))
				elif (len(list_of_points_for_SuperGDU_1) == 0 and len(list_of_points_for_SuperGDU_2) > 0):
					# #find interesections between SuperGDU_1 and small_circle_boundary
					# small_circle_boundary_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
					SuperGDU_1_PolylineOnSphere = pygplates.PolylineOnSphere(SuperGDU_1.to_lat_lon_list())
					for segment in SuperGDU_1_PolylineOnSphere.get_segments():
						start_point = segment.get_start_point()						   
						end_point = segment.get_end_point()
						small_line = pygplates.PolylineOnSphere([start_point,end_point])
						approx_rad_closest_dist, point_on_margin, _ = pygplates.GeometryOnSphere.distance(small_line, small_circle_boundary, return_closest_positions = True)
						if (approx_rad_closest_dist == 0.00):
							temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, point_on_margin, valid_time = (at_age,0.00))
							temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_1)
							temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
							temp_pt_ft.set_name("SuperGDU_"+str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
							if (reference is not None):
								pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age,reference)
							else:
								pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age)
							list_of_points_for_SuperGDU_1.append((temp_pt_ft, point_on_margin))

				if (len(list_of_points_for_SuperGDU_1) > 0 and len(list_of_points_for_SuperGDU_2) > 0):
					minimum_dist_btw = -1.00
					chosen_pt_1, chosen_pt_2 = None, None
					for ft_1,pt_1 in list_of_points_for_SuperGDU_1:
						for ft_2,pt_2 in list_of_points_for_SuperGDU_2:
							d = pygplates.GeometryOnSphere.distance(pt_1, pt_2)
							if (minimum_dist_btw == -1.00 or (minimum_dist_btw > 0.00 and d > 0.00 and d < minimum_dist_btw)):
								minimum_dist_btw = d
								chosen_pt_1, chosen_pt_2 = pt_1,pt_2
					approx_dis_in_km = minimum_dist_btw * pygplates.Earth.equatorial_radius_in_kms
					if (chosen_pt_1 is not None and chosen_pt_2 is not None and approx_dis_in_km >= 5.00):
						#find MOR location
						MOR_location = tm.find_the_mid_of_two_PointOnSphere(chosen_pt_1,chosen_pt_2)
						print("chosen_pt_1,chosen_pt_2,MOR_location",chosen_pt_1,chosen_pt_2,MOR_location)
						print("minimum_dist_btw",minimum_dist_btw)
						count_locations_of_MOR = count_locations_of_MOR + 1
						great_circle_arc = pygplates.GreatCircleArc(MOR_location,E_pole)
						normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
						MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, MOR_location, valid_time = (at_age,0.00))
						MOR_location_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
						MOR_location_ft.set_name(key)
						side_1 = classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1)
						side_2 = classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2)
						if (side_1 == 'left' and side_2 == 'right'):
							MOR_location_ft.set_left_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
							MOR_location_ft.set_right_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
						elif (side_1 == 'right' and side_2 == 'left'):
							MOR_location_ft.set_left_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
							MOR_location_ft.set_right_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
						else:
							print("Error in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2")
							print("Error unexpected values for side_1 and side_2")
							print("side_1, side_2", side_1, side_2)
							print(calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1))
							print(calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2))
							exit()
						MOR_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
						list_of_MOR_locations.append((at_age,MOR_location_ft.get_feature_id().get_string(),MOR_location_ft.get_left_plate(),MOR_location_ft.get_right_plate(),smallest_circle_angular_radius_degrees))
						outputPointFeatureCollection.add(MOR_location_ft)
						
						#output chosen_pt_1 and chosen_pt_2
						pt1_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, chosen_pt_1, valid_time = (at_age,0.00))
						if (side_1 == 'left' and side_2 == 'right'):
							pt1_location_ft.set_left_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
							pt1_location_ft.set_right_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
						elif (side_1 == 'right' and side_2 == 'left'):
							pt1_location_ft.set_left_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
							pt1_location_ft.set_right_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
						pt1_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
						pt1_location_ft.set_reconstruction_plate_id(initial_plate_id_1)
						pt1_location_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
						outputPointFeatureCollection_2.add(pt1_location_ft)

						pt2_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, chosen_pt_2, valid_time = (at_age,0.00))
						if (side_1 == 'left' and side_2 == 'right'):
							pt2_location_ft.set_left_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
							pt2_location_ft.set_right_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
						elif (side_1 == 'right' and side_2 == 'left'):
							pt2_location_ft.set_left_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
							pt2_location_ft.set_right_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
						pt2_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
						pt2_location_ft.set_reconstruction_plate_id(initial_plate_id_2)
						pt2_location_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
						outputPointFeatureCollection_2.add(pt2_location_ft)

				#update smallest_circle_angular_radius_degrees
				smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.00
	
	if (reference is not None):
		pygplates.reverse_reconstruct(outputPointFeatureCollection_2, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(outputPointFeatureCollection, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(temp_output_points_fts, rotation_model, at_age, reference)
	else:
		pygplates.reverse_reconstruct(outputPointFeatureCollection_2, rotation_model, at_age)
		pygplates.reverse_reconstruct(outputPointFeatureCollection, rotation_model, at_age)
		pygplates.reverse_reconstruct(temp_output_points_fts, rotation_model, at_age)
	#output_SuperGDU_fts.write("output_SuperGDU_fts_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	temp_output_points_fts.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\temp_output_location_ft_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	outputPointFeatureCollection.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\MOR_location_ft_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	outputPointFeatureCollection_2.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\div_margin_location_ft_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	new_dataframe = pd.DataFrame.from_records(list_of_MOR_locations, columns = ['age','ft_id','left_plate_id','right_plate_id','smallest_circle_radius_degrees'])
	filename = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\attributes_of_MOR_locations_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".csv"
	new_dataframe.to_csv(filename,index=False)
	#outputSmallCirlceFeatureCollection.write("small_circle_ft_for_10953_10439_test_17_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	
	# new_dataframe = pd.DataFrame.from_records(output_geometry, columns = ['from_age','to_age','plate_id','small_circle_deg','geometry'])
	# new_gdf = gpd.GeoDataFrame(new_dataframe,crs='EPSG:4326')
	# filename = "intersection_geom_for_10439_10953_and_div_margins_"+str(at_age)+"_"+modelname+"_"+yyyymmdd+".shp"
	# new_gdf.to_file(filename)

def find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2(list_of_passive_margin_fts, SuperGDU_features, at_age, interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output):
	"""
	Find and connect locations where rifts/MOR ocurrs at age 
		list_of_passive_margin_fts: a list or a list-like structure that contains CON_OCN margin features which were previously identified from first approximated tectonic motion evaluation
		at_age: interpreted in Ma - float
		rotation_model: pygplates.RotationModel from .rot or grot file
		reference: None or any other value to be used as the reference_frame for the plate tectonic reconstruction
		test_number: int to keep track for testing the module
		modelname: str name of the plate tectonic model that we evaluate
		yyyymmdd: str year - month - day 
	Return:
		a list of: 
			locations of rifts/MOR
			topological line features connecting rifts/MOR locations
	"""
	
	output_geometry = []
	outputPointFeatureCollection = pygplates.FeatureCollection()
	temp_output_points_fts = pygplates.FeatureCollection()
	output_SuperGDU_fts = pygplates.FeatureCollection()
	list_of_MOR_locations = []
	dic = {}
	temp_left_passive_margin_fts = []
	temp_right_passive_margin_fts = []
	reconstructed_passive_margin_features = []
	output_small_circle_fts = []
	passive_margin_fts = [ft for ft in list_of_passive_margin_fts if ft.is_valid_at_time(at_age)]
	final_fts = []
	left_features = []
	right_features = []
	list_of_ordered_middle_fts = []
	final_list_of_middle_fts = []
	final_list_of_middle_polygon_fts = []
	final_list_of_oceanic_crust = []
	final_list_of_surface_oceanic_crust = []
	estimated_final_list_of_oceanic_crust = []
	estimated_final_list_of_surface_oceanic_crust = []	  
	list_of_ordered_left_fts = []
	final_list_of_left_fts = []
	list_of_ordered_right_fts = []
	final_list_of_right_fts = []
	list_of_ordered_middle_fts_for_left = []
	list_of_ordered_middle_fts_for_right = []
	list_of_valid_SuperGDU_fts = [SuperGDU_ft for SuperGDU_ft in SuperGDU_features if SuperGDU_ft.is_valid_at_time(at_age)]
	reconstructed_SuperGDU_fts = []
	SuperGDU_polygons = [] 
	temp_list_of_left_features = []
	temp_list_of_right_features = []
	list_of_points_intersecting_left = []
	list_of_points_intersecting_right = [] 
	line_features_for_SuperGDU_2 = [] 
	line_features_for_SuperGDU_1 = []
	outputPointFeatureCollection = pygplates.FeatureCollection()
	outputPointFeatureCollection_2 = pygplates.FeatureCollection()
	outputSmallCirlceFeatureCollection = pygplates.FeatureCollection()
	
	if (reference is not None):
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,group_with_feature = True)
	final_reconstructed_passive_margin_fts = supporting.find_final_reconstructed_geometries(reconstructed_passive_margin_features,pygplates.PolylineOnSphere)
	final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU_fts, pygplates.PolygonOnSphere)
	SuperGDU_polygons[:] = []
	for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
		SuperGDU_polygons.append(SuperGDU_polygon.clone())

	print('find pairs of GDUs_id and associated divergent continental-oceanic divergent margins to find relative stage E poles')
	txt = """SELECT super_gdu_id, represent_gdu_id FROM super_gdu_and_members_id WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}"""
	txt_3 = """SELECT DISTINCT represent_gdu_id,super_gdu_id FROM temp_final_super_gdu_id_2
					WHERE from_time > {input_time} and to_time <= {input_time} AND represent_gdu_id in 
						(SELECT DISTINCT gdu_id_member from super_gdu_and_members_id 
							WHERE super_gdu_id in
								(SELECT DISTINCT super_gdu_id FROM super_gdu_and_members_id 
										WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}))"""
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_2 = conn.cursor()
		cur_4 = conn.cursor()

		already_included = []
		for passive_margin_ft_1, passive_margin_1 in final_reconstructed_passive_margin_fts:
			if (passive_margin_ft_1.get_feature_id().get_string() not in already_included):
				#already_included.append(passive_margin_ft_1.get_feature_id().get_string())
				# left_plate_ID = passive_margin_ft_1.get_left_plate()
				# right_plate_ID = passive_margin_ft_1.get_right_plate()
				left_plate_ID = passive_margin_ft_1.get_reconstruction_plate_id()
				right_plate_ID = passive_margin_ft_1.get_conjugate_plate_id()
				sql = txt.format(input_member_id = left_plate_ID, input_time = at_age)
				cur.execute(sql)
				row = cur.fetchone()
				SuperGDU_id_1 = -1
				SuperGDU_id_2 = -1
				represent_gdu_id_1 = -1
				represent_gdu_id_2 = -1
				if (row is None):
					print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
					print("Warning cannot find SuperGDU id associated with member GDU id:")
					print(left_plate_ID)
					print("at age")
					print(at_age)
					print(sql)
					exit()
				else:
					SuperGDU_id_1 = row[0]
					represent_gdu_id_1 = row[1]
				sql_2 = txt.format(input_member_id = right_plate_ID, input_time = at_age)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				if (row_2 is None):
					print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
					print("Warning cannot find SuperGDU id associated with member GDU id:")
					print(right_plate_ID)
					print("at age")
					print(at_age)
					print(sql_2)
					exit()
				else:
					SuperGDU_id_2 = row_2[0]
					represent_gdu_id_2 = row_2[1]
				if (row is not None and row_2 is not None):
					key = str(represent_gdu_id_1)+"_"+str(represent_gdu_id_2)
					reverse_key = str(represent_gdu_id_2)+"_"+str(represent_gdu_id_1)
					if (key not in dic and reverse_key not in dic):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_conjugate_plate_id() == passive_margin_ft_2.get_reconstruction_plate_id() and passive_margin_ft_2.get_conjugate_plate_id() == passive_margin_ft_1.get_reconstruction_plate_id()):
										sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
										cur_4.execute(sql_4)
										row_4 = cur_4.fetchone()
										if (row_4 is None):
											print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
											print("Warning cannot find SuperGDU id associated with member GDU id:")
											print(passive_margin_ft_2.get_reconstruction_plate_id())
											print("at age")
											print(at_age)
											print(sql_4)
											exit()
										else:
											temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
											temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
											if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
												dic[key] = {str(represent_gdu_id_1): [(passive_margin_ft_1.clone(), passive_margin_1.clone())], str(represent_gdu_id_2): [(passive_margin_ft_2.clone(), passive_margin_2.clone())]} 
												already_included.append(passive_margin_ft_1.get_feature_id().get_string())
												already_included.append(passive_margin_ft_2.get_feature_id().get_string())
					elif (key in dic):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							# if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								# if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									# if ((passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
									# or (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
										# dic[key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										# dic[key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
							if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_conjugate_plate_id() == passive_margin_ft_2.get_reconstruction_plate_id() and passive_margin_ft_2.get_conjugate_plate_id() == passive_margin_ft_1.get_reconstruction_plate_id()):
										sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
										cur_4.execute(sql_4)
										row_4 = cur_4.fetchone()
										if (row_4 is None):
											print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
											print("Warning cannot find SuperGDU id associated with member GDU id:")
											print(passive_margin_ft_2.get_reconstruction_plate_id())
											print("at age")
											print(at_age)
											print(sql_4)
											exit()
										else:
											temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
											temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
											if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
												dic[key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
												dic[key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
												already_included.append(passive_margin_ft_2.get_feature_id().get_string())
												already_included.append(passive_margin_ft_1.get_feature_id().get_string())
		for passive_margin_ft_1, passive_margin_1 in final_reconstructed_passive_margin_fts:
			if (passive_margin_ft_1.get_feature_id().get_string() not in already_included):
				#already_included.append(passive_margin_ft_1.get_feature_id().get_string())
				left_plate_ID = passive_margin_ft_1.get_reconstruction_plate_id()
				right_plate_ID = passive_margin_ft_1.get_conjugate_plate_id()
				sql = txt.format(input_member_id = right_plate_ID, input_time = at_age)
				cur.execute(sql)
				row = cur.fetchone()
				SuperGDU_id_1 = -1
				SuperGDU_id_2 = -1
				represent_gdu_id_1 = -1
				represent_gdu_id_2 = -1
				if (row is None):
					print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
					print("Warning cannot find SuperGDU id associated with member GDU id:")
					print(right_plate_ID)
					print("at age")
					print(at_age)
					print(sql)
					exit()
				else:
					SuperGDU_id_1 = row[0]
					represent_gdu_id_1 = row[1]
				sql_2 = txt.format(input_member_id = left_plate_ID, input_time = at_age)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
				if (row_2 is None):
					print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
					print("Warning cannot find SuperGDU id associated with member GDU id:")
					print(left_plate_ID)
					print("at age")
					print(at_age)
					print(sql_2)
					exit()
				else:
					SuperGDU_id_2 = row_2[0]
					represent_gdu_id_2 = row_2[1]
				if (row is not None and row_2 is not None):
					key = str(represent_gdu_id_1)+"_"+str(represent_gdu_id_2)
					reverse_key = str(represent_gdu_id_2)+"_"+str(represent_gdu_id_1)
					if (key not in dic and reverse_key not in dic):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_conjugate_plate_id() == passive_margin_ft_2.get_reconstruction_plate_id() and passive_margin_ft_2.get_conjugate_plate_id() == passive_margin_ft_1.get_reconstruction_plate_id()):
										sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
										cur_4.execute(sql_4)
										row_4 = cur_4.fetchone()
										if (row_4 is None):
											print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
											print("Warning cannot find SuperGDU id associated with member GDU id:")
											print(passive_margin_ft_2.get_reconstruction_plate_id())
											print("at age")
											print(at_age)
											print(sql_4)
											exit()
										else:
											temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
											temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
											if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
												dic[key] = {str(represent_gdu_id_1): [(passive_margin_ft_1.clone(), passive_margin_1.clone())], str(represent_gdu_id_2): [(passive_margin_ft_2.clone(), passive_margin_2.clone())]} 
												already_included.append(passive_margin_ft_1.get_feature_id().get_string())
												already_included.append(passive_margin_ft_2.get_feature_id().get_string())
					elif (key in dic):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							# if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								# if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									# if ((passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id())\
									# or (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id())):
										# dic[key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										# dic[key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
							if (passive_margin_ft_2.get_feature_id().get_string() not in already_included):
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_conjugate_plate_id() == passive_margin_ft_2.get_reconstruction_plate_id() and passive_margin_ft_2.get_conjugate_plate_id() == passive_margin_ft_1.get_reconstruction_plate_id()):
										sql_4 = txt.format(input_member_id = passive_margin_ft_2.get_reconstruction_plate_id(), input_time = at_age)
										cur_4.execute(sql_4)
										row_4 = cur_4.fetchone()
										if (row_4 is None):
											print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
											print("Warning cannot find SuperGDU id associated with member GDU id:")
											print(passive_margin_ft_2.get_reconstruction_plate_id())
											print("at age")
											print(at_age)
											print(sql_4)
											exit()
										else:
											temp_SuperGDU_for_passive_margin_ft_2 = row_4[0]
											temp_represnt_gdu_id_for_passive_margin_ft_2 = row_4[1]
											if (temp_SuperGDU_for_passive_margin_ft_2 == SuperGDU_id_2 and temp_represnt_gdu_id_for_passive_margin_ft_2 == represent_gdu_id_2):
												dic[key][str(represent_gdu_id_1)].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
												dic[key][str(represent_gdu_id_2)].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
												already_included.append(passive_margin_ft_2.get_feature_id().get_string())
												already_included.append(passive_margin_ft_1.get_feature_id().get_string())
	except (psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
	#find small circles for each E pole
	# print('find small circles for each E pole')
	print('number of pairs of GDUs_id')
	print(len(dic.keys()))

	
	conn = None
	cur_3 = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_3 = conn.cursor()
	except (psycopg2.DatabaseError) as error:
		print (error)
		exit()
	for key in dic.keys():
		count_locations_of_MOR = 0
		pairs_GDU_id = key.split('_')
		plate_id_1 = int(pairs_GDU_id[0])
		plate_id_2 = int(pairs_GDU_id[1])
		initial_plate_id_1 = plate_id_1
		initial_plate_id_2 = plate_id_2
		print("plate_id_1,plate_id_2", plate_id_1, plate_id_2)
		print("key",key)
		SuperGDU_1 = None 
		SuperGDU_2 = None
		SuperGDU_1_size = 0.00
		SuperGDU_2_size = 0.00
		for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
			if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1):
				if (SuperGDU_1_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_1_size):
					SuperGDU_1_size = SuperGDU_polygon.get_area()
					SuperGDU_1 = SuperGDU_polygon
			elif (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2):
				if (SuperGDU_2_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_2_size):
					SuperGDU_2_size = SuperGDU_polygon.get_area()
					SuperGDU_2 = SuperGDU_polygon
		if (SuperGDU_1 is None):
			sql_3 = txt_3.format(input_member_id = plate_id_1 , input_time = at_age)
			cur_3.execute(sql_3)
			row_3 = cur_3.fetchone()
			if (row_3 is None):
				print('Error find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2')
				print('sql_3')
				print(sql_3)
				exit()
			plate_id_1 = int(row_3[0])
			SuperGDU_1_name = row_3[1]
			SuperGDU_1 = None 
			SuperGDU_1_size = 0.00
			for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1 or int(SuperGDU_ft.get_name()) == SuperGDU_1_name):
					if (SuperGDU_1_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_1_size):
						SuperGDU_1_size = SuperGDU_polygon.get_area()
						SuperGDU_1 = SuperGDU_polygon
		if (SuperGDU_1 is None):
			print("Error SuperGDU_1 is None")
			print("plate_id_1,SuperGDU_1_name", plate_id_1, SuperGDU_1_name)
			for ft in SuperGDU_features:
				if (ft.get_reconstruction_plate_id() == plate_id_1 or int(SuperGDU_ft.get_name()) == SuperGDU_1_name):
					print(ft.get_reconstruction_plate_id())
					print(ft.get_name())
					print(ft.get_valid_time())
			exit()
		if (SuperGDU_2 is None):
			sql_3 = txt_3.format(input_member_id = plate_id_2 , input_time = at_age)
			cur_3.execute(sql_3)
			row_3 = cur_3.fetchone()
			if (row_3 is None):
				print('Error find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2')
				print('sql_3')
				print(sql_3)
				exit()
			plate_id_2 = int(row_3[0])
			SuperGDU_2 = None 
			SuperGDU_2_size = 0.00
			SuperGDU_2_name = row_3[1]
			for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2 or int(SuperGDU_ft.get_name()) == SuperGDU_2_name):
					if (SuperGDU_2_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_2_size):
						SuperGDU_2_size = SuperGDU_polygon.get_area()
						SuperGDU_2 = SuperGDU_polygon
		if (SuperGDU_2 is None):
			print("Error SuperGDU_2 is None")
			print("plate_id_2,SuperGDU_2_name", plate_id_2, SuperGDU_2_name)
			for ft in SuperGDU_features:
				if (ft.get_reconstruction_plate_id() == plate_id_2 or int(SuperGDU_ft.get_name()) == SuperGDU_2_name):
					print(ft.get_reconstruction_plate_id())
					print(ft.get_name())
					print(ft.get_valid_time())
			exit()
		#stage_relative_reconstruction_rotation = tm.find_stage_relative_reconstruction_rotation_(rotation_model,initial_plate_id_1,initial_plate_id_2, at_age, interval)
		#if (stage_relative_reconstruction_rotation.represents_identity_rotation() == False):
		total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,initial_plate_id_1,initial_plate_id_2, at_age, reference)
		if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
			list_of_points_for_SuperGDU_1 = []
			list_of_points_for_SuperGDU_2 = []
			E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
			smallest_circle_angular_radius_degrees = 179.00
			#smallest_circle_angular_radius_degrees = 90.00
			#final_left_plate_id and final_right_plate_id to assign oceanic crust
			final_left_plate_id, final_right_plate_id = -1,-1
			while (smallest_circle_angular_radius_degrees > 0.00):
				#print('value of smallest_circle_angular_radius_degrees')
				#print(smallest_circle_angular_radius_degrees)
				#debug
				# if ((initial_plate_id_1 == 10953 and initial_plate_id_2 == 10439) or (initial_plate_id_1 == 10439 and initial_plate_id_2 == 10953)):
					# small_circle_ft = None
					# small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
					# small_circle_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, small_circle_boundary, valid_time = (at_age,0.00))
					# #small_circle_ft.set_description(str(smallest_circle_angular_radius_degrees))
					# small_circle_ft.set_name(str(smallest_circle_angular_radius_degrees))
					# outputSmallCirlceFeatureCollection.add(small_circle_ft)
					#pygplates.reverse_reconstruct(outputSmallCirlceFeatureCollection, rotation_model, at_age, initial_plate_id_1)
				small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
				list_of_points_for_SuperGDU_1[:] = []
				list_of_points_for_SuperGDU_2[:] = []
				for passive_margin_ft, passive_margin in dic[key][str(initial_plate_id_1)]:
					approx_rad_closest_dist, point_on_margin, _ = pygplates.GeometryOnSphere.distance(passive_margin, small_circle_boundary, return_closest_positions = True)
					if (approx_rad_closest_dist == 0.00):
						# new_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,point_on_SuperGDU_1,valid_time = (at_age,0.00))
						# new_feature.set_reconstruction_plate_id(initial_plate_id_1)
						temp_begin_age, temp_end_age = passive_margin_ft.get_valid_time()
						temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, point_on_margin, valid_time = (at_age,temp_end_age))
						if (reference is not None):
							pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age,reference)
						else:
							pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age)
						list_of_points_for_SuperGDU_1.append((temp_pt_ft, point_on_margin))
						
				for passive_margin_ft, passive_margin in dic[key][str(initial_plate_id_2)]:		
					approx_rad_closest_dist, point_on_margin, _ = pygplates.GeometryOnSphere.distance(passive_margin, small_circle_boundary, return_closest_positions = True)
					if (approx_rad_closest_dist == 0.00):
						temp_begin_age, temp_end_age = passive_margin_ft.get_valid_time()
						temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, point_on_margin, valid_time = (at_age,temp_end_age))
						temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_2)
						temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
						temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
						temp_output_points_fts.add(temp_pt_ft)
						
						
						if (reference is not None):
							pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age,reference)
						else:
							pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age)
						list_of_points_for_SuperGDU_2.append((temp_pt_ft, point_on_margin))

				if (len(list_of_points_for_SuperGDU_1) > 0 and len(list_of_points_for_SuperGDU_2) == 0):
					# #find interesections between SuperGDU_2 and small_circle_boundary
					# small_circle_boundary_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
					SuperGDU_2_PolylineOnSphere = pygplates.PolylineOnSphere(SuperGDU_2.to_lat_lon_list())
					for segment in SuperGDU_2_PolylineOnSphere.get_segments():
						start_point = segment.get_start_point()						   
						end_point = segment.get_end_point()
						small_line = pygplates.PolylineOnSphere([start_point,end_point])
						approx_rad_closest_dist, point_on_margin, _ = pygplates.GeometryOnSphere.distance(small_line, small_circle_boundary, return_closest_positions = True)
						if (approx_rad_closest_dist == 0.00):
							temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, point_on_margin, valid_time = (at_age,0.00))
							temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_2)
							temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
							temp_pt_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2)+"_SuperGDU")
							temp_output_points_fts.add(temp_pt_ft)
							if (reference is not None):
								pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age,reference)
							else:
								pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age)
							list_of_points_for_SuperGDU_2.append((temp_pt_ft, point_on_margin))
				elif (len(list_of_points_for_SuperGDU_1) == 0 and len(list_of_points_for_SuperGDU_2) > 0):
					# #find interesections between SuperGDU_1 and small_circle_boundary
					# small_circle_boundary_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
					SuperGDU_1_PolylineOnSphere = pygplates.PolylineOnSphere(SuperGDU_1.to_lat_lon_list())
					for segment in SuperGDU_1_PolylineOnSphere.get_segments():
						start_point = segment.get_start_point()						   
						end_point = segment.get_end_point()
						small_line = pygplates.PolylineOnSphere([start_point,end_point])
						approx_rad_closest_dist, point_on_margin, _ = pygplates.GeometryOnSphere.distance(small_line, small_circle_boundary, return_closest_positions = True)
						if (approx_rad_closest_dist == 0.00):
							temp_pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, point_on_margin, valid_time = (at_age,0.00))
							temp_pt_ft.set_reconstruction_plate_id(initial_plate_id_1)
							temp_pt_ft.set_description(str(smallest_circle_angular_radius_degrees))
							temp_pt_ft.set_name("SuperGDU_"+str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
							if (reference is not None):
								pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age,reference)
							else:
								pygplates.reverse_reconstruct(temp_pt_ft,rotation_model,at_age)
							list_of_points_for_SuperGDU_1.append((temp_pt_ft, point_on_margin))

				if (len(list_of_points_for_SuperGDU_1) > 0 and len(list_of_points_for_SuperGDU_2) > 0):
					minimum_dist_btw = -1.00
					chosen_pt_1, chosen_pt_2 = None, None
					chosen_ft_1, chosen_ft_2 = None, None
					for ft_1,pt_1 in list_of_points_for_SuperGDU_1:
						for ft_2,pt_2 in list_of_points_for_SuperGDU_2:
							d = pygplates.GeometryOnSphere.distance(pt_1, pt_2)
							if (minimum_dist_btw == -1.00 or (minimum_dist_btw > 0.00 and d > 0.00 and d < minimum_dist_btw)):
								minimum_dist_btw = d
								chosen_pt_1, chosen_pt_2 = pt_1,pt_2
								chosen_ft_1, chosen_ft_2 = ft_1,ft_2
					approx_dis_in_km = minimum_dist_btw * pygplates.Earth.equatorial_radius_in_kms
					if (chosen_pt_1 is not None and chosen_pt_2 is not None and approx_dis_in_km >= 5.00):
						#choose the end_age for MOR
						temp_begin_age_1, temp_end_age_1 = chosen_ft_1.get_valid_time()
						temp_begin_age_2, temp_end_age_2 = chosen_ft_2.get_valid_time()
						final_end_age = 0.00
						if (temp_end_age_1 > temp_end_age_2):
							final_end_age = temp_end_age_1
						else:
							final_end_age = temp_end_age_2
						#find MOR location
						MOR_location = tm.find_the_mid_of_two_PointOnSphere(chosen_pt_1,chosen_pt_2)
						print("chosen_pt_1,chosen_pt_2,MOR_location",chosen_pt_1,chosen_pt_2,MOR_location)
						print("minimum_dist_btw",minimum_dist_btw)
						count_locations_of_MOR = count_locations_of_MOR + 1
						great_circle_arc = pygplates.GreatCircleArc(MOR_location,E_pole)
						normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
						MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, MOR_location, valid_time = (at_age,final_end_age))
						MOR_location_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
						MOR_location_ft.set_name(key)
						side_1 = classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1)
						side_2 = classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2)
						if (side_1 == 'left' and side_2 == 'right'):
							MOR_location_ft.set_left_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
							MOR_location_ft.set_right_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
						elif (side_1 == 'right' and side_2 == 'left'):
							MOR_location_ft.set_left_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
							MOR_location_ft.set_right_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
						else:
							print("Error in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2")
							print("Error unexpected values for side_1 and side_2")
							print("side_1, side_2", side_1, side_2)
							print(calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1))
							print(calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2))
							exit()
						MOR_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
						list_of_MOR_locations.append((at_age,MOR_location_ft.get_feature_id().get_string(),MOR_location_ft.get_left_plate(),MOR_location_ft.get_right_plate(),smallest_circle_angular_radius_degrees))
						outputPointFeatureCollection.add(MOR_location_ft)
						
						#output chosen_pt_1 and chosen_pt_2
						pt1_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, chosen_pt_1, valid_time = (at_age,final_end_age))
						if (side_1 == 'left' and side_2 == 'right'):
							pt1_location_ft.set_left_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
							pt1_location_ft.set_right_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
						elif (side_1 == 'right' and side_2 == 'left'):
							pt1_location_ft.set_left_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
							pt1_location_ft.set_right_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
						pt1_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
						pt1_location_ft.set_reconstruction_plate_id(initial_plate_id_1)
						pt1_location_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
						outputPointFeatureCollection_2.add(pt1_location_ft)

						pt2_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, chosen_pt_2, valid_time = (at_age,final_end_age))
						if (side_1 == 'left' and side_2 == 'right'):
							pt2_location_ft.set_left_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
							pt2_location_ft.set_right_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
						elif (side_1 == 'right' and side_2 == 'left'):
							pt2_location_ft.set_left_plate(initial_plate_id_2,verify_information_model = pygplates.VerifyInformationModel.no)
							pt2_location_ft.set_right_plate(initial_plate_id_1,verify_information_model = pygplates.VerifyInformationModel.no)
						pt2_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
						pt2_location_ft.set_reconstruction_plate_id(initial_plate_id_2)
						pt2_location_ft.set_name(str(initial_plate_id_1)+"_"+str(initial_plate_id_2))
						outputPointFeatureCollection_2.add(pt2_location_ft)

				#update smallest_circle_angular_radius_degrees
				smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.00
	
	if (reference is not None):
		pygplates.reverse_reconstruct(outputPointFeatureCollection_2, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(outputPointFeatureCollection, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(temp_output_points_fts, rotation_model, at_age, reference)
	else:
		pygplates.reverse_reconstruct(outputPointFeatureCollection_2, rotation_model, at_age)
		pygplates.reverse_reconstruct(outputPointFeatureCollection, rotation_model, at_age)
		pygplates.reverse_reconstruct(temp_output_points_fts, rotation_model, at_age)
	#output_SuperGDU_fts.write("output_SuperGDU_fts_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	temp_output_points_fts.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\temp_output_location_ft_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	outputPointFeatureCollection.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\MOR_location_ft_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	outputPointFeatureCollection_2.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\div_margin_location_ft_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".shp")
	new_dataframe = pd.DataFrame.from_records(list_of_MOR_locations, columns = ['age','ft_id','left_plate_id','right_plate_id','smallest_circle_radius_degrees'])
	filename = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\attributes_of_MOR_locations_"+modelname+"_"+str(at_age)+"_"+yyyymmdd+".csv"
	new_dataframe.to_csv(filename,index=False)

def create_list_of_ordered_MOR_or_div_locations_fts(list_of_initial_locations_ft, interval_of_btw_order, order_as_asc_or_desc, is_ridge_and_transform):
	list_of_ordered_fts = []
	storage = []
	maximum_order = -1.00
	ft_w_max_order = None
	for ft in list_of_initial_locations_ft:
		if (maximum_order == -1.00):
			ft_w_max_order = ft
			maximum_order = float(ft.get_description())
		else:
			current_order = float(ft.get_description())
			if (maximum_order < current_order):
				ft_w_max_order = ft
				maximum_order = current_order
	
	minimum_order = 200.00
	ft_w_min_order = None
	for ft in list_of_initial_locations_ft:
		if (minimum_order == 200.00):
			ft_w_min_order = ft
			minimum_order = float(ft.get_description())
		else:
			current_order = float(ft.get_description())
			if (minimum_order > current_order):
				ft_w_min_order = ft
				minimum_order = current_order
	if (is_ridge_and_transform == False):
		if (order_as_asc_or_desc == "desc"):
			list_of_ordered_fts.append(ft_w_max_order)
			start = maximum_order - interval_of_btw_order
			previous_order = maximum_order
			order = start
			while(order >= minimum_order):
				for ft in list_of_initial_locations_ft:
					ft_order = float(ft.get_description())
					if (ft_order == order):
						if (previous_order > 0.00):
							if (abs(previous_order - ft_order) > 5.00):
								if (len(list_of_ordered_fts) > 1):
									storage.append(list_of_ordered_fts)
								new_list = [ft]
								list_of_ordered_fts = new_list
							else:
								list_of_ordered_fts.append(ft)
						else:
							list_of_ordered_fts.append(ft)
						previous_order = ft_order
						break
				order = order - interval_of_btw_order
			#list_of_ordered_fts.append(ft_w_min_order)
		else:
			list_of_ordered_fts.append(ft_w_min_order)
			start = minimum_order + interval_of_btw_order
			previous_order = minimum_order
			order = start
			while(order <= maximum_order):
				for ft in list_of_initial_locations_ft:
					ft_order = float(ft.get_description())
					if (ft_order == order):
						if (previous_order > 0.00):
							if (abs(previous_order - ft_order) > 5.00):
								if (len(list_of_ordered_fts) > 1):
									storage.append(list_of_ordered_fts)
								new_list = [ft]
								list_of_ordered_fts = new_list
							else:
								list_of_ordered_fts.append(ft)
						else:
							list_of_ordered_fts.append(ft)
						previous_order = ft_order
						break
				order = order + interval_of_btw_order
			#list_of_ordered_fts.append(ft_w_max_order)
	else:
		if (order_as_asc_or_desc == "desc"):
			list_of_ordered_fts.append(ft_w_max_order)
			start = maximum_order - interval_of_btw_order
			previous_order = maximum_order
			order = start
			while(order >= minimum_order):
				transform_ft = None
				MOR_ft = None
				for ft in list_of_initial_locations_ft:
					ft_order = float(ft.get_description())
					if (ft_order == order):
						if(ft.get_feature_type() == pygplates.FeatureType.gpml_basic_rock_unit):
							transform_ft = ft
						elif (ft.get_feature_type() == pygplates.FeatureType.gpml_oceanic_crust):
							MOR_ft = ft
						if (transform_ft is not None and MOR_ft is not None):
							break
				
				if (transform_ft is not None):
					list_of_ordered_fts.append(transform_ft)
					if (previous_order > 0.00):
						if (abs(previous_order - order) > 5.00):
							if (len(list_of_ordered_fts) > 1):
								storage.append(list_of_ordered_fts)
							new_list = [transform_ft]
							list_of_ordered_fts = new_list
						else:
							list_of_ordered_fts.append(transform_ft)
					else:
						list_of_ordered_fts.append(transform_ft)
					previous_order = ft_order
				if (MOR_ft is not None):
					if (previous_order > 0.00):
						if (abs(previous_order - order) > 5.00):
							if (len(list_of_ordered_fts) > 1):
								storage.append(list_of_ordered_fts)
							new_list = [MOR_ft]
							list_of_ordered_fts = new_list
						else:
							list_of_ordered_fts.append(MOR_ft)
					else:
						list_of_ordered_fts.append(MOR_ft)
					previous_order = ft_order
				order = order - interval_of_btw_order
			#list_of_ordered_fts.append(ft_w_min_order)
		else:
			list_of_ordered_fts.append(ft_w_min_order)
			start = minimum_order
			order = start
			previous_order = 0.00
			while(order <= maximum_order):
				transform_ft = None
				MOR_ft = None
				for ft in list_of_initial_locations_ft:
					ft_order = float(ft.get_description())
					if (ft_order == order):
						if(ft.get_feature_type() == pygplates.FeatureType.gpml_basic_rock_unit):
							transform_ft = ft
						elif (ft.get_feature_type() == pygplates.FeatureType.gpml_oceanic_crust):
							MOR_ft = ft
						if (transform_ft is not None and MOR_ft is not None):
							break
				if (transform_ft is not None):
					list_of_ordered_fts.append(transform_ft)
					if (previous_order > 0.00):
						if (abs(previous_order - order) > 5.00):
							if (len(list_of_ordered_fts) > 1):
								storage.append(list_of_ordered_fts)
							new_list = [transform_ft]
							list_of_ordered_fts = new_list
						else:
							list_of_ordered_fts.append(transform_ft)
					else:
						list_of_ordered_fts.append(transform_ft)
					previous_order = ft_order
				if (MOR_ft is not None):
					if (previous_order > 0.00):
						if (abs(previous_order - order) > 5.00):
							if (len(list_of_ordered_fts) > 1):
								storage.append(list_of_ordered_fts)
							new_list = [MOR_ft]
							list_of_ordered_fts = new_list
						else:
							list_of_ordered_fts.append(MOR_ft)
					else:
						list_of_ordered_fts.append(MOR_ft)
					previous_order = ft_order
				order = order + interval_of_btw_order
			#list_of_ordered_fts.append(ft_w_max_order)
	if (len(list_of_ordered_fts) > 1):
		storage.append(list_of_ordered_fts)
	return storage

def create_list_of_ordered_div_locations_fts(list_of_initial_locations_ft, list_of_order_MOR, is_ridge_and_transform):
	list_of_ordered_fts = []
	list_of_unfound_order = []
	storage = []
	first_order = -1.00
	print("list_of_order_MOR",list_of_order_MOR)
	for wanted_order in list_of_order_MOR:
		print("wanted_order",wanted_order)
		if (is_ridge_and_transform == False):
			found_associated_ft = False
			for div_ft in list_of_initial_locations_ft:
				div_ft_order = float(div_ft.get_description())
				print("div_ft_order",div_ft_order)
				if (first_order == -1.00):
					if (div_ft_order < wanted_order):
						list_of_ordered_fts.append(div_ft)
						found_associated_ft = True
						break
				else:
					if (div_ft_order == wanted_order):
						list_of_ordered_fts.append(div_ft)
						first_order = wanted_order
						found_associated_ft = True
						break
			if (found_associated_ft == False):
				list_of_unfound_order.append(wanted_order)
				if (len(list_of_ordered_fts) > 1):
					storage.append(list_of_ordered_fts)
				new_list = [div_ft]
				list_of_ordered_fts = new_list
		else:
			found_associated_ft = False
			transform_ft = None
			MOR_ft = None
			for div_ft in list_of_initial_locations_ft:
				div_ft_order = float(div_ft.get_description())
				if (first_order == -1.00):
					if (div_ft_order < wanted_order):
						if (div_ft.get_feature_type() == pygplates.FeatureType.gpml_basic_rock_unit):
							transform_ft = div_ft
						elif (div_ft.get_feature_type() == pygplates.FeatureType.gpml_oceanic_crust):
							MOR_ft = div_ft
				else:
					if (div_ft_order == wanted_order):
						if (div_ft.get_feature_type() == pygplates.FeatureType.gpml_basic_rock_unit):
							transform_ft = div_ft
						elif (div_ft.get_feature_type() == pygplates.FeatureType.gpml_oceanic_crust):
							MOR_ft = div_ft
				if (transform_ft is not None and MOR_ft is not None):
					break
			if (MOR_ft is not None):
				found_associated_ft = True
				list_of_ordered_fts.append(MOR_ft)
			if (transform_ft is not None):
				list_of_ordered_fts.append(transform_ft)
			if (found_associated_ft == False):
				list_of_unfound_order.append(wanted_order)
				if (len(list_of_ordered_fts) > 1):
					storage.append(list_of_ordered_fts)
				new_list = [div_ft]
				list_of_ordered_fts = new_list
	print("list_of_ordered_fts",list_of_ordered_fts)
	if (len(list_of_ordered_fts) > 1):
		storage.append(list_of_ordered_fts)
	return (storage,list_of_unfound_order)

def create_left_and_right_div_fts_from_MOR_ft(MOR_ft, current_geom, at_age):
	left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age,0.00))
	left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_name(MOR_ft.get_name())
	left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
	left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)

	right_MOR_location_ft = left_MOR_location_ft.clone()
	right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
	right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	return (left_MOR_location_ft,right_MOR_location_ft)

def create_MOR_feature_for_a_pair_of_SuperGDUs_only(list_of_reconstructed_ordered_MOR_locations_ft, at_age, threshold_degrees, rotation_model, reference, write_tmp):
	"""list of order MOR location ft: contains MOR location fts at age - not yet applied reverse_reconstruct - in the order from the maximum small circle angular degreee
		to the minimum"""
	previous_ft = None
	previous_geom = None
	list_of_ordered_points_for_MOR = []
	list_of_ridges = []
	list_of_transforms = []
	previous_MOR_transform_fts_collections = pygplates.FeatureCollection()
	index = 1
	for MOR_ft,reconstructed_geometry in list_of_reconstructed_ordered_MOR_locations_ft:
		if (previous_ft is None):
			previous_ft = MOR_ft
			list_of_ordered_points_for_MOR.append(reconstructed_geometry)
			previous_geom = reconstructed_geometry
			left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, previous_geom, valid_time = (at_age,0.00))
			left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_name(MOR_ft.get_name())
			left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
			left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
			right_MOR_location_ft = left_MOR_location_ft.clone()
			right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
			right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
		else:
			current_geom = reconstructed_geometry
			
			previous_x,previous_y,previous_z = previous_geom.to_xyz()
			current_x,current_y,current_z = current_geom.to_xyz()
			vector_from_previous_to_current = pygplates.Vector3D([(current_x-previous_x),(current_y-previous_y),(current_z-previous_z)])
			#convert vector_from_previous_to_current from geocentric coordinates to local coordinates with respected to previous_geom
			magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(previous_geom, vector_from_previous_to_current)
			azim_degrees = math.degrees(azimuth)
			if((azim_degrees <= threshold_degrees) or ((azim_degrees) >= (360.00 - threshold_degrees))):
				ridge_seg = pygplates.PolylineOnSphere([previous_geom,current_geom])
				list_of_ordered_points_for_MOR.append(current_geom)
				
				left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age,0.00))
				left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_name(MOR_ft.get_name())
				left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
				right_MOR_location_ft = left_MOR_location_ft.clone()
				right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
			else:
				previous_lat,previous_lon = previous_geom.to_lat_lon()
				current_lat,current_lon = current_geom.to_lat_lon()
				estimated_transform_point = pygplates.PointOnSphere((previous_lat,current_lon))
				
				trans_seg = pygplates.PolylineOnSphere([previous_geom,estimated_transform_point])
				#create transform_ft 
				transform_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, trans_seg, valid_time = (at_age,0.00))
				transform_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				transform_ft.set_conjugate_plate_id(MOR_ft.get_right_plate())
				transform_ft.set_name(MOR_ft.get_name())
				transform_ft.set_description(str(index))
				list_of_transforms.append(transform_ft)
				
				ridge_seg = pygplates.PolylineOnSphere([estimated_transform_point,current_geom])
				#create ridge_ft
				ridge_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, ridge_seg, valid_time = (at_age,0.00))
				ridge_ft.set_reconstruction_method('HalfStageRotationVersion2')
				ridge_ft.set_left_plate(MOR_ft.get_left_plate())
				ridge_ft.set_right_plate(MOR_ft.get_right_plate())
				ridge_ft.set_name(MOR_ft.get_name())
				ridge_ft.set_description(str(index))
				list_of_ridges.append(ridge_ft)
				
				list_of_ordered_points_for_MOR.append(estimated_transform_point)
				list_of_ordered_points_for_MOR.append(current_geom)
				
				left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age,0.00))
				left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_name(MOR_ft.get_name())
				left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
				right_MOR_location_ft = left_MOR_location_ft.clone()
				right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
				
				left_transform_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_basic_rock_unit, estimated_transform_point, valid_time = (at_age,0.00))
				left_transform_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_name(MOR_ft.get_name())
				left_transform_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_transform_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_transform_location_ft)
				
				right_transform_location_ft = left_transform_location_ft.clone()
				right_transform_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_transform_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_transform_location_ft)
				
			
			index = index + 1
			previous_ft = MOR_ft
			previous_geom = reconstructed_geometry
	
	final_linear_for_entire_MOR = pygplates.PolylineOnSphere(list_of_ordered_points_for_MOR)
	final_linear_for_entire_MOR_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, final_linear_for_entire_MOR, valid_time = (at_age,0.00))
	final_linear_for_entire_MOR_ft.set_reconstruction_method('HalfStageRotationVersion2')
	final_linear_for_entire_MOR_ft.set_left_plate(MOR_ft.get_left_plate())
	final_linear_for_entire_MOR_ft.set_right_plate(MOR_ft.get_right_plate())
	final_linear_for_entire_MOR_ft.set_name(MOR_ft.get_name())
	final_linear_for_entire_MOR_ft.set_description(str(index))
	
	left_linear_for_entire_MOR = pygplates.PolylineOnSphere(list_of_ordered_points_for_MOR)
	left_linear_for_entire_MOR_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, final_linear_for_entire_MOR, valid_time = (at_age,0.00))
	left_linear_for_entire_MOR_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
	left_linear_for_entire_MOR_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_linear_for_entire_MOR_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_linear_for_entire_MOR_ft.set_name(MOR_ft.get_name())
	left_linear_for_entire_MOR_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_linear_for_entire_MOR_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_linear_for_entire_MOR_ft.set_description(str(index))
	
	right_linear_for_entire_MOR_ft = left_linear_for_entire_MOR_ft.clone()
	right_linear_for_entire_MOR_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	right_linear_for_entire_MOR_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	
	if (reference is not None):
		pygplates.reverse_reconstruct(final_linear_for_entire_MOR_ft, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(left_linear_for_entire_MOR_ft, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(right_linear_for_entire_MOR_ft, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(list_of_ridges, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(list_of_transforms, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(previous_MOR_transform_fts_collections, rotation_model, at_age, reference)
	else:
		pygplates.reverse_reconstruct(final_linear_for_entire_MOR_ft, rotation_model, at_age)
		pygplates.reverse_reconstruct(left_linear_for_entire_MOR_ft, rotation_model, at_age)
		pygplates.reverse_reconstruct(right_linear_for_entire_MOR_ft, rotation_model, at_age)
		pygplates.reverse_reconstruct(list_of_ridges, rotation_model, at_age)
		pygplates.reverse_reconstruct(list_of_transforms, rotation_model, at_age)
		pygplates.reverse_reconstruct(previous_MOR_transform_fts_collections, rotation_model, at_age)
	# if (write_tmp == True):
		# temp_outputPointFeatureCollection = pygplates.FeatureCollection(final_linear_for_entire_MOR_ft)
		# temp_outputPointFeatureCollection.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\final_linear_for_entire_MOR_ft_"+MOR_ft.get_name()+"_"+str(at_age)+".shp")
	
	name = MOR_ft.get_name()
	outputPointFeatureCollection = pygplates.FeatureCollection(list_of_ridges)
	outputPointFeatureCollection.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\ridges_"+name+"_"+str(at_age)+".shp")
	outputPointFeatureCollection_2 = pygplates.FeatureCollection(list_of_transforms)
	outputPointFeatureCollection_2.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\transforms_"+name+"_"+str(at_age)+".shp")
	
	previous_MOR_transform_fts_collections.write(r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\previous_MOR_transform_fts_"+MOR_ft.get_name()+"_"+str(at_age)+".shp")
	
	return (list_of_ordered_points_for_MOR,final_linear_for_entire_MOR_ft,left_linear_for_entire_MOR_ft,right_linear_for_entire_MOR_ft)

#to_age for divergent feature has to be to age of divergence

def create_temporal_linear_MOR_feature_for_parent_SuperGDUs(parent_SuperGDUs_id,list_of_reconstructed_ordered_MOR_locations_ft, at_age, to_age, threshold_degrees, rotation_model, reference):
	"""list of order MOR location ft: contains MOR location fts at age - not yet applied reverse_reconstruct - in the order from the maximum small circle angular degreee
		to the minimum"""
	list_of_ordered_points_for_MOR = []
	output_final_linear_ft_for_MOR = pygplates.FeatureCollection()
	previous_MOR_transform_fts_collections = pygplates.FeatureCollection()
	previous_geom = None
	previous_ft = None
	for MOR_ft,reconstructed_geometry in list_of_reconstructed_ordered_MOR_locations_ft:
		if (previous_ft is None):
			previous_ft = MOR_ft
			list_of_ordered_points_for_MOR.append(reconstructed_geometry)
			previous_geom = reconstructed_geometry
			left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, previous_geom, valid_time = (at_age,to_age))
			left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_name(parent_SuperGDUs_id)
			left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
			left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
			right_MOR_location_ft = left_MOR_location_ft.clone()
			right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
			right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
		else:
			current_geom = reconstructed_geometry
			#calculate the distance between previous_geom and current_geom
			approx_dis_in_km = pygplates.GeometryOnSphere.distance(previous_geom, current_geom) * pygplates.Earth.equatorial_radius_in_kms
			if (approx_dis_in_km < 500.00):
				list_of_ordered_points_for_MOR.append(current_geom)
				
				left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age,to_age))
				left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_name(parent_SuperGDUs_id)
				left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
				right_MOR_location_ft = left_MOR_location_ft.clone()
				right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
			else:
				if (len(list_of_ordered_points_for_MOR) >1):
					final_linear_for_entire_MOR = pygplates.PolylineOnSphere(list_of_ordered_points_for_MOR)
					final_linear_for_entire_MOR_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, final_linear_for_entire_MOR, valid_time = (at_age, to_age))
					final_linear_for_entire_MOR_ft.set_reconstruction_method('HalfStageRotationVersion2')
					final_linear_for_entire_MOR_ft.set_left_plate(MOR_ft.get_left_plate())
					final_linear_for_entire_MOR_ft.set_right_plate(MOR_ft.get_right_plate())
					final_linear_for_entire_MOR_ft.set_name(parent_SuperGDUs_id)
					output_final_linear_ft_for_MOR.add(final_linear_for_entire_MOR_ft)
				
					list_of_ordered_points_for_MOR[:] = []
					list_of_ordered_points_for_MOR.append(current_geom)
				
					left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age, to_age))
					left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
					left_MOR_location_ft.set_name(parent_SuperGDUs_id)
					left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
					left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
					left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
					left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
					left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
					previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
					right_MOR_location_ft = left_MOR_location_ft.clone()
					right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
					right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
					previous_MOR_transform_fts_collections.add(right_MOR_location_ft)

				previous_ft = MOR_ft
				previous_geom = reconstructed_geometry

	if (len(list_of_ordered_points_for_MOR) > 1):
		final_linear_for_entire_MOR = pygplates.PolylineOnSphere(list_of_ordered_points_for_MOR)
		final_linear_for_entire_MOR_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, final_linear_for_entire_MOR, valid_time = (at_age, to_age))
		final_linear_for_entire_MOR_ft.set_reconstruction_method('HalfStageRotationVersion2')
		final_linear_for_entire_MOR_ft.set_left_plate(MOR_ft.get_left_plate())
		final_linear_for_entire_MOR_ft.set_right_plate(MOR_ft.get_right_plate())
		final_linear_for_entire_MOR_ft.set_name(parent_SuperGDUs_id)
		output_final_linear_ft_for_MOR.add(final_linear_for_entire_MOR_ft)
	
	if (reference is not None):
		pygplates.reverse_reconstruct(output_final_linear_ft_for_MOR, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(previous_MOR_transform_fts_collections, rotation_model, at_age, reference)
	else:
		pygplates.reverse_reconstruct(output_final_linear_ft_for_MOR, rotation_model, at_age)
		pygplates.reverse_reconstruct(previous_MOR_transform_fts_collections, rotation_model, at_age)

	
	return (output_final_linear_ft_for_MOR,previous_MOR_transform_fts_collections)

def create_linear_MOR_feature_for_parent_SuperGDUs(parent_SuperGDUs_id,list_of_reconstructed_ordered_MOR_locations_ft, at_age, to_age, threshold_degrees, rotation_model, reference):
	"""list of order MOR location ft: contains MOR location fts at age - not yet applied reverse_reconstruct - in the order from the maximum small circle angular degreee
		to the minimum"""
	previous_ft = None
	previous_geom = None
	list_of_ordered_points_for_MOR = []
	list_of_ridges = []
	list_of_transforms = []
	previous_MOR_transform_fts_collections = pygplates.FeatureCollection()
	index = 1
	for MOR_ft,reconstructed_geometry in list_of_reconstructed_ordered_MOR_locations_ft:
		if (previous_ft is None):
			previous_ft = MOR_ft
			list_of_ordered_points_for_MOR.append(reconstructed_geometry)
			previous_geom = reconstructed_geometry
			left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, previous_geom, valid_time = (at_age, to_age))
			left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_name(parent_SuperGDUs_id)
			left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
			left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
			right_MOR_location_ft = left_MOR_location_ft.clone()
			right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
			right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
		else:
			current_geom = reconstructed_geometry
			
			previous_x,previous_y,previous_z = previous_geom.to_xyz()
			current_x,current_y,current_z = current_geom.to_xyz()
			vector_from_previous_to_current = pygplates.Vector3D([(current_x-previous_x),(current_y-previous_y),(current_z-previous_z)])
			#convert vector_from_previous_to_current from geocentric coordinates to local coordinates with respected to previous_geom
			magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(previous_geom, vector_from_previous_to_current)
			azim_degrees = math.degrees(azimuth)
			if((azim_degrees <= threshold_degrees) or ((azim_degrees) >= (360.00 - threshold_degrees))):
				ridge_seg = pygplates.PolylineOnSphere([previous_geom,current_geom])
				list_of_ordered_points_for_MOR.append(current_geom)
				
				left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age, to_age))
				left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_name(parent_SuperGDUs_id)
				left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
				right_MOR_location_ft = left_MOR_location_ft.clone()
				right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
			else:
				previous_lat,previous_lon = previous_geom.to_lat_lon()
				current_lat,current_lon = current_geom.to_lat_lon()
				estimated_transform_point = pygplates.PointOnSphere((previous_lat,current_lon))
				
				trans_seg = pygplates.PolylineOnSphere([previous_geom,estimated_transform_point])
				#create transform_ft 
				transform_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, trans_seg, valid_time = (at_age, to_age))
				transform_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				transform_ft.set_conjugate_plate_id(MOR_ft.get_right_plate())
				transform_ft.set_name(parent_SuperGDUs_id)
				transform_ft.set_description(str(index))
				list_of_transforms.append(transform_ft)
				
				ridge_seg = pygplates.PolylineOnSphere([estimated_transform_point,current_geom])
				#create ridge_ft
				ridge_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, ridge_seg, valid_time = (at_age, to_age))
				ridge_ft.set_reconstruction_method('HalfStageRotationVersion2')
				ridge_ft.set_left_plate(MOR_ft.get_left_plate())
				ridge_ft.set_right_plate(MOR_ft.get_right_plate())
				ridge_ft.set_name(parent_SuperGDUs_id)
				ridge_ft.set_description(str(index))
				list_of_ridges.append(ridge_ft)
				
				list_of_ordered_points_for_MOR.append(estimated_transform_point)
				list_of_ordered_points_for_MOR.append(current_geom)
				
				left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age, to_age))
				left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_name(parent_SuperGDUs_id)
				left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
				right_MOR_location_ft = left_MOR_location_ft.clone()
				right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
				
				left_transform_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_basic_rock_unit, estimated_transform_point, valid_time = (at_age, to_age))
				left_transform_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_name(parent_SuperGDUs_id)
				left_transform_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_transform_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_transform_location_ft)
				
				right_transform_location_ft = left_transform_location_ft.clone()
				right_transform_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_transform_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_transform_location_ft)
				
			
			index = index + 1
			previous_ft = MOR_ft
			previous_geom = reconstructed_geometry
	
	final_linear_for_entire_MOR = pygplates.PolylineOnSphere(list_of_ordered_points_for_MOR)
	final_linear_for_entire_MOR_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, final_linear_for_entire_MOR, valid_time = (at_age, to_age))
	final_linear_for_entire_MOR_ft.set_reconstruction_method('HalfStageRotationVersion2')
	final_linear_for_entire_MOR_ft.set_left_plate(MOR_ft.get_left_plate())
	final_linear_for_entire_MOR_ft.set_right_plate(MOR_ft.get_right_plate())
	final_linear_for_entire_MOR_ft.set_name(parent_SuperGDUs_id)
	final_linear_for_entire_MOR_ft.set_description(str(index))
	
	if (reference is not None):
		pygplates.reverse_reconstruct(final_linear_for_entire_MOR_ft, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(list_of_ridges, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(list_of_transforms, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(previous_MOR_transform_fts_collections, rotation_model, at_age, reference)
	else:
		pygplates.reverse_reconstruct(final_linear_for_entire_MOR_ft, rotation_model, at_age)
		pygplates.reverse_reconstruct(list_of_ridges, rotation_model, at_age)
		pygplates.reverse_reconstruct(list_of_transforms, rotation_model, at_age)
		pygplates.reverse_reconstruct(previous_MOR_transform_fts_collections, rotation_model, at_age)

	
	return (final_linear_for_entire_MOR_ft,list_of_ridges,list_of_transforms,list_of_ordered_points_for_MOR,previous_MOR_transform_fts_collections)

def create_MOR_feature_for_a_pair_of_SuperGDUs_only_2(list_of_reconstructed_ordered_MOR_locations_ft, at_age, threshold_degrees, rotation_model, reference, write_tmp):
	"""list of order MOR location ft: contains MOR location fts at age - not yet applied reverse_reconstruct - in the order from the maximum small circle angular degreee
		to the minimum"""
	previous_ft = None
	previous_geom = None
	list_of_ordered_points_for_MOR = []
	list_of_ridges = []
	list_of_transforms = []
	previous_MOR_transform_fts_collections = pygplates.FeatureCollection()
	index = 1
	for MOR_ft,reconstructed_geometry in list_of_reconstructed_ordered_MOR_locations_ft:
		if (previous_ft is None):
			previous_ft = MOR_ft
			list_of_ordered_points_for_MOR.append(reconstructed_geometry)
			previous_geom = reconstructed_geometry
			left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, previous_geom, valid_time = (at_age,0.00))
			left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_name(MOR_ft.get_name())
			left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
			left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
			left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
			right_MOR_location_ft = left_MOR_location_ft.clone()
			right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
			right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
		else:
			current_geom = reconstructed_geometry
			
			previous_x,previous_y,previous_z = previous_geom.to_xyz()
			current_x,current_y,current_z = current_geom.to_xyz()
			vector_from_previous_to_current = pygplates.Vector3D([(current_x-previous_x),(current_y-previous_y),(current_z-previous_z)])
			#convert vector_from_previous_to_current from geocentric coordinates to local coordinates with respected to previous_geom
			magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(previous_geom, vector_from_previous_to_current)
			azim_degrees = math.degrees(azimuth)
			if((azim_degrees <= threshold_degrees) or ((azim_degrees) >= (360.00 - threshold_degrees))):
				ridge_seg = pygplates.PolylineOnSphere([previous_geom,current_geom])
				list_of_ordered_points_for_MOR.append(current_geom)
				
				left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age,0.00))
				left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_name(MOR_ft.get_name())
				left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
				right_MOR_location_ft = left_MOR_location_ft.clone()
				right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
			else:
				previous_lat,previous_lon = previous_geom.to_lat_lon()
				current_lat,current_lon = current_geom.to_lat_lon()
				estimated_transform_point = pygplates.PointOnSphere((previous_lat,current_lon))
				
				trans_seg = pygplates.PolylineOnSphere([previous_geom,estimated_transform_point])
				#create transform_ft 
				transform_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, trans_seg, valid_time = (at_age,0.00))
				transform_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				transform_ft.set_conjugate_plate_id(MOR_ft.get_right_plate())
				transform_ft.set_name(MOR_ft.get_name())
				transform_ft.set_description(str(index))
				list_of_transforms.append(transform_ft)
				
				ridge_seg = pygplates.PolylineOnSphere([estimated_transform_point,current_geom])
				#create ridge_ft
				ridge_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, ridge_seg, valid_time = (at_age,0.00))
				ridge_ft.set_reconstruction_method('HalfStageRotationVersion2')
				ridge_ft.set_left_plate(MOR_ft.get_left_plate())
				ridge_ft.set_right_plate(MOR_ft.get_right_plate())
				ridge_ft.set_name(MOR_ft.get_name())
				ridge_ft.set_description(str(index))
				list_of_ridges.append(ridge_ft)
				
				list_of_ordered_points_for_MOR.append(estimated_transform_point)
				list_of_ordered_points_for_MOR.append(current_geom)
				
				left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_geom, valid_time = (at_age,0.00))
				left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_name(MOR_ft.get_name())
				left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_MOR_location_ft)
			
				right_MOR_location_ft = left_MOR_location_ft.clone()
				right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_MOR_location_ft)
				
				left_transform_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_basic_rock_unit, estimated_transform_point, valid_time = (at_age,0.00))
				left_transform_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_name(MOR_ft.get_name())
				left_transform_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_description(MOR_ft.get_description(),verify_information_model = pygplates.VerifyInformationModel.no)
				left_transform_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
				left_transform_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(left_transform_location_ft)
				
				right_transform_location_ft = left_transform_location_ft.clone()
				right_transform_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
				right_transform_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
				previous_MOR_transform_fts_collections.add(right_transform_location_ft)
				
			
			index = index + 1
			previous_ft = MOR_ft
			previous_geom = reconstructed_geometry
	
	final_linear_for_entire_MOR = pygplates.PolylineOnSphere(list_of_ordered_points_for_MOR)
	final_linear_for_entire_MOR_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, final_linear_for_entire_MOR, valid_time = (at_age,0.00))
	final_linear_for_entire_MOR_ft.set_reconstruction_method('HalfStageRotationVersion2')
	final_linear_for_entire_MOR_ft.set_left_plate(MOR_ft.get_left_plate())
	final_linear_for_entire_MOR_ft.set_right_plate(MOR_ft.get_right_plate())
	final_linear_for_entire_MOR_ft.set_name(MOR_ft.get_name())
	final_linear_for_entire_MOR_ft.set_description(str(index))
	
	if (reference is not None):
		pygplates.reverse_reconstruct(final_linear_for_entire_MOR_ft, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(list_of_ridges, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(list_of_transforms, rotation_model, at_age, reference)
		pygplates.reverse_reconstruct(previous_MOR_transform_fts_collections, rotation_model, at_age, reference)
	else:
		pygplates.reverse_reconstruct(final_linear_for_entire_MOR_ft, rotation_model, at_age)
		pygplates.reverse_reconstruct(list_of_ridges, rotation_model, at_age)
		pygplates.reverse_reconstruct(list_of_transforms, rotation_model, at_age)
		pygplates.reverse_reconstruct(previous_MOR_transform_fts_collections, rotation_model, at_age)
	# if (write_tmp == True):
		# temp_outputPointFeatureCollection = pygplates.FeatureCollection(final_linear_for_entire_MOR_ft)
		# temp_outputPointFeatureCollection.write("final_linear_for_entire_MOR_ft"+MOR_ft.get_name()+"_"+str(at_age)+".shp")
	
	# name = MOR_ft.get_name()
	# outputPointFeatureCollection = pygplates.FeatureCollection(list_of_ridges)
	# outputPointFeatureCollection.write("ridges_"+name+"_"+str(at_age)+".shp")
	# outputPointFeatureCollection_2 = pygplates.FeatureCollection(list_of_transforms)
	# outputPointFeatureCollection_2.write("transforms_"+name+"_"+str(at_age)+".shp")
	
	# previous_MOR_transform_fts_collections.write("previous_MOR_transform_fts_"+MOR_ft.get_name()+"_"+str(at_age)+".shp")
	
	return (final_linear_for_entire_MOR_ft,previous_MOR_transform_fts_collections)

def create_oceanic_crust_polygon_fts_at_age(at_age, to_age, list_of_reconstructed_points_from_div_margins, list_of_reconstructed_points_for_MOR, reconstruction_plate_id, left_plate_id, right_plate_id, left_or_right_side_rel_to_MOR, name, rotation_model, reference):
	oceanic_crust_ft = None
	print(type(list_of_reconstructed_points_from_div_margins),type(list_of_reconstructed_points_for_MOR))
	if (left_or_right_side_rel_to_MOR == 'left'):
		temporary_reversed_ordered_left_fts = [item for item in reversed(list_of_reconstructed_points_from_div_margins)]
		final_list_of_points = list_of_reconstructed_points_for_MOR + temporary_reversed_ordered_left_fts
		oceanic_polygon = pygplates.PolygonOnSphere(final_list_of_points)
		oceanic_crust_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, oceanic_polygon, valid_time = (at_age,to_age))
		oceanic_crust_ft.set_reconstruction_plate_id(reconstruction_plate_id)
		oceanic_crust_ft.set_name(name)
		oceanic_crust_ft.set_left_plate(left_plate_id,verify_information_model = pygplates.VerifyInformationModel.no)
		oceanic_crust_ft.set_right_plate(right_plate_id,verify_information_model = pygplates.VerifyInformationModel.no)
	elif (left_or_right_side_rel_to_MOR == 'right'):
		temporary_reversed_ordered_middle_fts = [item for item in reversed(list_of_reconstructed_points_for_MOR)]
		final_list_of_points = list_of_reconstructed_points_from_div_margins + temporary_reversed_ordered_middle_fts
		oceanic_polygon = pygplates.PolygonOnSphere(final_list_of_points)
		oceanic_crust_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, oceanic_polygon, valid_time = (at_age,to_age))
		oceanic_crust_ft.set_reconstruction_plate_id(reconstruction_plate_id)
		oceanic_crust_ft.set_name(name)
		oceanic_crust_ft.set_left_plate(left_plate_id,verify_information_model = pygplates.VerifyInformationModel.no)
		oceanic_crust_ft.set_right_plate(right_plate_id,verify_information_model = pygplates.VerifyInformationModel.no)
	
	if (reference is not None):
		pygplates.reverse_reconstruct(oceanic_crust_ft, rotation_model, at_age, reference)
	else:
		pygplates.reverse_reconstruct(oceanic_crust_ft, rotation_model, at_age)
	
	return oceanic_crust_ft

def create_oceanic_crust_polygon_fts_from_MOR_and_associated_div_margin_location_fts_within_period(oldest_age, youngest_age, age_interval, rotation_model, reference, modelname, yyyymmdd):
	dic_MOR = {}
	dic_margins = {}
	reconstructed_MOR_features = []
	reconstructed_left_div_fts = []
	reconstructed_right_div_fts = []
	output_oceanic_crust_fts = pygplates.FeatureCollection()
	output_temp_MOR_linear_fts = pygplates.FeatureCollection()
	output_temp_left_and_right_MOR_linear_fts = pygplates.FeatureCollection()
	at_age = oldest_age
	while (at_age > (youngest_age - age_interval)):
		print("at_age",at_age)
		filename_MOR_fts = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\MOR_location_ft_test_2_PalaeoPlatesNov2021_"+str(at_age)+"_20220715.shp"
		collection_all_MOR_fts = pygplates.FeatureCollection(filename_MOR_fts)
		for MOR_ft in collection_all_MOR_fts:
			if (MOR_ft.get_name() not in dic_MOR):
				dic_MOR[MOR_ft.get_name()] = [MOR_ft]
			else:
				dic_MOR[MOR_ft.get_name()].append(MOR_ft)
		if (at_age == oldest_age):
			filename_div_margin_fts = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\div_margin_location_ft_test_2_PalaeoPlatesNov2021_"+str(at_age)+"_20220715.shp"
			collection_all_div_margin_fts = pygplates.FeatureCollection(filename_div_margin_fts)
			for margin_ft in collection_all_div_margin_fts:
				left_id = margin_ft.get_left_plate()
				right_id = margin_ft.get_right_plate()
			
				rep_associated_MOR_ft = dic_MOR[margin_ft.get_name()][0]
				left_of_MOR = rep_associated_MOR_ft.get_left_plate()
				right_of_MOR = rep_associated_MOR_ft.get_right_plate()
			
				if (margin_ft.get_name() not in dic_margins):
					if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
						dic_margins[margin_ft.get_name()] = {"left":[margin_ft],"right":[]}
					elif (margin_ft.get_reconstruction_plate_id() == right_of_MOR):
						dic_margins[margin_ft.get_name()] = {"left":[],"right":[margin_ft]}
				else:
					if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
						dic_margins[margin_ft.get_name()]["left"].append(margin_ft)
					elif (margin_ft.get_reconstruction_plate_id() == right_of_MOR):
						dic_margins[margin_ft.get_name()]["right"].append(margin_ft)
		else:
			# filename_div_margin_fts = r"MOR_location_ft_test_21_SAM_NAM_PalaeoPlatesNov2021_"+str(at_age + age_interval)+"_20220308.shp"
			# collection_all_div_margin_fts = pygplates.FeatureCollection(filename_div_margin_fts)
			# for margin_ft in collection_all_div_margin_fts:
				# left_id = margin_ft.get_left_plate()
				# right_id = margin_ft.get_right_plate()
			
				# # rep_associated_MOR_ft = dic_MOR[margin_ft.get_name()][0]
				# # left_of_MOR = rep_associated_MOR_ft.get_left_plate()
				# # right_of_MOR = rep_associated_MOR_ft.get_right_plate()
				# temp_left_of_MOR,temp_right_of_MOR = margin_ft.get_name().split('_')
				# left_of_MOR = int(temp_left_of_MOR)
				# right_of_MOR = int(temp_right_of_MOR)
				
				# left_margin = margin_ft.get_geometry()
				# left_margin_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, left_margin, valid_time = margin_ft.get_valid_time())
				# left_margin_ft.set_reconstruction_plate_id(left_of_MOR)
				# left_margin_ft.set_left_plate(left_of_MOR,verify_information_model = pygplates.VerifyInformationModel.no)
				# left_margin_ft.set_right_plate(right_of_MOR,verify_information_model = pygplates.VerifyInformationModel.no)
				# left_margin_ft.set_description(margin_ft.get_description())
				# left_margin_ft.set_name(margin_ft.get_name())
				# #left_margin_ft.set_reconstruction_method('ByPlateId')
				# right_margin = margin_ft.get_geometry()
				# right_margin_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, right_margin, valid_time = margin_ft.get_valid_time())
				# right_margin_ft.set_reconstruction_plate_id(right_of_MOR)
				# right_margin_ft.set_left_plate(left_of_MOR,verify_information_model = pygplates.VerifyInformationModel.no)
				# right_margin_ft.set_right_plate(right_of_MOR,verify_information_model = pygplates.VerifyInformationModel.no)
				# right_margin_ft.set_description(margin_ft.get_description())
				# right_margin_ft.set_name(margin_ft.get_name())
				# #right_margin_ft.set_reconstruction_method('ByPlateId')
			
				# if (margin_ft.get_name() not in dic_margins):
					# dic_margins[margin_ft.get_name()] = {"left":[left_margin_ft],"right":[right_margin_ft]}
				# else:
					# dic_margins[margin_ft.get_name()]["left"].append(left_margin_ft)
					# dic_margins[margin_ft.get_name()]["right"].append(right_margin_ft)
			for name in dic_MOR.keys():
				path_to_filename_div_margin_fts = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\previous_MOR_transform_fts_"+name+"_"+str(at_age+age_interval)+".shp"
				print(path_to_filename_div_margin_fts)
				print(os.path.exists(path_to_filename_div_margin_fts))
				if (os.path.exists(path_to_filename_div_margin_fts)):
					collection_all_div_margin_fts = pygplates.FeatureCollection(path_to_filename_div_margin_fts)
					for margin_ft in collection_all_div_margin_fts:
						left_id = margin_ft.get_left_plate()
						right_id = margin_ft.get_right_plate()
			
						# rep_associated_MOR_ft = dic_MOR[margin_ft.get_name()][0]
						# left_of_MOR = rep_associated_MOR_ft.get_left_plate()
						# right_of_MOR = rep_associated_MOR_ft.get_right_plate()
						temp_left_of_MOR,temp_right_of_MOR = margin_ft.get_name().split('_')
						left_of_MOR = int(temp_left_of_MOR)
						right_of_MOR = int(temp_right_of_MOR)
				
						# left_margin = margin_ft.get_geometry()
						# left_margin_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, left_margin, valid_time = (at_age+age_interval, 0.00))
						# #left_margin_ft.set_reconstruction_plate_id(left_of_MOR)
						# left_margin_ft.set_left_plate(left_of_MOR,verify_information_model = pygplates.VerifyInformationModel.no)
						# left_margin_ft.set_right_plate(right_of_MOR,verify_information_model = pygplates.VerifyInformationModel.no)
						# left_margin_ft.set_description(margin_ft.get_description())
						# left_margin_ft.set_name(margin_ft.get_name())
						# #left_margin_ft.set_reconstruction_method('ByPlateId')
						# right_margin = margin_ft.get_geometry()
						# right_margin_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, right_margin, valid_time = (at_age+age_interval, 0.00))
						# #right_margin_ft.set_reconstruction_plate_id(right_of_MOR)
						# right_margin_ft.set_left_plate(left_of_MOR,verify_information_model = pygplates.VerifyInformationModel.no)
						# right_margin_ft.set_right_plate(right_of_MOR,verify_information_model = pygplates.VerifyInformationModel.no)
						# right_margin_ft.set_description(margin_ft.get_description())
						# right_margin_ft.set_name(margin_ft.get_name())
						#right_margin_ft.set_reconstruction_method('ByPlateId')
			
						if (margin_ft.get_name() not in dic_margins):
							if (margin_ft.get_reconstruction_plate_id() == margin_ft.get_left_plate()):
								dic_margins[margin_ft.get_name()] = {"left":[margin_ft.clone()],"right":[]}
							elif (margin_ft.get_reconstruction_plate_id() == margin_ft.get_right_plate()):
								dic_margins[margin_ft.get_name()] = {"left":[],"right":[margin_ft.clone()]}
						else:
							if (margin_ft.get_reconstruction_plate_id() == margin_ft.get_left_plate()):
								dic_margins[margin_ft.get_name()]["left"].append(margin_ft.clone())
							elif (margin_ft.get_reconstruction_plate_id() == margin_ft.get_right_plate()):
								dic_margins[margin_ft.get_name()]["right"].append(margin_ft.clone())

		for name in dic_MOR.keys():
			list_of_MOR_fts = dic_MOR[name]
			list_of_left_div_margin_fts = None
			list_of_right_div_margin_fts = None
			is_there_previous_MOR = False
			if (name in dic_margins):
				print(margin_ft.get_name())
				list_of_left_div_margin_fts = dic_margins[name]["left"]
				list_of_right_div_margin_fts = dic_margins[name]["right"]
				is_there_previous_MOR = True
			else:
				filename_div_margin_fts = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\div_margin_location_ft_test_2_PalaeoPlatesNov2021_"+str(at_age)+"_20220715.shp"
				collection_all_div_margin_fts = pygplates.FeatureCollection(filename_div_margin_fts)
				temp_left_of_MOR,temp_right_of_MOR = name.split('_')
				left_of_MOR = int(temp_left_of_MOR)
				right_of_MOR = int(temp_right_of_MOR)
				for margin_ft in collection_all_div_margin_fts:
					if (margin_ft.get_name() == name):
						if (name not in dic_margins):
							if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
								dic_margins[margin_ft.get_name()] = {"left":[margin_ft],"right":[]}
							elif (margin_ft.get_reconstruction_plate_id() == right_of_MOR):
								dic_margins[margin_ft.get_name()] = {"left":[],"right":[margin_ft]}
						else:
							if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
								dic_margins[margin_ft.get_name()]["left"].append(margin_ft)
							elif (margin_ft.get_reconstruction_plate_id() == right_of_MOR):
								dic_margins[margin_ft.get_name()]["right"].append(margin_ft)
				list_of_left_div_margin_fts = dic_margins[name]["left"]
				list_of_right_div_margin_fts = dic_margins[name]["right"]

			print("len(list_of_left_div_margin_fts)",len(list_of_left_div_margin_fts))
			storage_lists_of_ordered_MOR_fts = create_list_of_ordered_MOR_or_div_locations_fts(list_of_MOR_fts, 1.00, "desc",False)
			print("len(storage_lists_of_ordered_MOR_fts)",len(storage_lists_of_ordered_MOR_fts))
			is_ridge_and_transform = False
			if (at_age < oldest_age and is_there_previous_MOR == True):
				is_ridge_and_transform = True
			if (len(storage_lists_of_ordered_MOR_fts) > 1): 
				for list_of_ordered_MOR_fts in storage_lists_of_ordered_MOR_fts:
					list_of_order_MOR = []
					list_of_ordered_left_div_margin_fts = [] 
					list_of_ordered_right_div_margin_fts = []
					reconstructed_left_div_fts = []
					reconstructed_right_div_fts = []
					reconstructed_MOR_features = []
					for order_MOR_ft in list_of_ordered_MOR_fts:
						list_of_order_MOR.append(float(order_MOR_ft.get_description()))
					
					storage_lists_of_order_left_div_margin_fts,list_of_unfound_order = create_list_of_ordered_div_locations_fts(list_of_left_div_margin_fts, list_of_order_MOR, is_ridge_and_transform)
					print("len(storage_lists_of_order_left_div_margin_fts)",len(storage_lists_of_order_left_div_margin_fts))
					storage_lists_of_order_right_div_margin_fts,list_of_unfound_order = create_list_of_ordered_div_locations_fts(list_of_right_div_margin_fts, list_of_order_MOR, is_ridge_and_transform)
					if (len(storage_lists_of_order_left_div_margin_fts) >= 1 and len(storage_lists_of_order_right_div_margin_fts) >= 1):
						list_of_ordered_left_div_margin_fts = storage_lists_of_order_left_div_margin_fts[0]
						print("list_of_ordered_left_div_margin_fts",list_of_ordered_left_div_margin_fts)
						list_of_ordered_right_div_margin_fts = storage_lists_of_order_right_div_margin_fts[0]
						print("list_of_ordered_right_div_margin_fts",list_of_ordered_right_div_margin_fts)
					else:
						#have to read the div margin ft 
						temp_left_fts = []
						temp_right_fts = []
						filename_div_margin_fts = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\div_margin_location_ft_test_2_PalaeoPlatesNov2021_"+str(at_age)+"_20220715.shp"
						collection_all_div_margin_fts = pygplates.FeatureCollection(filename_div_margin_fts)
						temp_left_of_MOR,temp_right_of_MOR = name.split('_')
						left_of_MOR = int(temp_left_of_MOR)
						right_of_MOR = int(temp_right_of_MOR)
						for margin_ft in collection_all_div_margin_fts:
							if (margin_ft.get_name() == name):
								if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
									temp_left_fts.append(margin_ft)
								elif (margin_ft.get_reconstruction_plate_id() == right_of_MOR):
									temp_right_fts.append(margin_ft)
						for wanted_order in list_of_unfound_order:
							for margin_ft in temp_left_fts:
								if (float(margin_ft.get_description()) == wanted_order):
									list_of_ordered_left_div_margin_fts.append(margin_ft)
									break
							for margin_ft in temp_right_fts:
								if (float(margin_ft.get_description()) == wanted_order):
									list_of_ordered_right_div_margin_fts.append(margin_ft)
									break
					
					print("list_of_ordered_left_div_margin_fts",list_of_ordered_left_div_margin_fts)
					print("list_of_ordered_right_div_margin_fts",list_of_ordered_right_div_margin_fts)
					if (reference is not None):
						pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,at_age,anchor_plate_id = reference, group_with_feature = True)
						pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
						pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
					else:
						pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,at_age,group_with_feature = True)
						pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
						pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				
					final_reconstructed_MOR_fts = supporting.find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
					final_reconstructed_left_fts = supporting.find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PointOnSphere)
					final_reconstructed_right_fts = supporting.find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PointOnSphere)
				
					MOR_features,reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
					div_left_features,reconstructed_div_left_points = zip(*final_reconstructed_left_fts)
					div_right_features,reconstructed_div_right_points = zip(*final_reconstructed_right_fts)
			
					left_plate_id = MOR_features[0].get_left_plate()
					right_plate_id = MOR_features[0].get_right_plate()
			
					if (len(final_reconstructed_MOR_fts) > 1):
						final_list_of_points_for_MOR,temp_linear_MOR_ft,left_linear_MOR_ft,right_linear_MOR_ft = create_MOR_feature_for_a_pair_of_SuperGDUs_only(final_reconstructed_MOR_fts, at_age, 10.00, rotation_model, reference, True)
				
						output_temp_MOR_linear_fts.add(temp_linear_MOR_ft)
						output_temp_left_and_right_MOR_linear_fts.add(left_linear_MOR_ft)
						output_temp_left_and_right_MOR_linear_fts.add(right_linear_MOR_ft)
						left_oceanic_crust_ft = create_oceanic_crust_polygon_fts_at_age(at_age, 0.00, list(reconstructed_div_left_points), final_list_of_points_for_MOR,\
										left_plate_id, left_plate_id, right_plate_id, "left", name, rotation_model, reference)
						right_oceanic_crust_ft = create_oceanic_crust_polygon_fts_at_age(at_age, 0.00, list(reconstructed_div_right_points), final_list_of_points_for_MOR,\
										right_plate_id, left_plate_id, right_plate_id, "right", name, rotation_model, reference)
						output_oceanic_crust_fts.add(left_oceanic_crust_ft)
						output_oceanic_crust_fts.add(right_oceanic_crust_ft)
			elif (len(storage_lists_of_ordered_MOR_fts) == 1):
				list_of_ordered_MOR_fts = storage_lists_of_ordered_MOR_fts[0]
				list_of_order_MOR = []
				list_of_ordered_left_div_margin_fts = [] 
				list_of_ordered_right_div_margin_fts = []
				reconstructed_left_div_fts = []
				reconstructed_right_div_fts = []
				reconstructed_MOR_features = []
				for order_MOR_ft in list_of_ordered_MOR_fts:
					list_of_order_MOR.append(float(order_MOR_ft.get_description()))
				
				storage_lists_of_order_left_div_margin_fts,list_of_unfound_order = create_list_of_ordered_div_locations_fts(list_of_left_div_margin_fts, list_of_order_MOR, is_ridge_and_transform)
				print("len(storage_lists_of_order_left_div_margin_fts)",len(storage_lists_of_order_left_div_margin_fts))
				storage_lists_of_order_right_div_margin_fts,list_of_unfound_order = create_list_of_ordered_div_locations_fts(list_of_right_div_margin_fts, list_of_order_MOR, is_ridge_and_transform)
				print("len(storage_lists_of_order_right_div_margin_fts)",len(storage_lists_of_order_right_div_margin_fts))
				if (len(storage_lists_of_order_left_div_margin_fts) == 1 and len(storage_lists_of_order_right_div_margin_fts) == 1):
					print("enter this condition")
					list_of_ordered_left_div_margin_fts = storage_lists_of_order_left_div_margin_fts[0]
					list_of_ordered_right_div_margin_fts = storage_lists_of_order_right_div_margin_fts[0]
				elif (len(storage_lists_of_order_left_div_margin_fts) > 1 and len(storage_lists_of_order_right_div_margin_fts) > 1):
					#have to read the div margin ft 
					temp_dic = {}
					temp_left_fts = []
					temp_right_fts = []
					filename_div_margin_fts = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\div_margin_location_ft_test_2_PalaeoPlatesNov2021_"+str(at_age)+"_20220715.shp"
					collection_all_div_margin_fts = pygplates.FeatureCollection(filename_div_margin_fts)
					temp_left_of_MOR,temp_right_of_MOR = name.split('_')
					left_of_MOR = int(temp_left_of_MOR)
					right_of_MOR = int(temp_right_of_MOR)
					for margin_ft in collection_all_div_margin_fts:
						if (margin_ft.get_name() == name):
							if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
								temp_left_fts.append(margin_ft)
							elif (margin_ft.get_reconstruction_plate_id() == right_of_MOR):
								temp_right_fts.append(margin_ft)
					for list_of_margin_fts in storage_lists_of_order_left_div_margin_fts:
						for margin_ft in list_of_margin_fts:
							if (margin_ft.get_name() == name):
								if (margin_ft.get_description() not in temp_dic):
									if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
										temp_dic[margin_ft.get_description()] = {'left':margin_ft,'right':None}
								else:
									if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
										temp_dic[margin_ft.get_description()]['left'] = margin_ft
					for list_of_margin_fts in storage_lists_of_order_right_div_margin_fts:
						for margin_ft in list_of_margin_fts:
							if (margin_ft.get_name() == name):
								if (margin_ft.get_reconstruction_plate_id() == right_of_MOR):
									temp_dic[margin_ft.get_description()]['right'] = margin_ft
					for wanted_order in list_of_order_MOR:
						if (str(wanted_order) in temp_dic):
							previous_left_margin_ft = temp_dic[str(wanted_order)]['left']
							previous_right_margin_ft = temp_dic[str(wanted_order)]['right']
							list_of_ordered_left_div_margin_fts.append(previous_left_margin_ft)
							list_of_ordered_right_div_margin_fts.append(previous_right_margin_ft)
						else:
							for sub_margin_ft in temp_left_fts:
								if (float(sub_margin_ft.get_description()) == wanted_order):
									list_of_ordered_left_div_margin_fts.append(sub_margin_ft)
									break
							for sub_margin_ft in temp_right_fts:		
								if (float(sub_margin_ft.get_description()) == wanted_order):
									list_of_ordered_right_div_margin_fts.append(sub_margin_ft)
									break
				elif (len(storage_lists_of_order_left_div_margin_fts) == 0 and len(storage_lists_of_order_right_div_margin_fts) == 0):
					#have to read the div margin ft 
					temp_left_fts = []
					temp_right_fts = []
					filename_div_margin_fts = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\temp_MOR_div_features\div_margin_location_ft_test_2_PalaeoPlatesNov2021_"+str(at_age)+"_20220715.shp"
					collection_all_div_margin_fts = pygplates.FeatureCollection(filename_div_margin_fts)
					temp_left_of_MOR,temp_right_of_MOR = name.split('_')
					left_of_MOR = int(temp_left_of_MOR)
					right_of_MOR = int(temp_right_of_MOR)
					for margin_ft in collection_all_div_margin_fts:
						if (margin_ft.get_name() == name):
							if (margin_ft.get_reconstruction_plate_id() == left_of_MOR):
								temp_left_fts.append(margin_ft)
							elif (margin_ft.get_reconstruction_plate_id() == right_of_MOR):
								temp_right_fts.append(margin_ft)
					for wanted_order in list_of_unfound_order:
						for margin_ft in temp_left_fts:
							if (float(margin_ft.get_description()) == wanted_order):
								list_of_ordered_left_div_margin_fts.append(margin_ft)
								break
						for margin_ft in temp_right_fts:
							if (float(margin_ft.get_description()) == wanted_order):
								list_of_ordered_right_div_margin_fts.append(margin_ft)
								break
				print("list_of_ordered_left_div_margin_fts",list_of_ordered_left_div_margin_fts)
				print("list_of_ordered_right_div_margin_fts",list_of_ordered_right_div_margin_fts)
				if (reference is not None):
					pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,at_age,anchor_plate_id = reference, group_with_feature = True)
					pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
					pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,at_age,group_with_feature = True)
					pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,at_age, group_with_feature = True)
					pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,at_age, group_with_feature = True)
				
				final_reconstructed_MOR_fts = supporting.find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
				final_reconstructed_left_fts = supporting.find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PointOnSphere)
				final_reconstructed_right_fts = supporting.find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PointOnSphere)
				
				MOR_features,reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
				div_left_features,reconstructed_div_left_points = zip(*final_reconstructed_left_fts)
				div_right_features,reconstructed_div_right_points = zip(*final_reconstructed_right_fts)
			
				left_plate_id = MOR_features[0].get_left_plate()
				right_plate_id = MOR_features[0].get_right_plate()
			
				if (len(final_reconstructed_MOR_fts) > 1):
					final_list_of_points_for_MOR,temp_linear_MOR_ft,left_linear_MOR_ft,right_linear_MOR_ft = create_MOR_feature_for_a_pair_of_SuperGDUs_only(final_reconstructed_MOR_fts, at_age, 10.00, rotation_model, reference, True)
				
					output_temp_MOR_linear_fts.add(temp_linear_MOR_ft)
					output_temp_left_and_right_MOR_linear_fts.add(left_linear_MOR_ft)
					output_temp_left_and_right_MOR_linear_fts.add(right_linear_MOR_ft)
					left_oceanic_crust_ft = create_oceanic_crust_polygon_fts_at_age(at_age, 0.00, list(reconstructed_div_left_points), final_list_of_points_for_MOR,\
										left_plate_id, left_plate_id, right_plate_id, "left", name, rotation_model, reference)
					right_oceanic_crust_ft = create_oceanic_crust_polygon_fts_at_age(at_age, 0.00, list(reconstructed_div_right_points), final_list_of_points_for_MOR,\
										right_plate_id, left_plate_id, right_plate_id, "right", name, rotation_model, reference)
					output_oceanic_crust_fts.add(left_oceanic_crust_ft)
					output_oceanic_crust_fts.add(right_oceanic_crust_ft)
		dic_MOR.clear()
		dic_margins.clear()
		at_age = at_age - age_interval
	print ("output_oceanic_crust_fts",output_oceanic_crust_fts)
	#output_oceanic_crust_fts.write("output_oceanic_crust_fts_"+modelname+"_"+str(oldest_age)+"_"+str(youngest_age)+"_"+yyyymmdd+".shp")
	output_temp_MOR_linear_fts.write("output_temp_MOR_linear_fts_"+modelname+"_"+str(oldest_age)+"_"+str(youngest_age)+"_"+yyyymmdd+".shp")
	output_temp_left_and_right_MOR_linear_fts.write("output_temp_left_and_right_MOR_linear_fts_"+modelname+"_"+str(oldest_age)+"_"+str(youngest_age)+"_"+yyyymmdd+".shp")
	

def refine_end_age_for_temporal_linear_MOR_feature(linear_MOR_features,interval_of_time_when_evaluated_motion,modelname,yearmonthday):
	dic_summary = {}
	output_MOR_ft = pygplates.FeatureCollection()
	for linear_MOR_ft in linear_MOR_features:
		feature_name = linear_MOR_ft.get_name()
		from_time,_ = linear_MOR_ft.get_valid_time()
		if (feature_name in dic_summary):
			dic_summary[feature_name].append((from_time,linear_MOR_ft))
		else:
			dic_summary[feature_name] = [(from_time,linear_MOR_ft)]
	for key in dic_summary:
		list_of_MOR_fts_and_from_time = dic_summary[key]
		list_of_MOR_fts_and_from_time.sort(reverse = True)
		number_of_fts = len(list_of_MOR_fts_and_from_time)
		print('number_of_fts',number_of_fts)
		youngest_ft = None
		for m in range(0,number_of_fts - 1):
			older_time,older_ft = list_of_MOR_fts_and_from_time[m]
			n = m + 1
			yng_time,yng_ft = list_of_MOR_fts_and_from_time[n]
			print("older_time",older_time,"yng_time",yng_time)
			print("m",m,'n',n)
			print(older_ft.get_valid_time())
			print(yng_ft.get_valid_time())
			if (older_time > yng_time):
				older_ft.set_valid_time(older_time,yng_time + (interval_of_time_when_evaluated_motion*0.100))
				output_MOR_ft.add(older_ft)
			#print("n",n)
			
			if (n == (number_of_fts - 1)):
				youngest_ft = yng_ft
			print("yng_ft",youngest_ft)
		if (number_of_fts > 1):
			#print('youngest_ft',youngest_ft)
			output_MOR_ft.add(youngest_ft)
		else:
			older_time,older_ft = list_of_MOR_fts_and_from_time[0]
			output_MOR_ft.add(older_ft)
	output_MOR_ft.write("refine_end_age_for_temporal_linear_MOR_features_"+modelname+"_"+yearmonthday+".shp")
	output_MOR_ft.write("refine_end_age_for_temporal_linear_MOR_features_"+modelname+"_"+yearmonthday+".gpml")

def subdivide_temporal_linear_MOR_ft_whenever_it_crosses_any_continental_polygon_feat(temporal_linear_MOR_features,continental_polygon_features,rotation_model,reference,modelname,yearmonthday):
	output_subdivide_linear_MOR_ft = pygplates.FeatureCollection()
	reconstructed_line_features = []
	reconstructed_polygon_features = []
	list_of_tuples = []
	output_point_MOR_ft = pygplates.FeatureCollection()
	for long_MOR_ft in temporal_linear_MOR_features:
		reconstructed_line_features[:] = []
		reconstructed_polygon_features[:] = []
		list_of_tuples[:] = []
		#ger valid time to then reconstruct MOR_ft to from_time
		from_time,to_time = long_MOR_ft.get_valid_time()
		if (reference is not None):
			pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_line_features,from_time,anchor_plate_id = reference,group_with_feature = True)
		else:
			pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_line_features,from_time,group_with_feature = True)
		final_reconstructed_MOR_ft = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
		initial_MOR_ft,long_MOR_line = final_reconstructed_MOR_ft[0]
		if (reference is not None):
			pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,from_time,anchor_plate_id = reference,group_with_feature = True)
		else:
			pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,from_time,group_with_feature = True)
		final_reconstructed_polygon_feats = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
		for continental_ft,polygon in final_reconstructed_polygon_feats:
			dist_rads = pygplates.GeometryOnSphere.distance(polygon,long_MOR_line)
			dist_kms = dist_rads * pygplates.Earth.equatorial_radius_in_kms
			if (dist_kms <= 1500.00):
				list_of_tuples.append((dist_kms,polygon,continental_ft))
		#sort the list by distance
		list_of_tuples.sort()
		num_of_points = len(long_MOR_line)
		current_list_of_pts = []
		for i in range(0, num_of_points-1):
			j = i + 1
			start_pt = long_MOR_line[i]
			if (len(current_list_of_pts) == 0):
				current_list_of_pts.append(start_pt)
			end_pt = long_MOR_line[j]
			temporal_line_segment = pygplates.PolylineOnSphere([start_pt,end_pt])
			already_subdivided = False
			for _,polygon,_ in list_of_tuples:
				if (polygon.partition(temporal_line_segment) != pygplates.PolygonOnSphere.PartitionResult.outside):
					if (len(current_list_of_pts) > 1):
						new_line_geometry = pygplates.PolylineOnSphere(current_list_of_pts)
						clone_MOR_ft = initial_MOR_ft.clone()
						clone_MOR_ft.set_geometry(new_line_geometry)
						if (reference is not None):
							pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,from_time,reference)
						else:
							pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,from_time)
						output_subdivide_linear_MOR_ft.add(clone_MOR_ft)
					current_list_of_pts[:] = []
					already_subdivided = True
					
					pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, end_pt, valid_time = initial_MOR_ft.get_valid_time())
					pt_ft.set_name(initial_MOR_ft.get_name())
					pt_ft.set_description(initial_MOR_ft.get_description())
					pt_ft.set_left_plate(initial_MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
					pt_ft.set_right_plate(initial_MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
					pt_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
					if (reference is not None):
						pygplates.reverse_reconstruct(pt_ft,rotation_model,from_time,reference)
					else:
						pygplates.reverse_reconstruct(pt_ft,rotation_model,from_time)
					output_point_MOR_ft.add(pt_ft)
					break
			if (already_subdivided == False):
				current_list_of_pts.append(end_pt)
		if (len(current_list_of_pts) > 1):
			new_line_geometry = pygplates.PolylineOnSphere(current_list_of_pts)
			clone_MOR_ft = initial_MOR_ft.clone()
			clone_MOR_ft.set_geometry(new_line_geometry)
			if (reference is not None):
				pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,from_time,reference)
			else:
				pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,from_time)
			output_subdivide_linear_MOR_ft.add(clone_MOR_ft)
		elif (len(current_list_of_pts) == 1):
			pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_list_of_pts[0], valid_time = initial_MOR_ft.get_valid_time())
			pt_ft.set_name(initial_MOR_ft.get_name())
			pt_ft.set_description(initial_MOR_ft.get_description())
			pt_ft.set_left_plate(initial_MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			pt_ft.set_right_plate(initial_MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			pt_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
			if (reference is not None):
				pygplates.reverse_reconstruct(pt_ft,rotation_model,from_time,reference)
			else:
				pygplates.reverse_reconstruct(pt_ft,rotation_model,from_time)
			output_point_MOR_ft.add(pt_ft)
	output_subdivide_linear_MOR_ft.write("subdivide_temporal_linear_MOR_ft_"+modelname+"_"+yearmonthday+".shp")
	output_subdivide_linear_MOR_ft.write("subdivide_temporal_linear_MOR_ft_"+modelname+"_"+yearmonthday+".gpml")
	
	output_point_MOR_ft.write("not_connected_point_MOR_ft_"+modelname+"_"+yearmonthday+".shp")
	output_point_MOR_ft.write("not_connected_point_MOR_ft_"+modelname+"_"+yearmonthday+".gpml")

def subdivide_temporal_left_and_right_prev_MOR_ft_whenever_it_crosses_any_continental_polygon_feat(temporal_left_and_right_from_prev_MOR_features,continental_polygon_features,rotation_model,reference,modelname,yearmonthday):
	output_subdivide_linear_MOR_ft = pygplates.FeatureCollection()
	reconstructed_line_features = []
	reconstructed_polygon_features = []
	list_of_tuples = []
	output_point_MOR_ft = pygplates.FeatureCollection()
	for long_MOR_ft in temporal_left_and_right_from_prev_MOR_features:
		reconstructed_line_features[:] = []
		reconstructed_polygon_features[:] = []
		list_of_tuples[:] = []
		#ger valid time to then reconstruct MOR_ft to from_time
		from_time,to_time = long_MOR_ft.get_valid_time()
		if (reference is not None):
			pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_line_features,from_time,anchor_plate_id = reference,group_with_feature = True)
		else:
			pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_line_features,from_time,group_with_feature = True)
		final_reconstructed_MOR_ft = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
		initial_MOR_ft,long_MOR_line = final_reconstructed_MOR_ft[0]
		if (reference is not None):
			pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,from_time,anchor_plate_id = reference,group_with_feature = True)
		else:
			pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,from_time,group_with_feature = True)
		final_reconstructed_polygon_feats = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
		for continental_ft,polygon in final_reconstructed_polygon_feats:
			dist_rads = pygplates.GeometryOnSphere.distance(polygon,long_MOR_line)
			dist_kms = dist_rads * pygplates.Earth.equatorial_radius_in_kms
			if (dist_kms <= 1500.00):
				list_of_tuples.append((dist_kms,polygon,continental_ft))
		#sort the list by distance
		list_of_tuples.sort()
		num_of_points = len(long_MOR_line)
		current_list_of_pts = []
		for i in range(0, num_of_points-1):
			j = i + 1
			start_pt = long_MOR_line[i]
			if (len(current_list_of_pts) == 0):
				current_list_of_pts.append(start_pt)
			end_pt = long_MOR_line[j]
			temporal_line_segment = pygplates.PolylineOnSphere([start_pt,end_pt])
			already_subdivided = False
			for _,polygon,_ in list_of_tuples:
				if (polygon.partition(temporal_line_segment) != pygplates.PolygonOnSphere.PartitionResult.outside):
					if (len(current_list_of_pts) > 1):
						new_line_geometry = pygplates.PolylineOnSphere(current_list_of_pts)
						clone_MOR_ft = initial_MOR_ft.clone()
						clone_MOR_ft.set_geometry(new_line_geometry)
						if (reference is not None):
							pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,from_time,reference)
						else:
							pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,from_time)
						output_subdivide_linear_MOR_ft.add(clone_MOR_ft)
					current_list_of_pts[:] = []
					already_subdivided = True
					
					pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, end_pt, valid_time = initial_MOR_ft.get_valid_time())
					pt_ft.set_name(initial_MOR_ft.get_name())
					pt_ft.set_description(initial_MOR_ft.get_description())
					pt_ft.set_left_plate(initial_MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
					pt_ft.set_right_plate(initial_MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
					pt_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
					pt_ft.set_reconstruction_plate_id(initial_MOR_ft.get_reconstruction_plate_id(),)
					pt_ft.set_conjugate_plate_id(initial_MOR_ft.get_conjugate_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
					if (reference is not None):
						pygplates.reverse_reconstruct(pt_ft,rotation_model,from_time,reference)
					else:
						pygplates.reverse_reconstruct(pt_ft,rotation_model,from_time)
					output_point_MOR_ft.add(pt_ft)
					break
			if (already_subdivided == False):
				current_list_of_pts.append(end_pt)
		if (len(current_list_of_pts) > 1):
			new_line_geometry = pygplates.PolylineOnSphere(current_list_of_pts)
			clone_MOR_ft = initial_MOR_ft.clone()
			clone_MOR_ft.set_geometry(new_line_geometry)
			if (reference is not None):
				pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,from_time,reference)
			else:
				pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,from_time)
			output_subdivide_linear_MOR_ft.add(clone_MOR_ft)
		elif (len(current_list_of_pts) == 1):
			pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_list_of_pts[0], valid_time = initial_MOR_ft.get_valid_time())
			pt_ft.set_name(initial_MOR_ft.get_name())
			pt_ft.set_description(initial_MOR_ft.get_description())
			pt_ft.set_left_plate(initial_MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			pt_ft.set_right_plate(initial_MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
			pt_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
			pt_ft.set_reconstruction_plate_id(initial_MOR_ft.get_reconstruction_plate_id())
			pt_ft.set_conjugate_plate_id(initial_MOR_ft.get_conjugate_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
			if (reference is not None):
				pygplates.reverse_reconstruct(pt_ft,rotation_model,from_time,reference)
			else:
				pygplates.reverse_reconstruct(pt_ft,rotation_model,from_time)
			output_point_MOR_ft.add(pt_ft)
	output_subdivide_linear_MOR_ft.write("temporal_left_and_right_prev_MOR_ft_"+modelname+"_"+yearmonthday+".shp")
	output_subdivide_linear_MOR_ft.write("temporal_left_and_right_prev_MOR_ft_"+modelname+"_"+yearmonthday+".gpml")
	
	output_point_MOR_ft.write("not_connected_point_left_or_right_from_prev_MOR_ft_"+modelname+"_"+yearmonthday+".shp")
	output_point_MOR_ft.write("not_connected_point_left_or_right_from_prev_MOR_ft_"+modelname+"_"+yearmonthday+".gpml")

def subdivide_temporal_linear_MOR_ft_when_crosses_polygon_feat_and_refine_end_age(temp_refined_end_age_and_subdivided_linear_MOR_features,continental_polygon_features,rotation_model,reference,interval_of_time_when_evaluated_motion,modelname,yearmonthday):
	output_subdivide_linear_MOR_ft = pygplates.FeatureCollection()
	reconstructed_line_features = []
	reconstructed_polygon_features = []
	current_list_of_pts = []
	list_of_tuples = []
	output_point_MOR_ft = pygplates.FeatureCollection()
	for long_MOR_ft in temp_refined_end_age_and_subdivided_linear_MOR_features:
		#get valid time to then reconstruct MOR_ft to to_time - keep in mind duration of MOR feature is about one time interval when we evaluate tectonic motion initially, i.e 5Ma
		#but to_time can also be equal to 0.00 - so we have two cases and we only focus on to_time == 0.00 cases
		from_time,to_time = long_MOR_ft.get_valid_time()
		if (to_time <= 0.00):
			if (to_time < 0.00):
				to_time = 0.00
			#because we already evaludated and subdivided when reconstruction_time == from_time
			reconstruction_time = from_time - interval_of_time_when_evaluated_motion
			while (reconstruction_time >= to_time):
				reconstructed_line_features[:] = []
				reconstructed_polygon_features[:] = []
				list_of_tuples[:] = []
				if (reference is not None):
					pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
				else:
					pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_polygon_feats = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
				
				if (reconstruction_time <= (from_time - interval_of_time_when_evaluated_motion)): # I am not sure how the results look like if we have segment of MOR features in short duration
					if (reference is not None):
						pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
					else:
						pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
					final_reconstructed_MOR_ft = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
					initial_MOR_ft,long_MOR_line = final_reconstructed_MOR_ft[0]
					for continental_ft,polygon in final_reconstructed_polygon_feats:
						dist_rads = pygplates.GeometryOnSphere.distance(polygon,long_MOR_line)
						dist_kms = dist_rads * pygplates.Earth.equatorial_radius_in_kms
						if (dist_kms <= 1500.00):
							list_of_tuples.append((dist_kms,polygon,continental_ft))
					#sort the list by distance
					list_of_tuples.sort()
					num_of_points = len(long_MOR_line)
					current_list_of_pts[:] = []
					for i in range(0, num_of_points-1):
						j = i + 1
						start_pt = long_MOR_line[i]
						if (len(current_list_of_pts) == 0):
							current_list_of_pts.append(start_pt)
						end_pt = long_MOR_line[j]
						temporal_line_segment = pygplates.PolylineOnSphere([start_pt,end_pt])
						already_subdivided = False
						for _,polygon,_ in list_of_tuples:
							if (polygon.partition(temporal_line_segment) != pygplates.PolygonOnSphere.PartitionResult.outside):
								if (len(current_list_of_pts) > 1):
									new_line_geometry = pygplates.PolylineOnSphere(current_list_of_pts)
									clone_MOR_ft = initial_MOR_ft.clone()
									clone_MOR_ft.set_geometry(new_line_geometry)
									if (reference is not None):
										pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,reconstruction_time,reference)
									else:
										pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,reconstruction_time)
									clone_MOR_ft.set_valid_time(reconstruction_time,(reconstruction_time - interval_of_time_when_evaluated_motion)+(interval_of_time_when_evaluated_motion*0.100))
									output_subdivide_linear_MOR_ft.add(clone_MOR_ft)
								current_list_of_pts[:] = []
								already_subdivided = True
								pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, end_pt, valid_time = initial_MOR_ft.get_valid_time())
								pt_ft.set_name(initial_MOR_ft.get_name())
								pt_ft.set_description(initial_MOR_ft.get_description())
								pt_ft.set_left_plate(initial_MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								pt_ft.set_right_plate(initial_MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								pt_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
								if (reference is not None):
									pygplates.reverse_reconstruct(pt_ft,rotation_model,reconstruction_time,reference)
								else:
									pygplates.reverse_reconstruct(pt_ft,rotation_model,reconstruction_time)
								output_point_MOR_ft.add(pt_ft)
								break
						if (already_subdivided == False):
							current_list_of_pts.append(end_pt)
					if (len(current_list_of_pts) > 1):
						new_line_geometry = pygplates.PolylineOnSphere(current_list_of_pts)
						clone_MOR_ft = initial_MOR_ft.clone()
						clone_MOR_ft.set_geometry(new_line_geometry)
						if (reference is not None):
							pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,reconstruction_time,reference)
						else:
							pygplates.reverse_reconstruct(clone_MOR_ft,rotation_model,reconstruction_time)
						clone_MOR_ft.set_valid_time(reconstruction_time,(reconstruction_time - interval_of_time_when_evaluated_motion)+(interval_of_time_when_evaluated_motion*0.100))
						output_subdivide_linear_MOR_ft.add(clone_MOR_ft)
					elif (len(current_list_of_pts) == 1):
						pt_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, current_list_of_pts[0], valid_time = initial_MOR_ft.get_valid_time())
						pt_ft.set_name(initial_MOR_ft.get_name())
						pt_ft.set_description(initial_MOR_ft.get_description())
						pt_ft.set_left_plate(initial_MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
						pt_ft.set_right_plate(initial_MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
						pt_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
						if (reference is not None):
							pygplates.reverse_reconstruct(pt_ft,rotation_model,reconstruction_time,reference)
						else:
							pygplates.reverse_reconstruct(pt_ft,rotation_model,reconstruction_time)
						output_point_MOR_ft.add(pt_ft)
				reconstruction_time = reconstruction_time - interval_of_time_when_evaluated_motion
		else:
			output_subdivide_linear_MOR_ft.add(long_MOR_ft)
	output_subdivide_linear_MOR_ft.write("subdivide_temp_linear_MOR_ft_crosses_polygon_feat_and_refine_end_age_"+modelname+"_"+yearmonthday+".shp")
	output_subdivide_linear_MOR_ft.write("subdivide_temp_linear_MOR_ft_crosses_polygon_feat_and_refine_end_age_"+modelname+"_"+yearmonthday+".gpml")
	
	output_point_MOR_ft.write("not_connected_point_MOR_ft_from_second_subdiv_"+modelname+"_"+yearmonthday+".shp")
	output_point_MOR_ft.write("not_connected_point_MOR_ft_from_second_subdiv_"+modelname+"_"+yearmonthday+".gpml")

def quick_refine_temporal_left_and_right_prev_MOR_ft_whenever_it_crosses_any_continental_polygon_feat(temporal_left_and_right_from_prev_MOR_features, continental_polygon_features, rotation_model, reference, interval_of_time_when_evaluated_motion, modelname, yearmonthday):
	output_prev_linear_MOR_ft = pygplates.FeatureCollection()
	reconstructed_line_features = []
	reconstructed_polygon_features = []
	list_of_tuples = []
	output_point_MOR_ft = pygplates.FeatureCollection()
	for long_MOR_ft in temporal_left_and_right_from_prev_MOR_features:
		print('long_MOR_ft',long_MOR_ft)
		reconstructed_line_features[:] = []
		reconstructed_polygon_features[:] = []
		list_of_tuples[:] = []
		#ger valid time to then reconstruct MOR_ft to from_time
		from_time,to_time = long_MOR_ft.get_valid_time()
		reconstruction_time = from_time
		while(reconstruction_time > (to_time - interval_of_time_when_evaluated_motion)):
			print('reconstruction_time',reconstruction_time)
			list_of_tuples[:] = []
			reconstructed_line_features[:] = []
			reconstructed_polygon_features[:] = []
			if (reference is not None):
				pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
			else:
				pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_MOR_ft = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			initial_MOR_ft,long_MOR_line = final_reconstructed_MOR_ft[0]
			if (reference is not None):
				pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
			else:
				pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_polygon_feats = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
			for continental_ft,polygon in final_reconstructed_polygon_feats:
				dist_rads = pygplates.GeometryOnSphere.distance(polygon,long_MOR_line)
				dist_kms = dist_rads * pygplates.Earth.equatorial_radius_in_kms
				if (dist_kms <= 1500.00):
					list_of_tuples.append((dist_kms,polygon,continental_ft))
			#sort the list by distance
			list_of_tuples.sort()
			already_modified = False
			for _,polygon,_ in list_of_tuples:
				if (polygon.partition(long_MOR_line) != pygplates.PolygonOnSphere.PartitionResult.outside):
					clone_MOR_ft = initial_MOR_ft.clone()
					clone_MOR_ft.set_valid_time(from_time,reconstruction_time)
					output_prev_linear_MOR_ft.add(clone_MOR_ft)
					already_modified = True
					break
			if (already_modified == True):
				break
			reconstruction_time = reconstruction_time - interval_of_time_when_evaluated_motion
	output_prev_linear_MOR_ft.write("quick_refine_end_age_of_left_and_right_prev_MOR_ft_"+modelname+"_"+yearmonthday+".shp")
	output_prev_linear_MOR_ft.write("quick_refine_end_age_of_left_and_right_prev_MOR_ft_"+modelname+"_"+yearmonthday+".gpml")

def quick_refine_temporal_point_features_associated_with_MOR_whenever_it_crosses_any_continental_polygon_feat(temporal_left_and_right_from_prev_MOR_features, continental_polygon_features, rotation_model, reference, interval_of_time_when_evaluated_motion, modelname, yearmonthday):
	output_prev_linear_MOR_ft = pygplates.FeatureCollection()
	reconstructed_pt_features = []
	reconstructed_polygon_features = []
	list_of_tuples = []
	output_point_MOR_ft = pygplates.FeatureCollection()
	for long_MOR_ft in temporal_left_and_right_from_prev_MOR_features:
		print('point MOR_ft',long_MOR_ft)
		reconstructed_pt_features[:] = []
		reconstructed_polygon_features[:] = []
		list_of_tuples[:] = []
		#ger valid time to then reconstruct MOR_ft to from_time
		from_time,to_time = long_MOR_ft.get_valid_time()
		prev_time = -1.00
		reconstruction_time = from_time
		while(reconstruction_time > (to_time - interval_of_time_when_evaluated_motion)):
			print('reconstruction_time',reconstruction_time)
			reconstructed_pt_features[:] = []
			if (reference is not None):
				pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_pt_features,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
			else:
				pygplates.reconstruct(long_MOR_ft,rotation_model,reconstructed_pt_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_MOR_ft = supporting.find_final_reconstructed_geometries(reconstructed_pt_features,pygplates.PointOnSphere)
			initial_MOR_ft,MOR_pt = final_reconstructed_MOR_ft[0]
			if (prev_time == -1.00):
				prev_time = reconstruction_time
				list_of_tuples[:] = []
				reconstructed_polygon_features[:] = []
				if (reference is not None):
					pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
				else:
					pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_polygon_feats = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
				for continental_ft,polygon in final_reconstructed_polygon_feats:
					dist_rads = pygplates.GeometryOnSphere.distance(polygon,MOR_pt)
					dist_kms = dist_rads * pygplates.Earth.equatorial_radius_in_kms
					if (dist_kms <= 1500.00):
						list_of_tuples.append((dist_kms,polygon,continental_ft))
					#sort the list by distance
					list_of_tuples.sort()
			else:
				if ((prev_time - reconstruction_time) > interval_of_time_when_evaluated_motion):
					prev_time = reconstruction_time
					list_of_tuples[:] = []
					reconstructed_polygon_features[:] = []
					if (reference is not None):
						pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
					else:
						pygplates.reconstruct(continental_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
					final_reconstructed_polygon_feats = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
					for continental_ft,polygon in final_reconstructed_polygon_feats:
						dist_rads = pygplates.GeometryOnSphere.distance(polygon,MOR_pt)
						dist_kms = dist_rads * pygplates.Earth.equatorial_radius_in_kms
						if (dist_kms <= 1500.00):
							list_of_tuples.append((dist_kms,polygon,continental_ft))
						#sort the list by distance
						list_of_tuples.sort()
						
			
			already_modified = False
			for _,polygon,_ in list_of_tuples:
				if (polygon.is_point_in_polygon(MOR_pt) ):
					clone_MOR_ft = initial_MOR_ft.clone()
					clone_MOR_ft.set_valid_time(from_time,reconstruction_time)
					output_prev_linear_MOR_ft.add(clone_MOR_ft)
					already_modified = True
					break
			if (already_modified == True):
				break
			reconstruction_time = reconstruction_time - interval_of_time_when_evaluated_motion
	output_prev_linear_MOR_ft.write("quick_refine_end_age_of_point_features_associated_w_MOR_"+modelname+"_"+yearmonthday+".shp")
	output_prev_linear_MOR_ft.write("quick_refine_end_age_of_point_features_associated_w_MOR_"+modelname+"_"+yearmonthday+".gpml")


def create_temporal_oceanic_crust_features(dic_MOR, dic_margins, at_age, rotation_model, reference, is_ridge_and_transform):
	output_oceanic_crust_fts = pygplates.FeatureCollection()
	output_ridges_fts = pygplates.FeatureCollection()
	for name in dic_MOR.keys():
		list_of_MOR_fts = dic_MOR[name]
		list_of_left_div_margin_fts = None
		list_of_right_div_margin_fts = None
		if (name in dic_margins):
			print('name',name)
			print('len(list_of_MOR_fts)',len(list_of_MOR_fts))
			if (len(list_of_MOR_fts) > 0):
				for MOR_ft in list_of_MOR_fts:
					print(MOR_ft.get_description())
			#print(margin_ft.get_name())
			list_of_left_div_margin_fts = dic_margins[name]["left"]
			list_of_right_div_margin_fts = dic_margins[name]["right"]
			print("len(list_of_left_div_margin_fts)",len(list_of_left_div_margin_fts))
			storage_lists_of_ordered_MOR_fts = create_list_of_ordered_MOR_or_div_locations_fts(list_of_MOR_fts, 1.00, "desc",is_ridge_and_transform)
			print("len(storage_lists_of_ordered_MOR_fts)",len(storage_lists_of_ordered_MOR_fts))
			if (len(storage_lists_of_ordered_MOR_fts) > 1): 
				for list_of_ordered_MOR_fts in storage_lists_of_ordered_MOR_fts:
					list_of_order_MOR = []
					list_of_ordered_left_div_margin_fts = [] 
					list_of_ordered_right_div_margin_fts = []
					reconstructed_left_div_fts = []
					reconstructed_right_div_fts = []
					reconstructed_MOR_features = []
					for order_MOR_ft in list_of_ordered_MOR_fts:
						list_of_order_MOR.append(float(order_MOR_ft.get_description()))
					storage_lists_of_order_left_div_margin_fts,list_of_unfound_order = create_list_of_ordered_div_locations_fts(list_of_left_div_margin_fts, list_of_order_MOR, is_ridge_and_transform)
					print("len(storage_lists_of_order_left_div_margin_fts)",len(storage_lists_of_order_left_div_margin_fts))
					storage_lists_of_order_right_div_margin_fts,list_of_unfound_order = create_list_of_ordered_div_locations_fts(list_of_right_div_margin_fts, list_of_order_MOR, is_ridge_and_transform)
					if (len(storage_lists_of_order_left_div_margin_fts) >= 1 and len(storage_lists_of_order_right_div_margin_fts) >= 1):
						list_of_ordered_left_div_margin_fts = storage_lists_of_order_left_div_margin_fts[0]
						print('list_of_ordered_left_div_margin_fts',list_of_ordered_left_div_margin_fts)
						for ft in list_of_ordered_left_div_margin_fts:
							print("left ft 's valid time",ft.get_valid_time())
						list_of_ordered_right_div_margin_fts = storage_lists_of_order_right_div_margin_fts[0]
						if (reference is not None):
							pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,at_age,anchor_plate_id = reference, group_with_feature = True)
							pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
							pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,at_age,group_with_feature = True)
							pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
							pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				
						final_reconstructed_MOR_fts = supporting.find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
						final_reconstructed_left_fts = supporting.find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PointOnSphere)
						final_reconstructed_right_fts = supporting.find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PointOnSphere)
				
						MOR_features,reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
						div_left_features,reconstructed_div_left_points = zip(*final_reconstructed_left_fts)
						div_right_features,reconstructed_div_right_points = zip(*final_reconstructed_right_fts)
			
						left_plate_id = MOR_features[0].get_left_plate()
						right_plate_id = MOR_features[0].get_right_plate()
			
						if (len(final_reconstructed_MOR_fts) > 1):
							final_list_of_points_for_MOR,temp_linear_MOR_ft,left_linear_MOR_ft,right_linear_MOR_ft = create_MOR_feature_for_a_pair_of_SuperGDUs_only(final_reconstructed_MOR_fts, at_age, 10.00, rotation_model, reference, True)
				
							left_oceanic_crust_ft = create_oceanic_crust_polygon_fts_at_age(at_age, 0.00, list(reconstructed_div_left_points), final_list_of_points_for_MOR,\
										left_plate_id, left_plate_id, right_plate_id, "left", name, rotation_model, reference)
							right_oceanic_crust_ft = create_oceanic_crust_polygon_fts_at_age(at_age, 0.00, list(reconstructed_div_right_points), final_list_of_points_for_MOR,\
										right_plate_id, left_plate_id, right_plate_id, "right", name, rotation_model, reference)
							output_oceanic_crust_fts.add(left_oceanic_crust_ft)
							output_oceanic_crust_fts.add(right_oceanic_crust_ft)
			elif (len(storage_lists_of_ordered_MOR_fts) == 1):
				list_of_ordered_MOR_fts = storage_lists_of_ordered_MOR_fts[0]
				list_of_order_MOR = []
				list_of_ordered_left_div_margin_fts = [] 
				list_of_ordered_right_div_margin_fts = []
				reconstructed_left_div_fts = []
				reconstructed_right_div_fts = []
				reconstructed_MOR_features = []
				for order_MOR_ft in list_of_ordered_MOR_fts:
					list_of_order_MOR.append(float(order_MOR_ft.get_description()))
				storage_lists_of_order_left_div_margin_fts,list_of_unfound_order = create_list_of_ordered_div_locations_fts(list_of_left_div_margin_fts, list_of_order_MOR, is_ridge_and_transform)
				print("len(storage_lists_of_order_left_div_margin_fts)",len(storage_lists_of_order_left_div_margin_fts))
				storage_lists_of_order_right_div_margin_fts,list_of_unfound_order = create_list_of_ordered_div_locations_fts(list_of_right_div_margin_fts, list_of_order_MOR, is_ridge_and_transform)
				print("len(storage_lists_of_order_right_div_margin_fts)",len(storage_lists_of_order_right_div_margin_fts))
				if (len(storage_lists_of_order_left_div_margin_fts) == 1 and len(storage_lists_of_order_right_div_margin_fts) == 1):
					print("enter this condition")
					list_of_ordered_left_div_margin_fts = storage_lists_of_order_left_div_margin_fts[0]
					list_of_ordered_right_div_margin_fts = storage_lists_of_order_right_div_margin_fts[0]
					if (reference is not None):
						pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,at_age,anchor_plate_id = reference, group_with_feature = True)
						pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
						pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
					else:
						pygplates.reconstruct(list_of_ordered_MOR_fts,rotation_model,reconstructed_MOR_features,at_age,group_with_feature = True)
						pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
						pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				
					final_reconstructed_MOR_fts = supporting.find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
					final_reconstructed_left_fts = supporting.find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PointOnSphere)
					final_reconstructed_right_fts = supporting.find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PointOnSphere)
				
					MOR_features,reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
					div_left_features,reconstructed_div_left_points = zip(*final_reconstructed_left_fts)
					div_right_features,reconstructed_div_right_points = zip(*final_reconstructed_right_fts)
			
					left_plate_id = MOR_features[0].get_left_plate()
					right_plate_id = MOR_features[0].get_right_plate()
			
					if (len(final_reconstructed_MOR_fts) > 1):
						final_list_of_points_for_MOR,temp_linear_MOR_ft,left_linear_MOR_ft,right_linear_MOR_ft = create_MOR_feature_for_a_pair_of_SuperGDUs_only(final_reconstructed_MOR_fts, at_age, 10.00, rotation_model, reference, True)
				
						left_oceanic_crust_ft = create_oceanic_crust_polygon_fts_at_age(at_age, 0.00, list(reconstructed_div_left_points), final_list_of_points_for_MOR,\
										left_plate_id, left_plate_id, right_plate_id, "left", name, rotation_model, reference)
						right_oceanic_crust_ft = create_oceanic_crust_polygon_fts_at_age(at_age, 0.00, list(reconstructed_div_right_points), final_list_of_points_for_MOR,\
										right_plate_id, left_plate_id, right_plate_id, "right", name, rotation_model, reference)
						output_oceanic_crust_fts.add(left_oceanic_crust_ft)
						output_oceanic_crust_fts.add(right_oceanic_crust_ft)
	return output_oceanic_crust_fts