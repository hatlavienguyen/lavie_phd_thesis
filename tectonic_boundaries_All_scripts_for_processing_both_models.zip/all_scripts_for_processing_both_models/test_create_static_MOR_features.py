from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
from multiprocessing import Pool
from os import environ
from time import sleep
import create_topological_isochron_and_estimate_MOR as create_topological

#oceanic_crust_features_file = r"oceanic_crust_from_rift_and_isochron_point_features_with_max_star_div_age_600.0_min_400.0_test_29_PalaeoPlatesendJan2023_20231106.shp"
#oceanic_crust_features = pygplates.FeatureCollection(oceanic_crust_features_file)
#oceanic_crust_features_file = r"oceanic_crust_from_rift_and_isochron_point_features_with_max_star_div_age_{input_max_time}_min_{input_min_time}_test_29_PalaeoPlatesendJan2023_20231106.shp"
#supergdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
#supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)
#gdu_oceanic_crust_features_file = r"oceanic_crust_for_gdus_from_rift_and_isochron_feats_with_max_star_div_age_2800.0_0.0_test_1_PalaeoPlatesendJan2023_20231211.shp"
#gdu_oceanic_crust_features_file = r"modified_end_age_of_oceanic_crust_feats_from_2800.00Ma_PalaeoPlatesendJan2023_20231128.shp"
#gdu_oceanic_crust_features_file = r"modified_end_age_of_invalid_temporary_oceanic_crust_polygon_feats_max_div_age_2800.0_0.0_test_1_PalaeoPlatesendJan2023_20231212.shp"
#gdu_oceanic_crust_features = pygplates.FeatureCollection(gdu_oceanic_crust_features_file)
modified_rift_point_ft_file = r"modified_end_age_of_rift_point_feats_based_on_kinematic_records_from_2800Ma_test_29_PalaeoPlatesendJan2023_fts_20240103.shp"
modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_ft_file)
rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
reference = 700
time_interval = 5.00
yearmonthday = "20240111"
modelname = "test_1_PalaeoPlatesendJan2023"
def calculate_values_for_max_reconstruction_time(maximum_of_reconstruction_period,minimum_of_reconstruction_period,time_interval_of_input_file):
	max_rec_time_list = []
	value = maximum_of_reconstruction_period
	while (value >= minimum_of_reconstruction_period):
		min_recon = value - time_interval_of_input_file
		max_rec_time_list.append(value)
		value = min_recon
	return max_rec_time_list

def evaluate_temporary_oceanic_crust_feats_and_estimate_subducted_materials(maximum_reconstruction_time):
	final_oceanic_crust_features_file = oceanic_crust_features_file.format(input_max_time = str(maximum_reconstruction_time), input_min_time = str(maximum_reconstruction_time - time_interval_of_input_file))
	oceanic_crust_features = pygplates.FeatureCollection(final_oceanic_crust_features_file)
	create_topological.modified_end_age_of_temporary_oceanic_crust_polygon_features(oceanic_crust_features, supergdu_features, rotation_model, reference, maximum_reconstruction_time, time_interval, modelname, yearmonthday)

def evaluate_oceanic_crust_features_to_find_oceanic_subduction(maximum_reconstruction_time, minimum_reconstruction_time, time_interval):
	create_topological.evaluate_oceanic_crust_features_with_each_other(gdu_oceanic_crust_features, supergdu_features, rotation_model, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, reference, modelname, yearmonthday)

def find_static_MOR_features(maximum_reconstruction_time, minimum_reconstruction_time, time_interval):
	create_topological.create_static_MOR_to_represent_each_div_margin(modified_rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday)
if __name__ == '__main__':
	maximum_of_reconstruction_period = 2800.00
	minimum_of_reconstruction_period = 400.00
	time_interval_of_input_file = 200.00
	# max_rec_time_list = calculate_values_for_max_reconstruction_time(maximum_of_reconstruction_period,minimum_of_reconstruction_period,time_interval_of_input_file)
	# with Pool(ncpus) as pool:
		# results = pool.map(evaluate_temporary_oceanic_crust_feats_and_estimate_subducted_materials, max_rec_time_list)
		# print(results)
	
	maximum_reconstruction_time = 2800.00
	minimum_reconstruction_time = 0.00
	time_interval = 5.00
	#evaluate_oceanic_crust_features_to_find_oceanic_subduction(maximum_reconstruction_time, minimum_of_reconstruction_period, time_interval)
	
	find_static_MOR_features(maximum_reconstruction_time, minimum_reconstruction_time, time_interval)
	