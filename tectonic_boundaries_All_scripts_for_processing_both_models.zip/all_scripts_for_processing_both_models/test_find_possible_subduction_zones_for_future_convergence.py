#import supporting_modules as supporting
import supporting_modules_to_be_converted as supporting
import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
import pygplates
#update PalaeoPlate model by April 2020
#EUR_ASI_PalaeoPlates_April_2020
#polygon_feature_file = "C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\GDUs\SAM_AFR_PlatePolygons2020.shp"
#topological_line_features_file = "C:\Users\lavie\Desktop\Research\Summer2020\Code\examine_line_topology\\topology_of_lines_SAM_AFR_PalaeoPlate2020_test_5_test_1_0.00100_v2_200625.gpml"

# polygon_feature_file = "C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\GDUs\\ASI_EUR_PalaeoPlates2020.shp"
# topological_line_features_file = "C:\Users\lavie\Desktop\Research\Summer2020\Code\examine_line_topology\\topology_of_lines_EUR_ASI_PalaeoPlate2020_test_1_test_1_0.00100_v2_200714.gpml"
#polygon_feature_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\GDUs\ASI_EUR_PalaeoPlates2020.shp"
#topological_line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2020\Code\examine_line_topology\\08052020\\PalaeoPlates\\topology_of_lines_EUR_ASI_PalaeoPlate2020_test_1_test_1_0.00100_v2_200813.gpml"

polygon_feature_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\GDUs\PlatePolygons2016Continental.shp"
topological_line_features_file = r"C:\Users\lavie\Desktop\Research\Fall2020\Code\examine_line_topology\topology_of_lines_PalaeoPlates2020_test_2_after_testing_present_topology_test_1_0.00100_v2_201007.gpml"

rot_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\Rotation\\T_Rot_Model_PalaeoPlates_20200131be.rot"

#igneous_buffer_zone_features_file = 'C:\Users\lavie\Desktop\Research\Summer2020\Code\igneous_metamorphics_records\\07202020\\igneous_dissolved_buffer_v1_test_1_300.0_0.5_polygon_ft_1800_0_10Ma_15_time_wdn_with_PeterHone_data_and_PalaeoPlates_April2020_test_4_20200724.shp'

#deposits_or_geochron_buffer_features_file = r'C:\Users\lavie\Desktop\Research\Fall2020\Code\identify_plate_boundaries\deposits_dissolved_buffer_v1_test_1_280.0_0.5_polygon_ft_1800_0_10Ma_15_time_wdn_PalaeoPlates_with_deposits_from_DateView_and_Neftex_test_1_280km_20200810.shp'
deposits_or_geochron_buffer_features_file = r'C:\Users\lavie\Desktop\Research\Fall2020\Code\identify_plate_boundaries\dissolved_buffer_v1_test_1_300.0_0.5_polygon_ft_1800_0_10Ma_15_time_wdn_Igneous_data_from_Prof_Bruce_Winter2020_with_PalaeoPlates2020_20200826.shp'


#deposits_or_geochron_buffer_features_file = 'C:\Users\lavie\Desktop\Research\Summer2020\Code\igneous_metamorphics_records\\07202020\\igneous_dissolved_buffer_from_DateView_and_Neftex_Geochron_for_EUR_ASI_Region_from_20200704.shp'

rot_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\Rotation\T_Rot_Model_PalaeoPlates_20200131be.rot"

from_age = 200
to_age = 0
interval = 5
field_name_for_lithosphere_type = 'COTID'
continental_type_symbol = 'C'
threshold_distance_in_km = 1500
difference_distance_km = 0.0500
cos_value_for_transform = 0.010
reference = 700
number_of_intervals = 2
modelname = 'PalaeoPlates_April2020_test_1_from_igneous_DateView_only'
mmddyy = '10132020'
freq_writing_csv_files = 2
write_output = True
output_freq = 0.00 

def main(rot_file,topological_line_features_file,deposits_or_geochron_buffer_features_file,from_age,to_age,interval,reference,modelname,mmddyy,write_output,output_freq):
	# print('This is polygon_feature_file')
	# print polygon_feature_file
	# polygon_features_collection = pygplates.FeatureCollection(polygon_feature_file)
	
	# list_of_continental_polygons_fts = polygon_features_collection.get(
			# lambda polygon_feature: polygon_feature.get_shapefile_attribute(field_name_for_lithosphere_type) == continental_type_symbol ,pygplates.FeatureReturn.all)
	# supporting.find_centroid_features(list_of_continental_polygons_fts,False)
	# oldest_ft = supporting.find_the_oldest_feature(list_of_continental_polygons_fts)
	# print "The oldest feature GDU_id"
	# print oldest_ft.get_reconstruction_plate_id()
	# print oldest_ft.get_valid_time()
	
	# print('This is a rotation_file')
	# print rot_file
	
	# rotation_model = pygplates.RotationModel(rot_file)
	# threshold_distance_in_km = 1000.00
	# dictionary_of_neighbours_id = {}
	# reconstruction_time = 0.00
	
	#read all input files
	print('This is a rotation_file')
	print(rot_file)
	rotation_model = pygplates.RotationModel(rot_file)
	print('This is topological_line_features_file')
	print(topological_line_features_file)
	topological_line_features = pygplates.FeatureCollection(topological_line_features_file)
	print('This is deposits_or_geochron_buffer_features_file')
	print(deposits_or_geochron_buffer_features_file)
	deposits_or_geochron_buffer_features = pygplates.FeatureCollection(deposits_or_geochron_buffer_features_file)
	
	supporting.find_possible_subduction_zone_for_future_convergence(rotation_model,topological_line_features,deposits_or_geochron_buffer_features,from_age,to_age,interval,reference,modelname,mmddyy,write_output,output_freq)
	#supporting.find_neighbours_for_polygon_features(rotation_model,list_of_continental_polygons_fts,threshold_distance_in_km,dictionary_of_neighbours_id,reconstruction_time,reference)
	#print "Here is dictionary_of_neighbours_id"
	#for each_key in dictionary_of_neighbours_id.keys():
	#	list_of_neighbours_id = dictionary_of_neighbours_id[each_key]
	#	for each_neighbour_id in list_of_neighbours_id:
	#		print each_neighbour_id

if __name__ == "__main__":
	main(rot_file,topological_line_features_file,deposits_or_geochron_buffer_features_file,from_age,to_age,interval,reference,modelname,mmddyy,write_output,output_freq)