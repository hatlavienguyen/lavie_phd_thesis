import os
import csv
import math
from statistics import mean	
import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import geopandas as gpd
import pandas as pd

def summarize_kinematic_line_features(features_from_conv_process_shp_file, features_from_div_process_shp_file, con_ocn_line_features_shp_file, parent_dir, modelname, yearmonthday):
	'''Each line feature can only be one type of kinematic feature in one period'''
	gdf_con_ocn = gpd.read_file(con_ocn_line_features_shp_file)
	gdf_from_conv_process = gpd.read_file(features_from_conv_process_shp_file)
	gdf_from_div_process = gpd.read_file(features_from_div_process_shp_file)
	features_from_div_process = pygplates.FeatureCollection(features_from_div_process_shp_file)
	features_from_conv_process = pygplates.FeatureCollection(features_from_conv_process_shp_file)
	output_FeatureCollection = pygplates.FeatureCollection()
	unique_polylid = gdf_con_ocn['POLYLID'].unique()
	output_dic = {}
	for polylid in unique_polylid:
		if (polylid not in output_dic):
			output_dic[polylid] = []
			#get all possible CON-OCN line feats associated with polylid
			records_w_polylid = gdf_con_ocn.loc[gdf_con_ocn['POLYLID'] == polylid,['from_time','to_time']]
			max_from_time = -1.00
			min_to_time = 1000000.000
			found_reliable_record = False
			for from_time,to_time in records_w_polylid.itertuples(index = False, name = None):
				records_from_div_process = gdf_from_div_process.loc[(gdf_from_div_process['NAME'] == polylid) & (gdf_from_div_process['FROMAGE'] <= from_time) & (gdf_from_div_process['TOAGE'] >= to_time) & (gdf_from_div_process['Certainty'] == 'High') & (gdf_from_div_process['KinID'] == 'D'),['FROMAGE','TOAGE']]
				if (len(records_from_div_process) > 0):
					found_reliable_record = True
					for div_from_age,div_to_age in records_from_div_process.itertuples(index = False, name = None):
						output_dic[polylid].append((div_from_age,div_to_age,'div','D'))
				records_from_conv_process = gdf_from_conv_process.loc[(gdf_from_conv_process['NAME'] == polylid) & (gdf_from_conv_process['FROMAGE'] <= from_time) & (gdf_from_conv_process['TOAGE'] >= to_time) & (gdf_from_conv_process['Certainty'] == 'High') & (gdf_from_conv_process['KinID'] == 'C'),['FROMAGE','TOAGE']]
				if (len(records_from_conv_process) > 0):
					found_reliable_record = True
					for conv_from_age,conv_to_age in records_from_conv_process.itertuples(index = False, name = None):
						output_dic[polylid].append((conv_from_age,conv_to_age,'conv','C'))
				other_records_from_div_process = gdf_from_div_process.loc[(gdf_from_div_process['NAME'] == polylid) & (gdf_from_div_process['FROMAGE'] <= from_time) & (gdf_from_div_process['TOAGE'] >= to_time) & (gdf_from_div_process['Certainty'] == 'High'),['FROMAGE','TOAGE','KinID']]
				if (len(other_records_from_div_process) > 0):
					found_reliable_record = True
					for other_from_age,other_to_age,kinid in other_records_from_div_process.itertuples(index = False, name = None):
						if (kinid == 'T'):
							output_dic[polylid].append((other_from_age,other_to_age,'div','T'))
						elif (kinid == 'U'):
							output_dic[polylid].append((other_from_age,other_to_age,'div','U'))
				other_records_from_conv_process = gdf_from_conv_process.loc[(gdf_from_conv_process['NAME'] == polylid) & (gdf_from_conv_process['FROMAGE'] <= from_time) & (gdf_from_conv_process['TOAGE'] >= to_time) & (gdf_from_conv_process['Certainty'] == 'High'),['FROMAGE','TOAGE','KinID']]
				if (len(other_records_from_conv_process) > 0):
					found_reliable_record = True
					for other_from_age,other_to_age,kinid in other_records_from_conv_process.itertuples(index = False, name = None):
						if (kinid == 'T'):
							output_dic[polylid].append((other_from_age,other_to_age,'conv','T'))
						elif (kinid == 'U'):
							output_dic[polylid].append((other_from_age,other_to_age,'conv','U'))
				if (found_reliable_record == False):
					other_low_records_from_div_process = gdf_from_div_process.loc[(gdf_from_div_process['NAME'] == polylid) & (gdf_from_div_process['FROMAGE'] <= from_time) & (gdf_from_div_process['TOAGE'] >= to_time) & (gdf_from_div_process['Certainty'] == 'Low'),['FROMAGE','TOAGE','KinID']]
					if (len(other_low_records_from_div_process) > 0):
						for other_from_age,other_to_age,kinid in other_low_records_from_div_process.itertuples(index = False, name = None):
							if (kinid == 'C'):
								output_dic[polylid].append((other_from_age,other_to_age,'div','C'))
					else:
						other_low_records_from_conv_process = gdf_from_conv_process.loc[(gdf_from_conv_process['NAME'] == polylid) & (gdf_from_conv_process['FROMAGE'] <= from_time) & (gdf_from_conv_process['TOAGE'] >= to_time) & (gdf_from_conv_process['Certainty'] == 'Low'),['FROMAGE','TOAGE','KinID']]
						if (len(other_low_records_from_conv_process) > 0):
							for other_from_age,other_to_age,kinid in other_low_records_from_conv_process.itertuples(index = False, name = None):
								if (kinid == 'D'):
									output_dic[polylid].append((other_from_age,other_to_age,'conv','D'))
	
	for polylid in output_dic:
		#obtain list of tuples
		list_of_tuples = output_dic[polylid]
		#sort list_of_tuples based on the first element that is the from_age of a kin feat
		list_of_tuples.sort(reverse = True)
		new_list_of_tuples = []
		if (len(list_of_tuples) > 0):
			for current_from_age, current_to_age, name_dataset, kinid in list_of_tuples:
				if (len(new_list_of_tuples) == 0):
					if ((name_dataset == 'div' and kinid == 'C') or (name_dataset == 'conv' and kinid == 'D')):
						continue
					else:
						new_list_of_tuples.append((current_from_age, current_to_age, name_dataset, kinid))
				else:
					prev_from_age, prev_to_age, prev_name_dataset, prev_kinid = new_list_of_tuples[-1]
					if (current_from_age <= prev_to_age):
						new_list_of_tuples.append((current_from_age, current_to_age, name_dataset, kinid))
					#elif (current_from_age > prev_to_age and current_from_age <= prev_from_age):
					elif (current_from_age > prev_to_age):
						if ((prev_name_dataset == 'div' and prev_kinid == 'C') or (prev_name_dataset == 'conv' and prev_kinid == 'D')):
							#completely replace the record, if the current records is the most reliable 
							if ((name_dataset == 'div' and kinid == 'D') or (name_dataset == 'conv' and kinid == 'C')):
								new_list_of_tuples.pop()
								new_list_of_tuples.append((current_from_age, current_to_age, name_dataset, kinid))
							elif ((name_dataset == 'div' and kinid != 'C') or (name_dataset == 'conv' and kinid != 'D')):
								new_list_of_tuples.pop()
								new_list_of_tuples.append((current_from_age, current_to_age, name_dataset, kinid))
							elif ((prev_name_dataset == 'conv' and prev_kinid == 'D') and (name_dataset == 'div')):
								new_list_of_tuples.pop()
								new_list_of_tuples.append((current_from_age, current_to_age, name_dataset, kinid))
						elif (prev_name_dataset == 'div' and (prev_kinid == 'T' or prev_kinid == 'U')):
							if (name_dataset == 'div' and kinid == 'D'):
								new_list_of_tuples.pop()
								new_list_of_tuples.append((current_from_age, current_to_age, name_dataset, kinid))
						elif (prev_name_dataset == 'conv' and (prev_kinid == 'T' or prev_kinid == 'U')):
							if (name_dataset == 'conv' and kinid == 'C'):
								new_list_of_tuples.pop()
								new_list_of_tuples.append((current_from_age, current_to_age, name_dataset, kinid))
		already_included_fts = []
		for final_from_age, final_to_age, final_name_dataset, final_kinid in new_list_of_tuples:
			if (final_name_dataset == 'div'):
				for ft in features_from_div_process:
					if (ft.get_feature_id() not in already_included_fts):
						already_included_fts.append(ft.get_feature_id())
						ft_from_age,ft_to_age = ft.get_valid_time()
						if (ft.get_name() == polylid and ft_from_age == final_from_age and ft_to_age == final_to_age and ft.get_shapefile_attribute('KinID') == final_kinid):
							output_FeatureCollection.add(ft)
			elif (final_name_dataset == 'conv'):
				for ft in features_from_conv_process:
					if (ft.get_feature_id() not in already_included_fts):
						already_included_fts.append(ft.get_feature_id())
						ft_from_age,ft_to_age = ft.get_valid_time()
						if (ft.get_name() == polylid and ft_from_age == final_from_age and ft_to_age == final_to_age and ft.get_shapefile_attribute('KinID') == final_kinid):
							output_FeatureCollection.add(ft)
	
	output_FeatureCollection.write('summarize_kinematic_line_features_for_'+modelname+'_'+yearmonthday+'.shp')
	#create folder to output temporary records for each polylid 
	path = os.path.join(parent_dir,'temp_records_polylid_'+modelname+'_'+yearmonthday)
	os.mkdir(path)
	for polylid in output_dic:
		#obtain list of tuples
		list_of_tuples = output_dic[polylid]
		new_df = pd.DataFrame.from_records(list_of_tuples, columns=['from_age', 'to_age', 'dataset', 'kinid'])
		new_path = os.path.join(path,polylid+'.csv')
		new_df.to_csv(new_path)
		new_path = 'temp_records_polylid_'+polylid+'_'+modelname+'_'+yearmonthday+'.csv'
		new_df.to_csv(new_path)

def main():
	# features_from_conv_process_shp_file = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/summarize/converging_line_features_for_2300.0_0.0_test_28_short_conv_PalaeoPlatesJan2023_20230923.shp'
	# features_from_div_process_shp_file = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/summarize/fixed_diverging_line_features_for_2000.0_5.0_test_28_short_PalaeoPlatesendJan2023_w_1_deg_20230924.shp' 
	# con_ocn_line_features_shp_file = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_valid_single_line_fts_All_PalaeoPlatesJan2023_20230628.shp'
	# parent_dir = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/summarize'
	# modelname = 'PalaeoPlatesendJan2023'
	# yearmonthday = '20231004'
	# summarize_kinematic_line_features(features_from_conv_process_shp_file, features_from_div_process_shp_file, con_ocn_line_features_shp_file, parent_dir, modelname, yearmonthday)

	features_from_conv_process_shp_file = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/tectonic_boundaries/converging_line_features_for_995.0_0.0_test_12_EB2022_20231023.shp'
	features_from_div_process_shp_file = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/tectonic_boundaries/diverging_line_features_for_995.0_5.0_test_8_EB2022_20231020.shp' 
	con_ocn_line_features_shp_file = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/CON_OCN_w_temp_neighbours_for_test_1_original_and_new_single_POLYGID_joined_line_fts_995.0_0.0_Merdith_et_al_EB2021_20230930.shp'
	parent_dir = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/tectonic_boundaries/summarize'
	modelname = 'test_2_EB2022'
	yearmonthday = '20231024'
	summarize_kinematic_line_features(features_from_conv_process_shp_file, features_from_div_process_shp_file, con_ocn_line_features_shp_file, parent_dir, modelname, yearmonthday)

if __name__== '__main__':
	main()