import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import identify_kinematic_boundaries as kin_boundary

def main():
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	#rotation_model = pygplates.RotationModel(rotation_file)
	sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	#sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	gdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	#gdu_features_collection = pygplates.FeatureCollection(gdu_features_file)
	#line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_26_valid_single_dissolved_merged_POLGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230509.shp"
	line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_valid_single_line_fts_All_PalaeoPlatesJan2023_20230628.shp"
	#line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/AFR_NAM_SAM_CON_OCN_from_test_32_PalaeoPlatesJan2023_20230628.shp"
	#line_features_collection = pygplates.FeatureCollection(line_features_file)
	
	
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	# sgdu_distance_csv = r"C:\Users\lavie\Desktop\Research\Fall2022\tectonic_boundaries\PalaeoPlates2022_smallest_dist_km_btw_valid_sgdu_feats_3420.0_0.0_5.0_20230204.csv"
	# sgdu_outer_gdu_members_csv = r"C:\Users\lavie\Desktop\Research\Fall2022\tectonic_boundaries\PalaeoPlatesOct2022_sgu_and_outer_gdu_members_from_3420.0_0.0_20230204.csv"
	sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	common_filename_for_temporary_sgdu_and_members_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	gdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	gdu_features_collection = pygplates.FeatureCollection(gdu_features_file)
	line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\CON_OCN_w_temp_neighbours_for_test_32_original_and_new_valid_single_line_fts_All_PalaeoPlatesJan2023_20230628.shp"
	# #line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\AFR_SAM_valid_till_present_CON_OCN_from_test_32_PalaeoPlatesJan2023_20230628.shp"
	# line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\troubled_line_features_should_be_div_but_conv_SAM_AFR_test_32_PalaeoPlates.shp"
	line_features_collection = pygplates.FeatureCollection(line_features_file)
	
	
	begin_reconstruction_time = 1900.00
	end_reconstruction_time = 1380.00
	time_interval = 10.0
	reference = 700
	neighbouring_distance_km = 8000.00
	yearmonthday = "20241012"
	modelname = "test_1_eval_kin_PalaeoPlatesendJan2023_w_1_deg"
	oldest_age_to_start_decaying_neighbouring_dist = 1700.00
	decaying_rate = 0.2000
	kin_boundary.evaluate_kinematic(neighbouring_distance_km, oldest_age_to_start_decaying_neighbouring_dist, decaying_rate, line_features_collection, sgdu_features, gdu_features_collection, common_filename_for_temporary_sgdu_and_members_csv, time_interval, begin_reconstruction_time, end_reconstruction_time, rotation_model, reference, modelname, yearmonthday)
	
if __name__ == '__main__':
	main()
