import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting


test_GDU_id = [10389, 10452]
input_line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\SAM_AFR_PlatePolygons2016Continental.shp"
line_features = pygplates.FeatureCollection(input_line_features_file)
rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
rotation_model = pygplates.RotationModel(rotation_file)
test_line_features = []
from_time = 140.00
interval_time = 5.00
reference = 700
cos_value_for_transform = 0.0100
reconstructed_line_features = []
reconstruction_time = from_time
while (reconstruction_time >= 0.00):
	reconstructed_line_features[:] = []
	for line_ft in line_features:
		if (line_ft.get_reconstruction_plate_id() in test_GDU_id and line_ft.is_valid_at_time(reconstruction_time)):
			test_line_features.append(line_ft)
	if (reference is not None):
		#polygon_features
		#pygplates.reconstruct(list_of_appropriate_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		#line_features
		pygplates.reconstruct(test_line_features,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	else:
		#polygon_features
		#pygplates.reconstruct(list_of_appropriate_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time, group_with_feature = True)
		#line_features
		pygplates.reconstruct(test_line_features,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
	final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolygonOnSphere)
	first_line_ft,first_line = None,None
	second_line_ft,second_line = None,None
	first_gdu_id = test_GDU_id[0]
	second_gdu_id = test_GDU_id[1]
	for reconstructed_line_ft,line in final_reconstructed_line_features:
		if (reconstructed_line_ft.get_reconstruction_plate_id() == first_gdu_id):
			first_line_ft = reconstructed_line_ft
			first_line = line
		elif (reconstructed_line_ft.get_reconstruction_plate_id() == second_gdu_id):
			second_line_ft = reconstructed_line_ft
			second_line = line
		if (first_line_ft is not None and second_line_ft is not None):
			break
	centroid_of_first = first_line.get_interior_centroid()
	centroid_of_second = second_line.get_interior_centroid()
	distance = pygplates.GeometryOnSphere.distance(centroid_of_first,centroid_of_second)
	distance_in_km = distance * pygplates.Earth.mean_radius_in_kms
	print("reconstruction_time", reconstruction_time)
	print("distance_in_km", distance_in_km)
	featureType = pygplates.FeatureType.gpml_continental_crust
	reference_point_ft = pygplates.Feature.create_reconstructable_feature(featureType, centroid_of_first, valid_time = (reconstruction_time,reconstruction_time - interval_time), reconstruction_plate_id = first_gdu_id)
	neighbour_point_ft = pygplates.Feature.create_reconstructable_feature(featureType, centroid_of_second, valid_time = (reconstruction_time,reconstruction_time - interval_time), reconstruction_plate_id = second_gdu_id)
	if (reference is not None):
		pygplates.reverse_reconstruct([reference_point_ft,neighbour_point_ft], rotation_model, reconstruction_time, anchor_plate_id = reference)
	vel_vector = supporting.relative_position_velocity_vectors_eval(rotation_model,reference_point_ft,neighbour_point_ft,reconstruction_time,interval_time,reference,cos_value_for_transform)
	print("vel_vector",vel_vector)
	reconstruction_time = reconstruction_time - interval_time