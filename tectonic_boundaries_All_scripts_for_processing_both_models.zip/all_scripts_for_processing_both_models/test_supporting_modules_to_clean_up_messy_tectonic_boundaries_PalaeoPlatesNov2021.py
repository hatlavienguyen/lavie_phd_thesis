import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_extend_tectonic_boundaries as supporting_extending
import supporting_modules_to_clean_up_messy_tectonic_features as supporting_cleaning

def main():
	messy_tectonic_boundaries_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_motion_and_tectonic_boundaries_and_CON_OCN_line_fts_PalaeoPlatesNov2021_temp_2000_0Ma_1_20220327.gpml"
	messy_tectonic_boundaries_features = pygplates.FeatureCollection(messy_tectonic_boundaries_shp_or_gpml)
	SuperGDU_fts_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\superGDU\test_11_optimize_no_rotation_refine_boundaries_of_SuperGDU_fts_Shapely_only_clean_up_final_SuperGDU_fts_PalaeoPlatesNov2021_from_2000_20220120_20220203.shp"
	SuperGDU_fts = pygplates.FeatureCollection(SuperGDU_fts_file)
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	test_number = 1
	modelname = "PalaeoPlatesNov2021"
	yearmonthday = "20220327"
	#supporting.clean_up_messy_tectonic_boundaries_based_on_geological_topology(messy_tectonic_boundaries_feature, time_interval_uncertainty, test_number, modelname, yearmonthday)
	#supporting.clean_up_messy_tectonic_boundaries_based_on_geol_topology_temp_bdn(messy_tectonic_boundaries_feature, time_interval_uncertainty, test_number, modelname, yearmonthday)
	supporting_cleaning.check_validity_of_every_pair_of_GDUs_based_on_SuperGDU(rotation_model, messy_tectonic_boundaries_features, SuperGDU_fts, reference ,test_number, modelname, yearmonthday)

if __name__ == "__main__":
	# messy_tectonic_boundaries_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Fall2021\tectonic_boundaries\extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_motion_and_tectonic_boundaries_and_CON_OCN_line_fts_PalaeoPlates_June_2021_test_6_threshold_2_20211027.gpml"
	# test_number = 1
	# modelname = "PalaeoPlatesJune2021"
	# yearmonthday = "20211121"
	# time_interval_uncertainty = 50.00
	main()