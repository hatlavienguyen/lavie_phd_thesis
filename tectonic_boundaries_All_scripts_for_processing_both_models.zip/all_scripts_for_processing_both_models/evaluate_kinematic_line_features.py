import math
import enum
import operator
from os.path import isdir, join, isfile
from os import makedirs 
import sys
import copy
import csv 
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1, 'C:\Downloads\GPlates\pygplates_rev28_python27_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import numpy as np
import pandas as pd

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def construct_lines_of_latitude_v1_at_interval_of(start_lat,end_lat,interval_lat,spin_axis_ref,is_output_shp,yyyymmdd):
	list_of_lat_lon_points_at_lat = []
	featType = pygplates.FeatureType.gpml_unknown_contact
	distant_future = pygplates.GeoTimeInstant.create_distant_future()
	distant_past = pygplates.GeoTimeInstant.create_distant_past()
	output_lines_of_latitude = []
	lat = start_lat
	while (lat <= end_lat):
		list_of_lat_lon_points_at_lat[:] = []
		lon = -180.00
		while (lon < (180.00 + 1.00)):
			lat_lon_tuple = (lat,lon)
			if (lat == 0.00):
				lat_lon_tuple = (0.01,lon)
			point = pygplates.PointOnSphere(lat_lon_tuple)
			list_of_lat_lon_points_at_lat.append(point)
			#update longitude values
			lon = lon + 1.00
		#construct line of latitutde - small_circle
		small_circle = pygplates.PolylineOnSphere(list_of_lat_lon_points_at_lat)
		#create a reconstructable feature with reconstruction_plate_id as spin_axis_ref
		small_circle_ft = pygplates.Feature.create_reconstructable_feature(featType,small_circle,name= "latitude"+str(lat),valid_time = (distant_past,distant_future),reconstruction_plate_id = spin_axis_ref,description = str(lat))
		output_lines_of_latitude.append(small_circle_ft)
		#update latitude values 
		lat = lat + interval_lat
	#store this output for the later use 
	if (is_output_shp == True):
		outputLinesFeatureCollection = pygplates.FeatureCollection(output_lines_of_latitude)
		outputLinesFile = "Latitudes_"+str(start_lat)+"_"+str(end_lat)+"_"+str(interval_lat)+"_spin_axis_ref_"+str(spin_axis_ref)+"_"+yyyymmdd+".shp"
		outputLinesFeatureCollection.write(outputLinesFile)
	outputLinesFeatureCollection = pygplates.FeatureCollection(output_lines_of_latitude)
	outputLinesFile = "Latitudes_"+str(start_lat)+"_"+str(end_lat)+"_"+str(interval_lat)+"_spin_axis_ref_"+str(spin_axis_ref)+"_"+yyyymmdd+".gpml"
	outputLinesFeatureCollection.write(outputLinesFile)

def evaluate_amount_of_continental_GDU_cut_at_each_line_of_latitude(rotation_file, latitude_lines_feature_file, interval_lat, kinematic_line_feature_file, modified_rift_pt_feature_file, threshold_diff_paleo_lat, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, modelname, yearmonthday):
	print('Latitude_lines_feature_file:')
	print(latitude_lines_feature_file)
	latitude_lines_features_collection = pygplates.FeatureCollection(latitude_lines_feature_file)
	print('kinematic_line_feature_file:')
	print(kinematic_line_feature_file)
	kinematic_line_features_collection = pygplates.FeatureCollection(kinematic_line_feature_file)
	print('modified_rift_pt_feature_file:')
	print(modified_rift_pt_feature_file)
	mor_pt_features_collection = pygplates.FeatureCollection(modified_rift_pt_feature_file)
	print('Rotation file:')
	print(rotation_file)
	rotation_model = pygplates.RotationModel(rotation_file)
	
	output_records_of_intersecting_features = {'reconstruction_time':[],'latitude':[],'polylid':[],'type':[]}
	output_records_of_each_type_of_intersecting_kin_feat = {'reconstruction_time':[],'latitude':[],'total_kin_ft':[],'count':[],'type':[],'ratio':[],'pct':[]}
	
	reconstruction_time = begin_reconstruction_time
	reconstructed_latitude_features = []
	reconstructed_kinematic_features = []
	reconstructed_mor_pt_features = []
	intersecting_kin_feats = []
	geometries_inside = []
	geometries_outside = []
	while (reconstruction_time >= end_reconstruction_time):
		reconstructed_kinematic_features[:] = []
		reconstructed_mor_pt_features[:] = []
		reconstructed_latitude_features[:] = []
		
		intersecting_kin_feats[:] = []
		valid_kinematic_line_feats = [line_ft for line_ft in kinematic_line_features_collection if line_ft.is_valid_at_time(reconstruction_time)]
		valid_mor_feats = [mor_ft for mor_ft in mor_pt_features_collection if mor_ft.is_valid_at_time(reconstruction_time)]
		if (reference is not None):
			pygplates.reconstruct(valid_kinematic_line_feats, rotation_model, reconstructed_kinematic_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(valid_mor_feats, rotation_model, reconstructed_mor_pt_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(latitude_lines_features_collection, rotation_model, reconstructed_latitude_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_kinematic_line_feats, rotation_model, reconstructed_kinematic_features, reconstruction_time, group_with_feature = True)
			pygplates.reconstruct(valid_mor_feats, rotation_model, reconstructed_mor_pt_features, reconstruction_time, group_with_feature = True)
			pygplates.reconstruct(latitude_lines_features_collection, rotation_model, reconstructed_latitude_features, reconstruction_time, group_with_feature = True)
		
		final_reconstructed_latitude_features = find_final_reconstructed_geometries(reconstructed_latitude_features, pygplates.PolylineOnSphere)
		final_reconstructed_kinematic_features = find_final_reconstructed_geometries(reconstructed_kinematic_features, pygplates.PolylineOnSphere)
		final_reconstructed_mor_features = find_final_reconstructed_geometries(reconstructed_mor_pt_features, pygplates.PointOnSphere)
		for lat_feat, reconstructed_lat_geometry in final_reconstructed_latitude_features:
			lat_reconstructed_geometry = reconstructed_lat_geometry
			
			total_num_intersecting_passive_div_feat = 0
			total_num_intersecting_conv_feat = 0
			total_num_intersecting_upper_feat = 0
			total_num_intersecting_trans_feat = 0
			total_num_intersecting_plate_bdn_zone_feat = 0
			total_num_of_kin_feat_at_time = len(final_reconstructed_kinematic_features)
			total_num_mor_pt_feat = 0
			latitude_value = lat_feat.get_description()
			#print "latitude_value"
			#print latitude_value
			
			lat_in_degree = float(latitude_value)
			#radius_at_lat = calculate_radius_of_the_small_circle_at_latitude(lat_in_degree)
			intersecting_kin_feats[:] = []
			for kin_feat, reconstructed_kin_geometry in final_reconstructed_kinematic_features:
				result = pygplates.GeometryOnSphere.distance(reconstructed_kin_geometry, reconstructed_lat_geometry)
				if (result == 0.00):
					intersecting_kin_feats.append((kin_feat, reconstructed_kin_geometry))
				#debug
				# if ((latitude_value == "-89.0" and reconstruction_time == 0.00) or (latitude_value == "-88.0" and reconstruction_time == 0.00)):
					# print "Result of partition"
					# print result
					# print "geometries_inside"
					# print geometries_inside
					# print "geometries_outside"
					# print geometries_outside
			if (len(intersecting_kin_feats) > 0):
				#debug
				# if ((latitude_value == "-89.0" and reconstruction_time == 0.00) or (latitude_value == "-88.0" and reconstruction_time == 0.00)):
					# print "Result of partition"
					# print result
					# print "geometries_inside"
					# print geometries_inside
					# print "geometries_outside"
					# print geometries_outside
				for kin_feat, each_geometry in intersecting_kin_feats:
					if (kin_feat.get_description() == 'convergent_margin'):
						total_num_intersecting_conv_feat = total_num_intersecting_conv_feat + 1
					elif (kin_feat.get_description() == 'divergent_margin'):
						total_num_intersecting_passive_div_feat = total_num_intersecting_passive_div_feat + 1
					elif (kin_feat.get_description() == 'plate_boundary_zone'):
						total_num_intersecting_plate_bdn_zone_feat = total_num_intersecting_plate_bdn_zone_feat + 1
					elif (kin_feat.get_description() == 'transform_fault'):
						total_num_intersecting_trans_feat = total_num_intersecting_trans_feat + 1
					elif (kin_feat.get_description() == 'upper_plate_margin'):
						total_num_intersecting_upper_feat = total_num_intersecting_upper_feat + 1
					
					output_records_of_intersecting_features['reconstruction_time'].append(reconstruction_time)
					output_records_of_intersecting_features['latitude'].append(lat_in_degree)
					output_records_of_intersecting_features['polylid'].append(kin_feat.get_name())
					output_records_of_intersecting_features['type'].append(kin_feat.get_description())
					
						#debug
						# if ((latitude_value == "24.0" and reconstruction_time == 372.00) or (latitude_value == "23.0" and reconstruction_time == 386.00)):
							# print "geometries_inside"
							# print geometries_inside
							# suspecting_intersecting_geometries.append(ft)
						# if ((latitude_value == "89.0" and reconstruction_time == 60.00)):
							# print "geometries_inside"
							# print each_geometry.get_arc_length()
							# print each_geometry.to_lat_lon_list()
							# suspecting_intersecting_geometries.append(ft)
						# if ((polygon_feat.get_reconstruction_plate_id() == 11224 and reconstruction_time == 0.00 and latitude_value == "-88.0")):
							# print "geometries_inside"
							# print each_geometry.get_arc_length()
							# print each_geometry.to_lat_lon_list()
							# suspecting_intersecting_geometries.append(ft)
						
					#arc_length_in_rad = each_geometry.get_arc_length()
					
					#distance = calculate_the_actual_length_of_a_line_feature_in_km_at_latitude(each_geometry)
					
					#debug 
					# if ((latitude_value == "-89.1" and reconstruction_time == 0.00) or (latitude_value == "-88.1" and reconstruction_time == 0.00)):
						# #print "segments"
						# #print each_geometry.get_segments()
						# total_length = 0
						# for s in each_geometry.get_segments():
							# total_length = total_length + s.get_arc_length()
							#print s.get_start_point()
							#print s.get_end_point()
							#print s.get_arc_length()
							# temp = pygplates.PolylineOnSphere([s.get_start_point(),s.get_end_point()])
							# new_segment_ft = pygplates.Feature.create_reconstructable_feature(featType,temp,valid_time = (reconstruction_time,reconstruction_time-(interval*0.1)),reconstruction_plate_id = polygon_feat.get_reconstruction_plate_id())
							# #reverse_reconstruct
							# if (reference is None):
								# pygplates.reverse_reconstruct(new_segment_ft,rotation_model,reconstruction_time)
							# else:
								# pygplates.reverse_reconstruct(new_segment_ft,rotation_model,reconstruction_time,reference)
							# suspecting_intersecting_geometries.append(new_segment_ft)
						#print "total_length of all segments"
						#print total_length
						#print "each_geometry.get_arc_length()"
						#print each_geometry.get_arc_length()
						# print "Here is arc_length_in_rad"
						# print arc_length_in_rad
						# print "Here is value of distance"
						# print distance
							
						#debug 
						# total_arc_length_in_rad = total_arc_length_in_rad + arc_length_in_rad
						
					#for all latitude at present 
					# if (reconstruction_time == 0.00):
						# total_amount_of_crust_at_present = total_amount_of_crust_at_present + distance
				
				output_records_of_each_type_of_intersecting_kin_feat['reconstruction_time'].append(reconstruction_time)
				output_records_of_each_type_of_intersecting_kin_feat['latitude'].append(lat_in_degree)
				output_records_of_each_type_of_intersecting_kin_feat['total_kin_ft'].append(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['count'].append(total_num_intersecting_conv_feat)
				output_records_of_each_type_of_intersecting_kin_feat['type'].append('convergent_margin')
				ratio = float(total_num_intersecting_conv_feat)/float(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['ratio'].append(ratio)
				output_records_of_each_type_of_intersecting_kin_feat['pct'].append(ratio*100.00)
				
				output_records_of_each_type_of_intersecting_kin_feat['reconstruction_time'].append(reconstruction_time)
				output_records_of_each_type_of_intersecting_kin_feat['latitude'].append(lat_in_degree)
				output_records_of_each_type_of_intersecting_kin_feat['total_kin_ft'].append(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['count'].append(total_num_intersecting_passive_div_feat)
				output_records_of_each_type_of_intersecting_kin_feat['type'].append('divergent_margin')
				ratio = float(total_num_intersecting_passive_div_feat)/float(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['ratio'].append(ratio)
				output_records_of_each_type_of_intersecting_kin_feat['pct'].append(ratio*100.00)
				
				output_records_of_each_type_of_intersecting_kin_feat['reconstruction_time'].append(reconstruction_time)
				output_records_of_each_type_of_intersecting_kin_feat['latitude'].append(lat_in_degree)
				output_records_of_each_type_of_intersecting_kin_feat['total_kin_ft'].append(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['count'].append(total_num_intersecting_plate_bdn_zone_feat)
				output_records_of_each_type_of_intersecting_kin_feat['type'].append('plate_boundary_zone')
				ratio = float(total_num_intersecting_plate_bdn_zone_feat)/float(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['ratio'].append(ratio)
				output_records_of_each_type_of_intersecting_kin_feat['pct'].append(ratio*100.00)
				
				output_records_of_each_type_of_intersecting_kin_feat['reconstruction_time'].append(reconstruction_time)
				output_records_of_each_type_of_intersecting_kin_feat['latitude'].append(lat_in_degree)
				output_records_of_each_type_of_intersecting_kin_feat['total_kin_ft'].append(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['count'].append(total_num_intersecting_upper_feat)
				output_records_of_each_type_of_intersecting_kin_feat['type'].append('upper_plate_margin')
				ratio = float(total_num_intersecting_upper_feat)/float(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['ratio'].append(ratio)
				output_records_of_each_type_of_intersecting_kin_feat['pct'].append(ratio*100.00)
				
				output_records_of_each_type_of_intersecting_kin_feat['reconstruction_time'].append(reconstruction_time)
				output_records_of_each_type_of_intersecting_kin_feat['latitude'].append(lat_in_degree)
				output_records_of_each_type_of_intersecting_kin_feat['total_kin_ft'].append(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['count'].append(total_num_intersecting_trans_feat)
				output_records_of_each_type_of_intersecting_kin_feat['type'].append('transform_fault')
				ratio = float(total_num_intersecting_trans_feat)/float(total_num_of_kin_feat_at_time)
				output_records_of_each_type_of_intersecting_kin_feat['ratio'].append(ratio)
				output_records_of_each_type_of_intersecting_kin_feat['pct'].append(ratio*100.00)
			
			for mor_pt_ft, mor_pt in final_reconstructed_mor_features:
				paleo_lat, paleo_lon = mor_pt.to_lat_lon()
				diff_paleo_lat = abs(lat_in_degree - paleo_lat)
				if (diff_paleo_lat <= threshold_diff_paleo_lat):
					total_num_mor_pt_feat = total_num_mor_pt_feat + 1
			output_records_of_each_type_of_intersecting_kin_feat['reconstruction_time'].append(reconstruction_time)
			output_records_of_each_type_of_intersecting_kin_feat['latitude'].append(lat_in_degree)
			output_records_of_each_type_of_intersecting_kin_feat['total_kin_ft'].append(total_num_of_kin_feat_at_time)
			output_records_of_each_type_of_intersecting_kin_feat['count'].append(total_num_mor_pt_feat)
			output_records_of_each_type_of_intersecting_kin_feat['type'].append('mor')
			ratio = float(total_num_mor_pt_feat)/float(total_num_of_kin_feat_at_time)
			output_records_of_each_type_of_intersecting_kin_feat['ratio'].append(ratio)
			output_records_of_each_type_of_intersecting_kin_feat['pct'].append(ratio*100.00)
		reconstruction_time = reconstruction_time - time_interval
	output_kin_intersecting_dataframe = pd.DataFrame.from_dict(output_records_of_each_type_of_intersecting_kin_feat)
	filename = 'records_of_each_type_of_intersecting_kin_feat_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.csv'
	output_kin_intersecting_dataframe.to_csv(filename,index=False)
	
	output_kin_intersecting_dataframe = pd.DataFrame.from_dict(output_records_of_intersecting_features)
	filename = 'records_of_each_intersecting_kin_feat_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.csv'
	output_kin_intersecting_dataframe.to_csv(filename,index=False)

if __name__== '__main__':
	start_lat = -89.00
	end_lat = 89.00
	interval_lat = 3.00
	spin_axis_ref = 700
	is_output_shp = True
	yyyymmdd = '20231218'
	#construct_lines_of_latitude_v1_at_interval_of(start_lat,end_lat,interval_lat,spin_axis_ref,is_output_shp,yyyymmdd)
	
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	latitude_lines_feature_file = r"Latitudes_-89.0_89.0_3.0_spin_axis_ref_700_20231218.shp"
	interval_lat = 2.00
	#kinematic_line_feature_file = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\all_kin_line_feats_PalaeoPlatesendJan2023_from_2800.0_0.0.0_late_Oct_2023_20231218.shp"
	kinematic_line_feature_file = r"all_kin_line_feats_PalaeoPlatesendJan2023_from_2800.0_0.0.0_late_Oct_2023_20231218.shp"
	modified_rift_pt_feature_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	threshold_diff_paleo_lat = 0.850
	begin_reconstruction_time = 2800.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	reference = 700
	model_name = "raw_data_PalaeoPlatesendJan2023"
	yearmonthday = "20231220"
	evaluate_amount_of_continental_GDU_cut_at_each_line_of_latitude(rotation_file, latitude_lines_feature_file, interval_lat, kinematic_line_feature_file, modified_rift_pt_feature_file, threshold_diff_paleo_lat, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, model_name, yearmonthday)