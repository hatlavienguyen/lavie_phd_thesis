from multiprocessing import Pool
from os import environ
from os import path
from time import sleep
import pygplates
import create_topological_isochron_and_estimate_MOR as topological

# def create_isochron_from_temp_rift_point_features_within_a_period(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	# modelname = "test_22_PalaeoPlatesJan2023_fts_from_early_July_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	# create_remnant.create_isochron_from_temp_rift_point_features(temp_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
# rotation_model = pygplates.RotationModel(rotation_file)
# rift_point_features_records_csv = r"rift_point_features_records_for_test_21_short_PalaeoPlatesendJan2023_w_1_deg_20230713.csv"
# div_margin_feats_file = r"diverging_line_features_for__3410.0_5.0_test_21_short_PalaeoPlatesendJan2023_w_1_deg_20230713.shp"
# div_margin_features = pygplates.FeatureCollection(div_margin_feats_file)
# rift_point_features_file = r"modified_end_age_of_rift_point_features_for_3420_0Ma_test_25_short_PalaeoPlatesendJan2023_w_1_deg_20230804.shp"
# rift_point_features = pygplates.FeatureCollection(rift_point_features_file)
# modelname = "isochron_test_26_PalaeoPlatesJan2023_fts_from_late_July"
# yearmonthday = "20240308"
# reference = 700

#PalaeoPlatesendJan2023
common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)

#rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
#rift_point_features_file = r"modified_end_age_rift_point_features_from_unrelated_SGDU_for_test_2_PalaeoPlatesendJan2023_20240216.shp"

#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_and_sgdu_2800.0_test_29_PalaeoPlatesendJan2023_fts_20240304.shp"
rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kin_records_and_sgdu_2800.0_v3_test_29_PalaeoPlatesendJan2023_fts_20240407.shp"
#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_and_sgdu_2800.0_test_3_unrelated_SGDU_PalaeoPlatesendJan2023_fts_20240305.shp"
#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_and_sgdu_2800.0_test_4_unrelated_SGDU_ynger_PalaeoPlatesendJan2023_fts_20240305.shp"
#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_and_sgdu_2800.0_test_3_unrelated_subseq_SGDU_PalaeoPlatesendJan2023_fts_20240305.shp"
#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_and_sgdu_2800.0_test_4_unrelated_subseq_SGDU_ynger_PalaeoPlatesendJan2023_fts_20240305.shp"
rift_point_features = pygplates.FeatureCollection(rift_point_features_file)

#div_margin_feats_file = r"extract_features_based_on_descriptiondivergent_margin_PalaeoPlatesendJan2023_2800_5Ma_from_test_29_identify_div_bdn_20231106.shp"
#div_margin_feats_file = r"additional_kin_line_features_from_unrelated_SGDU_for_2800.0_5.0_test_2_PalaeoPlatesendJan2023_20240216.shp"

div_margin_feats_file = r"all_div_margin_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240304.shp"
div_margin_features = pygplates.FeatureCollection(div_margin_feats_file)
#margin_feats_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_segment_POLYGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230921.shp"
#margin_features = pygplates.FeatureCollection(margin_feats_file)
#temp_unwanted_rift_point_features_file = r"unwanted_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
#temp_unwanted_rift_point_features = pygplates.FeatureCollection(temp_unwanted_rift_point_features_file)

#old rift
#rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_2_PalaeoPlatesendJan2023_20240216.csv"

rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
#rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.csv"
#rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.csv"
#rift_point_features_records_csv = r"subseq_rift_point_features_records_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.csv"
#rift_point_features_records_csv = r"subseq_rift_point_features_records_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.csv"

plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
#plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)

yearmonthday = "20240409"
reference = 700
time_interval = 5.00

#Merdith et al 2021
# common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/supergdu_and_members_gdu_at_{time}_for_Merdith_et_al_EB2021_20230428.csv"
# sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/final_supergdu_feats_995.0_0.0_Merdith_et_al_EB2021_20230428.shp"
# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/1000_0_rotfile_Merdith_et_al.rot"
# rotation_model = pygplates.RotationModel(rotation_file)
# # temp_rift_point_features_file = r"rift_point_features_for_test_8_EB2022_20231020.shp"
# # temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
# div_margin_feats_file = r"extract_features_based_on_descriptiondivergent_margin_EB2022_995_0Ma_from_test_8_identify_div_bdn_20231106.shp"
# div_margin_features = pygplates.FeatureCollection(div_margin_feats_file)
# rift_point_features_file = r"modified_end_age_for_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
# rift_point_features = pygplates.FeatureCollection(rift_point_features_file)
# rift_point_features_records_csv = r"rift_point_features_records_for_test_8_EB2022_20231020.csv"
# plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_EB2022_20231023.shp"
# plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
# yearmonthday = "20231106"
# reference = 0
# time_interval = 5.00

ncpus = int(environ['SLURM_CPUS_PER_TASK'])
def calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval):
	max_min_rec_time_list = []
	value = maximum_of_reconstruction_period
	while (value >= minimum_of_reconstruction_period):
		min_recon = value - reconstruction_interval
		max_min_rec_time_list.append((value,min_recon))
		value = min_recon
	return max_min_rec_time_list

def create_topological_isochron_from_temp_isochron_point_feats_within_a_period(maximum_reconstruction_time, minimum_reconstruction_time):
	common_input_point_features_filename = r"isochron_right_point_features_test_26_PalaeoPlatesJan2023_fts_from_late_July_max_{max_time}_{min_time}_20230802.shp"
	input_point_features_file = common_input_point_features_filename.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
	input_point_features = pygplates.FeatureCollection(input_point_features_file)
	age_interval_for_isochron_fts = 5.00
	topological.create_isochron_from_temp_isochron_point_features(input_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, modelname, yearmonthday)

def create_oceanic_crust_feats_from_temp_isochron_point_feats_within_a_period(maximum_reconstruction_time, minimum_reconstruction_time):
	#common_input_point_features_filename = r"isochron_right_point_features_v2_test_29_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20231102.shp"
	common_input_point_features_filename = r"isochron_right_point_features_test_8_EB2022_fts_max_{max_time}_{min_time}_20231029.shp"
	input_point_features_file = common_input_point_features_filename.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
	right_input_point_features = pygplates.FeatureCollection(input_point_features_file)

	#common_input_point_features_filename = r"isochron_left_point_features_v2_test_29_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20231102.shp"
	common_input_point_features_filename = r"isochron_left_point_features_test_8_EB2022_fts_max_{max_time}_{min_time}_20231029.shp"
	input_point_features_file = common_input_point_features_filename.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
	left_input_point_features = pygplates.FeatureCollection(input_point_features_file)
	modelname = "test_8_EB2022"
	age_interval_for_isochron_fts = 5.00
	topological.create_oceanic_crust_from_rift_and_isochron_point_features(div_margin_features, left_input_point_features, right_input_point_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday)

def create_oceanic_crust_feats_for_gdus_from_temp_isochron_point_feats_within_a_period(maximum_reconstruction_time, minimum_reconstruction_time):
	#common_input_point_features_filename = r"isochron_right_point_features_v2_test_29_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20231102.shp"
	#common_input_point_features_filename = r"isochron_right_point_features_test_8_EB2022_fts_max_{max_time}_{min_time}_20231029.shp"
	#common_input_point_features_filename = r"isochron_right_point_features_test_2_additional_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240217.shp"
	
	#original
	common_input_point_features_filename = r"isochron_right_point_features_v3_test_29_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240408.shp"
	#test_3_unrelated_SGDU
	#common_input_point_features_filename = r"isochron_right_point_features_test_3_unrelated_SGDU_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240302.shp"
	#test_4_unrelated_SGDU
	#common_input_point_features_filename = r"isochron_right_point_features_test_4_unrelated_SGDU_ynger_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240302.shp"
	#test_3_subseq_unrelated_SGDU
	#common_input_point_features_filename = r"isochron_right_point_features_test_3_unrelated_subseq_SGDU_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240302.shp"
	#test_4_subseq_unrelated_SGDU
	#common_input_point_features_filename = r"isochron_right_point_features_test_4_unrelated_subseq_SGDU_ynger_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240302.shp"
	
	input_point_features_file = common_input_point_features_filename.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
	right_input_point_features = None
	if (path.isfile(input_point_features_file)):
		right_input_point_features = pygplates.FeatureCollection(input_point_features_file)

	#common_input_point_features_filename = r"isochron_left_point_features_v2_test_29_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20231102.shp"
	#common_input_point_features_filename = r"isochron_left_point_features_test_8_EB2022_fts_max_{max_time}_{min_time}_20231029.shp"
	#common_input_point_features_filename = r"isochron_left_point_features_test_2_additional_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240217.shp"
	
	#original
	common_input_point_features_filename = r"isochron_left_point_features_v3_test_29_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240408.shp"
	#test_3_unrelated_SGDU
	#common_input_point_features_filename = r"isochron_left_point_features_test_3_unrelated_SGDU_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240302.shp"
	#test_4_unrelated_SGDU
	#common_input_point_features_filename = r"isochron_left_point_features_test_4_unrelated_SGDU_ynger_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240302.shp"
	#test_3_subseq_unrelated_SGDU
	#common_input_point_features_filename = r"isochron_left_point_features_test_3_unrelated_subseq_SGDU_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240302.shp"
	#test_4_subseq_unrelated_SGDU
	#common_input_point_features_filename = r"isochron_left_point_features_test_4_unrelated_subseq_SGDU_ynger_PalaeoPlatesendJan2023_fts_max_{max_time}_{min_time}_20240302.shp"
	
	input_point_features_file = common_input_point_features_filename.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
	left_input_point_features = None
	if (path.isfile(input_point_features_file)):
		left_input_point_features = pygplates.FeatureCollection(input_point_features_file)
	
	modelname = "v3_test_29_PalaeoPlatesendJan2023"
	# modelname = "test_3_unrelated_SGDU_PalaeoPlatesendJan2023"
	#modelname = "test_4_unrelated_SGDU_ynger_PalaeoPlatesendJan2023"
	# modelname = "test_3_unrelated_subseq_SGDU_PalaeoPlatesendJan2023"
	# modelname = "test_4_unrelated_subseq_SGDU_ynger_PalaeoPlatesendJan2023"
	
	age_interval_for_isochron_fts = 5.00
	
	#initial rift point features from continental rifts
	if (left_input_point_features is not None and right_input_point_features is not None):
		topological.create_oceanic_crust_from_rift_and_isochron_point_features_w_distinct_pairs_of_sgdus(div_margin_features, left_input_point_features, right_input_point_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday)

	#rift point features from oceanic-oceanic rift
	common_filename_for_temp_div_margin_features_file = r"additional_diverging_line_features_for_{max_age}_{min_age}_PalaeoPlatesendJan2023_20240206.shp"
	temp_div_margin_features_file = common_filename_for_temp_div_margin_features_file.format(max_age = str(maximum_reconstruction_time), min_age = str(minimum_reconstruction_time))
	#temp_div_margin_features = pygplates.FeatureCollection(temp_div_margin_features_file)
	#common_filename_for_temp_rift_point_features = r"additional_rift_point_features_for_{max_age}_{min_age}_PalaeoPlatesendJan2023_fts_max_{max_age}_{min_age}_20240118.shp"
	# common_filename_for_temp_rift_point_features = r"~/Geology/Research/Winter2023/PalaeoPlatesendJan2023/utility/modified_end_age_additional_rift_point_features_2_for_PalaeoPlatesendJan2023_fts_max_{max_age}_{min_age}_20240207.shp"
	# filename_for_temp_rift_point_features = common_filename_for_temp_rift_point_features.format(max_age = str(maximum_reconstruction_time), min_age = str(minimum_reconstruction_time))
	filename_for_temp_rift_point_features = r"modified_end_age_of_rift_point_fts_based_on_spatial_rlx_with_polygon_fts_2800.0_0.0_test_2_additional_rift_with_sgdu_PalaeoPlatesendJan2023_fts_max__20240208.shp"
	#temp_rift_point_features_for_interval = pygplates.FeatureCollection(filename_for_temp_rift_point_features)
	common_filename_for_temp_rift_point_records = r"additional_rift_point_features_records_for_{max_age}_{min_age}_PalaeoPlatesendJan2023_20240206.csv"
	temp_rift_point_features_records_csv = common_filename_for_temp_rift_point_records.format(max_age = str(maximum_reconstruction_time), min_age = str(minimum_reconstruction_time))
	#topological.create_oceanic_crust_from_rift_and_isochron_point_features_w_distinct_pairs_of_sgdus(temp_div_margin_features, left_input_point_features, right_input_point_features, temp_rift_point_features_for_interval, temp_rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday)

def extend_boundary_of_each_sgdu_from_rift_point_features(maximum_reconstruction_time, minimum_reconstruction_time):
	modelname = "test_29_PalaeoPlatesendJan2023"
	#modelname = "test_3_unrelated_SGDU_PalaeoPlatesendJan2023"
	#modelname = "test_4_unrelated_SGDU_ynger_PalaeoPlatesendJan2023"
	# modelname = "test_3_unrelated_subseq_SGDU_PalaeoPlatesendJan2023"
	# modelname = "test_4_unrelated_subseq_SGDU_ynger_PalaeoPlatesendJan2023"
	
	age_interval_for_isochron_fts = 5.00

	topological.extend_boundary_of_each_sgdu_from_rift_point_features_w_distinct_pairs_of_sgdus(margin_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday)


def modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features_for_entire_model(maximum_reconstruction_time, minimum_reconstruction_time):
	#common_filename_for_oceanic_crust_features_file = r"oceanic_crust_for_gdus_from_rift_and_isochron_feats_with_max_star_div_age_{max_time}_min_{min_time}_test_29_PalaeoPlatesendJan2023_20240321.shp"
	common_filename_for_oceanic_crust_features_file = r"oceanic_crust_for_gdus_from_rift_and_isochron_feats_with_max_star_div_age_{max_time}_min_{min_time}_v3_test_29_PalaeoPlatesendJan2023_20240409.shp"
	oceanic_crust_features_file = common_filename_for_oceanic_crust_features_file.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
	oceanic_crust_features = pygplates.FeatureCollection(oceanic_crust_features_file)
	#for original oceanic crust features
	modelname = "v3_test_29_PalaeoPlatesendJan2023"
	#modelname = "test_3_unrelated_SGDU_PalaeoPlatesendJan2023"
	#modelname = "test_4_unrelated_SGDU_ynger_PalaeoPlatesendJan2023"
	# modelname = "test_3_unrelated_subseq_SGDU_PalaeoPlatesendJan2023"
	# modelname = "test_4_unrelated_subseq_SGDU_ynger_PalaeoPlatesendJan2023"
	topological.modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features(common_filename_for_temporary_sgdu_and_members_csv, rift_point_features_records_csv, oceanic_crust_features, sgdu_features, rotation_model, reference, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, modelname, yearmonthday)
	
	#common_filename_for_temp_rift_point_records = r"additional_rift_point_features_records_for_{max_age}_{min_age}_PalaeoPlatesendJan2023_20240206.csv"
	#temp_rift_point_features_records_csv = common_filename_for_temp_rift_point_records.format(max_age = str(maximum_reconstruction_time), min_age = str(minimum_reconstruction_time))
	# modelname = "test_29_PalaeoPlatesendJan2023"
	# topological.modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features(common_filename_for_temporary_sgdu_and_members_csv, temp_rift_point_features_records_csv, oceanic_crust_features, sgdu_features, rotation_model, reference, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, modelname, yearmonthday)
	#topological.modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features_based_on_spatial_rlxn_with_any_sgdu(temp_rift_point_features_records_csv, oceanic_crust_features, sgdu_features, rotation_model, reference, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, modelname, yearmonthday)


if __name__ == '__main__':
	maximum_of_reconstruction_period = 2800.00
	minimum_of_reconstruction_period = 200.00
	reconstruction_interval = 200.00
	max_min_rec_time_list = calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval)

	with Pool(ncpus) as pool:
		#results = pool.starmap(create_oceanic_crust_feats_from_temp_isochron_point_feats_within_a_period, max_min_rec_time_list)
		#results = pool.starmap(create_oceanic_crust_feats_for_gdus_from_temp_isochron_point_feats_within_a_period, max_min_rec_time_list)
		results = pool.starmap(modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features_for_entire_model, max_min_rec_time_list)
		#results = pool.starmap(extend_boundary_of_each_sgdu_from_rift_point_features, max_min_rec_time_list)
		print(results)
