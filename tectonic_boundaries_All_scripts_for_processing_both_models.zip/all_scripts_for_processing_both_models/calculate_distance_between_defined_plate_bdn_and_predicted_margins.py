import os
import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import math


def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries
def find_stage_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,from_time,to_time,reference_frame):
	"""
	Relative stage reconstruction is a reconstruction from any from_time to any to_time between any two GDUIDS
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		#print('moving_plate_id')
		#print(moving_plate_id)
		#print('fixed_plate_id')
		#print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		#print("Euler_pole,angle_rads")
		#print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		#print("lat,lon,angle_degrees")
		#print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		#print("Warning in find_rift_segment_and_transform_faults")
		#print("Warning finite_rotation_1 is identity")
		#print(moving_plate_id, fixed_plate_id, reference_frame)
		#print("from_time,to_time")
		#print(from_time,to_time)
		# print('moving_plate_id')
		# print(moving_plate_id)
		# print('fixed_plate_id')
		# print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		# print("Euler_pole,angle_rads")
		# print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		# print("lat,lon,angle_degrees")
		# print(lat,lon,angle_degrees)
		return finite_rotation_1

def calculate_distance_between_defined_MOR_ft_and_center_of_MOR_point_fts(MOR_line_fts, center_of_MOR_point_fts, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	output_dic = {'reconstruction_time':[],'total_dist_rads':[],'total_dist_kms':[],'number_of_matching_point_ft':[],'number_of_matching_line_ft':[],'number_of_line_ft':[],'rmse':[]}
	list_of_valid_MOR_fts = []
	list_of_valid_center_of_MOR_fts = []
	reconstructed_line_features = []
	reconstructed_point_features = []
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		list_of_valid_MOR_fts = [MOR_ft for MOR_ft in MOR_line_fts if MOR_ft.is_valid_at_time(reconstruction_time)]
		list_of_valid_center_of_MOR_fts = [point_ft for point_ft in center_of_MOR_point_fts if point_ft.is_valid_at_time(reconstruction_time)]
		reconstructed_line_features[:] = []
		print("reconstruction_time",reconstruction_time)
		if (len(list_of_valid_center_of_MOR_fts) > 0):
			reconstructed_point_features[:] = []
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_MOR_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(list_of_valid_center_of_MOR_fts,rotation_model,reconstructed_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_MOR_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
				pygplates.reconstruct(list_of_valid_center_of_MOR_fts,rotation_model,reconstructed_point_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_line_fts = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			final_reconstructed_point_fts = find_final_reconstructed_geometries(reconstructed_point_features,pygplates.PointOnSphere)
			
			#find the closest line ft for each point ft
			total_dist_rads = 0.00
			number_of_matching_point_feat = 0
			list_of_matching_line_feat = []
			for point_ft, reconstructed_point in final_reconstructed_point_fts:
				minimum_dist = -1.00
				closest_line_ft,closest_line = None,None
				left_GDUID_for_pt_ft = point_ft.get_left_plate()
				right_GDUID_for_pt_ft = point_ft.get_right_plate()
				#spatial distance BUT also need to check for stage rotation like SuperGDU
				for line_ft, reconstructed_line in final_reconstructed_line_fts:
					left_GDUID_for_line_ft = line_ft.get_left_plate()
					right_GDUID_for_line_ft = line_ft.get_right_plate()
					#SHOULD Check for stage rotation here
					is_same_rot = False
					total_stage_rel_rot_of_left_point_to_left_line = find_stage_relative_reconstruction_rotation_(rotation_model,left_GDUID_for_pt_ft,left_GDUID_for_line_ft,reconstruction_time,reconstruction_time-time_interval,reference)
					lat,lon,angle_degrees = total_stage_rel_rot_of_left_point_to_left_line.get_lat_lon_euler_pole_and_angle_degrees()
					if (angle_degrees > 0.100):
						total_stage_rel_rot_of_left_point_to_right_line = find_stage_relative_reconstruction_rotation_(rotation_model,left_GDUID_for_pt_ft,right_GDUID_for_line_ft,reconstruction_time,reconstruction_time-time_interval,reference)
						lat,lon,angle_degrees = total_stage_rel_rot_of_left_point_to_right_line.get_lat_lon_euler_pole_and_angle_degrees()
						if (angle_degrees <= 0.100):
							is_same_rot = True
					else:
						is_same_rot = True
					if (is_same_rot == True):
						#reset is_same_rot
						is_same_rot = False
						total_stage_rel_rot_of_right_point_to_right_line = find_stage_relative_reconstruction_rotation_(rotation_model,right_GDUID_for_pt_ft,right_GDUID_for_line_ft,reconstruction_time,reconstruction_time-time_interval,reference)
						lat,lon,angle_degrees = total_stage_rel_rot_of_right_point_to_right_line.get_lat_lon_euler_pole_and_angle_degrees()
						if (angle_degrees > 0.100):
							total_stage_rel_rot_of_right_point_to_left_line = find_stage_relative_reconstruction_rotation_(rotation_model,right_GDUID_for_pt_ft,left_GDUID_for_line_ft,reconstruction_time,reconstruction_time-time_interval,reference)
							lat,lon,angle_degrees = total_stage_rel_rot_of_right_point_to_left_line.get_lat_lon_euler_pole_and_angle_degrees()
							if (angle_degrees <= 0.100):
								is_same_rot = True
						else:
							is_same_rot = True
						if (is_same_rot == True):
							#calculate distance 
							distance = pygplates.GeometryOnSphere.distance(reconstructed_line,reconstructed_point)
							if ((minimum_dist == -1.00) or (minimum_dist > 0.00 and distance < minimum_dist)):
								minimum_dist = distance
								closest_line_ft,closest_line = line_ft, reconstructed_line
						if (minimum_dist == 0.00):
							break
				if (minimum_dist >= 0.00):
					total_dist_rads = total_dist_rads + minimum_dist
					number_of_matching_point_feat = number_of_matching_point_feat + 1
					list_of_matching_line_feat.append(closest_line_ft.get_feature_id().get_string())
			output_dic['reconstruction_time'].append(reconstruction_time)
			output_dic['total_dist_rads'].append(total_dist_rads)
			output_dic['total_dist_kms'].append(total_dist_rads*pygplates.Earth.equatorial_radius_in_kms)
			output_dic['number_of_matching_point_ft'].append(number_of_matching_point_feat)
			series = pd.Series(list_of_matching_line_feat)
			unique_values = series.unique()
			output_dic['number_of_matching_line_ft'].append(len(unique_values))
			output_dic['number_of_line_ft'].append(len(list_of_valid_MOR_fts))
			output_dic['rmse'].append(math.sqrt((1.00/float(number_of_matching_point_feat))*(total_dist_rads*pygplates.Earth.equatorial_radius_in_kms)*(total_dist_rads*pygplates.Earth.equatorial_radius_in_kms)))
		elif (len(list_of_valid_MOR_fts) > 0 and len(list_of_valid_center_of_MOR_fts) == 0):
			output_dic['reconstruction_time'].append(reconstruction_time)
			output_dic['total_dist_rads'].append(-1.00)
			output_dic['total_dist_kms'].append(-1.00)
			output_dic['number_of_matching_point_ft'].append(0)
			output_dic['number_of_matching_line_ft'].append(0)
			output_dic['number_of_line_ft'].append(len(list_of_valid_MOR_fts))
			output_dic['rmse'].append(-1.00)
		reconstruction_time = reconstruction_time - time_interval
	output_df = pd.DataFrame(output_dic)
	output_df.to_csv("distance_between_defined_MOR_ft_and_center_of_MOR_point_fts_"+modelname+"_"+yearmonthday+".csv")

def calculate_distance_between_defined_subduction_zone_and_upper_plate_margins(subduction_line_fts, upper_plate_margins, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	output_dic = {'reconstruction_time':[],'total_dist_rads':[],'total_dist_kms':[],'number_of_matching_subduction_ft':[],'number_of_subduction_ft':[],'number_of_upper_plate_ft':[],'rmse':[]}
	list_of_valid_subduction_fts = []
	list_of_valid_upper_plate_fts = []
	reconstructed_subduction_features = []
	reconstructed_upper_plate_features = []
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		list_of_valid_subduction_fts = [subduction_ft for subduction_ft in subduction_line_fts if subduction_ft.is_valid_at_time(reconstruction_time)]
		list_of_valid_upper_plate_fts = [upper_ft for upper_ft in upper_plate_margins if upper_ft.is_valid_at_time(reconstruction_time) and upper_ft.get_description('upper_plate_margin')]
		reconstructed_subduction_features[:] = []
		reconstructed_upper_plate_features[:] = []
		print("reconstruction_time",reconstruction_time)
		if (len(list_of_valid_upper_plate_fts) > 0):
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_subduction_fts,rotation_model,reconstructed_subduction_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(list_of_valid_upper_plate_fts,rotation_model,reconstructed_upper_plate_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_subduction_fts,rotation_model,reconstructed_subduction_features,reconstruction_time,group_with_feature = True)
				pygplates.reconstruct(list_of_valid_upper_plate_fts,rotation_model,reconstructed_upper_plate_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_subduction_fts = find_final_reconstructed_geometries(reconstructed_subduction_features,pygplates.PolylineOnSphere)
			final_reconstructed_upper_fts = find_final_reconstructed_geometries(reconstructed_upper_plate_features,pygplates.PolylineOnSphere)
			
			#find the closest line ft for each point ft
			total_dist_rads = 0.00
			number_of_matching_point_feat = 0
			list_of_matching_line_feat = []
			for point_ft, reconstructed_point in final_reconstructed_upper_fts:
				minimum_dist = -1.00
				closest_line_ft,closest_line = None,None
				left_GDUID_for_pt_ft = point_ft.get_left_plate()
				right_GDUID_for_pt_ft = point_ft.get_right_plate()
				#spatial distance BUT also need to check for stage rotation like SuperGDU
				for line_ft, reconstructed_line in final_reconstructed_subduction_fts:
					left_GDUID_for_line_ft = line_ft.get_left_plate()
					right_GDUID_for_line_ft = line_ft.get_right_plate()
					#SHOULD Check for stage rotation here
					is_same_rot = False
					total_stage_rel_rot_of_left_point_to_left_line = find_stage_relative_reconstruction_rotation_(rotation_model,left_GDUID_for_pt_ft,left_GDUID_for_line_ft,reconstruction_time,reconstruction_time-time_interval,reference)
					lat,lon,angle_degrees = total_stage_rel_rot_of_left_point_to_left_line.get_lat_lon_euler_pole_and_angle_degrees()
					if (angle_degrees > 0.100):
						total_stage_rel_rot_of_left_point_to_right_line = find_stage_relative_reconstruction_rotation_(rotation_model,left_GDUID_for_pt_ft,right_GDUID_for_line_ft,reconstruction_time,reconstruction_time-time_interval,reference)
						lat,lon,angle_degrees = total_stage_rel_rot_of_left_point_to_right_line.get_lat_lon_euler_pole_and_angle_degrees()
						if (angle_degrees <= 0.100):
							is_same_rot = True
					else:
						is_same_rot = True
					if (is_same_rot == True):
						#reset is_same_rot
						is_same_rot = False
						total_stage_rel_rot_of_right_point_to_right_line = find_stage_relative_reconstruction_rotation_(rotation_model,right_GDUID_for_pt_ft,right_GDUID_for_line_ft,reconstruction_time,reconstruction_time-time_interval,reference)
						lat,lon,angle_degrees = total_stage_rel_rot_of_right_point_to_right_line.get_lat_lon_euler_pole_and_angle_degrees()
						if (angle_degrees > 0.100):
							total_stage_rel_rot_of_right_point_to_left_line = find_stage_relative_reconstruction_rotation_(rotation_model,right_GDUID_for_pt_ft,left_GDUID_for_line_ft,reconstruction_time,reconstruction_time-time_interval,reference)
							lat,lon,angle_degrees = total_stage_rel_rot_of_right_point_to_left_line.get_lat_lon_euler_pole_and_angle_degrees()
							if (angle_degrees <= 0.100):
								is_same_rot = True
						else:
							is_same_rot = True
						if (is_same_rot == True):
							#calculate distance 
							distance = pygplates.GeometryOnSphere.distance(reconstructed_line,reconstructed_point)
							if ((minimum_dist == -1.00) or (minimum_dist > 0.00 and distance < minimum_dist)):
								minimum_dist = distance
								closest_line_ft,closest_line = line_ft, reconstructed_line
						if (minimum_dist == 0.00):
							break
				if (minimum_dist >= 0.00):
					total_dist_rads = total_dist_rads + minimum_dist
					number_of_matching_point_feat = number_of_matching_point_feat + 1
					list_of_matching_line_feat.append(closest_line_ft.get_feature_id().get_string())
			output_dic['reconstruction_time'].append(reconstruction_time)
			output_dic['total_dist_rads'].append(total_dist_rads)
			output_dic['total_dist_kms'].append(total_dist_rads*pygplates.Earth.equatorial_radius_in_kms)
			#output_dic['number_of_matching_point_ft'].append(number_of_matching_point_feat)
			series = pd.Series(list_of_matching_line_feat)
			unique_values = series.unique()
			output_dic['number_of_matching_subduction_ft'].append(len(unique_values))
			output_dic['number_of_subduction_ft'].append(len(list_of_valid_subduction_fts))
			output_dic['number_of_upper_plate_ft'].append(len(list_of_valid_upper_plate_fts))
			output_dic['rmse'].append(math.sqrt((1.00/float(number_of_matching_point_feat))*(total_dist_rads*pygplates.Earth.equatorial_radius_in_kms)*(total_dist_rads*pygplates.Earth.equatorial_radius_in_kms)))
		elif (len(list_of_valid_subduction_fts) > 0 and len(list_of_valid_upper_plate_fts) == 0):
			output_dic['reconstruction_time'].append(reconstruction_time)
			output_dic['total_dist_rads'].append(-1.00)
			output_dic['total_dist_kms'].append(-1.00)
			#output_dic['number_of_matching_point_ft'].append(0)
			output_dic['number_of_matching_subduction_ft'].append(0)
			output_dic['number_of_subduction_ft'].append(len(list_of_valid_subduction_fts))
			output_dic['number_of_upper_plate_ft'].append(len(list_of_valid_upper_plate_fts))
			output_dic['rmse'].append(-1.00)
		reconstruction_time = reconstruction_time - time_interval
	output_df = pd.DataFrame(output_dic)
	output_df.to_csv("distance_between_defined_subduction_zone_and_upper_plate_margins_"+modelname+"_"+yearmonthday+".csv")


if __name__=="__main__":
	MOR_line_fts_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\extract_features_based_on_featType_Merdith_et_al_2021_mor_1000_0Ma_20240413.shp"
	#MOR_line_fts = pygplates.FeatureCollection(MOR_line_fts_shp)
	center_of_MOR_point_fts_shp = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\modified_end_age_of_rift_point_features_based_on_kinematic_records_v2_test_8_div_test_12_conv_EB2022_fts_20240806.shp"
	#center_of_MOR_point_fts = pygplates.FeatureCollection(center_of_MOR_point_fts_shp)
	rotation_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\1000_0_rotfile_Merdith_et_al.rot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 0
	begin_reconstruction_time = 995.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	modelname = "EB2021"
	yearmonthday = "20240912"
	#calculate_distance_between_defined_MOR_ft_and_center_of_MOR_point_fts(MOR_line_fts, center_of_MOR_point_fts, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)
	
	
	subduction_line_fts_file = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\extract_features_based_on_featType_subduction_zone_Merdith_et_al_2021_1000_0Ma_20230722.shp"
	subduction_line_fts = pygplates.FeatureCollection(subduction_line_fts_file)
	upper_plate_margins_file = r"upper_and_lower_margins_for_pairs_of_convergent_margins_use_buffer_IPQ_0.01_995.0_0.0_Merdith_et_al_2021_20241127.shp"
	upper_plate_margins = pygplates.FeatureCollection(upper_plate_margins_file)
	calculate_distance_between_defined_subduction_zone_and_upper_plate_margins(subduction_line_fts, upper_plate_margins, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)