import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
import estimate_tectonic_plates as estimate

def main():
	# order_to_connect_lines_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/simple_line_topology/order_to_connect_con_ocn_line_feats_for_each_sgdu_PalaeoPlatesendJan2023_from_max_time_2800.0_20231024.csv"
	# #supergdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# #supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
	
	# all_supergdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# all_supergdu_features = pygplates.FeatureCollection(all_supergdu_features_file)
	
	# order_to_connect_lines_csv = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\all_records_to_connect_con_ocn_line_feats_for_each_sgdu_temp_13_SGDUS_PalaeoPlatesendJan2023_from_max_time_2800.0_20231121.csv"
	# #this is what we will do but for testing we can choose one SGDU at the time
	# #select SuperGDU features from the csv file of order to connect CON-OCN line features 
	# df_order = pd.read_csv(order_to_connect_lines_csv)
	# unique_sgdu_name = df_order['sgdu'].unique()
	# supergdu_features = pygplates.FeatureCollection()
	# for sgdu_ft in all_supergdu_features:
		# sgdu_name = sgdu_ft.get_name()
		# if (np.isin(sgdu_name,unique_sgdu_name)):
			# supergdu_features.add(sgdu_ft)
	
	
	# line_feats_from_div_process_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/diverging_line_features_for_2800.0_5.0_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	# line_feats_from_div_process = pygplates.FeatureCollection(line_feats_from_div_process_file)
	# line_feats_from_conv_process_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/converging_line_features_for_2800.0_0.0_test_30_short_conv_PalaeoPlatesJan2023_20231023.shp"
	# line_feats_from_conv_process = pygplates.FeatureCollection(line_feats_from_conv_process_file)
	# plate_boundary_zone_feats_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
	# plate_boundary_zone_feats = pygplates.FeatureCollection(plate_boundary_zone_feats_file)
	# modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	# modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
	# rift_csv_file = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	# begin_reconstruction_time = 200.00
	# end_reconstruction_time = 100.00
	# time_interval = 5.00
	# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# reference = 700
	# yearmonthday = '20231107'
	# modelname = 'PalaeoPlatesendJan2023'
	# estimate.create_tectonic_plates(order_to_connect_lines_csv, supergdu_features, line_feats_from_div_process, line_feats_from_conv_process, plate_boundary_zone_feats, modified_rift_point_features, rift_csv_file, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday)
	
	
	all_supergdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	all_supergdu_features = pygplates.FeatureCollection(all_supergdu_features_file)
	
	order_to_connect_lines_csv = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\all_records_to_connect_con_ocn_line_feats_for_each_sgdu_temp_58_SGDUS_PalaeoPlatesendJan2023_from_max_time_2800.0_20231125.csv"
	#this is what we will do but for testing we can choose one SGDU at the time
	#select SuperGDU features from the csv file of order to connect CON-OCN line features 
	df_order = pd.read_csv(order_to_connect_lines_csv)
	unique_sgdu_name = df_order['sgdu'].unique()
	supergdu_features = pygplates.FeatureCollection()
	for sgdu_ft in all_supergdu_features:
		sgdu_name = sgdu_ft.get_name()
		if (np.isin(sgdu_name,unique_sgdu_name)):
			supergdu_features.add(sgdu_ft)
	#test
	# supergdu_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\superGDU\selected_61545_SGDU_PalaeoPlatesendJan2023_1955Ma.shp"
	# supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
	
	line_feats_from_div_process_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\diverging_line_features_for_2800.0_5.0_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	line_feats_from_div_process = pygplates.FeatureCollection(line_feats_from_div_process_file)
	line_feats_from_conv_process_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\converging_line_features_for_2800.0_0.0_test_30_short_conv_PalaeoPlatesJan2023_20231023.shp"
	line_feats_from_conv_process = pygplates.FeatureCollection(line_feats_from_conv_process_file)
	plate_boundary_zone_feats_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
	plate_boundary_zone_feats = pygplates.FeatureCollection(plate_boundary_zone_feats_file)
	modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
	rift_csv_file = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	begin_reconstruction_time = 20.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	yearmonthday = '20231125'
	modelname = '58_PalaeoPlatesendJan2023'
	estimate.create_tectonic_plates(order_to_connect_lines_csv, supergdu_features, line_feats_from_div_process, line_feats_from_conv_process, plate_boundary_zone_feats, modified_rift_point_features, rift_csv_file, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday)

if __name__ == '__main__':
	main()