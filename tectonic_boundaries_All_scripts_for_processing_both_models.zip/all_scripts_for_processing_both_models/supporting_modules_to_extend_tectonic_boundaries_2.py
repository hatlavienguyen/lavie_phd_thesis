import sys
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
import supporting_topological_modules as supporting_topology
import psycopg2
from config_plate_tectonics import config

def extend_current_valid_and_recorded_tectonic_boundaries_from_table_final_summary_of_tectonic_boundaries_and_motion(CON_OCN_line_features, modelname, yearmonthday):
	outputExtendedTectonicBdnFeatures = pygplates.FeatureCollection()
	sql	 = """SELECT from_time,to_time,line_1_ft_name,line_2_ft_name,ref_gdu_id,other_gdu_id,tectonic_motion 
				FROM test_final_summary_of_tectonic_boundaries_and_motion 
				ORDER BY from_time DESC"""
	cur = None
	cur_1 = None
	cur_2 = None
	cur_3 = None
	cur_4 = None
	cur_5 = None
	cur_6 = None
	cur_8 = None
	cur_7 = None
	list_of_already_processed = []
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		cur_5 = conn.cursor()
		cur_6 = conn.cursor()
		cur_7 = conn.cursor()
		cur_8 = conn.cursor()
		output_dic = {}
		cur.execute(sql)
		row = cur.fetchone()
		while(row is not None):
			print(row)
			#from_time,to_time,line_1_ft_name,line_2_ft_name,ref_gdu_id,other_gdu_id
			from_time = float(row[0])
			to_time = float(row[1])
			line_1_ft_name = row[2]
			line_2_ft_name = row[3]
			ref_gdu_id = int(row[4])
			other_gdu_id = int(row[5])
			tectonic_motion = row[6]
			txt_2 = """SELECT gdu_id, lef_gdu_id, right_gdu_id
							   FROM tectonic_topological_line_fts
							   WHERE type_of_line_fts = 'CON_OCN' AND (initial_ft_id = '{input_line_ft_name}' or name = '{input_line_ft_name}')"""
			sql_2 = txt_2.format(input_line_ft_name = line_1_ft_name)
			cur_2.execute(sql_2)
			row_2 = cur_2.fetchone()
			gdu_id = int(row_2[0])
			left_gdu_id = int(row_2[1])
			right_gdu_id = int(row_2[2])
			txt_3 = None
			if (gdu_id == left_gdu_id):
				txt_3 = """SELECT initial_ft_id, name, gdu_id, lef_gdu_id, right_gdu_id 
						FROM tectonic_topological_line_fts
						WHERE type_of_line_fts = 'CON_OCN' AND (initial_ft_id <> '{input_line_ft_name}' and name <> '{input_line_ft_name}') 
								AND gdu_id = {input_gdu_id} AND lef_gdu_id = {input_gdu_id} AND from_time >= {input_from_time} AND to_time <= {input_to_time}"""
			elif (gdu_id == right_gdu_id):
				txt_3 = """SELECT initial_ft_id, name, gdu_id, lef_gdu_id, right_gdu_id 
						FROM tectonic_topological_line_fts
						WHERE type_of_line_fts = 'CON_OCN' AND (initial_ft_id <> '{input_line_ft_name}' and name <> '{input_line_ft_name}') 
								AND gdu_id = {input_gdu_id} AND right_gdu_id = {input_gdu_id} AND from_time >= {input_from_time} AND to_time <= {input_to_time}"""
			sql_3 = txt_3.format(input_line_ft_name = line_1_ft_name, input_gdu_id = gdu_id, input_from_time = from_time, input_to_time = to_time)
			cur_3.execute(sql_3)
			row_3 = cur_3.fetchone()
			while (row_3 is not None):
				candidate_initial_ft_id = row_3[0]
				candidate_name = row_3[1]
				candidate_gdu_id = int(row_3[2])
				candidate_lef_gdu_id = int(row_3[3])
				candidate_right_gdu_id = int(row_3[4])
				print("candidate_initial_ft_id",candidate_initial_ft_id)
				txt_6 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_final_summary_of_tectonic_boundaries_and_motion 
						   WHERE (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}' or line_1_ft_name = '{input_line_ft_name_2}' or line_2_ft_name = '{input_line_ft_name_2}') 
						   AND (ref_gdu_id = {input_gdu_id}OR other_gdu_id = {input_gdu_id}) 
						   AND (NOT (to_time > {input_from_time} OR from_time < {input_to_time}))
						   ORDER BY from_time DESC """
				sql_6 = txt_6.format(input_gdu_id = candidate_gdu_id , input_line_ft_name = candidate_initial_ft_id, input_line_ft_name_2 = candidate_name, input_from_time = from_time, input_to_time = to_time)
				cur_6.execute(sql_6)
				row_6 = cur_6.fetchone()
				txt_7 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_extended_final_summary_of_tectonic_boundaries_and_motion 
						   WHERE (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}' or line_1_ft_name = '{input_line_ft_name_2}' or line_2_ft_name = '{input_line_ft_name_2}') 
						   AND (ref_gdu_id = {input_gdu_id}OR other_gdu_id = {input_gdu_id}) 
						   AND (NOT (to_time > {input_from_time} OR from_time < {input_to_time}))
						   ORDER BY from_time DESC """
				sql_7 = txt_7.format(input_gdu_id = candidate_gdu_id , input_line_ft_name = candidate_initial_ft_id, input_line_ft_name_2 = candidate_name, input_from_time = from_time, input_to_time = to_time)
				cur_7.execute(sql_7)
				row_7 = cur_7.fetchone()
				if (row_6 is None and row_7 is None):#there is no record for this line feature in the final_summary_of_tectonic_boundaries_and_motion, so we can infer the appropriate tectonic boundary
					plate_tectonic_margin_ft_1 = None
					infer_line_ft = CON_OCN_line_features.get(lambda ft: ft.get_name() == candidate_initial_ft_id, pygplates.FeatureReturn.first)
					if (infer_line_ft is None):
						infer_line_ft = CON_OCN_line_features.get(lambda ft: ft.get_name() == candidate_name, pygplates.FeatureReturn.first)
					infer_line = infer_line_ft.get_geometry(property_return = pygplates.PropertyReturn.first)
					if (tectonic_motion == "Convergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,infer_line, name = candidate_name, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = candidate_gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(left_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(right_gdu_id)

					elif (tectonic_motion == "Divergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,infer_line, name = candidate_name, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = candidate_gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(left_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(right_gdu_id)

					elif (tectonic_motion == "Transform"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,infer_line, name = candidate_name, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = candidate_gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(left_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(right_gdu_id)
					
					elif (tectonic_motion == "Unknown_same_motion"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,infer_line, name = candidate_name, description = "unknown_same_motion", valid_time = (from_time, to_time), reconstruction_plate_id = candidate_gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(left_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(right_gdu_id)
					outputExtendedTectonicBdnFeatures.add(plate_tectonic_margin_ft_1)
					sql_8 = """INSERT INTO test_extended_final_summary_of_tectonic_boundaries_and_motion (from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s,%s,%s,%s,%s,%s,%s) """
					if (candidate_gdu_id == left_gdu_id):
						cur_8.execute(sql_8,(from_time, to_time,tectonic_motion,candidate_name,line_2_ft_name,left_gdu_id,right_gdu_id))
					else:
						cur_8.execute(sql_8,(from_time, to_time,tectonic_motion,candidate_name,line_2_ft_name,right_gdu_id,left_gdu_id))
					conn.commit()
				row_3 = cur_3.fetchone()
			
			
			sql_2 = txt_2.format(input_line_ft_name = line_2_ft_name)
			cur_2.execute(sql_2)
			row_2 = cur_2.fetchone()
			gdu_id = int(row_2[0])
			left_gdu_id = int(row_2[1])
			right_gdu_id = int(row_2[2])
			txt_3 = None
			if (gdu_id == left_gdu_id):
				txt_3 = """SELECT initial_ft_id, name, gdu_id, lef_gdu_id, right_gdu_id 
						FROM tectonic_topological_line_fts
						WHERE type_of_line_fts = 'CON_OCN' AND (initial_ft_id <> '{input_line_ft_name}' and name <> '{input_line_ft_name}') 
								AND gdu_id = {input_gdu_id} AND lef_gdu_id = {input_gdu_id} AND from_time >= {input_from_time} AND to_time <= {input_to_time}"""
			elif (gdu_id == right_gdu_id):
				txt_3 = """SELECT initial_ft_id, name, gdu_id, lef_gdu_id, right_gdu_id 
						FROM tectonic_topological_line_fts
						WHERE type_of_line_fts = 'CON_OCN' AND (initial_ft_id <> '{input_line_ft_name}' and name <> '{input_line_ft_name}') 
								AND gdu_id = {input_gdu_id} AND right_gdu_id = {input_gdu_id} AND from_time >= {input_from_time} AND to_time <= {input_to_time}"""
			sql_3 = txt_3.format(input_line_ft_name = line_2_ft_name, input_gdu_id = gdu_id, input_from_time = from_time, input_to_time = to_time)
			cur_3.execute(sql_3)
			row_3 = cur_3.fetchone()
			while (row_3 is not None):
				candidate_initial_ft_id = row_3[0]
				candidate_name = row_3[1]
				candidate_gdu_id = int(row_3[2])
				candidate_lef_gdu_id = int(row_3[3])
				candidate_right_gdu_id = int(row_3[4])
				txt_6 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_final_summary_of_tectonic_boundaries_and_motion 
						   WHERE (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}' or line_1_ft_name = '{input_line_ft_name_2}' or line_2_ft_name = '{input_line_ft_name_2}') 
						   AND (ref_gdu_id = {input_gdu_id}OR other_gdu_id = {input_gdu_id}) 
						   AND (NOT (to_time > {input_from_time} OR from_time < {input_to_time}))
						   ORDER BY from_time DESC """
				sql_6 = txt_6.format(input_gdu_id = candidate_gdu_id , input_line_ft_name = candidate_initial_ft_id, input_line_ft_name_2 = candidate_name, input_from_time = from_time, input_to_time = to_time)
				cur_6.execute(sql_6)
				row_6 = cur_6.fetchone()
				txt_7 = """SELECT ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion
						   FROM test_extended_final_summary_of_tectonic_boundaries_and_motion 
						   WHERE (line_1_ft_name = '{input_line_ft_name}' or line_2_ft_name = '{input_line_ft_name}' or line_1_ft_name = '{input_line_ft_name_2}' or line_2_ft_name = '{input_line_ft_name_2}') 
						   AND (ref_gdu_id = {input_gdu_id}OR other_gdu_id = {input_gdu_id}) 
						   AND (NOT (to_time > {input_from_time} OR from_time < {input_to_time}))
						   ORDER BY from_time DESC """
				sql_7 = txt_7.format(input_gdu_id = candidate_gdu_id , input_line_ft_name = candidate_initial_ft_id, input_line_ft_name_2 = candidate_name, input_from_time = from_time, input_to_time = to_time)
				cur_7.execute(sql_7)
				row_7 = cur_7.fetchone()
				if (row_6 is None and row_7 is None):#there is no record for this line feature in the final_summary_of_tectonic_boundaries_and_motion, so we can infer the appropriate tectonic boundary
					plate_tectonic_margin_ft_2 = None
					infer_line_ft = CON_OCN_line_features.get(lambda ft: ft.get_name() == candidate_initial_ft_id, pygplates.FeatureReturn.first)
					if (infer_line_ft is None):
						infer_line_ft = CON_OCN_line_features.get(lambda ft: ft.get_name() == candidate_name, pygplates.FeatureReturn.first)
					infer_line = infer_line_ft.get_geometry(property_return = pygplates.PropertyReturn.first)
					if (tectonic_motion == "Convergence"):
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,infer_line, name = candidate_name, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = candidate_gdu_id)
						plate_tectonic_margin_ft_2.set_left_plate(left_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(right_gdu_id)

					elif (tectonic_motion == "Divergence"):
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,infer_line, name = candidate_name, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = candidate_gdu_id)
						plate_tectonic_margin_ft_2.set_left_plate(left_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(right_gdu_id)

					elif (tectonic_motion == "Transform"):
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,infer_line, name = candidate_name, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = candidate_gdu_id)
						plate_tectonic_margin_ft_2.set_left_plate(left_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(right_gdu_id)
					
					elif (tectonic_motion == "Unknown_same_motion"):
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,infer_line, name = candidate_name, description = "unknown_same_motion", valid_time = (from_time, to_time), reconstruction_plate_id = candidate_gdu_id)
						plate_tectonic_margin_ft_2.set_left_plate(left_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(right_gdu_id)
					outputExtendedTectonicBdnFeatures.add(plate_tectonic_margin_ft_2)
					sql_8 = """INSERT INTO test_extended_final_summary_of_tectonic_boundaries_and_motion (from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s,%s,%s,%s,%s,%s,%s) """
					if (candidate_gdu_id == left_gdu_id):
						cur_8.execute(sql_8,(from_time, to_time,tectonic_motion,candidate_name,line_1_ft_name,left_gdu_id,right_gdu_id))
					else:
						cur_8.execute(sql_8,(from_time, to_time,tectonic_motion,candidate_name,line_1_ft_name,right_gdu_id,left_gdu_id))
					conn.commit()
				row_3 = cur_3.fetchone()
			
			row = cur.fetchone()
		outputExtendedTectonicBdnFeatures.write("extend_tectonic_boundaries_"+modelname+"_"+yearmonthday+".shp")
		outputExtendedTectonicBdnFeatures.write("extend_tectonic_boundaries_"+modelname+"_"+yearmonthday+".gpml")
	except (psycopg2.DatabaseError) as error:
		print("Error in extend_current_valid_and_recorded_tectonic_boundaries_from_table_final_summary_of_tectonic_boundaries_and_motion")
		print(error)