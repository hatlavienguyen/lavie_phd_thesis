import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
#import supporting_topological_modules as tm
#import supporting_topological_modules_for_MOR as MOR_topology
import rotation_utility
import identify_kinematic_boundaries as kin_bdn


def evaluate_spatial_relationship_between_small_circle_boundaries_and_line_features(rotation_model, reference, child_repgduid_1, child_repgduid_2, reconstruction_time, line_features_collection, sgu_features_collection):
	#Find valid gdu features with con-ocn line features
	reconstructed_line_features = []
	reconstructed_sgdu_features = []
	valid_con_ocn_line_features = [con_ocn_ft for con_ocn_ft in line_features_collection if con_ocn_ft.is_valid_at_time(reconstruction_time)]
	valid_sgdu_features = [sgdu_ft for sgdu_ft in sgu_features_collection if sgdu_ft.is_valid_at_time(reconstruction_time)]
	if (reference is not None):
		pygplates.reconstruct(valid_con_ocn_line_features, rotation_model, reconstructed_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(valid_con_ocn_line_features, rotation_model, reconstructed_line_features, reconstruction_time, group_with_feature = True)
		pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, group_with_feature = True)
	final_reconstructed_line_features = kin_bdn.find_final_reconstructed_geometries(reconstructed_line_features, pygplates.PolylineOnSphere)
	final_reconstructed_sgdu_features = kin_bdn.find_final_reconstructed_geometries(reconstructed_sgdu_features, pygplates.PolygonOnSphere)
	#check whether the pair of sgdus is valid
	child_sgud_1 = []
	child_sgud_2 = []
	non_related = []
	#for yng_sgdu_ft,yng_sgdu in final_reconstructed_sgdu_features_ynger:
	for yng_sgdu_ft,yng_sgdu in final_reconstructed_sgdu_features:
		#divergence
		# if (yng_sgdu_ft.get_name() == str(71261)):
			# child_sgud_1.append((yng_sgdu_ft,yng_sgdu))
		# elif (yng_sgdu_ft.get_name() == str(71252)):
			# child_sgud_2.append((yng_sgdu_ft,yng_sgdu))
		# else:
			# non_related.append((yng_sgdu_ft,yng_sgdu))
		#convergence
		if (yng_sgdu_ft.get_name() == str(79049)):
			child_sgud_1.append((yng_sgdu_ft,yng_sgdu))
		elif (yng_sgdu_ft.get_name() == str(79050)):
			child_sgud_2.append((yng_sgdu_ft,yng_sgdu))
		else:
			non_related.append((yng_sgdu_ft,yng_sgdu))
	# for con_ocn_line_ft,_ in final_reconstructed_line_features:
		# print('POLYLID',con_ocn_line_ft.get_shapefile_attribute('POLYLID'))
	output_pairs_of_line_features = pygplates.FeatureCollection()
	total_relative_reconstruction_rotation = kin_bdn.find_total_relative_reconstruction_rotation_(rotation_model, child_repgduid_1, child_repgduid_2, reconstruction_time, reference)
	E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
	smallest_circle_angular_radius_degrees = 178.00
	while (smallest_circle_angular_radius_degrees > 0.00):
		found_pair_of_line_features = None
		small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
		for gdu_line_ft_1, line_gdu_1 in final_reconstructed_line_features:
			approx_rad_closest_dist_neighbour,pt1,_ = pygplates.GeometryOnSphere.distance(line_gdu_1, small_circle_boundary,return_closest_positions = True)
			lat1,lon1 = pt1.to_lat_lon()
			sgdu_for_line_gdu_1 = None
			sgdu_for_line_gdu_2 = None
			for sgdu_ft_1,reconstructed_sgdu_1 in child_sgud_1:
				if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu_1,line_gdu_1) == 0.00):
					sgdu_for_line_gdu_1 = sgdu_ft_1.get_name()
					break
			if (sgdu_for_line_gdu_1 is None):
				for sgdu_ft_2,reconstructed_sgdu_2 in child_sgud_2:
					if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu_2,line_gdu_1) == 0.00):
						sgdu_for_line_gdu_1 = sgdu_ft_2.get_name()
						break
			for gdu_line_ft_2, line_gdu_2 in final_reconstructed_line_features:
				for sgdu_ft_1,reconstructed_sgdu_1 in child_sgud_1:
					if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu_1,line_gdu_2) == 0.00):
						sgdu_for_line_gdu_2 = sgdu_ft_1.get_name()
						break
				if (sgdu_for_line_gdu_2 is None or sgdu_for_line_gdu_2 == sgdu_for_line_gdu_1):
					for sgdu_ft_2,reconstructed_sgdu_2 in child_sgud_2:
						if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu_2,line_gdu_2) == 0.00):
							sgdu_for_line_gdu_2 = sgdu_ft_2.get_name()
							break
				if (gdu_line_ft_1.get_shapefile_attribute('POLYLID') != gdu_line_ft_2.get_shapefile_attribute('POLYLID') and (sgdu_for_line_gdu_2 is not None and sgdu_for_line_gdu_1 is not None) and (sgdu_for_line_gdu_2 != sgdu_for_line_gdu_1)):
					# print('polylid1')
					# print(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
					# print('polylid2')
					# print(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
					approx_rad_closest_dist_ref,pt2,_ = pygplates.GeometryOnSphere.distance(line_gdu_2, small_circle_boundary,return_closest_positions = True)
					if (approx_rad_closest_dist_neighbour == 0.00 and approx_rad_closest_dist_ref == 0.00):
						lat2,lon2 = pt2.to_lat_lon()
						distance_btw_point = kin_bdn.calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
						#divergence 
						# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12200_11495_1210' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17143_10784_1089') or (gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17143_10784_1089' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12200_11495_1210')):
							# #debug
							# print('POLYLID1',gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
							# print('POLYLID2',gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
							# print('distance_btw_point',distance_btw_point)
							# print('at smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
						
						# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12404_11454_1198' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17023_14194_2132') or (gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17023_14194_2132' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12404_11454_1198')):
							# #debug
							# print('POLYLID1',gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
							# print('POLYLID2',gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
							# print('distance_btw_point',distance_btw_point)
							# print('at smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
						
						temporary_PolylineOnSphere = pygplates.PolylineOnSphere([pt1,pt2])
						valid_pair_of_line_fts = True
						for random_sgdu_ft,random_sgdu in non_related:
							if (random_sgdu.partition(temporary_PolylineOnSphere) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
								valid_pair_of_line_fts = False
								print('POLYLID1',gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
								print('POLYLID2',gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
								print('FAILED for crossing random_sgdu ',random_sgdu_ft.get_name(),' at smallest_circle_angular_radius_degrees at ',smallest_circle_angular_radius_degrees)
								break
						if (valid_pair_of_line_fts == True and distance_btw_point <= 1000.00):
							# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12200_11495_1210' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17143_10784_1089') or (gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17143_10784_1089' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12200_11495_1210')):
								# #debug
								# print('POLYLID1',gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
								# print('POLYLID2',gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
								# print('found_pair_of_line_features',found_pair_of_line_features)
							
							# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12404_11454_1198' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17023_14194_2132') or (gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17023_14194_2132' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12404_11454_1198')):
								# #debug
								# print('POLYLID1',gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
								# print('POLYLID2',gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
								# print('distance_btw_point',distance_btw_point)
								# print('at smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
							
							gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
							gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
							if (found_pair_of_line_features is None):
								found_pair_of_line_features = (gdu_line_ft_1.clone(), line_gdu_1.clone(), gdu_line_ft_2.clone(), line_gdu_2.clone(), distance_btw_point)
							else:
								previous_distance = found_pair_of_line_features[4]
								previous_gdu_line_ft_1 = found_pair_of_line_features[0]
								previous_gdu_line_ft_2 = found_pair_of_line_features[2]
								
								if (previous_distance > distance_btw_point):
									#debug
									# if ((previous_gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12404_11454_1198' and previous_gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17023_14194_2132') or (previous_gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17023_14194_2132' and previous_gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12404_11454_1198')):
										# print('previous_distance',previous_distance, previous_gdu_line_ft_1.get_shapefile_attribute('POLYLID'), previous_gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
										# print('distance_btw_point',distance_btw_point,gdu_line_ft_1.get_shapefile_attribute('POLYLID'),gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
									# if ((previous_gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '11815_11634_7117' and previous_gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17332_13735_7693') or (previous_gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17332_13735_7693' and previous_gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '11815_11634_7117')):
										# print('previous_distance',previous_distance, previous_gdu_line_ft_1.get_shapefile_attribute('POLYLID'), previous_gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
										# print('distance_btw_point',distance_btw_point,gdu_line_ft_1.get_shapefile_attribute('POLYLID'),gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
									
									found_pair_of_line_features = (gdu_line_ft_1.clone(), line_gdu_1.clone(), gdu_line_ft_2.clone(), line_gdu_2.clone(), distance_btw_point)
								
								# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12404_11454_1198' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17023_14194_2132') or (gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17023_14194_2132' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12404_11454_1198')):
									# print('previous_distance',previous_distance, previous_gdu_line_ft_1.get_shapefile_attribute('POLYLID'), previous_gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
									# print('distance_btw_point',distance_btw_point,gdu_line_ft_1.get_shapefile_attribute('POLYLID'),gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
								
								# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '11815_11634_7117' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17332_13735_7693') or (gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17332_13735_7693' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '11815_11634_7117')):
									# print('previous_distance',previous_distance, previous_gdu_line_ft_1.get_shapefile_attribute('POLYLID'), previous_gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
									# print('distance_btw_point',distance_btw_point,gdu_line_ft_1.get_shapefile_attribute('POLYLID'),gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
								
		if (found_pair_of_line_features is not None):
			gdu_line_ft_1, line_gdu_1, gdu_line_ft_2, line_gdu_2, distance_btw_point = found_pair_of_line_features
			#gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
			#gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
			output_pairs_of_line_features.add(gdu_line_ft_1)
			output_pairs_of_line_features.add(gdu_line_ft_2)
			print('at smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
					# if (distance_btw_point <= 1000.00): supergdu_and_members_gdu_at_995.0_for_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230414.csv dissolved_polygon_fts_from_995.0_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230414
						# print('POLYLID1',gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
						# print('POLYLID2',gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
						# gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
						# gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
						# output_pairs_of_line_features.add(gdu_line_ft_1)
						# output_pairs_of_line_features.add(gdu_line_ft_2)
						# print('at smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
				# print('POLYLID',gdu_line_ft.get_shapefile_attribute('POLYLID'))
				# print('approx_rad_closest_dist_neighbour',approx_rad_closest_dist_neighbour)
				# print('at smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
			# if (gdu_line_ft.get_shapefile_attribute('POLYLID') == '12200_11495_1210' and smallest_circle_angular_radius_degrees == 82.00):
				# print('approx_rad_closest_dist_neighbour',approx_rad_closest_dist_neighbour)
				# print('at smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
		smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.00
	output_pairs_of_line_features.write('test_4_expected_valid_pairs_of_line_features_w_1000km_threshold_20230506_'+str(child_repgduid_1)+'_'+str(child_repgduid_2)+'.shp')

def main():
	# rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# reference = 700
	# child_repgduid_1 = 17100
	# child_repgduid_2 = 12000
	# reconstruction_time = 135.00
	# line_ft_file = r"C:\Users\lavie\Desktop\Research\Winter2023\tectonic_boundaries\expected_pair_divergent_line_features_but_failed_at_135.0_PalaeoPlatesendOct2022_20230410.shp"
	# line_features_collection = pygplates.FeatureCollection(line_ft_file)
	# sgu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# sgu_features_collection = pygplates.FeatureCollection(sgu_features_file)
	# evaluate_spatial_relationship_between_small_circle_boundaries_and_line_features(rotation_model, reference, child_repgduid_1, child_repgduid_2, reconstruction_time, line_features_collection, sgu_features_collection)
	
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	child_repgduid_1 = 11743
	child_repgduid_2 = 11000
	reconstruction_time = 185.00
	line_ft_file = r"C:\Users\lavie\Desktop\Research\Fall2022\line_topology_qgis_geopandas_shapely\example_8_merged_POLYGID_joined_line_fts_510_0_All_PalaeoPlatesJan2023.shp"
	line_features_collection = pygplates.FeatureCollection(line_ft_file)
	sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgu_features_collection = pygplates.FeatureCollection(sgdu_features_file)
	evaluate_spatial_relationship_between_small_circle_boundaries_and_line_features(rotation_model, reference, child_repgduid_1, child_repgduid_2, reconstruction_time, line_features_collection, sgu_features_collection)

if __name__=='__main__':
	main()
