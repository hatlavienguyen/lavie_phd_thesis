#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import geopandas as gpd
import pandas as pd

def find_plate_boundary_zone_features(temp_conv_line_features_file, temp_div_line_features_file, line_features_file, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	conv_gdf = gpd.read_file(temp_conv_line_features_file)
	div_gdf = gpd.read_file(temp_div_line_features_file)
	merge_gdf = pd.concat([conv_gdf,div_gdf])
	dic_plate_boundary_zone = {}
	output_plate_boundary_zone = pygplates.FeatureCollection()
	line_features_collection = pygplates.FeatureCollection(line_features_file)
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		valid_line_features = [line_ft for line_ft in line_features_collection if line_ft.is_valid_at_time(reconstruction_time)]
		for line_ft in valid_line_features:
			polylid = line_ft.get_shapefile_attribute('POLYLID')
			records_from_gdf = merge_gdf.loc[((merge_gdf['NAME'] == polylid) & (merge_gdf['FROMAGE'] >= reconstruction_time) & (merge_gdf['TOAGE'] <= reconstruction_time))]
			if (records_from_gdf is not None):
				if (len(records_from_gdf) > 0):
					if (polylid in dic_plate_boundary_zone):
						clone_ft = dic_plate_boundary_zone[polylid]
						line_begin_age,line_end_age = clone_ft.get_valid_time()
						if ((line_begin_age > reconstruction_time and line_end_age < reconstruction_time) or (line_begin_age >= reconstruction_time and line_end_age < reconstruction_time) or (line_begin_age > reconstruction_time and line_end_age <= reconstruction_time)):
							clone_ft.set_valid_time(line_begin_age, reconstruction_time+0.100)
							output_plate_boundary_zone.add(clone_ft)
							del dic_plate_boundary_zone[polylid]
				else:
					if (polylid not in dic_plate_boundary_zone):
						clone_ft = line_ft.clone()
						clone_ft.set_description('plate_boundary_zone')
						dic_plate_boundary_zone[polylid] = clone_ft
					else:
						clone_ft = dic_plate_boundary_zone[polylid]
						clone_begin_age,clone_end_age = clone_ft.get_valid_time()
						if (clone_end_age > reconstruction_time):
							current_line_begin_age,current_line_end_age = line_ft.get_valid_time()
							if (current_line_begin_age <= reconstruction_time):
								output_plate_boundary_zone.add(clone_ft)
								new_clone = line_ft.clone()
								dic_plate_boundary_zone[polylid] = new_clone
		reconstruction_time = reconstruction_time - time_interval
	for polylid in dic_plate_boundary_zone:
		final_line_ft = dic_plate_boundary_zone[polylid]
		output_plate_boundary_zone.add(final_line_ft)
	output_plate_boundary_zone.write('plate_boundary_zone_features_for_'+modelname+'_'+yearmonthday+'.shp')

def main():
	temp_conv_line_features_file = r'converging_line_features_for_600.0_0.0_test_13_short_conv_PalaeoPlatesJan2023_20230614.shp'
	temp_div_line_features_file = r'diverging_line_features_for_test_16_short_PalaeoPlatesendOct2022_w_1_deg_from_600Ma_20230614.shp'
	line_features_file = r'/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_26_valid_single_dissolved_merged_POLGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230509.shp'
	begin_reconstruction_time = 600.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	modelname = 'PalaeoPlatesendJan2023_from_600Ma'
	yearmonthday = '20230617'
	find_plate_boundary_zone_features(temp_conv_line_features_file, temp_div_line_features_file, line_features_file, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)

if __name__=='__main__':
	main()
