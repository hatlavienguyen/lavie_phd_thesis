import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted_2 as supporting

def main():
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	polygon_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\PlatePolygons2016Continental.shp"
	polygon_features_collection = pygplates.FeatureCollection(polygon_features_file)
	centroid_features_file = None
	line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\examine_line_topology\ft_id_str_in_GPlates_format_to_ft_name_CON_OCN_line_features_BC_only_PalaeoPlatesNov2021_20220129.shp"
	line_features_collection = pygplates.FeatureCollection(line_features_file)
	begin_reconstruction_time = 220.00
	end_reconstruction_time = 50.00
	interval = 5.00
	field_name_for_lithosphere_type = "COTID"
	continental_type_symbol = 'C'
	threshold_distance_in_km = 1000.00
	reference = 700
	cos_value_for_transform = 0.0100
	modelname = "BC_PalaeoPlatesNov2021"
	yearmonthday = "20220427"
	supporting.identify_tectonic_motion('BC_tectonic_motion_at_each_time',rotation_model, polygon_features_collection, centroid_features_file, line_features_collection, begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,cos_value_for_transform,reference,modelname,yearmonthday)

if __name__=='__main__':
    main()