#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
import estimate_tectonic_plates as estimate
from multiprocessing import Pool
from os import environ
from time import sleep
import identify_kinematic_boundaries as identify_kin

ncpus = int(environ['SLURM_CPUS_PER_TASK'])

common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
gdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
gdu_features = pygplates.FeatureCollection(gdu_features_file)
#line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_26_valid_single_dissolved_merged_POLGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230509.shp"
line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_segment_POLYGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230921.shp"
#line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/AFR_NAM_SAM_CON_OCN_from_test_32_PalaeoPlatesJan2023_20230628.shp"
line_features_collection = pygplates.FeatureCollection(line_features_file)
rift_csv_file = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
time_interval = 5.00
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)
reference = 700
yearmonthday = '20231218'
modelname = 'PalaeoPlatesendJan2023'


def calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval):
	max_min_rec_time_list = []
	value = maximum_of_reconstruction_period
	while (value >= minimum_of_reconstruction_period):
		min_recon = value - reconstruction_interval
		max_min_rec_time_list.append((value,min_recon))
		value = min_recon
	return max_min_rec_time_list

def find_additional_rift_point_feats_within_a_period(maximum_reconstruction_time, minimum_reconstruction_time):
	identify_kin.find_additional_rift_point_features_from_initial_rift_point_features(rift_csv_file, line_features_collection, sgdu_features, gdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, maximum_reconstruction_time, minimum_reconstruction_time, rotation_model, reference, modelname, yearmonthday)

if __name__ == '__main__':
	maximum_of_reconstruction_period = 2800.00
	minimum_of_reconstruction_period = 200.00
	reconstruction_interval = 200.00
	max_min_rec_time_list = calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval)

	with Pool(ncpus) as pool:
		#results = pool.starmap(create_oceanic_crust_feats_from_temp_isochron_point_feats_within_a_period, max_min_rec_time_list)
		#results = pool.starmap(create_oceanic_crust_feats_for_gdus_from_temp_isochron_point_feats_within_a_period, max_min_rec_time_list)
		results = pool.starmap(find_additional_rift_point_feats_within_a_period, max_min_rec_time_list)
		print(results)