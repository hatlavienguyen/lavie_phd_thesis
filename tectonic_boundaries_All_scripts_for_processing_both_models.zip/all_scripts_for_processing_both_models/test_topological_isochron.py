import pygplates
import create_remnant_of_previous_MOR as create_remnant
import create_topological_isochron_and_estimate_MOR as topological

def calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval):
	max_min_rec_time_list = []
	value = maximum_of_reconstruction_period
	while (value > minimum_of_reconstruction_period):
		min_recon = value - reconstruction_interval
		max_min_rec_time_list.append((value,min_recon))
		value = min_recon
	return max_min_rec_time_list

rift_point_features_records_csv = r"rift_point_features_records_for_test_21_short_PalaeoPlatesendJan2023_w_1_deg_20230713.csv"
modelname = "isochron_right_test_25_PalaeoPlatesJan2023_fts_from_late_July"
yearmonthday = "20230731"

def create_topological_isochron_from_temp_isochron_point_feats_within_a_period(maximum_reconstruction_time, minimum_reconstruction_time):
	common_input_point_features_filename = r"isochron_right_point_features_test_25_PalaeoPlatesJan2023_fts_from_late_July_max_{max_time}_{min_time}_20230724.shp"
	input_point_features_file = common_input_point_features_filename.format(max_time = str(maximum_reconstruction_time), min_time = str(minimum_reconstruction_time))
	input_point_features = pygplates.FeatureCollection(input_point_features_file)
	topological.create_isochron_from_temp_isochron_point_features(input_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, modelname, yearmonthday)

if __name__ == '__main__':
	maximum_of_reconstruction_period = 3410.00
	minimum_of_reconstruction_period = 0.00
	reconstruction_interval = 155.00
	max_min_rec_time_list = calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval)
	
	for max_time_in_tuple,min_time_in_tuple in max_min_rec_time_list:
		create_topological_isochron_from_temp_isochron_point_feats_within_a_period(max_time_in_tuple,min_time_in_tuple)