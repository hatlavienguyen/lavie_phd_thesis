from multiprocessing import Pool
from os import environ
from time import sleep
#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pygplates
import create_remnant_of_previous_MOR as create_remnant

#Merdith et al 2021
# common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/supergdu_and_members_gdu_at_{time}_for_Merdith_et_al_EB2021_20230428.csv"
# sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/final_supergdu_feats_995.0_0.0_Merdith_et_al_EB2021_20230428.shp"
# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/1000_0_rotfile_Merdith_et_al.rot"
# rotation_model = pygplates.RotationModel(rotation_file)
# temp_rift_point_features_file = r"rift_point_features_for_test_8_EB2022_20231020.shp"
# temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
# modified_rift_point_features_file = r"modified_end_age_for_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
# modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
# temp_unwanted_rift_point_features_file = r"unwanted_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
# temp_unwanted_rift_point_features = pygplates.FeatureCollection(temp_unwanted_rift_point_features_file)
# rift_point_features_records_csv = r"rift_point_features_records_for_test_8_EB2022_20231020.csv"
# plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_EB2022_20231023.shp"
# plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
# yearmonthday = "20231103"
# reference = 0
# time_interval = 5.00
# records_of_pairs_of_ridges_csv = r"possible_pairs_of_SGDUs_for_RRR_200.0_0.0_test_8_EB2022_20231029.csv"

#PalaeoPlatesendJan2023 
# common_filename_for_temporary_sgdu_and_members_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
# sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
# rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
# rotation_model = pygplates.RotationModel(rotation_file)
# modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
# modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
# rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
# plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
# plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
# yearmonthday = "20231120"
# reference = 0
# time_interval = 5.00
# records_of_pairs_of_ridges_csv = r""

#PalaeoPlatesendJan2023 
common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)
modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
yearmonthday = "20231121"
reference = 0
time_interval = 5.00
records_of_pairs_of_ridges_csv = r"possible_pairs_of_SGDUs_for_RRR_2800.0_0.0_v1_test_1_PalaeoPlatesendJan2023_fts_max_2800.0_0.0_20231120.csv"
temp_triple_junction_point_features_file = r"triple_junction_for_RRR_2800.0_0.0_v1_test_1_PalaeoPlatesendJan2023_fts_max_2800.0_0.0_20231121.shp"
temp_triple_junction_point_features = pygplates.FeatureCollection(temp_triple_junction_point_features_file)

#jobid: 1838035

def find_possible_RRR(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, yearmonthday):
	modelname = "v1_test_1_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.find_pairs_of_SGDUs_for_RRR(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday)

def find_triple_junction_coordinates(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	modelname = "v1_test_1_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.find_coordinates_of_triple_junction_for_RRR(records_of_pairs_of_ridges_csv, modified_rift_point_features, rift_point_features_records_csv, rotation_model, reference, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday)

def modify_end_age_of_triple_junction_RRR_based_on_spatial_rlxn_w_SuperGDU(max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, time_interval):
	modelname = "v1_test_1_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.modify_end_age_of_triple_junction_RRR(temp_triple_junction_point_features, sgdu_features, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, time_interval, rotation_model, reference,  modelname, yearmonthday)

def check_end_time_of_rift_point_features_part_2(rift_point_features_records_csv, temp_rift_point_features, time_interval, rotation_model, reference, yearmonthday):
	modelname = "test_8_EB2022_995_0Ma"
	create_remnant.check_end_time_of_rift_point_features(rift_point_features_records_csv, temp_rift_point_features, time_interval, rotation_model, reference, modelname, yearmonthday)
def main():
	max_reconstruction_time_for_start_div = 2800.00
	min_reconstruction_time_for_start_div = 0.00
	#find_possible_RRR(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, yearmonthday)
	#find_triple_junction_coordinates(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div)
	modify_end_age_of_triple_junction_RRR_based_on_spatial_rlxn_w_SuperGDU(max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, time_interval)
	#check_end_time_of_rift_point_features_part_2(rift_point_features_records_csv, modified_rift_point_features, time_interval, rotation_model, reference, yearmonthday)

if __name__=='__main__':
	main()