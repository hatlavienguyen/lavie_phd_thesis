#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import math
import pandas as pd
import numpy as np

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def find_stage_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,from_time,to_time,reference_frame):
	"""
	Relative stage reconstruction is a reconstruction from any from_time to any to_time between any two GDUIDS
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		#print('moving_plate_id')
		#print(moving_plate_id)
		#print('fixed_plate_id')
		#print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		#print("Euler_pole,angle_rads")
		#print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		#print("lat,lon,angle_degrees")
		#print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		#print("Warning in find_rift_segment_and_transform_faults")
		#print("Warning finite_rotation_1 is identity")
		#print(moving_plate_id, fixed_plate_id, reference_frame)
		#print("from_time,to_time")
		#print(from_time,to_time)
		#print('moving_plate_id')
		#print(moving_plate_id)
		#print('fixed_plate_id')
		#print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		#print("Euler_pole,angle_rads")
		#print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		#print("lat,lon,angle_degrees")
		#print(lat,lon,angle_degrees)
		return finite_rotation_1

def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def find_new_valid_pairs_of_SuperGDU_to_evaluate_kinematics(supergdu_features, rift_csv, conv_csv, min_threshold_distance_btwn_sgdu, max_threshold_distance_btwn_sgdu, time_interval, rotation_model, reference, modelname, yearmonthday):
	rift_df = pd.read_csv(rift_csv)
	conv_df = pd.read_csv(conv_csv)
	dic_of_pair_sgdu_features = {}
	output_dic = {'reconstruction_time':[],'ref_sgdu':[],'other_sgdu':[]}
	valid_other_sgdu_features = []
	for supergdu_ft in supergdu_features:
		ref_sgdu_name = supergdu_ft.get_name()
		
		#hard code for testing IND and AUS
		#tested_sgdu_name = ['79316', '79329', '79379', '79390', '79452', '79459', '79636']
		#if (ref_sgdu_name not in dic_of_pair_sgdu_features and ref_sgdu_name in tested_sgdu_name):
		if (ref_sgdu_name not in dic_of_pair_sgdu_features):
			dic_of_pair_sgdu_features[ref_sgdu_name] = {}
			all_ref_sgdu_feats = [ft for ft in supergdu_features if ft.get_name() == ref_sgdu_name]
			begin_sgdu_age, end_sgdu_age = supergdu_ft.get_valid_time()
			reconstruction_time = begin_sgdu_age - time_interval
			end_evaluation_time = end_sgdu_age + time_interval
			while (reconstruction_time >= end_evaluation_time):
				valid_other_sgdu_features[:] = []
				for other_sgdu_ft in supergdu_features:
					other_sgdu_name = other_sgdu_ft.get_name()
					if (other_sgdu_ft.is_valid_at_time(reconstruction_time) and other_sgdu_name != ref_sgdu_name):
						valid_other_sgdu_features.append(other_sgdu_ft)
				for valid_other_sgdu_ft in valid_other_sgdu_features:
					valid_other_sgdu_name = valid_other_sgdu_ft.get_name()
					if (valid_other_sgdu_name not in dic_of_pair_sgdu_features[ref_sgdu_name]):
						current_interested_other_sgdu_feats = [ft for ft in valid_other_sgdu_features if ft.get_name() == valid_other_sgdu_name]
						all_other_sgdu_feats = [ft for ft in valid_other_sgdu_features if (ft.get_name() != valid_other_sgdu_name and ft.get_name() != ref_sgdu_name)]
						reconstructed_all_other_sgdu_feats = []
						reconstructed_current_other_sgdu_feats = []
						reconstructed_ref_sgdu_feats = []
						if (reference is None):
							pygplates.reconstruct(all_ref_sgdu_feats,rotation_model,reconstructed_ref_sgdu_feats,reconstruction_time,group_with_feature = True)
							pygplates.reconstruct(current_interested_other_sgdu_feats,rotation_model,reconstructed_current_other_sgdu_feats,reconstruction_time,group_with_feature = True)
							pygplates.reconstruct(all_other_sgdu_feats,rotation_model,reconstructed_all_other_sgdu_feats,reconstruction_time,group_with_feature = True)
						else:
							pygplates.reconstruct(all_ref_sgdu_feats,rotation_model,reconstructed_ref_sgdu_feats,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
							pygplates.reconstruct(current_interested_other_sgdu_feats,rotation_model,reconstructed_current_other_sgdu_feats,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
							pygplates.reconstruct(all_other_sgdu_feats,rotation_model,reconstructed_all_other_sgdu_feats,reconstruction_time,anchor_plate_id = reference,group_with_feature = True)
						final_reconstructed_ref_sgdu_feats = find_final_reconstructed_geometries(reconstructed_ref_sgdu_feats,pygplates.PolygonOnSphere)
						final_reconstructed_current_other_sgdu_feats = find_final_reconstructed_geometries(reconstructed_current_other_sgdu_feats,pygplates.PolygonOnSphere)
						final_reconstructed_all_other_sgdu_feats = find_final_reconstructed_geometries(reconstructed_all_other_sgdu_feats,pygplates.PolygonOnSphere)
						for ref_sgdu_ft, reconstructed_ref_sgdu in final_reconstructed_ref_sgdu_feats:
							ref_sgdu_repgduid = ref_sgdu_ft.get_reconstruction_plate_id()
							is_already_existed = False
							for current_other_sgdu_ft, reconstructed_other_sgdu in final_reconstructed_current_other_sgdu_feats:
								curent_other_sgdu_repgduid = current_other_sgdu_ft.get_reconstruction_plate_id()
								#check whether previously when we perform kinematic evaluation we have checked this pair of sgdu
								#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
								records_from_rift = rift_df.loc[(((rift_df['lrepgduid'] == ref_sgdu_repgduid) & (rift_df['rrepgduid'] == curent_other_sgdu_repgduid)) | ((rift_df['rrepgduid'] == ref_sgdu_repgduid) & (rift_df['lrepgduid'] == curent_other_sgdu_repgduid))) & (rift_df['start_div'] == reconstruction_time)]
								if (len(records_from_rift) > 0):
									is_already_existed = True
									#break
								else:
									#end_conv,conv_name,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
									records_from_conv = conv_df.loc[(((conv_df['lrepgduid'] == ref_sgdu_repgduid) & (conv_df['rrepgduid'] == curent_other_sgdu_repgduid)) | ((conv_df['rrepgduid'] == ref_sgdu_repgduid) & (conv_df['lrepgduid'] == curent_other_sgdu_repgduid))) & (conv_df['end_conv'] == reconstruction_time)]
									if (len(records_from_conv) > 0):
										is_already_existed = True
										#break
									else:
										is_already_existed == False
										break
							#debug
							# if (ref_sgdu_name in tested_sgdu_name and valid_other_sgdu_name in tested_sgdu_name):
								# print('ref_sgdu_name', ref_sgdu_name, 'valid_other_sgdu_name', valid_other_sgdu_name)
								# print('is_already_existed', is_already_existed)
							
							if (is_already_existed == False):
								#find the pair
								is_valid_pair_of_line_fts = True
								total_stage_rel_rot_of_1_to_2 = find_stage_relative_reconstruction_rotation_(rotation_model,ref_sgdu_repgduid,curent_other_sgdu_repgduid,float(reconstruction_time+time_interval),reconstruction_time,reference)
								total_stage_rel_rot_of_2_to_1 = find_stage_relative_reconstruction_rotation_(rotation_model,curent_other_sgdu_repgduid,ref_sgdu_repgduid,float(reconstruction_time+time_interval),reconstruction_time,reference)
								if (total_stage_rel_rot_of_1_to_2 is not None):
									if (total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == True):
										is_valid_pair_of_line_fts = False
									else:
										if (total_stage_rel_rot_of_2_to_1 is not None):
											if (total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == True):
												is_valid_pair_of_line_fts = False
										else:
											is_valid_pair_of_line_fts = False
								else:
									is_valid_pair_of_line_fts = False
								if(is_valid_pair_of_line_fts == True):
									#lat1, lon1 = reconstructed_ref_sgdu.get_interior_centroid().to_lat_lon()
									#lat2, lon2 = reconstructed_other_sgdu.get_interior_centroid().to_lat_lon()
									
									#find the closest points rather than interior centroids
									_,closest_on_ref_sgdu,closest_on_other_sgdu = pygplates.GeometryOnSphere.distance(reconstructed_ref_sgdu, reconstructed_other_sgdu, return_closest_positions = True)
									lat1, lon1 = closest_on_ref_sgdu.to_lat_lon()
									lat2, lon2 = closest_on_other_sgdu.to_lat_lon()
									distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
									if (distance_in_km >= min_threshold_distance_btwn_sgdu and distance_in_km < max_threshold_distance_btwn_sgdu):
										#find two closest points
										distance_rad, intersection_on_ref_sgdu, intersection_on_other_sgdu = pygplates.GeometryOnSphere.distance(reconstructed_ref_sgdu, reconstructed_other_sgdu, return_closest_positions = True)
										temporary_line_connecting_points = pygplates.PolylineOnSphere([intersection_on_ref_sgdu,intersection_on_other_sgdu])
										for possible_intersecting_sgdu_ft, reconstructed_possible_intersecting_sgdu in final_reconstructed_all_other_sgdu_feats:
											if (reconstructed_possible_intersecting_sgdu.partition(temporary_line_connecting_points) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
												is_valid_pair_of_line_fts = False
												break
								if (is_valid_pair_of_line_fts == True):
									dic_of_pair_sgdu_features[ref_sgdu_name][valid_other_sgdu_name] = reconstruction_time

								###old-way
								# for current_other_sgdu_ft, reconstructed_other_sgdu in final_reconstructed_current_other_sgdu_feats:
									# total_stage_rel_rot_of_1_to_2 = find_stage_relative_reconstruction_rotation_(rotation_model,ref_sgdu_repgduid,curent_other_sgdu_repgduid,float(reconstruction_time+time_interval),reconstruction_time,reference)
									# total_stage_rel_rot_of_2_to_1 = find_stage_relative_reconstruction_rotation_(rotation_model,curent_other_sgdu_repgduid,ref_sgdu_repgduid,float(reconstruction_time+time_interval),reconstruction_time,reference)
									# if (total_stage_rel_rot_of_1_to_2 is not None):
										# if (total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == True):
											# is_valid_pair_of_line_fts = False
										# else:
											# if (total_stage_rel_rot_of_2_to_1 is not None):
												# if (total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == True):
													# is_valid_pair_of_line_fts = False
											# else:
												# is_valid_pair_of_line_fts = False
									# else:
										# is_valid_pair_of_line_fts = False
									# if (is_valid_pair_of_line_fts == False):
										# break
									# else:
										# lat1, lon1 = reconstructed_ref_sgdu.get_interior_centroid().to_lat_lon()
										# lat2, lon2 = reconstructed_other_sgdu.get_interior_centroid().to_lat_lon()
										# distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
										# if (distance_in_km <= threshold_distance_btwn_sgdu):
											# #find two closest points
											# distance_rad, intersection_on_ref_sgdu, intersection_on_other_sgdu = pygplates.GeometryOnSphere.distance(reconstructed_ref_sgdu, reconstructed_other_sgdu, return_closest_positions = True)
											# temporary_line_connecting_points = pygplates.PolylineOnSphere([intersection_on_ref_sgdu,intersection_on_other_sgdu])
											# for possible_intersecting_sgdu_ft, reconstructed_possible_intersecting_sgdu in final_reconstructed_all_other_sgdu_feats:
												# if (reconstructed_possible_intersecting_sgdu.partition(temporary_line_connecting_points) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
													# is_valid_pair_of_line_fts = False
													# break
								# if (is_valid_pair_of_line_fts == True):
									# dic_of_pair_sgdu_features[ref_sgdu_name] = {valid_other_sgdu_name:reconstruction_time}
								
								#debug
								# if (ref_sgdu_name in tested_sgdu_name and valid_other_sgdu_name in tested_sgdu_name):
									# print('ref_sgdu_name', ref_sgdu_name, 'valid_other_sgdu_name', valid_other_sgdu_name)
									# print('is_valid_pair_of_line_fts', is_valid_pair_of_line_fts)
									# print('dic_of_pair_sgdu_features[ref_sgdu_name][valid_other_sgdu_name]',dic_of_pair_sgdu_features[ref_sgdu_name][valid_other_sgdu_name])
								
								if (is_valid_pair_of_line_fts == True):
									break
							
							#make sure to record properly
							elif (is_already_existed == True):
								if (valid_other_sgdu_name not in dic_of_pair_sgdu_features[ref_sgdu_name]):
									dic_of_pair_sgdu_features[ref_sgdu_name][valid_other_sgdu_name] = -1
				
				list_of_already_recorded_pairs = []
				for ref_sgdu_name in dic_of_pair_sgdu_features:
					#print("ref_sgdu_name",ref_sgdu_name)
					dic_of_other_sgdu_name = dic_of_pair_sgdu_features[ref_sgdu_name]
					for other_sgdu_name in dic_of_other_sgdu_name:
						#print("other_sgdu_name",other_sgdu_name)
						reconstruction_time_eval = dic_of_other_sgdu_name[other_sgdu_name]
						pair_sgdus = ref_sgdu_name+"_"+other_sgdu_name
						rev_pair_sgdus = other_sgdu_name+"_"+ref_sgdu_name
						#print("reconstruction_time_eval",reconstruction_time_eval)
						if (reconstruction_time_eval != -1):
							if (pair_sgdus not in list_of_already_recorded_pairs and rev_pair_sgdus not in list_of_already_recorded_pairs):
								output_dic['reconstruction_time'].append(reconstruction_time_eval)
								output_dic['ref_sgdu'].append(ref_sgdu_name)
								output_dic['other_sgdu'].append(other_sgdu_name)
								list_of_already_recorded_pairs.append(pair_sgdus)
				reconstruction_time = reconstruction_time - time_interval
	# for ref_sgdu_name in dic_of_pair_sgdu_features:
		# print("ref_sgdu_name",ref_sgdu_name)
		# dic_of_other_sgdu_name = dic_of_pair_sgdu_features[ref_sgdu_name]
		# for other_sgdu_name in dic_of_other_sgdu_name:
			# print("other_sgdu_name",other_sgdu_name)
			# reconstruction_time_eval = dic_of_other_sgdu_name[other_sgdu_name]
			# print("reconstruction_time_eval",reconstruction_time_eval)
			# if (reconstruction_time_eval != -1):
				# output_dic['reconstruction_time'].append(reconstruction_time_eval)
				# output_dic['ref_sgdu'].append(ref_sgdu_name)
				# output_dic['other_sgdu'].append(other_sgdu_name)
	output_df = pd.DataFrame.from_dict(output_dic)
	output_df.to_csv('valid_pairs_of_SuperGDU_to_evaluate_kinematics_'+modelname+'_'+yearmonthday+'.csv')

def main():
	#supergdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	supergdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
	rift_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	conv_csv = r"conv_features_records_for_2800.0_0.0_test_30_short_conv_PalaeoPlatesJan2023_20231023.csv"
	min_threshold_distance_btwn_sgdu = 2000.00
	max_threshold_distance_btwn_sgdu = 20000.00
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	#begin_reconstruction_time = 155.00
	#end_reconstruction_time = 150.00
	time_interval = 5.00
	reference = 700
	modelname = "test_4_PalaeoPlatesendJan2023"
	yearmonthday = "20240331"
	find_new_valid_pairs_of_SuperGDU_to_evaluate_kinematics(supergdu_features, rift_csv, conv_csv, min_threshold_distance_btwn_sgdu, max_threshold_distance_btwn_sgdu, time_interval, rotation_model, reference, modelname, yearmonthday)

if __name__ == '__main__':
	main()