import sys
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import geopandas as gpd
import pandas as pd

def create_list_of_records_of_gplates_fid_and_polygid(list_of_polygon_features_shp,modelname,yearmonthday):
	dic_of_fid_and_polygid = {}
	required_manual_check = []
	output_list = []
	for shp_file in list_of_polygon_features_shp:
		geopandas_dataframe = gpd.read_file(shp_file)
		series_of_fid_and_polygid = geopandas_dataframe[['FEATURE_ID','POLYGID','COID','PlateID','PlateName','OBJECTID_1']]
		for fid,polygid,coid,plateid,name,objid in series_of_fid_and_polygid.values:
			if (fid in dic_of_fid_and_polygid):
				dic_of_fid_and_polygid[fid].append((polygid,coid,plateid,name,objid))
			else:
				dic_of_fid_and_polygid[fid]=[(polygid,coid,plateid,name,objid)]
	for fid in dic_of_fid_and_polygid:
		list_of_polygid = dic_of_fid_and_polygid[fid]
		if (len(list_of_polygid) > 1):
			current_record = None
			found_diff = False
			for polygid,coid,plateid,name,objid in list_of_polygid:
				if (current_record is None):
					current_record = (polygid,coid,plateid,name,objid)
				else:
					prev_polygid,prev_coid,prev_plateid,prev_name,prev_objid = current_record
					if (prev_polygid != polygid or prev_coid != coid or prev_plateid != plateid or prev_name != name or prev_objid != objid):
						required_manual_check.append((fid,prev_polygid,prev_coid,prev_plateid,prev_name,prev_objid))
						found_diff = True
						current_record = (polygid,coid,plateid,name,objid)
			prev_polygid,prev_coid,prev_plateid,prev_name,prev_objid = current_record
			if (found_diff == True):
				required_manual_check.append((fid,prev_polygid,prev_coid,prev_plateid,prev_name,prev_objid))
			else:
				output_list.append((fid,prev_polygid,prev_coid,prev_plateid,prev_name,prev_objid))
		else:
			polygid,coid,plateid,name,objid = list_of_polygid[0]
			output_list.append((fid,polygid,coid,plateid,name,objid))
	output_dataframe = pd.DataFrame.from_records(output_list, columns = ['fid','polygid','coid','plateid','platename','objid'])
	filename = modelname+'_records_of_gplates_fid_and_polygid_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,sep=';',index=False)
	
	output_dataframe = pd.DataFrame.from_records(required_manual_check, columns = ['fid','polygid','coid','plateid','platename','objid'])
	filename = modelname+'_required_manual_check_records_of_gplates_fid_and_polygid_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,sep=';',index=False)

def assign_polygid_and_QGIS_or_self_fid_generated_for_original_polygon_features(fid_and_polygid_csv,polygon_features_shp,modelname,yearmonthday):
	# fid_polygid_df = pd.read_csv(fid_and_polygid_csv,delimiter=';',header=0)
	# series_of_fid_and_polygid = fid_polygid_df[['fid','polygid','coid','plateid','platename']]
	# featurecollection = pygplates.FeatureCollection(polygon_features_shp)
	# for fid,polygid,coid,plateid,platename in series_of_fid_and_polygid.values:
		# #print(fid)
		# for ft in featurecollection:
			# if (ft.get_feature_id() is not None):
				# if (ft.get_feature_id().get_string() == fid):
					# if (ft.get_shapefile_attribute('COID') == coid and ft.get_shapefile_attribute('PlateName') == platename and ft.get_reconstruction_plate_id()==plateid):
						# ft.set_shapefile_attribute('POLYGID',polygid)
			# else:
				# if (ft.get_shapefile_attribute('COID') == coid and ft.get_shapefile_attribute('PlateName') == platename and ft.get_reconstruction_plate_id()==plateid):
					# ft.set_shapefile_attribute('POLYGID',polygid)
					# ft.set_shapefile_attribute('FEATURE_ID',fid)
	# output_filename = modelname+'w_fid_and_polygid_'+yearmonthday+'.shp'
	# featurecollection.write(output_filename)
	
	fid_polygid_df = pd.read_csv(fid_and_polygid_csv,delimiter=';',header=0)
	series_of_fid_and_polygid = fid_polygid_df[['fid','polygid','coid','plateid','platename']]
	geodf = gpd.read_file(polygon_features_shp)
	for fid,polygid,coid,plateid,platename in series_of_fid_and_polygid.values:
		selected_records = geodf.loc[(geodf['FEATURE_ID']==fid) & (geodf['COID']==coid) & (geodf['PlateName']==platename) & (geodf['PlateID']==plateid)]
		if (len(selected_records)==1):
			geodf.loc[(geodf['FEATURE_ID']==fid) & (geodf['COID']==coid) & (geodf['PlateName']==platename) & (geodf['PlateID']==plateid),'POLYGID'] = polygid
		else:
			geodf.loc[(geodf['COID']==coid) & (geodf['PlateName']==platename) & (geodf['PlateID']==plateid),'POLYGID'] = polygid
			geodf.loc[(geodf['COID']==coid) & (geodf['PlateName']==platename) & (geodf['PlateID']==plateid),'FEATURE_ID'] = fid
	geodf.to_file(modelname+'_w_fid_and_polygid_'+yearmonthday+'.shp')

def main():
	shp_1 = r'C:\Users\lavie\Desktop\Research\Fall2022\PalaeoPlatesOct2022\Final_Valid_PlatePolygons_Continental_without_ANT_Oct_2022_ESRI_45009.shp'
	shp_2 = r'C:\Users\lavie\Desktop\Research\Fall2022\PalaeoPlatesOct2022\Valid_ANT_PlatePolygons_Continental_Oct_2022_EPSG_3031.shp'
	shp_3 = r'C:\Users\lavie\Desktop\Research\Fall2022\PalaeoPlatesOct2022\Valid_test_2_Artic_PalaeoPlates_Oct_2022_EPSG_3995.shp'
	shp_4 = r'C:\Users\lavie\Desktop\Research\Fall2022\PalaeoPlatesOct2022\Refactored_Valid_PlateExtra_Top_Oct_2022_EPSG_4326.shp'
	shp_5 = r'C:\Users\lavie\Desktop\Research\Fall2022\PalaeoPlatesOct2022\Refactored_Valid_PlateExtra_Bottom_Oct_2022_EPSG_4326.shp'
	list_of_polygon_features_shp = [shp_1,shp_2,shp_3,shp_4,shp_5]
	modelname = 'test_3_PalaeoPlatesendOct2022'
	yearmonthday = '20230115'
	#create_list_of_records_of_gplates_fid_and_polygid(list_of_polygon_features_shp,modelname,yearmonthday)
	fid_and_polygid_csv = r'PalaeoPlatesendOct2022_records_of_gplates_fid_and_polygid_20230115.csv'
	polygon_features_shp = r'C:\Users\lavie\Desktop\Research\Fall2022\PalaeoPlatesOct2022\New_Valid_All_PlatePolygons_Continental_Oct_2022_EPSG_4326.shp'
	assign_polygid_and_QGIS_or_self_fid_generated_for_original_polygon_features(fid_and_polygid_csv,polygon_features_shp,modelname,yearmonthday)

if __name__=='__main__':
	main()