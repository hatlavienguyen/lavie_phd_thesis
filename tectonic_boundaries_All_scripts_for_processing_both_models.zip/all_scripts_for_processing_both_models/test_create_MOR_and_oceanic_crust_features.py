import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import create_MOR_and_oceanic_crust_features as create

def main():
	modelname = "test_11_PalaeoPlatesNov2021_test_9"
	yearmonthday = "20220716"
	name_of_table_for_pairs_of_SuperGDUs_and_GDUs = 'test_pairs_of_line_features_at_each_time_reversed_2'
	name_of_table_for_initial_rel_pos_vector_motion = 'test_rel_pos_vel_vector_motion_at_each_time_reversed_2'
	name_of_table_for_subsequent_rel_pos_vector_motion = 'test_subsequent_rel_pos_vel_vector_motion_at_each_time_reversed_2'
	name_of_table_for_MOR_features = 'test_mor_location_fts_at_each_time_reversed_2'
	name_of_table_for_recover_temporal_MOR_location_feats = 'recover_MOR_location_fts_at_each_time_reversed'
	name_of_table_for_recover_div_features = 'recover_div_location_fts_at_each_time_reversed'
	name_of_table_for_summary_of_tectonic_motion = "test_summary_of_tectonic_motion_from_gondwana_rev_2"
	#name_of_table_for_summary_of_tectonic_motion = "test_summary_of_tectonic_boundaries_from_nuna_rev_2"
	name_of_table_for_temporal_MOR_location_feats = "test_mor_location_fts_at_each_time_reversed_2"
	name_of_table_for_summary_of_MOR_location_fts = "summary_of_MOR_location_fts_reversed"
	name_of_table_for_linear_MOR_feats = "linear_MOR_fts_reversed"
	max_begin_reconstruction_time = 510.00
	interval = 5.00 #this has to be the same time interval when we ran tectonic_motion
	create.summarize_temporal_MOR_location_features_no_inner_join_query(name_of_table_for_summary_of_tectonic_motion, name_of_table_for_temporal_MOR_location_feats, name_of_table_for_recover_temporal_MOR_location_feats, name_of_table_for_summary_of_MOR_location_fts, max_begin_reconstruction_time, modelname, yearmonthday)
	#summary_of_temp_MOR_location_fts_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\summary_of_temporal_MOR_location_features_for_test_11_PalaeoPlatesNov2021_test_4_20220713.shp"
	summary_of_temp_MOR_location_fts = pygplates.FeatureCollection(summary_of_temp_MOR_location_fts_file)
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	threshold_degrees = 10.00 # threshold to be considered to create a transform between two consecutive MOR
	reference = 700
	#create.create_MOR_linear_features_from_summary_of_MOR_location_features_no_inner_join_query_2(name_of_table_for_summary_of_MOR_location_fts, name_of_table_for_linear_MOR_feats, summary_of_temp_MOR_location_fts, threshold_degrees, interval, rotation_model, reference, modelname, yearmonthday)
	# output_file = r"summary_of_MOR_location_features_for_test_11_PalaeoPlatesNov2021_20220702.shp"
	# output_feature_collection = pygplates.FeatureCollection(output_file)
	# print("number of MOR location fts:",len(output_feature_collection))
if __name__=='__main__':
	main()