from multiprocessing import Pool
from os import environ
from time import sleep
import pygplates
import find_order_to_connect_con_ocn_line_feats as find_order


ncpus = int(environ['SLURM_CPUS_PER_TASK'])

#Merdith et al 2021
# common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/supergdu_and_members_gdu_at_{time}_for_Merdith_et_al_EB2021_20230428.csv"
# sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/final_supergdu_feats_995.0_0.0_Merdith_et_al_EB2021_20230428.shp"
# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/1000_0_rotfile_Merdith_et_al.rot"
# rotation_model = pygplates.RotationModel(rotation_file)
# temp_rift_point_features_file = r"rift_point_features_for_test_8_EB2022_20231020.shp"
# temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
# temp_unwanted_rift_point_features_file = r"unwanted_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
# temp_unwanted_rift_point_features = pygplates.FeatureCollection(temp_unwanted_rift_point_features_file)
# rift_point_features_records_csv = r"rift_point_features_records_for_test_8_EB2022_20231020.csv"
# plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_EB2022_20231023.shp"
# plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
# yearmonthday = "20231029"
# reference = 0
# time_interval = 5.00

#PalaeoPlatesendJan2023
time_interval = 5.00
reference = 700
modelname = 'PalaeoPlatesendJan2023'
yearmonthday = '20231113'
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)
# #sgdu_distance_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/QGISfixedPalaeoPlatesendJan2023_smallest_dist_km_btw_valid_sgdu_feats_3420.0_0.0_5.0_20230224.csv"
# #sgdu_outer_gdu_members_csv = r"PalaeoPlatesOct2022_sgu_and_outer_gdu_members_from_3420.0_0.0_20230204.csv"
sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
gdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
gdu_features = pygplates.FeatureCollection(gdu_features_file)
line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_segment_POLYGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230921.shp"
con_ocn_line_features = pygplates.FeatureCollection(line_features_file)

def calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval):
	max_min_rec_time_list = []
	value = maximum_of_reconstruction_period
	while (value >= minimum_of_reconstruction_period):
		min_recon = value - reconstruction_interval
		max_min_rec_time_list.append((value,min_recon))
		value = min_recon
	return max_min_rec_time_list

def find_order_to_connect_complete_bdn_of_sgdu_feats_within_a_period(max_reconstruction_time,min_reconstruction_time):
	find_order.find_order_to_connect_con_ocn_line_feats_for_each_sgdu(common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features, con_ocn_line_features, max_reconstruction_time, min_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday)


if __name__ == '__main__':
	maximum_of_reconstruction_period = 2800.00
	minimum_of_reconstruction_period = 0.00
	reconstruction_interval = 200.00
	max_min_rec_time_list = find_order_to_connect_complete_bdn_of_sgdu_feats_within_a_period(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div)

	with Pool(ncpus) as pool:
		#find isochrons
		#results = pool.starmap(find_order_to_connect_complete_bdn_of_sgdu_feats_within_a_period, max_min_rec_time_list)
		
		print(results)