#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import math
import geopandas as gpd
import pandas as pd
import rotation_utility
import supporting_modules_to_be_converted as supporting
from shapely.ops import nearest_points, linemerge, unary_union
from shapely.geometry import Point, MultiLineString
#import psycopg2
#from config_plate_tectonics import config
import matplotlib.pyplot as plt


def create_topological_points_for_topological_lines(list_of_tuples_fts):
	result_topological_lines = []
	for ft_1,ft_2 in list_of_tuples_fts:
		topological_p1 = pygplates.GpmlTopologicalSection.create(ft_1, topological_geometry_type = pygplates.GpmlTopologicalLine)
		topological_p2 = pygplates.GpmlTopologicalSection.create(ft_2, topological_geometry_type = pygplates.GpmlTopologicalLine)
		topological_line = pygplates.GpmlTopologicalLine([topological_p1,topological_p2])
		result_topological_lines.append(topological_line)
	return result_topological_lines

def create_topological_lines_from_static_line_fts(list_of_tuples_line_ft_and_cond):
	result_topological_sections = []
	for line_ft,cond in list_of_tuples_line_ft_and_cond:
		topological_section = pygplates.GpmlTopologicalSection.create(line_ft,reverse_order = cond,topological_geometry_type = pygplates.GpmlTopologicalLine)
		result_topological_sections.append(topological_section)
	topological_line = pygplates.GpmlTopologicalLine(result_topological_sections)
	return topological_line

def create_a_topological_line_from_static_point_fts(list_of_ordered_point_fts):
	result_topological_sections = []
	for point_ft in list_of_ordered_point_fts:
		topological_section = pygplates.GpmlTopologicalSection.create(point_ft,topological_geometry_type = pygplates.GpmlTopologicalLine)
		result_topological_sections.append(topological_section)
	topological_line = pygplates.GpmlTopologicalLine(result_topological_sections)
	return topological_line

def create_a_topological_polygon_from_static_point_fts(list_of_ordered_point_fts):
	result_topological_sections = []
	for point_ft in list_of_ordered_point_fts:
		topological_section = pygplates.GpmlTopologicalSection.create(point_ft,topological_geometry_type = pygplates.GpmlTopologicalPolygon)
		result_topological_sections.append(topological_section)
	topological_polygon = pygplates.GpmlTopologicalPolygon(result_topological_sections)
	return topological_polygon

def create_topological_sections_from_static_point_fts(list_of_ordered_point_fts):
	result_topological_sections = []
	for point_ft in list_of_ordered_point_fts:
		topological_section = pygplates.GpmlTopologicalSection.create(point_ft,topological_geometry_type = pygplates.GpmlTopologicalPolygon)
		result_topological_sections.append(topological_section)
	return result_topological_sections

def create_list_of_topological_features_from_topological_sections(topological_feature_type, list_of_topological_sections):
	final_topological_features = []
	for topological_section in list_of_topological_sections:
		#creat topological_passive_margins 
		print(topological_section)
		topological_feature = pygplates.Feature.create_topological_feature(topological_feature_type, topological_section)
		final_topological_features.append(topological_feature)
	return final_topological_features
	
def find_pairs_of_points_for_passive_margins_associated_with_rift(list_of_transform_point_fts):
	dic = {}
	tuple_of_point_fts = []
	for transform_point_ft in list_of_transform_point_fts:
		plate_id = transform_point_ft.get_reconstruction_plate_id()
		name = transform_point_ft.get_name()
		if (name not in dic):
			print(name)
			print(plate_id)
			points_1 = [point_ft_1 for point_ft_1 in list_of_transform_point_fts if (point_ft_1.get_name() == name and point_ft_1.get_reconstruction_plate_id() == plate_id)]
			points_2 = [point_ft_2 for point_ft_2 in list_of_transform_point_fts if (point_ft_2.get_name() == name and point_ft_2.get_reconstruction_plate_id() != plate_id)]
			print(len(points_1),len(points_2))
			if (len(points_1) == len(points_2)):
				#simply choose 1 as representative - because we have duplicates
				tuple_of_point_fts.append((points_1[0],points_2[0]))
				#append the name to the list to avoid processing same thing twice
				dic[name] = (points_1[0],points_2[0])
	list_of_tuples = dic.values()
	print("list_of_tuples")
	print(list_of_tuples)
	return list_of_tuples
		
def get_nearest_values(row, other_gdf, point_column = 'geometry', value_column = "geometry"):
	"""Find the nearest point and return the corresponding value from specified value column."""
	#reference:https://automating-gis-processes.github.io/site/notebooks/L3/nearest-neighbour.html#:~:text=Nearest%20point%20using%20Shapely&text=In%20the%20tuple%2C%20the%20first,coordinates%20(0%2C%201.45).

def simplify_complex_LineString(linestring):
	multiple_lines = unary_union(linestring)
	return multiple_lines
		
def create_topological_boundaries_from_any_tectonic_boundary_features(featType,list_of_passive_margin_fts, at_age, rotation_model, reference, test_number, write_output):
	reconstructed_passive_margin_features = []
	passive_margin_fts = [ft for ft in list_of_passive_margin_fts if ft.is_valid_at_time(at_age)]
	final_fts = []
	if (reference is not None):
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,group_with_feature = True)
	final_reconstructed_line_ft = supporting.find_final_reconstructed_geometries(reconstructed_passive_margin_features,pygplates.PolylineOnSphere)
	polyline_fts_and_wrapped_lines = []
	list_of_tesselated_clone_fts = []
	list_of_unique_line_ft_name = []
	multiple_lines = []
	for ft,line in final_reconstructed_line_ft:
		#check for duplicates
		line_1_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line)
		if (len(final_fts) == 0):
			final_fts.append((ft,line))
		else:
			already_included = False
			for ft_2,line_2 in final_fts:
				if (ft_2.get_feature_id() != ft.get_feature_id()):
					line_2_converted = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
					if (line_1_converted.almost_equals(line_2_converted,decimal = 4)): #might need to check for the oldest feature
						already_included = True
						# if (ft.get_feature_id().get_string() == 'GPlates-19f73777-1662-4396-a11f-c454c996f76a'):
							# print('ft_2.get_feature_id().get_string()')
							# print(ft_2.get_feature_id().get_string())
							# print(ft_2.get_reconstruction_plate_id())
							# print(ft_2.get_feature_type())
							# print(line_1_converted.coords)
							# print(line_2_converted.coords)
						break
					else:
						already_included = False
			# if (ft.get_reconstruction_plate_id() == 10016):
				# print(ft.get_feature_id().get_string())
				# print(already_included)
			if (already_included == False):
				final_fts.append((ft,line))
	for line_ft,line in final_fts:
		#wrap line with the DateLineWrapper
		date_line_wrapper = pygplates.DateLineWrapper()
		wrapped_polylines = date_line_wrapper.wrap(line)
		for tesselated_line in wrapped_polylines:
			#print(tesselated_line.get_points())
			new_line = pygplates.PolylineOnSphere(tesselated_line.get_points())
			clone_feature = line_ft.clone()
			clone_feature.set_geometry(new_line)
			clone_feature.set_name('wrapped_line_ft_'+line_ft.get_name())
			line_in_shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(new_line)
			multiple_lines.append(line_in_shapely)
			polyline_fts_and_wrapped_lines.append((line_ft,line_in_shapely))
			
			list_of_tesselated_clone_fts.append(clone_feature)
	if (reference is not None):
		pygplates.reverse_reconstruct(list_of_tesselated_clone_fts,rotation_model,at_age,reference)
	else:
		pygplates.reverse_reconstruct(list_of_tesselated_clone_fts,rotation_model,at_age)
	# outputFeatureCollection = pygplates.FeatureCollection(list_of_tesselated_clone_fts)
	# outputFile = "tesselated_clone_line_fts_at_age_"+str(at_age)+"_"+str(test_number)+".gpml"
	# outputFeatureCollection.write(outputFile)
	
	input_for_line_merge = MultiLineString(multiple_lines)
	results = linemerge(input_for_line_merge)
	#results = unary_union(multiple_lines)
	print("Here are geom_type of results of linemerge:")
	print(results.geom_type)
	if (results.geom_type == 'LineString'):
		l = results
		if (l.is_simple == False):
			results = simplify_complex_LineString(l)
			l = results
	if (results.geom_type == 'LineString'):
		list_of_references = []
		output_line_ft_from_linemerge = []
		converted_line = supporting.convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(results)
		if (reference is not None):
			#featType = pygplates.FeatureType.gpml_passive_continental_boundary
			new_line_ft_from_linemerge = pygplates.Feature.create_reconstructable_feature(featType,\
																		converted_line,\
																		valid_time = (at_age,at_age - 1.00),\
																		reconstruction_plate_id = reference)
			pygplates.reverse_reconstruct(new_line_ft_from_linemerge,rotation_model,at_age,reference)
			output_line_ft_from_linemerge.append(new_line_ft_from_linemerge)
		else:
			#featType = pygplates.FeatureType.gpml_passive_continental_boundary
			new_line_ft_from_linemerge = pygplates.Feature.create_reconstructable_feature(featType,\
																		converted_line,\
																		valid_time = (at_age,at_age - 1.00))
			pygplates.reverse_reconstruct(new_line_ft_from_linemerge,rotation_model,at_age)
			output_line_ft_from_linemerge.append(new_line_ft_from_linemerge)
		outputFeatureCollection = pygplates.FeatureCollection(output_line_ft_from_linemerge)
		outputFile = "test_output_for_ordering_of_line_features_at_age_"+str(at_age)+"_"+str(test_number)+".shp"
		outputFeatureCollection.write(outputFile)
		
		# lat_lon_list = converted_line.to_lat_lon_list()
		# number_of_points = len(lat_lon_list)
		# for lat,lon in lat_lon_list:
		# for i in range(number_of_points - 1):
			# lat,lon = lat_lon_list[i]
			# for line_ft,line in polyline_fts_and_wrapped_lines:
				# first_point = supporting.get_first_point_of_line(line)
				# first_lat,first_lon = first_point.to_lat_lon()
				# last_point = supporting.get_last_point_of_line(line)
				# last_lat,last_lon = last_point.to_lat_lon()
				# if (first_lat == lat and first_lon == lon):
					# list_of_references.append((line_ft,False))
					# break
				# elif (last_lat == lat and last_lon == lon):
					# list_of_references.append((line_ft,True))
					# break
					
		#find all possible line segments
		candidates = []
		included_refs = []
		left_over_features_lines = []
		for line_ft, line_Shapely in polyline_fts_and_wrapped_lines:
			if (l.contains(line_Shapely)):
				candidates.append((line_ft,line_Shapely))
		#find the line segment with the starting point
		start_point = l.coords[0]
		start_point_Shapely = Point(start_point)
		start_line_ft = None
		start_line = None
		for line_ft, line_Shapely in candidates:
			if (line_Shapely.touches(start_point_Shapely)):
				n = len(line_Shapely.coords)
				p1 = Point(line_Shapely.coords[0])
				p2 = Point(line_Shapely.coords[n-1])
				if (p1.distance(start_point_Shapely) <= p2.distance(start_point_Shapely)):
					list_of_references.append((line_ft,False))
				else:
					list_of_references.append((line_ft,True))
				start_line = line_Shapely
				start_line_ft = line_ft
				break
		if (start_line_ft is None):
			print ("Error in create_topological_passive_margins_from_passive_margin_features")
			print ("Error could not find the appropriate line feature for the start:")
			print (start_point)
			print ('number_of_candidates')
			print (len(candidates))
			fig,ax = plt.subplots()
			xs = [c[0] for c in l.coords]
			ys = [c[1] for c in l.coords]
			ax.plot(xs, ys, color = 'green', marker = 'o')
			for line_ft, line_Shapely in candidates:
				x = [c[0] for c in line_Shapely.coords]
				y = [c[1] for c in line_Shapely.coords]
				ax.plot(x, y, color = 'red', marker = 'o', linestyle = 'dashed')
			# for line_ft, line_Shapely in candidates:
				# print(line_ft.get_feature_id())
				# for c in line_Shapely.coords:
					# print(c)
			# print ('here is line l')
			# for c in l.coords:
				# print(c)
			# for line_ft, line_Shapely in polyline_fts_and_wrapped_lines:
				# print(line_ft.get_feature_id())
				# for c in line_Shapely.coords:
					# print(c)
			plt.show()
			#exit()
		if (start_line_ft is not None):
			included_refs.append(start_line_ft.get_feature_id())
			cont_line_ft = None
			cont_line = None
			stop_finding_candidates = False
			number_of_iteration = 0
			#while ((len(candidates) - len(list_of_references)) > 0):
			while (number_of_iteration < len(candidates)):
				number_of_iteration = number_of_iteration + 1
				print('len(candidates)')
				print(len(candidates))
				print('len(list_of_references)')
				print(len(list_of_references))
				for line_ft, line_Shapely in candidates:
					n = len(line_Shapely.coords)
					if (cont_line is None and cont_line_ft is None):
						if (line_ft.get_feature_id() != start_line_ft.get_feature_id() and line_Shapely.touches(start_line)):
							p1 = Point(line_Shapely.coords[0])
							p2 = Point(line_Shapely.coords[n-1])
							if (start_line.touches(p1) or start_line.contains(p1)):
								list_of_references.append((line_ft,False))
							else:
								list_of_references.append((line_ft,True))
							included_refs.append(line_ft.get_feature_id())
							cont_line = line_Shapely
							cont_line_ft = line_ft
						# elif (line_ft.get_feature_id() != start_line_ft.get_feature_id() and line_Shapely.crosses(start_line)):
							# p1 = Point(line_Shapely.coords[0])
							# p2 = Point(line_Shapely.coords[n-1])
							# if (start_line.touches(p1) or start_line.contains(p1)):
								# list_of_references.append((line_ft,False))
							# else:
								# list_of_references.append((line_ft,True))
							# included_refs.append(line_ft.get_feature_id())
							# cont_line = line_Shapely
							# cont_line_ft = line_ft
					else:
						if (line_ft.get_feature_id() not in included_refs):
							p1 = Point(line_Shapely.coords[0])
							p2 = Point(line_Shapely.coords[n-1])
							n_cont = len(cont_line.coords)
							p1_cont = Point(cont_line.coords[0])
							p2_cont = Point(cont_line.coords[n_cont-1])
							if (line_Shapely.touches(cont_line)):
								if (cont_line.contains(p1) or cont_line.touches(p1)):
									list_of_references.append((line_ft,False))
								else:
									list_of_references.append((line_ft,True))
								included_refs.append(line_ft.get_feature_id())
								cont_line = line_Shapely
								cont_line_ft = line_ft
							elif (line_Shapely.intersects(cont_line)):
								if (cont_line.contains(p1) or cont_line.touches(p1)):
									list_of_references.append((line_ft,False))
								else:
									list_of_references.append((line_ft,True))
								included_refs.append(line_ft.get_feature_id())
								cont_line = line_Shapely
								cont_line_ft = line_ft
					if (len(candidates) == len(list_of_references)):
						stop_finding_candidates = True
						break
					# elif ((len(candidates) - len(list_of_references)) < 10):
						# if (cont_line is None):
							# stop_finding_candidates = True
							# break
						# else:
							# left_over_features_lines[:] = []
							# for t_line_ft, t_line_Shapely in candidates:
								# if (t_line_ft.get_feature_id() not in included_refs):
									# left_over_features_lines.append((t_line_ft,t_line_Shapely))
							# count_disjoint_candidate = 0
							# for left_over_ft,left_over_line in left_over_features_lines:
								# if (left_over_line.disjoint(cont_line) == True):
									# count_disjoint_candidate = count_disjoint_candidate + 1
							# if (count_disjoint_candidate == len(left_over_features_lines)):
								# stop_finding_candidates = True
				if (stop_finding_candidates == True):
					break
			topological_line = create_topological_lines_from_static_line_fts(list_of_references)
			print("Here is the only topological_line:")
			print(topological_line)
		
		final_topological_passive_margins = []
		topological_line_feature_type = featType
		topological_line_feature = pygplates.Feature.create_topological_feature(topological_line_feature_type, topological_line)
		final_topological_passive_margins.append(topological_line_feature)
		outputFeatureCollection = pygplates.FeatureCollection(final_topological_passive_margins)
		outputFile = "topological_margins_at_"+str(test_number)+"_"+str(at_age)+".gpml"
		outputFeatureCollection.write(outputFile)
		return final_topological_passive_margins
	elif (results.geom_type == 'MultiLineString'):
		dic = {}
		id = 0
		output_line_ft_from_linemerge = []
		candidates = []
		included_refs = []
		left_over_features_lines = []
		print("Number of connected lines")
		print(len(results))
		final_line_results = []
		for l in results:
			simplified_l = None 
			if (l.is_simple == False):
				simplified_l = simplify_complex_LineString(l)
				if (simplified_l.geom_type == 'LineString'):
					final_line_results.append(simplified_l)
				elif (simplified_l.geom_type == 'MultiLineString'):
					for temp_simplified_l in simplified_l:
						final_line_results.append(temp_simplified_l)
			else:
				final_line_results.append(l)
		for l in final_line_results:
			list_of_references = []
			converted_line = supporting.convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(l)
			if (reference is not None):
				#featType = pygplates.FeatureType.gpml_passive_continental_boundary
				new_line_ft_from_linemerge = pygplates.Feature.create_reconstructable_feature(featType,\
																		converted_line,\
																		valid_time = (at_age,at_age - 1.00),\
																		reconstruction_plate_id = reference)
				pygplates.reverse_reconstruct(new_line_ft_from_linemerge,rotation_model,at_age,reference)
				output_line_ft_from_linemerge.append(new_line_ft_from_linemerge)
			else:
				#featType = pygplates.FeatureType.gpml_passive_continental_boundary
				new_line_ft_from_linemerge = pygplates.Feature.create_reconstructable_feature(featType,\
																		converted_line,\
																		valid_time = (at_age,at_age - 1.00))
				pygplates.reverse_reconstruct(new_line_ft_from_linemerge,rotation_model,at_age)
				output_line_ft_from_linemerge.append(new_line_ft_from_linemerge)
			outputFeatureCollection = pygplates.FeatureCollection(output_line_ft_from_linemerge)
			outputFile = "test_output_for_ordering_of_line_features_at_age_"+str(at_age)+"_"+str(test_number)+".shp"
			outputFeatureCollection.write(outputFile)
			
			#find all possible line segments
			candidates[:] = []
			included_refs[:] = []
			for line_ft, line_Shapely in polyline_fts_and_wrapped_lines:
				if (l.contains(line_Shapely)):
					candidates.append((line_ft,line_Shapely))
			#find the line segment with the starting point
			start_point = l.coords[0]
			start_point_Shapely = Point(start_point)
			start_line_ft = None
			start_line = None
			for line_ft, line_Shapely in candidates:
				if (line_Shapely.touches(start_point_Shapely)):
					n = len(line_Shapely.coords)
					p1 = Point(line_Shapely.coords[0])
					p2 = Point(line_Shapely.coords[n-1])
					if (p1.distance(start_point_Shapely) <= p2.distance(start_point_Shapely)):
						list_of_references.append((line_ft,False))
					else:
						list_of_references.append((line_ft,True))
					start_line = line_Shapely
					start_line_ft = line_ft
					break
			if (start_line_ft is None):
				print ("Error in create_topological_passive_margins_from_passive_margin_features")
				print ("Error could not find the appropriate line feature for the start:")
				print (start_point)
				print ('number_of_candidates')
				print (len(candidates))
				fig,ax = plt.subplots()
				xs = [c[0] for c in l.coords]
				ys = [c[1] for c in l.coords]
				ax.plot(xs, ys, color = 'green', marker = 'o')
				for line_ft, line_Shapely in candidates:
					x = [c[0] for c in line_Shapely.coords]
					y = [c[1] for c in line_Shapely.coords]
					ax.plot(x, y, color = 'red', marker = 'o', linestyle = 'dashed')
				plt.show()
				# for line_ft, line_Shapely in candidates:
					# print(line_ft.get_feature_id())
					# for c in line_Shapely.coords:
						# print(c)
				# print ('here is line l')
				# for c in l.coords:
					# print(c)
				# for line_ft, line_Shapely in polyline_fts_and_wrapped_lines:
					# print(line_ft.get_feature_id())
					# for c in line_Shapely.coords:
						# print(c)
				#exit()
			if (start_line_ft is not None):
				included_refs.append(start_line_ft.get_feature_id())
				cont_line_ft = None
				cont_line = None
				stop_finding_candidates = False
				number_of_iteration = 0
				#while ((len(candidates) - len(list_of_references)) > 0):
				while (number_of_iteration < len(candidates)):
					number_of_iteration = number_of_iteration + 1
					print('len(candidates)')
					print(len(candidates))
					print('len(list_of_references)')
					print(len(list_of_references))
					for line_ft, line_Shapely in candidates:
						n = len(line_Shapely.coords)
						if (cont_line is None and cont_line_ft is None):
							if (line_ft.get_feature_id() != start_line_ft.get_feature_id() and (line_Shapely.touches(start_line))):
								p1 = Point(line_Shapely.coords[0])
								p2 = Point(line_Shapely.coords[n-1])
								if (start_line.touches(p1) or start_line.contains(p1)):
									list_of_references.append((line_ft,False))
								else:
									list_of_references.append((line_ft,True))
								included_refs.append(line_ft.get_feature_id())
								cont_line = line_Shapely
								cont_line_ft = line_ft
							# elif (line_ft.get_feature_id() != start_line_ft.get_feature_id() and (line_Shapely.crosses(start_line))):
								# p1 = Point(line_Shapely.coords[0])
								# p2 = Point(line_Shapely.coords[n-1])
								# if (start_line.touches(p1) or start_line.contains(p1)):
									# list_of_references.append((line_ft,False))
								# else:
									# list_of_references.append((line_ft,True))
								# included_refs.append(line_ft.get_feature_id())
								# cont_line = line_Shapely
								# cont_line_ft = line_ft
						else:
							if (line_ft.get_feature_id() not in included_refs):
								p1 = Point(line_Shapely.coords[0])
								p2 = Point(line_Shapely.coords[n-1])
								n_cont = len(cont_line.coords)
								p1_cont = Point(cont_line.coords[0])
								p2_cont = Point(cont_line.coords[n_cont-1])
								if (line_Shapely.touches(cont_line)):
									if (cont_line.contains(p1) or cont_line.touches(p1)):
										list_of_references.append((line_ft,False))
									else:
										list_of_references.append((line_ft,True))
									included_refs.append(line_ft.get_feature_id())
									cont_line = line_Shapely
									cont_line_ft = line_ft
								elif (line_Shapely.intersects(cont_line)):
									if (cont_line.contains(p1) or cont_line.touches(p1)):
										list_of_references.append((line_ft,False))
									else:
										list_of_references.append((line_ft,True))
									included_refs.append(line_ft.get_feature_id())
									cont_line = line_Shapely
									cont_line_ft = line_ft
						if (len(candidates)==len(list_of_references)):
							stop_finding_candidates = True
							break
						# elif (len(candidates) - len(list_of_references) < 10):
							# if (cont_line is None):
								# stop_finding_candidates = True
								# break
							# else:
								# left_over_features_lines[:] = []
								# for t_line_ft, t_line_Shapely in candidates:
									# if (t_line_ft.get_feature_id() not in included_refs):
										# left_over_features_lines.append((t_line_ft,t_line_Shapely))
								# count_disjoint_candidate = 0
								# for left_over_ft,left_over_line in left_over_features_lines:
									# if (left_over_line.disjoint(cont_line) == True):
										# count_disjoint_candidate = count_disjoint_candidate + 1
								# if (count_disjoint_candidate == len(left_over_features_lines)):
									# stop_finding_candidates = True
					if (stop_finding_candidates == True):
						break
				dic[str(id)] = list_of_references
				id = id + 1
		multiple_list_of_references = dic.values()
		multiple_topological_lines = []
		
		for list in multiple_list_of_references:
			topological_line = create_topological_lines_from_static_line_fts(list)
			multiple_topological_lines.append(topological_line)
			
		print("Here are multiple_topological_lines:")
		print(multiple_topological_lines)
		final_topological_passive_margins = []
		#topological_line_feature_type = pygplates.FeatureType.gpml_passive_continental_boundary
		topological_line_feature_type = featType
		for topological_line in multiple_topological_lines:
			#creat topological_passive_margins 
			topological_line_feature = pygplates.Feature.create_topological_feature(topological_line_feature_type, topological_line)
			final_topological_passive_margins.append(topological_line_feature)
		if (write_output == True):
			outputFeatureCollection = pygplates.FeatureCollection(final_topological_passive_margins)
			outputFile = "topological_margins_at_"+str(at_age)+"_"+str(test_number)+".gpml"
			outputFeatureCollection.write(outputFile)

		return final_topological_passive_margins

def create_topological_boundaries_from_any_tectonic_boundary_features_within_period(featType_in_description,featType_create_reconstr_ft,list_of_margin_fts, from_age, to_age, interval, rotation_model, reference, modelname, test_number, write_output, length_of_topological_margins_output_csv_file, yyyymmdd):
	at_age = from_age
	output_all_final_topological_features = []
	list_of_features_to_be_evaluated = []
	list_of_topological_ft_id_and_len = []
	while (at_age > (to_age - interval)):
		list_of_features_to_be_evaluated[:] = []
		
		# if (at_age == from_age):
			# for ft in list_of_margin_fts:
				# if (ft.is_valid_at_time(at_age) == True):
					# list_of_features_to_be_evaluated.append(ft)
		# elif (at_age < from_age):
			# for ft in list_of_margin_fts:
				# if (ft.is_valid_at_time(at_age) == True and ft.is_valid_at_time(at_age + interval) == False):
					# list_of_features_to_be_evaluated.append(ft)
		
		for ft in list_of_margin_fts:
			temp_ft_begin_age,temp_ft_end_age = ft.get_valid_time()
			if (ft.is_valid_at_time(at_age) == True and temp_ft_begin_age > temp_ft_end_age):
				list_of_features_to_be_evaluated.append(ft)
		
		print("list_of_features_to_be_evaluated")
		print(len(list_of_features_to_be_evaluated))
		if (len(list_of_features_to_be_evaluated) > 0):
			final_topological_features = create_topological_boundaries_from_any_tectonic_boundary_features(featType_create_reconstr_ft,list_of_features_to_be_evaluated, at_age, rotation_model, reference, test_number, write_output)
			print("here is final_topological_features")
			print(final_topological_features)
			#resolve topological features to at_age
			if (length_of_topological_margins_output_csv_file is not None):
				# resolved_topologies = []
				# if (reference is not None):
					# pygplates.resolve_topologies(final_topological_features, rotation_model, resolved_topologies, float(at_age), anchor_plate_id = reference, resolve_topology_types = pygplates.ResolveTopologyType.line|pygplates.ResolveTopologyType.boundary)
				# else:
					# pygplates.resolve_topologies(final_topological_features, rotation_model, resolved_topologies, float(at_age), resolve_topology_types = pygplates.ResolveTopologyType.line|pygplates.ResolveTopologyType.boundary)
				# print("resolved_topologies")
				# print(resolved_topologies)
				reconstructed_features = []
				features_to_be_reconstructed = []
				for resolved_ft in final_topological_features:
					reconstructed_features[:] = []
					features_to_be_reconstructed[:] = []
					sections = resolved_ft.get_topological_geometry().get_sections()
					number_of_sections = len(sections)
					print(resolved_ft.get_topological_geometry())
					print(sections)
					for s in sections:
						ft_id = s.get_property_delegate().get_feature_id()
						for ft in list_of_features_to_be_evaluated:
							if (ft.get_feature_id() == ft_id):
								features_to_be_reconstructed.append(ft)
					if (reference is not None):
						#approximate with arc length in pygplates - GreatCircleArc
						pygplates.reconstruct(features_to_be_reconstructed,rotation_model,reconstructed_features,at_age,anchor_plate_id = reference, group_with_feature = True)
					else:
						pygplates.reconstruct(features_to_be_reconstructed,rotation_model,reconstructed_features,at_age,group_with_feature = True)
					final_reconstructed_fts = supporting.find_final_reconstructed_geometries(reconstructed_features,pygplates.PolylineOnSphere)
					apprx_len_km = 0.00
					for reconstructed_ft,reconstructed_line in final_reconstructed_fts:
						apprx_len_km = apprx_len_km + reconstructed_line.get_arc_length()*pygplates.Earth.equatorial_radius_in_kms
					
					max_begin_age,min_end_age = -1.00,-1.00
					for reconstructed_ft in features_to_be_reconstructed:
						current_begin_age,current_end_age = reconstructed_ft.get_valid_time()
						if (pygplates.GeoTimeInstant(current_end_age).is_distant_future()):
							current_end_age = 0.00
						if (max_begin_age == -1.00 or (max_begin_age > -1.00 and max_begin_age < current_begin_age)):
							max_begin_age = current_begin_age
						if (min_end_age == -1.00 or (min_end_age > -1.00 and min_end_age > current_end_age)):
							min_end_age = current_end_age
					apprx_dur = max_begin_age - min_end_age
					if (apprx_dur == 0.00):
						print("max_begin_age,min_end_age")
						print(max_begin_age,min_end_age)
						exit()
					
					fid_string = resolved_ft.get_feature_id().get_string()
					list_of_topological_ft_id_and_len.append((at_age,fid_string,number_of_sections,apprx_len_km,apprx_dur))
							
			for ft in final_topological_features:
				output_all_final_topological_features.append(ft)
		
			outputFeatureCollection = pygplates.FeatureCollection(output_all_final_topological_features)
			outputFile = "topological_features_"+str(at_age)+"_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
			outputFeatureCollection.write(outputFile)
			output_all_final_topological_features[:] = []
		
		# if (length_of_topological_margins_output_csv_file is not None):
			# new_dataframe = pd.DataFrame.from_records(list_of_topological_ft_id_and_len, columns = ['reconstruction_time','ft_id','number_of_sections','apprx_len_km','apprx_dur_myrs'])
			# print("new_dataframe")
			# print(new_dataframe)
			# new_dataframe.to_csv(length_of_topological_margins_output_csv_file+"_"+str(at_age)+"_"+str(test_number)+"_"+modelname+"_"+yyyymmdd+".csv",index=False)
			# list_of_topological_ft_id_and_len[:] = [] 
		
		#update at_age
		at_age = at_age - interval
	
	if (length_of_topological_margins_output_csv_file is not None):
		new_dataframe = pd.DataFrame.from_records(list_of_topological_ft_id_and_len, columns = ['reconstruction_time','ft_id','number_of_sections','apprx_len_km','apprx_dur_myrs'])
		print("new_dataframe")
		print(new_dataframe)
		new_dataframe.to_csv(length_of_topological_margins_output_csv_file+"_"+str(test_number)+"_"+modelname+"_"+yyyymmdd+".csv",index=False)

def find_total_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,reconstruction_time,reference_frame):
	"""
	Total reconstruction is a reconstruction relative to the present (in time) and relative to any reference frame (spin axis or mantle or anything else)
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_stage_relative_reconstruction_rotation_(rotation_model,fixed_plate_id,moving_plate_id, reconstruction_time, interval):
	"""
	stage relative reconstruction is a reconstruction from reconstruction_time + interval to reconstruction_time
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time and interval: a float 
	"""
	finite_rotation_1 = None
	finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, reconstruction_time+interval , fixed_plate_id, anchor_plate_id = fixed_plate_id)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id)
		print("reconstruction_time")
		print(reconstruction_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
def calculate_angular_distance_of_any_two_points_on_a_globe(lat_1,lon_1,lat_2,lon_2):
	"""
		lat_1 and lon_1: (latitude, longitude) of point 1
		lat_2 and lon_2: (latitude, longitude) of point 2
		latitude is range from [-90, +90 degree]
		longitude is range from [0, 360 degree] or [-180, +180] 
		Return: theta in radians the angular distance from point 1 to point 2
	"""
	#alpha is longitude 
	#delta is latitude
	delta_1 = math.radians(lat_1)
	delta_2 = math.radians(lat_2)
	alpha_1 = math.radians(lon_1)
	alpha_2 = math.radians(lon_2)
	theta = math.acos((math.sin(delta_1)*math.sin(delta_2)) + (math.cos(delta_1)*math.cos(delta_2))* math.cos(alpha_1-alpha_2))
	return theta

def find_the_mid_of_two_PointOnSphere(p1,p2):
	"""
		p1 and p2: pygplates.PointOnSphere
		Return: a mid point between p1 and p2 in the datatype pygplates.PointOnSphere
		
		p1 and p2 can be expressed as (x,y,z) coordinates in pygplates. Thus, mid_point(x,y,z) = (x1+x2/2.0, y1+y2/2.0, z1+z2/2.0)
	"""
	x1,y1,z1 = p1.to_xyz()
	x2,y2,z2 = p2.to_xyz()
	mid_point_x = (x1+x2)/2.00
	mid_point_y = (y1+y2)/2.00
	mid_point_z = (z1+z2)/2.00
	
	vector = pygplates.Vector3D([mid_point_x, mid_point_y, mid_point_z])
	normalized_vector = vector.to_normalised()
	
	mid_point = pygplates.PointOnSphere(normalized_vector.to_xyz())
	return mid_point
	
def identify_left_gdu_and_right_gdu(normal_unit_vector, rift_point_location, mid_point_line_1, mid_point_line_2, plate_id_1, plate_id_2):
	opposite_unit_vector = normal_unit_vector*(-1.00)
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z = mid_point_line_2.to_xyz()
	
	#identify left and right
	vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	vector_to_line_2 = pygplates.Vector3D([(mid_point_line_2_x-rift_point_location_x),(mid_point_line_2_y-rift_point_location_y),(mid_point_line_2_z-rift_point_location_z)])
	normalized_vector_to_line_2 = vector_to_line_2.to_normalised()
	
	left = None
	right = None 

	if (pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,opposite_unit_vector) > 0):
		left = plate_id_1
		right = plate_id_2
	elif (pygplates.Vector3D.dot(normalized_vector_to_line_1,opposite_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector) > 0):
		left = plate_id_2
		right = plate_id_1	
	else:
		print("Error in find_rift_segment_and_transform_faults")
		print("line_1 and line_2 are not located on two different sides relative to the mid_point")
		print("dot product of unit vectors for line_1")
		print(pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector))
		print("dot product of unit vectors for line_2")
		print(pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector))
		
		print ('rift_point_location')
		print(rift_point_location)
		
		print('mid_point_line_1')
		print(mid_point_line_1)
		
		print('mid_point_line_2')
		print(mid_point_line_2)
		
		print('plate_id_1')
		print(plate_id_1)
		print('plate_id_2')
		print(plate_id_2)
		exit()
	return (left,right)

def classify_left_or_right(normal_unit_vector,rift_point_location,mid_point_line_1):
	opposite_unit_vector = normal_unit_vector*(-1.00)
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	#identify left and right
	vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	if (pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector) > 0):
		return 'left'
	elif (pygplates.Vector3D.dot(normalized_vector_to_line_1,opposite_unit_vector) > 0):
		return 'right'
	
def find_min_max_age_from_middle_fts(list_of_middle_fts_at_age):
	min_age = -1.00
	max_age = -1.00
	for ft in list_of_middle_fts_at_age:
		begin_age,end_age = ft.get_valid_time()
		if (min_age == -1.00):
			min_age = end_age
		elif (min_age > -1.00 and min_age > end_age):
			min_age = end_age
		if (max_age == -1.00):
			max_age = begin_age
		elif (max_age > -1.00 and max_age < begin_age):
			max_age = begin_age
	return (min_age,max_age)

def find_max_end_age_from_middle_fts(list_of_middle_fts_at_age):
	max_age = -1.00
	for ft in list_of_middle_fts_at_age:
		_,end_age = ft.get_valid_time()
		if (max_age == -1.00):
			max_age = end_age
		elif (max_age > -1.00 and max_age < end_age):
			max_age = end_age
	return max_age

def discretize_middle_features(list_of_ordered_middle_fts,polygons,rotation_model,at_age,reference):
	reconstructed_middle_fts = []
	if (reference is not None):
		pygplates.reconstruct(list_of_ordered_middle_fts,rotation_model,reconstructed_middle_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(list_of_ordered_middle_fts,rotation_model,reconstructed_middle_fts,at_age, group_with_feature = True)
	final_reconstructed_middle_ft = supporting.find_final_reconstructed_geometries(reconstructed_middle_fts, pygplates.PointOnSphere)
	number_of_middle_fts = len(final_reconstructed_middle_ft)
	new_middle_points = []
	new_middle_fts = []
	dic = {}
	for index in range(0,number_of_middle_fts):
		reconstructed_middle_ft,reconstructed_middle_point = final_reconstructed_middle_ft[index]
		new_middle_points.append(reconstructed_middle_point)
		new_middle_fts.append(reconstructed_middle_ft)
		if (len(new_middle_points) > 2):
			tectonic_line = pygplates.PolylineOnSphere(new_middle_points)
			valid = True
			for p in polygons:
				if (p.partition(tectonic_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
					valid = False
					break
			if (valid == False):
				last_middle_ft = new_middle_fts.pop()
				last_middle_point = new_middle_points.pop()
				dic[str(index)] = []
				for n in range(0,len(new_middle_fts)):
					middle_ft = new_middle_fts[n]
					middle_point = new_middle_points[n]
					#dic[str(index)].append((middle_ft.clone(),middle_point.clone()))
					dic[str(index)].append(middle_ft.clone())
				#clear new_middle_points and new_middle_fts
				new_middle_points[:] = []
				new_middle_fts[:] = []
				#add the last middle ft and last middle point back to lists
				new_middle_points.append(last_middle_point)
				new_middle_fts.append(last_middle_ft)
	dic[str(index)] = []
	for n in range(0,len(new_middle_fts)):
		middle_ft = new_middle_fts[n]
		#middle_point = new_middle_points[n]
		dic[str(index)].append(middle_ft.clone())
	
	return dic

def find_subsequent_left_right_oceanic_crust(list_of_ordered_middle_fts, list_of_ordered_fts_for_left, list_of_ordered_fts_for_right, rotation_model, at_age, divergent_end_age, interval, reference, SuperGDU_features):
	print("len(list_of_ordered_middle_fts)")
	print(len(list_of_ordered_middle_fts))
	f = list_of_ordered_middle_fts[0]
	print(f.get_valid_time())
	print("at_age")
	print(at_age)
	print("divergent_end_age")
	print(divergent_end_age)
	
	left_oceanic_crust_fts = []
	right_oceanic_crust_fts = []
	reconstructed_middle_fts = []
	reconstructed_fts_for_left = []
	reconstructed_fts_for_right = []
	reconstructed_SuperGDU_fts = []
	SuperGDU_polygons = []
	already_processed_oceanic_crust_ft = []
	surface_left_oceanic_crust_fts = []
	surface_right_oceanic_crust_fts = []
	new_left_points = []
	new_left_points_fts = []
	new_left_fts = []
	new_right_points_fts = []
	new_right_fts = []
	new_middle_points = []
	new_middle_points_fts = []
	resolved_left_topologies = []
	resolved_right_topologies = []
	
	previous_middle_points = False
	while (at_age >= divergent_end_age):
		reconstructed_fts_for_left[:] = []
		reconstructed_fts_for_right[:] = []
		reconstructed_middle_fts[:] = []
		reconstructed_SuperGDU_fts[:] = []
		list_of_valid_SuperGDU_fts = [SuperGDU_ft for SuperGDU_ft in SuperGDU_features if SuperGDU_ft.is_valid_at_time(at_age)]
		SuperGDU_polygons[:] = []
		#reconstruct middle_ft to subsequent time-step
		if (reference is not None):
			if (previous_middle_points == False):
				pygplates.reconstruct(list_of_ordered_fts_for_left,rotation_model,reconstructed_fts_for_left,at_age,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(list_of_ordered_fts_for_right,rotation_model,reconstructed_fts_for_right,at_age,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(new_left_fts,rotation_model,reconstructed_fts_for_left,at_age,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(new_right_fts,rotation_model,reconstructed_fts_for_right,at_age,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(list_of_ordered_middle_fts,rotation_model,reconstructed_middle_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
		else:
			if (previous_middle_points == False):
				pygplates.reconstruct(list_of_ordered_fts_for_left,rotation_model,reconstructed_fts_for_left,at_age,group_with_feature = True)
				pygplates.reconstruct(list_of_ordered_fts_for_right,rotation_model,reconstructed_fts_for_right,at_age,group_with_feature = True)
			else:
				pygplates.reconstruct(new_left_fts,rotation_model,reconstructed_fts_for_left,at_age,group_with_feature = True)
				pygplates.reconstruct(new_right_fts,rotation_model,reconstructed_fts_for_right,at_age,group_with_feature = True)
			pygplates.reconstruct(list_of_ordered_middle_fts,rotation_model,reconstructed_middle_fts,at_age,group_with_feature = True)
			pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age, group_with_feature = True)
		final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU_fts, pygplates.PolygonOnSphere)
		for SuperGDU_ft, SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
			SuperGDU_polygons.append(SuperGDU_polygon) 
		if (len(reconstructed_fts_for_left) > 1):
			final_reconstructed_ft_for_left = supporting.find_final_reconstructed_geometries(reconstructed_fts_for_left, pygplates.PointOnSphere)
			final_reconstructed_ft_for_right = supporting.find_final_reconstructed_geometries(reconstructed_fts_for_right, pygplates.PointOnSphere)
			new_left_points_fts[:] = []
			new_right_points_fts[:] = []
			if (previous_middle_points == False):
				previous_middle_points = True
			for reconstructed_left_ft,reconstructed_left_geometry in final_reconstructed_ft_for_left:
				new_left_points_fts.append(reconstructed_left_ft)
			for reconstructed_right_ft,reconstructed_right_geometry in final_reconstructed_ft_for_right:
				new_right_points_fts.append(reconstructed_right_ft)
			final_reconstructed_middle_ft = supporting.find_final_reconstructed_geometries(reconstructed_middle_fts, pygplates.PointOnSphere)
			new_middle_points[:] = []
			new_middle_points_fts[:] = []
			new_left_fts[:] = []
			new_right_fts[:] = []
			for reconstructed_middle_ft,reconstructed_middle_geometry in final_reconstructed_middle_ft:
				_,end_age = reconstructed_middle_ft.get_valid_time()
				new_middle_points.append(reconstructed_middle_geometry)
				new_middle_points_fts.append(reconstructed_middle_ft)
				new_left_ft = reconstructed_middle_ft.clone()
				new_left_ft.set_geometry(reconstructed_middle_geometry)
				left_id = reconstructed_middle_ft.get_left_plate()
				right_id = reconstructed_middle_ft.get_right_plate()
				print("at_age,divergent_end_age")
				print(at_age,divergent_end_age)
				#new_left_ft.set_valid_time(at_age, divergent_end_age)
				new_left_ft.set_valid_time(at_age, end_age)
				new_left_ft.set_reconstruction_plate_id(left_id)
				new_left_ft.set_conjugate_plate_id(right_id)
				new_left_ft.set_left_plate(left_id)
				new_left_ft.set_right_plate(right_id)
				new_left_ft.set_reconstruction_method('ByPlateId')
				new_left_fts.append(new_left_ft)
				
				new_right_ft = reconstructed_middle_ft.clone()
				new_right_ft.set_geometry(reconstructed_middle_geometry)
				#new_right_ft.set_valid_time(at_age, divergent_end_age)
				new_right_ft.set_valid_time(at_age, end_age)
				new_right_ft.set_reconstruction_plate_id(right_id)
				new_right_ft.set_conjugate_plate_id(left_id)
				new_right_ft.set_left_plate(left_id)
				new_right_ft.set_right_plate(right_id)
				new_right_ft.set_reconstruction_method('ByPlateId')
				new_right_fts.append(new_right_ft)
			if (reference is None):
				pygplates.reverse_reconstruct(new_left_fts,rotation_model,at_age)
				pygplates.reverse_reconstruct(new_right_fts,rotation_model,at_age)
			else:
				pygplates.reverse_reconstruct(new_left_fts,rotation_model,at_age,reference)
				pygplates.reverse_reconstruct(new_right_fts,rotation_model,at_age,reference)
			
			# new_left_points.reverse()
			# list_of_points_for_left_oceanic_crust_polygon = new_middle_points + new_left_points
			# left_oceanic_polygon = None
			# if (len(list_of_points_for_left_oceanic_crust_polygon) > 2):
				# left_oceanic_polygon = pygplates.PolygonOnSphere(list_of_points_for_left_oceanic_crust_polygon)
			# elif (len(list_of_points_for_left_oceanic_crust_polygon) == 2):
				# left_oceanic_polygon = pygplates.PolylineOnSphere(list_of_points_for_left_oceanic_crust_polygon)
			# elif (len(list_of_points_for_left_oceanic_crust_polygon) == 1):
				# left_oceanic_polygon = pygplates.PointOnSphere(list_of_points_for_left_oceanic_crust_polygon)
			# left_oceanic_polygon_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,left_oceanic_polygon,name=str(at_age),valid_time = (at_age,divergent_end_age))
			# left_oceanic_polygon_feature.set_reconstruction_plate_id(final_left_plate_id)
			# if (reference is not None):
				# pygplates.reverse_reconstruct(left_oceanic_polygon_feature,rotation_model,at_age,reference)
			# else:
				# pygplates.reverse_reconstruct(left_oceanic_polygon_feature,rotation_model,at_age)
			# left_oceanic_crust_fts.append(left_oceanic_polygon_feature)
			
			#topology features
			#new_left_points_fts.reverse()
			temporary_reversed_ordered_left_fts = [item for item in reversed(new_left_points_fts)]
			list_of_points_fts_for_left_oceanic_crust_polygon = []
			#new_middle_points_fts + temporary_reversed_ordered_left_fts
			for point_ft in new_left_fts:
				list_of_points_fts_for_left_oceanic_crust_polygon.append(point_ft.clone())
			for point_ft in temporary_reversed_ordered_left_fts:
				list_of_points_fts_for_left_oceanic_crust_polygon.append(point_ft.clone())
			for point_ft in list_of_points_fts_for_left_oceanic_crust_polygon:
				left_oceanic_crust_fts.append(point_ft)
			left_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_fts_for_left_oceanic_crust_polygon)
			topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
			left_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, left_topological_polygon)
			left_topological_polygon_feature.set_valid_time(at_age,divergent_end_age)
			left_oceanic_crust_fts.append(left_topological_polygon_feature)
			
			temporary_reversed_ordered_middle_fts = [item for item in reversed(new_right_fts)]
			list_of_points_fts_for_right_oceanic_crust_polygon = []
			#new_middle_points_fts + temporary_reversed_ordered_left_fts
			for point_ft in new_right_points_fts:
				list_of_points_fts_for_right_oceanic_crust_polygon.append(point_ft.clone())
			for point_ft in temporary_reversed_ordered_middle_fts:
				list_of_points_fts_for_right_oceanic_crust_polygon.append(point_ft.clone())
			for point_ft in list_of_points_fts_for_right_oceanic_crust_polygon:
				right_oceanic_crust_fts.append(point_ft)
			right_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_fts_for_right_oceanic_crust_polygon)
			topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
			right_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, right_topological_polygon)
			right_topological_polygon_feature.set_valid_time(at_age,divergent_end_age)
			right_oceanic_crust_fts.append(right_topological_polygon_feature)

		
		#topology features
		resolved_left_topologies[:] = []
		resolved_right_topologies[:] = []
		if (len(left_oceanic_crust_fts) > 0):
			if	(reference is not None):
				pygplates.resolve_topologies(left_oceanic_crust_fts, rotation_model, resolved_left_topologies, float(at_age), anchor_plate_id = reference, resolve_topology_types = pygplates.ResolveTopologyType.line|pygplates.ResolveTopologyType.boundary)
				pygplates.resolve_topologies(right_oceanic_crust_fts, rotation_model, resolved_left_topologies, float(at_age), anchor_plate_id = reference, resolve_topology_types = pygplates.ResolveTopologyType.line|pygplates.ResolveTopologyType.boundary)
			else:
				pygplates.resolve_topologies(left_oceanic_crust_fts, rotation_model, resolved_left_topologies, float(at_age), anchor_plate_id = 0, resolve_topology_types = pygplates.ResolveTopologyType.line|pygplates.ResolveTopologyType.boundary)
				pygplates.resolve_topologies(right_oceanic_crust_fts, rotation_model, resolved_left_topologies, float(at_age), anchor_plate_id = 0, resolve_topology_types = pygplates.ResolveTopologyType.line|pygplates.ResolveTopologyType.boundary)
			for resolve_topological_line in resolved_left_topologies:
				resolved_line = resolve_topological_line.get_resolved_geometry()
				resolved_ft = resolve_topological_line.get_feature()
				valid = True
				for SuperGDU_polygon in SuperGDU_polygons:
					if (SuperGDU_polygon.partition(resolved_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting or SuperGDU_polygon.partition(resolved_line) == pygplates.PolygonOnSphere.PartitionResult.inside):
						valid = False
						break
				if (valid == False):
					current_oceanic_begin_age,current_oceanic_end_age = resolved_ft.get_valid_time()
					for oceanic_crust_ft in left_oceanic_crust_fts:
						if (oceanic_crust_ft.get_feature_id() == resolved_ft.get_feature_id()):
							if (current_oceanic_begin_age <= (at_age + (interval*0.100))):
								print ('current_oceanic_begin_age')
								print (current_oceanic_begin_age)
								print ('current_oceanic_end_age')
								print (current_oceanic_end_age)
								print ('at_age')
								print (at_age)
								print ('at_age + (interval*0.100)')
								print (at_age + (interval*0.100))
							else:
								#oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								already_processed_oceanic_crust_ft.append(oceanic_crust_ft.get_feature_id().get_string())
								clone_oceanic_crust_ft = oceanic_crust_ft.clone()
								clone_oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								surface_left_oceanic_crust_fts.append(clone_oceanic_crust_ft)
							break
			for resolve_topological_line in resolved_right_topologies:
				resolved_line = resolve_topological_line.get_resolved_geometry()
				resolved_ft = resolve_topological_line.get_feature()
				valid = True
				for SuperGDU_polygon in SuperGDU_polygons:
					if (SuperGDU_polygon.partition(resolved_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting or SuperGDU_polygon.partition(resolved_line) == pygplates.PolygonOnSphere.PartitionResult.inside):
						valid = False
						break
				if (valid == False):
					current_oceanic_begin_age,current_oceanic_end_age = resolved_ft.get_valid_time()
					for oceanic_crust_ft in left_oceanic_crust_fts:
						if (oceanic_crust_ft.get_feature_id() == resolved_ft.get_feature_id()):
							if (current_oceanic_begin_age <= (at_age + (interval*0.100))):
								print ('current_oceanic_begin_age')
								print (current_oceanic_begin_age)
								print ('current_oceanic_end_age')
								print (current_oceanic_end_age)
								print ('at_age')
								print (at_age)
								print ('at_age + (interval*0.100)')
								print (at_age + (interval*0.100))
							else:
								#oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								already_processed_oceanic_crust_ft.append(oceanic_crust_ft.get_feature_id().get_string())
								clone_oceanic_crust_ft = oceanic_crust_ft.clone()
								clone_oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								surface_right_oceanic_crust_fts.append(clone_oceanic_crust_ft)
							break

		at_age = at_age - interval
	#include other oceanic crust ft which never cut across continent
	for oc_ft in left_oceanic_crust_fts:
		if (oc_ft.get_feature_id().get_string() not in already_processed_oceanic_crust_ft):
			surface_left_oceanic_crust_fts.append(oc_ft)
	for oc_ft in right_oceanic_crust_fts:
		if (oc_ft.get_feature_id().get_string() not in already_processed_oceanic_crust_ft):
			surface_right_oceanic_crust_fts.append(oc_ft)
		
	return left_oceanic_crust_fts, surface_left_oceanic_crust_fts, right_oceanic_crust_fts, surface_right_oceanic_crust_fts

def find_subsequent_left_oceanic_crust_v2(final_left_plate_id,list_of_ordered_middle_fts,list_of_ordered_fts_for_left, rotation_model, at_age, divergent_end_age, interval, reference):
	print("len(list_of_ordered_middle_fts)")
	print(len(list_of_ordered_middle_fts))
	f = list_of_ordered_middle_fts[0]
	print(f.get_valid_time())
	print("at_age")
	print(at_age)
	print("divergent_end_age")
	print(divergent_end_age)
	print("len(list_of_ordered_fts_for_left)")
	print(len(list_of_ordered_fts_for_left))
	
	left_oceanic_crust_fts = []
	reconstructed_middle_fts = []
	reconstructed_fts_for_left = []
	new_left_points = []
	new_middle_points = []
	cloned_fts_for_lefts = []
	cloned_middle_fts = []
	previous_middle_points = None
	for ft_for_left in list_of_ordered_fts_for_left:
		cloned_fts_for_lefts.append(ft_for_left.clone())
	for middle_ft in list_of_ordered_middle_fts:
		cloned_middle_fts.append(middle_ft.clone())
	new_left_fts = []
	new_middle_fts = []
	#update at_age
	at_age = at_age - interval
	while (at_age > (divergent_end_age - interval)):
		reconstructed_fts_for_left[:] = []
		reconstructed_middle_fts[:] = []
		#reconstruct middle_ft to subsequent time-step
		if (reference is not None):
			if (previous_middle_points is None):
				pygplates.reconstruct(cloned_fts_for_lefts,rotation_model,reconstructed_fts_for_left,at_age,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(cloned_middle_fts,rotation_model,reconstructed_middle_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
		else:
			if (previous_middle_points is None):
				pygplates.reconstruct(cloned_fts_for_lefts,rotation_model,reconstructed_fts_for_left,at_age, group_with_feature = True)
			pygplates.reconstruct(cloned_middle_fts,rotation_model,reconstructed_middle_fts,at_age,group_with_feature = True)
		final_reconstructed_ft_for_left = None
		new_left_points = None
		if (previous_middle_points is None):
			final_reconstructed_ft_for_left = supporting.find_final_reconstructed_geometries(reconstructed_fts_for_left, pygplates.PointOnSphere)
			new_left_points = []
			for reconstructed_left_ft,reconstructed_left_geometry in final_reconstructed_ft_for_left:
				new_left_points.append(reconstructed_left_geometry)
		else:
			new_left_points = previous_middle_points 
		final_reconstructed_middle_ft = supporting.find_final_reconstructed_geometries(reconstructed_middle_fts, pygplates.PointOnSphere)
		new_middle_points[:] = []
		for reconstructed_middle_ft,reconstructed_middle_geometry in final_reconstructed_middle_ft:
			new_middle_points.append(reconstructed_middle_geometry)
		new_left_points.reverse()
		list_of_points_for_left_oceanic_crust_polygon = new_middle_points + new_left_points
		left_oceanic_polygon = pygplates.PolygonOnSphere(list_of_points_for_left_oceanic_crust_polygon)
		left_oceanic_polygon_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,left_oceanic_polygon,name=str(at_age),valid_time = (at_age,divergent_end_age))
		left_oceanic_polygon_feature.set_reconstruction_plate_id(final_left_plate_id)
		if (reference is not None):
			pygplates.reverse_reconstruct(left_oceanic_polygon_feature,rotation_model,at_age,reference)
		else:
			pygplates.reverse_reconstruct(left_oceanic_polygon_feature,rotation_model,at_age)
		left_oceanic_crust_fts.append(left_oceanic_polygon_feature)
		if (previous_middle_points is None):
			previous_middle_points = []
		else:
			previous_middle_points[:] = []
		for new_middle_pt in new_middle_points:
			previous_middle_points.append(new_middle_pt.clone())
		#update at_age value
		at_age = at_age - interval
	return left_oceanic_crust_fts

def find_subsequent_right_oceanic_crust_old_v1(final_right_plate_id,list_of_ordered_middle_fts, list_of_ordered_middle_fts_for_right, rotation_model, at_age, divergent_end_age, interval, reference):
	right_oceanic_crust_fts = []
	reconstructed_mid_fts_for_right = []
	reconstructed_middle_fts = []
	cloned_middle_fts_for_right = []
	cloned_middle_fts = []
	new_right_points = []
	new_middle_points = []
	new_middle_fts = []

	for middle_ft_for_right in list_of_ordered_middle_fts_for_right:
		cloned_middle_fts_for_right.append(middle_ft_for_right.clone())
	
	for middle_ft in list_of_ordered_middle_fts:
		cloned_middle_fts.append(middle_ft.clone())
	
	#reconstructed_mid_fts = []
	new_right_fts = []
	#update at_age
	at_age = at_age - interval
	while (at_age > (divergent_end_age - interval)):
		reconstructed_middle_fts[:] = []
		reconstructed_mid_fts_for_right[:] = []
		new_right_fts[:] = []
		new_middle_fts[:] = []
		new_right_points[:] = []
		new_middle_points[:] = []
		#reconstruct middle_ft to subsequent time-step
		if (reference is not None):
			#pygplates.reconstruct(cloned_middle_fts_for_right,rotation_model,reconstructed_mid_fts_for_right,at_age,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(cloned_middle_fts_for_right,rotation_model,reconstructed_mid_fts_for_right,at_age+interval,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(cloned_middle_fts,rotation_model,reconstructed_middle_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
		else:
			#pygplates.reconstruct(cloned_middle_fts_for_right,rotation_model,reconstructed_mid_fts_for_right,at_age,group_with_feature = True)
			pygplates.reconstruct(cloned_middle_fts_for_right,rotation_model,reconstructed_mid_fts_for_right,at_age+interval,group_with_feature = True)
			pygplates.reconstruct(cloned_middle_fts,rotation_model,reconstructed_middle_fts,at_age,group_with_feature = True)
		final_reconstructed_middle_ft_for_right = supporting.find_final_reconstructed_geometries(reconstructed_mid_fts_for_right, pygplates.PointOnSphere)
		final_reconstructed_middle_ft = supporting.find_final_reconstructed_geometries(reconstructed_middle_fts, pygplates.PointOnSphere)
		for reconstructed_middle_ft_for_right,reconstructed_middle_geometry_for_right in final_reconstructed_middle_ft_for_right:
			new_right_ft = reconstructed_middle_ft_for_right.clone()
			new_right_ft.set_geometry(reconstructed_middle_geometry_for_right)
			new_right_ft.set_valid_time(at_age, divergent_end_age)
			new_right_fts.append(new_right_ft)
			new_right_points.append(reconstructed_middle_geometry_for_right)
		for reconstructed_middle_ft,reconstructed_middle_geometry in final_reconstructed_middle_ft:
			new_mid_ft = reconstructed_middle_ft.clone()
			new_mid_ft.set_geometry(reconstructed_middle_geometry)
			new_mid_ft.set_valid_time(at_age, divergent_end_age)
			new_middle_fts.append(new_mid_ft)
			new_middle_points.append(reconstructed_middle_geometry)
		if (reference is None):
			pygplates.reverse_reconstruct(new_right_fts,rotation_model,at_age)
		else:
			pygplates.reverse_reconstruct(new_right_fts,rotation_model,at_age,reference)
		if (reference is None):
			pygplates.reverse_reconstruct(new_middle_fts,rotation_model,at_age)
		else:
			pygplates.reverse_reconstruct(new_middle_fts,rotation_model,at_age,reference)	
		# new_reversed_list = [item for item in reversed(new_middle_fts)]
		# list_of_points_for_right_oceanic_crust = new_right_fts + new_reversed_list
		# right_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_right_oceanic_crust)
		# topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
		# right_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, right_topological_polygon)
		# right_topological_polygon_feature.set_name(str(at_age))
		# for ft in list_of_points_for_right_oceanic_crust:
			# right_oceanic_crust_fts.append(ft)
		# right_oceanic_crust_fts.append(right_topological_polygon_feature)
		
		new_middle_points_reversed_list = [item for item in reversed(new_middle_points)]
		list_of_points_for_right_oceanic_crust_polygon = new_right_points + new_middle_points_reversed_list
		right_oceanic_polygon = pygplates.PolygonOnSphere(list_of_points_for_right_oceanic_crust_polygon)
		right_oceanic_polygon_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,right_oceanic_polygon,name=str(at_age),valid_time = (at_age,divergent_end_age))
		right_oceanic_polygon_feature.set_reconstruction_plate_id(final_right_plate_id)
		if (reference is not None):
			pygplates.reverse_reconstruct(right_oceanic_polygon_feature,rotation_model,at_age,reference)
		else:
			pygplates.reverse_reconstruct(right_oceanic_polygon_feature,rotation_model,at_age)
		right_oceanic_crust_fts.append(right_oceanic_polygon_feature)
		#update at_age value
		at_age = at_age - interval
	return right_oceanic_crust_fts

def find_subsequent_right_oceanic_crust(final_right_plate_id,list_of_ordered_middle_fts,list_of_ordered_fts_for_left, rotation_model, at_age, divergent_end_age, interval, reference, SuperGDU_features):
	# print("len(list_of_ordered_middle_fts)")
	# print(len(list_of_ordered_middle_fts))
	# f = list_of_ordered_middle_fts[0]
	# print(f.get_valid_time())
	# print("at_age")
	# print(at_age)
	# print("divergent_end_age")
	# print(divergent_end_age)
	
	left_oceanic_crust_fts = []
	reconstructed_middle_fts = []
	reconstructed_fts_for_left = []
	reconstructed_SuperGDU_fts = []
	SuperGDU_polygons = []
	reconstructed_previous_left_oceanic_crust_polygon_fts = []
	reconstructed_previous_left_oceanic_crust_line_fts = []
	reconstructed_previous_left_oceanic_crust_point_fts = []
	interested_oceanic_crust_polygon_fts = []
	interested_oceanic_crust_line_fts = []
	interested_oceanic_crust_point_fts = []
	already_processed_oceanic_crust_ft = []
	surface_oceanic_crust_fts = []
	new_left_points = []
	new_left_fts = []
	new_middle_points = []
	cloned_middle_fts_for_lefts = []
	cloned_middle_fts = []
	cloned_fts_for_lefts = []
	
	previous_middle_points = False
	# for middle_ft_for_left in list_of_ordered_middle_fts_for_left:
		# cloned_middle_fts_for_lefts.append(middle_ft_for_left.clone())
	for ft_for_left in list_of_ordered_fts_for_left:
		cloned_fts_for_lefts.append(ft_for_left.clone())
	for middle_ft_for_left in list_of_ordered_middle_fts:
		clone_ft = middle_ft_for_left.clone()
		#clone_ft.set_reconstruction_method('HalfStageRotationVersion2')
		#clone_ft.set_reconstruction_plate_id(final_left_plate_id) 
		cloned_middle_fts_for_lefts.append(clone_ft)
	for middle_ft in list_of_ordered_middle_fts:
		cloned_middle_fts.append(middle_ft.clone())

	while (at_age >= divergent_end_age):
		list_of_valid_SuperGDU_fts = [SuperGDU_ft for SuperGDU_ft in SuperGDU_features if SuperGDU_ft.is_valid_at_time(at_age)]
		reconstructed_fts_for_left[:] = []
		reconstructed_middle_fts[:] = []
		reconstructed_SuperGDU_fts[:] = []
		#reconstruct middle_ft to subsequent time-step
		if (reference is not None):
			#pygplates.reconstruct(cloned_middle_fts_for_lefts,rotation_model,reconstructed_middle_fts_for_left,at_age,anchor_plate_id = reference, group_with_feature = True)
			if (previous_middle_points == False):
				pygplates.reconstruct(cloned_fts_for_lefts,rotation_model,reconstructed_fts_for_left,at_age,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(new_left_fts,rotation_model,reconstructed_fts_for_left,at_age,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(cloned_middle_fts,rotation_model,reconstructed_middle_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
		else:
			#pygplates.reconstruct(cloned_middle_fts_for_lefts,rotation_model,reconstructed_middle_fts_for_left,at_age,group_with_feature = True)
			if (previous_middle_points == False):
				pygplates.reconstruct(cloned_fts_for_lefts,rotation_model,reconstructed_fts_for_left,at_age,group_with_feature = True)
			else:
				pygplates.reconstruct(new_left_fts,rotation_model,reconstructed_fts_for_left,at_age,group_with_feature = True)
			pygplates.reconstruct(cloned_middle_fts,rotation_model,reconstructed_middle_fts,at_age,group_with_feature = True)
			pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,group_with_feature = True)
		final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU_fts, pygplates.PolygonOnSphere)
		SuperGDU_polygons[:] = []
		for SuperGDU_ft, SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
			SuperGDU_polygons.append(SuperGDU_polygon) 
		if (len(reconstructed_fts_for_left) > 1):
			final_reconstructed_ft_for_left = supporting.find_final_reconstructed_geometries(reconstructed_fts_for_left, pygplates.PointOnSphere)
			new_left_points[:] = []
			if (previous_middle_points == False):
				previous_middle_points = True
			for reconstructed_left_ft,reconstructed_left_geometry in final_reconstructed_ft_for_left:
				new_left_points.append(reconstructed_left_geometry)
			final_reconstructed_middle_ft = supporting.find_final_reconstructed_geometries(reconstructed_middle_fts, pygplates.PointOnSphere)
			new_middle_points[:] = []
			new_left_fts[:] = []
			for reconstructed_middle_ft,reconstructed_middle_geometry in final_reconstructed_middle_ft:
				new_middle_points.append(reconstructed_middle_geometry)
				new_left_ft = reconstructed_middle_ft.clone()
				new_left_ft.set_geometry(reconstructed_middle_geometry)
				new_left_ft.set_valid_time(at_age, divergent_end_age)
				new_left_ft.set_reconstruction_plate_id(final_right_plate_id)
				new_left_ft.set_reconstruction_method('ByPlateId')
				new_left_fts.append(new_left_ft)
			if (reference is None):
				pygplates.reverse_reconstruct(new_left_fts,rotation_model,at_age)
			else:
				pygplates.reverse_reconstruct(new_left_fts,rotation_model,at_age,reference)
			
			new_middle_points_reversed_list = [item for item in reversed(new_middle_points)]
			list_of_points_for_left_oceanic_crust_polygon = new_left_points + new_middle_points_reversed_list
			
			left_oceanic_polygon = None
			if (len(list_of_points_for_left_oceanic_crust_polygon) > 2):
				left_oceanic_polygon = pygplates.PolygonOnSphere(list_of_points_for_left_oceanic_crust_polygon)
			elif (len(list_of_points_for_left_oceanic_crust_polygon) == 2):
				left_oceanic_polygon = pygplates.PolylineOnSphere(list_of_points_for_left_oceanic_crust_polygon)
			elif (len(list_of_points_for_left_oceanic_crust_polygon) == 1):
				left_oceanic_polygon = pygplates.PointOnSphere(list_of_points_for_left_oceanic_crust_polygon)
			left_oceanic_polygon_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,left_oceanic_polygon,name=str(at_age),valid_time = (at_age,divergent_end_age))
			left_oceanic_polygon_feature.set_reconstruction_plate_id(final_right_plate_id)
			if (reference is not None):
				pygplates.reverse_reconstruct(left_oceanic_polygon_feature,rotation_model,at_age,reference)
			else:
				pygplates.reverse_reconstruct(left_oceanic_polygon_feature,rotation_model,at_age)

			left_oceanic_crust_fts.append(left_oceanic_polygon_feature)
		
		#check validation of left_oceanic_crust_fts
		reconstructed_previous_left_oceanic_crust_polygon_fts[:] = []
		reconstructed_previous_left_oceanic_crust_line_fts[:] = []
		reconstructed_previous_left_oceanic_crust_point_fts[:] = []
		
		interested_oceanic_crust_polygon_fts[:] = []
		interested_oceanic_crust_line_fts[:] = []
		interested_oceanic_crust_point_fts[:] = []
		if (len(left_oceanic_crust_fts) > 0):
			for temp_oceanic_crust_ft in left_oceanic_crust_fts:
				temp_oceanic_begin_age,temp_oceanic_end_age = temp_oceanic_crust_ft.get_valid_time()
				if (temp_oceanic_crust_ft.get_feature_id().get_string() not in already_processed_oceanic_crust_ft and temp_oceanic_begin_age > at_age):
					if (type(temp_oceanic_crust_ft.get_geometry()) == pygplates.PolygonOnSphere):
						interested_oceanic_crust_polygon_fts.append(temp_oceanic_crust_ft)
					elif (type(temp_oceanic_crust_ft.get_geometry()) == pygplates.PolylineOnSphere):
						interested_oceanic_crust_line_fts.append(temp_oceanic_crust_ft)
					elif (type(temp_oceanic_crust_ft.get_geometry()) == pygplates.PointOnSphere):
						interested_oceanic_crust_point_fts.append(temp_oceanic_crust_ft)
						
			if (reference is not None):
				pygplates.reconstruct(interested_oceanic_crust_polygon_fts,rotation_model,reconstructed_previous_left_oceanic_crust_polygon_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(interested_oceanic_crust_line_fts,rotation_model,reconstructed_previous_left_oceanic_crust_line_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(interested_oceanic_crust_point_fts,rotation_model,reconstructed_previous_left_oceanic_crust_point_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(interested_oceanic_crust_polygon_fts,rotation_model,reconstructed_previous_left_oceanic_crust_polygon_fts,at_age,group_with_feature = True)
				pygplates.reconstruct(interested_oceanic_crust_line_fts,rotation_model,reconstructed_previous_left_oceanic_crust_line_fts,at_age,group_with_feature = True)
				pygplates.reconstruct(interested_oceanic_crust_point_fts,rotation_model,reconstructed_previous_left_oceanic_crust_point_fts,at_age,group_with_feature = True)
			final_reconstructed_previous_left_oceanic_crust_polygon_fts = supporting.find_final_reconstructed_geometries(reconstructed_previous_left_oceanic_crust_polygon_fts, pygplates.PolygonOnSphere)
			final_reconstructed_previous_left_oceanic_crust_line_fts = supporting.find_final_reconstructed_geometries(reconstructed_previous_left_oceanic_crust_line_fts, pygplates.PolylineOnSphere)
			final_reconstructed_previous_left_oceanic_crust_point_fts = supporting.find_final_reconstructed_geometries(reconstructed_previous_left_oceanic_crust_point_fts, pygplates.PointOnSphere)
			for previous_oceanic_crust_ft, previous_oceanic_crust in final_reconstructed_previous_left_oceanic_crust_polygon_fts:
				valid = True
				for SuperGDU_polygon in SuperGDU_polygons:
					if (SuperGDU_polygon.partition(previous_oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or SuperGDU_polygon.partition(previous_oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
						valid = False
						break
				if (valid == False):
					current_oceanic_begin_age,current_oceanic_end_age = previous_oceanic_crust_ft.get_valid_time()
					for oceanic_crust_ft in left_oceanic_crust_fts:
						if (oceanic_crust_ft.get_feature_id() == previous_oceanic_crust_ft.get_feature_id()):
							if (current_oceanic_begin_age <= (at_age + (interval*0.100))):
								print ('current_oceanic_begin_age')
								print (current_oceanic_begin_age)
								print ('current_oceanic_end_age')
								print (current_oceanic_end_age)
								print ('at_age')
								print (at_age)
								print ('at_age + (interval*0.100)')
								print (at_age + (interval*0.100))
							else:
								#oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								already_processed_oceanic_crust_ft.append(oceanic_crust_ft.get_feature_id().get_string())
								clone_oceanic_crust_ft = oceanic_crust_ft.clone()
								clone_oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								surface_oceanic_crust_fts.append(clone_oceanic_crust_ft)
							break
			for previous_oceanic_crust_ft, previous_oceanic_crust in final_reconstructed_previous_left_oceanic_crust_line_fts:
				valid = True
				for SuperGDU_polygon in SuperGDU_polygons:
					if (SuperGDU_polygon.partition(previous_oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or SuperGDU_polygon.partition(previous_oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
						valid = False
						break
				if (valid == False):
					current_oceanic_begin_age,current_oceanic_end_age = previous_oceanic_crust_ft.get_valid_time()
					for oceanic_crust_ft in left_oceanic_crust_fts:
						if (oceanic_crust_ft.get_feature_id() == previous_oceanic_crust_ft.get_feature_id()):
							if (current_oceanic_begin_age <= (at_age + (interval*0.100))):
								print ('current_oceanic_begin_age')
								print (current_oceanic_begin_age)
								print ('current_oceanic_end_age')
								print (current_oceanic_end_age)
								print ('at_age')
								print (at_age)
								print ('at_age + (interval*0.100)')
								print (at_age + (interval*0.100))
							else:
								#oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								already_processed_oceanic_crust_ft.append(oceanic_crust_ft.get_feature_id().get_string())
								clone_oceanic_crust_ft = oceanic_crust_ft.clone()
								clone_oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								surface_oceanic_crust_fts.append(clone_oceanic_crust_ft)
							break
			for previous_oceanic_crust_ft, previous_oceanic_crust in final_reconstructed_previous_left_oceanic_crust_point_fts:
				valid = True
				for SuperGDU_polygon in SuperGDU_polygons:
					if (SuperGDU_polygon.partition(previous_oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
						valid = False
						break
				if (valid == False):
					current_oceanic_begin_age,current_oceanic_end_age = previous_oceanic_crust_ft.get_valid_time()
					for oceanic_crust_ft in left_oceanic_crust_fts:
						if (oceanic_crust_ft.get_feature_id() == previous_oceanic_crust_ft.get_feature_id()):
							if (current_oceanic_begin_age <= (at_age + (interval*0.100))):
								print ('current_oceanic_begin_age')
								print (current_oceanic_begin_age)
								print ('current_oceanic_end_age')
								print (current_oceanic_end_age)
								print ('at_age')
								print (at_age)
								print ('at_age + (interval*0.100)')
								print (at_age + (interval*0.100))
							else:
								#oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								already_processed_oceanic_crust_ft.append(oceanic_crust_ft.get_feature_id().get_string())
								clone_oceanic_crust_ft = oceanic_crust_ft.clone()
								clone_oceanic_crust_ft.set_valid_time(current_oceanic_begin_age,at_age + (interval*0.100))
								surface_oceanic_crust_fts.append(clone_oceanic_crust_ft)
							break
		at_age = at_age - interval
	#include other oceanic crust ft which never cut across continent
	for oc_ft in left_oceanic_crust_fts:
		if (oc_ft.get_feature_id().get_string() not in already_processed_oceanic_crust_ft):
			surface_oceanic_crust_fts.append(oc_ft)
	return left_oceanic_crust_fts,surface_oceanic_crust_fts

def find_reconstructable_left_ceanic_crust_features_formed_at_age(list_of_orderd_left_point_features,list_of_ordered_middle_fts,rotation_model,at_age,reference):
	"""find reconstructable oceanic crust features formed at the given age.
	lists of points - left, middle and right - are all in the ordered from 179 to 1.00 degree in the context of small circles from the finite rotation"""
	#have to reverse the order of point for the left features
	temporary_reversed_ordered_left_fts = [item for item in reversed(list_of_orderd_left_point_features)]
	number_of_middle_fts = len(list_of_ordered_middle_fts)
	current_list_of_points_to_form_left_oceanic_crust = []
	current_indices_of_mid_points = []
	reconstructed_point_fts = []
	list_of_point_features	= []
	output_oceanic_polygon_fts = []
	for i in range(0, number_of_middle_fts-1):
		j = i + 1
		#left
		first_left_point_ft = list_of_orderd_left_point_features[i]
		first_middle_point_ft_for_left = list_of_ordered_middle_fts[i]
		second_left_point_ft = list_of_orderd_left_point_features[j]
		second_middle_point_ft_for_left = list_of_ordered_middle_fts[j]
		
		if (first_left_point_ft.get_reconstruction_plate_id() == second_left_point_ft.get_reconstruction_plate_id()):
			if (len(current_indices_of_mid_points) == 0):
				current_indices_of_mid_points.append(i)
				current_indices_of_mid_points.append(j)
				current_list_of_points_to_form_left_oceanic_crust.append(first_middle_point_ft_for_left)
				current_list_of_points_to_form_left_oceanic_crust.append(second_middle_point_ft_for_left)
				current_list_of_points_to_form_left_oceanic_crust.append(first_left_point_ft)
				current_list_of_points_to_form_left_oceanic_crust.append(second_left_point_ft)
			else:
				current_list_of_points_to_form_left_oceanic_crust.append(second_middle_point_ft_for_left)
				current_list_of_points_to_form_left_oceanic_crust.append(first_left_point_ft)
				current_indices_of_mid_points.append(j)
		else:
			if (len(current_indices_of_mid_points) == 0):
				reconstructed_point_fts[:] = []
				if (reference is not None):
					pygplates.reconstruct([first_middle_point_ft_for_left,second_middle_point_ft_for_left,first_left_point_ft,second_left_point_ft],rotation_model,reconstructed_point_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct([first_middle_point_ft_for_left,second_middle_point_ft_for_left,first_left_point_ft,second_left_point_ft],rotation_model,reconstructed_point_fts,at_age,group_with_feature = True)
				final_reconstructed_ft_points = supporting.find_final_reconstructed_geometries(reconstructed_point_fts,pygplates.PointOnSphere)
				first_reconstructed_middle_ft,first_reconstructed_middle_pt = final_reconstructed_ft_points[0]
				second_reconstructed_middle_ft,second_reconstructed_middle_pt = final_reconstructed_ft_points[1]
				new_middle_pt = find_the_mid_of_two_PointOnSphere(first_reconstructed_middle_pt,second_reconstructed_middle_pt)
				first_reconstructed_left_ft,first_reconstructed_left_pt = final_reconstructed_ft_points[2]
				second_reconstructed_left_ft,second_reconstructed_left_pt = final_reconstructed_ft_points[3]
				new_middle_pt_for_left = find_the_mid_of_two_PointOnSphere(first_reconstructed_left_pt,second_reconstructed_left_pt)
				#first_left_oceanic crust polyon
				temp_list_of_points = [first_reconstructed_middle_pt,new_middle_pt,new_middle_pt_for_left,first_reconstructed_left_pt]
				#create reconstructable left polygon 
				_,divergent_end_age = first_reconstructed_left_ft.get_valid_time()
				new_first_left_polygon = pygplates.PolygonOnSphere(temp_list_of_points)
				new_first_left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,new_first_left_polygon,valid_time = (at_age,divergent_end_age))
				new_first_left_ft.set_reconstruction_plate_id(first_reconstructed_left_ft.get_reconstruction_plate_id())
				output_oceanic_polygon_fts.append(new_first_left_ft)
				#second_left_oceanic crust polygon 
				_,divergent_end_age = second_reconstructed_left_ft.get_valid_time()
				temp_list_of_points = [new_middle_pt,new_middle_pt,second_reconstructed_middle_pt,second_reconstructed_left_pt,new_middle_pt_for_left]
				new_second_left_polygon = pygplates.PolygonOnSphere(temp_list_of_points)
				new_second_left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,new_second_left_polygon,valid_time = (at_age,divergent_end_age))
				new_second_left_ft.set_reconstruction_plate_id(second_reconstructed_left_ft.get_reconstruction_plate_id())
				output_oceanic_polygon_fts.append(new_second_left_ft)
			else:
				#obtain all left point features to create the polygon
				list_of_point_features[:] = []
				for n in current_indices_of_mid_points:
					list_of_point_features.append(list_of_ordered_middle_fts[n])
				for m in current_indices_of_mid_points:
					list_of_point_features.append(temporary_reversed_ordered_left_fts[m])
				reconstructed_point_fts[:] = []
				if (reference is not None):
					pygplates.reconstruct(list_of_point_features,rotation_model,reconstructed_point_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_point_features,rotation_model,reconstructed_point_fts,at_age,group_with_feature = True)
				final_reconstructed_ft_points = supporting.find_final_reconstructed_geometries(reconstructed_point_fts,pygplates.PointOnSphere)
				temp_list_of_points = []
				for temp_left_point_feature,left_point_for_polygon in final_reconstructed_ft_points:
					temp_list_of_points.append(left_point_for_polygon)
				_,divergent_end_age = temp_left_point_feature.get_valid_time()
				new_first_left_polygon = pygplates.PolygonOnSphere(temp_list_of_points)
				new_first_left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,new_first_left_polygon,valid_time = (at_age,divergent_end_age))
				new_first_left_ft.set_reconstruction_plate_id(temp_left_point_feature.get_reconstruction_plate_id())
				output_oceanic_polygon_fts.append(new_first_left_ft)
				#create the second new left polygon
				reconstructed_point_fts[:] = []
				if (reference is not None):
					pygplates.reconstruct([first_middle_point_ft_for_left,second_middle_point_ft_for_left,first_left_point_ft,second_left_point_ft],rotation_model,reconstructed_point_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct([first_middle_point_ft_for_left,second_middle_point_ft_for_left,first_left_point_ft,second_left_point_ft],rotation_model,reconstructed_point_fts,at_age,group_with_feature = True)
				final_reconstructed_ft_points = supporting.find_final_reconstructed_geometries(reconstructed_point_fts,pygplates.PointOnSphere)
				first_reconstructed_middle_ft,first_reconstructed_middle_pt = final_reconstructed_ft_points[0]
				second_reconstructed_middle_ft,second_reconstructed_middle_pt = final_reconstructed_ft_points[1]
				new_middle_pt = find_the_mid_of_two_PointOnSphere(first_reconstructed_middle_pt,second_reconstructed_middle_pt)
				first_reconstructed_left_ft,first_reconstructed_left_pt = final_reconstructed_ft_points[2]
				second_reconstructed_left_ft,second_reconstructed_left_pt = final_reconstructed_ft_points[3]
				new_middle_pt_for_left = find_the_mid_of_two_PointOnSphere(first_reconstructed_left_pt,second_reconstructed_left_pt)
				#second_left_oceanic crust polygon 
				_,divergent_end_age = second_reconstructed_left_ft.get_valid_time()
				temp_list_of_points = [new_middle_pt,new_middle_pt,second_reconstructed_middle_pt,second_reconstructed_left_pt,new_middle_pt_for_left]
				new_second_left_polygon = pygplates.PolygonOnSphere(temp_list_of_points)
				new_second_left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,new_second_left_polygon,valid_time = (at_age,divergent_end_age))
				new_second_left_ft.set_reconstruction_plate_id(second_reconstructed_left_ft.get_reconstruction_plate_id())
				output_oceanic_polygon_fts.append(new_second_left_ft)
	#reverse reconstruct 
	if (reference is not None):
		pygplates.reverse_reconstruct(output_oceanic_polygon_fts,rotation_model,at_age,reference)
	else:
		pygplates.reverse_reconstruct(output_oceanic_polygon_fts,rotation_model,at_age)
	return output_oceanic_polygon_fts

def find_reconstructable_right_ceanic_crust_features_formed_at_age(list_of_ordered_right_point_features,list_of_ordered_middle_fts,rotation_model,at_age,reference):	
	temporary_reversed_ordered_middle_fts = [item for item in reversed(list_of_ordered_middle_fts)]
	number_of_middle_fts = len(list_of_ordered_middle_fts)
	current_indices_of_mid_points = []
	reconstructed_point_fts = []
	list_of_point_features	= []
	output_oceanic_polygon_fts = []
	for i in range(0, number_of_middle_fts-1):
		j = i + 1	
		#right
		first_right_point_ft = list_of_ordered_right_point_features[i]
		first_middle_point_ft_for_right = temporary_reversed_ordered_middle_fts[i]
		second_right_point_ft = list_of_ordered_right_point_features[j]
		second_middle_point_ft_for_right = temporary_reversed_ordered_middle_fts[j]
		if (first_right_point_ft.get_reconstruction_plate_id() == second_right_point_ft.get_reconstruction_plate_id()):
			if (len(current_indices_of_mid_points) == 0):
				current_indices_of_mid_points.append(i)
				current_indices_of_mid_points.append(j)
			else:
				current_indices_of_mid_points.append(j)
		else:
			if (len(current_indices_of_mid_points) == 0):
				reconstructed_point_fts[:] = []
				if (reference is not None):
					pygplates.reconstruct([first_middle_point_ft_for_right,second_middle_point_ft_for_right,first_right_point_ft,second_right_point_ft],rotation_model,reconstructed_point_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct([first_middle_point_ft_for_right,second_middle_point_ft_for_right,first_right_point_ft,second_right_point_ft],rotation_model,reconstructed_point_fts,at_age,group_with_feature = True)
				final_reconstructed_ft_points = supporting.find_final_reconstructed_geometries(reconstructed_point_fts,pygplates.PointOnSphere)
				first_reconstructed_middle_ft,first_reconstructed_middle_pt = final_reconstructed_ft_points[0]
				second_reconstructed_middle_ft,second_reconstructed_middle_pt = final_reconstructed_ft_points[1]
				new_middle_pt = find_the_mid_of_two_PointOnSphere(first_reconstructed_middle_pt,second_reconstructed_middle_pt)
				first_reconstructed_right_ft,first_reconstructed_right_pt = final_reconstructed_ft_points[2]
				second_reconstructed_right_ft,second_reconstructed_right_pt = final_reconstructed_ft_points[3]
				new_middle_pt_for_right = find_the_mid_of_two_PointOnSphere(first_reconstructed_right_pt,second_reconstructed_right_pt)
				#first_left_oceanic crust polyon
				#temp_list_of_points = [first_reconstructed_middle_pt,new_middle_pt,new_middle_pt_for_right,first_reconstructed_right_pt]
				temp_list_of_points = [first_reconstructed_right_pt, new_middle_pt_for_right, new_middle_pt, first_reconstructed_middle_pt]
				#create reconstructable left polygon 
				_,divergent_end_age = first_reconstructed_right_ft.get_valid_time()
				new_first_right_polygon = pygplates.PolygonOnSphere(temp_list_of_points)
				new_first_right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,new_first_right_polygon,valid_time = (at_age,divergent_end_age))
				new_first_right_ft.set_reconstruction_plate_id(first_reconstructed_right_ft.get_reconstruction_plate_id())
				output_oceanic_polygon_fts.append(new_first_right_ft)
				#second_left_oceanic crust polygon 
				_,divergent_end_age = second_reconstructed_right_ft.get_valid_time()
				#temp_list_of_points = [new_middle_pt,new_middle_pt,second_reconstructed_middle_pt,second_reconstructed_right_pt,new_middle_pt_for_right]
				temp_list_of_points = [new_middle_pt_for_right, second_reconstructed_right_pt,second_reconstructed_middle_pt,new_middle_pt]
				new_second_right_polygon = pygplates.PolygonOnSphere(temp_list_of_points)
				new_second_right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,new_second_right_polygon,valid_time = (at_age,divergent_end_age))
				new_second_right_ft.set_reconstruction_plate_id(second_reconstructed_right_ft.get_reconstruction_plate_id())
				output_oceanic_polygon_fts.append(new_second_right_ft)
			else:
				#obtain all left point features to create the polygon
				list_of_point_features[:] = []
				for m in current_indices_of_mid_points:
					list_of_point_features.append(list_of_ordered_right_point_features[m])
				#obtain the reconstruction plate id since the last point is MOR which means the last reconstruction_plate_id == 0 --- don't need to do this for the left side 
				reconstruction_plate_id_for_new_first_right_ft = list_of_ordered_right_point_features[m].get_reconstruction_plate_id()
				for n in current_indices_of_mid_points:
					list_of_point_features.append(temporary_reversed_ordered_middle_fts[n])
				reconstructed_point_fts[:] = []
				if (reference is not None):
					pygplates.reconstruct(list_of_point_features,rotation_model,reconstructed_point_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_point_features,rotation_model,reconstructed_point_fts,at_age,group_with_feature = True)
				final_reconstructed_ft_points = supporting.find_final_reconstructed_geometries(reconstructed_point_fts,pygplates.PointOnSphere)
				temp_list_of_points = []
				for temp_right_point_feature,right_point_for_polygon in final_reconstructed_ft_points:
					temp_list_of_points.append(right_point_for_polygon)
				_,divergent_end_age = temp_right_point_feature.get_valid_time()
				new_first_right_polygon = pygplates.PolygonOnSphere(temp_list_of_points)
				new_first_right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,new_first_right_polygon,valid_time = (at_age,divergent_end_age))
				new_first_right_ft.set_reconstruction_plate_id(reconstruction_plate_id_for_new_first_right_ft)
				output_oceanic_polygon_fts.append(new_first_right_ft)
				#create the second new right polygon
				reconstructed_point_fts[:] = []
				if (reference is not None):
					pygplates.reconstruct([first_middle_point_ft_for_right,second_middle_point_ft_for_right,first_right_point_ft,second_right_point_ft],rotation_model,reconstructed_point_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct([first_middle_point_ft_for_right,second_middle_point_ft_for_right,first_right_point_ft,second_right_point_ft],rotation_model,reconstructed_point_fts,at_age,group_with_feature = True)
				final_reconstructed_ft_points = supporting.find_final_reconstructed_geometries(reconstructed_point_fts,pygplates.PointOnSphere)
				first_reconstructed_middle_ft,first_reconstructed_middle_pt = final_reconstructed_ft_points[0]
				second_reconstructed_middle_ft,second_reconstructed_middle_pt = final_reconstructed_ft_points[1]
				new_middle_pt = find_the_mid_of_two_PointOnSphere(first_reconstructed_middle_pt,second_reconstructed_middle_pt)
				first_reconstructed_right_ft,first_reconstructed_right_pt = final_reconstructed_ft_points[2]
				second_reconstructed_right_ft,second_reconstructed_right_pt = final_reconstructed_ft_points[3]
				new_middle_pt_for_right = find_the_mid_of_two_PointOnSphere(first_reconstructed_right_pt,second_reconstructed_right_pt)
				#second_left_oceanic crust polygon 
				_,divergent_end_age = second_reconstructed_right_ft.get_valid_time()
				#temp_list_of_points = [new_middle_pt,new_middle_pt,second_reconstructed_middle_pt,second_reconstructed_right_pt,new_middle_pt_for_right]
				temp_list_of_points = [new_middle_pt_for_right, second_reconstructed_right_pt,second_reconstructed_middle_pt,new_middle_pt]
				new_second_right_polygon = pygplates.PolygonOnSphere(temp_list_of_points)
				new_second_right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,new_second_right_polygon,valid_time = (at_age,divergent_end_age))
				new_second_right_ft.set_reconstruction_plate_id(second_reconstructed_right_ft.get_reconstruction_plate_id())
				output_oceanic_polygon_fts.append(new_second_right_ft)
	#reverse reconstruct 
	if (reference is not None):
		pygplates.reverse_reconstruct(output_oceanic_polygon_fts,rotation_model,at_age,reference)
	else:
		pygplates.reverse_reconstruct(output_oceanic_polygon_fts,rotation_model,at_age)
	return output_oceanic_polygon_fts
				

def find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features(list_of_passive_margin_fts, SuperGDU_features, at_age, interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output):
	"""
	Find and connect locations where rifts/MOR ocurrs at age 
		list_of_passive_margin_fts: a list or a list-like structure that contains CON_OCN margin features which were previously identified from first approximated tectonic motion evaluation
		at_age: interpreted in Ma - float
		rotation_model: pygplates.RotationModel from .rot or grot file
		reference: None or any other value to be used as the reference_frame for the plate tectonic reconstruction
		test_number: int to keep track for testing the module
		modelname: str name of the plate tectonic model that we evaluate
		yyyymmdd: str year - month - day 
	Return:
		a list of: 
			locations of rifts/MOR
			topological line features connecting rifts/MOR locations
	"""

	dic = {}
	reconstructed_passive_margin_features = []
	output_small_circle_fts = []
	passive_margin_fts = [ft for ft in list_of_passive_margin_fts if ft.is_valid_at_time(at_age)]
	final_fts = []
	list_of_ordered_middle_fts = []
	final_list_of_middle_fts = []
	final_list_of_oceanic_crust = []
	final_list_of_surface_oceanic_crust = [] 
	list_of_ordered_left_fts = []
	final_list_of_left_fts = []
	list_of_ordered_right_fts = []
	final_list_of_right_fts = []
	list_of_ordered_middle_fts_for_left = []
	list_of_ordered_middle_fts_for_right = []
	list_of_valid_SuperGDU_fts = [SuperGDU_ft for SuperGDU_ft in SuperGDU_features if SuperGDU_ft.is_valid_at_time(at_age)]
	reconstructed_SuperGDU_fts = []
	SuperGDU_polygons = [] 
	temp_list_of_left_features = []
	temp_list_of_right_features = []
	
	if (reference is not None):
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,group_with_feature = True)
	final_reconstructed_passive_margin_fts = supporting.find_final_reconstructed_geometries(reconstructed_passive_margin_features,pygplates.PolylineOnSphere)
	final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU_fts, pygplates.PolygonOnSphere)
	SuperGDU_polygons[:] = []
	for _,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
		SuperGDU_polygons.append(SuperGDU_polygon.clone())

	print('find pairs of GDUs_id and associated divergent continental-oceanic divergent margins to find relative stage E poles')
	txt = """SELECT super_gdu_id, represent_gdu_id FROM super_gdu_and_members_id WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}  """
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_2 = conn.cursor()
		for passive_margin_ft_1, passive_margin_1 in final_reconstructed_passive_margin_fts:
			#check whether passive_margin_ft_1 is an infered margin
			is_inferred_tectonic_ft = False
			name_of_ft_1 = passive_margin_ft_1.get_name()
			spilt_string = name_of_ft_1.split("_")
			if (spilt_string[0] == 'inferred'):
				is_inferred_tectonic_ft = True
			left_plate_ID = passive_margin_ft_1.get_left_plate()
			right_plate_ID = passive_margin_ft_1.get_right_plate()
			sql = txt.format(input_member_id = left_plate_ID, input_time = at_age)
			cur.execute(sql)
			row = cur.fetchone()
			SuperGDU_id_1 = -1
			SuperGDU_id_2 = -1
			represent_gdu_id_1 = -1
			represent_gdu_id_2 = -1
			if (row is None):
				print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
				print("Warning cannot find SuperGDU id associated with member GDU id:")
				print(left_plate_ID)
				print("at age")
				print(at_age)
				#exit()
			else:
				SuperGDU_id_1 = row[0]
				represent_gdu_id_1 = row[1]
			sql_2 = txt.format(input_member_id = right_plate_ID, input_time = at_age)
			cur_2.execute(sql_2)
			row_2 = cur_2.fetchone()
			if (row_2 is None):
				print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
				print("Warning cannot find SuperGDU id associated with member GDU id:")
				print(right_plate_ID)
				print("at age")
				print(at_age)
				#exit()
			else:
				SuperGDU_id_2 = row_2[0]
				represent_gdu_id_2 = row_2[1]
			if (row is not None and row_2 is not None):
				key = str(represent_gdu_id_1)+"_"+str(represent_gdu_id_2)
				reverse_key = str(represent_gdu_id_2)+"_"+str(represent_gdu_id_1)
				if (key not in dic and reverse_key not in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone())]
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone())]
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone())]
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone())]
				elif (key in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
				elif (reverse_key in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							if (closest_ft is not None):
								dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							if (closest_ft is not None):
								dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
	except (psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
	#find small circles for each E pole
	# print('find small circles for each E pole')
	# print('number of pairs of GDUs_id')
	# print(len(dic.keys()))
	for key in dic.keys():
		pairs_GDU_id = key.split('_')
		plate_id_1 = int(pairs_GDU_id[0])
		plate_id_2 = int(pairs_GDU_id[1])
		#find rotation pole from total_relative_reconstruction_rotation (relative between two GDU and from the present-day to at_age)
		total_relative_reconstruction_rotation = find_total_relative_reconstruction_rotation_(rotation_model,plate_id_1,plate_id_2, at_age, reference)
		#find intersection for each pair of divergent continental-oceanic boundaries
		l = dic[key]
		print('number of pairs of margins with key:')
		print(key)
		print(len(l))
		#degbug
		if (key == '10401_10041' or key == '10041_10401'):
			for temp_passive_margin_ft_1, temp_passive_margin_1, temp_passive_margin_ft_2, temp_passive_margin_2 in l:
				temp_gdu_id_1 = temp_passive_margin_ft_1.get_reconstruction_plate_id()
				temp_gdu_id_2 = temp_passive_margin_ft_2.get_reconstruction_plate_id()
				if ((temp_gdu_id_1 == 10503 and temp_gdu_id_2 == 10752) or (temp_gdu_id_1 == 10752 and temp_gdu_id_2 == 10503)):
					is_inferred_tectonic_ft = False
					name_of_ft_1 = temp_passive_margin_ft_1.get_name()
					spilt_string = name_of_ft_1.split("_")
					if (spilt_string[0] == 'inferred'):
						is_inferred_tectonic_ft = True
					is_inferred_tectonic_ft = False
					name_of_ft_2 = temp_passive_margin_ft_2.get_name()
					spilt_string = name_of_ft_2.split("_")
					if (spilt_string[0] == 'inferred'):
						is_inferred_tectonic_ft = True
					if (is_inferred_tectonic_ft == True):
						print(temp_gdu_id_1,temp_gdu_id_2)
						print(temp_passive_margin_ft_1.get_name(), temp_passive_margin_ft_2.get_name())
						#print(temp_passive_margin_ft_1.get_feature_id().get_string())
						#print(temp_passive_margin_ft_2.get_feature_id().get_string())
						exit()
			
		if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
			list_of_ordered_middle_fts[:] = []
			list_of_ordered_middle_fts_for_left[:] = []
			list_of_ordered_middle_fts_for_right[:] = []
			list_of_ordered_left_fts[:] = []
			list_of_ordered_right_fts[:] = []
			#moving_plate_id is plate_id_1 and fixed_plate_id is plate_id_2 - programmer's choice
			E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
			#small_circle_centre,small_circle_angular_radius_degrees,small_circle_reconstruction_plate_id,small_circle_begin_time,small_circle_end_time
			smallest_circle_angular_radius_degrees = 179.00
			#final_left_plate_id and final_right_plate_id to assign oceanic crust
			final_left_plate_id, final_right_plate_id = -1,-1
			while (smallest_circle_angular_radius_degrees > 0.00):
				#print('value of smallest_circle_angular_radius_degrees')
				#print(smallest_circle_angular_radius_degrees)
				small_circle_ft = None
				small_circle_begin_time = at_age
				small_circle_end_time = 0.00
				if (reference is not None):
					small_circle_ft = rotation_utility.create_small_circle_PolygonOnSphere_feature(E_pole,smallest_circle_angular_radius_degrees,reference,small_circle_begin_time,small_circle_end_time)
				else:
					small_circle_ft = rotation_utility.create_small_circle_PolygonOnSphere_feature(E_pole,smallest_circle_angular_radius_degrees,0,small_circle_begin_time,small_circle_end_time)
				
				#debug
				if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
					small_circle_ft.set_description(str(smallest_circle_angular_radius_degrees))
					small_circle_ft.set_conjugate_plate_id([plate_id_1,plate_id_2])
					output_small_circle_fts.append(small_circle_ft)
				
				small_circle_geometry = small_circle_ft.get_geometry()
				small_circle_lat_lon_list = small_circle_geometry.to_lat_lon_list()
				small_circle_boundary = pygplates.PolylineOnSphere(small_circle_lat_lon_list)
				small_circle_boundary_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
				#be aware small circle passing through -180 and +180 ---- think about it
				for passive_margin_ft_1, passive_margin_1, passive_margin_ft_2, passive_margin_2 in l:
					passive_margin_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(passive_margin_1)
					passive_margin_2_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(passive_margin_2)
					valid_age_of_tectonic_ft = passive_margin_ft_1.get_valid_time()
					gdu_id_1 = passive_margin_ft_1.get_reconstruction_plate_id()
					gdu_id_2 = passive_margin_ft_2.get_reconstruction_plate_id()
					#p1 means closest point on line 1 from passive_margin_1 and p2 means closest point on line 2 from passive_margin_2
					approx_rad_closes_dist_1, p1, _ = pygplates.GeometryOnSphere.distance(passive_margin_1, small_circle_boundary, return_closest_positions=True)
					approx_rad_closes_dist_2, p2, _ = pygplates.GeometryOnSphere.distance(passive_margin_2, small_circle_boundary, return_closest_positions=True)
					
					# first_intersection = small_circle_boundary_in_Shapely.intersection(passive_margin_1_in_Shapely)
					# second_intersection = small_circle_boundary_in_Shapely.intersection(passive_margin_2_in_Shapely)
					# if (first_intersection.geom_type == 'Point' and second_intersection.geom_type == 'Point'):
						# lat_1 = first_intersection.y
						# lon_1 = first_intersection.x
						# lat_2 = second_intersection.y
						# lon_2 = second_intersection.x
						# p1 = pygplates.PointOnSphere((lat_1,lon_1))
						# p2 = pygplates.PointOnSphere((lat_2,lon_2))
						
					if (approx_rad_closes_dist_1 == approx_rad_closes_dist_2 == 0.00):
						#debug
						if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
							print('approx_rad_closes_dist_1 == approx_rad_closes_dist_2 == 0.00')
							print(gdu_id_1, gdu_id_2)
						mid_point = find_the_mid_of_two_PointOnSphere(p1,p2)

						#great circle arc from mid_point to E
						great_circle_arc = pygplates.GreatCircleArc(mid_point,E_pole)
						normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
						left, right = identify_left_gdu_and_right_gdu(normal_vector_of_great_circle_arc, mid_point, p1, p2, gdu_id_1, gdu_id_2)
						if (final_left_plate_id == -1 and final_right_plate_id == -1):
							temp_total_relative_reconstruction_rotation = find_total_relative_reconstruction_rotation_(rotation_model,left,right, at_age, reference)
							_,temp_angle_rads = temp_total_relative_reconstruction_rotation.get_euler_pole_and_angle()
							if (temp_angle_rads == angle_rads):
								final_left_plate_id = plate_id_1
								final_right_plate_id = plate_id_2
							else:
								final_left_plate_id = plate_id_2
								final_right_plate_id = plate_id_1
							
						#MOR
						print("valid_age_of_tectonic_ft")
						print(valid_age_of_tectonic_ft)
						description_str = str(left)+"_"+str(right)
						middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_continental_rift,mid_point,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
						middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
						middle_ft.set_description(str(smallest_circle_angular_radius_degrees))
						middle_ft.set_left_plate(left)
						middle_ft.set_right_plate(right)
						#middle_ft.set_conjugate_plate_id([plate_id_1,plate_id_2])
						middle_ft_for_left = middle_ft.clone()
						middle_ft_for_left.set_reconstruction_plate_id(left)
						#middle_ft_for_left.set_reconstruction_method('ByPlateId')
						middle_ft_for_right = middle_ft.clone()
						middle_ft_for_right.set_reconstruction_plate_id(right)
						#middle_ft_for_right.set_reconstruction_method('ByPlateId')
						if (reference is None):
							pygplates.reverse_reconstruct([middle_ft,middle_ft_for_left,middle_ft_for_right],rotation_model,at_age)
						else:
							pygplates.reverse_reconstruct([middle_ft,middle_ft_for_left,middle_ft_for_right],rotation_model,at_age,reference)
						list_of_ordered_middle_fts_for_left.append(middle_ft_for_left)
						list_of_ordered_middle_fts_for_right.append(middle_ft_for_right)
						list_of_ordered_middle_fts.append(middle_ft)
						final_list_of_middle_fts.append(middle_ft)
						
						#CON_OCN divergent margins
						left_ft, right_ft = None,None
						if (left == gdu_id_1 and right == gdu_id_2):
							left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p1,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							left_ft.set_reconstruction_plate_id(gdu_id_1)
							right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p2,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							right_ft.set_reconstruction_plate_id(gdu_id_2)
						elif (left == gdu_id_2 and right == gdu_id_1):
							left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p2,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							left_ft.set_reconstruction_plate_id(gdu_id_2)
							right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p1,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							right_ft.set_reconstruction_plate_id(gdu_id_1)	
						#debug 
						print("here is left_ft")
						print(left_ft)
						print("here is right_ft")
						print(right_ft)
						if(left_ft is None or right_ft is None):
							print("Error: either left_ft or right_ft is None")
							print("left, right")
							print(left, right)
							print("gdu_id_1, gdu_id_2")
							print(gdu_id_1, gdu_id_2)
							exit()
						#left_ft.set_conjugate_plate_id([plate_id_1,plate_id_2])
						#right_ft.set_conjugate_plate_id([plate_id_1,plate_id_2])
						if (reference is None):
							pygplates.reverse_reconstruct([left_ft,right_ft],rotation_model,at_age)
						else:
							pygplates.reverse_reconstruct([left_ft,right_ft],rotation_model,at_age,reference)
						list_of_ordered_left_fts.append(left_ft)
						final_list_of_middle_fts.append(left_ft)
						list_of_ordered_right_fts.append(right_ft)
						final_list_of_middle_fts.append(right_ft)
						print('len(list_of_ordered_left_fts)')
						print(len(list_of_ordered_left_fts))
						print('len(list_of_ordered_right_fts)')
						print(len(list_of_ordered_right_fts))

				smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 0.500
			#connect middle features to create a single topological feature
			# topological_line = create_a_topological_line_from_static_point_fts(list_of_ordered_middle_fts)
			# topological_feature_type = pygplates.FeatureType.gpml_mid_ocean_ridge
			# list_of_topological_fts_for_E_pole = create_list_of_topological_features_from_topological_sections(topological_feature_type, [topological_line])
			# for topological_ft in list_of_topological_fts_for_E_pole:
				# final_list_of_middle_fts.append(topological_ft)
			
			#create left oceanic topological polygon features - orderd of points is counterclockwise. 
			# print('len(list_of_ordered_middle_fts)')
			# print(len(list_of_ordered_middle_fts))
			# print('len(list_of_ordered_left_fts)')
			# print(len(list_of_ordered_left_fts))
			# print('len(list_of_ordered_right_fts)')
			# print(len(list_of_ordered_right_fts))
			# print('reversed list_of_ordered_left_fts')
			# print(list_of_ordered_left_fts.reverse())
			# print('reversed list_of_ordered_right_fts')
			# print(list_of_ordered_right_fts.reverse())
			divergent_end_age,_ = find_min_max_age_from_middle_fts(list_of_ordered_middle_fts)
			#divergent_max_end_age = find_max_end_age_from_middle_fts(list_of_ordered_middle_fts)
			#list_of_ordered_left_fts.reverse()
			#list_of_points_for_left_oceanic_crust = list_of_ordered_middle_fts + list_of_ordered_left_fts
			#list_of_points_for_left_oceanic_crust = list_of_ordered_middle_fts_for_left + list_of_ordered_left_fts
			temporary_reversed_ordered_left_fts = [item for item in reversed(list_of_ordered_left_fts)]
			list_of_points_for_left_oceanic_crust = list_of_ordered_middle_fts + temporary_reversed_ordered_left_fts
			left_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_left_oceanic_crust)
			print('Here is left_topological_polygon')
			print(left_topological_polygon)
			topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
			left_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, left_topological_polygon)
			#left_topological_polygon_feature.set_valid_time(at_age,at_age-interval)
			print('Here is left_topological_polygon_feature')
			print(left_topological_polygon_feature)
			final_list_of_middle_fts.append(left_topological_polygon_feature)

			#list_of_ordered_middle_fts.reverse()
			#list_of_points_for_right_oceanic_crust = list_of_ordered_right_fts + list_of_ordered_middle_fts
			temporary_reversed_ordered_middle_fts = [item for item in reversed(list_of_ordered_middle_fts)]
			list_of_points_for_right_oceanic_crust = list_of_ordered_right_fts + temporary_reversed_ordered_middle_fts
			#list_of_ordered_middle_fts_for_right.reverse()
			#list_of_points_for_right_oceanic_crust = list_of_ordered_right_fts + list_of_ordered_middle_fts_for_right
			right_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_right_oceanic_crust)
			print('Here is right_topological_polygon')
			print(right_topological_polygon)
			topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
			right_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, right_topological_polygon)
			print('Here is right_topological_polygon_feature')
			print(right_topological_polygon_feature)
			final_list_of_middle_fts.append(right_topological_polygon_feature)
			
			#try to create topological boundary
			#subsequent oceanic crust --- LEFT relative to MOR
			#subsequent_left_fts =	find_subsequent_left_oceanic_crust(list_of_ordered_middle_fts, list_of_ordered_middle_fts_for_left, rotation_model, at_age, divergent_end_age, interval, reference)
			#for subsequent_left_ft in subsequent_left_fts:
			#	final_list_of_middle_fts.append(subsequent_left_ft)
			#subsequent oceanic crust --- RIGHT relative to MOR
			#subsequent_right_fts = find_subsequent_right_oceanic_crust(list_of_ordered_middle_fts, list_of_ordered_middle_fts_for_right, rotation_model, at_age, divergent_end_age, interval, reference)
			#for subsequent_right_ft in subsequent_right_fts:
			#	final_list_of_middle_fts.append(subsequent_right_ft)
			
			# #create reconstructable oceanic crust
			# print('len(list_of_ordered_middle_fts)')
			# print(len(list_of_ordered_middle_fts))
			# print('(at_age - divergent_end_age)')
			# print((at_age - divergent_end_age))
			# if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
				# print('len(list_of_ordered_middle_fts)')
				# print(len(list_of_ordered_middle_fts))
				# print('len(list_of_ordered_left_fts)')
				# print(len(list_of_ordered_left_fts))
				# print('final_left_plate_id')
				# print(final_left_plate_id)
				# print('at_age,divergent_end_age')
				# print(at_age,divergent_end_age)
				# print('at_age - divergent_end_age')
				# print(at_age - divergent_end_age)
				# #exit()
				
				
			if (len(list_of_ordered_middle_fts) > 0 and (at_age - divergent_end_age) >= interval):
				subsequent_left_fts, surface_left_oceanic_crust_fts, subsequent_right_fts, surface_right_oceanic_crust_fts =  find_subsequent_left_right_oceanic_crust(list_of_ordered_middle_fts, list_of_ordered_left_fts, list_of_ordered_right_fts, rotation_model, at_age, divergent_end_age, interval, reference,SuperGDU_features)
				for subsequent_left_ft in subsequent_left_fts:
					final_list_of_oceanic_crust.append(subsequent_left_ft)
				for subsequent_left_ft in surface_left_oceanic_crust_fts:
					final_list_of_surface_oceanic_crust.append(subsequent_left_ft)
				for subsequent_right_ft in subsequent_right_fts:
					final_list_of_oceanic_crust.append(subsequent_right_ft)
				for subsequent_right_ft in surface_right_oceanic_crust_fts:
					final_list_of_surface_oceanic_crust.append(subsequent_right_ft)
				
				#old...require discretize_middle_features
				# dic_of_middle_fts = discretize_middle_features(list_of_ordered_middle_fts,SuperGDU_polygons,rotation_model,at_age,reference)
				# not_incl_middle_point_index = -1
				# for key_of_dic_of_middle_fts in dic_of_middle_fts:
					# temp_list_of_middle_features = dic_of_middle_fts[key_of_dic_of_middle_fts]
					# temp_list_of_left_features[:] = []
					# temp_list_of_right_features[:] = []
					# if (not_incl_middle_point_index == -1):
						# not_incl_middle_point_index = int(key_of_dic_of_middle_fts)
						# for u in range(0, not_incl_middle_point_index):
							# temp_list_of_left_features.append(list_of_ordered_left_fts[u])
							# temp_list_of_right_features.append(list_of_ordered_right_fts[u])
					# else:
						# previous_not_incl_index = not_incl_middle_point_index
						# not_incl_middle_point_index = int(key_of_dic_of_middle_fts)
						# for u in range(previous_not_incl_index, not_incl_middle_point_index):
							# temp_list_of_left_features.append(list_of_ordered_left_fts[u])
							# temp_list_of_right_features.append(list_of_ordered_right_fts[u])
					# #subsequent oceanic crust --- LEFT relative to MOR
					# subsequent_left_fts, surface_left_oceanic_crust_fts =	 find_subsequent_left_oceanic_crust(final_left_plate_id, temp_list_of_middle_features, temp_list_of_left_features, rotation_model, at_age, divergent_end_age, interval, reference,SuperGDU_features)
					# for subsequent_left_ft in subsequent_left_fts:
						# final_list_of_oceanic_crust.append(subsequent_left_ft)
					# for left_oc_ft in surface_left_oceanic_crust_fts:
						# final_list_of_surface_oceanic_crust.append(left_oc_ft)
					# #subsequent oceanic crust --- RIGHT relative to MOR
					# # subsequent_right_fts, surface_right_oceanic_crust_fts = find_subsequent_right_oceanic_crust(final_right_plate_id, temp_list_of_middle_features, temp_list_of_right_features, rotation_model, at_age, divergent_end_age, interval, reference,SuperGDU_features)
					# # for subsequent_right_ft in subsequent_right_fts:
						# # final_list_of_oceanic_crust.append(subsequent_right_ft)
					# # for right_oc_ft in surface_right_oceanic_crust_fts:
						# # final_list_of_surface_oceanic_crust.append(right_oc_ft)
				
					# if (len(temp_list_of_right_features) == 0 and len(temp_list_of_left_features) == 0):
						# print("Error in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
						# print(len(temp_list_of_right_features) == 0 and len(temp_list_of_left_features) == 0)
						# print('len(temp_list_of_middle_features)')
						# print(len(temp_list_of_middle_features))
						# print('len(temp_list_of_right_features)')
						# print(len(temp_list_of_right_features))
						# print('len(temp_list_of_left_features)')
						# print(len(temp_list_of_left_features))
						# print('at_age')
						# print(at_age)
						# print('plate_id_1,plate_id_2')
						# print(plate_id_1,plate_id_2)
						# exit()
				
	if (write_output == True):
		# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_middle_fts)
		# outputFile = "new_rift_point_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		# outputFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_oceanic_crust)
		outputFile = "oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_surface_oceanic_crust)
		outputFile = "surface_oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
	# outputFeatureCollection = pygplates.FeatureCollection(output_small_circle_fts)
	# outputFile = "output_small_circle_fts_10439_10480_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".shp"
	# outputFeatureCollection.write(outputFile)
	
	return final_list_of_middle_fts,final_list_of_oceanic_crust,final_list_of_surface_oceanic_crust

def find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_version_2(list_of_passive_margin_fts, SuperGDU_features, at_age, interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output):
	"""
	Find and connect locations where rifts/MOR ocurrs at age 
		list_of_passive_margin_fts: a list or a list-like structure that contains CON_OCN margin features which were previously identified from first approximated tectonic motion evaluation
		at_age: interpreted in Ma - float
		rotation_model: pygplates.RotationModel from .rot or grot file
		reference: None or any other value to be used as the reference_frame for the plate tectonic reconstruction
		test_number: int to keep track for testing the module
		modelname: str name of the plate tectonic model that we evaluate
		yyyymmdd: str year - month - day 
	Return:
		a list of: 
			locations of rifts/MOR
			topological line features connecting rifts/MOR locations
	"""

	dic = {}
	reconstructed_passive_margin_features = []
	output_small_circle_fts = []
	passive_margin_fts = [ft for ft in list_of_passive_margin_fts if ft.is_valid_at_time(at_age)]
	final_fts = []
	left_features = []
	right_features = []
	list_of_ordered_middle_fts = []
	final_list_of_middle_fts = []
	final_list_of_middle_polygon_fts = []
	final_list_of_oceanic_crust = []
	final_list_of_surface_oceanic_crust = [] 
	list_of_ordered_left_fts = []
	final_list_of_left_fts = []
	list_of_ordered_right_fts = []
	final_list_of_right_fts = []
	list_of_ordered_middle_fts_for_left = []
	list_of_ordered_middle_fts_for_right = []
	list_of_valid_SuperGDU_fts = [SuperGDU_ft for SuperGDU_ft in SuperGDU_features if SuperGDU_ft.is_valid_at_time(at_age)]
	reconstructed_SuperGDU_fts = []
	SuperGDU_polygons = [] 
	temp_list_of_left_features = []
	temp_list_of_right_features = []
	list_of_points_intersecting_left = []
	list_of_points_intersecting_right = [] 
	outputPointFeatureCollection = pygplates.FeatureCollection()
	
	if (reference is not None):
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,group_with_feature = True)
	final_reconstructed_passive_margin_fts = supporting.find_final_reconstructed_geometries(reconstructed_passive_margin_features,pygplates.PolylineOnSphere)
	final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU_fts, pygplates.PolygonOnSphere)
	SuperGDU_polygons[:] = []
	for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
		SuperGDU_polygons.append(SuperGDU_polygon.clone())

	print('find pairs of GDUs_id and associated divergent continental-oceanic divergent margins to find relative stage E poles')
	txt = """SELECT super_gdu_id, represent_gdu_id FROM super_gdu_and_members_id WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}  """
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_2 = conn.cursor()
		for passive_margin_ft_1, passive_margin_1 in final_reconstructed_passive_margin_fts:
			#check whether passive_margin_ft_1 is an infered margin
			is_inferred_tectonic_ft = False
			name_of_ft_1 = passive_margin_ft_1.get_name()
			spilt_string = name_of_ft_1.split("_")
			if (spilt_string[0] == 'inferred'):
				is_inferred_tectonic_ft = True
			left_plate_ID = passive_margin_ft_1.get_left_plate()
			right_plate_ID = passive_margin_ft_1.get_right_plate()
			sql = txt.format(input_member_id = left_plate_ID, input_time = at_age)
			cur.execute(sql)
			row = cur.fetchone()
			SuperGDU_id_1 = -1
			SuperGDU_id_2 = -1
			represent_gdu_id_1 = -1
			represent_gdu_id_2 = -1
			if (row is None):
				print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
				print("Warning cannot find SuperGDU id associated with member GDU id:")
				print(left_plate_ID)
				print("at age")
				print(at_age)
				#exit()
			else:
				SuperGDU_id_1 = row[0]
				represent_gdu_id_1 = row[1]
			sql_2 = txt.format(input_member_id = right_plate_ID, input_time = at_age)
			cur_2.execute(sql_2)
			row_2 = cur_2.fetchone()
			if (row_2 is None):
				print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
				print("Warning cannot find SuperGDU id associated with member GDU id:")
				print(right_plate_ID)
				print("at age")
				print(at_age)
				#exit()
			else:
				SuperGDU_id_2 = row_2[0]
				represent_gdu_id_2 = row_2[1]
			if (row is not None and row_2 is not None):
				key = str(represent_gdu_id_1)+"_"+str(represent_gdu_id_2)
				reverse_key = str(represent_gdu_id_2)+"_"+str(represent_gdu_id_1)
				if (key not in dic and reverse_key not in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone())]
										dic[key] = {'left':[(passive_margin_ft_1.clone(), passive_margin_1.clone())], 'right':[(passive_margin_ft_2.clone(),passive_margin_2.clone())]}
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone())]
										dic[key] = {'left':[(passive_margin_ft_2.clone(), passive_margin_2.clone())], 'right':[(passive_margin_ft_1.clone(),passive_margin_1.clone())]}
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone())]
								dic[key] = {'left':[(passive_margin_ft_1.clone(), passive_margin_1.clone())], 'right':[(closest_ft.clone(),closest_margin.clone())]}
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone())]
								dic[key] = {'left':[(closest_ft.clone(),closest_margin.clone())], 'right':[(passive_margin_ft_1.clone(), passive_margin_1.clone())]}
				elif (key in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										#dic[key]['right'].append((closest_ft.clone(),closest_margin.clone()))
										
										dic[key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										dic[key]['right'].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										#dic[key]['left'].append((closest_ft.clone(),closest_margin.clone()))
										
										dic[key]['left'].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
										dic[key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[key]['right'].append((closest_ft.clone(),closest_margin.clone()))
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[key]['left'].append((closest_ft.clone(),closest_margin.clone()))
				elif (reverse_key in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										dic[reverse_key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										dic[reverse_key]['right'].append((passive_margin_ft_2.clone(),passive_margin_2.clone()))
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										dic[reverse_key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										dic[reverse_key]['left'].append((passive_margin_ft_2.clone(),passive_margin_2.clone()))
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							if (closest_ft is not None):
								#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[reverse_key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[reverse_key]['right'].append((closest_ft.clone(),closest_margin.clone()))
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							if (closest_ft is not None):
								#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[reverse_key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[reverse_key]['left'].append((closest_ft.clone(),closest_margin.clone()))
	except (psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
	#find small circles for each E pole
	# print('find small circles for each E pole')
	# print('number of pairs of GDUs_id')
	# print(len(dic.keys()))
	for key in dic.keys():
		pairs_GDU_id = key.split('_')
		plate_id_1 = int(pairs_GDU_id[0])
		plate_id_2 = int(pairs_GDU_id[1])
		#find rotation pole from total_relative_reconstruction_rotation (relative between two GDU and from the present-day to at_age)
		total_relative_reconstruction_rotation = find_total_relative_reconstruction_rotation_(rotation_model,plate_id_1,plate_id_2, at_age, reference)
		#find intersection for each pair of divergent continental-oceanic boundaries
		print('number of pairs of margins with key:')
		print(key)
		temp_left_features = dic[key]['left']
		temp_right_features = dic[key]['right']
		print(len(temp_left_features))
		#degbug
		# if (key == '10401_10041' or key == '10041_10401'):
			# for temp_passive_margin_ft_1, temp_passive_margin_1, temp_passive_margin_ft_2, temp_passive_margin_2 in l:
				# temp_gdu_id_1 = temp_passive_margin_ft_1.get_reconstruction_plate_id()
				# temp_gdu_id_2 = temp_passive_margin_ft_2.get_reconstruction_plate_id()
				# if ((temp_gdu_id_1 == 10503 and temp_gdu_id_2 == 10752) or (temp_gdu_id_1 == 10752 and temp_gdu_id_2 == 10503)):
					# is_inferred_tectonic_ft = False
					# name_of_ft_1 = temp_passive_margin_ft_1.get_name()
					# spilt_string = name_of_ft_1.split("_")
					# if (spilt_string[0] == 'inferred'):
						# is_inferred_tectonic_ft = True
					# is_inferred_tectonic_ft = False
					# name_of_ft_2 = temp_passive_margin_ft_2.get_name()
					# spilt_string = name_of_ft_2.split("_")
					# if (spilt_string[0] == 'inferred'):
						# is_inferred_tectonic_ft = True
					# if (is_inferred_tectonic_ft == True):
						# print(temp_gdu_id_1,temp_gdu_id_2)
						# print(temp_passive_margin_ft_1.get_name(), temp_passive_margin_ft_2.get_name())
						# #print(temp_passive_margin_ft_1.get_feature_id().get_string())
						# #print(temp_passive_margin_ft_2.get_feature_id().get_string())
						# exit()
		if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
			list_of_ordered_middle_fts[:] = []
			list_of_ordered_middle_fts_for_left[:] = []
			list_of_ordered_middle_fts_for_right[:] = []
			list_of_ordered_left_fts[:] = []
			list_of_ordered_right_fts[:] = []
			left_features[:] = []
			right_features[:] = []
			#moving_plate_id is plate_id_1 and fixed_plate_id is plate_id_2 - programmer's choice
			E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
			SuperGDU_centroid_1 = None 
			SuperGDU_centroid_2 = None
			for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1):
					SuperGDU_centroid_1 = SuperGDU_polygon.get_interior_centroid()
				elif (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2):
					SuperGDU_centroid_2 = SuperGDU_polygon.get_interior_centroid()
				if (SuperGDU_centroid_1 is not None and SuperGDU_centroid_2 is not None):
					break
			mid_point_btwn_centroids = find_the_mid_of_two_PointOnSphere(SuperGDU_centroid_1,SuperGDU_centroid_2)
			great_circle_arc = pygplates.GreatCircleArc(mid_point_btwn_centroids,E_pole)
			normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
			for l1_ft,l1 in temp_left_features:
				p = l1.get_centroid()
				side = classify_left_or_right(normal_vector_of_great_circle_arc, mid_point_btwn_centroids, p)
				if (side == 'left'):
					left_features.append((l1_ft,l1))
				elif (side == 'right'):
					right_features.append((l1_ft,l1))
			for l2_ft,l2 in temp_right_features:
				p = l2.get_centroid()
				side = classify_left_or_right(normal_vector_of_great_circle_arc, mid_point_btwn_centroids, p)
				if (side == 'left'):
					left_features.append((l2_ft,l2))
				elif (side == 'right'):
					right_features.append((l2_ft,l2))
			#small_circle_centre,small_circle_angular_radius_degrees,small_circle_reconstruction_plate_id,small_circle_begin_time,small_circle_end_time
			smallest_circle_angular_radius_degrees = 179.00
			#final_left_plate_id and final_right_plate_id to assign oceanic crust
			final_left_plate_id, final_right_plate_id = -1,-1
			while (smallest_circle_angular_radius_degrees > 0.00):
				#print('value of smallest_circle_angular_radius_degrees')
				#print(smallest_circle_angular_radius_degrees)
				small_circle_ft = None
				small_circle_begin_time = at_age
				small_circle_end_time = 0.00
				if (reference is not None):
					small_circle_ft = rotation_utility.create_small_circle_PolygonOnSphere_feature(E_pole,smallest_circle_angular_radius_degrees,reference,small_circle_begin_time,small_circle_end_time)
				else:
					small_circle_ft = rotation_utility.create_small_circle_PolygonOnSphere_feature(E_pole,smallest_circle_angular_radius_degrees,0,small_circle_begin_time,small_circle_end_time)
				
				#debug
				# if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
					# small_circle_ft.set_description(str(smallest_circle_angular_radius_degrees))
					# small_circle_ft.set_conjugate_plate_id([plate_id_1,plate_id_2])
					# output_small_circle_fts.append(small_circle_ft)
				
				small_circle_geometry = small_circle_ft.get_geometry()
				small_circle_lat_lon_list = small_circle_geometry.to_lat_lon_list()
				small_circle_boundary = pygplates.PolylineOnSphere(small_circle_lat_lon_list)
				small_circle_boundary_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
				#be aware small circle passing through -180 and +180 ---- think about it
				list_of_points_intersecting_left[:] = []
				list_of_points_intersecting_right[:] = []
				for left_passive_margin_ft, left_passive_margin in left_features:
					#passive_margin_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(left_passive_margin)
					valid_age_of_tectonic_ft = left_passive_margin_ft.get_valid_time()
					gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
					#p1 means closest point on line 1 from left_passive_margin
					approx_rad_closes_dist_1, p1, _ = pygplates.GeometryOnSphere.distance(left_passive_margin, small_circle_boundary, return_closest_positions=True)
					if (approx_rad_closes_dist_1 == 0.00):
						list_of_points_intersecting_left.append(p1)
				for right_passive_margin_ft, right_passive_margin in right_features:
					approx_rad_closes_dist_2,p2, _ = pygplates.GeometryOnSphere.distance(right_passive_margin, small_circle_boundary, return_closest_positions=True)
					if (approx_rad_closes_dist_2 == 0.00):
						list_of_points_intersecting_right.append(p2)
				final_left_point,final_right_point = None,None
				min_distance = -1.00
				for left_point in list_of_points_intersecting_left:
					for right_point in list_of_points_intersecting_right:
						if (left_point != right_point):
							d = pygplates.GeometryOnSphere.distance(left_point, right_point)
							if (min_distance == -1.00):
								min_distance = d
								final_left_point,final_right_point = left_point,right_point
							elif (min_distance >= 0.00 and d < min_distance):
								min_distance = d
								final_left_point,final_right_point = left_point,right_point
				if (final_left_point is not None and final_right_point is not None):
					for left_passive_margin_ft, left_passive_margin in left_features:
						if (pygplates.GeometryOnSphere.distance(left_passive_margin,final_left_point) == 0.00):
							p1 = final_left_point
							gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
							break
					for right_passive_margin_ft, right_passive_margin in right_features:
						if (pygplates.GeometryOnSphere.distance(right_passive_margin,final_right_point) == 0.00):
							p2 = final_right_point
							gdu_id_2 = right_passive_margin_ft.get_reconstruction_plate_id()
							break
					#find mid_point
					mid_point = None
					if (p1 is not None and p2 is not None and gdu_id_1 != gdu_id_2):
						#debug
						# if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
							# print('approx_rad_closes_dist_1 == approx_rad_closes_dist_2 == 0.00')
							# print(gdu_id_1, gdu_id_2)
						mid_point = find_the_mid_of_two_PointOnSphere(p1,p2)
						#have to make sure mid_point is not within the interior of any SuperGDU polygons
						for big_polygon in SuperGDU_polygons:
							if (big_polygon.is_point_in_polygon(mid_point) == True):
								mid_point = None
								break
					if (mid_point is not None):			
						#great circle arc from mid_point to E
						great_circle_arc = pygplates.GreatCircleArc(mid_point,E_pole)
						normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
						left, right = identify_left_gdu_and_right_gdu(normal_vector_of_great_circle_arc, mid_point, p1, p2, gdu_id_1, gdu_id_2)

						#MOR
						print("valid_age_of left_tectonic_ft")
						print(valid_age_of_tectonic_ft)
						description_str = str(left)+"_"+str(right)
						middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, mid_point, name = "rifting/MOR_"+description_str, valid_time = valid_age_of_tectonic_ft)
						middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
						middle_ft.set_description(str(smallest_circle_angular_radius_degrees))
						middle_ft.set_left_plate(left)
						middle_ft.set_right_plate(right)
						
						#debug
						# print("middle_ft")
						# print(middle_ft)
						# print("middle_ft left and middle_ft right")
						# print(middle_ft.get_left_plate(), middle_ft.get_right_plate())
						# print("conjugate plate_id for middle_ft")
						# print(middle_ft.get_conjugate_plate_id())
						# print("plate_id_1, plate_id_2")
						# print(plate_id_1, plate_id_2)
						# exit()
					
						middle_ft_for_left = middle_ft.clone()
						middle_ft_for_left.set_reconstruction_plate_id(left)
						#middle_ft_for_left.set_reconstruction_method('ByPlateId')
						middle_ft_for_right = middle_ft.clone()
						middle_ft_for_right.set_reconstruction_plate_id(right)
						#middle_ft_for_right.set_reconstruction_method('ByPlateId')
						if (reference is None):
							pygplates.reverse_reconstruct([middle_ft,middle_ft_for_left,middle_ft_for_right],rotation_model,at_age)
						else:
							pygplates.reverse_reconstruct([middle_ft,middle_ft_for_left,middle_ft_for_right],rotation_model,at_age,reference)
						list_of_ordered_middle_fts_for_left.append(middle_ft_for_left)
						list_of_ordered_middle_fts_for_right.append(middle_ft_for_right)
						list_of_ordered_middle_fts.append(middle_ft)
						final_list_of_middle_fts.append(middle_ft)
						final_list_of_middle_polygon_fts.append(middle_ft)
						
						outputPointFeatureCollection.add(middle_ft.clone())
						
						#CON_OCN divergent margins
						left_ft, right_ft = None,None
						if (left == gdu_id_1 and right == gdu_id_2):
							left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p1,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							left_ft.set_reconstruction_plate_id(gdu_id_1)
							right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p2,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							right_ft.set_reconstruction_plate_id(gdu_id_2)
						elif (left == gdu_id_2 and right == gdu_id_1):
							left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p2,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							left_ft.set_reconstruction_plate_id(gdu_id_2)
							right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p1,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							right_ft.set_reconstruction_plate_id(gdu_id_1)	
						#debug 
						# print("here is left_ft")
						# print(left_ft)
						# print("here is right_ft")
						# print(right_ft)
						if(left_ft is None or right_ft is None):
							print("Error: either left_ft or right_ft is None")
							print("left, right")
							print(left, right)
							print("gdu_id_1, gdu_id_2")
							print(gdu_id_1, gdu_id_2)
							exit()
						if (reference is None):
							pygplates.reverse_reconstruct([left_ft,right_ft],rotation_model,at_age)
						else:
							pygplates.reverse_reconstruct([left_ft,right_ft],rotation_model,at_age,reference)
						list_of_ordered_left_fts.append(left_ft)
						final_list_of_middle_fts.append(left_ft)
						final_list_of_middle_polygon_fts.append(left_ft)
						list_of_ordered_right_fts.append(right_ft)
						final_list_of_middle_fts.append(right_ft)
						final_list_of_middle_polygon_fts.append(right_ft)
						
						outputPointFeatureCollection.add(left_ft.clone())
						outputPointFeatureCollection.add(right_ft.clone())
						
						print('len(list_of_ordered_left_fts)')
						print(len(list_of_ordered_left_fts))
						print('len(list_of_ordered_right_fts)')
						print(len(list_of_ordered_right_fts))
				
				smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.000
			
			#connect middle features to create a single topological feature
			topological_line = create_a_topological_line_from_static_point_fts(list_of_ordered_middle_fts)
			topological_feature_type = pygplates.FeatureType.gpml_mid_ocean_ridge
			list_of_topological_fts_for_E_pole = create_list_of_topological_features_from_topological_sections(topological_feature_type, [topological_line])
			for topological_ft in list_of_topological_fts_for_E_pole:
				final_list_of_middle_fts.append(topological_ft)
			
			#create left oceanic topological polygon features - orderd of points is counterclockwise. 
			divergent_end_age,_ = find_min_max_age_from_middle_fts(list_of_ordered_middle_fts)
			temporary_reversed_ordered_left_fts = [item for item in reversed(list_of_ordered_left_fts)]
			list_of_points_for_left_oceanic_crust = list_of_ordered_middle_fts + temporary_reversed_ordered_left_fts
			left_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_left_oceanic_crust)
			print('Here is left_topological_polygon')
			print(left_topological_polygon)
			topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
			left_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, left_topological_polygon)
			print('Here is left_topological_polygon_feature')
			print(left_topological_polygon_feature)
			final_list_of_middle_polygon_fts.append(left_topological_polygon_feature)

			temporary_reversed_ordered_middle_fts = [item for item in reversed(list_of_ordered_middle_fts)]
			list_of_points_for_right_oceanic_crust = list_of_ordered_right_fts + temporary_reversed_ordered_middle_fts
			right_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_right_oceanic_crust)
			print('Here is right_topological_polygon')
			print(right_topological_polygon)
			topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
			right_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, right_topological_polygon)
			print('Here is right_topological_polygon_feature')
			print(right_topological_polygon_feature)
			final_list_of_middle_polygon_fts.append(right_topological_polygon_feature)

			if (len(list_of_ordered_middle_fts) > 0 and (at_age - divergent_end_age) >= interval):
				subsequent_left_fts, surface_left_oceanic_crust_fts, subsequent_right_fts, surface_right_oceanic_crust_fts =  find_subsequent_left_right_oceanic_crust(list_of_ordered_middle_fts, list_of_ordered_left_fts, list_of_ordered_right_fts, rotation_model, at_age, divergent_end_age, interval, reference,SuperGDU_features)
				for subsequent_left_ft in subsequent_left_fts:
					final_list_of_oceanic_crust.append(subsequent_left_ft)
				for subsequent_left_ft in surface_left_oceanic_crust_fts:
					final_list_of_surface_oceanic_crust.append(subsequent_left_ft)
				for subsequent_right_ft in subsequent_right_fts:
					final_list_of_oceanic_crust.append(subsequent_right_ft)
				for subsequent_right_ft in surface_right_oceanic_crust_fts:
					final_list_of_surface_oceanic_crust.append(subsequent_right_ft)

				
	if (write_output == True):
		outputFile = "new_rifts_and_associated_margins_points_fts_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".shp"
		outputPointFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_middle_fts)
		outputFile = "topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		final_list_of_middle_polygon_fts
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_middle_polygon_fts)
		outputFile = "topological_middle_polygon_fts_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_oceanic_crust)
		outputFile = "oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_surface_oceanic_crust)
		# outputFile = "surface_oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		# outputFeatureCollection.write(outputFile)
	# outputFeatureCollection = pygplates.FeatureCollection(output_small_circle_fts)
	# outputFile = "output_small_circle_fts_10439_10480_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".shp"
	# outputFeatureCollection.write(outputFile)
	
	#return final_list_of_middle_fts,final_list_of_oceanic_crust,final_list_of_surface_oceanic_crust
	return final_list_of_middle_fts,final_list_of_oceanic_crust,final_list_of_middle_polygon_fts

def find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust(list_of_passive_margin_fts, SuperGDU_features, at_age, interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output):
	"""
	Find and connect locations where rifts/MOR ocurrs at age 
		list_of_passive_margin_fts: a list or a list-like structure that contains CON_OCN margin features which were previously identified from first approximated tectonic motion evaluation
		at_age: interpreted in Ma - float
		rotation_model: pygplates.RotationModel from .rot or grot file
		reference: None or any other value to be used as the reference_frame for the plate tectonic reconstruction
		test_number: int to keep track for testing the module
		modelname: str name of the plate tectonic model that we evaluate
		yyyymmdd: str year - month - day 
	Return:
		a list of: 
			locations of rifts/MOR
			topological line features connecting rifts/MOR locations
	"""

	dic = {}
	reconstructed_passive_margin_features = []
	output_small_circle_fts = []
	passive_margin_fts = [ft for ft in list_of_passive_margin_fts if ft.is_valid_at_time(at_age)]
	final_fts = []
	left_features = []
	right_features = []
	list_of_ordered_middle_fts = []
	final_list_of_middle_fts = []
	final_list_of_middle_polygon_fts = []
	final_list_of_oceanic_crust = []
	final_list_of_surface_oceanic_crust = [] 
	list_of_ordered_left_fts = []
	final_list_of_left_fts = []
	list_of_ordered_right_fts = []
	final_list_of_right_fts = []
	list_of_ordered_middle_fts_for_left = []
	list_of_ordered_middle_fts_for_right = []
	list_of_valid_SuperGDU_fts = [SuperGDU_ft for SuperGDU_ft in SuperGDU_features if SuperGDU_ft.is_valid_at_time(at_age)]
	reconstructed_SuperGDU_fts = []
	SuperGDU_polygons = [] 
	temp_list_of_left_features = []
	temp_list_of_right_features = []
	list_of_points_intersecting_left = []
	list_of_points_intersecting_right = [] 
	line_features_for_SuperGDU_2 = [] 
	line_features_for_SuperGDU_1 = []
	outputPointFeatureCollection = pygplates.FeatureCollection()
	
	if (reference is not None):
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,group_with_feature = True)
	final_reconstructed_passive_margin_fts = supporting.find_final_reconstructed_geometries(reconstructed_passive_margin_features,pygplates.PolylineOnSphere)
	final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU_fts, pygplates.PolygonOnSphere)
	SuperGDU_polygons[:] = []
	for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
		SuperGDU_polygons.append(SuperGDU_polygon.clone())

	print('find pairs of GDUs_id and associated divergent continental-oceanic divergent margins to find relative stage E poles')
	txt = """SELECT super_gdu_id, represent_gdu_id FROM super_gdu_and_members_id WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}  """
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_2 = conn.cursor()
		for passive_margin_ft_1, passive_margin_1 in final_reconstructed_passive_margin_fts:
			#check whether passive_margin_ft_1 is an infered margin
			is_inferred_tectonic_ft = False
			name_of_ft_1 = passive_margin_ft_1.get_name()
			spilt_string = name_of_ft_1.split("_")
			if (spilt_string[0] == 'inferred'):
				is_inferred_tectonic_ft = True
			left_plate_ID = passive_margin_ft_1.get_left_plate()
			right_plate_ID = passive_margin_ft_1.get_right_plate()
			sql = txt.format(input_member_id = left_plate_ID, input_time = at_age)
			cur.execute(sql)
			row = cur.fetchone()
			SuperGDU_id_1 = -1
			SuperGDU_id_2 = -1
			represent_gdu_id_1 = -1
			represent_gdu_id_2 = -1
			if (row is None):
				print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
				print("Warning cannot find SuperGDU id associated with member GDU id:")
				print(left_plate_ID)
				print("at age")
				print(at_age)
				#exit()
			else:
				SuperGDU_id_1 = row[0]
				represent_gdu_id_1 = row[1]
			sql_2 = txt.format(input_member_id = right_plate_ID, input_time = at_age)
			cur_2.execute(sql_2)
			row_2 = cur_2.fetchone()
			if (row_2 is None):
				print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
				print("Warning cannot find SuperGDU id associated with member GDU id:")
				print(right_plate_ID)
				print("at age")
				print(at_age)
				#exit()
			else:
				SuperGDU_id_2 = row_2[0]
				represent_gdu_id_2 = row_2[1]
			if (row is not None and row_2 is not None):
				key = str(represent_gdu_id_1)+"_"+str(represent_gdu_id_2)
				reverse_key = str(represent_gdu_id_2)+"_"+str(represent_gdu_id_1)
				if (key not in dic and reverse_key not in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone())]
										dic[key] = {'left':[(passive_margin_ft_1.clone(), passive_margin_1.clone())], 'right':[(passive_margin_ft_2.clone(),passive_margin_2.clone())]}
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone())]
										dic[key] = {'left':[(passive_margin_ft_2.clone(), passive_margin_2.clone())], 'right':[(passive_margin_ft_1.clone(),passive_margin_1.clone())]}
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone())]
								dic[key] = {'left':[(passive_margin_ft_1.clone(), passive_margin_1.clone())], 'right':[(closest_ft.clone(),closest_margin.clone())]}
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone())]
								dic[key] = {'left':[(closest_ft.clone(),closest_margin.clone())], 'right':[(passive_margin_ft_1.clone(), passive_margin_1.clone())]}
				elif (key in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										#dic[key]['right'].append((closest_ft.clone(),closest_margin.clone()))
										
										dic[key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										dic[key]['right'].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										#dic[key]['left'].append((closest_ft.clone(),closest_margin.clone()))
										
										dic[key]['left'].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
										dic[key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[key]['right'].append((closest_ft.clone(),closest_margin.clone()))
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[key]['left'].append((closest_ft.clone(),closest_margin.clone()))
				elif (reverse_key in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
								if (passive_margin_ft_1.get_name() == passive_margin_ft_2.get_name()):
									if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										dic[reverse_key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										dic[reverse_key]['right'].append((passive_margin_ft_2.clone(),passive_margin_2.clone()))
									elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										dic[reverse_key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
										dic[reverse_key]['left'].append((passive_margin_ft_2.clone(),passive_margin_2.clone()))
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							if (closest_ft is not None):
								#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[reverse_key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[reverse_key]['right'].append((closest_ft.clone(),closest_margin.clone()))
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							if (closest_ft is not None):
								#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[reverse_key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[reverse_key]['left'].append((closest_ft.clone(),closest_margin.clone()))
	except (psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
	#find small circles for each E pole
	# print('find small circles for each E pole')
	# print('number of pairs of GDUs_id')
	# print(len(dic.keys()))
	for key in dic.keys():
		pairs_GDU_id = key.split('_')
		plate_id_1 = int(pairs_GDU_id[0])
		plate_id_2 = int(pairs_GDU_id[1])
		#find rotation pole from total_relative_reconstruction_rotation (relative between two GDU and from the present-day to at_age)
		total_relative_reconstruction_rotation = find_total_relative_reconstruction_rotation_(rotation_model,plate_id_1,plate_id_2, at_age, reference)
		#find intersection for each pair of divergent continental-oceanic boundaries
		print('number of pairs of margins with key:')
		print(key)
		temp_left_features = dic[key]['left']
		temp_right_features = dic[key]['right']
		print(len(temp_left_features))
		#degbug
		# if (key == '10401_10041' or key == '10041_10401'):
			# for temp_passive_margin_ft_1, temp_passive_margin_1, temp_passive_margin_ft_2, temp_passive_margin_2 in l:
				# temp_gdu_id_1 = temp_passive_margin_ft_1.get_reconstruction_plate_id()
				# temp_gdu_id_2 = temp_passive_margin_ft_2.get_reconstruction_plate_id()
				# if ((temp_gdu_id_1 == 10503 and temp_gdu_id_2 == 10752) or (temp_gdu_id_1 == 10752 and temp_gdu_id_2 == 10503)):
					# is_inferred_tectonic_ft = False
					# name_of_ft_1 = temp_passive_margin_ft_1.get_name()
					# spilt_string = name_of_ft_1.split("_")
					# if (spilt_string[0] == 'inferred'):
						# is_inferred_tectonic_ft = True
					# is_inferred_tectonic_ft = False
					# name_of_ft_2 = temp_passive_margin_ft_2.get_name()
					# spilt_string = name_of_ft_2.split("_")
					# if (spilt_string[0] == 'inferred'):
						# is_inferred_tectonic_ft = True
					# if (is_inferred_tectonic_ft == True):
						# print(temp_gdu_id_1,temp_gdu_id_2)
						# print(temp_passive_margin_ft_1.get_name(), temp_passive_margin_ft_2.get_name())
						# #print(temp_passive_margin_ft_1.get_feature_id().get_string())
						# #print(temp_passive_margin_ft_2.get_feature_id().get_string())
						# exit()
		if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
			list_of_ordered_middle_fts[:] = []
			list_of_ordered_middle_fts_for_left[:] = []
			list_of_ordered_middle_fts_for_right[:] = []
			list_of_ordered_left_fts[:] = []
			list_of_ordered_right_fts[:] = []
			left_features[:] = []
			right_features[:] = []
			#moving_plate_id is plate_id_1 and fixed_plate_id is plate_id_2 - programmer's choice
			E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
			# SuperGDU_centroid_1 = None 
			# SuperGDU_centroid_2 = None
			# for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				# if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1):
					# SuperGDU_centroid_1 = SuperGDU_polygon.get_interior_centroid()
				# elif (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2):
					# SuperGDU_centroid_2 = SuperGDU_polygon.get_interior_centroid()
				# if (SuperGDU_centroid_1 is not None and SuperGDU_centroid_2 is not None):
					# break
			great_circle_arc = None
			mid_point_btwn_centroids = None
			SuperGDU_1 = None 
			SuperGDU_2 = None
			SuperGDU_1_size = 0.00
			SuperGDU_2_size = 0.00
			for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1):
					if (SuperGDU_1_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_1_size):
						SuperGDU_1_size = SuperGDU_polygon.get_area()
						SuperGDU_1 = SuperGDU_polygon
				elif (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2):
					if (SuperGDU_2_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_2_size):
						SuperGDU_2_size = SuperGDU_polygon.get_area()
						SuperGDU_2 = SuperGDU_polygon
			#approx_rad_closest_dist_btw_SuperGDU_1_2, SuperGDU_1_p1, SuperGDU_2_p2 = pygplates.GeometryOnSphere.distance(SuperGDU_1, SuperGDU_2, return_closest_positions=True)
			# if (approx_rad_closest_dist_btw_SuperGDU_1_2 == 0.00):
				# if (SuperGDU_1_p1 == SuperGDU_2_p2):
					# mid_point_btwn_centroids = SuperGDU_1_p1
				# else:
					# mid_point_btwn_centroids = find_the_mid_of_two_PointOnSphere(SuperGDU_1_p1, SuperGDU_2_p2)
			# else:
				# mid_point_btwn_centroids = find_the_mid_of_two_PointOnSphere(SuperGDU_1_p1, SuperGDU_2_p2)
			current_smallest_dist_btwn_l1_l2 = -1.00
			current_l1_p1 = None
			current_l2_p2 = None
			line_features_for_SuperGDU_2[:] = [] 
			line_features_for_SuperGDU_1[:] = []
			for l1_ft,l1 in temp_left_features:
				if (pygplates.GeometryOnSphere.distance(SuperGDU_1,l1) == 0.00):
					line_features_for_SuperGDU_1.append(l1)
				elif (pygplates.GeometryOnSphere.distance(SuperGDU_2,l1) == 0.00):
					line_features_for_SuperGDU_2.append(l1)
			for l2_ft,l2 in temp_left_features:
				if (pygplates.GeometryOnSphere.distance(SuperGDU_1,l2) == 0.00):
					line_features_for_SuperGDU_1.append(l2)
				elif (pygplates.GeometryOnSphere.distance(SuperGDU_2,l2) == 0.00):
					line_features_for_SuperGDU_2.append(l2)
			for l1 in line_features_for_SuperGDU_1:
				for l2 in line_features_for_SuperGDU_2:
					approx_rad_closes_dist, l1_p1, l2_p2 = pygplates.GeometryOnSphere.distance(l1,l2, return_closest_positions=True)
					if (current_smallest_dist_btwn_l1_l2 == -1.00 and approx_rad_closes_dist > 0.00):
						current_smallest_dist_btwn_l1_l2 = approx_rad_closes_dist
						current_l1_p1 = l1_p1
						current_l2_p2 = l2_p2
					elif (current_smallest_dist_btwn_l1_l2 > 0.00 and approx_rad_closes_dist > 0 and approx_rad_closes_dist < current_smallest_dist_btwn_l1_l2 ):
						current_smallest_dist_btwn_l1_l2 = approx_rad_closes_dist
						current_l1_p1 = l1_p1
						current_l2_p2 = l2_p2
			mid_point_btwn_centroids = find_the_mid_of_two_PointOnSphere(current_l1_p1, current_l2_p2)
			great_circle_arc = pygplates.GreatCircleArc(mid_point_btwn_centroids,E_pole)
			normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
			#debug
			# if ((plate_id_1 == 10480 and plate_id_2 == 10802) or (plate_id_2 == 10480 and plate_id_1 == 10802)):
				# if (reference is not None):
					# SuperGDU_1_p1_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,current_l1_p1,valid_time = (at_age,0.00))
					# SuperGDU_1_p1_ft.set_reconstruction_plate_id(reference)
					# SuperGDU_2_p2_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,current_l2_p2,valid_time = (at_age,0.00))
					# SuperGDU_2_p2_ft.set_reconstruction_plate_id(reference)
					# E_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,E_pole,valid_time = (at_age,0.00))
					# E_ft.set_reconstruction_plate_id(reference)
					# mid_point_btwn_centroids_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,mid_point_btwn_centroids,valid_time = (at_age,0.00))
					# mid_point_btwn_centroids_ft.set_reconstruction_plate_id(reference)
					# pygplates.reverse_reconstruct([SuperGDU_1_p1_ft,SuperGDU_2_p2_ft,E_ft,mid_point_btwn_centroids_ft],rotation_model,at_age,reference)
				# else:
					# SuperGDU_1_p1_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,current_l1_p1,valid_time = (at_age,0.00))
					# SuperGDU_1_p1_ft.set_reconstruction_plate_id(reference)
					# SuperGDU_2_p2_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,current_l2_p2,valid_time = (at_age,0.00))
					# SuperGDU_2_p2_ft.set_reconstruction_plate_id(reference)
					# E_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,E_pole,valid_time = (at_age,0.00))
					# E_ft.set_reconstruction_plate_id(reference)
					# mid_point_btwn_centroids_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,mid_point_btwn_centroids,valid_time = (at_age,0.00))
					# mid_point_btwn_centroids_ft.set_reconstruction_plate_id(reference)
					# pygplates.reverse_reconstruct([SuperGDU_1_p1_ft,SuperGDU_2_p2_ft,E_ft,mid_point_btwn_centroids_ft],rotation_model,at_age)
				# temporal_output_FeatureCollection = pygplates.FeatureCollection([SuperGDU_1_p1_ft,SuperGDU_2_p2_ft,E_ft,mid_point_btwn_centroids_ft])
				# temporal_output_FeatureCollection.write("p1_ft,p2_ft,E_ft,mid_point_btwn_ft_at_100Ma_btwn_10480_and_10802_test_2.gpml")
				# exit()
			for l1_ft,l1 in temp_left_features:
				p = l1.get_centroid()
				side = classify_left_or_right(normal_vector_of_great_circle_arc, mid_point_btwn_centroids, p)
				if (side == 'left'):
					left_features.append((l1_ft,l1))
				elif (side == 'right'):
					right_features.append((l1_ft,l1))
			for l2_ft,l2 in temp_right_features:
				p = l2.get_centroid()
				side = classify_left_or_right(normal_vector_of_great_circle_arc, mid_point_btwn_centroids, p)
				if (side == 'left'):
					left_features.append((l2_ft,l2))
				elif (side == 'right'):
					right_features.append((l2_ft,l2))
			# if ((plate_id_1 == 10480 and plate_id_2 == 10802) or (plate_id_2 == 10480 and plate_id_1 == 10802)):
				# print("len(right_features)",len(right_features))
				# print("len(left_features)",len(left_features))
			#small_circle_centre,small_circle_angular_radius_degrees,small_circle_reconstruction_plate_id,small_circle_begin_time,small_circle_end_time
			smallest_circle_angular_radius_degrees = 179.00
			#final_left_plate_id and final_right_plate_id to assign oceanic crust
			final_left_plate_id, final_right_plate_id = -1,-1
			while (smallest_circle_angular_radius_degrees > 0.00):
				#print('value of smallest_circle_angular_radius_degrees')
				#print(smallest_circle_angular_radius_degrees)
				small_circle_ft = None
				small_circle_begin_time = at_age
				small_circle_end_time = 0.00
				if (reference is not None):
					small_circle_ft = rotation_utility.create_small_circle_PolygonOnSphere_feature(E_pole,smallest_circle_angular_radius_degrees,reference,small_circle_begin_time,small_circle_end_time)
				else:
					small_circle_ft = rotation_utility.create_small_circle_PolygonOnSphere_feature(E_pole,smallest_circle_angular_radius_degrees,0,small_circle_begin_time,small_circle_end_time)
				
				#debug
				# if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
					# small_circle_ft.set_description(str(smallest_circle_angular_radius_degrees))
					# small_circle_ft.set_conjugate_plate_id([plate_id_1,plate_id_2])
					# output_small_circle_fts.append(small_circle_ft)
				
				small_circle_geometry = small_circle_ft.get_geometry()
				small_circle_lat_lon_list = small_circle_geometry.to_lat_lon_list()
				small_circle_boundary = pygplates.PolylineOnSphere(small_circle_lat_lon_list)
				small_circle_boundary_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
				#be aware small circle passing through -180 and +180 ---- think about it
				list_of_points_intersecting_left[:] = []
				list_of_points_intersecting_right[:] = []
				for left_passive_margin_ft, left_passive_margin in left_features:
					#passive_margin_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(left_passive_margin)
					valid_age_of_tectonic_ft = left_passive_margin_ft.get_valid_time()
					gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
					#p1 means closest point on line 1 from left_passive_margin
					approx_rad_closes_dist_1, p1, _ = pygplates.GeometryOnSphere.distance(left_passive_margin, small_circle_boundary, return_closest_positions=True)
					if (approx_rad_closes_dist_1 == 0.00):
						list_of_points_intersecting_left.append(p1)
				for right_passive_margin_ft, right_passive_margin in right_features:
					approx_rad_closes_dist_2,p2, _ = pygplates.GeometryOnSphere.distance(right_passive_margin, small_circle_boundary, return_closest_positions=True)
					if (approx_rad_closes_dist_2 == 0.00):
						list_of_points_intersecting_right.append(p2)
				# if ((plate_id_1 == 10480 and plate_id_2 == 10802) or (plate_id_2 == 10480 and plate_id_1 == 10802)):
					# print("len(list_of_points_intersecting_left)",list_of_points_intersecting_left)
					# print("len(list_of_points_intersecting_right)",list_of_points_intersecting_right)
				final_left_point,final_right_point = None,None
				min_distance = -1.00
				for left_point in list_of_points_intersecting_left:
					for right_point in list_of_points_intersecting_right:
						if (left_point != right_point):
							d = pygplates.GeometryOnSphere.distance(left_point, right_point)
							if (min_distance == -1.00):
								min_distance = d
								final_left_point,final_right_point = left_point,right_point
							elif (min_distance >= 0.00 and d < min_distance):
								min_distance = d
								final_left_point,final_right_point = left_point,right_point
				# if ((plate_id_1 == 10480 and plate_id_2 == 10802) or (plate_id_2 == 10480 and plate_id_1 == 10802)):
					# print("final_left_point",final_left_point)
					# print("final_right_point",final_right_point)
				if (final_left_point is not None and final_right_point is not None):
					for left_passive_margin_ft, left_passive_margin in left_features:
						if (pygplates.GeometryOnSphere.distance(left_passive_margin,final_left_point) == 0.00):
							p1 = final_left_point
							gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
							break
					for right_passive_margin_ft, right_passive_margin in right_features:
						if (pygplates.GeometryOnSphere.distance(right_passive_margin,final_right_point) == 0.00):
							p2 = final_right_point
							gdu_id_2 = right_passive_margin_ft.get_reconstruction_plate_id()
							break
					#find mid_point
					mid_point = None
					if (p1 is not None and p2 is not None and gdu_id_1 != gdu_id_2):
						#debug
						# if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
							# print('approx_rad_closes_dist_1 == approx_rad_closes_dist_2 == 0.00')
							# print(gdu_id_1, gdu_id_2)
						mid_point = find_the_mid_of_two_PointOnSphere(p1,p2)
						#have to make sure mid_point is not within the interior of any SuperGDU polygons
						for big_polygon in SuperGDU_polygons:
							if (big_polygon.is_point_in_polygon(mid_point) == True):
								mid_point = None
								break
					if (mid_point is not None):			
						#great circle arc from mid_point to E
						great_circle_arc = pygplates.GreatCircleArc(mid_point,E_pole)
						normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
						left, right = identify_left_gdu_and_right_gdu(normal_vector_of_great_circle_arc, mid_point, p1, p2, gdu_id_1, gdu_id_2)

						#MOR
						print("valid_age_of left_tectonic_ft")
						print(valid_age_of_tectonic_ft)
						description_str = str(left)+"_"+str(right)
						middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, mid_point, name = "rifting/MOR_"+description_str, valid_time = valid_age_of_tectonic_ft)
						middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
						middle_ft.set_description(str(smallest_circle_angular_radius_degrees))
						middle_ft.set_left_plate(left)
						middle_ft.set_right_plate(right)
						
						#debug
						# print("middle_ft")
						# print(middle_ft)
						# print("middle_ft left and middle_ft right")
						# print(middle_ft.get_left_plate(), middle_ft.get_right_plate())
						# print("conjugate plate_id for middle_ft")
						# print(middle_ft.get_conjugate_plate_id())
						# print("plate_id_1, plate_id_2")
						# print(plate_id_1, plate_id_2)
						# exit()
					
						middle_ft_for_left = middle_ft.clone()
						middle_ft_for_left.set_reconstruction_plate_id(left)
						#middle_ft_for_left.set_reconstruction_method('ByPlateId')
						middle_ft_for_right = middle_ft.clone()
						middle_ft_for_right.set_reconstruction_plate_id(right)
						#middle_ft_for_right.set_reconstruction_method('ByPlateId')
						if (reference is None):
							pygplates.reverse_reconstruct([middle_ft,middle_ft_for_left,middle_ft_for_right],rotation_model,at_age)
						else:
							pygplates.reverse_reconstruct([middle_ft,middle_ft_for_left,middle_ft_for_right],rotation_model,at_age,reference)
						list_of_ordered_middle_fts_for_left.append(middle_ft_for_left)
						list_of_ordered_middle_fts_for_right.append(middle_ft_for_right)
						list_of_ordered_middle_fts.append(middle_ft)
						final_list_of_middle_fts.append(middle_ft)
						#final_list_of_middle_polygon_fts.append(middle_ft)
						
						outputPointFeatureCollection.add(middle_ft.clone())
						
						#CON_OCN divergent margins
						left_ft, right_ft = None,None
						if (left == gdu_id_1 and right == gdu_id_2):
							left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p1,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							left_ft.set_reconstruction_plate_id(gdu_id_1)
							right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p2,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							right_ft.set_reconstruction_plate_id(gdu_id_2)
						elif (left == gdu_id_2 and right == gdu_id_1):
							left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p2,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							left_ft.set_reconstruction_plate_id(gdu_id_2)
							right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p1,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
							right_ft.set_reconstruction_plate_id(gdu_id_1)	
						#debug 
						# print("here is left_ft")
						# print(left_ft)
						# print("here is right_ft")
						# print(right_ft)
						if(left_ft is None or right_ft is None):
							print("Error: either left_ft or right_ft is None")
							print("left, right")
							print(left, right)
							print("gdu_id_1, gdu_id_2")
							print(gdu_id_1, gdu_id_2)
							exit()
						if (reference is None):
							pygplates.reverse_reconstruct([left_ft,right_ft],rotation_model,at_age)
						else:
							pygplates.reverse_reconstruct([left_ft,right_ft],rotation_model,at_age,reference)
						list_of_ordered_left_fts.append(left_ft)
						final_list_of_middle_fts.append(left_ft)
						#final_list_of_middle_polygon_fts.append(left_ft)
						list_of_ordered_right_fts.append(right_ft)
						final_list_of_middle_fts.append(right_ft)
						#final_list_of_middle_polygon_fts.append(right_ft)
						
						outputPointFeatureCollection.add(left_ft.clone())
						outputPointFeatureCollection.add(right_ft.clone())
						
						print('len(list_of_ordered_left_fts)')
						print(len(list_of_ordered_left_fts))
						print('len(list_of_ordered_right_fts)')
						print(len(list_of_ordered_right_fts))
				
				smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.000
			
			#connect middle features to create a single topological feature
			topological_line = create_a_topological_line_from_static_point_fts(list_of_ordered_middle_fts)
			topological_feature_type = pygplates.FeatureType.gpml_mid_ocean_ridge
			list_of_topological_fts_for_E_pole = create_list_of_topological_features_from_topological_sections(topological_feature_type, [topological_line])
			for topological_ft in list_of_topological_fts_for_E_pole:
				final_list_of_middle_fts.append(topological_ft)
			
			left_oceanic_crust_fts_at_age = find_reconstructable_left_ceanic_crust_features_formed_at_age(list_of_ordered_left_fts,list_of_ordered_middle_fts,rotation_model,at_age,reference)	
			right_oceanic_crust_fts_at_age = find_reconstructable_right_ceanic_crust_features_formed_at_age(list_of_ordered_right_fts,list_of_ordered_middle_fts,rotation_model,at_age,reference)	
			
			for new_left_oc_crust_ft in left_oceanic_crust_fts_at_age:
				final_list_of_oceanic_crust.append(new_left_oc_crust_ft)
			for new_right_oc_crust_ft in right_oceanic_crust_fts_at_age:
				final_list_of_oceanic_crust.append(new_right_oc_crust_ft)
			
			#create left oceanic topological polygon features - orderd of points is counterclockwise. 
			# divergent_end_age,_ = find_min_max_age_from_middle_fts(list_of_ordered_middle_fts)
			# temporary_reversed_ordered_left_fts = [item for item in reversed(list_of_ordered_left_fts)]
			# list_of_points_for_left_oceanic_crust = list_of_ordered_middle_fts + temporary_reversed_ordered_left_fts
			# left_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_left_oceanic_crust)
			# print('Here is left_topological_polygon')
			# print(left_topological_polygon)
			# topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
			# left_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, left_topological_polygon)
			# print('Here is left_topological_polygon_feature')
			# print(left_topological_polygon_feature)
			# final_list_of_middle_polygon_fts.append(left_topological_polygon_feature)

			# temporary_reversed_ordered_middle_fts = [item for item in reversed(list_of_ordered_middle_fts)]
			# list_of_points_for_right_oceanic_crust = list_of_ordered_right_fts + temporary_reversed_ordered_middle_fts
			# right_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_right_oceanic_crust)
			# print('Here is right_topological_polygon')
			# print(right_topological_polygon)
			# topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
			# right_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, right_topological_polygon)
			# print('Here is right_topological_polygon_feature')
			# print(right_topological_polygon_feature)
			# final_list_of_middle_polygon_fts.append(right_topological_polygon_feature)


				
	if (write_output == True):
		outputFile = "new_rifts_and_associated_margins_points_fts_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".shp"
		outputPointFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_middle_fts)
		outputFile = "topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_middle_polygon_fts)
		# outputFile = "topological_middle_polygon_fts_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		# outputFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_oceanic_crust)
		outputFile = "oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_surface_oceanic_crust)
		# outputFile = "surface_oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		# outputFeatureCollection.write(outputFile)
	# outputFeatureCollection = pygplates.FeatureCollection(output_small_circle_fts)
	# outputFile = "output_small_circle_fts_10439_10480_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".shp"
	# outputFeatureCollection.write(outputFile)
	
	#return final_list_of_middle_fts,final_list_of_oceanic_crust,final_list_of_surface_oceanic_crust
	#return final_list_of_middle_fts,final_list_of_oceanic_crust,final_list_of_middle_polygon_fts
	return final_list_of_middle_fts,final_list_of_oceanic_crust
	
def find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2(list_of_passive_margin_fts, SuperGDU_features, at_age, interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output):
	"""
	Find and connect locations where rifts/MOR ocurrs at age 
		list_of_passive_margin_fts: a list or a list-like structure that contains CON_OCN margin features which were previously identified from first approximated tectonic motion evaluation
		at_age: interpreted in Ma - float
		rotation_model: pygplates.RotationModel from .rot or grot file
		reference: None or any other value to be used as the reference_frame for the plate tectonic reconstruction
		test_number: int to keep track for testing the module
		modelname: str name of the plate tectonic model that we evaluate
		yyyymmdd: str year - month - day 
	Return:
		a list of: 
			locations of rifts/MOR
			topological line features connecting rifts/MOR locations
	"""

	dic = {}
	reconstructed_passive_margin_features = []
	output_small_circle_fts = []
	passive_margin_fts = [ft for ft in list_of_passive_margin_fts if ft.is_valid_at_time(at_age)]
	final_fts = []
	left_features = []
	right_features = []
	list_of_ordered_middle_fts = []
	final_list_of_middle_fts = []
	final_list_of_middle_polygon_fts = []
	final_list_of_oceanic_crust = []
	final_list_of_surface_oceanic_crust = []
	estimated_final_list_of_oceanic_crust = []
	estimated_final_list_of_surface_oceanic_crust = []	  
	list_of_ordered_left_fts = []
	final_list_of_left_fts = []
	list_of_ordered_right_fts = []
	final_list_of_right_fts = []
	list_of_ordered_middle_fts_for_left = []
	list_of_ordered_middle_fts_for_right = []
	list_of_valid_SuperGDU_fts = [SuperGDU_ft for SuperGDU_ft in SuperGDU_features if SuperGDU_ft.is_valid_at_time(at_age)]
	reconstructed_SuperGDU_fts = []
	SuperGDU_polygons = [] 
	temp_list_of_left_features = []
	temp_list_of_right_features = []
	list_of_points_intersecting_left = []
	list_of_points_intersecting_right = [] 
	line_features_for_SuperGDU_2 = [] 
	line_features_for_SuperGDU_1 = []
	outputPointFeatureCollection = pygplates.FeatureCollection()
	
	if (reference is not None):
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,anchor_plate_id = reference, group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,anchor_plate_id = reference, group_with_feature = True)
	else:
		pygplates.reconstruct(passive_margin_fts,rotation_model,reconstructed_passive_margin_features,at_age,group_with_feature = True)
		pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_SuperGDU_fts,at_age,group_with_feature = True)
	final_reconstructed_passive_margin_fts = supporting.find_final_reconstructed_geometries(reconstructed_passive_margin_features,pygplates.PolylineOnSphere)
	final_reconstructed_SuperGDU_fts = supporting.find_final_reconstructed_geometries(reconstructed_SuperGDU_fts, pygplates.PolygonOnSphere)
	SuperGDU_polygons[:] = []
	for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
		SuperGDU_polygons.append(SuperGDU_polygon.clone())

	print('find pairs of GDUs_id and associated divergent continental-oceanic divergent margins to find relative stage E poles')
	txt = """SELECT super_gdu_id, represent_gdu_id FROM super_gdu_and_members_id WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}"""
	txt_3 = """SELECT DISTINCT represent_gdu_id,super_gdu_id FROM temp_final_super_gdu_id_2
					WHERE from_time > {input_time} and to_time <= {input_time} AND represent_gdu_id in 
						(SELECT DISTINCT gdu_id_member from super_gdu_and_members_id 
							WHERE super_gdu_id in
								(SELECT DISTINCT super_gdu_id FROM super_gdu_and_members_id 
										WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time}))"""
	conn = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_2 = conn.cursor()
		for passive_margin_ft_1, passive_margin_1 in final_reconstructed_passive_margin_fts:
			#check whether passive_margin_ft_1 is an infered margin
			is_inferred_tectonic_ft = False
			name_of_ft_1 = passive_margin_ft_1.get_name()
			spilt_string = name_of_ft_1.split("_")
			if (spilt_string[0] == 'inferred'):
				is_inferred_tectonic_ft = True
			left_plate_ID = passive_margin_ft_1.get_left_plate()
			right_plate_ID = passive_margin_ft_1.get_right_plate()
			sql = txt.format(input_member_id = left_plate_ID, input_time = at_age)
			cur.execute(sql)
			row = cur.fetchone()
			SuperGDU_id_1 = -1
			SuperGDU_id_2 = -1
			represent_gdu_id_1 = -1
			represent_gdu_id_2 = -1
			if (row is None):
				print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
				print("Warning cannot find SuperGDU id associated with member GDU id:")
				print(left_plate_ID)
				print("at age")
				print(at_age)
				#exit()
			else:
				SuperGDU_id_1 = row[0]
				represent_gdu_id_1 = row[1]
			sql_2 = txt.format(input_member_id = right_plate_ID, input_time = at_age)
			cur_2.execute(sql_2)
			row_2 = cur_2.fetchone()
			if (row_2 is None):
				print("Warning in find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features")
				print("Warning cannot find SuperGDU id associated with member GDU id:")
				print(right_plate_ID)
				print("at age")
				print(at_age)
				#exit()
			else:
				SuperGDU_id_2 = row_2[0]
				represent_gdu_id_2 = row_2[1]
			if (row is not None and row_2 is not None):
				key = str(represent_gdu_id_1)+"_"+str(represent_gdu_id_2)
				reverse_key = str(represent_gdu_id_2)+"_"+str(represent_gdu_id_1)
				if (key not in dic and reverse_key not in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
								if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
									#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone())]
									dic[key] = {'left':[(passive_margin_ft_1.clone(), passive_margin_1.clone())], 'right':[(passive_margin_ft_2.clone(),passive_margin_2.clone())]}
								elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
									#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone())]
									dic[key] = {'left':[(passive_margin_ft_2.clone(), passive_margin_2.clone())], 'right':[(passive_margin_ft_1.clone(),passive_margin_1.clone())]}
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone())]
								dic[key] = {'left':[(passive_margin_ft_1.clone(), passive_margin_1.clone())], 'right':[(closest_ft.clone(),closest_margin.clone())]}
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key] = [(passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone())]
								dic[key] = {'left':[(closest_ft.clone(),closest_margin.clone())], 'right':[(passive_margin_ft_1.clone(), passive_margin_1.clone())]}
				elif (key in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
								if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
										#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
										#dic[key]['right'].append((closest_ft.clone(),closest_margin.clone()))
										
									dic[key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
									dic[key]['right'].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
								elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
									#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
									#dic[key]['left'].append((closest_ft.clone(),closest_margin.clone()))
									
									dic[key]['left'].append((passive_margin_ft_2.clone(), passive_margin_2.clone()))
									dic[key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[key]['right'].append((closest_ft.clone(),closest_margin.clone()))
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_reconstruction_plate_id()')
							print(passive_margin_ft_1.get_reconstruction_plate_id())
							print('passive_margin_ft_1.get_name()')
							print(passive_margin_ft_1.get_name())
							print('passive_margin_ft_1.get_left_plate()')
							print(passive_margin_ft_1.get_left_plate())
							print('passive_margin_ft_1.get_right_plate()')
							print(passive_margin_ft_1.get_right_plate())
							if (closest_ft is not None):
								#dic[key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[key]['left'].append((closest_ft.clone(),closest_margin.clone()))
				elif (reverse_key in dic):
					if (is_inferred_tectonic_ft == False):
						for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
							if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
								if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_right_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
									#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
									dic[reverse_key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
									dic[reverse_key]['right'].append((passive_margin_ft_2.clone(),passive_margin_2.clone()))
								elif (passive_margin_ft_1.get_right_plate() == passive_margin_ft_1.get_reconstruction_plate_id() and passive_margin_ft_1.get_left_plate() == passive_margin_ft_2.get_reconstruction_plate_id()):
									#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),passive_margin_ft_2.clone(),passive_margin_2.clone()))
									dic[reverse_key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
									dic[reverse_key]['left'].append((passive_margin_ft_2.clone(),passive_margin_2.clone()))
					else:
						if (passive_margin_ft_1.get_left_plate() == passive_margin_ft_1.get_reconstruction_plate_id()):
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_right_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							if (closest_ft is not None):
								#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[reverse_key]['left'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[reverse_key]['right'].append((closest_ft.clone(),closest_margin.clone()))
						else:
							closest_ft = None
							closest_distance = -1.00
							closest_margin = None
							for passive_margin_ft_2, passive_margin_2 in final_reconstructed_passive_margin_fts:
								if (passive_margin_ft_1.get_feature_id() != passive_margin_ft_2.get_feature_id() and passive_margin_ft_1.get_name() != passive_margin_ft_2.get_name()):
									if (passive_margin_ft_2.get_reconstruction_plate_id() == passive_margin_ft_1.get_left_plate()):
										distance = pygplates.GeometryOnSphere.distance(passive_margin_1,passive_margin_2)
										if (closest_ft is None):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
										elif (closest_distance > -1.00 and closest_distance > distance):
											closest_distance = distance
											closest_ft = passive_margin_ft_2
											closest_margin = passive_margin_2
							if (closest_ft is not None):
								#dic[reverse_key].append((passive_margin_ft_1.clone(), passive_margin_1.clone(),closest_ft.clone(),closest_margin.clone()))
								dic[reverse_key]['right'].append((passive_margin_ft_1.clone(), passive_margin_1.clone()))
								dic[reverse_key]['left'].append((closest_ft.clone(),closest_margin.clone()))
	except (psycopg2.DatabaseError) as error:
		print (error)
	finally:
		if (conn is not None):
			conn.close()
	#find small circles for each E pole
	# print('find small circles for each E pole')
	print('number of pairs of GDUs_id')
	print(len(dic.keys()))
	#debug
	# for k in dic.keys():
		# print("key",k)
		# print(len(dic[k]['left']))
		# print(len(dic[k]['right']))
	# exit()
	
	conn = None
	cur_3 = None
	try:
		#read the connection parameters
		params = config()
		#connect to the PostgreSQL server
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_3 = conn.cursor()
	except (psycopg2.DatabaseError) as error:
		print (error)
		exit()
	for key in dic.keys():
		pairs_GDU_id = key.split('_')
		plate_id_1 = int(pairs_GDU_id[0])
		plate_id_2 = int(pairs_GDU_id[1])
		
		SuperGDU_1 = None 
		SuperGDU_2 = None
		SuperGDU_1_size = 0.00
		SuperGDU_2_size = 0.00
		for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
			if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1):
				if (SuperGDU_1_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_1_size):
					SuperGDU_1_size = SuperGDU_polygon.get_area()
					SuperGDU_1 = SuperGDU_polygon
			elif (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2):
				if (SuperGDU_2_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_2_size):
					SuperGDU_2_size = SuperGDU_polygon.get_area()
					SuperGDU_2 = SuperGDU_polygon
		if (SuperGDU_1 is None):
			sql_3 = txt_3.format(input_member_id = plate_id_1 , input_time = at_age)
			cur_3.execute(sql_3)
			row_3 = cur_3.fetchone()
			if (row_3 is None):
				print('Error find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2')
				print('sql_3')
				print(sql_3)
				exit()
			plate_id_1 = int(row_3[0])
			SuperGDU_1_name = row_3[1]
			SuperGDU_1 = None 
			SuperGDU_1_size = 0.00
			for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1 or int(SuperGDU_ft.get_name()) == SuperGDU_1_name):
					if (SuperGDU_1_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_1_size):
						SuperGDU_1_size = SuperGDU_polygon.get_area()
						SuperGDU_1 = SuperGDU_polygon
		if (SuperGDU_1 is None):
			print("Error SuperGDU_1 is None")
			print("plate_id_1,SuperGDU_1_name", plate_id_1, SuperGDU_1_name)
			for ft in SuperGDU_features:
				if (ft.get_reconstruction_plate_id() == plate_id_1 or int(SuperGDU_ft.get_name()) == SuperGDU_1_name):
					print(ft.get_reconstruction_plate_id())
					print(ft.get_name())
					print(ft.get_valid_time())
			exit()
		if (SuperGDU_2 is None):
			sql_3 = txt_3.format(input_member_id = plate_id_2 , input_time = at_age)
			cur_3.execute(sql_3)
			row_3 = cur_3.fetchone()
			if (row_3 is None):
				print('Error find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2')
				print('sql_3')
				print(sql_3)
				exit()
			plate_id_2 = int(row_3[0])
			SuperGDU_2 = None 
			SuperGDU_2_size = 0.00
			SuperGDU_2_name = row_3[1]
			for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2 or int(SuperGDU_ft.get_name()) == SuperGDU_2_name):
					if (SuperGDU_2_size == 0.00 or SuperGDU_polygon.get_area() > SuperGDU_2_size):
						SuperGDU_2_size = SuperGDU_polygon.get_area()
						SuperGDU_2 = SuperGDU_polygon
		if (SuperGDU_2 is None):
			print("Error SuperGDU_2 is None")
			print("plate_id_2,SuperGDU_2_name", plate_id_2, SuperGDU_2_name)
			for ft in SuperGDU_features:
				if (ft.get_reconstruction_plate_id() == plate_id_2 or int(SuperGDU_ft.get_name()) == SuperGDU_2_name):
					print(ft.get_reconstruction_plate_id())
					print(ft.get_name())
					print(ft.get_valid_time())
			exit()
		#find rotation pole from total_relative_reconstruction_rotation (relative between two GDU and from the present-day to at_age)
		#total_relative_reconstruction_rotation = find_total_relative_reconstruction_rotation_(rotation_model,plate_id_1,plate_id_2, at_age, reference)
		stage_relative_reconstruction_rotation = find_stage_relative_reconstruction_rotation_(rotation_model,plate_id_1,plate_id_2, at_age, interval)
		#print ('stage_relative_reconstruction_rotation',stage_relative_reconstruction_rotation)
		#find intersection for each pair of divergent continental-oceanic boundaries
		print('key:',key)
		temp_left_features = dic[key]['left']
		temp_right_features = dic[key]['right']
		#print('number of temp_left_features:',len(temp_left_features))
		#print('number of temp_right_features:',len(temp_right_features))
		#temp_left_features = dic[key]['left']
		#temp_right_features = dic[key]['right']
		#degbug
		# if (key == '10401_10041' or key == '10041_10401'):
			# for temp_passive_margin_ft_1, temp_passive_margin_1, temp_passive_margin_ft_2, temp_passive_margin_2 in l:
				# temp_gdu_id_1 = temp_passive_margin_ft_1.get_reconstruction_plate_id()
				# temp_gdu_id_2 = temp_passive_margin_ft_2.get_reconstruction_plate_id()
				# if ((temp_gdu_id_1 == 10503 and temp_gdu_id_2 == 10752) or (temp_gdu_id_1 == 10752 and temp_gdu_id_2 == 10503)):
					# is_inferred_tectonic_ft = False
					# name_of_ft_1 = temp_passive_margin_ft_1.get_name()
					# spilt_string = name_of_ft_1.split("_")
					# if (spilt_string[0] == 'inferred'):
						# is_inferred_tectonic_ft = True
					# is_inferred_tectonic_ft = False
					# name_of_ft_2 = temp_passive_margin_ft_2.get_name()
					# spilt_string = name_of_ft_2.split("_")
					# if (spilt_string[0] == 'inferred'):
						# is_inferred_tectonic_ft = True
					# if (is_inferred_tectonic_ft == True):
						# print(temp_gdu_id_1,temp_gdu_id_2)
						# print(temp_passive_margin_ft_1.get_name(), temp_passive_margin_ft_2.get_name())
						# #print(temp_passive_margin_ft_1.get_feature_id().get_string())
						# #print(temp_passive_margin_ft_2.get_feature_id().get_string())
						# exit()
		if (stage_relative_reconstruction_rotation.represents_identity_rotation() == False and len(temp_left_features) > 1 and len(temp_right_features) > 1):
		#if (total_relative_reconstruction_rotation.represents_identity_rotation() == False and len(temp_left_features) > 1 and len(temp_right_features) > 1):
			list_of_ordered_middle_fts[:] = []
			list_of_ordered_middle_fts_for_left[:] = []
			list_of_ordered_middle_fts_for_right[:] = []
			list_of_ordered_left_fts[:] = []
			list_of_ordered_right_fts[:] = []
			left_features[:] = []
			right_features[:] = []
			#moving_plate_id is plate_id_1 and fixed_plate_id is plate_id_2 - programmer's choice
			E_pole,angle_rads = stage_relative_reconstruction_rotation.get_euler_pole_and_angle()
			#E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
			# SuperGDU_centroid_1 = None 
			# SuperGDU_centroid_2 = None
			# for SuperGDU_ft,SuperGDU_polygon in final_reconstructed_SuperGDU_fts:
				# if (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_1):
					# SuperGDU_centroid_1 = SuperGDU_polygon.get_interior_centroid()
				# elif (SuperGDU_ft.get_reconstruction_plate_id() == plate_id_2):
					# SuperGDU_centroid_2 = SuperGDU_polygon.get_interior_centroid()
				# if (SuperGDU_centroid_1 is not None and SuperGDU_centroid_2 is not None):
					# break
			great_circle_arc = None
			mid_point_btwn_centroids = None
			#approx_rad_closest_dist_btw_SuperGDU_1_2, SuperGDU_1_p1, SuperGDU_2_p2 = pygplates.GeometryOnSphere.distance(SuperGDU_1, SuperGDU_2, return_closest_positions=True)
			# if (approx_rad_closest_dist_btw_SuperGDU_1_2 == 0.00):
				# if (SuperGDU_1_p1 == SuperGDU_2_p2):
					# mid_point_btwn_centroids = SuperGDU_1_p1
				# else:
					# mid_point_btwn_centroids = find_the_mid_of_two_PointOnSphere(SuperGDU_1_p1, SuperGDU_2_p2)
			# else:
				# mid_point_btwn_centroids = find_the_mid_of_two_PointOnSphere(SuperGDU_1_p1, SuperGDU_2_p2)
			#current_smallest_dist_btwn_l1_l2 = -1.00
			current_l1_p1 = None
			current_l2_p2 = None
			line_features_for_SuperGDU_2[:] = [] 
			line_features_for_SuperGDU_1[:] = []
			for l1_ft,l1 in temp_left_features:
				if (pygplates.GeometryOnSphere.distance(SuperGDU_1,l1) == 0.00):
					line_features_for_SuperGDU_1.append((l1_ft,l1))
				elif (pygplates.GeometryOnSphere.distance(SuperGDU_2,l1) == 0.00):
					line_features_for_SuperGDU_2.append((l1_ft,l1))
			for l2_ft,l2 in temp_right_features:
				if (pygplates.GeometryOnSphere.distance(SuperGDU_1,l2) == 0.00):
					line_features_for_SuperGDU_1.append((l2_ft,l2))
				elif (pygplates.GeometryOnSphere.distance(SuperGDU_2,l2) == 0.00):
					line_features_for_SuperGDU_2.append((l2_ft,l2))
			# for l2_ft,l2 in temp_left_features:
				# if (pygplates.GeometryOnSphere.distance(SuperGDU_1,l2) == 0.00):
					# line_features_for_SuperGDU_1.append(l2)
				# elif (pygplates.GeometryOnSphere.distance(SuperGDU_2,l2) == 0.00):
					# line_features_for_SuperGDU_2.append(l2)
			# for l2_ft,l2 in temp_right_features:
				# if (pygplates.GeometryOnSphere.distance(SuperGDU_1,l2) == 0.00):
					# line_features_for_SuperGDU_1.append(l2)
				# elif (pygplates.GeometryOnSphere.distance(SuperGDU_2,l2) == 0.00):
					# line_features_for_SuperGDU_2.append(l2)
			if (len(line_features_for_SuperGDU_1) == 0):
				all_SuperGDU_1 = [temp_SuperGDU_polyon for temp_SuperGDU_polyon_ft, temp_SuperGDU_polyon in final_reconstructed_SuperGDU_fts if (temp_SuperGDU_polyon_ft.get_reconstruction_plate_id() == plate_id_1 or temp_SuperGDU_polyon_ft.get_name() == SuperGDU_1_name)]
				for l1_ft,l1 in temp_left_features:
					for temp_SuperGDU_1 in all_SuperGDU_1:
						if (pygplates.GeometryOnSphere.distance(temp_SuperGDU_1,l1) == 0.00):
							line_features_for_SuperGDU_1.append((l1_ft,l1))
							break
				for l2_ft,l2 in temp_right_features:
					for temp_SuperGDU_1 in all_SuperGDU_1:
						if (pygplates.GeometryOnSphere.distance(temp_SuperGDU_1,l2) == 0.00):
							line_features_for_SuperGDU_1.append((l2_ft,l2))
							break
			if (len(line_features_for_SuperGDU_2) == 0):
				all_SuperGDU_2 = [temp_SuperGDU_polyon for temp_SuperGDU_polyon_ft, temp_SuperGDU_polyon in final_reconstructed_SuperGDU_fts if (temp_SuperGDU_polyon_ft.get_reconstruction_plate_id() == plate_id_2 or temp_SuperGDU_polyon_ft.get_name() == SuperGDU_2_name)]
				for l1_ft,l1 in temp_left_features:
					for temp_SuperGDU_2 in all_SuperGDU_2:
						if (pygplates.GeometryOnSphere.distance(temp_SuperGDU_2,l1) == 0.00):
							line_features_for_SuperGDU_2.append((l1_ft,l1))
							break
				for l2_ft,l2 in temp_right_features:
					for temp_SuperGDU_2 in all_SuperGDU_2:
						if (pygplates.GeometryOnSphere.distance(temp_SuperGDU_2,l2) == 0.00):
							line_features_for_SuperGDU_2.append((l2_ft,l2))
							break
			#print('len(line_features_for_SuperGDU_1)',len(line_features_for_SuperGDU_1))
			#print('len(line_features_for_SuperGDU_2)',len(line_features_for_SuperGDU_2))
			if (len(line_features_for_SuperGDU_1) > 1 and len(line_features_for_SuperGDU_2) > 1):
				# for l1_ft,l1 in line_features_for_SuperGDU_1:
					# current_smallest_dist_btwn_l1_l2 = -1.00
					# final_l2_ft,final_l2 = None, None
					# for l2_ft,l2 in line_features_for_SuperGDU_2:
						# approx_rad_closes_dist, l1_p1, l2_p2 = pygplates.GeometryOnSphere.distance(l1,l2, return_closest_positions=True)
						# if (current_smallest_dist_btwn_l1_l2 == -1.00 and approx_rad_closes_dist >= 0.00):
							# current_smallest_dist_btwn_l1_l2 = approx_rad_closes_dist
							# current_l1_p1 = l1_p1
							# current_l2_p2 = l2_p2
							# final_l2_ft = l2_ft
							# final_l2 = l2
						# elif (current_smallest_dist_btwn_l1_l2 > 0.00 and approx_rad_closes_dist >= 0 and approx_rad_closes_dist < current_smallest_dist_btwn_l1_l2 ):
							# current_smallest_dist_btwn_l1_l2 = approx_rad_closes_dist
							# current_l1_p1 = l1_p1
							# current_l2_p2 = l2_p2
							# final_l2_ft = l2_ft
							# final_l2 = l2
					# mid_point_btwn_centroids = find_the_mid_of_two_PointOnSphere(current_l1_p1, current_l2_p2)
					# great_circle_arc = pygplates.GreatCircleArc(mid_point_btwn_centroids,E_pole)
					# normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
					
					# side = classify_left_or_right(normal_vector_of_great_circle_arc, mid_point_btwn_centroids, current_l1_p1)
					# if (side == 'left'):
						# left_features.append((l1_ft,l1))
					# elif (side == 'right'):
						# right_features.append((l1_ft,l1))
					
					# side = classify_left_or_right(normal_vector_of_great_circle_arc, mid_point_btwn_centroids, current_l2_p2)
					# if (side == 'left'):
						# left_features.append((final_l2_ft,final_l2))
					# elif (side == 'right'):
						# right_features.append((final_l2_ft,final_l2))
				#debug
				# if ((plate_id_1 == 10480 and plate_id_2 == 10802) or (plate_id_2 == 10480 and plate_id_1 == 10802)):
					# if (reference is not None):
						# SuperGDU_1_p1_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,current_l1_p1,valid_time = (at_age,0.00))
						# SuperGDU_1_p1_ft.set_reconstruction_plate_id(reference)
						# SuperGDU_2_p2_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,current_l2_p2,valid_time = (at_age,0.00))
						# SuperGDU_2_p2_ft.set_reconstruction_plate_id(reference)
						# E_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,E_pole,valid_time = (at_age,0.00))
						# E_ft.set_reconstruction_plate_id(reference)
						# mid_point_btwn_centroids_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,mid_point_btwn_centroids,valid_time = (at_age,0.00))
						# mid_point_btwn_centroids_ft.set_reconstruction_plate_id(reference)
						# pygplates.reverse_reconstruct([SuperGDU_1_p1_ft,SuperGDU_2_p2_ft,E_ft,mid_point_btwn_centroids_ft],rotation_model,at_age,reference)
					# else:
						# SuperGDU_1_p1_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,current_l1_p1,valid_time = (at_age,0.00))
						# SuperGDU_1_p1_ft.set_reconstruction_plate_id(reference)
						# SuperGDU_2_p2_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,current_l2_p2,valid_time = (at_age,0.00))
						# SuperGDU_2_p2_ft.set_reconstruction_plate_id(reference)
						# E_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,E_pole,valid_time = (at_age,0.00))
						# E_ft.set_reconstruction_plate_id(reference)
						# mid_point_btwn_centroids_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,mid_point_btwn_centroids,valid_time = (at_age,0.00))
						# mid_point_btwn_centroids_ft.set_reconstruction_plate_id(reference)
						# pygplates.reverse_reconstruct([SuperGDU_1_p1_ft,SuperGDU_2_p2_ft,E_ft,mid_point_btwn_centroids_ft],rotation_model,at_age)
					# temporal_output_FeatureCollection = pygplates.FeatureCollection([SuperGDU_1_p1_ft,SuperGDU_2_p2_ft,E_ft,mid_point_btwn_centroids_ft])
					# temporal_output_FeatureCollection.write("p1_ft,p2_ft,E_ft,mid_point_btwn_ft_at_100Ma_btwn_10480_and_10802_test_2.gpml")
					# exit()
				# for l1_ft,l1 in temp_left_features:
					# p = l1.get_centroid()
					# side = classify_left_or_right(normal_vector_of_great_circle_arc, mid_point_btwn_centroids, p)
					# if (side == 'left'):
						# left_features.append((l1_ft,l1))
					# elif (side == 'right'):
						# right_features.append((l1_ft,l1))
				# for l2_ft,l2 in temp_right_features:
					# p = l2.get_centroid()
					# side = classify_left_or_right(normal_vector_of_great_circle_arc, mid_point_btwn_centroids, p)
					# if (side == 'left'):
						# left_features.append((l2_ft,l2))
					# elif (side == 'right'):
						# right_features.append((l2_ft,l2))
				# if ((plate_id_1 == 10480 and plate_id_2 == 10802) or (plate_id_2 == 10480 and plate_id_1 == 10802)):
					# print("len(right_features)",len(right_features))
					# print("len(left_features)",len(left_features))
				#small_circle_centre,small_circle_angular_radius_degrees,small_circle_reconstruction_plate_id,small_circle_begin_time,small_circle_end_time
				smallest_circle_angular_radius_degrees = 179.00
				#final_left_plate_id and final_right_plate_id to assign oceanic crust
				final_left_plate_id, final_right_plate_id = -1,-1
				while (smallest_circle_angular_radius_degrees > 0.00):
					#print('value of smallest_circle_angular_radius_degrees')
					#print(smallest_circle_angular_radius_degrees)
					small_circle_ft = None
					small_circle_begin_time = at_age
					small_circle_end_time = 0.00
					if (reference is not None):
						small_circle_ft = rotation_utility.create_small_circle_PolygonOnSphere_feature(E_pole,smallest_circle_angular_radius_degrees,reference,small_circle_begin_time,small_circle_end_time)
					else:
						small_circle_ft = rotation_utility.create_small_circle_PolygonOnSphere_feature(E_pole,smallest_circle_angular_radius_degrees,0,small_circle_begin_time,small_circle_end_time)
				
					#debug
					# if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
						# small_circle_ft.set_description(str(smallest_circle_angular_radius_degrees))
						# small_circle_ft.set_conjugate_plate_id([plate_id_1,plate_id_2])
						# output_small_circle_fts.append(small_circle_ft)
				
					small_circle_geometry = small_circle_ft.get_geometry()
					small_circle_lat_lon_list = small_circle_geometry.to_lat_lon_list()
					small_circle_boundary = pygplates.PolylineOnSphere(small_circle_lat_lon_list)
					small_circle_boundary_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(small_circle_boundary)
					#be aware small circle passing through -180 and +180 ---- think about it
					list_of_points_intersecting_left[:] = []
					list_of_points_intersecting_right[:] = []
					# for left_passive_margin_ft, left_passive_margin in left_features:
						# #passive_margin_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(left_passive_margin)
						# valid_age_of_tectonic_ft = left_passive_margin_ft.get_valid_time()
						# gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
						# #p1 means closest point on line 1 from left_passive_margin
						# approx_rad_closes_dist_1, p1, _ = pygplates.GeometryOnSphere.distance(left_passive_margin, small_circle_boundary, return_closest_positions=True)
						# if (approx_rad_closes_dist_1 == 0.00):
							# list_of_points_intersecting_left.append(p1)
					# for right_passive_margin_ft, right_passive_margin in right_features:
						# approx_rad_closes_dist_2,p2, _ = pygplates.GeometryOnSphere.distance(right_passive_margin, small_circle_boundary, return_closest_positions=True)
						# if (approx_rad_closes_dist_2 == 0.00):
							# list_of_points_intersecting_right.append(p2)
							
					for left_passive_margin_ft, left_passive_margin in line_features_for_SuperGDU_1:
						#passive_margin_1_in_Shapely = supporting.convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(left_passive_margin)
						valid_age_of_tectonic_ft = left_passive_margin_ft.get_valid_time()
						gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
						#p1 means closest point on line 1 from left_passive_margin
						approx_rad_closes_dist_1, p1, _ = pygplates.GeometryOnSphere.distance(left_passive_margin, small_circle_boundary, return_closest_positions=True)
						if (approx_rad_closes_dist_1 == 0.00):
							list_of_points_intersecting_left.append(p1)
					for right_passive_margin_ft, right_passive_margin in line_features_for_SuperGDU_2:
						approx_rad_closes_dist_2,p2, _ = pygplates.GeometryOnSphere.distance(right_passive_margin, small_circle_boundary, return_closest_positions=True)
						if (approx_rad_closes_dist_2 == 0.00):
							list_of_points_intersecting_right.append(p2)
					
					
					# if ((plate_id_1 == 10480 and plate_id_2 == 10802) or (plate_id_2 == 10480 and plate_id_1 == 10802)):
						# print("len(list_of_points_intersecting_left)",list_of_points_intersecting_left)
						# print("len(list_of_points_intersecting_right)",list_of_points_intersecting_right)
					#print('len(list_of_points_intersecting_left)',len(list_of_points_intersecting_left))
					#print('len(list_of_points_intersecting_right)',len(list_of_points_intersecting_right))
					final_left_point,final_right_point = None,None
					min_distance = -1.00
					for left_point in list_of_points_intersecting_left:
						for right_point in list_of_points_intersecting_right:
							if (left_point != right_point):
								d = pygplates.GeometryOnSphere.distance(left_point, right_point)
								if (min_distance == -1.00):
									min_distance = d
									final_left_point,final_right_point = left_point,right_point
								elif (min_distance >= 0.00 and d < min_distance):
									min_distance = d
									final_left_point,final_right_point = left_point,right_point
					# if ((plate_id_1 == 10480 and plate_id_2 == 10802) or (plate_id_2 == 10480 and plate_id_1 == 10802)):
						# print("final_left_point",final_left_point)
						# print("final_right_point",final_right_point)
					if (final_left_point is not None and final_right_point is not None):
						gdu_id_1 = -1
						gdu_id_2 = -1
						#for left_passive_margin_ft, left_passive_margin in left_features:
						for left_passive_margin_ft, left_passive_margin in line_features_for_SuperGDU_1:
							if (pygplates.GeometryOnSphere.distance(left_passive_margin,final_left_point) == 0.00):
								p1 = final_left_point
								gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
								break
							elif (pygplates.GeometryOnSphere.distance(left_passive_margin,final_right_point) == 0.00):
								p2 = final_right_point
								gdu_id_2 = left_passive_margin_ft.get_reconstruction_plate_id()
								break
						if (p1 is not None and p2 is None):
							for left_passive_margin_ft, left_passive_margin in line_features_for_SuperGDU_2:
								if (pygplates.GeometryOnSphere.distance(left_passive_margin,final_right_point) == 0.00):
									p2 = final_right_point
									gdu_id_2 = left_passive_margin_ft.get_reconstruction_plate_id()
									break
						elif (p1 is None and p2 is not None):
							for left_passive_margin_ft, left_passive_margin in line_features_for_SuperGDU_2:
								if (pygplates.GeometryOnSphere.distance(left_passive_margin,final_left_point) == 0.00):
									p1 = final_left_point
									gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
									break
						#for left_passive_margin_ft, left_passive_margin in left_features:
							# if (pygplates.GeometryOnSphere.distance(left_passive_margin,final_left_point) == 0.00):
								# p1 = final_left_point
								# gdu_id_1 = left_passive_margin_ft.get_reconstruction_plate_id()
								# break
						# for right_passive_margin_ft, right_passive_margin in right_features:
							# if (pygplates.GeometryOnSphere.distance(right_passive_margin,final_right_point) == 0.00):
								# p2 = final_right_point
								# gdu_id_2 = right_passive_margin_ft.get_reconstruction_plate_id()
								# break
						#find mid_point
						mid_point = None
						if (p1 is not None and p2 is not None and gdu_id_1 != gdu_id_2):
							#debug
							# if ((plate_id_1 == 10041 and plate_id_2 == 10401) or (plate_id_1 == 10401 and plate_id_2 == 10041)):
								# print('approx_rad_closes_dist_1 == approx_rad_closes_dist_2 == 0.00')
								# print(gdu_id_1, gdu_id_2)
							mid_point = find_the_mid_of_two_PointOnSphere(p1,p2)
							#have to make sure mid_point is not within the interior of any SuperGDU polygons
							for big_polygon in SuperGDU_polygons:
								if (big_polygon.is_point_in_polygon(mid_point) == True):
									mid_point = None
									break
						if (mid_point is not None):			
							#great circle arc from mid_point to E
							great_circle_arc = pygplates.GreatCircleArc(mid_point,E_pole)
							normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
							left, right = identify_left_gdu_and_right_gdu(normal_vector_of_great_circle_arc, mid_point, p1, p2, gdu_id_1, gdu_id_2)
							print('left,right',left,right)
							#MOR
							#print("valid_age_of left_tectonic_ft")
							#print(valid_age_of_tectonic_ft)
							description_str = str(left)+"_"+str(right)
							middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, mid_point, name = "rifting/MOR_"+description_str, valid_time = valid_age_of_tectonic_ft)
							middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
							middle_ft.set_description(str(smallest_circle_angular_radius_degrees))
							middle_ft.set_left_plate(left)
							middle_ft.set_right_plate(right)
							
							#debug
							# print("middle_ft")
							# print(middle_ft)
							# print("middle_ft left and middle_ft right")
							# print(middle_ft.get_left_plate(), middle_ft.get_right_plate())
							# print("conjugate plate_id for middle_ft")
							# print(middle_ft.get_conjugate_plate_id())
							# print("plate_id_1, plate_id_2")
							# print(plate_id_1, plate_id_2)
							# exit()
					
							middle_ft_for_left = middle_ft.clone()
							middle_ft_for_left.set_reconstruction_plate_id(left)
							#middle_ft_for_left.set_reconstruction_method('ByPlateId')
							middle_ft_for_right = middle_ft.clone()
							middle_ft_for_right.set_reconstruction_plate_id(right)
							#middle_ft_for_right.set_reconstruction_method('ByPlateId')
							if (reference is None):
								pygplates.reverse_reconstruct([middle_ft,middle_ft_for_left,middle_ft_for_right],rotation_model,at_age)
							else:
								pygplates.reverse_reconstruct([middle_ft,middle_ft_for_left,middle_ft_for_right],rotation_model,at_age,reference)
							list_of_ordered_middle_fts_for_left.append(middle_ft_for_left)
							list_of_ordered_middle_fts_for_right.append(middle_ft_for_right)
							list_of_ordered_middle_fts.append(middle_ft)
							final_list_of_middle_fts.append(middle_ft)
							#final_list_of_middle_polygon_fts.append(middle_ft)
						
							outputPointFeatureCollection.add(middle_ft.clone())
						
							#CON_OCN divergent margins
							left_ft, right_ft = None,None
							if (left == gdu_id_1 and right == gdu_id_2):
								left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p1,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
								left_ft.set_reconstruction_plate_id(gdu_id_1)
								right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p2,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
								right_ft.set_reconstruction_plate_id(gdu_id_2)
							elif (left == gdu_id_2 and right == gdu_id_1):
								left_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p2,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
								left_ft.set_reconstruction_plate_id(gdu_id_2)
								right_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust,p1,name = "rifting/MOR_"+description_str,valid_time = valid_age_of_tectonic_ft)
								right_ft.set_reconstruction_plate_id(gdu_id_1)	
							#debug 
							# print("here is left_ft")
							# print(left_ft)
							# print("here is right_ft")
							# print(right_ft)
							if(left_ft is None or right_ft is None):
								print("Error: either left_ft or right_ft is None")
								print("left, right")
								print(left, right)
								print("gdu_id_1, gdu_id_2")
								print(gdu_id_1, gdu_id_2)
								exit()
							if (reference is None):
								pygplates.reverse_reconstruct([left_ft,right_ft],rotation_model,at_age)
							else:
								pygplates.reverse_reconstruct([left_ft,right_ft],rotation_model,at_age,reference)
							list_of_ordered_left_fts.append(left_ft)
							final_list_of_middle_fts.append(left_ft)
							#final_list_of_middle_polygon_fts.append(left_ft)
							list_of_ordered_right_fts.append(right_ft)
							final_list_of_middle_fts.append(right_ft)
							#final_list_of_middle_polygon_fts.append(right_ft)
						
							outputPointFeatureCollection.add(left_ft.clone())
							outputPointFeatureCollection.add(right_ft.clone())
						
							print('len(list_of_ordered_left_fts)')
							print(len(list_of_ordered_left_fts))
							print('len(list_of_ordered_right_fts)')
							print(len(list_of_ordered_right_fts))
				
					smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.000
			
				#connect middle features to create a single topological feature
				topological_line = create_a_topological_line_from_static_point_fts(list_of_ordered_middle_fts)
				topological_feature_type = pygplates.FeatureType.gpml_mid_ocean_ridge
				list_of_topological_fts_for_E_pole = create_list_of_topological_features_from_topological_sections(topological_feature_type, [topological_line])
				for topological_ft in list_of_topological_fts_for_E_pole:
					final_list_of_middle_fts.append(topological_ft)
			
				left_oceanic_crust_fts_at_age = find_reconstructable_left_ceanic_crust_features_formed_at_age(list_of_ordered_left_fts,list_of_ordered_middle_fts,rotation_model,at_age,reference)	
				right_oceanic_crust_fts_at_age = find_reconstructable_right_ceanic_crust_features_formed_at_age(list_of_ordered_right_fts,list_of_ordered_middle_fts,rotation_model,at_age,reference)	
			
				for new_left_oc_crust_ft in left_oceanic_crust_fts_at_age:
					final_list_of_oceanic_crust.append(new_left_oc_crust_ft)
				for new_right_oc_crust_ft in right_oceanic_crust_fts_at_age:
					final_list_of_oceanic_crust.append(new_right_oc_crust_ft)
			
				#create left oceanic topological polygon features - orderd of points is counterclockwise. 
				divergent_end_age,_ = find_min_max_age_from_middle_fts(list_of_ordered_middle_fts)
				# temporary_reversed_ordered_left_fts = [item for item in reversed(list_of_ordered_left_fts)]
				# list_of_points_for_left_oceanic_crust = list_of_ordered_middle_fts + temporary_reversed_ordered_left_fts
				# left_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_left_oceanic_crust)
				# print('Here is left_topological_polygon')
				# print(left_topological_polygon)
				# topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
				# left_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, left_topological_polygon)
				# print('Here is left_topological_polygon_feature')
				# print(left_topological_polygon_feature)
				# final_list_of_middle_polygon_fts.append(left_topological_polygon_feature)

				# temporary_reversed_ordered_middle_fts = [item for item in reversed(list_of_ordered_middle_fts)]
				# list_of_points_for_right_oceanic_crust = list_of_ordered_right_fts + temporary_reversed_ordered_middle_fts
				# right_topological_polygon = create_a_topological_polygon_from_static_point_fts(list_of_points_for_right_oceanic_crust)
				# print('Here is right_topological_polygon')
				# print(right_topological_polygon)
				# topological_feature_type = pygplates.FeatureType.gpml_topological_closed_plate_boundary
				# right_topological_polygon_feature = pygplates.Feature.create_topological_feature(topological_feature_type, right_topological_polygon)
				# print('Here is right_topological_polygon_feature')
				# print(right_topological_polygon_feature)
				# final_list_of_middle_polygon_fts.append(right_topological_polygon_feature)

				if (len(list_of_ordered_middle_fts) > 0 and (at_age - divergent_end_age) >= interval):
					subsequent_left_fts, surface_left_oceanic_crust_fts, subsequent_right_fts, surface_right_oceanic_crust_fts =  find_subsequent_left_right_oceanic_crust(list_of_ordered_middle_fts, list_of_ordered_left_fts, list_of_ordered_right_fts, rotation_model, at_age, divergent_end_age, interval, reference,SuperGDU_features)
					for subsequent_left_ft in subsequent_left_fts:
						estimated_final_list_of_oceanic_crust.append(subsequent_left_ft)
					for subsequent_left_ft in surface_left_oceanic_crust_fts:
						estimated_final_list_of_surface_oceanic_crust.append(subsequent_left_ft)
					for subsequent_right_ft in subsequent_right_fts:
						estimated_final_list_of_oceanic_crust.append(subsequent_right_ft)
					for subsequent_right_ft in surface_right_oceanic_crust_fts:
						estimated_final_list_of_surface_oceanic_crust.append(subsequent_right_ft)


				
	if (write_output == True):
		outputFile = "new_rifts_and_associated_margins_points_fts_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".shp"
		outputPointFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_middle_fts)
		outputFile = "topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_middle_polygon_fts)
		# outputFile = "topological_middle_polygon_fts_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		# outputFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(final_list_of_oceanic_crust)
		outputFile = "oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(estimated_final_list_of_surface_oceanic_crust)
		outputFile = "est_surface_oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
		outputFeatureCollection = pygplates.FeatureCollection(estimated_final_list_of_oceanic_crust)
		outputFile = "est_oceanic_crust_features_and_topological_MOR_"+modelname+"_"+str(at_age)+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
		outputFeatureCollection.write(outputFile)
	# outputFeatureCollection = pygplates.FeatureCollection(output_small_circle_fts)
	# outputFile = "output_small_circle_fts_10439_10480_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".shp"
	# outputFeatureCollection.write(outputFile)
	
	#return final_list_of_middle_fts,final_list_of_oceanic_crust,final_list_of_surface_oceanic_crust
	#return final_list_of_middle_fts,final_list_of_oceanic_crust,final_list_of_middle_polygon_fts
	return final_list_of_middle_fts,final_list_of_oceanic_crust

def find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_within_period(list_of_passive_margin_fts, SuperGDU_features, from_age, to_age, age_interval, rotation_model, reference, test_number, modelname, yyyymmdd):
	"""
	Find and connect locations where rifts/MOR ocurrs within period from_age to to_age with age_interval
		list_of_passive_margin_fts: a list or a list-like structure that contains CON_OCN margin features which were previously identified from first approximated tectonic motion evaluation
		SuperGDU_features
		from_age, to_age, age_interval: interpreted in Ma - float
		rotation_model: pygplates.RotationModel from .rot or grot file
		reference: None or any other value to be used as the reference_frame for the plate tectonic reconstruction
		test_number: int to keep track for testing the module
		modelname: str name of the plate tectonic model that we evaluate
		yyyymmdd: str year - month - day 
	Return:
		a list of: 
			locations of rifts/MOR
			topological line features connecting rifts/MOR locations
		write a .gpml file contains rifts/MOR locations and topological_line_features
	"""
	write_output = True #write_output at each time-step
	final_list_of_middle_fts = []
	final_list_of_oceanic_crust_fts = []
	final_list_of_surface_oceanic_crust_fts = []
	list_of_features_to_be_evaluated = []
	at_age = from_age
	while (at_age > (to_age - age_interval)):
		print("current age")
		print(at_age)
		list_of_features_to_be_evaluated[:] = []
		# if (at_age == from_age):
			# for ft in list_of_passive_margin_fts:
				# if (ft.is_valid_at_time(at_age) == True):
					# list_of_features_to_be_evaluated.append(ft)
		# elif (at_age < from_age):
			# for ft in list_of_passive_margin_fts:
				# if (ft.is_valid_at_time(at_age) == True and ft.is_valid_at_time(at_age + age_interval) == False):
					# list_of_features_to_be_evaluated.append(ft)
		for ft in list_of_passive_margin_fts:
			if (ft.is_valid_at_time(at_age)):
				list_of_features_to_be_evaluated.append(ft)
		#list_of_middle_fts_at_age, list_of_oceanic_crust_fts_at_age, list_of_surface_oceanic_crust_fts_at_age = find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features(list_of_features_to_be_evaluated, SuperGDU_features, at_age, age_interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output)
		list_of_middle_fts_at_age, list_of_oceanic_crust_fts_at_age = find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2(list_of_features_to_be_evaluated, SuperGDU_features, at_age, age_interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output)
		print("number of features at age")
		print(len(list_of_middle_fts_at_age))
		#move value of list_of_middle_fts_at_age to final_list_of_middle_fts
		# for ft in list_of_middle_fts_at_age:
			# final_list_of_middle_fts.append(ft)
		# for oc_ft in list_of_oceanic_crust_fts_at_age:
			# final_list_of_oceanic_crust_fts.append(oc_ft)
		# for sur_oc_ft in list_of_surface_oceanic_crust_fts_at_age:
			# final_list_of_surface_oceanic_crust_fts.append(sur_oc_ft)
		# print("number of features in final_list_of_middle_fts")
		# print(len(final_list_of_middle_fts))
		#update value of at_age
		at_age = at_age - age_interval
	# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_middle_fts)
	# outputFile = "topological_polygons_from_rifting_and_MOR_"+str(from_age)+"_"+str(to_age)+"_"+str(age_interval)+"_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
	# outputFeatureCollection.write(outputFile)
	
	# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_oceanic_crust_fts)
	# outputFile = "topological_oceanic_crust_features_"+str(from_age)+"_"+str(to_age)+"_"+str(age_interval)+"_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
	# outputFeatureCollection.write(outputFile)
	
	# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_surface_oceanic_crust_fts)
	# outputFile = "topological_surface_oceanic_crust_features_"+str(from_age)+"_"+str(to_age)+"_"+str(age_interval)+"_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
	# outputFeatureCollection.write(outputFile)
	
	# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_oceanic_crust_fts)
	# outputFile = "ttopological_MOR_"+str(from_age)+"_"+str(to_age)+"_"+str(age_interval)+"_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
	# outputFeatureCollection.write(outputFile)
	
	# outputFeatureCollection = pygplates.FeatureCollection(final_list_of_surface_oceanic_crust_fts)
	# outputFile = "topological_middle_polygon_fts_"+str(from_age)+"_"+str(to_age)+"_"+str(age_interval)+"_"+modelname+"_"+str(test_number)+"_"+yyyymmdd+".gpml"
	# outputFeatureCollection.write(outputFile)

