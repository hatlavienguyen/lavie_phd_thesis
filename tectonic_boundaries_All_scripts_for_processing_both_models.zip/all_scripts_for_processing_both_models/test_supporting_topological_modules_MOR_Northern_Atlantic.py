import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_topological_modules_for_MOR as supporting_MOR


def main():
	#testing module to find and count locations of MOR at a single time
	input_file_for_tectonic_boundaries = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\plate_tectonic_boundaries_test_10_reversed_PalaeoPlatesNov2021_without_subseq_eval_310.0_0.0_20220615.gpml"
	tectonic_boundaries_fts = pygplates.FeatureCollection(input_file_for_tectonic_boundaries)
	input_file_for_SuperGDU_features = r"C:\Users\Lavie\Desktop\Research\Winter2022\superGDU\test_11_optimize_no_rotation_refine_boundaries_of_SuperGDU_fts_Shapely_only_clean_up_final_SuperGDU_fts_PalaeoPlatesNov2021_from_2000_20220120_20220203.gpml"
	SuperGDU_features = pygplates.FeatureCollection(input_file_for_SuperGDU_features)
	input_file_for_rotation_model = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	rotation_model = pygplates.RotationModel(input_file_for_rotation_model)
	at_age = 310.00
	interval = 50.00
	reference = 700
	test_number = 1
	modelname = "test_1_PalaeoPlatesNov2021"
	yyyymmdd = "20220618"
	write_output = True
	list_of_passive_margin_fts = [ft for ft in tectonic_boundaries_fts if ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary and (ft.get_description() != 'lower_plate_margin' or ft.get_description() != 'unknown_convergent_margin')]
	# while (at_age >= 5.00):
		# supporting_MOR.find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_to_create_oceanic_crust_2(list_of_passive_margin_fts, SuperGDU_features, at_age, interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output)
		# at_age = at_age - interval
	supporting_MOR.create_oceanic_crust_polygon_fts_from_MOR_and_associated_div_margin_location_fts_within_period(310.00, 50.00, 5.00, rotation_model, reference, modelname, yyyymmdd)
if __name__ == "__main__":
	main()
