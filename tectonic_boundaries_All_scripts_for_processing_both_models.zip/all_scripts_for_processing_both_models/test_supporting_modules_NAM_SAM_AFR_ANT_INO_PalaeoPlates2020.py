#import supporting_modules as supporting
import supporting_modules_to_be_converted as supporting
import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
#update PalaeoPlate model by April 2020
#NAM_SAM_AFR_ANT_INO_PalaeoPlates_April_2020
#polygon_feature_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\GDUs\NAM_SAM_AFR_ANT_INO_PalaeoPlates2020.shp"
#topological_line_features_file = r"C:\Users\lavie\Desktop\Research\Fall2020\Code\examine_line_topology\topology_of_lines_PalaeoPlates2020_test_2_after_testing_present_topology_test_1_0.00100_v2_201007.gpml"

#polygon_feature_file = "C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\GDUs\\ASI_EUR_PalaeoPlates2020.shp"
#topological_line_features_file = "C:\Users\lavie\Desktop\Research\Summer2020\Code\examine_line_topology\\topology_of_lines_EUR_ASI_PalaeoPlate2020_test_1_test_1_0.00100_v2_200714.gpml"
#rot_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\Rotation\\T_Rot_Model_PalaeoPlates_20200131be.rot"

#igneous_buffer_zone_features_file = 'C:\Users\lavie\Desktop\Research\Summer2020\Code\igneous_metamorphics_records\\07202020\\igneous_dissolved_buffer_from_DateView_and_Neftex_Geochron_for_NAM_SAM_AFR_ANT_INO_Region_from_20200704.shp'

#possible_line_fts_for_subduction_zone_deposits_file = r'C:\Users\lavie\Desktop\Research\Fall2020\Code\identify_plate_boundaries\possible_subduction_zones_for_future_convergence_consider_all_buffersNAM_SAM_AFR_ANT_INO_PalaeoPlates_April2020_test_4_170_0_5Ma_08122020.gpml' 
#possible_line_fts_for_subduction_zone_igneous_file = r'C:\Users\lavie\Desktop\Research\Fall2020\Code\identify_plate_boundaries\possible_subduction_zones_for_future_convergence_consider_all_buffersNAM_SAM_AFR_ANT_INO_PalaeoPlates_April2020_test_4_from_igneous_170_0_5Ma_08122020.gpml'


# polygon_feature_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\GDUs\PlatePolygons2016Continental.shp"
# topological_line_features_file = r"C:\Users\lavie\Desktop\Research\Fall2020\Code\examine_line_topology\topology_of_lines_PalaeoPlates2020_test_2_after_testing_present_topology_test_1_0.00100_v2_201007.gpml"
# possible_line_fts_for_subduction_zone_deposits_file = r'C:\Users\lavie\Desktop\Research\Fall2020\Code\identify_plate_boundaries\possible_subduction_zones_for_future_convergence_consider_all_buffersPalaeoPlates_April2020_test_1_from_deposits_200_0_5Ma_10132020.gpml'
# possible_line_fts_for_subduction_zone_igneous_file = r'C:\Users\lavie\Desktop\Research\Fall2020\Code\identify_plate_boundaries\possible_subduction_zones_for_future_convergence_consider_all_buffersPalaeoPlates_April2020_test_1_from_igneous_DateView_only_200_0_5Ma_10132020.gpml'
# rot_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\Rotation\T_Rot_Model_PalaeoPlates_20200131be.rot"

# polygon_feature_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\SAM_AFR_PlatePolygons2016Continental.shp"
# centroid_features_file = None
# topological_line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\examine_line_topology\final_CON_OCN_from_modifying_CON_OCN_line_features_SAM_AFR_PalaeoPlatesNov2021_20211218.gpml"

test_GDU_id = [11093,10788]

polygon_feature_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\PlatePolygons2016Continental.shp"
polygon_features = pygplates.FeatureCollection(polygon_feature_file)
test_polygon_feature_collection = pygplates.FeatureCollection()
centroid_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\centroid_features_for_polygon_features_20220225.shp"
centroid_features = pygplates.FeatureCollection(centroid_features_file)
test_centroid_feature_collection = pygplates.FeatureCollection()
for ft in polygon_features:
	if (ft.get_reconstruction_plate_id() in test_GDU_id and ft.is_valid_at_time(325.00)):
		test_polygon_feature_collection.add(ft)
for ft in centroid_features:
	if (ft.get_reconstruction_plate_id() in test_GDU_id and ft.is_valid_at_time(325.00)):
		test_centroid_feature_collection.add(ft)

topological_line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\utility\check_and_assign_ft_id_str_in_GPlates_format_to_ft_name_CON_OCN_line_features_PalaeoPlatesNov2021_20220224.gpml"
line_features_collection = pygplates.FeatureCollection(topological_line_features_file)
test_line_features = pygplates.FeatureCollection()
for line_ft in line_features_collection:
	if (line_ft.get_reconstruction_plate_id() in test_GDU_id and line_ft.is_valid_at_time(325.00)):
		test_line_features.add(line_ft)
possible_line_fts_for_subduction_zone_deposits_file = None
possible_line_fts_for_subduction_zone_igneous_file = None
rot_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"

begin_reconstruction_time = 325.00
end_reconstruction_time = 305.00
interval = 5.00
field_name_for_lithosphere_type = 'COTID'
continental_type_symbol = 'C'
threshold_distance_in_km = 2000.00
difference_distance_km = 0.0500
cos_value_for_transform = 0.0100
reference = 700
number_of_intervals = 5
modelname = '11093_10788_PalaeoPlatesNov2021_test_6_threshold_1000km'
yearmonthday = '20220420'
freq_writing_csv_files = 40


#def main(rot_file,polygon_feature_file,centroid_features_file,topological_line_features_file,possible_line_fts_for_subduction_zone_deposits_file, possible_line_fts_for_subduction_zone_igneous_file,begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,difference_distance_km,cos_value_for_transform,reference,number_of_intervals,modelname,yearmonthday,freq_writing_csv_files):
def main(rot_file, test_polygon_feature_collection, test_centroid_feature_collection, test_line_features, possible_line_fts_for_subduction_zone_deposits_file, possible_line_fts_for_subduction_zone_igneous_file,begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,difference_distance_km,cos_value_for_transform,reference,number_of_intervals,modelname,yearmonthday,freq_writing_csv_files):
	# print('This is polygon_feature_file')
	# print polygon_feature_file
	# polygon_features_collection = pygplates.FeatureCollection(polygon_feature_file)
	
	# list_of_continental_polygons_fts = polygon_features_collection.get(
			# lambda polygon_feature: polygon_feature.get_shapefile_attribute(field_name_for_lithosphere_type) == continental_type_symbol ,pygplates.FeatureReturn.all)
	# supporting.find_centroid_features(list_of_continental_polygons_fts,False)
	# oldest_ft = supporting.find_the_oldest_feature(list_of_continental_polygons_fts)
	# print "The oldest feature GDU_id"
	# print oldest_ft.get_reconstruction_plate_id()
	# print oldest_ft.get_valid_time()
	
	# print('This is a rotation_file')
	# print rot_file
	
	# rotation_model = pygplates.RotationModel(rot_file)
	# threshold_distance_in_km = 1000.00
	# dictionary_of_neighbours_id = {}
	# reconstruction_time = 0.00
	
	#supporting.identify_plate_tectonic_boundaries(rot_file,polygon_feature_file,topological_line_features_file,igneous_buffer_zone_features_file,begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,difference_distance_km,cos_value_for_transform,reference,number_of_intervals,modelname,mmddyy,freq_writing_csv_files)
	
	#supporting.identify_plate_tectonic_boundaries(rot_file,polygon_feature_file,centroid_features_file,topological_line_features_file,possible_line_fts_for_subduction_zone_deposits_file, possible_line_fts_for_subduction_zone_igneous_file,begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,difference_distance_km,cos_value_for_transform,reference,number_of_intervals,modelname,yearmonthday,freq_writing_csv_files)
	rotation_model = pygplates.RotationModel(rot_file)
	print("test_polygon_feature_collection",len(test_polygon_feature_collection))
	print("test_centroid_feature_collection",len(test_polygon_feature_collection))
	print("test_line_features",len(test_line_features))
	supporting.identify_plate_tectonic_boundaries(rotation_model, test_polygon_feature_collection, test_centroid_feature_collection, test_line_features, possible_line_fts_for_subduction_zone_deposits_file, possible_line_fts_for_subduction_zone_igneous_file,begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,difference_distance_km,cos_value_for_transform,reference,number_of_intervals,modelname,yearmonthday,freq_writing_csv_files)
	#supporting.find_neighbours_for_polygon_features(rotation_model,list_of_continental_polygons_fts,threshold_distance_in_km,dictionary_of_neighbours_id,reconstruction_time,reference)
	#print "Here is dictionary_of_neighbours_id"
	#for each_key in dictionary_of_neighbours_id.keys():
	#	list_of_neighbours_id = dictionary_of_neighbours_id[each_key]
	#	for each_neighbour_id in list_of_neighbours_id:
	#		print each_neighbour_id
	

if __name__ == "__main__":
	#main(rot_file,polygon_feature_file,centroid_features_file,topological_line_features_file,possible_line_fts_for_subduction_zone_deposits_file, possible_line_fts_for_subduction_zone_igneous_file,begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,difference_distance_km,cos_value_for_transform,reference,number_of_intervals,modelname,yearmonthday,freq_writing_csv_files)
	main(rot_file, test_polygon_feature_collection, test_centroid_feature_collection, test_line_features, possible_line_fts_for_subduction_zone_deposits_file, possible_line_fts_for_subduction_zone_igneous_file,begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,difference_distance_km,cos_value_for_transform,reference,number_of_intervals,modelname,yearmonthday,freq_writing_csv_files)