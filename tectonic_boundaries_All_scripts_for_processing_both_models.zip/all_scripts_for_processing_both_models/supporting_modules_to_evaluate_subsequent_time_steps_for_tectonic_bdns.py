import sys

#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
import supporting_modules_to_be_converted_2 as supporting_2
import psycopg2
from config_plate_tectonics import config

def evaluate_subsequent_time_steps_for_tectonic_boundaries_from_database_tables(name_of_table_for_tectonic_motion_of_pairs_of_line_features, name_of_table_for_pairs_of_lines_and_GDUs_at_each_time, name_for_table_for_subsequent_tectonic_motion, line_features_collection, super_gdu_features_collection, rotation_model, reference, cos_value_for_transform, begin_reconstruction_time, end_reconstruction_time,time_interval, modelname, yearmonthday):
	txt = """SELECT DISTINCT ref_ft_id, neighbour_ft_id, tectonic_motion 
                FROM {input_name_of_table_for_tectonic_motion_of_pairs_of_line_features} 
                WHERE time = {input_time} AND tectonic_motion != 'Invalid'"""
	txt_1 = """SELECT first_supergdu_represent_id, first_supergdu_name, second_supergdu_represent_id, second_supergdu_name FROM {input_name_of_table_for_pairs_of_lines_and_GDUs_at_each_time}
				WHERE ((first_line_name = '{input_first_line_name}' and second_line_name = '{input_second_line_name}') 
						OR (first_line_name = '{input_second_line_name}' and second_line_name = '{input_first_line_name}'))
					AND time = {input_time}"""
	txt_B = """INSERT INTO {input_name_name_for_table_for_subseq_tectonic_motion}(time, ref_ft_id, neighbour_ft_id, tectonic_motion) VALUES (%s, %s, %s, %s)"""
	already_processed = []
	conn = None
	cur = None
	cur_1 = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		reconstruction_time = begin_reconstruction_time
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		dic = {}
		#filling the dictionary with temporal boundaries at begin_reconstruction_time
		sql = txt.format(input_name_of_table_for_tectonic_motion_of_pairs_of_line_features = name_of_table_for_tectonic_motion_of_pairs_of_line_features, input_time = begin_reconstruction_time)
		cur.execute(sql)
		row = cur.fetchone()
		if (row is not None):
			first_line_name = row[0]
			second_line_name = row[1]
			recorded_tectonic_motion = row[2]
			key = first_line_name+'$'+second_line_name
			inversed_key = second_line_name+'$'+first_line_name
			if (key not in dic and inversed_key not in dic):
				dic[key] = (begin_reconstruction_time,recorded_tectonic_motion)
		#update reconstruction_time to one time step after begin_reconstruction_time
		reconstruction_time = reconstruction_time - time_interval 
		while (reconstruction_time > (end_reconstruction_time - time_interval)):
			#keep in mind the dictionary is NOT empty.
			for key in dic:
				temp_first_line_name = None
				temp_second_line_name = None
				components_of_key = key.split("$")
				temp_first_line_name = components_of_key[0]
				temp_second_line_name = components_of_key[1]
				recorded_tectonic_motion = dic[key][1]
				sql_1 = txt_1.format(input_name_of_table_for_pairs_of_lines_and_GDUs_at_each_time = name_of_table_for_pairs_of_lines_and_GDUs_at_each_time,input_first_line_name = temp_first_line_name, input_second_line_name = temp_second_line_name, input_time = reconstruction_time)
				cur_1.execute(sql_1)
				row_1 = cur_1.fetchone()
				if (row_1 is None):
					#we have to validate the status of these two line features 
					#find the two line_ft
					first_line_ft = None
					second_line_ft = None
					for CON_OCN_line_ft in line_features_collection:
						if (CON_OCN_line_ft.get_name() == temp_first_line_name and CON_OCN_line_ft.is_valid_at_time(reconstruction_time)):
							first_line_ft = CON_OCN_line_ft
						if (CON_OCN_line_ft.get_name() == temp_second_line_name and CON_OCN_line_ft.is_valid_at_time(reconstruction_time)):
							second_line_ft = CON_OCN_line_ft
						if (first_line_ft is not None and second_line_ft is not None):
							break
					if (first_line_ft is not None and second_line_ft is not None):
						if (first_line_ft.is_valid_at_time(reconstruction_time) == True and second_line_ft.is_valid_at_time(reconstruction_time) == True):
							list_of_line_fts = [first_line_ft,second_line_ft]
							reconstructed_line_features = []
							if (reference is not None):
								pygplates.reconstruct(list_of_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(list_of_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
							final_reconstructed_line_fts = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
							first_line_ft,first_line = final_reconstructed_line_fts[0]
							second_line_ft,second_line = final_reconstructed_line_fts[1]
							list_of_valid_SuperGDU_fts = [super_gdu_ft for super_gdu_ft in super_gdu_features_collection if super_gdu_ft.is_valid_at_time(reconstruction_time)]
							reconstructed_polygon_features = []
							if (reference is not None):
								pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
							final_reconstructed_polygon_fts = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
							super_gdu_ft_of_first_line = None
							super_gdu_ft_of_second_line = None
							super_gdu_of_first_line = None
							super_gdu_of_second_line = None
							centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
							centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
							for super_gdu_ft,super_gdu in final_reconstructed_polygon_fts:
								if (pygplates.GeometryOnSphere.distance(centroid_of_first_line,super_gdu) == 0.00):
									super_gdu_ft_of_first_line = super_gdu_ft
									super_gdu_of_first_line = super_gdu
								if (pygplates.GeometryOnSphere.distance(centroid_of_second_line,super_gdu) == 0.00):
									super_gdu_ft_of_second_line = super_gdu_ft
									super_gdu_of_second_line = super_gdu
								if (super_gdu_ft_of_second_line is not None and super_gdu_of_first_line is not None):
									break
							temp_polyline = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
							#check any in_btw_SuperGDU
							valid = True
							for in_btw_super_gdu_ft,in_btw_super_gdu in final_reconstructed_polygon_fts:
								result = supporting_2.is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(temp_polyline, first_line, second_line, in_btw_super_gdu)
								if (result == True):
									valid = False
									break
							#the pair of line features have become invalid at the reconstruction_time
							if (valid == True):
								txt_4 = """INSERT INTO {input_name_for_table_for_subseq_tectonic_motion}(time, ref_ft_id, neighbour_ft_id, tectonic_motion) VALUES (%s, %s, %s, %s)"""
								sql_4 = txt_4.format(input_name_for_table_for_subseq_tectonic_motion = name_for_table_for_subsequent_tectonic_motion)
								list_of_centroid_ft = supporting_2.find_centroid_features_from_line_features(list_of_line_fts,False,None)
								first_centroid_ft = list_of_centroid_ft[0]
								second_centroid_ft = list_of_centroid_ft[1]
								tectonic_motion_at_reconstruction_time = supporting.relative_position_velocity_vectors_eval(rotation_model,first_centroid_ft,second_centroid_ft,reconstruction_time,time_interval,reference,cos_value_for_transform)
								cur_4.execute(sql_4,(reconstruction_time,temp_first_line_name,temp_second_line_name,tectonic_motion_at_reconstruction_time.name))
								
								#update value in dictionary
								dic[key] = (reconstruction_time,recorded_tectonic_motion)
			sql = txt.format(input_name_of_table_for_tectonic_motion_of_pairs_of_line_features = name_of_table_for_tectonic_motion_of_pairs_of_line_features, input_time = reconstruction_time)
			cur.execute(sql)
			row = cur.fetchone()
			while (row is not None):
				first_line_name = row[0]
				second_line_name = row[1]
				recorded_tectonic_motion = row[2]
				key = first_line_name+'$'+second_line_name
				inversed_key = second_line_name+'$'+first_line_name
				if (key not in dic and inversed_key not in dic):
					dic[key] = (reconstruction_time,recorded_tectonic_motion)
				row = cur.fetchone()
			#commit changes to database
			conn.commit()
			#update reconstruction_time
			reconstruction_time = reconstruction_time - time_interval 
	except (psycopg2.DatabaseError) as error:
		print("Error in evaluate_subsequent_time_steps_for_tectonic_boundaries_from_database_tables")
		print(error)