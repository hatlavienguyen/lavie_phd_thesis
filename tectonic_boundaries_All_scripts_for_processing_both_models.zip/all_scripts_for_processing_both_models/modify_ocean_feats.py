import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
import estimate_tectonic_plates as estimate
from multiprocessing import Pool
from os import environ
from time import sleep
import create_topological_isochron_and_estimate_MOR as create_ocean
def main():
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	temp_oceanic_crust_features_file = r"oceanic_crust_from_rift_and_isochron_point_features_with_max_star_div_age_200.0_min_0.0_test_29_PalaeoPlatesendJan2023_20231106.shp"
	temp_oceanic_crust_features = pygplates.FeatureCollection(temp_oceanic_crust_features_file)
	sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	maximum_reconstruction_time = 180.00
	minimum_reconstruction_time = 175.00
	time_interval = 5.00
	reference = 700
	modelname = 'v3_PalaeoPlatesendJan2023'
	yearmonthday = '20231206'
	create_ocean.check_and_assign_proper_SuperGDU_to_rift_point_features(rift_point_features_records_csv, temp_oceanic_crust_features, sgdu_features, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday)
	

if __name__ == '__main__':
	main()