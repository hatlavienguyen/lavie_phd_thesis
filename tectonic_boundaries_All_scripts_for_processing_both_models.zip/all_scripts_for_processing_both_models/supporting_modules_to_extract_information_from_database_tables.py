import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
from config_plate_tectonics import config
import psycopg2

def extract_plate_tectonic_motion_from_database_table_tectonic_motion(time_interval):
	sql = """SELECT DISTINCT ref_gdu_id, other_gdu_id FROM tectonic_motion_test WHERE ref_gdu_id != other_gdu_id"""
	txt_1 = """SELECT DISTINCT time, actual_tectonic_motion FROM tectonic_motion_test 
				WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or ((ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))) 
					and actual_tectonic_motion <> 'Not_known_yet_2' ORDER BY time DESC"""
	sql_2 = """INSERT INTO test_summary_of_tectonic_motion(from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id) VALUES (%s, %s, %s, %s, %s)"""
	txt_3 = """SELECT from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id FROM test_summary_of_tectonic_motion WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or ((ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))) and ABS(to_time - {input_time}) <= {input_time_interval} and tectonic_motion = 'Transform' """
	txt_5 = """SELECT from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id FROM test_summary_of_tectonic_motion WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or ((ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id})))""" 
	conn = None
	cur = None
	cur_1 = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		cur_5 = conn.cursor()
		cur.execute(sql)
		row = cur.fetchone()
		while (row is not None):
			ref_gdu_id = int(row[0])
			other_gdu_id = int(row[1])
			
			sql_5 = txt_5.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id)
			cur_5.execute(sql_5)
			row_5 = cur_5.fetchone()
			while (row_5 is not None):
				row = cur.fetchone()
				if (row is None):
					break
				ref_gdu_id = int(row[0])
				other_gdu_id = int(row[1])
			
				sql_5 = txt_5.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id)
				cur_5.execute(sql_5)
				row_5 = cur_5.fetchone()
			if (row is None):
				break
			sql_1 = txt_1.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id)
			cur_1.execute(sql_1)
			row_1 = cur_1.fetchone()
			previous_time = -100.00
			previous_teoctonic_motion = None
			oldest_time = -100.00
			while(row_1 is not None):
				current_time = float(row_1[0])
				current_tectonic_motion = row_1[1]
				print('00000000000')
				print('oldest_time,previous_time,current_time, (previous_time - current_time)',oldest_time,previous_time,current_time,(previous_time - current_time))
				print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
				if (previous_time == -100.00 and previous_teoctonic_motion is None):
					previous_time = current_time 
					previous_teoctonic_motion = current_tectonic_motion
					if (current_tectonic_motion is not None):
						oldest_time = current_time
				else:
					if (current_time < previous_time and (previous_time - current_time) <= (time_interval+0.5000)): #within 5Ma 
						if (current_tectonic_motion is not None):
							if (current_tectonic_motion == previous_teoctonic_motion):
								previous_time = current_time
								previous_teoctonic_motion = current_tectonic_motion
							else:
								if (previous_teoctonic_motion is None):
									previous_time = current_time
									previous_teoctonic_motion = current_tectonic_motion
									oldest_time = current_time
								elif (previous_teoctonic_motion is not None):
									#print('first')
									#print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
									#print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
									if (previous_teoctonic_motion == 'Transform'):
										sql_3 = txt_3.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_time = previous_time, input_time_interval = time_interval)
										cur_3.execute(sql_3)
										print("previous_teoctonic_motion == 'Transform'")
										print("oldest_time,previous_time,current_time",oldest_time,previous_time,current_time)
										row_3 = cur_3.fetchone()
										print(row_3)
										if (row_3 is None):
											cur_2.execute(sql_2,(oldest_time,current_time + (0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
										else:
											new_input_from_time = row_3[0]
											txt_4 = """UPDATE test_summary_of_tectonic_motion 
														SET from_time = {input_from_time},
															to_time = {input_to_time},
															ref_gdu_id = {input_ref_gdu_id},
															other_gdu_id = {input_other_gdu_id},
															tectonic_motion = 'Transform'
														WHERE ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id} and ABS(to_time - {input_time}) <= {input_time_interval} and tectonic_motion = 'Transform'"""
											sql_4 = txt_4.format(input_from_time = new_input_from_time, input_to_time = current_time + (0.100*time_interval), input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_time = previous_time, input_time_interval = time_interval)
											cur_4.execute(sql_4)
										previous_time = current_time
										previous_teoctonic_motion = current_tectonic_motion
										#print('previous_teoctonic_motion after first insert', previous_teoctonic_motion)
										oldest_time = current_time
									else:
										# cur_2.execute(sql_2,(oldest_time,current_time + (0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
										# previous_time = current_time
										# previous_teoctonic_motion = current_tectonic_motion
										# #print('previous_teoctonic_motion after first insert', previous_teoctonic_motion)
										# oldest_time = current_time
										
										# if (previous_teoctonic_motion == 'Transform'):
											# #print('fourth')
											# #print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
											# #print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
											# cur_2.execute(sql_2,(oldest_time,current_time - time_interval +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
											# previous_time = current_time
											# previous_teoctonic_motion = current_tectonic_motion
											# oldest_time = current_time
										# elif ((previous_teoctonic_motion == 'Divergence' and current_tectonic_motion == 'Convergence') or (previous_teoctonic_motion == 'Convergence' and current_tectonic_motion == 'Divergence')):
											# if (oldest_time > current_time):
												# #print('fifth')
												# #print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
												# #print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
												# cur_2.execute(sql_2,(oldest_time,current_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
												# previous_time = current_time
												# previous_teoctonic_motion = 'Transform'
												# oldest_time = current_time
											# elif (oldest_time == current_time):
												# previous_time = current_time
												# previous_teoctonic_motion = 'Transform'
										
										if ((previous_teoctonic_motion == 'Divergence' and current_tectonic_motion == 'Convergence') or (previous_teoctonic_motion == 'Convergence' and current_tectonic_motion == 'Divergence')):
											if (oldest_time > current_time):
												#print('fifth')
												#print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
												#print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
												cur_2.execute(sql_2,(oldest_time,current_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
												previous_time = current_time
												previous_teoctonic_motion = 'Transform'
												oldest_time = current_time
											elif (oldest_time == current_time):
												previous_time = current_time
												previous_teoctonic_motion = 'Transform'
						else:
							if (current_tectonic_motion == previous_teoctonic_motion):
								previous_time = current_time
								previous_teoctonic_motion = current_tectonic_motion
							else:
								#print('second')
								#print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
								#print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
								cur_2.execute(sql_2,(oldest_time,current_time + (0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
								previous_time = current_time
								previous_teoctonic_motion = current_tectonic_motion
								oldest_time = current_time
					elif (current_time == previous_time):
						if (current_tectonic_motion == previous_teoctonic_motion):
							previous_time = current_time
							previous_teoctonic_motion = current_tectonic_motion
						else:
							if (current_tectonic_motion is None and previous_teoctonic_motion is not None):
								#print('third')
								#print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
								#print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
								cur_2.execute(sql_2,(oldest_time,current_time + (0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
								previous_time = current_time
								previous_teoctonic_motion = current_tectonic_motion
								oldest_time = current_time
							elif (current_tectonic_motion is not None and previous_teoctonic_motion is None):
								previous_time = current_time
								previous_teoctonic_motion = current_tectonic_motion
								oldest_time = current_time
							elif (current_tectonic_motion is not None and previous_teoctonic_motion is not None):
								if (previous_teoctonic_motion == 'Transform'):
									#print('fourth')
									#print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
									#print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
									cur_2.execute(sql_2,(oldest_time,current_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
									previous_time = current_time
									previous_teoctonic_motion = current_tectonic_motion
									oldest_time = current_time
								elif ((previous_teoctonic_motion == 'Divergence' and current_tectonic_motion == 'Convergence') or (previous_teoctonic_motion == 'Convergence' and current_tectonic_motion == 'Divergence')):
									if (oldest_time > current_time):
										#print('fifth')
										#print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
										#print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
										cur_2.execute(sql_2,(oldest_time,current_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
										previous_time = current_time
										previous_teoctonic_motion = 'Transform'
										oldest_time = current_time
									elif (oldest_time == current_time):
										previous_time = current_time
										previous_teoctonic_motion = 'Transform'
										#oldest_time = current_time
					elif (current_time < previous_time and (previous_time - current_time) > (time_interval+0.5000)): #not two consecutive time steps
						# if (previous_teoctonic_motion is not None):
							# #print('sixth')
							# #print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
							# #print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
							# if ((previous_teoctonic_motion == 'Divergence' and current_tectonic_motion == 'Convergence') or (previous_teoctonic_motion == 'Convergence' and current_tectonic_motion == 'Divergence')):
								# cur_2.execute(sql_2,(oldest_time,previous_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
								# cur_2.execute(sql_2,(previous_time,current_time+(0.100*time_interval),'Unknown_rapid_fluct_motion',ref_gdu_id,other_gdu_id))
								# previous_time = current_time
								# previous_teoctonic_motion = 'Transform'
								# oldest_time = current_time
							# elif (previous_teoctonic_motion == current_tectonic_motion):
								# cur_2.execute(sql_2,(oldest_time,previous_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
								# cur_2.execute(sql_2,(previous_time,current_time+(0.100*time_interval),'Unknown_same_motion',ref_gdu_id,other_gdu_id))
								# previous_time = current_time
								# previous_teoctonic_motion = current_tectonic_motion
								# oldest_time = current_time
							# elif ((previous_teoctonic_motion == 'Transform' and (current_tectonic_motion == 'Convergence' or current_tectonic_motion == 'Divergence')) or ((previous_teoctonic_motion == 'Divergence' or previous_teoctonic_motion == 'Convergence') and current_tectonic_motion == 'Transform')):
								# cur_2.execute(sql_2,(oldest_time,previous_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
								# cur_2.execute(sql_2,(previous_time,current_time+(0.100*time_interval),'Unknown_fluct_motion',ref_gdu_id,other_gdu_id))
								# previous_time = current_time
								# previous_teoctonic_motion = current_tectonic_motion
								# oldest_time = current_time
						
						if (previous_teoctonic_motion is not None):
							#print('sixth')
							#print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
							#print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
							if ((previous_teoctonic_motion == 'Convergence' and current_tectonic_motion == 'Divergence')):
								cur_2.execute(sql_2,(oldest_time,previous_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
								#cur_2.execute(sql_2,(previous_time,current_time+(0.100*time_interval),'Divergence',ref_gdu_id,other_gdu_id))
								previous_time = current_time
								previous_teoctonic_motion = 'Divergence'
								oldest_time = current_time
							elif (previous_teoctonic_motion == current_tectonic_motion):
								cur_2.execute(sql_2,(oldest_time,previous_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
								cur_2.execute(sql_2,(previous_time,current_time+(0.100*time_interval),'Unknown_same_motion',ref_gdu_id,other_gdu_id))
								previous_time = current_time
								previous_teoctonic_motion = current_tectonic_motion
								oldest_time = current_time
							elif ((previous_teoctonic_motion == 'Transform' and (current_tectonic_motion == 'Convergence' or current_tectonic_motion == 'Divergence')) or ((previous_teoctonic_motion == 'Divergence' or previous_teoctonic_motion == 'Convergence') and current_tectonic_motion == 'Transform')):
								cur_2.execute(sql_2,(oldest_time,previous_time +(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
								#cur_2.execute(sql_2,(previous_time,current_time+(0.100*time_interval),'Unknown_fluct_motion',ref_gdu_id,other_gdu_id))
								previous_time = current_time
								previous_teoctonic_motion = current_tectonic_motion
								oldest_time = current_time
						else:
							if (current_tectonic_motion is not None):
								previous_time = current_time
								previous_teoctonic_motion = current_tectonic_motion
								oldest_time = current_time
				row_1= cur_1.fetchone()
			if (previous_time >= 0.00):
				print(previous_teoctonic_motion)
				if (previous_teoctonic_motion is not None):
					if (previous_time == oldest_time):
						cur_2.execute(sql_2,(oldest_time,previous_time -(0.100*time_interval),previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
					elif (previous_time < oldest_time):
						cur_2.execute(sql_2,(oldest_time,previous_time,previous_teoctonic_motion,ref_gdu_id,other_gdu_id))
					else:
						cur_2.execute(sql_2,(oldest_time,previous_time,"Invalid",ref_gdu_id,other_gdu_id))
					# cur_2.execute(sql_2,(previous_time,-5.00,"Unknown",ref_gdu_id,other_gdu_id))
				# else:
					# cur_2.execute(sql_2,(previous_time,-5.00,"Unknown",ref_gdu_id,other_gdu_id))
			# if (previous_time > 0.00):
				# #print('seventh')
				# #print('oldest_time,previous_time,current_time',oldest_time,previous_time,current_time)
				# #print('previous_teoctonic_motion,current_tectonic_motion',previous_teoctonic_motion,current_tectonic_motion)
				# cur_2.execute(sql_2,(previous_time,-5.00,"Unknown",ref_gdu_id,other_gdu_id))
			row = cur.fetchone()
		conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_motion_from_database_table_tectonic_motion")
		print(error)
	

def extract_plate_tectonic_margins_from_temp_output_tectonic_boundaries(common_name_for_output_files,modelname,threshold,yyyymmdd,begin,end,interval,output_freq,fileformat,output_modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins from temporary output files for tectonic boundaries
		Input: database table tectonic_boundaries when we process plate boundaries identification 
				common_name_for_output_files, modelname, threshold, yyyymmdd, begin, end, interval, output_freq, fileformat that we use to construct set of name of temporaral output files"""
	temporal_output_features = pygplates.FeatureCollection()
	time = begin
	list_of_filename = []
	list_of_temporal_fts = []
	list_of_final_fts = []
	already_proccessed_ft = []
	output_features = []
	while (time > end):
		print('time')
		print(time)
		next_time = time - (interval * output_freq)
		if (next_time < end):
			next_time = end 
		print('next_time')
		print(next_time)
		#tectonic_boundaries_features_test_5_for_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_800km__170.0_150.0_5Ma_20210204.gpml
		txt = """{input_common_name_for_output_files}_{input_modelname}_{input_threshold}km__{input_begin}_{input_end}_{input_interval}Ma_{input_yyyymmdd}.{input_fileformat}"""
		if (time <= 560.00 ):
			#"tectonic_boundaries_features_PalaeoPlates_June_2021_test_2_threshold_1000km_cont_60.0_40.0_5Ma_20210828"
			txt = """{input_common_name_for_output_files}_{input_modelname}_{input_threshold}km_cont_{input_begin}_{input_end}_{input_interval}Ma_20210828.{input_fileformat}"""
		final_filename = txt.format(input_common_name_for_output_files = common_name_for_output_files, input_modelname = modelname, input_threshold = threshold, input_begin = str(time), input_end = str(next_time), input_interval = str(interval), input_yyyymmdd = yyyymmdd, input_fileformat = fileformat)
		print('final_filename')
		print(final_filename)
		temporal_output_features_from_the_file = pygplates.FeatureCollection(final_filename)
		for ft in temporal_output_features_from_the_file:
			temporal_output_features.add(ft)
		#list_of_filename.append(final_filename)
		print("total number of fts",len(temporal_output_features))
		time = next_time
	
		
	#multiple_feature_collection = pygplates.FeatureCollection.read(list_of_filename)
	#print('multiple_feature_collection')
	#print(multiple_feature_collection)
	
	# list_of_features = []
	# for collection in multiple_feature_collection:
		# for ft in collection:
			# list_of_features.append(ft)
	
	feature_collection = temporal_output_features
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()

	txt_1 = """SELECT DISTINCT line_1_ft_name,line_2_ft_name,from_time,to_time,tectonic_motion FROM not_found_tectonic_boundaries"""
	txt = """SELECT time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id FROM tectonic_boundaries WHERE line_1_ft_name = {input_line_1_ft_name} AND line_2_ft_name = {input_line_2_ft_name} AND tectonic_motion = {input_tectonic_motion} ORDER BY time DESC"""
	sql_2 = """INSERT INTO not_found_tectonic_boundaries_after_first_run(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	sql_3 = """INSERT INTO summary_of_tectonic_boundaries_after_first_run(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_1.execute(txt_1)
		row_1 = cur_1.fetchone()
		number_of_processed_fts = 1
		while (row_1 is not None):
			print("number_of_processed_fts",number_of_processed_fts)
			number_of_processed_fts = number_of_processed_fts +1
			print("row_1",row_1)
			line_1_ft_name = row_1[0]
			line_2_ft_name = row_1[1]
			current_begin_age = float(row_1[2])
			current_end_age = float(row_1[3])
			current_tectonic_motion = row_1[4]
			sql = txt.format(input_line_1_ft_name = '\''+line_1_ft_name+'\'',input_line_2_ft_name = '\''+line_2_ft_name+'\'', input_tectonic_motion = '\''+current_tectonic_motion+'\'')
			cur.execute(sql)
			row = cur.fetchone()
			if (row is not None):
				current_line_2_ft_name = line_2_ft_name
				current_line_1_ft_id = row[3]
				current_line_2_ft_id = row[4]
				ref_gdu_id = int(row[1])
				other_gdu_id = int(row[2])
				if (abs(current_begin_age - current_end_age) > 1.00):
					#find the two line features 
					line_ft_1 = feature_collection.get(lambda ft: ft.get_reconstruction_plate_id() == ref_gdu_id and ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.first)
					line_ft_2 = None
					if (line_ft_1 is None):
						line_ft_1 = feature_collection.get(lambda ft: ft.get_reconstruction_plate_id() == other_gdu_id and ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.first)
						line_ft_2 = feature_collection.get(lambda ft: ft.get_reconstruction_plate_id() == ref_gdu_id and ft.get_name() == current_line_2_ft_name, pygplates.FeatureReturn.first)
					else:
						line_ft_2 = feature_collection.get(lambda ft: ft.get_reconstruction_plate_id() == other_gdu_id and ft.get_name() == current_line_2_ft_name, pygplates.FeatureReturn.first)
					plate_tectonic_margin_ft_1 = None
					plate_tectonic_margin_ft_2 = None
					if (line_ft_1 is not None and line_ft_2 is not None):
						if (current_tectonic_motion == "Convergence"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_1.get_geometry(), name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, current_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_2.get_geometry(), name = current_line_2_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, current_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						elif (current_tectonic_motion == "Divergence"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_1.get_geometry(), name = line_1_ft_name, description = "divergent_margin", valid_time = (current_begin_age, current_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_2.get_geometry(), name = current_line_2_ft_name, description = "divergent_margin", valid_time = (current_begin_age, current_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						elif (current_tectonic_motion == "Transform"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_1.get_geometry(), name = line_1_ft_name, description = "transform_fault", valid_time = (current_begin_age, current_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_2.get_geometry(), name = current_line_2_ft_name, description = "transform_fault", valid_time = (current_begin_age, current_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						else:
							print("current_tectonic_motion",current_tectonic_motion)
						print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
						output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
						output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
						cur_3.execute(sql_3,(current_begin_age, current_end_age, current_tectonic_motion, line_1_ft_name, current_line_2_ft_name, current_line_1_ft_id, current_line_2_ft_id))
					else:
						cur_2.execute(sql_2,(current_begin_age, current_end_age, current_tectonic_motion, line_1_ft_name, current_line_2_ft_name, current_line_1_ft_id, current_line_2_ft_id))
			row_1 = cur_1.fetchone()
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_tectonic_boundaries")
		print(error)
	
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_temp_output_tectonic_boundaries_"+output_modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def extract_plate_tectonic_margins_from_temp_output_tectonic_boundaries_that_were_not_recorded_in_database(common_name_for_output_files,modelname,threshold,yyyymmdd,begin,end,interval,output_freq,fileformat,output_modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins from temporary output files for tectonic boundaries which were not recorded to database at all
		Input: database table tectonic_boundaries when we process plate boundaries identification 
				common_name_for_output_files, modelname, threshold, yyyymmdd, begin, end, interval, output_freq, fileformat that we use to construct set of name of temporaral output files"""
	
	txt_1 = """SELECT ref_gdu_id, other_gdu_id FROM tectonic_boundaries WHERE (line_1_ft_name = {input_line_1_ft_name} OR line_2_ft_name = {input_line_2_ft_name}) AND tectonic_motion = {input_tectonic_motion}"""
	sql_2 = """INSERT INTO not_recorded_tectonic_boundaries_during_identification(time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_1_ft_name, tectonic_motion) VALUES (%s, %s, %s, %s, %s, %s)"""
	
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	temporal_output_features = pygplates.FeatureCollection()
	list_of_filename = []
	list_of_temporal_fts = []
	list_of_final_fts = []
	already_proccessed_ft = []
	output_features = []
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		time = begin
		while (time > end):
			print('time')
			print(time)
			next_time = time - (interval * output_freq)
			if (next_time < end):
				next_time = end 
			print('next_time')
			print(next_time)
			#tectonic_boundaries_features_test_5_for_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_800km__170.0_150.0_5Ma_20210204.gpml
			txt = """{input_common_name_for_output_files}_{input_modelname}_{input_threshold}km__{input_begin}_{input_end}_{input_interval}Ma_{input_yyyymmdd}.{input_fileformat}"""
			if (time <= 560.00 ):
				#"tectonic_boundaries_features_PalaeoPlates_June_2021_test_2_threshold_1000km_cont_60.0_40.0_5Ma_20210828"
				txt = """{input_common_name_for_output_files}_{input_modelname}_{input_threshold}km_cont_{input_begin}_{input_end}_{input_interval}Ma_20210828.{input_fileformat}"""
			final_filename = txt.format(input_common_name_for_output_files = common_name_for_output_files, input_modelname = modelname, input_threshold = threshold, input_begin = str(time), input_end = str(next_time), input_interval = str(interval), input_yyyymmdd = yyyymmdd, input_fileformat = fileformat)
			print('final_filename')
			print(final_filename)
			temporal_output_features_from_the_file = pygplates.FeatureCollection(final_filename)
			#list_of_filename.append(final_filename)
			print("temporal_output_features_from_the_file",len(temporal_output_features_from_the_file))
			for ft in temporal_output_features_from_the_file:
				ft_name = ft.get_name()
				ft_left_id = ft.get_left_plate()
				ft_right_id = ft.get_right_plate()
				ft_geometry_type = type(ft.get_geometry())
				ft_type = ft.get_description()
				ft_begin_age,ft_end_age = ft.get_valid_time()
				if (ft_geometry_type == pygplates.PolylineOnSphere):
					if (ft_type == "upper_plate_margin" or ft_type == "lower_plate_margin" or ft_type == 'unknown_margin_convergent_zone'):
						sql_1 = txt_1.format(input_line_1_ft_name = '\''+ft_name+'\'', input_line_2_ft_name = '\''+ft_name+'\'', input_tectonic_motion = "'Convergence'")
						cur_1.execute(sql_1)
						row_1 = cur_1.fetchone()
						if (row_1 is None):
							cur_2.execute(sql_2,(ft_begin_age, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Convergence'))
							output_plate_tectonic_margin_fts.add(ft)
					elif (ft_type == "divergent_zone"):
						sql_1 = txt_1.format(input_line_1_ft_name = '\''+ft_name+'\'', input_line_2_ft_name = '\''+ft_name+'\'', input_tectonic_motion = "'Divergence'")
						cur_1.execute(sql_1)
						row_1 = cur_1.fetchone()
						if (row_1 is None):
							cur_2.execute(sql_2,(ft_begin_age, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Divergence'))
							output_plate_tectonic_margin_fts.add(ft)
					elif (ft_type == "transform"):
						sql_1 = txt_1.format(input_line_1_ft_name = '\''+ft_name+'\'', input_line_2_ft_name = '\''+ft_name+'\'', input_tectonic_motion = "'Transform'")
						cur_1.execute(sql_1)
						row_1 = cur_1.fetchone()
						if (row_1 is None):
							cur_2.execute(sql_2,(ft_begin_age, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Transform'))
							output_plate_tectonic_margin_fts.add(ft)		
			#update value for time and database
			time = next_time
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_temp_output_tectonic_boundaries_that_were_not_recorded_in_database")
		print(error)
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_temp_output_tectonic_boundaries_that_were_not_recorded_in_database_"+output_modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def extract_plate_tectonic_margins_from_temp_output_tectonic_boundaries(common_name_for_output_files,modelname,threshold,yyyymmdd,begin,end,interval,output_freq,fileformat,output_modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins from temporary output files for tectonic boundaries which were not recorded to database at all
		Input: database table tectonic_boundaries when we process plate boundaries identification 
				common_name_for_output_files, modelname, threshold, yyyymmdd, begin, end, interval, output_freq, fileformat that we use to construct set of name of temporaral output files"""
	sql_2 = """INSERT INTO temporal_output_tectonic_boundaries_during_identification(from_time, to_time, ref_gdu_id, other_gdu_id, left_gdu_id , right_gdu_id, line_ft_id, line_ft_name, tectonic_motion, type) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
	
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		time = begin
		while (time > end):
			print('time')
			print(time)
			next_time = time - (interval * output_freq)
			if (next_time < end):
				next_time = end 
			print('next_time')
			print(next_time)
			#tectonic_boundaries_features_test_5_for_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_800km__170.0_150.0_5Ma_20210204.gpml
			txt = """{input_common_name_for_output_files}_{input_modelname}_{input_threshold}km__{input_begin}_{input_end}_{input_interval}Ma_{input_yyyymmdd}.{input_fileformat}"""
			if (time <= 560.00 ):
				#"tectonic_boundaries_features_PalaeoPlates_June_2021_test_2_threshold_1000km_cont_60.0_40.0_5Ma_20210828"
				txt = """{input_common_name_for_output_files}_{input_modelname}_{input_threshold}km_cont_{input_begin}_{input_end}_{input_interval}Ma_20210828.{input_fileformat}"""
			final_filename = txt.format(input_common_name_for_output_files = common_name_for_output_files, input_modelname = modelname, input_threshold = threshold, input_begin = str(time), input_end = str(next_time), input_interval = str(interval), input_yyyymmdd = yyyymmdd, input_fileformat = fileformat)
			print('final_filename')
			print(final_filename)
			temporal_output_features_from_the_file = pygplates.FeatureCollection(final_filename)
			temporal_tectonic_margin_features = [feat for feat in temporal_output_features_from_the_file if (type(feat.get_geometry()) == pygplates.PolylineOnSphere)]
			#list_of_filename.append(final_filename)
			print("temporal_tectonic_margin_features",len(temporal_tectonic_margin_features))
			for ft in temporal_tectonic_margin_features:
				ft_name = ft.get_name()
				ft_left_id = ft.get_left_plate()
				ft_right_id = ft.get_right_plate()
				ft_geometry_type = type(ft.get_geometry())
				ft_type = ft.get_description()
				ft_begin_age,ft_end_age = ft.get_valid_time()
				if (ft_type == "upper_plate_margin" or ft_type == "lower_plate_margin" or ft_type == 'unknown_margin_convergent_zone'):
					if (ft.get_reconstruction_plate_id() == ft_left_id):
						cur_2.execute(sql_2,(ft_begin_age, ft_end_age, ft_left_id, ft_right_id, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Convergence',ft_type))
					elif (ft.get_reconstruction_plate_id() == ft_right_id):
						cur_2.execute(sql_2,(ft_begin_age, ft_end_age, ft_right_id, ft_left_id, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Convergence',ft_type))
				elif (ft_type == "divergent_zone"):
					if (ft.get_reconstruction_plate_id() == ft_left_id):
						cur_2.execute(sql_2,(ft_begin_age, ft_end_age, ft_left_id, ft_right_id, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Divergence',ft_type))
					elif (ft.get_reconstruction_plate_id() == ft_right_id):
						cur_2.execute(sql_2,(ft_begin_age, ft_end_age, ft_right_id, ft_left_id, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Divergence',ft_type))
				elif (ft_type == "transform"):
					if (ft.get_reconstruction_plate_id() == ft_left_id):
						cur_2.execute(sql_2,(ft_begin_age, ft_end_age, ft_left_id, ft_right_id, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Transform',ft_type))
					elif (ft.get_reconstruction_plate_id() == ft_right_id):
						cur_2.execute(sql_2,(ft_begin_age, ft_end_age, ft_right_id, ft_left_id, ft_left_id, ft_right_id, ft.get_feature_id().get_string(),ft_name, 'Transform',ft_type))	
			#update value for time and database
			time = next_time
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_temp_output_tectonic_boundaries")
		print(error)

def extract_plate_tectonic_margins_from_database_table_tectonic_boundaries(initial_CON_OCN_geological_topological_line_feature_file,modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins for the CON-OCN geological topological line features at each reconstruction time 
		Input: database table tectonic_boundaries when we process plate boundaries identification 
				initial_CON_OCN_geological_topological_line_feature that we use as the input when we process plate boundaries identification"""
	
	initial_CON_OCN_features = pygplates.FeatureCollection(initial_CON_OCN_geological_topological_line_feature_file)
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	
	txt_1 = """SELECT DISTINCT line_1_ft_name FROM tectonic_boundaries"""
	txt = """SELECT time, tectonic_motion, line_2_ft_name, line_1_ft_id, line_2_ft_id FROM tectonic_boundaries WHERE line_1_ft_name = {input_line_1_ft_name} ORDER BY time DESC"""
	sql_2 = """INSERT INTO not_found_tectonic_boundaries(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	sql_3 = """INSERT INTO summary_of_tectonic_boundaries(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_1.execute(txt_1)
		row_1 = cur_1.fetchone()
		while (row_1 is not None):
			line_1_ft_name = row_1[0]
			sql = txt.format(input_line_1_ft_name = '\''+line_1_ft_name+'\'')
			cur.execute(sql)
			row = cur.fetchone()
			#print("here is row",row)
			current_tectonic_motion = None
			current_begin_age = -1.00
			current_line_2_ft_name = None
			current_line_1_ft_id = None
			current_line_2_ft_id = None
			while (row is not None):
				#print(row)
				new_tectonic_motion = row[1]
				new_begin_age = float(row[0])
				new_line_2_ft_name = row[2]
				new_line_1_ft_id = row[3]
				new_line_2_ft_id = row[4]
				#print("new_line_2_ft_name", new_line_2_ft_name)
				if (current_tectonic_motion is None):
					current_tectonic_motion = new_tectonic_motion
					current_begin_age = new_begin_age
					current_line_2_ft_name = new_line_2_ft_name
					current_line_1_ft_id = new_line_1_ft_id
					current_line_2_ft_id = new_line_2_ft_id
				elif (current_tectonic_motion != new_tectonic_motion):
					#find the two line features 
					line_ft_1 = initial_CON_OCN_features.get(lambda ft: ft.get_feature_id().get_string() == line_1_ft_name or ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.first)
					line_ft_2 = initial_CON_OCN_features.get(lambda ft: ft.get_feature_id().get_string() == current_line_2_ft_name or ft.get_name() == current_line_2_ft_name, pygplates.FeatureReturn.first)
					plate_tectonic_margin_ft_1 = None
					plate_tectonic_margin_ft_2 = None
					if (line_ft_1 is not None and line_ft_2 is not None and current_begin_age != new_begin_age):
						if (current_tectonic_motion == "Convergence"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_1.get_geometry(), name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_2.get_geometry(), name = current_line_2_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						elif (current_tectonic_motion == "Divergence"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_1.get_geometry(), name = line_1_ft_name, description = "divergent_margin", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_2.get_geometry(), name = current_line_2_ft_name, description = "divergent_margin", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						elif (current_tectonic_motion == "Transform"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_1.get_geometry(), name = line_1_ft_name, description = "transform_fault", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_2.get_geometry(), name = current_line_2_ft_name, description = "transform_fault", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						else:
							print("current_tectonic_motion",current_tectonic_motion)
						print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
						output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
						output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
						final_end_age = new_begin_age + 0.0500
						cur_3.execute(sql_3,(current_begin_age, final_end_age, current_tectonic_motion, line_1_ft_name, current_line_2_ft_name, current_line_1_ft_id, current_line_2_ft_id))
					else:
						final_end_age = new_begin_age + 0.0500
						cur_2.execute(sql_2,(current_begin_age, final_end_age, current_tectonic_motion, line_1_ft_name, current_line_2_ft_name, current_line_1_ft_id, current_line_2_ft_id))
					current_tectonic_motion = new_tectonic_motion
					current_begin_age = new_begin_age
					current_line_2_ft_name = new_line_2_ft_name
					current_line_1_ft_id = new_line_1_ft_id
					current_line_2_ft_id = new_line_2_ft_id
				row = cur.fetchone()
			row_1 = cur_1.fetchone()
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_tectonic_boundaries")
		print(error)
	
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_database_table_tectonic_boundaries_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def extract_plate_tectonic_margins_from_database_table_tectonic_boundaries_and_motion(initial_CON_OCN_geological_topological_line_feature_file,time_interval,modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins for the CON-OCN geological topological line features at each reconstruction time 
		Input: database table tectonic_boundaries and tectonic_motion when we process plate boundaries identification 
				initial_CON_OCN_geological_topological_line_feature that we use as the input when we process plate boundaries identification"""
	
	initial_CON_OCN_features = pygplates.FeatureCollection(initial_CON_OCN_geological_topological_line_feature_file)
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	
	txt_1 = """SELECT DISTINCT line_1_ft_name,line_2_ft_name,ref_gdu_id,other_gdu_id FROM tectonic_boundaries"""
	txt_4 = """SELECT DISTINCT line_1_ft_name,line_2_ft_name FROM tectonic_boundaries WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))  and time > {input_time}"""
	txt = """SELECT time, tectonic_motion FROM tectonic_boundaries WHERE line_1_ft_name = {input_line_1_ft_name} and line_2_ft_name = {input_line_2_ft_name} ORDER BY time DESC"""
	sql_2 = """INSERT INTO not_found_tectonic_boundaries(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	sql_3 = """INSERT INTO summary_of_tectonic_boundaries_and_motion(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		cur_1.execute(txt_1)
		row_1 = cur_1.fetchone()
		while (row_1 is not None):
			line_1_ft_name = row_1[0]
			line_2_ft_name = row_1[1]
			ref_gdu_id = int(row_1[2])
			other_gdu_id = int(row_1[3])
			sql = txt.format(input_line_1_ft_name = '\''+line_1_ft_name+'\'',input_line_2_ft_name = '\''+line_2_ft_name+'\'')
			cur.execute(sql)
			row = cur.fetchone()
			#print("here is row",row)
			current_tectonic_motion = None
			current_begin_age = -1.00
			while (row is not None):
				#print(row)
				new_tectonic_motion = row[1]
				new_begin_age = float(row[0])
				#print("new_line_2_ft_name", new_line_2_ft_name)
				if (current_tectonic_motion is None):
					current_tectonic_motion = new_tectonic_motion
					current_begin_age = new_begin_age
				elif (current_tectonic_motion != new_tectonic_motion):
					#find the two line features 
					line_ft_1 = initial_CON_OCN_features.get(lambda ft: ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.first)
					line_ft_2 = initial_CON_OCN_features.get(lambda ft: ft.get_name() == line_2_ft_name, pygplates.FeatureReturn.first)
					plate_tectonic_margin_ft_1 = None
					plate_tectonic_margin_ft_2 = None
					sub_line_1_ft_name = None
					sub_line_2_ft_name = None
					final_end_age = new_begin_age
					if (current_begin_age == new_begin_age):
						final_end_age = current_begin_age - time_interval
					if (line_ft_1 is not None and line_ft_2 is not None):
						if (current_tectonic_motion == "Convergence"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_1.get_geometry(), name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_2.get_geometry(), name = line_2_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						elif (current_tectonic_motion == "Divergence"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_1.get_geometry(), name = line_1_ft_name, description = "divergent_margin", valid_time = (current_begin_age,final_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_2.get_geometry(), name = line_2_ft_name, description = "divergent_margin", valid_time = (current_begin_age,final_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						elif (current_tectonic_motion == "Transform"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_1.get_geometry(), name = line_1_ft_name, description = "transform_fault", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_2.get_geometry(), name = line_2_ft_name, description = "transform_fault", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						else:
							print("current_tectonic_motion",current_tectonic_motion)
						print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
					elif (line_ft_1 is None and line_ft_2 is None):
						sql_4 = txt_4.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_time = new_begin_age)
						cur_4.execute(sql_4)
						row_4 = cur_4.fetchone()
						if (row_4 is None):
							print("Error because cannot find substitute line features", line_1_ft_name, line_2_ft_name, ref_gdu_id, other_gdu_id, current_begin_age, new_begin_age)
							exit()
						sub_line_1_ft_name = row_4[0]
						sub_line_2_ft_name = row_4[1]
						
						line_ft_1 = initial_CON_OCN_features.get(lambda ft: ft.get_name() == sub_line_1_ft_name, pygplates.FeatureReturn.first)
						line_ft_2 = initial_CON_OCN_features.get(lambda ft: ft.get_name() == sub_line_2_ft_name, pygplates.FeatureReturn.first)
						while(line_ft_1 is None and line_ft_2 is None and row_4 is not None):
							row_4 = cur_4.fetchone()
							sub_line_1_ft_name = row_4[0]
							sub_line_2_ft_name = row_4[1]
							line_ft_1 = initial_CON_OCN_features.get(lambda ft: ft.get_name() == sub_line_1_ft_name, pygplates.FeatureReturn.first)
							line_ft_2 = initial_CON_OCN_features.get(lambda ft: ft.get_name() == sub_line_2_ft_name, pygplates.FeatureReturn.first)
						if (line_ft_1 is not None and line_ft_2 is not None):
							if (current_tectonic_motion == "Convergence"):
								plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_1.get_geometry(), name = sub_line_1_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
								plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_2.get_geometry(), name = sub_line_2_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
								plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
								plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
								plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
								plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
							elif (current_tectonic_motion == "Divergence"):
								plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_1.get_geometry(), name = sub_line_1_ft_name, description = "divergent_margin", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
								plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_2.get_geometry(), name = sub_line_2_ft_name, description = "divergent_margin", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
								plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
								plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
								plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
								plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
							elif (current_tectonic_motion == "Transform"):
								plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_1.get_geometry(), name = sub_line_1_ft_name, description = "transform_fault", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
								plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_2.get_geometry(), name = sub_line_2_ft_name, description = "transform_fault", valid_time = (current_begin_age, final_end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
								plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
								plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
								plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
								plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					if (plate_tectonic_margin_ft_1 is not None and plate_tectonic_margin_ft_2 is not None):
						print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
						output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
						output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
						if (sub_line_1_ft_name is not None and sub_line_2_ft_name is not None):
							cur_3.execute(sql_3,(current_begin_age, final_end_age, current_tectonic_motion, sub_line_1_ft_name,sub_line_2_ft_name, ref_gdu_id, other_gdu_id))
						else:
							cur_3.execute(sql_3,(current_begin_age, final_end_age, current_tectonic_motion, line_1_ft_name,line_2_ft_name, ref_gdu_id, other_gdu_id))
						current_tectonic_motion = new_tectonic_motion
						current_begin_age = new_begin_age
					else:
						print("Error could not find line_ft_1 and line_ft_2", line_1_ft_name, line_2_ft_name, current_begin_age)
						exit()
				row = cur.fetchone()
			row_1 = cur_1.fetchone()
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_tectonic_boundaries")
		print(error)
	
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_database_table_tectonic_boundaries_and_motion_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def extract_plate_tectonic_margins_from_database_table_summary_of_not_initially_recorded_tectonic_boundaries(tectonic_boundaries_feature_file,time_interval,modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins for the CON-OCN geological topological line features at each reconstruction time 
		Input: database table tectonic_boundaries when we process plate boundaries identification 
				initial_CON_OCN_geological_topological_line_feature that we use as the input when we process plate boundaries identification"""
	
	tectonic_boundaries_features = pygplates.FeatureCollection(tectonic_boundaries_feature_file)
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	
	txt_1 = """SELECT DISTINCT line_1_ft_name FROM summary_of_not_initially_recorded_tectonic_boundaries"""
	txt = """SELECT from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id FROM summary_of_not_initially_recorded_tectonic_boundaries WHERE line_1_ft_name = {input_line_1_ft_name} ORDER BY from_time DESC"""
	
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur = conn.cursor()
		cur_1.execute(txt_1)
		row_1 = cur_1.fetchone()
		while (row_1 is not None):
			line_1_ft_name = row_1[0]
			sql = txt.format(input_line_1_ft_name = '\''+line_1_ft_name+'\'')
			cur.execute(sql)
			row = cur.fetchone()
			while (row is not None):
				#print(row)
				tectonic_motion = row[2]
				begin_age = float(row[0])
				end_age = float(row[1])
				if (end_age - begin_age > 0.00):
					end_age = begin_age - time_interval
				left_id = int(row[3])
				right_id = int(row[4])
				line_ft_1 = tectonic_boundaries_features.get(lambda ft: ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.first)
				plate_tectonic_margin_ft_1 = None
				if (tectonic_motion == "Convergence"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_1.get_geometry(), name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (begin_age, end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_1.set_left_plate(left_id)
					plate_tectonic_margin_ft_1.set_right_plate(right_id)
				elif (tectonic_motion == "Divergence"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_1.get_geometry(), name = line_1_ft_name, description = "divergent_margin", valid_time = (begin_age, end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_1.set_left_plate(left_id)
					plate_tectonic_margin_ft_1.set_right_plate(right_id)
				elif (tectonic_motion == "Transform"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_1.get_geometry(), name = line_1_ft_name, description = "transform_fault", valid_time = (begin_age, end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_1.set_left_plate(left_id)
					plate_tectonic_margin_ft_1.set_right_plate(right_id)
				else:
					print("current_tectonic_motion",current_tectonic_motion)
				print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
				if (plate_tectonic_margin_ft_1 is None):
					print("error in extract_plate_tectonic_margins_from_database_table_summary_of_not_initially_recorded_tectonic_boundaries")
					print("error plate_tectonic_margin_ft_1 is None")
					print("line_ft_1", line_ft_1)
					print("tectonic_motion",tectonic_motion)
				output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
				
				row = cur.fetchone()
			row_1 = cur_1.fetchone()
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_summary_of_not_initially_recorded_tectonic_boundaries")
		print(error)
	
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_database_table_summary_of_not_initially_recorded_tectonic_boundaries_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")



def extract_plate_tectonic_margins_from_database_table_not_recorded_tectonic_boundaries_during_identification(temporal_tectonic_boundaries_previously_not_recorded_file, time_interval, modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins from the temporary output file for tectonic boundaries that were not recorded to the database during the identification
		Input: database table not_recorded_tectonic_boundaries_during_identification
				temporal output file for not recorded tectonic boundaries
				time_interval is the time interval when we identify tectonic_boundaries"""
	temporal_tectonic_boundaries_features = pygplates.FeatureCollection(temporal_tectonic_boundaries_previously_not_recorded_file)
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	
	txt_1 = """SELECT DISTINCT line_1_ft_name FROM not_recorded_tectonic_boundaries_during_identification"""
	txt = """SELECT DISTINCT time, tectonic_motion, ref_gdu_id, other_gdu_id FROM not_recorded_tectonic_boundaries_during_identification WHERE line_1_ft_name = {input_line_1_ft_name} ORDER BY time DESC"""
	sql_3 = """INSERT INTO summary_of_not_initially_recorded_tectonic_boundaries(from_time, to_time, tectonic_motion, line_1_ft_name,ref_gdu_id,other_gdu_id) VALUES (%s, %s, %s, %s, %s, %s)"""
	
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur = conn.cursor()
		cur_3 = conn.cursor()
		cur_1.execute(txt_1)
		row_1 = cur_1.fetchone()
		while (row_1 is not None):
			line_1_ft_name = row_1[0]
			sql = txt.format(input_line_1_ft_name = '\''+line_1_ft_name+'\'')
			cur.execute(sql)
			row = cur.fetchone()
			oldest_age = float(row[0])
			youngest_age = -1.00
			#print("here is row",row)
			current_tectonic_motion = None
			current_begin_age = -1.00
			ref_gdu_id = -1
			other_gdu_id = -1
			#plate_tectonic_margin_ft_1,line_ft_1 = None,None
			all_line_ft_1 = temporal_tectonic_boundaries_features.get(lambda ft: ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.all)
			if (all_line_ft_1 is None):
				print("Error in extract_plate_tectonic_margins_from_database_table_not_recorded_tectonic_boundaries_during_identification")
				print("Error cannot find the record or controversial tectonic motion at the same age")
				print("new_begin_age, line_1_ft_name, ref_gdu_id, other_gdu_id",new_begin_age, line_1_ft_name, ref_gdu_id, other_gdu_id)
				exit()
			count_num_of_times_recorded_new_motion = 0
			while (row is not None):
				#print(row)
				new_tectonic_motion = row[1]
				new_begin_age = float(row[0])
				youngest_age = new_begin_age
				#new_line_1_ft_id = row[2]
				new_ref_gdu_id = int(row[2])
				new_other_gdu_id = int(row[3])
				#print("new_line_2_ft_name", new_line_2_ft_name)
				if (current_tectonic_motion is None):
					current_tectonic_motion = new_tectonic_motion
					current_begin_age = new_begin_age
					#current_line_1_ft_id = new_line_1_ft_id
					ref_gdu_id = new_ref_gdu_id
					other_gdu_id = new_other_gdu_id
				elif (current_tectonic_motion != new_tectonic_motion):
					#find the two line features 
					#line_ft_1 = initial_CON_OCN_features.get(lambda ft: ft.get_feature_id().get_string() == line_1_ft_name or ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.first)
					# if (all_line_ft_1 is not None and current_begin_age != new_begin_age):
						# if (current_tectonic_motion == "Convergence"):
							# plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_1.get_geometry(), name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						# elif (current_tectonic_motion == "Divergence"):
							# plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_1.get_geometry(), name = line_1_ft_name, description = "divergent_margin", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						# elif (current_tectonic_motion == "Transform"):
							# plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_1.get_geometry(), name = line_1_ft_name, description = "transform_fault", valid_time = (current_begin_age, new_begin_age + 0.0500), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						# else:
							# print("not recorded current_tectonic_motion",current_tectonic_motion)
							# exit()
						# print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
						# output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
						# final_end_age = new_begin_age + 0.0500
						# cur_3.execute(sql_3,(current_begin_age, final_end_age, current_tectonic_motion, line_1_ft_name,current_line_1_ft_id, ref_gdu_id,other_gdu_id))
						# plate_tectonic_margin_ft_1,line_ft_1 = None,None
					if (current_begin_age != new_begin_age):
						final_end_age = new_begin_age + 0.0500
						cur_3.execute(sql_3,(current_begin_age, final_end_age, current_tectonic_motion, line_1_ft_name,ref_gdu_id,other_gdu_id))
						count_num_of_times_recorded_new_motion = count_num_of_times_recorded_new_motion + 1
					else:
						print("Error in extract_plate_tectonic_margins_from_database_table_not_recorded_tectonic_boundaries_during_identification")
						print("Error controversial tectonic motion at the same age")
						print("new_begin_age, line_1_ft_name, ref_gdu_id, other_gdu_id",new_begin_age, line_1_ft_name, ref_gdu_id, other_gdu_id)
						exit()
						
					current_tectonic_motion = new_tectonic_motion
					current_begin_age = new_begin_age
					#current_line_1_ft_id = new_line_1_ft_id
					ref_gdu_id = new_ref_gdu_id
					other_gdu_id = new_other_gdu_id
				row = cur.fetchone()

			if (count_num_of_times_recorded_new_motion == 0):
				if (current_begin_age == youngest_age):
					youngest_age = current_begin_age + 0.0500
				cur_3.execute(sql_3,(oldest_age, youngest_age, current_tectonic_motion, line_1_ft_name,ref_gdu_id,other_gdu_id))
				# print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
			elif (count_num_of_times_recorded_new_motion > 0):
				if (current_begin_age == youngest_age):
					youngest_age = current_begin_age + 0.0500
				cur_3.execute(sql_3,(current_begin_age, youngest_age, current_tectonic_motion, line_1_ft_name,ref_gdu_id,other_gdu_id))
				# output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
			row_1 = cur_1.fetchone()
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_not_recorded_tectonic_boundaries_during_identification")
		print(error)
	#output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_database_table_not_recorded_tectonic_boundaries_during_identification_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def extract_plate_tectonic_margins_from_database_table_not_found_tectonic_boundaries(initial_CON_OCN_geological_topological_line_feature_file,modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins for the CON-OCN geological topological line features at each reconstruction time 
		Input: database table not_found_tectonic_boundaries after we extracted information from database table tectonic boundaries and temporal_output files
				initial_CON_OCN_geological_topological_line_feature that we use as the input when we process plate boundaries identification"""
	
	initial_CON_OCN_features = pygplates.FeatureCollection(initial_CON_OCN_geological_topological_line_feature_file)
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	
	txt_1 = """SELECT DISTINCT from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id FROM not_found_tectonic_boundaries ORDER BY from_time DESC"""
	sql_2 = """INSERT INTO not_found_tectonic_boundaries_after_second_run(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	sql_3 = """INSERT INTO summary_of_tectonic_boundaries(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_1.execute(txt_1)
		row_1 = cur_1.fetchone()
		count_fts = 0
		while (row_1 is not None):
			count_fts = count_fts +1
			print("current features that are already processed", count_fts)
			line_1_ft_name = row_1[3]
			line_2_ft_name = row_1[4]
			line_1_ft_id = row_1[5]
			line_2_ft_id = row_1[6]
			line_ft_1 = initial_CON_OCN_features.get(lambda ft: ft.get_feature_id().get_string() == line_1_ft_name or ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.first)
			line_ft_2 = initial_CON_OCN_features.get(lambda ft: ft.get_feature_id().get_string() == line_2_ft_name or ft.get_name() == line_2_ft_name, pygplates.FeatureReturn.first)
			begin_age = float(row_1[0]) 
			end_age = float(row_1[1])
			print("begin and end age", begin_age, end_age)
			current_tectonic_motion = row_1[2]
			plate_tectonic_margin_ft_1 = None
			plate_tectonic_margin_ft_2 = None
			#print(row_1)
			if (line_ft_1 is not None and line_ft_2 is not None and begin_age > end_age):
				if (current_tectonic_motion == "Convergence"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_1.get_geometry(), name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_2.get_geometry(), name = line_2_ft_name, description = "unknown_convergent_margin", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				elif (current_tectonic_motion == "Divergence"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_1.get_geometry(), name = line_1_ft_name, description = "divergent_margin", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_2.get_geometry(), name = line_2_ft_name, description = "divergent_margin", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				elif (current_tectonic_motion == "Transform"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_1.get_geometry(), name = line_1_ft_name, description = "transform_fault", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_2.get_geometry(), name = line_2_ft_name, description = "transform_fault", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				else:
					print("current_tectonic_motion",current_tectonic_motion)
				##print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
				if (plate_tectonic_margin_ft_1 is not None):
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
					cur_3.execute(sql_3,(begin_age, end_age, current_tectonic_motion, line_1_ft_name, line_2_ft_name,line_1_ft_id,line_2_ft_id))
			else:
				cur_2.execute(sql_2,(begin_age, end_age, current_tectonic_motion, line_1_ft_name, line_2_ft_name,line_1_ft_id,line_2_ft_id))
			row_1 = cur_1.fetchone()
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_tectonic_boundaries")
		print(error)
	
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_database_table_not_found_tectonic_boundaries_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")


def extract_plate_tectonic_margins_from_database_table_not_found_tectonic_boundaries_after_first_run(initial_CON_OCN_geological_topological_line_feature_file,modelname, test_number, yearmonthday):
	"""the module is to extract and summarize the type of plate tectonic margins for the CON-OCN geological topological line features at each reconstruction time 
		Input: database table not_found_tectonic_boundaries_after_first_run after we extracted information from database table tectonic boundaries and temporal_output files
				initial_CON_OCN_geological_topological_line_feature that we use as the input when we process plate boundaries identification"""
	
	initial_CON_OCN_features = pygplates.FeatureCollection(initial_CON_OCN_geological_topological_line_feature_file)
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	
	txt_1 = """SELECT from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id FROM not_found_tectonic_boundaries_after_first_run ORDER BY from_time DESC"""
	sql_2 = """INSERT INTO not_found_tectonic_boundaries_after_second_run(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	sql_3 = """INSERT INTO summary_of_tectonic_boundaries(from_time, to_time, tectonic_motion, line_1_ft_name, line_2_ft_name, line_1_ft_id, line_2_ft_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	
	conn = None
	cur = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_1.execute(txt_1)
		row_1 = cur_1.fetchone()
		while (row_1 is not None):
			line_1_ft_name = row_1[3]
			line_2_ft_name = row_1[4]
			line_1_ft_id = row_1[5]
			line_2_ft_id = row_1[6]
			line_ft_1 = initial_CON_OCN_features.get(lambda ft: ft.get_feature_id().get_string() == line_1_ft_name or ft.get_name() == line_1_ft_name, pygplates.FeatureReturn.first)
			line_ft_2 = initial_CON_OCN_features.get(lambda ft: ft.get_feature_id().get_string() == line_2_ft_name or ft.get_name() == line_2_ft_name, pygplates.FeatureReturn.first)
			begin_age = float(row_1[0]) 
			end_age = float(row_1[1])
			current_tectonic_motion = row_1[2]
			plate_tectonic_margin_ft_1 = None
			plate_tectonic_margin_ft_2 = None
			#print(row_1)
			if (line_ft_1 is not None and line_ft_2 is not None and abs(begin_age - end_age) > 0.0500):
				if (current_tectonic_motion == "Convergence"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_1.get_geometry(), name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_ft_2.get_geometry(), name = line_2_ft_name, description = "unknown_convergent_margin", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				elif (current_tectonic_motion == "Divergence"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_1.get_geometry(), name = line_1_ft_name, description = "divergent_margin", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_ft_2.get_geometry(), name = line_2_ft_name, description = "divergent_margin", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				elif (current_tectonic_motion == "Transform"):
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_1.get_geometry(), name = line_1_ft_name, description = "transform_fault", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
					plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_ft_2.get_geometry(), name = line_2_ft_name, description = "transform_fault", valid_time = (begin_age,end_age), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				else:
					print("current_tectonic_motion",current_tectonic_motion)
				print("plate_tectonic_margin_ft_1",plate_tectonic_margin_ft_1)
				output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
				output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
				cur_3.execute(sql_3,(begin_age, end_age, current_tectonic_motion, line_1_ft_name, line_2_ft_name,line_1_ft_id,line_2_ft_id))
			else:
				cur_2.execute(sql_2,(begin_age, end_age, current_tectonic_motion, line_1_ft_name, line_2_ft_name,line_1_ft_id,line_2_ft_id))
			row_1 = cur_1.fetchone()
			conn.commit()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_tectonic_boundaries")
		print(error)
	
	
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_database_table_not_found_tectonic_boundaries_after_first_run_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_motion_and_tectonic_boundaries_and_CON_OCN_line_features(initial_CON_OCN_geological_topological_line_feature_file, uncertainty_time_difference, modelname, test_number, yearmonthday):
	initial_CON_OCN_geological_topological_line_feature = pygplates.FeatureCollection(initial_CON_OCN_geological_topological_line_feature_file)
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	#sql_1 = """SELECT from_time,to_time,tectonic_motion,ref_gdu_id,other_gdu_id FROM summary_of_tectonic_motion WHERE tectonic_motion <> 'Unsure' and tectonic_motion <> 'Unknown' and tectonic_motion <> 'Not_known_yet_2' ORDER BY from_time DESC"""
	sql_1 = """SELECT from_time,to_time,tectonic_motion,ref_gdu_id,other_gdu_id FROM test_summary_of_tectonic_motion ORDER BY from_time DESC"""
	txt_2 = """SELECT line_1_ft_name,line_2_ft_name, time FROM test_tectonic_boundaries 
	WHERE (ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) OR (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}) 
	AND ((time <= {input_from_time} AND time >= {input_to_time}) OR (abs(time - {input_from_time}) <= {input_uncertainty_time_difference}) OR (abs (time - {input_to_time}) <= {input_uncertainty_time_difference}))
	ORDER BY time DESC"""
	txt_2B = """SELECT line_1_ft_name,line_2_ft_name, time FROM test_tectonic_boundaries 
	WHERE (ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) OR (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}) 
	AND ((time <= {input_from_time} AND time >= {input_to_time}) OR (abs(time - {input_from_time}) <= {input_uncertainty_time_difference}) OR (abs (time - {input_to_time}) <= {input_uncertainty_time_difference}))
	AND (tectonic_motion = 'Divergence' or tectonic_motion = 'Convergence')
	ORDER BY time DESC"""
	sql_3 = """INSERT into test_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion(from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id, line_1_ft_name, line_2_ft_name) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_1.execute(sql_1)
		row_1 = cur_1.fetchone()
		while (row_1 is not None):
			from_time = float(row_1[0])
			to_time = float(row_1[1])
			if ((from_time < to_time) and (to_time - from_time) <= 5.50):
				t = from_time
				from_time = to_time
				to_time = t
			tectonic_motion = row_1[2]
			ref_gdu_id = int(row_1[3])
			other_gdu_id = int(row_1[4])
			sql_2 = txt_2.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time, input_uncertainty_time_difference = uncertainty_time_difference, input_tectonic_motion = '\''+tectonic_motion+'\'')
			cur_2.execute(sql_2)
			row_2 = cur_2.fetchone()
			if (row_2 is None): #try again because Divergence or Convergence margins can be used for Transform too
				sql_2 = txt_2B.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_from_time = from_time, input_to_time = to_time, input_uncertainty_time_difference = uncertainty_time_difference)
				cur_2.execute(sql_2)
				row_2 = cur_2.fetchone()
			if (row_2 is not None):
				plate_tectonic_margin_ft_1 = None
				plate_tectonic_margin_ft_2 = None
				line_1_ft_name = row_2[0]
				line_2_ft_name = row_2[1]
				time = float(row_2[2])
				line_ft_1 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_name() == line_1_ft_name and ft.is_valid_at_time(time), pygplates.FeatureReturn.first)
				line_ft_2 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_name() == line_2_ft_name and ft.is_valid_at_time(time), pygplates.FeatureReturn.first)
				sub_line_1_ft_name,sub_line_2_ft_name = None,None
				if (line_ft_1 is None or line_ft_2 is None):
					cur_5 = conn.cursor()
					txt_5 = None
					sql_5 = None
					# if (tectonic_motion == 'Transform' or tectonic_motion == 'Convergence' or tectonic_motion == 'Divergence'):
						# txt_5 = """SELECT line_1_ft_name,line_2_ft_name FROM tectonic_boundaries 
						# WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))
						# AND time > {input_time} AND tectonic_motion = {input_tectonic_motion}"""
						# sql_5 = txt_5.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_time = time,	 input_tectonic_motion = '\''+tectonic_motion+'\'')
					# else:
						# txt_5 = """SELECT line_1_ft_name,line_2_ft_name FROM tectonic_boundaries 
						# WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))
						# AND time > {input_time}"""
					txt_5 = """SELECT line_1_ft_name,line_2_ft_name FROM tectonic_boundaries 
						WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))
						AND time > {input_time}"""
					sql_5 = txt_5.format(input_ref_gdu_id = ref_gdu_id, input_other_gdu_id = other_gdu_id, input_time = time)
					cur_5.execute(sql_5)
					row_5 = cur_5.fetchone()
					if (row_5 is None):
						print("Error in extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_motion_and_tectonic_boundaries_and_CON_OCN_line_features")
						print("Error cannot find appropriate CON-OCN line features for ref_gdu_id, other_gdu_id, time", ref_gdu_id, other_gdu_id, time)
						exit()
					sub_line_1_ft_name = row_5[0]
					sub_line_2_ft_name = row_5[1]
					all_line_ft_1 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_name() == sub_line_1_ft_name, pygplates.FeatureReturn.all)
					final_line_ft_1 = None
					for potential_line_ft_1 in all_line_ft_1:
						if (potential_line_ft_1.is_valid_at_time(time)):
							final_line_ft_1 = potential_line_ft_1
							break
					all_line_ft_2 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_name() == sub_line_2_ft_name, pygplates.FeatureReturn.all)
					final_line_ft_2 = None
					for potential_line_ft_2 in all_line_ft_2:
						if (potential_line_ft_2.is_valid_at_time(time)):
							final_line_ft_2 = potential_line_ft_2
							break
					if (final_line_ft_1 is not None and final_line_ft_2 is not None):
						#I have no idea why and how there are multiple geometries for the line ft.
						#Since it is possible for a ft to have a multiple geometry for a line ft, take the line has the longest length (approx in rads)
						line_1,line_2 = None,None
						len_of_current_geom = -1.0
						for geom in final_line_ft_1.get_geometries():
							if (geom.get_arc_length() > len_of_current_geom):
								len_of_current_geom = geom.get_arc_length()
								line_1 = geom
						len_of_current_geom = -1.0
						for geom in final_line_ft_2.get_geometries():
							if (geom.get_arc_length() > len_of_current_geom):
								len_of_current_geom = geom.get_arc_length()
								line_2 = geom
						if (tectonic_motion == "Convergence"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_1, name = sub_line_1_ft_name, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_2, name = sub_line_2_ft_name, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						elif (tectonic_motion == "Divergence"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = sub_line_1_ft_name, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = sub_line_2_ft_name, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						elif (tectonic_motion == "Transform"):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_1, name = sub_line_1_ft_name, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_2, name = sub_line_2_ft_name, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						elif (tectonic_motion == 'Unknown'):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = sub_line_1_ft_name, description = "unknown", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = sub_line_2_ft_name, description = "unknown", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						elif (tectonic_motion == 'Unknown_fluct_motion'):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = sub_line_1_ft_name, description = "unknown_fluct_motion", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = sub_line_2_ft_name, description = "unknown_fluct_motion", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						elif (tectonic_motion == 'Unknown_rapid_fluct_motion'):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = sub_line_1_ft_name, description = "unknown_rapid_fluct_motion", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = sub_line_2_ft_name, description = "unknown_rapid_fluct_motion", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
						elif (tectonic_motion == 'Unknown_same_motion'):
							plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = sub_line_1_ft_name, description = "unknown_same_motion", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
							
							plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = sub_line_2_ft_name, description = "unknown_same_motion", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
							plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
							plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
							
						cur_3.execute(sql_3, (from_time,to_time,tectonic_motion,ref_gdu_id,other_gdu_id,sub_line_1_ft_name,sub_line_2_ft_name))
						output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
						output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
				else:
					#print(line_ft_1.get_geometries(),line_ft_2.get_geometries())
					#I have no idea why and how there are multiple geometries for the line ft.
					#Since it is possible for a ft to have a multiple geometry for a line ft, take the line has the longest length (approx in rads)
					line_1,line_2 = None,None
					len_of_current_geom = -1.0
					for geom in line_ft_1.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_1 = geom
					len_of_current_geom = -1.0
					for geom in line_ft_2.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_2 = geom
					if (tectonic_motion == "Convergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,line_1, name = line_1_ft_name, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,line_2, name = line_2_ft_name, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					elif (tectonic_motion == "Divergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_1, name = line_1_ft_name, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_2, name = line_2_ft_name, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					elif (tectonic_motion == "Transform"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,line_1, name = line_1_ft_name, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,line_2, name = line_2_ft_name, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					elif (tectonic_motion == 'Unknown'):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = line_1_ft_name, description = "unknown", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = line_2_ft_name, description = "unknown", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					elif (tectonic_motion == 'Unknown_fluct_motion'):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = line_1_ft_name, description = "unknown_fluct_motion", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = line_2_ft_name, description = "unknown_fluct_motion", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					elif (tectonic_motion == 'Unknown_rapid_fluct_motion'):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = line_1_ft_name, description = "unknown_rapid_fluct_motion", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = line_2_ft_name, description = "unknown_rapid_fluct_motion", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					elif (tectonic_motion == 'Unknown_same_motion'):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = line_1_ft_name, description = "unknown_same_motion", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = line_2_ft_name, description = "unknown_same_motion", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
					cur_3.execute(sql_3, (from_time,to_time,tectonic_motion,ref_gdu_id,other_gdu_id,line_1_ft_name,line_2_ft_name))
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
					output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
			conn.commit()
			row_1 = cur_1.fetchone()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_motion_and_tectonic_boundaries_and_CON_OCN_line_features")
		print(error)
	
	
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_motion_and_tectonic_boundaries_and_CON_OCN_line_fts_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")


def extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion(initial_CON_OCN_geological_topological_line_feature_file, modelname, test_number, yearmonthday):
	initial_CON_OCN_geological_topological_line_feature = pygplates.FeatureCollection(initial_CON_OCN_geological_topological_line_feature_file)
	output_plate_tectonic_margin_fts = pygplates.FeatureCollection()
	sql_1 = """SELECT  from_time, to_time, tectonic_motion, ref_gdu_id, other_gdu_id, line_1_ft_name, line_2_ft_name FROM summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion ORDER BY from_time DESC"""
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur_1 = conn.cursor()
		cur_1.execute(sql_1)
		row_1 = cur_1.fetchone()
		while (row_1 is not None):
			from_time = float(row_1[0])
			to_time = float(row_1[1])
			tectonic_motion = row_1[2]
			ref_gdu_id = int(row_1[3])
			other_gdu_id = int(row_1[4])
			line_1_ft_name = row_1[5]
			line_2_ft_name = row_1[6]
			plate_tectonic_margin_ft_1 = None
			plate_tectonic_margin_ft_2 = None
			line_ft_1 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_name() == line_1_ft_name , pygplates.FeatureReturn.first)
			line_ft_2 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_name() == line_2_ft_name , pygplates.FeatureReturn.first)
			final_line_ft_1,final_line_ft_2 = line_ft_1,line_ft_2
			# all_possible_fts_1 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_reconstruction_plate_id() == line_ft_1.get_reconstruction_plate_id(), pygplates.FeatureReturn.all)
			# for line_ft in all_possible_fts_1:
				# if (line_ft.is_valid_at_time(from_time) and line_ft.is_valid_at_time(to_time)):
					# final_line_ft_1 = line_ft
					# break
				# elif (line_ft.is_valid_at_time(from_time)):
					# final_line_ft_1 = line_ft
					# break
			# all_possible_fts_2 = initial_CON_OCN_geological_topological_line_feature.get(lambda ft: ft.get_reconstruction_plate_id() == line_ft_2.get_reconstruction_plate_id(), pygplates.FeatureReturn.all)
			# for line_ft in all_possible_fts_2:
				# if (line_ft.is_valid_at_time(from_time) and line_ft.is_valid_at_time(to_time)):
					# final_line_ft_2 = line_ft
					# break
				# elif (line_ft.is_valid_at_time(from_time)):
					# final_line_ft_2 = line_ft
					# break
			if (final_line_ft_1 is None or final_line_ft_2 is None):
				print("Error in extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion")
				print("Cannot find final_line_ft_1 and/or final_line_ft_2 for line_1_ft_name, line_2_ft_name, from_time, to_time:",line_1_ft_name,line_2_ft_name,from_time,to_time, line_ft_1.get_reconstruction_plate_id(), line_ft_2.get_reconstruction_plate_id())
				exit()
			if (tectonic_motion == "Convergence"):
				plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,final_line_ft_1.get_geometry(), name = final_line_ft_1.get_name(), description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
				plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
				plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
				plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,final_line_ft_2.get_geometry(), name = final_line_ft_2.get_name(), description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
				plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
			elif (tectonic_motion == "Divergence"):
				plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,final_line_ft_1.get_geometry(), name = final_line_ft_1.get_name(), description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
				plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
				plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
				plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,final_line_ft_2.get_geometry(), name = final_line_ft_2.get_name(), description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
				plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
			elif (tectonic_motion == "Transform"):
				plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,final_line_ft_1.get_geometry(), name = final_line_ft_1.get_name(), description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_1.get_reconstruction_plate_id())
				plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
				plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
				
				plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,final_line_ft_2.get_geometry(), name = final_line_ft_2.get_name(), description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = line_ft_2.get_reconstruction_plate_id())
				plate_tectonic_margin_ft_2.set_left_plate(ref_gdu_id)
				plate_tectonic_margin_ft_2.set_right_plate(other_gdu_id)
			output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_1)
			output_plate_tectonic_margin_fts.add(plate_tectonic_margin_ft_2)
			row_1 = cur_1.fetchone()
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion")
		print(error)
	
	
	output_plate_tectonic_margin_fts.write("extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion_"+modelname+"_"+str(test_number)+"_"+yearmonthday+".gpml")

def update_Unknown_summary_of_tectonic_motion():
	txt = """SELECT initial_ft_id FROM tectonic_topological_line_fts WHERE ((lef_gdu_id = {input_left_gdu_id} and right_gdu_id = {input_right_gdu_id}) 
							 or (lef_gdu_id = {input_right_gdu_id} and right_gdu_id = {input_left_gdu_id})) 
						AND ((to_time < {input_from_time} and from_time >= {input_from_time} and to_time < {input_to_time})
							  OR (to_time <= {input_to_time} and from_time > {input_to_time} and from_time <= {input_from_time})) 
						AND type_of_line_fts = 'CON_OCN' ORDER BY from_time DESC """
	txt_1 = """SELECT ref_gdu_id, input_other_gdu_id,from_time,to_time FROM summary_of_tectonic_motion 
				WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or 
					 (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))
				and tectonic_motion = 'Unknown' """
	txt_2 = """UPDATE summary_of_tectonic_motion 
				SET tectonic_motion = {input_motion}
				WHERE ((ref_gdu_id = {input_ref_gdu_id} and other_gdu_id = {input_other_gdu_id}) or (ref_gdu_id = {input_other_gdu_id} and other_gdu_id = {input_ref_gdu_id}))
				and ABS(to_time == {input_to_time} AND from_time = {input_from_time} and tectonic_motion = 'Unknown'"""

def set_all_unclassified_CON_OCN_line_features_to_passive_continental_bdn_without_divergence(initial_CON_OCN_line_features_file,clean_up_messy_tectonic_bdn_file,output_filename):
	output_unclassified_fts = pygplates.FeatureCollection()
	clean_up_messy_tectonic_bdn_fts = pygplates.FeatureCollection(clean_up_messy_tectonic_bdn_file)
	initial_CON_OCN_line_features = pygplates.FeatureCollection(initial_CON_OCN_line_features_file)
	try:
		params = config()
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		for CON_OCN_line_ft in initial_CON_OCN_line_features:
			gdu_id = CON_OCN_line_ft.get_reconstruction_plate_id()
			line = CON_OCN_line_ft.get_geometry()
			initial_name = CON_OCN_line_ft.get_name()
			CON_OCN_begin,CON_OCN_end = CON_OCN_line_ft.get_valid_time()
			bdn_ft = clean_up_messy_tectonic_bdn_fts.get(lambda ft: ft.get_name() == initial_name , pygplates.FeatureReturn.first)
			if (bdn_ft is None):
				# txt = """SELECT tectonic_motion, ref_gdu_id, other_gdu_id, from_time, to_time FROM test_summary_of_tectonic_motion 
							# WHERE (ref_gdu_id = {input_ref_gdu_id} or other_gdu_id = {input_ref_gdu_id}) 
							 # AND ((to_time < {input_from_time} and from_time >= {input_from_time} and to_time < {input_to_time})
							  # OR (to_time <= {input_to_time} and from_time > {input_to_time} and from_time <= {input_from_time})
							  # OR (from_time >= {input_from_time} and to_time <= {input_to_time})) """
				txt = """SELECT tectonic_motion, ref_gdu_id, other_gdu_id, from_time, to_time FROM test_summary_of_tectonic_motion 
							WHERE (ref_gdu_id = {input_ref_gdu_id} or other_gdu_id = {input_ref_gdu_id}) 
							 AND (({input_from_time} < to_time and {input_from_time} >= from_time and {input_to_time} < to_time)
							  OR ({input_to_time} <= to_time and {input_to_time}> from_time and {input_from_time} <= from_time)
							  OR ({input_from_time} >= from_time and {input_to_time} <= to_time)) """
				sql = txt.format(input_ref_gdu_id = gdu_id, input_from_time = CON_OCN_begin, input_to_time = CON_OCN_end)
				cur.execute(sql)
				row = cur.fetchone()
				while (row is not None):
					tectonic_motion = row[0]
					ref_gdu_id = row[1]
					other_gdu_id = row[2]
					tectonic_from_time = float(row[3])
					tectonic_to_time = float(row[4])
					if (tectonic_from_time < tectonic_to_time and abs(tectonic_from_time - tectonic_to_time) < 1.00):
						tectonic_from_time = tectonic_to_time
					print("tectonic_from_time,tectonic_to_time", tectonic_from_time, tectonic_to_time)
					plate_tectonic_margin_ft_1 = None
					if (tectonic_motion == "Convergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,line, name = initial_name, description = "unknown_convergent_margin", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						
					elif (tectonic_motion == "Divergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line, name = initial_name, description = "divergent_margin", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						
					elif (tectonic_motion == "Transform"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform,line, name = initial_name, description = "transform_fault", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						
					elif (tectonic_motion == 'Unknown'):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line, name = initial_name, description = "unknown", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						
					elif (tectonic_motion == 'Unknown_fluct_motion'):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line, name = initial_name, description = "unknown_fluct_motion", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						
					elif (tectonic_motion == 'Unknown_rapid_fluct_motion'):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line, name = initial_name, description = "unknown_rapid_fluct_motion", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
						
					elif (tectonic_motion == 'Unknown_same_motion'):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line, name = initial_name, description = "unknown_same_motion", valid_time = (tectonic_from_time, tectonic_to_time), reconstruction_plate_id = gdu_id)
						plate_tectonic_margin_ft_1.set_left_plate(ref_gdu_id)
						plate_tectonic_margin_ft_1.set_right_plate(other_gdu_id)
						
					if (plate_tectonic_margin_ft_1 is not None):
						output_unclassified_fts.add(plate_tectonic_margin_ft_1)
					row = cur.fetchone()
		output_unclassified_fts.write(output_filename)
	except (psycopg2.DatabaseError) as error:
		print("Error in set_all_unclassified_CON_OCN_line_features_to_passive_continental_bdn_without_divergence")
		print(error)
#def infer_margin_with_unknown_description_and_tectonic_boundaries_table():
	# initial_CON_OCN_line_features = pygplates.FeatureCollection(initial_CON_OCN_line_features_file)
	# txt = """SELECT * FROM summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion WHERE line_1_ft_name = {initial_line_ft_name} or line_2_ft_name = {initial_line_ft_name} """
	# try:
		# params = config()
		# conn = psycopg2.connect(**params)
		# cur = conn.cursor()
		# for CON_OCN_line_ft in initial_CON_OCN_line_features:
			# initial_name = CON_OCN_line_ft.get_name()
			# sql = txt.format(initial_line_ft_name = '\''+initial_name+'\'')
			# cur.execute(sql)
			# row = cur.fetchone()
			# if (row is None):
				# CON_OCN_line_ft.set_description('unclassified')
				# output_unclassified_fts.add(CON_OCN_line_ft)
		# output_unclassified_fts.write(output_filename)
	# except (psycopg2.DatabaseError) as error:
		# print("Error in set_all_unclassified_CON_OCN_line_features_to_passive_continental_bdn_without_divergence")
		# print(error)

