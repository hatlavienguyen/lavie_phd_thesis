import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import evaluate_tectonic_motion as tectonic_motion 
import identify_kinematic_boundaries as identify_bdn

test_line_features_file = r"C:\Users\lavie\Desktop\Research\Fall2022\line_topology_qgis_geopandas_shapely\example_13_younger_div_merged_POLYGID_joined_line_fts_3420_0_All_PalaeoPlatesJan2023.shp"
test_line_features = pygplates.FeatureCollection(test_line_features_file)
rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)
reference = 700
time_interval = 5.00
reconstruction_time = 0.00
reconstructed_current_div_line_features = []
if (reference is not None):
	pygplates.reconstruct(test_line_features, rotation_model, reconstructed_current_div_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
else:
	pygplates.reconstruct(test_line_features, rotation_model, reconstructed_current_div_line_features, reconstruction_time, group_with_feature = True)
final_current_reconstructed_line_features = identify_bdn.find_final_reconstructed_geometries(reconstructed_current_div_line_features, pygplates.PolylineOnSphere)
current_reconstr_ft_1, current_reconstr_line_1 = final_current_reconstructed_line_features[0]
current_reconstr_ft_2, current_reconstr_line_2 = final_current_reconstructed_line_features[1]

reconstructed_prev_div_line_features = []
if (reference is not None):
	pygplates.reconstruct(test_line_features, rotation_model, reconstructed_prev_div_line_features, reconstruction_time + time_interval, anchor_plate_id = reference, group_with_feature = True)
else:
	pygplates.reconstruct(test_line_features, rotation_model, reconstructed_prev_div_line_features, reconstruction_time + time_interval, group_with_feature = True)
final_prev_reconstructed_line_features = identify_bdn.find_final_reconstructed_geometries(reconstructed_prev_div_line_features,pygplates.PolylineOnSphere)
prev_reconstr_ft_1,prev_reconstr_line_1 = final_prev_reconstructed_line_features[0]
prev_reconstr_ft_2,prev_reconstr_line_2 = final_prev_reconstructed_line_features[1]

reconstructed_point_A_at_from_time = prev_reconstr_line_1.get_centroid()
reconstructed_point_B_at_from_time = prev_reconstr_line_2.get_centroid()
reconstructed_point_A_at_to_time = current_reconstr_line_1.get_centroid()
reconstructed_point_B_at_to_time = current_reconstr_line_2.get_centroid()
result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_pos_and_angular_vel_vec(reconstructed_point_A_at_from_time, reconstructed_point_A_at_to_time, reconstructed_point_B_at_from_time, reconstructed_point_B_at_to_time, reconstruction_time+time_interval, reconstruction_time)
print('result_of_tectonic_motion',result_of_tectonic_motion)


