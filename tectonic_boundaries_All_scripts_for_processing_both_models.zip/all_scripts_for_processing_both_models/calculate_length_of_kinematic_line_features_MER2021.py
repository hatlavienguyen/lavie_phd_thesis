import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import calculate_length_of_kinematic_line_features as calculate_len
import os
import geopandas as gpd
import pandas as pd

def main():
	#Merdith et al 2021
	#subduction_line_features_file = r"extract_features_based_on_featType_subduction_zone_Merdith_et_al_2021_1000_0Ma_20230722.shp"
	#MOR_line_features_file = r"final_unique_kine_line_feats_test_1_EB2022_20240811.shp"
	#div_line_features_file = r"extract_features_based_on_descriptionunique_div_margins_EB2022_995_0Ma_from_test_8_identify_div_and_test_12_identify_conv_bdn_20240823.shp"
	conv_line_features_file = r"extract_features_based_on_descriptionunique_conv_margins_EB2022_995_0Ma_from_test_8_identify_div_and_test_12_identify_conv_bdn_20240823.shp"
	#CON_line_features = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_segment_POLYGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230921.shp"
	#passive_margin_line_features_file = r"passive_margins_from_patterns_of_unique_kin_line_fts_test_3_PalaeoPlatesendJan2023_20240409.shp"
	line_features = pygplates.FeatureCollection(conv_line_features_file)
	begin_reconstruction_time = 995.0
	end_reconstruction_time = 0.00
	time_interval = 5.00
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/1000_0_rotfile_Merdith_et_al.rot"
	#rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 0
	epsg_code = 'ESRI:54032'
	name_of_line_features = 'divergent_margins'
	modelname = 'Merdith_et_al_2021'
	yearmonthday = '20240823'
	#calculate_len.reconstruct_line_features_to_each_reconstruction_time_and_calculate_length(line_features, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, epsg_code, name_of_line_features, yearmonthday)
	
	common_shp_filename_for_reconstructed_line_feat = r"lengthm_w_Geopandas_divergent_margins_{age}_20240823.shp"
	#for various kinematic types
	#perform_simple_statistics_on_length_of_each_kin_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday)
	#for con_ocn line_features
	name_of_line_feat = 'divergent_margins'
	calculate_len.perform_simple_statistics_on_length_of_same_type_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, name_of_line_feat, modelname, yearmonthday)
	
	# common_shp_filename_for_reconstructed_line_feat = r"lengthm_w_Geopandas_subduction_zone_{age}_20240413.shp"
	# name_of_line_feat = "subduction_zone"
	# calculate_len.perform_simple_statistics_on_length_of_same_type_line_feat_at_each_time(common_shp_filename_for_reconstructed_line_feat, begin_reconstruction_time, end_reconstruction_time, time_interval, name_of_line_feat, modelname, yearmonthday)
	
	
if __name__=="__main__":
	main()