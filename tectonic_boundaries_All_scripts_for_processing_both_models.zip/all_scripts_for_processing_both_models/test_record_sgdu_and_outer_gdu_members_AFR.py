import identify_kinematic_boundaries as kin
import pygplates

def main():
	rotation_file = r'/globalhome/hon686/HPC/Geology/Research/Fall2022/PalaeoPlatesendOct2022/superGDU/T_Rot_Model_PalaeoPlates_20221018.grot'
	rotation_model = pygplates.RotationModel(rotation_file)
	gdu_features_file = r'test_3_PalaeoPlatesendOct2022_w_fid_and_polygid_20230115.shp'
	gdu_features_collection = pygplates.FeatureCollection(gdu_features_file)
	line_features_file = r'/globalhome/hon686/HPC/Geology/Research/Fall2022/PalaeoPlatesendOct2022/examine_line_topology/simple_con_ocn_line_fts_for_segmented_AFR_PalaeoPlatesendOct2022_20230105.shp'
	line_features_collection = pygplates.FeatureCollection(line_features_file)
	sgdu_features_file = r'/globalhome/hon686/HPC/Geology/Research/Fall2022/PalaeoPlatesendOct2022/superGDU/final_supergdu_feats_3420.0_0.0_test_5_PalaeoPlatesendOct2022_20221208.shp'
	super_gdu_features_collection = pygplates.FeatureCollection(sgdu_features_file)
	common_filename_for_temporary_sgdu_and_members_csv = r'/globalhome/hon686/HPC/Geology/Research/Fall2022/PalaeoPlatesendOct2022/superGDU/supergdu_and_members_gdu_at_{time}_for_PalaeoPlatesOct2022_20221126.csv'
	common_filename_for_invalid_con_ocn_line_csv = r'/globalhome/hon686/HPC/Geology/Research/Fall2022/PalaeoPlatesendOct2022/examine_line_topology/invalid_con_ocn_line_ft_at_each_time_AFR_PalaeoPlatesendOct2022_w_v2_20230107.csv'
	sgdu_distance_csv = None
	maximum_accepted_angle_in_degrees = 45.00
	threshold_distance_in_km = 100.00
	begin_reconstruction_time = 3420.00
	end_reconstruction_time = 0.00
	time_interval = 5.00
	modelname = 'AFR_PalaeoPlatesOct2022'
	yearmonthday = '20230113'
	reference = 700
	kin.find_and_record_valid_sgdus_and_outer_gdu_members_at_each_reconstruction_time(rotation_model, gdu_features_collection, line_features_collection, super_gdu_features_collection, common_filename_for_temporary_sgdu_and_members_csv, common_filename_for_invalid_con_ocn_line_csv, sgdu_distance_csv, maximum_accepted_angle_in_degrees, threshold_distance_in_km, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, modelname,yearmonthday)

if __name__ == '__main__':
	main()