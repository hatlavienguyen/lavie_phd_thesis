import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import psycopg2
from config_plate_tectonics import config
def create_plate_tectonic_boundaries_from_database_table_tectonic_motion(name_of_table_for_pairs_of_line_features_at_each_time, name_for_table_for_summary_tectonic_boundary, line_features_collection, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	txt = """SELECT DISTINCT time, ref_ft_id, neighbour_ft_id, tectonic_motion FROM {input_name_of_table_for_pairs_of_line_features_at_each_time} 
			WHERE time = {input_time} AND (tectonic_motion != 'Invalid') ORDER BY time DESC"""
	txt_1 = """SELECT DISTINCT time, tectonic_motion FROM {input_name_of_table_for_pairs_of_line_features_at_each_time}
				WHERE ((ref_ft_id = '{input_ref_ft_id}' 
						AND neighbour_ft_id = '{input_neighbour_ft_id}')
					   OR (ref_ft_id = '{input_neighbour_ft_id}' 
							AND neighbour_ft_id = '{input_ref_ft_id}'))
					 AND ({input_condition_for_tectonic_motion})
					 AND (tectonic_motion != 'Invalid')
					 ORDER BY time DESC """
	txt_2 = """INSERT INTO {input_name_name_for_table_for_summary_tectonic_boundary}(from_time, to_time, tectonic_motion, ref_ft_id, neighbour_ft_id, ref_gdu_id, neighbour_gdu_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	conn = None
	cur = None
	cur_1 = None
	cur_2 = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		dic = {}
		outputFeatureCollection = pygplates.FeatureCollection()
		reconstruction_time = begin_reconstruction_time
		while (reconstruction_time > (end_reconstruction_time - time_interval)):
			sql = txt.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time, input_time = reconstruction_time)
			cur.execute(sql)
			row = cur.fetchone()
			while (row is not None):
				print("row",row)
				time = float(row[0])
				ref_ft_id = row[1]
				neighbour_ft_id = row[2]
				tectonic_motion = row[3]
				key = ref_ft_id+'_'+neighbour_ft_id
				rev_key = neighbour_ft_id+'_'+ref_ft_id
				if (key not in dic and rev_key not in dic):
					dic[key] = []
					sql_1 = None
					if (tectonic_motion == 'Convergence' or tectonic_motion == 'Oblique_convergence'):
						sql_1 = txt_1.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time,input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id, input_condition_for_tectonic_motion = """(tectonic_motion = 'Convergence' or tectonic_motion = 'Oblique_convergence')""")
					elif (tectonic_motion == 'Divergence' or tectonic_motion == 'Oblique_divergence'):
						sql_1 = txt_1.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time,input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id, input_condition_for_tectonic_motion = """(tectonic_motion = 'Divergence' or tectonic_motion = 'Oblique_divergence')""")
					elif (tectonic_motion == 'Transform'):
						sql_1 = txt_1.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time, input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id, input_condition_for_tectonic_motion = """(tectonic_motion = 'Transform')""")
					elif (tectonic_motion == 'Stable'):
						sql_1 = txt_1.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time, input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id, input_condition_for_tectonic_motion = """(tectonic_motion = 'Stable')""")
                    print("sql_1",sql_1)
					cur_1.execute(sql_1)
					row_1 = cur_1.fetchone()
					oldest_time = -50000.00
					previous_time_of_tectonic_motion = -1.00
					time_of_tectonic_motion = -1.00
					previous_tectonic_motion = None
					while (row_1 is not None):
						#print(row_1)
						time_of_tectonic_motion = float(row_1[0])
						current_tectonic_motion = row_1[1]
						#print('time_of_tectonic_motion',time_of_tectonic_motion)
						#print('current_tectonic_motion',current_tectonic_motion)
						if (oldest_time < 0.00):
							oldest_time = time_of_tectonic_motion
							previous_tectonic_motion = current_tectonic_motion
						elif ((previous_time_of_tectonic_motion - time_of_tectonic_motion) > time_interval):
							if (previous_time_of_tectonic_motion == oldest_time):
								dic[key].append((oldest_time, (oldest_time - time_interval) + (0.100*time_interval), ref_ft_id, neighbour_ft_id, previous_tectonic_motion))
							else:
								dic[key].append((oldest_time, previous_time_of_tectonic_motion, ref_ft_id, neighbour_ft_id, previous_tectonic_motion))
							oldest_time = time_of_tectonic_motion
							previous_tectonic_motion = current_tectonic_motion
						previous_time_of_tectonic_motion = time_of_tectonic_motion
						#print('oldest_time',oldest_time,'previous_time_of_tectonic_motion',previous_time_of_tectonic_motion)
						row_1 = cur_1.fetchone()
					if (oldest_time > 0.00 and previous_time_of_tectonic_motion == oldest_time):
						if (oldest_time > 5.00):
							previous_time_of_tectonic_motion = (previous_time_of_tectonic_motion - time_interval) + (0.100*time_interval)
						elif (oldest_time == 5.00):
							previous_time_of_tectonic_motion = (previous_time_of_tectonic_motion - time_interval)
						dic[key].append((oldest_time, previous_time_of_tectonic_motion, ref_ft_id, neighbour_ft_id, previous_tectonic_motion))
					elif (oldest_time > 0.00 and previous_time_of_tectonic_motion < oldest_time):
						if (previous_time_of_tectonic_motion == 5.00):
							previous_time_of_tectonic_motion = 0.00
						dic[key].append((oldest_time, previous_time_of_tectonic_motion, ref_ft_id, neighbour_ft_id, previous_tectonic_motion))
					elif (oldest_time == 0.00 and previous_time_of_tectonic_motion == 0.00):
						dic[key].append((oldest_time, previous_time_of_tectonic_motion - time_interval, ref_ft_id, neighbour_ft_id, previous_tectonic_motion))
					if (len(dic[key]) == 0):
						print("Error in create_plate_tectonic_boundaries_from_database_table_tectonic_motion")
						print("There are not records for the pair:",key)
						print("sql_1",sql_1)
						cur_1.execute(sql_1)
						row_1 = cur_1.fetchone()
						while (row_1 is not None):
							print(row_1)
							row_1 = cur_1.fetchone()
						exit()
				row = cur.fetchone()
			#update reconstruction_time
			reconstruction_time = reconstruction_time - time_interval
		
		for key in dic:
			print('dic[key]',dic[key])
			list_of_records = dic[key]
			for r in list_of_records:
				from_time, to_time, ref_ft_id, neighbour_ft_id, tectonic_motion = r[0],r[1],r[2],r[3],r[4]
				if (len(list_of_records) == 1 and from_time == 0.00):
					break
				all_line_ft_1 = line_features_collection.get(lambda ft: ft.get_name() == ref_ft_id, pygplates.FeatureReturn.all)
				final_line_ft_1 = None
				print("number of ft in all_line_ft_1", len(all_line_ft_1))
				final_to_time_1 = -1.00
				for potential_line_ft_1 in all_line_ft_1:
					#print('potential_line_ft_1.get_valid_time()',potential_line_ft_1.get_valid_time())
					begin_at_line_1,end_at_line_1 = potential_line_ft_1.get_valid_time()
					if (potential_line_ft_1.is_valid_at_time(from_time)):
						final_line_ft_1 = potential_line_ft_1
						if (end_at_line_1 > to_time):
							final_to_time_1 = end_at_line_1
						else:
							final_to_time_1 = to_time
						break
				all_line_ft_2 = line_features_collection.get(lambda ft: ft.get_name() == neighbour_ft_id, pygplates.FeatureReturn.all)
				final_line_ft_2 = None
				print("number of ft in all_line_ft_2", len(all_line_ft_2))
				final_to_time_2 = -1.00
				for potential_line_ft_2 in all_line_ft_2:
					#print('potential_line_ft_2.get_valid_time()',potential_line_ft_2.get_valid_time())
					begin_at_line_2,end_at_line_2 = potential_line_ft_2.get_valid_time()
					if (potential_line_ft_2.is_valid_at_time(from_time)):
						final_line_ft_2 = potential_line_ft_2
						if (end_at_line_2 > to_time):
							final_to_time_2 = end_at_line_2
						else:
							final_to_time_2 = to_time
						break
				if (final_to_time_1 != final_to_time_2):
					if (final_to_time_1 > final_to_time_2):
						to_time = final_to_time_1
					else:
						to_time = final_to_time_2
				elif (final_to_time_1 == final_to_time_2 and final_to_time_1 != to_time):
					if (final_to_time_1 > to_time):
						to_time = final_to_time_1
					else:
						to_time = to_time
				
				#The portion of code to determine to_time of final output tectonic_motion is only considered because I once messed up the valid_time of CON-OCN line feature when evaluated subsequent tectonic motion
				
				if (final_line_ft_1 is not None and final_line_ft_2 is not None):
					plate_tectonic_margin_ft_1 = None
					plate_tectonic_margin_ft_2 = None
					line_1,line_2 = None,None
					len_of_current_geom = -1.0
					for geom in final_line_ft_1.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_1 = geom
					len_of_current_geom = -1.0
					for geom in final_line_ft_2.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_2 = geom
					if (tectonic_motion == "Convergence" or tectonic_motion == "Oblique_convergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_1, name = ref_ft_id, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_2, name = neighbour_ft_id, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					elif (tectonic_motion == "Divergence" or tectonic_motion == "Oblique_divergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = ref_ft_id, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
						
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = neighbour_ft_id, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					elif (tectonic_motion == "Stable"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = ref_ft_id, description = "stable_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
						
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = neighbour_ft_id, description = "stable_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					elif (tectonic_motion == "Transform"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_1, name = ref_ft_id, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_2, name = neighbour_ft_id, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					sql_2 = txt_2.format(input_name_name_for_table_for_summary_tectonic_boundary = name_for_table_for_summary_tectonic_boundary)
					cur_2.execute(sql_2,(from_time, to_time, tectonic_motion, ref_ft_id, neighbour_ft_id, final_line_ft_1.get_reconstruction_plate_id(), final_line_ft_2.get_reconstruction_plate_id()))
					conn.commit()
					print('plate_tectonic_margin_ft_1',plate_tectonic_margin_ft_1)
					print('plate_tectonic_margin_ft_2',plate_tectonic_margin_ft_2)
					print(r)
					outputFeatureCollection.add(plate_tectonic_margin_ft_1)
					outputFeatureCollection.add(plate_tectonic_margin_ft_2)
				else:
					print("Warning in create_plate_tectonic_boundaries_from_database_table_tectonic_motion")
					print("Cannot find either final_line_ft_1 or final_line_ft_2")
					print(final_line_ft_1, final_line_ft_2)
					print('from_time, to_time, ref_ft_id, neighbour_ft_id, tectonic_motion',from_time, to_time, ref_ft_id, neighbour_ft_id, tectonic_motion)
					exit()
		outputFeatureCollection.write("plate_tectonic_boundaries_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+yearmonthday+".shp")
		outputFeatureCollection.write("plate_tectonic_boundaries_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+yearmonthday+".gpml")
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_motion_from_database_table_tectonic_motion")
		print(error)

def create_plate_tectonic_boundaries_from_database_table_summary_of_tectonic_motion(name_for_table_for_summary_tectonic_boundary, line_features_collection, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	conn = None
	cur = None
	txt = """SELECT	 from_time, to_time, tectonic_motion, ref_ft_id, neighbour_ft_id, ref_gdu_id, neighbour_gdu_id FROM {input_name_name_for_table_for_summary_tectonic_boundary} ORDER BY from_time DESC"""
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		dic = {}
		outputFeatureCollection = pygplates.FeatureCollection()
		sql = txt.format(input_name_name_for_table_for_summary_tectonic_boundary = name_for_table_for_summary_tectonic_boundary)
		cur.execute(sql)
		row = cur.fetchone()
		while (row is not None):
			print("row",row)
			from_time = float(row[0])
			to_time = float(row[1])
			tectonic_motion = str(row[2])
			ref_ft_id = str(row[3])
			neighbour_ft_id = str(row[4])
			ref_gdu_id = int(row[5])
			neighbour_gdu_id = int(row[6])
			if (from_time > 0.00):
				all_line_ft_1 = line_features_collection.get(lambda ft: ft.get_name() == ref_ft_id, pygplates.FeatureReturn.all)
				final_line_ft_1 = None
				print("number of ft in all_line_ft_1", len(all_line_ft_1))
				final_to_time_1 = -1.00
				for potential_line_ft_1 in all_line_ft_1:
					#print('potential_line_ft_1.get_valid_time()',potential_line_ft_1.get_valid_time())
					begin_at_line_1,end_at_line_1 = potential_line_ft_1.get_valid_time()
					if (potential_line_ft_1.is_valid_at_time(from_time)):
						final_line_ft_1 = potential_line_ft_1
						if (end_at_line_1 > to_time):
							final_to_time_1 = end_at_line_1
						else:
							final_to_time_1 = to_time
						break
				all_line_ft_2 = line_features_collection.get(lambda ft: ft.get_name() == neighbour_ft_id, pygplates.FeatureReturn.all)
				final_line_ft_2 = None
				print("number of ft in all_line_ft_2", len(all_line_ft_2))
				final_to_time_2 = -1.00
				for potential_line_ft_2 in all_line_ft_2:
					#print('potential_line_ft_2.get_valid_time()',potential_line_ft_2.get_valid_time())
					begin_at_line_2,end_at_line_2 = potential_line_ft_2.get_valid_time()
					if (potential_line_ft_2.is_valid_at_time(from_time)):
						final_line_ft_2 = potential_line_ft_2
						if (end_at_line_2 > to_time):
							final_to_time_2 = end_at_line_2
						else:
							final_to_time_2 = to_time
						break
				if (final_to_time_1 != final_to_time_2):
					if (final_to_time_1 > final_to_time_2):
						to_time = final_to_time_1
					else:
						to_time = final_to_time_2
				elif (final_to_time_1 == final_to_time_2 and final_to_time_1 != to_time):
					if (final_to_time_1 > to_time):
						to_time = final_to_time_1
					else:
						to_time = to_time
				
				#The portion of code to determine to_time of final output tectonic_motion is only considered because I once messed up the valid_time of CON-OCN line feature when evaluated subsequent tectonic motion
				
				if (final_line_ft_1 is not None and final_line_ft_2 is not None):
					plate_tectonic_margin_ft_1 = None
					plate_tectonic_margin_ft_2 = None
					line_1,line_2 = None,None
					len_of_current_geom = -1.0
					for geom in final_line_ft_1.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_1 = geom
					len_of_current_geom = -1.0
					for geom in final_line_ft_2.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_2 = geom
					if (tectonic_motion == "Convergence" or tectonic_motion == "Oblique_convergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_1, name = ref_ft_id, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_2, name = neighbour_ft_id, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					elif (tectonic_motion == "Divergence" or tectonic_motion == "Oblique_divergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = ref_ft_id, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
						
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = neighbour_ft_id, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					elif (tectonic_motion == "Stable"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = ref_ft_id, description = "stable_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
						
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = neighbour_ft_id, description = "stable_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
                    elif (tectonic_motion == "Transform"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_1, name = ref_ft_id, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_2, name = neighbour_ft_id, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)

					print('plate_tectonic_margin_ft_1',plate_tectonic_margin_ft_1)
					print('plate_tectonic_margin_ft_2',plate_tectonic_margin_ft_2)
					print(row)
					outputFeatureCollection.add(plate_tectonic_margin_ft_1)
					outputFeatureCollection.add(plate_tectonic_margin_ft_2)
				else:
					print("Warning in create_plate_tectonic_boundaries_from_database_table_tectonic_motion")
					print("Cannot find either final_line_ft_1 or final_line_ft_2")
					print(final_line_ft_1, final_line_ft_2)
					print('from_time, to_time, ref_ft_id, neighbour_ft_id, tectonic_motion',from_time, to_time, ref_ft_id, neighbour_ft_id, tectonic_motion)
					exit()
			row = cur.fetchone()
		outputFeatureCollection.write("plate_tectonic_boundaries_from_summary_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+yearmonthday+".shp")
		outputFeatureCollection.write("plate_tectonic_boundaries_from_summary"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+yearmonthday+".gpml")
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_motion_from_database_table_tectonic_motion")
		print(error)
def create_passive_boundaries_from_database_table_passive_boundaries(name_of_table_for_passive_boundaries_at_each_time, name_for_table_for_summary_passive_boundary, line_features_collection, begin_reconstruction_time, end_reconstruction_time, time_interval, modelname, yearmonthday):
	txt = """SELECT DISTINCT time, ref_ft_id, neighbour_ft_id, tectonic_motion FROM {input_name_of_table_for_passive_boundaries_at_each_time} 
			WHERE time = {input_time} AND (tectonic_motion != 'Invalid') ORDER BY time DESC"""
	txt_1 = """SELECT DISTINCT time FROM {input_name_of_table_for_passive_boundaries_at_each_time} 
			WHERE time <= {input_time} AND (tectonic_motion != 'Invalid') AND ref_ft_id = '{input_line_name}' ORDER BY time DESC"""
	txt_2 = """INSERT INTO {input_name_for_table_for_summary_passive_boundary}(from_time, to_time, tectonic_motion, ref_ft_id, ref_gdu_id) VALUES (%s, %s, %s, %s, %s)"""
	conn = None
	cur = None
	cur_1 = None
	cur_2 = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		dic = {}
		outputFeatureCollection = pygplates.FeatureCollection()
		reconstruction_time = begin_reconstruction_time
		while (reconstruction_time > (end_reconstruction_time - time_interval)):
			print("reconstruction_time",reconstruction_time)
			sql = txt.format(input_name_of_table_for_passive_boundaries_at_each_time = name_of_table_for_passive_boundaries_at_each_time, input_time = reconstruction_time)
			cur.execute(sql)
			row = cur.fetchone()
			while (row is not None):
				time = float(row[0])
				ref_ft_id = row[1]
				key = ref_ft_id
				if (key not in dic):
					dic[key] = []
					sql_1 = None
					sql_1 = txt_1.format(input_name_of_table_for_passive_boundaries_at_each_time = name_of_table_for_passive_boundaries_at_each_time, input_time = reconstruction_time, input_line_name = ref_ft_id)
					cur_1.execute(sql_1)
					row_1 = cur_1.fetchone()
					oldest_time = 0.00
					previous_time_of_tectonic_motion = 0.00
					time_of_tectonic_motion = -1.00
					while (row_1 is not None):
						#print(row_1)
						time_of_tectonic_motion = float(row_1[0])
						#print('time_of_tectonic_motion',time_of_tectonic_motion)
						#print('current_tectonic_motion',current_tectonic_motion)
						if (oldest_time == 0.00):
							oldest_time = time_of_tectonic_motion
						elif ((previous_time_of_tectonic_motion - time_of_tectonic_motion) > time_interval):
							if (previous_time_of_tectonic_motion == oldest_time):
								dic[key].append((oldest_time, (oldest_time - time_interval) + (0.100*time_interval), ref_ft_id))
							else:
								dic[key].append((oldest_time, previous_time_of_tectonic_motion, ref_ft_id))
							oldest_time = time_of_tectonic_motion
						previous_time_of_tectonic_motion = time_of_tectonic_motion
						#print('oldest_time',oldest_time,'previous_time_of_tectonic_motion',previous_time_of_tectonic_motion)
						row_1 = cur_1.fetchone()
					if (oldest_time > 0.00 and previous_time_of_tectonic_motion == oldest_time):
						if (oldest_time > 5.00):
							previous_time_of_tectonic_motion = (previous_time_of_tectonic_motion - time_interval) + (0.100*time_interval)
						elif (oldest_time == 5.00):
							previous_time_of_tectonic_motion = (previous_time_of_tectonic_motion - time_interval)
						dic[key].append((oldest_time, previous_time_of_tectonic_motion, ref_ft_id))
					elif (oldest_time > 0.00 and previous_time_of_tectonic_motion < oldest_time):
						if (previous_time_of_tectonic_motion == 5.00):
							previous_time_of_tectonic_motion = 0.00
						dic[key].append((oldest_time, previous_time_of_tectonic_motion, ref_ft_id))
					elif (oldest_time == 0.00):
						previous_time_of_tectonic_motion = -5.00
						dic[key].append((oldest_time, previous_time_of_tectonic_motion, ref_ft_id))
					if (len(dic[key]) == 0):
						print("Error create_passive_boundaries_from_database_table_passive_boundaries")
						print("There are not records for the key:",key)
						sql_1 = txt.format(input_name_of_table_for_passive_boundaries_at_each_time = name_of_table_for_passive_boundaries_at_each_time, input_time = reconstruction_time)
						cur_1.execute(sql_1)
						row_1 = cur_1.fetchone()
						while (row_1 is not None):
							print(row_1)
							row_1 = cur_1.fetchone()
						exit()
				row = cur.fetchone()
			#update reconstruction_time
			reconstruction_time = reconstruction_time - time_interval
		
		for key in dic:
			print('dic[key]',dic[key])
			list_of_records = dic[key]
			for r in list_of_records:
				from_time, to_time, ref_ft_id= r[0],r[1],r[2]
				all_line_ft_1 = line_features_collection.get(lambda ft: ft.get_name() == ref_ft_id, pygplates.FeatureReturn.all)
				final_line_ft_1 = None
				print("number of ft in all_line_ft_1", len(all_line_ft_1))
				final_to_time_1 = -1.00
				for potential_line_ft_1 in all_line_ft_1:
					#print('potential_line_ft_1.get_valid_time()',potential_line_ft_1.get_valid_time())
					begin_at_line_1,end_at_line_1 = potential_line_ft_1.get_valid_time()
					if (potential_line_ft_1.is_valid_at_time(from_time)):
						final_line_ft_1 = potential_line_ft_1
						if (end_at_line_1 > to_time):
							final_to_time_1 = end_at_line_1
						else:
							final_to_time_1 = to_time
						break
				
				if (final_line_ft_1 is not None):
					plate_tectonic_margin_ft_1 = None
					line_1 = None
					len_of_current_geom = -1.0
					for geom in final_line_ft_1.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_1 = geom
					
					plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = ref_ft_id, description = "passive_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
					
					sql_2 = txt_2.format(input_name_for_table_for_summary_passive_boundary = name_for_table_for_summary_passive_boundary)
					cur_2.execute(sql_2,(from_time, to_time, "Passive", ref_ft_id, final_line_ft_1.get_reconstruction_plate_id()))
					conn.commit()

					outputFeatureCollection.add(plate_tectonic_margin_ft_1)
				else:
					print("Warning in create_plate_tectonic_boundaries_from_database_table_tectonic_motion")
					print("Cannot find final_line_ft_1")
					print('from_time, to_time, ref_ft_id,',from_time, to_time, ref_ft_id,final_line_ft_1.get_reconstruction_plate_id())
					exit()
		outputFeatureCollection.write("passive_boundaries_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+yearmonthday+".shp")
		outputFeatureCollection.write("passive_boundaries_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+yearmonthday+".gpml")
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_motion_from_database_table_tectonic_motion")
		print(error)

def create_plate_tectonic_boundaries_from_database_table_tectonic_motion_2(name_of_table_for_pairs_of_line_features_at_each_time, name_for_table_for_summary_tectonic_boundary, line_features_collection, time_interval, modelname, yearmonthday):
	txt = """SELECT DISTINCT time, ref_ft_id, neighbour_ft_id FROM {input_name_of_table_for_pairs_of_line_features_at_each_time} ORDER BY time DESC"""
	txt_1 = """SELECT DISTINCT time, tectonic_motion FROM {input_name_of_table_for_pairs_of_line_features_at_each_time}
				WHERE ((ref_ft_id = '{input_ref_ft_id}' 
						AND neighbour_ft_id = '{input_neighbour_ft_id}')
					   OR (ref_ft_id = '{input_neighbour_ft_id}' 
							AND neighbour_ft_id = '{input_ref_ft_id}'))
					 ORDER BY time DESC """
	txt_2 = """INSERT INTO {input_name_name_for_table_for_summary_tectonic_boundary}(from_time, to_time, tectonic_motion, ref_ft_id, neighbour_ft_id, ref_gdu_id, neighbour_gdu_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"""
	conn = None
	cur = None
	cur_1 = None
	cur_2 = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		dic = {}
		outputFeatureCollection = pygplates.FeatureCollection()
		sql = txt.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time)
		cur.execute(sql)
		row = cur.fetchone()
		while (row is not None):
			time = float(row[0])
			ref_ft_id = row[1]
			neighbour_ft_id = row[2]
			key = ref_ft_id+'_'+neighbour_ft_id
			rev_key = neighbour_ft_id+'_'+ref_ft_id
			if (key not in dic and rev_key not in dic):
				dic[key] = []
				sql_1 = None
				sql_1 = txt_1.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time,input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id)
				cur_1.execute(sql_1)
				row_1 = cur_1.fetchone()
				oldest_time = 0.00
				previous_time_of_tectonic_motion = -1.00
				time_of_tectonic_motion = -1.00
				previous_tectonic_motion = None
				while (row_1 is not None):
					print(row_1)
					time_of_tectonic_motion = float(row_1[0])
					current_tectonic_motion = row_1[1]
					print('time_of_tectonic_motion',time_of_tectonic_motion)
					print('current_tectonic_motion',current_tectonic_motion)
					if (oldest_time == 0.00):
						oldest_time = time_of_tectonic_motion
						previous_tectonic_motion = current_tectonic_motion
					elif (time_of_tectonic_motion < oldest_time and ((previous_time_of_tectonic_motion - time_of_tectonic_motion) == time_interval)):
						if (current_tectonic_motion != previous_tectonic_motion):
							dic[key].append((oldest_time, time_of_tectonic_motion, ref_ft_id, neighbour_ft_id, previous_tectonic_motion))
							oldest_time = time_of_tectonic_motion
							previous_tectonic_motion = current_tectonic_motion
					previous_time_of_tectonic_motion = time_of_tectonic_motion
					print('oldest_time',oldest_time,'previous_time_of_tectonic_motion',previous_time_of_tectonic_motion)
					row_1 = cur_1.fetchone()
				if (oldest_time > 0.00 and previous_time_of_tectonic_motion == oldest_time):
					previous_time_of_tectonic_motion = previous_time_of_tectonic_motion - time_interval
					dic[key].append((oldest_time, previous_time_of_tectonic_motion, ref_ft_id, neighbour_ft_id, previous_tectonic_motion))
				if (len(dic[key]) == 0):
					print("Error in create_plate_tectonic_boundaries_from_database_table_tectonic_motion")
					print("There are not records for the pair:",key)
					sql_1 = txt_1.format(input_name_of_table_for_pairs_of_line_features_at_each_time = name_of_table_for_pairs_of_line_features_at_each_time,input_ref_ft_id = ref_ft_id, input_neighbour_ft_id = neighbour_ft_id)
					cur_1.execute(sql_1)
					row_1 = cur_1.fetchone()
					while (row_1 is not None):
						print(row_1)
						row_1 = cur_1.fetchone()
					exit()
			row = cur.fetchone()

		for key in dic:
			print('dic[key]',dic[key])
			list_of_records = dic[key]
			for r in list_of_records:
				from_time, to_time, ref_ft_id, neighbour_ft_id, tectonic_motion = r[0],r[1],r[2],r[3],r[4]
				all_line_ft_1 = line_features_collection.get(lambda ft: ft.get_name() == ref_ft_id, pygplates.FeatureReturn.all)
				final_line_ft_1 = None
				for potential_line_ft_1 in all_line_ft_1:
					if (potential_line_ft_1.is_valid_at_time(from_time)):
						final_line_ft_1 = potential_line_ft_1
						break
				all_line_ft_2 = line_features_collection.get(lambda ft: ft.get_name() == neighbour_ft_id, pygplates.FeatureReturn.all)
				final_line_ft_2 = None
				for potential_line_ft_2 in all_line_ft_2:
					if (potential_line_ft_2.is_valid_at_time(from_time)):
						final_line_ft_2 = potential_line_ft_2
						break
				if (final_line_ft_1 is not None and final_line_ft_2 is not None):
					plate_tectonic_margin_ft_1 = None
					plate_tectonic_margin_ft_2 = None
					line_1,line_2 = None,None
					len_of_current_geom = -1.0
					for geom in final_line_ft_1.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_1 = geom
					len_of_current_geom = -1.0
					for geom in final_line_ft_2.get_geometries():
						if (geom.get_arc_length() > len_of_current_geom):
							len_of_current_geom = geom.get_arc_length()
							line_2 = geom
					if (tectonic_motion == "Convergence" or tectonic_motion == "Oblique_convergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_1, name = ref_ft_id, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, line_2, name = neighbour_ft_id, description = "unknown_convergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					elif (tectonic_motion == "Divergence" or tectonic_motion == "Oblique_divergence"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_1, name = ref_ft_id, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
						
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, line_2, name = neighbour_ft_id, description = "divergent_margin", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					elif (tectonic_motion == "Transform"):
						plate_tectonic_margin_ft_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_1, name = ref_ft_id, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_1.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_1.set_conjugate_plate_id(final_line_ft_2.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
							
						plate_tectonic_margin_ft_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, line_2, name = neighbour_ft_id, description = "transform_fault", valid_time = (from_time, to_time), reconstruction_plate_id = final_line_ft_2.get_reconstruction_plate_id())
						plate_tectonic_margin_ft_2.set_conjugate_plate_id(final_line_ft_1.get_reconstruction_plate_id(), verify_information_model = pygplates.VerifyInformationModel.no)
					sql_2 = txt_2.format(input_name_name_for_table_for_summary_tectonic_boundary = name_for_table_for_summary_tectonic_boundary)
					cur_2.execute(sql_2,(from_time, to_time, tectonic_motion, ref_ft_id, neighbour_ft_id, final_line_ft_1.get_reconstruction_plate_id(), final_line_ft_2.get_reconstruction_plate_id()))
					conn.commit()
					print('plate_tectonic_margin_ft_1',plate_tectonic_margin_ft_1)
					print('plate_tectonic_margin_ft_2',plate_tectonic_margin_ft_2)
					print(r)
					outputFeatureCollection.add(plate_tectonic_margin_ft_1)
					outputFeatureCollection.add(plate_tectonic_margin_ft_2)
				else:
					print("Error in create_plate_tectonic_boundaries_from_database_table_tectonic_motion")
					print("Cannot find either final_line_ft_1 or final_line_ft_2")
					print(final_line_ft_1, final_line_ft_2)
					print('from_time, to_time, ref_ft_id, neighbour_ft_id, tectonic_motion',from_time, to_time, ref_ft_id, neighbour_ft_id, tectonic_motion)
					exit()
		outputFeatureCollection.write("plate_tectonic_boundaries_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+yearmonthday+".shp")
		outputFeatureCollection.write("plate_tectonic_boundaries_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+yearmonthday+".gpml")
	except (psycopg2.DatabaseError) as error:
		print("Error in extract_plate_tectonic_motion_from_database_table_tectonic_motion")
		print(error)