import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
import pygplates
import supporting_modules_to_extend_tectonic_boundaries as supporting




# def main(featType, rotation_file, SuperGDU_features_file, margin_line_features_shp_or_gpml, tectonic_boundaries_shp_or_gpml, begin, end, interval, reference, only_single_gap, modelname, yyyymmdd):
	# rotation_model = pygplates.RotationModel(rotation_file)
	# SuperGDU_features = pygplates.FeatureCollection(SuperGDU_features_file)
	# margin_line_features = pygplates.FeatureCollection(margin_line_features_shp_or_gpml)
	# tectonic_boundaries_fts = pygplates.FeatureCollection(tectonic_boundaries_shp_or_gpml)
	# list_of_passive_margin_fts = [ft for ft in tectonic_boundaries_fts if ft.get_feature_type() == featType]
	# supporting.identify_new_lines_for_feats(featType,rotation_model, SuperGDU_features, margin_line_features, list_of_passive_margin_fts, begin, end, interval, reference, only_single_gap, modelname, yyyymmdd)


def main(rotation_file, SuperGDU_features_file, tectonic_boundaries_shp_or_gpml, margin_line_features_shp_or_gpml, only_check_inferred_fts, begin, end, interval, reference, modelname, yyyymmdd):
	rotation_model = pygplates.RotationModel(rotation_file)
	SuperGDU_features = pygplates.FeatureCollection(SuperGDU_features_file)
	tectonic_features = pygplates.FeatureCollection(tectonic_boundaries_shp_or_gpml)
	line_features = pygplates.FeatureCollection(margin_line_features_shp_or_gpml)
	list_of_passive_margin_fts = [ft for ft in tectonic_features if type(ft.get_geometry()) == pygplates.PolylineOnSphere]
	print("number of tectonic features:")
	print(len(list_of_passive_margin_fts))
	#SuperGDU_features, tectonic_features, line_features,
	supporting.clean_up_messy_tectonic_boundaries(rotation_model, SuperGDU_features, list_of_passive_margin_fts, line_features, only_check_inferred_fts, begin, end, interval, reference, modelname, yyyymmdd)


if __name__ == "__main__":
	#main(rift_transform_point_features_shp)
	margin_line_features_shp_or_gpml = r"C:\Users\lavie\Desktop\Research\Winter2021\examine_line_topology\line_features_with_type_CON_OCN__test_8_for_PalaeoPlates2020_with_finalized_superGDU_from_20210121_test93_buffer_distance_10000km_test_19_20210127.gpml"
	tectonic_boundaries_shp_or_gpml = r"C:\Users\lavie\Desktop\Research\Winter2021\tectonic_boundaries\test_5_combine_and_finalize_tectonic_features_from_170.0_100.0_5_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_20210204.gpml"
	begin = 135.00
	end = 100.00
	interval = 5.00
	rotation_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\Rotation\T_Rot_Model_PalaeoPlates_20200131be.rot"
	SuperGDU_features_file = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\final_SuperGDU_fts_test_19_with_adding_small_time_to_begin_age205.0_0.0_20210121.gpml"
	reference = 700
	test_number = 1
	modelname = "PalaeoPlates2020_test_38_"
	yyyymmdd = '20210329'
	featType = pygplates.FeatureType.gpml_passive_continental_boundary
	only_single_gap = False
	#cleaning messy tectonic features
	#main(rotation_file, SuperGDU_features_file, tectonic_boundaries_shp_or_gpml, margin_line_features_shp_or_gpml, begin, end, interval, reference, modelname, yyyymmdd)
	#extend cleaned tectonic features
	#cleaned_tectonic_boundaries_shp_or_gpml = r"C:\Users\lavie\Desktop\Research\Winter2021\tectonic_boundaries\output_valid_tectonic_features_170.0_100.0_PalaeoPlates2020_test_30__20210322.gpml"	
	#cleaned_tectonic_boundaries_shp_or_gpml = r"C:\Users\lavie\Desktop\Research\Winter2021\tectonic_boundaries\output_valid_tectonic_features_170.0_100.0_PalaeoPlates2020_test_35__20210324.gpml"
	#main(featType, rotation_file, SuperGDU_features_file, margin_line_features_shp_or_gpml, cleaned_tectonic_boundaries_shp_or_gpml, begin, end, interval, reference, only_single_gap, modelname, yyyymmdd)
	only_check_inferred_fts = False
	#tectonic_boundaries_shp_or_gpml = r"C:\Users\lavie\Desktop\Research\Winter2021\utility\utility\combined_filestest_2_PalaeoPlatesApril2020_SuperGDU_20210121_divergent_CON_OCN_boundaries_135_100Ma__20210324.gpml"
	main(rotation_file, SuperGDU_features_file, tectonic_boundaries_shp_or_gpml, margin_line_features_shp_or_gpml, only_check_inferred_fts, begin, end, interval, reference, modelname, yyyymmdd)
	
