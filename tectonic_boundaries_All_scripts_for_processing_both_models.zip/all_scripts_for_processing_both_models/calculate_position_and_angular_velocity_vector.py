#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates

def find_angular_velocity_vector_of_a_PointOnSphere(point_at_from_time, point_at_to_time, time_interval):
	great_circle_arc = pygplates.GreatCircleArc(point_at_from_time,point_at_to_time)
	arc_direction_at_the_end = great_circle_arc.get_arc_direction(0.00)
	arc_length_in_rads = great_circle_arc.get_arc_length()
	magnitude_of_vel = arc_length_in_rads/time_interval
	return (arc_direction_at_the_end, magnitude_of_vel)

def approx_direction_of_velocity_vector_of_a_PointOnSphere(point_at_from_time, point_at_to_time, time_interval):
	pos_at_from_time = pygplates.Vector3D(point_at_from_time.to_xyz())
	pos_at_to_time = pygplates.Vector3D(point_at_to_time.to_xyz())
	rel_pos = pos_at_to_time - pos_at_from_time
	return rel_pos

def find_position_vector_from_point_A_to_point_B(point_A, point_B):
	great_circle_arc = pygplates.GreatCircleArc(point_A,point_B)
	arc_direction_at_B = great_circle_arc.get_arc_direction(1.00)
	arc_length_in_rads = great_circle_arc.get_arc_length()
	return (arc_direction_at_the_end, arc_length_in_rads)

def approx_dir_position_vector_from_point_A_to_point_B(point_A, point_B):
	vec_A = pygplates.Vector3D(point_A.to_xyz())
	vec_B = pygplates.Vector3D(point_B.to_xyz())
	rel_pos = vec_B - vec_A
	return rel_pos
