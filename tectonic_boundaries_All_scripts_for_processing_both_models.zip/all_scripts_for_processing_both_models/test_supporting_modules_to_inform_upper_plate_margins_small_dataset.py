import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_extend_tectonic_boundaries as supporting

# def main(approximated_plate_tectonic_margins_shp_or_gpml, possible_line_fts_for_subduction_zone_deposits_shp_or_gpml, possible_line_fts_for_subduction_zone_igneous_shp_or_gpml, modelname, test_number, yearmonthday):
	# approximated_plate_tectonic_margins = pygplates.FeatureCollection(approximated_plate_tectonic_margins_shp_or_gpml)
	# possible_line_fts_for_subduction_zone_deposits = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_deposits_shp_or_gpml)
	# possible_line_fts_for_subduction_zone_igneous = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_igneous_shp_or_gpml)
	# supporting.identify_upper_plate_margins_from_porphyry_VMS_and_igneous_activities_approximated_plate_tectonic_margins(approximated_plate_tectonic_margins, possible_line_fts_for_subduction_zone_deposits, possible_line_fts_for_subduction_zone_igneous, modelname, test_number, yearmonthday)

def main(rotation_file, approximated_plate_tectonic_margins_shp_or_gpml, deposits_or_geochron_buffer_features_file, from_age,to_age,interval,reference,modelname,yearmonthday):
	rotation_model = pygplates.RotationModel(rotation_file)
	approximated_plate_tectonic_margins = pygplates.FeatureCollection(approximated_plate_tectonic_margins_shp_or_gpml)
	unknown_convergent_margin_line_features = [ft for ft in approximated_plate_tectonic_margins if (ft.get_feature_type = )]
	deposits_or_geochron_buffer_features = pygplates.FeatureCollection(deposits_or_geochron_buffer_features_file)
	supporting.identify_upper_plate_margins_from_porphyry_VMS_and_igneous_activities_approximated_plate_tectonic_margins_with_buffer(rotation_model,unknown_convergent_margin_line_features,deposits_or_geochron_buffer_features,from_age,to_age,interval,reference,modelname,yearmonthday)

if __name__ == "__main__":
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	#approximated_plate_tectonic_margins_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Fall2021\tectonic_boundaries\clean_up_messy_tectonic_boundaries_based_on_geol_topology_temp_bdn_PalaeoPlatesJune2021_uncertainty_15Ma__5_20211130.gpml"
	approximated_plate_tectonic_margins_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\plate_tectonic_boundaries_BC_PalaeoPlatesNov2021_215.0_50.0_20220509.gpml"
	deposits_or_geochron_buffer_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\buffer_zones_for_point_features\test_4_valid_age_porphyry_StratDB_Oct2021_dissolved_buffer_300.0_1970.0_0.0_5.0Ma_15.0_time_wdn_reconstructed_SuperGDU_PalaeoPlatesNov_2021_20220406.gpml"
	modelname = "BC_PalaeoPlatesNov2021_porphyry_StratDB_Oct2021_dissolved_buffer_300.0km_15Ma_time_wdn"
	test_number = 2
	yearmonthday = "202205018"
	from_age = 215.00
	to_age = 50.00
	interval = 5.00
	reference = 700
	main(rotation_file, approximated_plate_tectonic_margins_shp_or_gpml, deposits_or_geochron_buffer_features_file, from_age,to_age,interval,reference,modelname,yearmonthday)