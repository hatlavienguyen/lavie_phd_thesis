#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math


#A function to calculate the distance between two points on the sphere - specifically the Earth 
#I could have used haversine module for python, but for the purpose of practise, I do it myself
#According to the formula from https://www.igismap.com/haversine-formula-calculate-geographic-distance-earth/, 
#a = sin^2(Difference in latitudes/2)+cos(lat1)*cos(lat2)*sin^2(Difference in longitude/2)
#c = 2*atan2(sqrt(a),sqrt(1-a))
#d = Radius of the sphere * c
def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def convert_Point_in_Shapely_to_PointOnSphere_in_pygplates(point):
	'''point has coordinate as longitude and latitude'''
	longitude = point.x
	latitude = point.y
	point_on_sphere = pygplates.PointOnSphere(latitude,longitude)
	return point_on_sphere

def convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(line):
	'''each data point of the line has coordinate as longitude and latitude'''
	if (line.length > 0.00):
		try:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.coords]
		except NotImplementedError as error:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.exterior.coords]
		line_on_sphere = pygplates.PolylineOnSphere(list_of_lat_lon_vertices)
		if (line_on_sphere is None):
			print ("Error to convert convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
			print ("Here is a list_of_lat_lon_vertices")
			print (list_of_lat_lon_vertices)
			print (list_of_lat_lon_vertices)
			exit()
		return line_on_sphere
	else:
		print ("Error in convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
		print ("line.length == 0")
		print ("here are coords for line:")
		print((line.coords))
		print ("here is line")
		print (line)
		exit()

def convert_Polygon_in_Shapely_to_PolygonOnSphere_in_pygplates(each_polygon):
	'''each data point of each_polygon has a coordinate as longitude and latitude'''
	if (each_polygon.area > 0.00):
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			#print("lat,lon")
			#print(lat,lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
				print("Warning invalid value of latitude or/and longitude")
				print("value of latitude")
				print(lat)
				print("value of longitude")
				print(lon)
				if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
					if (abs(abs(lat) - 90.00) < 0.500):
						if (lat < -90.00):
							lat = -90.000
						elif (lat > 90.00):
							lat = 90.000
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of latitude")
						print("value of latitude")
						print(lat)					
						exit()
				if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
					if (abs(abs(lon) - 180.00) < 0.500):
						if (lon < -180.00):
							lon = -180.00
						elif (lon > 180.00):
							lon = 180.00
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of longitude")
						print("value of longitude")
						print(lon)					
						exit()
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print("Error in creating polygon in pygplates in conversion module")
			print("Here is a list of lat_lon vertices")
			print(list_of_lat_lon_vertices)
			print("Here is the first vertex and the last vertex:")
			print(list_of_lat_lon_vertices[0])
			print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
			exit()
		return new_polygon
	else:
		print("Error in creating polygon in pygplates in conversion module")
		print("Error each_polygon.area <= 0.00")
		print("here is each_polygon")
		print(each_polygon)
		print([(lon,lat) for lon,lat in each_polygon.exterior.coords])
		exit()

def convert_PolygonOnSphere_to_Polygon_in_Shapely(polygon_on_sphere):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in polygon_on_sphere.to_lat_lon_list()]
	new_polygon = Polygon(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating Polygon in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_polygon

def convert_PolylineOnSphere_to_LineString_in_Shapely(polyline_on_sphere):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in polyline_on_sphere.to_lat_lon_list()]
	new_linestring = LineString(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating LineString in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_linestring

def convert_PointOnSphere_to_Point_in_Shapely(point_on_sphere):
	lat,lon = point_on_sphere.to_lat_lon()
	new_point = Point(lon,lat)
	if (new_point is None):
		print("Error in creating Point in Shapely in conversion module")
		print("Here is a vertices")
		print(lat,lon)
		exit()
	return new_point

def project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(wgs84_geom, choosen_epsg_projection):
	'''wgs84_geom has a geometry data type defined in Shapely and coordinates with order longitude as x and latitude as y'''
	wgs84 = pyproj.CRS('EPSG:4326')
	projection = pyproj.CRS(choosen_epsg_projection)
	project = pyproj.Transformer.from_crs(wgs84, projection, always_xy = True).transform
	projected_geom = transform(project, wgs84_geom)
	return projected_geom

def project_any_Shapely_geometry_in_planar_projection_to_spherical_projection_wgs84_lon_lat(projected_geom, choosen_epsg_projection):
	wgs84 = pyproj.CRS('EPSG:4326')
	projection = pyproj.CRS(choosen_epsg_projection)
	project = pyproj.Transformer.from_crs(projection, wgs84, always_xy = True).transform
	wgs84_geom = transform(project,projected_geom)
	return wgs84_geom

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries
	
def find_valid_con_ocn_line_features(line_features, common_filename_for_invalid_con_ocn_line_csv, reconstruction_time):
	#csv_filename = common_filename_for_invalid_con_ocn_line_csv.format(time = str(reconstruction_time))
	csv_filename= common_filename_for_invalid_con_ocn_line_csv
	#'reconstruction_time','LineID','OPOLYLID','POLYLID','GPLATE_FID'
	invalid_con_ocn_df = pd.read_csv(csv_filename, delimiter = ';', header = 0)
	valid_line_features = []
	for line_ft in line_features:
		polylid = line_ft.get_shapefile_attribute('POLYLID')
		opolylid = line_ft.get_shapefile_attribute('OPOLYLID')
		lineid = line_ft.get_shapefile_attribute('LineID')
		gplate_fid = line_ft.get_feature_id().get_string()
		result = invalid_con_ocn_df.loc[(invalid_con_ocn_df['POLYLID'] == polylid) & (invalid_con_ocn_df['OPOLYLID'] == opolylid) & (invalid_con_ocn_df['LineID'] == lineid) & (invalid_con_ocn_df['GPLATE_FID'] == gplate_fid)]
		if (result is not None):
			if (len(result) == 0):
				valid_line_features.append(line_ft)
		else:
			valid_line_features.append(line_ft)
	return valid_line_features

def find_gdu_features_associated_with_line_features(gdu_features, line_features):
	selected_gdu_features = {}
	for line_ft in line_features:
		polygid = line_ft.get_shapefile_attribute('POLYGID')
		if (polygid is not None):
			for gdu_ft in gdu_features:
				if (gdu_ft.get_shapefile_attribute('POLYGID') is not None and gdu_ft.get_shapefile_attribute('POLYGID') == polygid):
					if (polygid not in selected_gdu_features):
						selected_gdu_features[polygid] = [gdu_ft]
					else:
						list_of_gdu_fts = selected_gdu_features[polygid]
						found_duplicated = False
						for prev_ft in list_of_gdu_fts:
							prev_geometries = prev_ft.get_geometries()
							current_geometries = gdu_ft.get_geometries()
							for prev_geom in prev_geometries:
								for current_geom in current_geometries:
									if (prev_geom == current_geom):
										found_duplicated = True
										break
								if (found_duplicated == True):
									break
							if (found_duplicated == True):
								break
						if (found_duplicated == False):
							selected_gdu_features[polygid].append(gdu_ft)
	return selected_gdu_features

def find_gdu_members_of_each_sgdu_feat_old(gdu_features, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv,reconstruction_time):
	list_of_distinct_gdu_ids = []
	dict_of_sgdu_and_members_ids = {}
	# for gdu_ft in gdu_features:
		# if (gdu_ft.get_reconstruction_plate_id() not in list_of_distinct_gdu_ids):
			# list_of_distinct_gdu_ids.append(gdu_ft.get_reconstruction_plate_id())
		# if (gdu_ft.get_reconstruction_plate_id() == 11732):
			# print('found gdu fts with gdu id')
			# print(gdu_ft.get_reconstruction_plate_id() in list_of_distinct_gdu_ids)
	# array_of_distinct_gdu_ids = np.array(list_of_distinct_gdu_ids)
	for sgdu_ft in sgdu_features:
		sgdu_id = sgdu_ft.get_name()
		rep_gdu_id = sgdu_ft.get_reconstruction_plate_id()
		list_of_associated_gdu_members = None
		if (sgdu_id not in dict_of_sgdu_and_members_ids):
			temp_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temp_df = pd.read_csv(temp_sgdu_and_members_csv, delimiter = ';', header = 0)
			
			unique_sgdus = temp_df.loc[(temp_df['repGDUID'] == rep_gdu_id),'SGDUID'].unique()
			records_of_gdu_members = []
			for sgdu in unique_sgdus:
				temp_members = temp_df.loc[(temp_df['SGDUID'] == sgdu),'GDUID'].unique()
				for temp_mem in temp_members:
					if (temp_mem not in records_of_gdu_members):
						records_of_gdu_members.append(temp_mem)

			#records_of_gdu_members = temp_df.loc[(temp_df['repGDUID'] == rep_gdu_id)|(temp_df['GDUID'] == rep_gdu_id),'GDUID'].unique()
			# if (sgdu_id == '70290'):
				# print('records_of_gdu_members',records_of_gdu_members)
			#array_of_all_distinct_gdu_members = records_of_gdu_members
			#wanted_gdu_members = np.intersect1d(array_of_distinct_gdu_ids,array_of_all_distinct_gdu_members)
			
			wanted_gdu_members = records_of_gdu_members
			
			#if (sgdu_id == '70290'):
				# print('wanted_gdu_members',wanted_gdu_members)
				# print(array_of_distinct_gdu_ids)
				# print(array_of_all_distinct_gdu_members)
			if (len(wanted_gdu_members) > 0):
				list_of_wanted_gdu_fts = []
				for each_gdu_ft in gdu_features:
					if (each_gdu_ft.is_valid_at_time(reconstruction_time) and each_gdu_ft.get_reconstruction_plate_id() in wanted_gdu_members):
						list_of_wanted_gdu_fts.append(each_gdu_ft)
				
				#the thing: there is a time latency between when SuperGDU feature occurs and when CON-OCN line features occur. 
				#if (len(list_of_wanted_gdu_fts) == 0):
					#print("Error could not find any gdu features for SuperGDU feature",sgdu_id)
					#print('records_of_gdu_members')
					#print(records_of_gdu_members)
					#pygplates.FeatureCollection(sgdu_ft).write('SGDU_feature_'+str(sgdu_id)+'_could_not_find_gdus.shp')
					# for each_gdu_ft in gdu_features:
						# if (each_gdu_ft.get_reconstruction_plate_id() == 19508):
							# print('each_gdu_ft.get_reconstruction_plate_id()',each_gdu_ft.get_reconstruction_plate_id())
							# print(each_gdu_ft.get_reconstruction_plate_id() in wanted_gdu_members)
					# exit()
				dict_of_sgdu_and_members_ids[sgdu_id] = list_of_wanted_gdu_fts
	return dict_of_sgdu_and_members_ids

def find_gdu_members_of_each_sgdu_feat(gdu_features, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv,reconstruction_time):
	list_of_distinct_gdu_ids = []
	dict_of_sgdu_and_members_ids = {}
	# for gdu_ft in gdu_features:
		# if (gdu_ft.get_reconstruction_plate_id() not in list_of_distinct_gdu_ids):
			# list_of_distinct_gdu_ids.append(gdu_ft.get_reconstruction_plate_id())
		# if (gdu_ft.get_reconstruction_plate_id() == 11732):
			# print('found gdu fts with gdu id')
			# print(gdu_ft.get_reconstruction_plate_id() in list_of_distinct_gdu_ids)
	# array_of_distinct_gdu_ids = np.array(list_of_distinct_gdu_ids)
	for sgdu_ft in sgdu_features:
		sgdu_id = sgdu_ft.get_name()
		rep_gdu_id = sgdu_ft.get_reconstruction_plate_id()
		sgdu_begin,sgdu_end = sgdu_ft.get_valid_time()
		list_of_associated_gdu_members = None
		if (sgdu_id not in dict_of_sgdu_and_members_ids):
			temp_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temp_df = pd.read_csv(temp_sgdu_and_members_csv, delimiter = ';', header = 0)
			
			initial_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(sgdu_begin))
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			initial_df = pd.read_csv(initial_sgdu_and_members_csv, delimiter = ';', header = 0)
			
			unique_sgdus = temp_df.loc[(temp_df['repGDUID'] == rep_gdu_id)|(temp_df['GDUID'] == rep_gdu_id),'SGDUID'].unique()
			records_of_gdu_members = []
			for sgdu in unique_sgdus:
				temp_members = temp_df.loc[(temp_df['SGDUID'] == sgdu),'GDUID'].unique()
				for temp_mem in temp_members:
					if (temp_mem not in records_of_gdu_members):
						records_of_gdu_members.append(temp_mem)
			
			temp_members = initial_df.loc[(initial_df['SGDUID'] == int(sgdu_id)),'GDUID'].unique()
			for temp_mem in temp_members:
				if (temp_mem not in records_of_gdu_members):
					records_of_gdu_members.append(temp_mem)

			#records_of_gdu_members = temp_df.loc[(temp_df['repGDUID'] == rep_gdu_id)|(temp_df['GDUID'] == rep_gdu_id),'GDUID'].unique()
			# if (sgdu_id == '70290'):
				# print('records_of_gdu_members',records_of_gdu_members)
			#array_of_all_distinct_gdu_members = records_of_gdu_members
			#wanted_gdu_members = np.intersect1d(array_of_distinct_gdu_ids,array_of_all_distinct_gdu_members)
			
			wanted_gdu_members = records_of_gdu_members
			
			#if (sgdu_id == '70290'):
				# print('wanted_gdu_members',wanted_gdu_members)
				# print(array_of_distinct_gdu_ids)
				# print(array_of_all_distinct_gdu_members)
			if (len(wanted_gdu_members) > 0):
				list_of_wanted_gdu_fts = []
				list_of_already_included_polygids = []
				for each_gdu_ft in gdu_features:
					if (each_gdu_ft.is_valid_at_time(reconstruction_time) and each_gdu_ft.get_reconstruction_plate_id() in wanted_gdu_members):
						if (each_gdu_ft.get_shapefile_attribute('POLYGID') not in list_of_already_included_polygids):
							list_of_already_included_polygids.append(each_gdu_ft.get_shapefile_attribute('POLYGID'))
							list_of_wanted_gdu_fts.append(each_gdu_ft)
				# if (len(list_of_wanted_gdu_fts) == 0):
					# print("Error could not find any gdu features for SuperGDU feature",sgdu_id)
					# print('records_of_gdu_members')
					# print(records_of_gdu_members)
					#pygplates.FeatureCollection(sgdu_ft).write('SGDU_feature_'+str(sgdu_id)+'_could_not_find_gdus.shp')
					# for each_gdu_ft in gdu_features:
						# if (each_gdu_ft.get_reconstruction_plate_id() == 19508):
							# print('each_gdu_ft.get_reconstruction_plate_id()',each_gdu_ft.get_reconstruction_plate_id())
							# print(each_gdu_ft.get_reconstruction_plate_id() in wanted_gdu_members)
					# exit()
				dict_of_sgdu_and_members_ids[sgdu_id] = list_of_wanted_gdu_fts
	return dict_of_sgdu_and_members_ids

def find_centroid_of_each_reconstructed_gdu_ft(final_reconstructed_gdu_features):
	dict_of_gdu_and_centroid = {}
	for recontructed_gdu_ft, polygon in final_reconstructed_gdu_features:
		gdu_id = recontructed_gdu_ft.get_reconstruction_plate_id()
		centroid = polygon.get_interior_centroid()
		polygid = recontructed_gdu_ft.get_shapefile_attribute('POLYGID')
		# if (str(gdu_id) not in dict_of_gdu_and_centroid):
			# dict_of_gdu_and_centroid[str(gdu_id)] = [(centroid,polygid)]
		# else:
			# dict_of_gdu_and_centroid[str(gdu_id)].append((centroid,polygid))
		
		if (polygid not in dict_of_gdu_and_centroid):
			dict_of_gdu_and_centroid[polygid] = [(centroid,polygid)]
		else:
			dict_of_gdu_and_centroid[polygid].append((centroid,polygid))
		
	return dict_of_gdu_and_centroid

def create_topological_sections(list_of_features):
	topological_sections = []
	for temp_ft in list_of_features:
		topological_section = pygplates.GpmlTopologicalSection.create(temp_ft,topological_geometry_type=pygplates.GpmlTopologicalLine)
		if topological_section is not None:
			topological_sections.append(topological_section)
		else:
			print("could not create topological section")
	return topological_sections

def create_topological_polygon_feature(topological_sections):
	if (len(topological_sections) > 1):
		topological_features = pygplates.Feature.create_topological_feature(pygplates.FeatureType.gpml_closed_plate_boundary, pygplates.GpmlTopologicalPolygon(topological_sections))
		return topological_features
	else:
		return None

def create_topological_line_feature(topological_sections):
	if (len(topological_sections) >= 1):
		topological_features = pygplates.Feature.create_topological_feature(pygplates.FeatureType.gpml_unclassified_feature, pygplates.GpmlTopologicalLine(topological_sections), verify_information_model = pygplates.VerifyInformationModel.no)
		return topological_features
	else:
		return None

def create_tectonic_plates_old(order_to_connect_lines_csv, supergdu_features, line_feats_from_div_process, line_feats_from_conv_process, plate_boundary_zone_feats, modified_rift_point_features, rift_csv_file, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday):
	already_included_line_features = []
	output_topological_tectonic_plates = pygplates.FeatureCollection()
	#,reconstruction_time,sgdu,first,polylid,second
	order_to_connect_lines_df = pd.read_csv(order_to_connect_lines_csv)
	#rift records: start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid 
	rift_df = pd.read_csv(rift_csv_file)
	dic_supergdu = {}
	valid_supergdu_feats = []
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		valid_supergdu_feats[:] = []
		valid_line_fts_from_div = [div_ft for div_ft in line_feats_from_div_process if div_ft.is_valid_at_time(reconstruction_time)]
		valid_line_fts_from_conv = [conv_ft for conv_ft in line_feats_from_conv_process if conv_ft.is_valid_at_time(reconstruction_time)]
		valid_plate_boundary_zone = [plat_bdn_ft for plat_bdn_ft in plate_boundary_zone_feats if plat_bdn_ft.is_valid_at_time(reconstruction_time)]
		valid_rift_pt_fts = [pt_ft for pt_ft in modified_rift_point_features if pt_ft.is_valid_at_time(reconstruction_time)]
		for supergdu_ft in supergdu_features:
			if (supergdu_ft.is_valid_at_time(reconstruction_time)):
				valid_supergdu_feats.append(supergdu_ft)
		for valid_sgdu_ft in valid_supergdu_feats:
			sgdu_name = valid_sgdu_ft.get_name()
			if (sgdu_name in dic_supergdu):
				#obtain all CON-OCN line features
				no_change = True
				for polylid in dic_supergdu[sgdu_name]:
					features = dic_supergdu[sgdu_name][polylid]
					if (len(features) > 1):
						#a collection of rift point features
						#check whether all rift point features are valid
						all_valid_pt_fts = True
						left_over_pt_feats = []
						for pt_ft in features:
							if (pt_ft.is_valid_at_time(reconstruction_time) == False):
								all_valid_pt_fts = False
							else:
								left_over_pt_feats.append(pt_ft)
						if (all_valid_pt_fts == False):
							dic_supergdu[sgdu_name][polylid] = left_over_pt_feats
							no_change = False
					if (no_change == False and len(dic_supergdu[sgdu_name][polylid]) == 0):
						for line_ft in line_feats_from_div_process:
							if (line_ft.get_name() == polylid and line_ft.is_valid_at_time(reconstruction_time + time_interval) == True):
								features = [line_ft]
								break
					if (len(features) == 1):
						line_ft = features[0]
						if (line_ft.is_valid_at_time(reconstruction_time) == False):
							no_change = False
							temporary_list_to_connect_features = []
							found_ft = None
							found_first_ft = None
							found_second_ft = None
							polylid = line_ft.get_name()
							if (line_ft.get_description() != 'divergent_margin'):
								for line_ft in valid_line_fts_from_div:
									if (line_ft.get_name() == polylid):
										found_ft = line_ft
										if (line_ft.get_description() == 'divergent_margin'):
											#obtain rift records for polylid
											selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
											gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
											if (len(selected_rift_record) > 1):
												#sort the dataframe of rift point features based on the order 
												sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
												for rift_name, order in selected_rift_record.itertuples(index = False, name = None):
													rift_pt_ft_name = rift_name+'_'+str(order)
													found_rift_point_ft = None
													for rift_pt_ft in valid_rift_pt_fts:
														if (rift_pt_ft.get_name() == rift_pt_ft_name):
															found_rift_point_ft = rift_pt_ft
														break
													if (found_rift_point_ft is not None):
														temporary_list_to_connect_features.append(found_rift_point_ft)
											if (len(temporary_list_to_connect_features) == 0):
												temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'transform_fault'):
											temporary_list_to_connect_features.append(line_ft)
											break
										break
								if (found_ft is not None):
									if (found_ft.get_description() == 'convergent_margin'):
										for line_ft in valid_line_fts_from_conv:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
												found_ft = line_ft
												break
											elif (line_ft.get_name() == polylid and line_ft.get_description() == 'transform_fault'):
												found_ft = line_ft
								else:
									for line_ft in valid_line_fts_from_conv:
										if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
											found_ft = line_ft
											break
										elif (line_ft.get_name() == polylid and line_ft.get_description() == 'transform_fault'):
											found_ft = line_ft
									if (found_ft is None):
										for line_ft in plate_boundary_zone_feats:
											if (line_ft.get_name() == polylid):
												found_ft = line_ft
								if (found_ft is not None):
									temporary_list_to_connect_features.append(found_ft)
								CON_OCN_records = order_to_connect_lines_df.loc[(order_to_connect_lines_df['sgdu'] == int(sgdu_name)) & (order_to_connect_lines_df['polylid'] == polylid), ['first', 'polylid', 'second']]
								if ((found_ft is None or found_ft.get_description() == 'plate_boundary_zone') and len(CON_OCN_records) > 1):
									if (found_ft is None):
										for line_ft in valid_line_fts_from_conv:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
												found_ft = line_ft
												break
									for first, polylid, second in CON_OCN_records.itertuples(index = False, name = None):
										#try to find the other two features: first and second
										if (first is not None):
											for first_line_ft in valid_line_fts_from_div:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'convergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None):
											for second_line_ft in valid_line_fts_from_div:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'convergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None and found_second_ft is not None):
											if ((found_first_ft.get_description() == found_second_ft.get_description())):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_first_ft is not None):
											if (found_first_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
										#try the new collections
										if (first is not None and found_first_ft is None and found_second_ft is None):
											for first_line_ft in valid_line_fts_from_conv:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'divergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None and found_second_ft is None and found_first_ft is None):
											for second_line_ft in valid_line_fts_from_conv:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'divergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None):
											if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								if (found_ft is not None and len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(found_ft)
							elif (line_ft.get_description() != 'convergent_margin'):
								polylid = line_ft.get_name()
								for line_ft in valid_line_fts_from_conv:
									if (line_ft.get_name() == polylid):
										found_ft = line_ft
										if (line_ft.get_description() == 'convergent_margin'):
											temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'transform_fault'):
											temporary_list_to_connect_features.append(line_ft)
											break
								if (found_ft is not None):
									if (found_ft.get_description() == 'divergent_margin'):
										for line_ft in valid_line_fts_from_div:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
												found_ft = line_ft
												#obtain rift records for polylid
												selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
												gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
												if (len(selected_rift_record) > 1):
													#sort the dataframe of rift point features based on the order 
													sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
													for rift_name, order in selected_rift_record.itertuples(index = False, name = None):
														rift_pt_ft_name = rift_name+'_'+str(order)
														found_rift_point_ft = None
														for rift_pt_ft in valid_rift_pt_fts:
															if (rift_pt_ft.get_name() == rift_pt_ft_name):
																found_rift_point_ft = rift_pt_ft
															break
														if (found_rift_point_ft is not None):
															temporary_list_to_connect_features.append(found_rift_point_ft)
												if (len(temporary_list_to_connect_features) == 0):
													temporary_list_to_connect_features.append(line_ft)
												break
											elif (line_ft.get_name() == polylid and line_ft.get_description() == 'transform_fault'):
												found_ft = line_ft
								else:
									for line_ft in valid_line_fts_from_div:
										if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
											found_ft = line_ft
											#obtain rift records for polylid
											selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
											gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
											if (len(selected_rift_record) > 1):
												#sort the dataframe of rift point features based on the order 
												sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
												for rift_name, order in selected_rift_record.itertuples(index = False, name = None):
													rift_pt_ft_name = rift_name+'_'+str(order)
													found_rift_point_ft = None
													for rift_pt_ft in valid_rift_pt_fts:
														if (rift_pt_ft.get_name() == rift_pt_ft_name):
															found_rift_point_ft = rift_pt_ft
														break
													if (found_rift_point_ft is not None):
														temporary_list_to_connect_features.append(found_rift_point_ft)
											if (len(temporary_list_to_connect_features) == 0):
												temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_name() == polylid and line_ft.get_description() == 'transform_fault'):
											found_ft = line_ft
									if (found_ft is None):
										for line_ft in plate_boundary_zone_feats:
											if (line_ft.get_name() == polylid):
												found_ft = line_ft
								if (found_ft is not None):
									temporary_list_to_connect_features.append(found_ft)
								CON_OCN_records = order_to_connect_lines_df.loc[(order_to_connect_lines_df['sgdu'] == int(sgdu_name)) & (order_to_connect_lines_df['polylid'] == found_ft.get_name()), ['first', 'polylid', 'second']]
								if ((found_ft is None or found_ft.get_description() == 'plate_boundary_zone') and len(CON_OCN_records) > 1):
									if (found_ft is None):
										for line_ft in valid_line_fts_from_div:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
												found_ft = line_ft
												break
									for first, polylid, second in CON_OCN_records.itertuples(index = False, name = None):
										#try to find the other two features: first and second
										if (first is not None):
											for first_line_ft in valid_line_fts_from_div:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'convergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None):
											for second_line_ft in valid_line_fts_from_div:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'convergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None and found_second_ft is not None):
											if ((found_first_ft.get_description() == found_second_ft.get_description())):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_first_ft is not None):
											if (found_first_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
										#try the new collections
										if (first is not None and found_first_ft is None and found_second_ft is None):
											for first_line_ft in valid_line_fts_from_conv:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'divergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None and found_second_ft is None and found_first_ft is None):
											for second_line_ft in valid_line_fts_from_conv:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'divergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None):
											if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								if (found_ft is not None and len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(found_ft)
							if (len(temporary_list_to_connect_features) > 0):
								dic_supergdu[sgdu_name][polylid] = temporary_list_to_connect_features
				if (no_change == False):
					for current_output_topological_ft in output_topological_tectonic_plates:
						if (current_output_topological_ft.get_name() == sgdu_name):
							current_begin_topological_age, current_end_topological_age = current_output_topological_ft.get_valid_time()
							if (current_end_topological_age < reconstruction_time and (reconstruction_time+0.1000) < current_begin_topological_age):
								current_output_topological_ft.set_valid_time(current_begin_topological_age,reconstruction_time+0.1000)
					list_to_connect_features = []
					CON_OCN_records = order_to_connect_lines_df.loc[order_to_connect_lines_df['sgdu'] == int(sgdu_name), ['first', 'polylid', 'second']]
					distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
					for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
						features_for_first = None
						features_for_polylid = None
						features_for_second = None
						if (first in dic_supergdu[sgdu_name]):
							features_for_first =  dic_supergdu[sgdu_name][first]
						if (polylid in dic_supergdu[sgdu_name]):
							features_for_polylid = dic_supergdu[sgdu_name][polylid]
						if (second in dic_supergdu[sgdu_name]):
							features_for_second = dic_supergdu[sgdu_name][second]
						list_of_features_to_be_connected = None
						if (features_for_first is not None):
							list_of_features_to_be_connected = features_for_first
						if (features_for_polylid is not None):
							if (list_of_features_to_be_connected is not None):
								list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_polylid
							elif (list_of_features_to_be_connected is None):
								list_of_features_to_be_connected = features_for_polylid
						if (features_for_second is not None):
							if (list_of_features_to_be_connected is not None and features_for_polylid is not None):
								list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_second
							elif (list_of_features_to_be_connected is None):
								list_of_features_to_be_connected = features_for_second
						if (list_of_features_to_be_connected is not None):
							if (len(list_of_features_to_be_connected) > 0):
								#double check to make sure no None feature
								no_none_ft = True
								for ft in list_of_features_to_be_connected:
									if (ft is None):
										no_none_ft = False
										break
								if (no_none_ft == True):
									topological_sections = create_topological_sections(list_of_features_to_be_connected)
									if (len(topological_sections) >= 1):
										topological_ft = create_topological_line_feature(topological_sections)
										topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
										if (topological_ft is not None):
											topological_ft.set_name(sgdu_name)
											topological_ft.set_valid_time(reconstruction_time, topological_end_age)
											output_topological_tectonic_plates.add(topological_ft)
										for each_original_ft in list_of_features_to_be_connected:
											if (each_original_ft.get_feature_id() not in already_included_line_features):
												output_topological_tectonic_plates.add(each_original_ft)
												already_included_line_features.append(each_original_ft.get_feature_id())
			else:
				#obtain all CON-OCN line features
				dic_supergdu[sgdu_name] = {}
				list_to_connect_features = []
				CON_OCN_records = order_to_connect_lines_df.loc[order_to_connect_lines_df['sgdu'] == int(sgdu_name), ['first', 'polylid', 'second']]
				distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
				for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
					dic_supergdu[sgdu_name][polylid] = []
					found_ft = None
					found_first_ft = None
					found_second_ft = None
					temporary_list_to_connect_features = []
					for line_ft in valid_line_fts_from_div:
						if (line_ft.get_name() == polylid ):
							if (line_ft.get_description() == 'divergent_margin'):
								#obtain rift records for polylid
								selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
								gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
								if (len(selected_rift_record) > 1):
									#sort the dataframe of rift point features based on the order 
									sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
									for rift_name, order in selected_rift_record.itertuples(index = False, name = None):
										rift_pt_ft_name = rift_name+'_'+str(order)
										found_rift_point_ft = None
										for rift_pt_ft in valid_rift_pt_fts:
											if (rift_pt_ft.get_name() == rift_pt_ft_name):
												found_rift_point_ft = rift_pt_ft
												break
										if (found_rift_point_ft is not None):
											temporary_list_to_connect_features.append(found_rift_point_ft)
								if (len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'transform_fault'):
								temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'plate_boundary_zone'):
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'convergent_margin'):
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												found_first_ft = first_line_ft
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												found_second_ft = second_line_ft
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
					if (found_ft is None):
						for line_ft in valid_line_fts_from_conv:
							if (line_ft.get_name() == polylid):
								found_ft = line_ft
								if (line_ft.get_description() == 'convergent_margin'):
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'transform_fault'):
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'plate_boundary_zone'):
									#try to find the other two features: first and second
									if (first is not None):
										for first_line_ft in valid_line_fts_from_conv:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'convergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													if (found_first_ft is None):
														found_first_ft = first_line_ft
													else:
														if (found_first_ft.get_description() == 'divergent_margin'):
															found_first_ft = first_line_ft #update
									if (second is not None):
										for second_line_ft in valid_line_fts_from_conv:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'convergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													if (found_second_ft is None):
														found_second_ft = second_line_ft
													else:
														if (found_second_ft.get_description() == 'divergent_margin'):
															found_second_ft = second_line_ft #update
									if (found_first_ft is not None and found_second_ft is not None):
										if ((found_first_ft.get_description() == found_second_ft.get_description())):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_first_ft is not None):
										if (found_first_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									
									#try the new collections
									if (first is not None and found_first_ft is None and found_second_ft is None):
										for first_line_ft in valid_line_fts_from_div:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'divergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													if (found_first_ft is None):
														found_first_ft = first_line_ft
													else:
														if (found_first_ft.get_description() == 'convergent_margin'):
															found_first_ft = first_line_ft #update
									if (found_second_ft is None and found_second_ft is None and found_first_ft is None):
										for second_line_ft in valid_line_fts_from_div:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'divergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													if (found_second_ft is None):
														found_second_ft = second_line_ft
													else:
														if (found_second_ft.get_description() == 'convergent_margin'):
															found_second_ft = second_line_ft #update
									if (found_first_ft is not None):
										if (found_first_ft.get_description() == 'divergent_margin' or found_first_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() == 'divergent_margin' or found_second_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'divergent_margin'):
									#try to find the other two features: first and second
									if (first is not None):
										for first_line_ft in valid_line_fts_from_conv:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'convergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													found_first_ft = first_line_ft
									if (second is not None):
										for second_line_ft in valid_line_fts_from_conv:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'convergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													found_second_ft = second_line_ft
									if (found_first_ft is not None and found_second_ft is not None):
										if ((found_first_ft.get_description() == found_second_ft.get_description())):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_first_ft is not None):
										if (found_first_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									#try the second time to find the other two features: first and second
									if (first is not None and found_first_ft is None and found_second_ft is None):
										for first_line_ft in valid_line_fts_from_div:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'divergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													found_first_ft = first_line_ft
									if (second is not None and found_second_ft is None and found_first_ft is None):
										for second_line_ft in valid_line_fts_from_div:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'divergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													found_second_ft = second_line_ft
									if (found_first_ft is not None):
										if (found_first_ft.get_description() == 'divergent_margin' or found_first_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() == 'divergent_margin' or found_second_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									temporary_list_to_connect_features.append(line_ft)
									break
					if (found_ft is None):
						for line_ft in plate_boundary_zone_feats:
							if (line_ft.get_name() == polylid):
								found_ft = line_ft
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
					if (len(temporary_list_to_connect_features) > 0):
						for each_ft in temporary_list_to_connect_features:
							dic_supergdu[sgdu_name][polylid].append(each_ft)
				for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
					features_for_first = None
					features_for_polylid = None
					features_for_second = None
					if (first in dic_supergdu[sgdu_name]):
						features_for_first =  dic_supergdu[sgdu_name][first]
					if (polylid in dic_supergdu[sgdu_name]):
						features_for_polylid = dic_supergdu[sgdu_name][polylid]
					if (second in dic_supergdu[sgdu_name]):
						features_for_second = dic_supergdu[sgdu_name][second]
					list_of_features_to_be_connected = None
					if (features_for_first is not None):
						list_of_features_to_be_connected = features_for_first
					if (features_for_polylid is not None):
						if (list_of_features_to_be_connected is not None):
							list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_polylid
						elif (list_of_features_to_be_connected is None):
							list_of_features_to_be_connected = features_for_polylid
					if (features_for_second is not None):
						if (list_of_features_to_be_connected is not None and features_for_polylid is not None):
							list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_second
						elif (list_of_features_to_be_connected is None):
							list_of_features_to_be_connected = features_for_second
					if (list_of_features_to_be_connected is not None):
						if (len(list_of_features_to_be_connected) > 0):
							#double check to make sure no None feature
							no_none_ft = True
							for ft in list_of_features_to_be_connected:
								if (ft is None):
									no_none_ft = False
									break
							if (no_none_ft == True):
								topological_sections = create_topological_sections(list_of_features_to_be_connected)
								if (len(topological_sections) >= 1):
									topological_ft = create_topological_line_feature(topological_sections)
									topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
									if (topological_ft is not None):
										topological_ft.set_name(sgdu_name)
										topological_ft.set_valid_time(topological_begin_age, topological_end_age)
										output_topological_tectonic_plates.add(topological_ft)
									for each_original_ft in list_of_features_to_be_connected:
										if (each_original_ft.get_feature_id() not in already_included_line_features):
											output_topological_tectonic_plates.add(each_original_ft)
											already_included_line_features.append(each_original_ft.get_feature_id())
		reconstruction_time = reconstruction_time - time_interval
	output_topological_tectonic_plates.write('topological_tectonic_plates_'+modelname+'_'+yearmonthday+'.gpml')

def find_the_order_to_complete_topological_feature_old(collection_of_records):
	# dic_of_potential_ends = {}
	# for first, polylid, second in collection_of_records:
		# if (second is None):
			# dic_of_potential_ends[polylid] = (first, polylid, second)
	# start_record = None
	# end_record = None
	# middle_record = None
	# current_end_record = None
	# temp_dic_order = {}
	# output_list_of_order = []
	# if (len(collection_of_records) == 1):
		# first, polylid, second = collection_of_records[0]
		# temp_dic_order[polylid] = [(first, polylid, second)]
		# return temp_dic_order
	# elif (len(collection_of_records) > 1):
		# list_of_already_included_pairs = []
		# if (len(dic_of_potential_ends) > 0):
			# for first, polylid, second in collection_of_records:
				# key = first+'_'+polylid
				# if (polylid in dic_of_potential_ends and key not in list_of_already_included_pairs and start_record is None):
					# list_of_already_included_pairs.append(key)
					# start_record = polylid
					# middle_record = first
					# if (start_record not in temp_dic_order):
						# temp_dic_order[start_record] = [(first, polylid, second)]
					# else:
						# #output everything first
						# temp_list = []
						# for t in temp_dic_order[start_record]:
							# temp_list.append(t)
						# output_list_of_order.append(temp_list)
						# temp_dic_order[start_record] = [(first, polylid, second)]
		
		
		# while (end_record is None):
			# for first, polylid, second in collection_of_records:
				# if (start_record is None and middle_record is None):
					# if (second is not None):
						# start_record = first
						# middle_record = polylid
						# if (polylid not in temp_dic_order):
							# temp_dic_order[polylid] = [(first, polylid, second)]
						# current_end_record = second
					# else:
						# start_record = second
						# middle_record = polylid
						# if (polylid not in temp_dic_order):
							# temp_dic_order[polylid] = [(first, polylid, second)]
						# current_end_record = middle_record
				# elif (middle_record is not None and current_end_record is not None):
					# if (current_end_record == first or current_end_record == second):
						# temp_dic_order[middle_record].append((first, polylid, second))
						# if (current_end_record == first):
							# current_end_record = first
						# else:
							# current_end_record = second
						# if (current_end_record == start_record):
							# end_record = current_end_record
							# break
			# #reverse check at the same time 
			# if (len(temp_dic_order[polylid]) >= 1):
				# rev_first,rev_polylid,rev_second = temp_dic_order[polylid][0]
				
	# else:
		# return temp_dic_order
	
	#mini dataframe 
	mini_df = pd.DataFrame.from_records(collection_of_records, columns = ['first','polylid','second'])
	mini_df_distinct = mini_df.drop_duplicates(subset = ['first','polylid','second'])
	
	mini_df_distinct = collection_of_records
	
	dic_of_potential_ends = {}
	dic_of_ordered_line_feats = {}
	output = []
	for first, polylid, second in mini_df_distinct.itertuples(index = False, name = None):
		if (second is None or pd.isna(second) == True):
			key = first+'$'+polylid
			dic_of_potential_ends[key] = (first, polylid)
	prev_p, prev_e = None, None
	current_list = []
	for first, polylid, second in mini_df_distinct.itertuples(index = False, name = None):
		prev_p, prev_e = polylid, second
		current_list.append(first)
		current_list.append(polylid)
		if (second is not None and pd.isna(second) == False):
			current_list.append(second)
		else:
			prev_p, prev_e = polylid, first
		key = prev_p+'$'+prev_e
		dic_of_ordered_line_feats[key] = prev_p, prev_e
		break #simply initiate the dictionary to start
	is_completed = False 
	while (prev_p is not None and prev_e is not None):
		next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_e) | (mini_df_distinct['second'] == prev_e)) & (mini_df_distinct['polylid'] != prev_p)]
		if (len(next_records) == 0):
			break
		else:
			is_finish_a_set = False
			for first, polylid, second in next_records.itertuples(index = False, name = None):
				if (polylid == prev_p):
					continue #take different record
				else:
					if (first == prev_e):
						if (second is not None and pd.isna(second) == False):
							key = second+'$'+polylid
							rev_key = polylid+'$'+second
							start = current_list[0]
							if (start == polylid):
								is_finish_a_set = True
								temp_list = []
								for item in current_list:
									temp_list.append(item)
								output.append(temp_list)
								current_list[:] = [] 
								is_completed = True
								for check_first, check_polylid, check_second in mini_df_distinct.itertuples(index = False, name = None):
									check_first_key = check_first+'$'+check_polylid
									check_first_rev_key = check_polylid+'$'+check_first
									check_second_key = None
									check_second_rev_key = None
									if (pd.isna(check_second) == False):
										check_second_key = check_second+'$'+check_polylid
										check_second_rev_key = check_polylid+'$'+check_second
									if ((check_first_key not in dic_of_ordered_line_feats) and (check_first_rev_key not in dic_of_ordered_line_feats)):
										if (check_second_key is not None):
											if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
												current_list[:] = []
												prev_p, prev_e = check_polylid, check_second 
												current_list.append(check_first)
												current_list.append(check_polylid)
												if (check_second is not None and pd.isna(check_second) == False):
													current_list.append(check_second)
												else:
													prev_p, prev_e = check_polylid, check_first
												key = prev_p+'$'+prev_e
												dic_of_ordered_line_feats[key] = prev_p, prev_e
												is_completed = False
												break #simply initiate the dictionary to start
										else:
											current_list[:] = []
											prev_p, prev_e = check_polylid, check_second 
											current_list.append(check_first)
											current_list.append(check_polylid)
											if (check_second is not None and pd.isna(check_second) == False):
												current_list.append(check_second)
											else:
												prev_p, prev_e = check_polylid, check_first
											key = prev_p+'$'+prev_e
											dic_of_ordered_line_feats[key] = prev_p, prev_e
											is_completed = False
											break #simply initiate the dictionary to start
								if (is_completed == True):
									prev_p, prev_e = None, None
									break
								elif (is_finish_a_set == True):
									is_completed = False
									break
							else:
								if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
									prev_p, prev_e = polylid, second
									current_list.append(prev_p)
									current_list.append(prev_e)
									key = prev_p+'$'+prev_e
									dic_of_ordered_line_feats[key] = prev_p, prev_e
								else:
									first_pair = current_list[0]+'$'+current_list[1]
									first_rev_pair = current_list[1]+'$'+current_list[0]
									if ((first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends) and (key in dic_of_potential_ends or rev_key in dic_of_potential_ends)):
										is_finish_a_set = True
										temp_list = []
										for item in current_list:
											temp_list.append(item)
										output.append(temp_list)
										is_completed = True
										current_list[:] = [] 
										for check_first, check_polylid, check_second in mini_df_distinct.itertuples(index = False, name = None):
											check_first_key = check_first+'$'+check_polylid
											check_first_rev_key = check_polylid+'$'+check_first
											check_second_key = None
											check_second_rev_key = None
											if (pd.isna(check_second) == False):
												check_second_key = check_second+'$'+check_polylid
												check_second_rev_key = check_polylid+'$'+check_second
											if ((check_first_key not in dic_of_ordered_line_feats) and (check_first_rev_key not in dic_of_ordered_line_feats)):
												if (check_second_key is not None):
													if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
														current_list[:] = []
														prev_p, prev_e = check_polylid, check_second 
														current_list.append(check_first)
														current_list.append(check_polylid)
														if (check_second is not None and pd.isna(check_second) == False):
															current_list.append(check_second)
														else:
															prev_p, prev_e = check_polylid, check_first
														key = prev_p+'$'+prev_e
														dic_of_ordered_line_feats[key] = prev_p, prev_e
														is_completed = False
														break #simply initiate the dictionary to start
												else:
													current_list[:] = []
													prev_p, prev_e = check_polylid, check_second 
													current_list.append(check_first)
													current_list.append(check_polylid)
													if (check_second is not None and pd.isna(check_second) == False):
														current_list.append(check_second)
													else:
														prev_p, prev_e = check_polylid, check_first
													key = prev_p+'$'+prev_e
													dic_of_ordered_line_feats[key] = prev_p, prev_e
													is_completed = False
													break #simply initiate the dictionary to start
										if (is_completed == True):
											prev_p, prev_e = None, None
											break
										elif (is_finish_a_set == True):
											is_completed = False
											break
						else:
							key = first+'$'+polylid
							rev_key = polylid+'$'+first
							if (start == polylid):
								is_finish_a_set = True
								temp_list = []
								for item in current_list:
									temp_list.append(item)
								output.append(temp_list)
								current_list[:] = []
								is_completed = True
								for check_first, check_polylid, check_second in mini_df_distinct.itertuples(index = False, name = None):
									check_first_key = check_first+'$'+check_polylid
									check_first_rev_key = check_polylid+'$'+check_first
									check_second_key = None
									check_second_rev_key = None
									if (pd.isna(check_second) == False):
										check_second_key = check_second+'$'+check_polylid
										check_second_rev_key = check_polylid+'$'+check_second
									if ((check_first_key not in dic_of_ordered_line_feats) and (check_first_rev_key not in dic_of_ordered_line_feats)):
										if (check_second_key is not None):
											if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
												current_list[:] = []
												prev_p, prev_e = check_polylid, check_second 
												current_list.append(check_first)
												current_list.append(check_polylid)
												if (check_second is not None and pd.isna(check_second) == False):
													current_list.append(check_second)
												else:
													prev_p, prev_e = check_polylid, check_first
												key = prev_p+'$'+prev_e
												dic_of_ordered_line_feats[key] = prev_p, prev_e
												is_completed = False
												break #simply initiate the dictionary to start
										else:
											current_list[:] = []
											prev_p, prev_e = check_polylid, check_second 
											current_list.append(check_first)
											current_list.append(check_polylid)
											if (check_second is not None and pd.isna(check_second) == False):
												current_list.append(check_second)
											else:
												prev_p, prev_e = check_polylid, check_first
											key = prev_p+'$'+prev_e
											dic_of_ordered_line_feats[key] = prev_p, prev_e
											is_completed = False
											break #simply initiate the dictionary to start
								if (is_completed == True):
									prev_p, prev_e = None, None
									break
								if (is_finish_a_set == True):
									is_completed = False
									break
							else:
								if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
									prev_p, prev_e = polylid, first
									current_list.append(prev_p)
									current_list.append(prev_e)
									key = prev_p+'$'+prev_e
									dic_of_ordered_line_feats[key] = prev_p, prev_e
								else:
									first_pair = current_list[0]+'$'+current_list[1]
									first_rev_pair = current_list[1]+'$'+current_list[0]
									if ((first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends) and (key in dic_of_potential_ends or rev_key in dic_of_potential_ends)):
										is_finish_a_set = True
										
										temp_list = []
										for item in current_list:
											temp_list.append(item)
										output.append(temp_list)
										current_list[:] = []
										is_completed = True
										for check_first, check_polylid, check_second in mini_df_distinct.itertuples(index = False, name = None):
											check_first_key = check_first+'$'+check_polylid
											check_first_rev_key = check_polylid+'$'+check_first
											check_second_key = None
											check_second_rev_key = None
											if (pd.isna(check_second) == False):
												check_second_key = check_second+'$'+check_polylid
												check_second_rev_key = check_polylid+'$'+check_second
											if ((check_first_key not in dic_of_ordered_line_feats) and (check_first_rev_key not in dic_of_ordered_line_feats)):
												if (check_second_key is not None):
													if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
														current_list[:] = []
														prev_p, prev_e = check_polylid, check_second 
														current_list.append(check_first)
														current_list.append(check_polylid)
														if (check_second is not None and pd.isna(check_second) == False):
															current_list.append(check_second)
														else:
															prev_p, prev_e = check_polylid, check_first
														key = prev_p+'$'+prev_e
														dic_of_ordered_line_feats[key] = prev_p, prev_e
														is_completed = False
														break #simply initiate the dictionary to start
												else:
													current_list[:] = []
													prev_p, prev_e = check_polylid, check_second 
													current_list.append(check_first)
													current_list.append(check_polylid)
													if (check_second is not None and pd.isna(check_second) == False):
														current_list.append(check_second)
													else:
														prev_p, prev_e = check_polylid, check_first
													key = prev_p+'$'+prev_e
													dic_of_ordered_line_feats[key] = prev_p, prev_e
													is_completed = False
													break #simply initiate the dictionary to start
										if (is_completed == True):
											prev_p, prev_e = None, None
											break
										if (is_finish_a_set == True):
											is_completed = False
											break
					elif (second == prev_e):
						if (second is not None and pd.isna(second) == False):
							key = first+'$'+polylid
							rev_key = polylid+'$'+first
							start = current_list[0]
							if (start == polylid):
								is_finish_a_set = True
								temp_list = []
								for item in current_list:
									temp_list.append(item)
								output.append(temp_list)
								current_list[:] = []
								is_completed = True
								for check_first, check_polylid, check_second in mini_df_distinct.itertuples(index = False, name = None):
									check_first_key = check_first+'$'+check_polylid
									check_first_rev_key = check_polylid+'$'+check_first
									check_second_key = None
									check_second_rev_key = None
									if (pd.isna(check_second) == False):
										check_second_key = check_second+'$'+check_polylid
										check_second_rev_key = check_polylid+'$'+check_second
									if ((check_first_key not in dic_of_ordered_line_feats) and (check_first_rev_key not in dic_of_ordered_line_feats)):
										if (check_second_key is not None):
											if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
												current_list[:] = []
												prev_p, prev_e = check_polylid, check_second 
												current_list.append(check_first)
												current_list.append(check_polylid)
												if (check_second is not None and pd.isna(check_second) == False):
													current_list.append(check_second)
												else:
													prev_p, prev_e = check_polylid, check_first
												key = prev_p+'$'+prev_e
												dic_of_ordered_line_feats[key] = prev_p, prev_e
												is_completed = False
												break #simply initiate the dictionary to start
										else:
											current_list[:] = []
											prev_p, prev_e = check_polylid, check_second 
											current_list.append(check_first)
											current_list.append(check_polylid)
											if (check_second is not None and pd.isna(check_second) == False):
												current_list.append(check_second)
											else:
												prev_p, prev_e = check_polylid, check_first
											key = prev_p+'$'+prev_e
											dic_of_ordered_line_feats[key] = prev_p, prev_e
											is_completed = False
											break #simply initiate the dictionary to start
								if (is_completed == True):
									prev_p, prev_e = None, None
									break
								if (is_finish_a_set == True):
									is_completed = False
									break
							else:
								if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
									prev_p, prev_e = polylid, first
									current_list.append(prev_p)
									current_list.append(prev_e)
									key = prev_p+'$'+prev_e
									dic_of_ordered_line_feats[key] = prev_p, prev_e
								else:
									first_pair = current_list[0]+'$'+current_list[1]
									first_rev_pair = current_list[1]+'$'+current_list[0]
									if ((first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends) and (key in dic_of_potential_ends or rev_key in dic_of_potential_ends)):
										is_finish_a_set = True
										temp_list = []
										for item in current_list:
											temp_list.append(item)
										output.append(temp_list)
										current_list[:] = []
										is_completed = True
										for check_first, check_polylid, check_second in mini_df_distinct.itertuples(index = False, name = None):
											check_first_key = check_first+'$'+check_polylid
											check_first_rev_key = check_polylid+'$'+check_first
											check_second_key = None
											check_second_rev_key = None
											if (pd.isna(check_second) == False):
												check_second_key = check_second+'$'+check_polylid
												check_second_rev_key = check_polylid+'$'+check_second
											if ((check_first_key not in dic_of_ordered_line_feats) and (check_first_rev_key not in dic_of_ordered_line_feats)):
												if (check_second_key is not None):
													if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
														current_list[:] = []
														prev_p, prev_e = check_polylid, check_second 
														current_list.append(check_first)
														current_list.append(check_polylid)
														if (check_second is not None and pd.isna(check_second) == False):
															current_list.append(check_second)
														else:
															prev_p, prev_e = check_polylid, check_first
														key = prev_p+'$'+prev_e
														dic_of_ordered_line_feats[key] = prev_p, prev_e
														is_completed = False
														break #simply initiate the dictionary to start
												else:
													current_list[:] = []
													prev_p, prev_e = check_polylid, check_second 
													current_list.append(check_first)
													current_list.append(check_polylid)
													if (check_second is not None and pd.isna(check_second) == False):
														current_list.append(check_second)
													else:
														prev_p, prev_e = check_polylid, check_first
													key = prev_p+'$'+prev_e
													dic_of_ordered_line_feats[key] = prev_p, prev_e
													is_completed = False
													break #simply initiate the dictionary to start
										if (is_completed == True):
											prev_p, prev_e = None, None
										if (is_finish_a_set == True):
											is_completed = False
											break
		# if (is_completed == True):
			# break
	return output

def find_the_order_to_complete_topological_feature(collection_of_records):
	#mini dataframe 
	mini_df = pd.DataFrame.from_records(collection_of_records, columns = ['first','polylid','second'])
	mini_df_distinct = mini_df.drop_duplicates(subset = ['first','polylid','second'])
	
	mini_df_distinct = collection_of_records
	
	dic_of_potential_ends = {}
	dic_of_ordered_line_feats = {}
	output = []
	for first, polylid, second in mini_df_distinct.itertuples(index = False, name = None):
		if (second is None or pd.isna(second) == True):
			key = first+'$'+polylid
			dic_of_potential_ends[key] = (first, polylid)
	prev_p, prev_e = None, None
	current_list = []
	for first, polylid, second in mini_df_distinct.itertuples(index = False, name = None):
		prev_p, prev_e = polylid, second
		if (second is not None and pd.isna(second) == False):
			current_list.append(first)
			current_list.append(polylid)
			current_list.append(second)
			additional_key = second+'$'+polylid
			dic_of_ordered_line_feats[additional_key] = second, polylid
		else:
			prev_p, prev_e = polylid, first
			current_list.append(polylid)
			current_list.append(first)
		key = prev_p+'$'+prev_e
		dic_of_ordered_line_feats[key] = prev_p, prev_e
		break #simply initiate the dictionary to start
	is_completed = False
	is_finish_a_set = False
	while (prev_p is not None and prev_e is not None):
		print('update prev_p',prev_p,'update prev_e',prev_e)#### The issue we did not update prev_e and prev_p properly the key does not reflect values of prev_p and prev_e
		next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_e) | (mini_df_distinct['second'] == prev_e)) & (mini_df_distinct['polylid'] != prev_p)]
		print('next_records',next_records)
		print('current_list',current_list)
		print('is_finish_a_set',is_finish_a_set)
		if (len(next_records) == 0):
			current_start = current_list[0]
			#one more try because sometime second is NAN or NULL
			next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_p)) & (mini_df_distinct['polylid'] == prev_e) & (mini_df_distinct['second'].notna())]
			if (len(next_records) == 0):
				key = prev_p+'$'+prev_e
				rev_key = prev_e+'$'+prev_p
				print('key when len(next_records) == 0',key)
				if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
					dic_of_ordered_line_feats[rev_key] = prev_e, prev_p
				temp_list = []
				if (len(current_list) > 1):
					for item in current_list:
						temp_list.append(item)
					output.append(temp_list)
				current_list[:] = [] 
				#unless we complete have every record or new records of first, polylid and second giving us new set to work with
				for check_first, check_polylid, check_second in mini_df_distinct.itertuples(index = False, name = None):
					check_first_key = check_first+'$'+check_polylid
					check_first_rev_key = check_polylid+'$'+check_first
					prev_p, prev_e = None, None
					current_list[:] = []
					#print('check_first_key',check_first_key)
					#exit()
					check_second_key = None
					check_second_rev_key = None
					if (pd.isna(check_second) == False):
						check_second_key = check_second+'$'+check_polylid
						check_second_rev_key = check_polylid+'$'+check_second
						#print('check_second_key',check_second_key)
						
					if ((check_first_key not in dic_of_ordered_line_feats) and (check_first_rev_key not in dic_of_ordered_line_feats)):
						if (check_second_key is not None):
							if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
								prev_p, prev_e = check_polylid, check_second
								next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_e) | (mini_df_distinct['second'] == prev_e)) & (mini_df_distinct['polylid'] != prev_p)]
								if (len(next_records) == 0):
									#one more try because sometime second is NAN or NULL
									next_records = mini_df_distinct.loc[(((mini_df_distinct['first'] == prev_p) & (mini_df_distinct['polylid'] == prev_e)) | ((mini_df_distinct['first'] == prev_e) & (mini_df_distinct['polylid'] == prev_p)))& (mini_df_distinct['second'].notna())]
								if (len(next_records) > 0):
									current_list.append(check_first)
									current_list.append(check_polylid)
									current_list.append(check_second)
									key = prev_p+'$'+prev_e
									dic_of_ordered_line_feats[key] = prev_p, prev_e
									break #simply initiate the dictionary to start
								else:
									prev_e, prev_p = check_first, check_polylid
									next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_e) | (mini_df_distinct['second'] == prev_e)) & (mini_df_distinct['polylid'] != prev_p)]
									if (len(next_records) == 0):
										#one more try because sometime second is NAN or NULL
										next_records = mini_df_distinct.loc[(((mini_df_distinct['first'] == prev_p) & (mini_df_distinct['polylid'] == prev_e)) | ((mini_df_distinct['first'] == prev_e) & (mini_df_distinct['polylid'] == prev_p)))& (mini_df_distinct['second'].notna())]
									if (len(next_records) > 0):
										current_list.append(check_polylid)
										current_list.append(check_first)
										key = prev_p+'$'+prev_e
										dic_of_ordered_line_feats[key] = prev_p, prev_e
										
										break #simply initiate the dictionary to start
							else:
								prev_e, prev_p = check_first, check_polylid
								next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_e) | (mini_df_distinct['second'] == prev_e)) & (mini_df_distinct['polylid'] != prev_p)]
								if (len(next_records) == 0):
									#one more try because sometime second is NAN or NULL
									next_records = mini_df_distinct.loc[(((mini_df_distinct['first'] == prev_p) & (mini_df_distinct['polylid'] == prev_e)) | ((mini_df_distinct['first'] == prev_e) & (mini_df_distinct['polylid'] == prev_p)))& (mini_df_distinct['second'].notna())]
								if (len(next_records) > 0):
									current_list.append(check_polylid)
									current_list.append(check_first)
									key = prev_p+'$'+prev_e
									dic_of_ordered_line_feats[key] = prev_p, prev_e
									break #simply initiate the dictionary to start
						else:
							prev_p, prev_e = check_first, check_polylid
							next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_e) | (mini_df_distinct['second'] == prev_e)) & (mini_df_distinct['polylid'] != prev_p)]
							if (len(next_records) == 0):
								#one more try because sometime second is NAN or NULL
								next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_p)) & (mini_df_distinct['polylid'] == prev_e) & (mini_df_distinct['second'].notna())]
							if (len(next_records) > 0):
								current_list.append(check_polylid)
								current_list.append(check_first)
								key = prev_p+'$'+prev_e
								dic_of_ordered_line_feats[key] = prev_p, prev_e
								break #simply initiate the dictionary to start
						
					else:
						if (check_second_key is not None):
							if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
								prev_p, prev_e = check_polylid, check_second
								next_records = mini_df_distinct.loc[((mini_df_distinct['first'] == prev_e) | (mini_df_distinct['second'] == prev_e)) & (mini_df_distinct['polylid'] != prev_p) & (mini_df_distinct['second'].notna())]
								if (len(next_records) == 0):
									#one more try because sometime second is NAN or NULL
									next_records = mini_df_distinct.loc[(((mini_df_distinct['first'] == prev_p) & (mini_df_distinct['polylid'] == prev_e)) | ((mini_df_distinct['first'] == prev_e) & (mini_df_distinct['polylid'] == prev_p)))& (mini_df_distinct['second'].notna())]
								if (len(next_records) > 0):
									current_list.append(check_first)
									current_list.append(check_polylid)
									current_list.append(check_second)
									key = prev_p+'$'+prev_e
									dic_of_ordered_line_feats[key] = prev_p, prev_e
									break #simply initiate the dictionary to start
				if (len(next_records) == 0):
					prev_p, prev_e = None, None
			else:
				temp_holder = prev_p
				prev_p = prev_e
				prev_e = temp_holder
		else:
			#already_updated_prev_records = False
			print('prev value of key before updating',key)
			print('current prev_p',prev_p,'current prev_e',prev_e)
			prev_key = None
			required_new_records = False
			for first, polylid, second in next_records.itertuples(index = False, name = None):
				print('first, polylid, second',first, polylid, second)
				print('current_list',current_list)
				if (polylid == prev_p):
					continue #take different record
				else:
					if (first == prev_p and pd.isna(second) == True and polylid == prev_e):
						start = current_list[0]
						if (start == prev_e): #only two line features to complete the polygon
							key = prev_p+'$'+prev_e
							rev_key = prev_e+'$'+prev_p
							if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
								dic_of_ordered_line_feats[key] = polylid, first
							is_finish_a_set = True
							if (len(current_list) > 1):
								temp_list = []
								for item in current_list:
									temp_list.append(item)
								output.append(temp_list)
								#check to make sure that we have stored every pair of line feature that is possible to be connected
								number_of_line_fts = len(current_list)
								for index_of_stored_id in range(0,number_of_line_fts-1):
									stored_prev_p = current_list[index_of_stored_id]
									stored_prev_e = current_list[index_of_stored_id+1]
									stored_key = stored_prev_p+'$'+stored_prev_e
									stored_rev_key = stored_prev_e+'$'+stored_prev_p
									if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
										dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
								#current_list[:] = [] 
							else:
								#check to make sure that we have stored every pair of line feature that is possible to be connected
								number_of_line_fts = len(current_list)
								for index_of_stored_id in range(0,number_of_line_fts-1):
									stored_prev_p = current_list[index_of_stored_id]
									stored_prev_e = current_list[index_of_stored_id+1]
									stored_key = stored_prev_p+'$'+stored_prev_e
									stored_rev_key = stored_prev_e+'$'+stored_prev_p
									if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
										dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
								#manually add the list 
								output.append([prev_p,prev_e])
								#current_list[:] = []
							break
					elif (first == prev_e):
						if (second is not None and pd.isna(second) == False):
							key = second+'$'+polylid
							rev_key = polylid+'$'+second
							#print('key',key)
							print('key 1',key)
							print('key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats',key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats)
							if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
								already_updated_prev_records = True
								prev_p, prev_e = polylid, second
								current_list.append(prev_p)
								current_list.append(prev_e)
								key = prev_p+'$'+prev_e
								dic_of_ordered_line_feats[key] = prev_p, prev_e
								additional_key = first+'$'+polylid
								dic_of_ordered_line_feats[additional_key] = first, polylid
								#check whether we finish a set
								start = current_list[0]
								if (start == prev_e):
									is_finish_a_set = True
									temp_list = []
									for item in current_list:
										temp_list.append(item)
									output.append(temp_list)
									#check to make sure that we have stored every pair of line feature that is possible to be connected
									number_of_line_fts = len(current_list)
									for index_of_stored_id in range(0,number_of_line_fts):
										stored_prev_p = current_list[index_of_stored_id]
										if (index_of_stored_id+1 == number_of_line_fts):
											stored_prev_e = current_list[0]
										else:
											stored_prev_e = current_list[index_of_stored_id+1]
										stored_key = stored_prev_p+'$'+stored_prev_e
										stored_rev_key = stored_prev_e+'$'+stored_prev_p
										if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
											dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
									#current_list[:] = []
								break#because we just update value
							else:
								#check whether we finish a set
								start = current_list[0]
								if (start == prev_e or start == polylid or start == prev_p):
									is_finish_a_set = True
									temp_list = []
									for item in current_list:
										temp_list.append(item)
									output.append(temp_list)
									#check to make sure that we have stored every pair of line feature that is possible to be connected
									number_of_line_fts = len(current_list)
									for index_of_stored_id in range(0,number_of_line_fts):
										stored_prev_p = current_list[index_of_stored_id]
										if (index_of_stored_id+1 == number_of_line_fts):
											stored_prev_e = current_list[0]
										else:
											stored_prev_e = current_list[index_of_stored_id+1]
										stored_key = stored_prev_p+'$'+stored_prev_e
										stored_rev_key = stored_prev_e+'$'+stored_prev_p
										if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
											dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
									#current_list[:] = []
									break
								else:
									first_pair = current_list[0]+'$'+current_list[1]
									first_rev_pair = current_list[1]+'$'+current_list[0]
									if ((key in dic_of_potential_ends or rev_key in dic_of_potential_ends)):
										if (first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends):
											is_finish_a_set = True
											temp_list = []
											for item in current_list:
												temp_list.append(item)
											output.append(temp_list)
										 
											#check to make sure that we have stored every pair of line feature that is possible to be connected
											number_of_line_fts = len(current_list)
											for index_of_stored_id in range(0,number_of_line_fts):
												stored_prev_p = current_list[index_of_stored_id]
												if (index_of_stored_id+1 == number_of_line_fts):
													stored_prev_e = current_list[0]
												else:
													stored_prev_e = current_list[index_of_stored_id+1]
												stored_key = stored_prev_p+'$'+stored_prev_e
												stored_rev_key = stored_prev_e+'$'+stored_prev_p
												if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
													dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
											#current_list[:] = []
											break
									else:
										is_finish_a_set = True
										#check to make sure that we have stored every pair of line feature that is possible to be connected
										number_of_line_fts = len(current_list)
										for index_of_stored_id in range(0,number_of_line_fts):
											stored_prev_p = current_list[index_of_stored_id]
											if (index_of_stored_id+1 == number_of_line_fts):
												stored_prev_e = current_list[0]
											else:
												stored_prev_e = current_list[index_of_stored_id+1]
											stored_key = stored_prev_p+'$'+stored_prev_e
											stored_rev_key = stored_prev_e+'$'+stored_prev_p
											if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
												dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
										#current_list[:] = []
										break
						else:
							key = first+'$'+polylid
							rev_key = polylid+'$'+first
							print('key 2',key)
							print('key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats',key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats)
							# exit()
							if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
								dic_of_ordered_line_feats[key] = polylid, first
							first_pair = current_list[0]+'$'+current_list[1]
							first_rev_pair = current_list[1]+'$'+current_list[0]
							print('first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends',first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends)
							if ((key in dic_of_potential_ends or rev_key in dic_of_potential_ends)):
								if (first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends):
									current_list.append(polylid)
									is_finish_a_set = True
									temp_list = []
									for item in current_list:
										temp_list.append(item)
									output.append(temp_list)
								
									#check to make sure that we have stored every pair of line feature that is possible to be connected
									number_of_line_fts = len(current_list)
									for index_of_stored_id in range(0,number_of_line_fts):
										stored_prev_p = current_list[index_of_stored_id]
										if (index_of_stored_id+1 == number_of_line_fts):
											stored_prev_e = current_list[0]
										else:
											stored_prev_e = current_list[index_of_stored_id+1]
										stored_key = stored_prev_p+'$'+stored_prev_e
										stored_rev_key = stored_prev_e+'$'+stored_prev_p
										if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
											dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
									#current_list[:] = []
									break
								else:
									last_element = current_list[-1]
									if (last_element != polylid):
										current_list.append(polylid)
									is_finish_a_set = True
									temp_list = []
									for item in current_list:
										temp_list.append(item)
									output.append(temp_list)
									#check to make sure that we have stored every pair of line feature that is possible to be connected
									number_of_line_fts = len(current_list)
									for index_of_stored_id in range(0,number_of_line_fts):
										stored_prev_p = current_list[index_of_stored_id]
										if (index_of_stored_id+1 == number_of_line_fts):
											stored_prev_e = current_list[0]
										else:
											stored_prev_e = current_list[index_of_stored_id+1]
										stored_key = stored_prev_p+'$'+stored_prev_e
										stored_rev_key = stored_prev_e+'$'+stored_prev_p
										if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
											dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
									break
							# else:
								# if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
									# already_updated_prev_records = True
									# prev_p, prev_e = polylid, first
									# current_list.append(prev_p)
									# current_list.append(prev_e)
									# key = prev_p+'$'+prev_e
									# dic_of_ordered_line_feats[key] = prev_p, prev_e
									# break
								# else:
									# first_pair = current_list[0]+'$'+current_list[1]
									# first_rev_pair = current_list[1]+'$'+current_list[0]
									# if ((first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends) and (key in dic_of_potential_ends or rev_key in dic_of_potential_ends)):
										# is_finish_a_set = True
										# temp_list = []
										# for item in current_list:
											# temp_list.append(item)
										# output.append(temp_list)
										# current_list[:] = []
										# break
					elif (second == prev_e):
						if (second is not None and pd.isna(second) == False):
							key = first+'$'+polylid
							rev_key = polylid+'$'+first
							print('key 3',key)
							print('key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats',key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats)
							if (key not in dic_of_ordered_line_feats and rev_key not in dic_of_ordered_line_feats):
								already_updated_prev_records = True
								prev_p, prev_e = polylid, first
								current_list.append(prev_p)
								current_list.append(prev_e)
								key = prev_p+'$'+prev_e
								dic_of_ordered_line_feats[key] = prev_p, prev_e
								additional_key = second+'$'+polylid
								dic_of_ordered_line_feats[additional_key] = second, polylid
								#check whether we finish a set
								start = current_list[0]
								if (start == prev_e):
									is_finish_a_set = True
									temp_list = []
									for item in current_list:
										temp_list.append(item)
									output.append(temp_list)
									#check to make sure that we have stored every pair of line feature that is possible to be connected
									number_of_line_fts = len(current_list)
									for index_of_stored_id in range(0,number_of_line_fts):
										stored_prev_p = current_list[index_of_stored_id]
										if (index_of_stored_id+1 == number_of_line_fts):
											stored_prev_e = current_list[0]
										else:
											stored_prev_e = current_list[index_of_stored_id+1]
										stored_key = stored_prev_p+'$'+stored_prev_e
										stored_rev_key = stored_prev_e+'$'+stored_prev_p
										if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
											dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
									#current_list[:] = []
								break #because we just updat value
							else:
								print('output',output)
								#check whether we finish a set
								start = current_list[0]
								if (start == prev_e or start == polylid or start == prev_p):
									is_finish_a_set = True
									temp_list = []
									for item in current_list:
										temp_list.append(item)
									output.append(temp_list)
									#check to make sure that we have stored every pair of line feature that is possible to be connected
									number_of_line_fts = len(current_list)
									for index_of_stored_id in range(0,number_of_line_fts):
										stored_prev_p = current_list[index_of_stored_id]
										if (index_of_stored_id+1 == number_of_line_fts):
											stored_prev_e = current_list[0]
										else:
											stored_prev_e = current_list[index_of_stored_id+1]
										stored_key = stored_prev_p+'$'+stored_prev_e
										stored_rev_key = stored_prev_e+'$'+stored_prev_p
										if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
											dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
									#current_list[:] = []
									break
								else:
									first_pair = current_list[0]+'$'+current_list[1]
									first_rev_pair = current_list[1]+'$'+current_list[0]
									if ((first_pair in dic_of_potential_ends or first_rev_pair in dic_of_potential_ends) and (key in dic_of_potential_ends or rev_key in dic_of_potential_ends)):
										is_finish_a_set = True
										temp_list = []
										for item in current_list:
											temp_list.append(item)
										output.append(temp_list)
										#check to make sure that we have stored every pair of line feature that is possible to be connected
										number_of_line_fts = len(current_list)
										for index_of_stored_id in range(0,number_of_line_fts):
											stored_prev_p = current_list[index_of_stored_id]
											if (index_of_stored_id+1 == number_of_line_fts):
												stored_prev_e = current_list[0]
											else:
												stored_prev_e = current_list[index_of_stored_id+1]
											stored_key = stored_prev_p+'$'+stored_prev_e
											stored_rev_key = stored_prev_e+'$'+stored_prev_p
											if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
												dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
										#current_list[:] = []
										break
									else:
										is_finish_a_set = True
										#check to make sure that we have stored every pair of line feature that is possible to be connected
										number_of_line_fts = len(current_list)
										for index_of_stored_id in range(0,number_of_line_fts):
											stored_prev_p = current_list[index_of_stored_id]
											if (index_of_stored_id+1 == number_of_line_fts):
												stored_prev_e = current_list[0]
											else:
												stored_prev_e = current_list[index_of_stored_id+1]
											stored_key = stored_prev_p+'$'+stored_prev_e
											stored_rev_key = stored_prev_e+'$'+stored_prev_p
											if (stored_key not in dic_of_ordered_line_feats and stored_rev_key not in dic_of_ordered_line_feats):
												dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
										#current_list[:] = []
										break
				# if (already_updated_prev_records == True):
					# break
			if (key is not None and rev_key is not None):
				if (prev_key is None):
					prev_key = key
				else:
					if (prev_key == key or prev_key == rev_key):
						required_new_records = True
			#check whether we finish a set
			# if (len(current_list) > 1):
				# start = current_list[0]
				# if (start == prev_e or is_finish_a_set == True):
					# is_finish_a_set = True
					# temp_list = []
					# for item in current_list:
						# temp_list.append(item)
					# output.append(temp_list)
					# #check to make sure that we have stored every pair of line feature that is possible to be connected
					# number_of_line_fts = len(current_list)
					# for index_of_stored_id in range(0,number_of_line_fts-1):
						# stored_prev_p = current_list[index_of_stored_id]
						# stored_prev_e = current_list[index_of_stored_id+1]
						# stored_key = stored_prev_p+'$'+stored_prev_e
						# stored_rev_key = stored_prev_e+'$'+stored_prev_p
						# if (stored_key not in dic_of_ordered_line_feats and stored_key not in dic_of_ordered_line_feats):
							# dic_of_ordered_line_feats[stored_key] = stored_prev_p, stored_prev_e
					# current_list[:] = []
			#need to find a new prev_p and prev_e if we have finished a set and start a new set or we have not updated new values
			if (is_finish_a_set == True):
				print('finished set',output)
				print('prev_p',prev_p,'prev_e',prev_e)
				current_list[:] = []
				is_finish_a_set = False 
				is_completed = True #hypothetically set is_completed to True
				for check_first, check_polylid, check_second in mini_df_distinct.itertuples(index = False, name = None):
					check_first_key = check_first+'$'+check_polylid
					check_first_rev_key = check_polylid+'$'+check_first
					#print('check_first_key',check_first_key)
					#exit()
					check_second_key = None
					check_second_rev_key = None
					if (pd.isna(check_second) == False):
						check_second_key = check_second+'$'+check_polylid
						check_second_rev_key = check_polylid+'$'+check_second
						#print('check_second_key',check_second_key)
					if ((check_first_key not in dic_of_ordered_line_feats) and (check_first_rev_key not in dic_of_ordered_line_feats)):
						is_completed = False
						#current_list[:] = []
						prev_p, prev_e = check_polylid, check_first 
						current_list.append(prev_p)
						current_list.append(prev_e)
						key = prev_p+'$'+prev_e
						dic_of_ordered_line_feats[key] = prev_p, prev_e
						break #simply initiate the dictionary to start
					else:
						if (check_second_key is not None):
							if ((check_second_key not in dic_of_ordered_line_feats) and (check_second_rev_key not in dic_of_ordered_line_feats)):
								is_completed = False
								#current_list[:] = []
								prev_p, prev_e = check_polylid, check_second 
								#current_list.append(check_first)
								current_list.append(check_polylid)
								current_list.append(check_second)
								key = prev_p+'$'+prev_e
								dic_of_ordered_line_feats[key] = prev_p, prev_e
								break #simply initiate the dictionary to start
			# elif (already_updated_prev_records == False):
				# #this when we have finished the route A-B but the other route A-C needs to be found too
				# #use the prev_p to help us eliminate that the route that we have already checked
				# print("")
			if (is_completed == True):
				prev_p, prev_e = None, None
				break
			
	print('output',output)
	return output

def find_the_order_to_complete_topological_feature_using_dic_tree(collection_of_records):
	warning_records = []
	dic_tree = {}
	for first, polylid, second in collection_of_records.itertuples(index = False, name = None):
		if (polylid not in dic_tree):
			dic_tree[polylid] = (first,second)
		else:
			stored_first = dic_tree[polylid][0]
			stored_second = dic_tree[polylid][1]
			if ((stored_first != second and stored_first != first) or (stored_second != first and stored_second != second)):
				warning_records.append((first, polylid, second))
	dic_already_processed = {}
	current_list = []
	output = []
	for polylid in dic_tree:
		current_first = dic_tree[polylid][0]
		current_second = dic_tree[polylid][1]
		#from first 
		key = current_first+'$'+polylid
		rev_key = polylid+'$'+current_first
		if (key not in dic_already_processed and rev_key not in dic_already_processed):
			if (pd.isna(current_second) == False):
				dic_already_processed[key] = current_first,polylid,current_second
				current_list.append(polylid)
				current_list.append(current_first)
				break
	if (len(current_list) == 0):
		already_checked_polylid = []
		for polylid in dic_tree:
			already_checked_polylid.append(polylid)
			current_first = dic_tree[polylid][0]
			current_second = dic_tree[polylid][1]
			#from first 
			key = current_first+'$'+polylid
			rev_key = polylid+'$'+current_first
			if (key not in dic_already_processed and rev_key not in dic_already_processed):
				dic_already_processed[key] = current_first,polylid
				if (len(current_list) == 0):
					current_list.append(polylid)
					current_list.append(current_first)
					break
		prev_element = current_list[-1]
		current_start = current_list[0]
		while (prev_element is not None):
			current_first = dic_tree[prev_element][0]
			current_second = dic_tree[prev_element][1]
			if (current_first == current_start):
				already_checked_polylid.append(current_first)
				temp_list = []
				for element in current_list:
					temp_list.append(element)
				output.append(temp_list)
				current_list[:] = []
				prev_element = None
				current_start = None
				for polylid in dic_tree:
					if (polylid not in already_checked_polylid):
						already_checked_polylid.append(polylid)
						current_first = dic_tree[polylid][0]
						current_second = dic_tree[polylid][1]
						current_list.append(polylid)
						current_list.append(current_first)
						prev_element = current_list[-1]
						current_start = current_list[0]
						break
		return output
		
	start_element = current_list[0]
	prev_element = current_list[-1]
	is_completed = False
	while ((is_completed == False)):
		print('start_element',start_element,'prev_element',prev_element)
		print('current_list', current_list)
		current_first = dic_tree[prev_element][0]
		current_second = dic_tree[prev_element][1]
		print('dic_tree[prev_element]',dic_tree[prev_element])
		last_neighbour = current_list[-2]
		is_new_prev_element = False
		print('last_neighbour',last_neighbour)
		#from first
		if (current_first != last_neighbour):
			key = current_first+'$'+prev_element
			rev_key = prev_element+'$'+current_first
			if (key not in dic_already_processed and rev_key not in dic_already_processed):
				print('from first key', key)
				dic_already_processed[key] = current_first,prev_element,current_second
				current_list.append(current_first)
				is_new_prev_element = True
				prev_element = current_list[-1]
		#from second
		elif (current_second != last_neighbour and pd.isna(current_second) == False):
			key = current_second+'$'+prev_element
			rev_key = prev_element+'$'+current_second
			if (key not in dic_already_processed and rev_key not in dic_already_processed):
				print('from second key', key)
				dic_already_processed[key] = current_first,prev_element,current_second
				current_list.append(current_second)
				is_new_prev_element = True
				prev_element = current_list[-1]
		#if (is_new_prev_element == False or pd.isna(prev_element) == True):
		if (is_new_prev_element == False):
			#try to see whether the other path from start will work 
			temp_first = dic_tree[start_element][0]
			temp_second = dic_tree[start_element][1]
			if (temp_second is not None and pd.isna(temp_second) == False):
				temp_second_key = start_element+'$'+temp_second
				temp_second_rev_key = temp_second+'$'+start_element
				if (temp_second_key not in dic_already_processed and temp_second_rev_key not in dic_already_processed):
					dic_already_processed[temp_second_key] = temp_first,start_element,temp_second
					#reverse the list
					current_list.reverse()
					#update start element 
					start = current_list[0]
					#add new member
					current_list.append(temp_second)
					is_new_prev_element = True
					prev_element = current_list[-1]
		if (is_new_prev_element == False or start_element == prev_element):
			#stop the current set and start a new one 
			if (len(current_list) > 0):
				temp_list = []
				for element in current_list:
					temp_list.append(element)
				output.append(temp_list)
			#check to make sure all the keys were created and stored properly
			number_of_line_fts = len(current_list)
			for index_of_stored_id in range(0,number_of_line_fts-1):
				stored_prev_p = current_list[index_of_stored_id]
				# if ((index_of_stored_id+1) == number_of_line_fts):
					# stored_prev_e = current_list[0]
				# else:
					# stored_prev_e = current_list[index_of_stored_id+1]
				stored_prev_e = current_list[index_of_stored_id+1]
				stored_key = stored_prev_p+'$'+stored_prev_e
				stored_rev_key = stored_prev_e+'$'+stored_prev_p
				if (stored_key not in dic_already_processed and stored_rev_key not in dic_already_processed):
					tuple = dic_tree[stored_prev_p]
					dic_already_processed[stored_key] = tuple[0],stored_prev_p,tuple[1]
			current_list[:] = []
			#check whether we have completed every record 
			is_completed = True #hypothetically set is_completed to True
			for check_polylid in dic_tree:
				check_first = dic_tree[check_polylid][0]
				check_second = dic_tree[check_polylid][1]
				check_first_key = check_first+'$'+check_polylid
				check_first_rev_key = check_polylid+'$'+check_first
				check_second_key = None
				check_second_rev_key = None
				if (pd.isna(check_second) == False):
					check_second_key = check_second+'$'+check_polylid
					check_second_rev_key = check_polylid+'$'+check_second
					#print('check_second_key',check_second_key)
				if ((check_first_key not in dic_already_processed) and (check_first_rev_key not in dic_already_processed)):
					is_completed = False
					#from first 
					dic_already_processed[check_first_key] = check_first,check_polylid,check_second
					current_list.append(check_polylid)
					current_list.append(check_first)
					start_element = current_list[0]
					prev_element = current_list[-1]
					break #simply initiate the dictionary to start
				else:
					if (check_second_key is not None):
						if ((check_second_key not in dic_already_processed) and (check_second_rev_key not in dic_already_processed)):
							is_completed = False
							#from second 
							dic_already_processed[check_second_key] = check_first,check_polylid,check_second
							current_list.append(check_polylid)
							current_list.append(check_second)
							start_element = current_list[0]
							prev_element = current_list[-1]
							break #simply initiate the dictionary to start
		if (is_completed == True):
			break
	print(output)
	return output

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = mean(lat_values)
				mean_lon = mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def create_tectonic_plates(order_to_connect_lines_csv, supergdu_features, line_feats_from_div_process, line_feats_from_conv_process, plate_boundary_zone_feats, modified_rift_point_features, rift_csv_file, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday):
	already_included_line_features = []
	output_cloned_feats = pygplates.FeatureCollection()
	output_topological_tectonic_plates = pygplates.FeatureCollection()
	#,reconstruction_time,sgdu,first,polylid,second
	order_to_connect_lines_df = pd.read_csv(order_to_connect_lines_csv)
	#rift records: start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid 
	rift_df = pd.read_csv(rift_csv_file)
	dic_supergdu = {}
	dic_order = {}
	valid_supergdu_feats = []
	reconstructed_line_features_from_div = []
	reconstructed_line_features_from_conv = []
	reconstructed_plate_boundary_zone = []
	reconstructed_point_features = []
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		valid_supergdu_feats[:] = []
		reconstructed_line_features_from_div[:] = []
		reconstructed_line_features_from_conv[:] = []
		reconstructed_plate_boundary_zone[:] = []
		reconstructed_point_features[:] = []
		valid_line_fts_from_div = [div_ft for div_ft in line_feats_from_div_process if div_ft.is_valid_at_time(reconstruction_time)]
		valid_line_fts_from_conv = [conv_ft for conv_ft in line_feats_from_conv_process if conv_ft.is_valid_at_time(reconstruction_time)]
		valid_plate_boundary_zone = [plat_bdn_ft for plat_bdn_ft in plate_boundary_zone_feats if plat_bdn_ft.is_valid_at_time(reconstruction_time)]
		valid_rift_pt_fts = [pt_ft for pt_ft in modified_rift_point_features if pt_ft.is_valid_at_time(reconstruction_time)]
		
		final_reconstructed_line_features_from_div = None
		final_reconstructed_line_features_from_conv = None
		final_reconstructed_plate_bdn_zone = None
		final_reconstructed_pt_feats = None
		if (len(valid_line_fts_from_div) > 0):
			if (reference is not None):
				pygplates.reconstruct(valid_line_fts_from_div, rotation_model, reconstructed_line_features_from_div, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_line_fts_from_div, rotation_model, reconstructed_line_features_from_div, reconstruction_time, group_with_feature = True)
				#print('len(valid_con_ocn_line_feats)', len(valid_con_ocn_line_feats))
			final_reconstructed_line_features_from_div = find_final_reconstructed_geometries(reconstructed_line_features_from_div, pygplates.PolylineOnSphere)
		if (len(valid_line_fts_from_conv) > 0):
			if (reference is not None):
				pygplates.reconstruct(valid_line_fts_from_conv, rotation_model, reconstructed_line_features_from_conv, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_line_fts_from_conv, rotation_model, reconstructed_line_features_from_conv, reconstruction_time, group_with_feature = True)
				#print('len(valid_con_ocn_line_feats)', len(valid_con_ocn_line_feats))
			final_reconstructed_line_features_from_conv = find_final_reconstructed_geometries(reconstructed_line_features_from_conv, pygplates.PolylineOnSphere)
		if (len(valid_plate_boundary_zone) > 0):
			if (reference is not None):
				pygplates.reconstruct(valid_plate_boundary_zone, rotation_model, reconstructed_plate_boundary_zone, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_plate_boundary_zone, rotation_model, reconstructed_plate_boundary_zone, reconstruction_time, group_with_feature = True)
				#print('len(valid_con_ocn_line_feats)', len(valid_con_ocn_line_feats))
			final_reconstructed_plate_bdn_zone = find_final_reconstructed_geometries(reconstructed_plate_boundary_zone, pygplates.PolylineOnSphere)
		if (len(valid_rift_pt_fts) > 0):
			if (reference is not None):
				pygplates.reconstruct(valid_rift_pt_fts, rotation_model, reconstructed_point_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_rift_pt_fts, rotation_model, reconstructed_point_features, reconstruction_time, group_with_feature = True)
			#print('len(valid_con_ocn_line_feats)', len(valid_con_ocn_line_feats))
			final_reconstructed_pt_feats = find_final_reconstructed_geometries(reconstructed_point_features, pygplates.PointOnSphere)
		
		
		for supergdu_ft in supergdu_features:
			if (supergdu_ft.is_valid_at_time(reconstruction_time)):
				valid_supergdu_feats.append(supergdu_ft)
		already_processed_sgdu_name = []
		for valid_sgdu_ft in valid_supergdu_feats:
			sgdu_name = valid_sgdu_ft.get_name()
			print('sgdu_name',sgdu_name)
			print('sgdu_name in dic_supergdu',sgdu_name in dic_supergdu)
			print('sgdu_name not in already_processed_sgdu_name',sgdu_name not in already_processed_sgdu_name)
			if ((sgdu_name in dic_supergdu) and (sgdu_name not in already_processed_sgdu_name)):
				already_processed_sgdu_name.append(sgdu_name)
				nested_lists_of_CON_OCN_records = dic_order[sgdu_name]
				print('len(nested_lists_of_CON_OCN_records)', len(nested_lists_of_CON_OCN_records))
				#obtain all CON-OCN line features
				no_change = True
				for polylid in dic_supergdu[sgdu_name]:
					features = dic_supergdu[sgdu_name][polylid]
					if (len(features) > 1):
						#a collection of rift point features
						#check whether all rift point features are valid
						all_valid_pt_fts = True
						left_over_pt_feats = []
						for pt_ft in features:
							if (pt_ft.is_valid_at_time(reconstruction_time) == False):
								all_valid_pt_fts = False
							else:
								left_over_pt_feats.append(pt_ft)
						if (all_valid_pt_fts == False):
							dic_supergdu[sgdu_name][polylid] = left_over_pt_feats
							no_change = False
					if (no_change == False and len(dic_supergdu[sgdu_name][polylid]) == 0):#all rift point features have been invalid so take the representative passive margin
						for line_ft in line_feats_from_div_process:
							if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin' and line_ft.is_valid_at_time(reconstruction_time + time_interval) == True):
								features = [line_ft]
								break
					if (len(features) == 1):
						line_ft = features[0]
						if (line_ft.is_valid_at_time(reconstruction_time) == False):
							no_change = False
							temporary_list_to_connect_features = []
							found_ft = None
							found_first_ft = None
							found_second_ft = None
							polylid = line_ft.get_name()
							if (line_ft.get_description() != 'divergent_margin'):
								for line_ft in valid_line_fts_from_div:
									if (line_ft.get_name() == polylid):
										found_ft = line_ft
										if (line_ft.get_description() == 'divergent_margin'):
											# #obtain rift records for polylid
											selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
											gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
											# if (len(selected_rift_record) > 1):
												# #sort the dataframe of rift point features based on the order 
												# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
												# max_order_rift_point = None
												# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
													# rift_pt_ft_name = rift_name+'_'+str(order)
													# #max_order_rift_point = None
													# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
														# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
															# max_order_rift_point = reconstructed_rift_pt
															# break
													# if (max_order_rift_point is not None):
														# break
												# #find the two line features 
												# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
												# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
												# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
													# if (div_line_ft.get_name() == first):
														# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
													# if (div_line_ft.get_name() == polylid):
														# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
													# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
														# break
												# if (found_first_reconstructed_line_ft is None):
													# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
														# if (conv_line_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
														# if (found_first_reconstructed_line_ft is not None):
															# break
												# if (found_first_reconstructed_line_ft is None):
													# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
														# if (plate_bdn_zone_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
														# if (found_first_reconstructed_line_ft is not None):
															# break
												# if (found_second_reconstructed_line_ft is None):
													# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
														# if (conv_line_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
														# if (found_second_reconstructed_line_ft is not None):
															# break
												# if (found_second_reconstructed_line_ft is None):
													# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
														# if (plate_bdn_zone_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
														# if (found_second_reconstructed_line_ft is not None):
															# break
												# if (max_order_rift_point is not None):
													# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
													# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
													# if (dist_from_first_line > dist_from_second_line):
														# #sort the dataframe of rift point features based on the order 
														# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
													# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
														# rift_pt_ft_name = rift_name+'_'+str(order)
														# found_rift_point_ft = None
														# for rift_pt_ft in valid_rift_pt_fts:
															# if (rift_pt_ft.get_name() == rift_pt_ft_name):
																# found_rift_point_ft = rift_pt_ft
															# break
														# if (found_rift_point_ft is not None):
															# temporary_list_to_connect_features.append(found_rift_point_ft)
											if (len(temporary_list_to_connect_features) == 0):
												temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'transform_fault'):
											temporary_list_to_connect_features.append(line_ft)
											break
										break
								if (found_ft is not None):
									if (found_ft.get_description() == 'convergent_margin'):
										for line_ft in valid_line_fts_from_conv:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
												found_ft = line_ft
												break
											elif (line_ft.get_name() == polylid and (line_ft.get_description() == 'transform_fault' or line_ft.get_description() == 'plate_boundary_zone')):
												found_ft = line_ft
								else:
									for line_ft in valid_line_fts_from_conv:
										if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
											found_ft = line_ft
											break
										elif (line_ft.get_name() == polylid and (line_ft.get_description() == 'transform_fault' or line_ft.get_description() == 'plate_boundary_zone')):
											found_ft = line_ft
									if (found_ft is None):
										for line_ft in valid_plate_boundary_zone:
											if (line_ft.get_name() == polylid):
												found_ft = line_ft
								if (found_ft is not None):
									temporary_list_to_connect_features.append(found_ft)
								if ((found_ft is None or found_ft.get_description() == 'plate_boundary_zone')):
									if (found_ft is None):
										for line_ft in valid_line_fts_from_conv:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
												found_ft = line_ft
												break
									if (found_ft is not None):
										CON_OCN_records = order_to_connect_lines_df.loc[(order_to_connect_lines_df['sgdu'] == int(sgdu_name)) & (order_to_connect_lines_df['polylid'] == found_ft.get_name()), ['first', 'polylid', 'second']]
										distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
										for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
											#try to find the other two features: first and second
											if (first is not None):
												for first_line_ft in valid_line_fts_from_div:
													if (first_line_ft.get_name() == first):
														if (first_line_ft.get_description() == 'divergent_margin'):
															found_first_ft = first_line_ft
															break
														else:
															if (found_first_ft is None):
																found_first_ft = first_line_ft
															else:
																if (found_first_ft.get_description() == 'convergent_margin'):
																	found_first_ft = first_line_ft #update
											if (second is not None):
												for second_line_ft in valid_line_fts_from_div:
													if (second_line_ft.get_name() == second):
														if (second_line_ft.get_description() == 'divergent_margin'):
															found_second_ft = second_line_ft
															break
														else:
															if (found_second_ft is None):
																found_second_ft = second_line_ft
															else:
																if (found_second_ft.get_description() == 'convergent_margin'):
																	found_second_ft = second_line_ft #update
										if (found_first_ft is not None and found_second_ft is not None):
											if ((found_first_ft.get_description() == found_second_ft.get_description())):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_first_ft is not None):
											if (found_first_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
										#try the new collections
										if (first is not None and found_first_ft is None and found_second_ft is None):
											for first_line_ft in valid_line_fts_from_conv:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'divergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None and found_second_ft is None and found_first_ft is None):
											for second_line_ft in valid_line_fts_from_conv:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'divergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None):
											if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								if (found_ft is not None and len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(found_ft)
							elif (line_ft.get_description() != 'convergent_margin'):
								polylid = line_ft.get_name()
								for line_ft in valid_line_fts_from_conv:
									if (line_ft.get_name() == polylid):
										found_ft = line_ft
										if (line_ft.get_description() == 'convergent_margin'):
											temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'transform_fault'):
											temporary_list_to_connect_features.append(line_ft)
											break
								if (found_ft is not None):
									if (found_ft.get_description() == 'divergent_margin'):
										for line_ft in valid_line_fts_from_div:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
												found_ft = line_ft
												#obtain rift records for polylid
												selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
												gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
												# if (len(selected_rift_record) > 1):
													# #sort the dataframe of rift point features based on the order 
													# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
													# max_order_rift_point = None
													# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
														# rift_pt_ft_name = rift_name+'_'+str(order)
														# #max_order_rift_point = None
														# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
															# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
																# max_order_rift_point = reconstructed_rift_pt
																# break
														# if (max_order_rift_point is not None):
															# break
													# #find the two line features 
													# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
													# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
													# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
														# if (div_line_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
														# if (div_line_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
														# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
															# break
													# if (found_first_reconstructed_line_ft is None):
														# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
															# if (conv_line_ft.get_name() == first):
																# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
															# if (found_first_reconstructed_line_ft is not None):
																# break
													# if (found_first_reconstructed_line_ft is None):
														# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
															# if (plate_bdn_zone_ft.get_name() == first):
																# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
															# if (found_first_reconstructed_line_ft is not None):
																# break
													# if (found_second_reconstructed_line_ft is None):
														# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
															# if (conv_line_ft.get_name() == polylid):
																# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
															# if (found_second_reconstructed_line_ft is not None):
																# break
													# if (found_second_reconstructed_line_ft is None):
														# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
															# if (plate_bdn_zone_ft.get_name() == polylid):
																# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
															# if (found_second_reconstructed_line_ft is not None):
																# break
													# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
													# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
													# if (dist_from_first_line > dist_from_second_line):
														# #sort the dataframe of rift point features based on the order 
														# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
													
													# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
														# rift_pt_ft_name = rift_name+'_'+str(order)
														# found_rift_point_ft = None
														# for rift_pt_ft in valid_rift_pt_fts:
															# if (rift_pt_ft.get_name() == rift_pt_ft_name):
																# found_rift_point_ft = rift_pt_ft
															# break
														# if (found_rift_point_ft is not None):
															# temporary_list_to_connect_features.append(found_rift_point_ft)
												if (len(temporary_list_to_connect_features) == 0):
													temporary_list_to_connect_features.append(line_ft)
												break
											elif (line_ft.get_name() == polylid and (line_ft.get_description() == 'transform_fault' or line_ft.get_description() == 'plate_boundary_zone')):
												found_ft = line_ft
								else:
									for line_ft in valid_line_fts_from_div:
										if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
											found_ft = line_ft
											#obtain rift records for polylid
											selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
											gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
											# if (len(selected_rift_record) > 1):
												# #sort the dataframe of rift point features based on the order 
												# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
												# #sort the dataframe of rift point features based on the order 
												# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
												# max_order_rift_point = None
												# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
													# rift_pt_ft_name = rift_name+'_'+str(order)
													# #max_order_rift_point = None
													# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
														# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
															# max_order_rift_point = reconstructed_rift_pt
															# break
													# if (max_order_rift_point is not None):
														# break
												# #find the two line features 
												# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
												# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
												# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
													# if (div_line_ft.get_name() == first):
														# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
													# if (div_line_ft.get_name() == polylid):
														# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
													# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
														# break
												# if (found_first_reconstructed_line_ft is None):
													# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
														# if (conv_line_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
														# if (found_first_reconstructed_line_ft is not None):
															# break
												# if (found_first_reconstructed_line_ft is None):
													# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
														# if (plate_bdn_zone_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
														# if (found_first_reconstructed_line_ft is not None):
															# break
												# if (found_second_reconstructed_line_ft is None):
													# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
														# if (conv_line_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
														# if (found_second_reconstructed_line_ft is not None):
															# break
												# if (found_second_reconstructed_line_ft is None):
													# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
														# if (plate_bdn_zone_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
														# if (found_second_reconstructed_line_ft is not None):
															# break
												# if (max_order_rift_point is not None):
													# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
													# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
													# if (dist_from_first_line > dist_from_second_line):
														# #sort the dataframe of rift point features based on the order 
														# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
												
													# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
														# rift_pt_ft_name = rift_name+'_'+str(order)
														# found_rift_point_ft = None
														# for rift_pt_ft in valid_rift_pt_fts:
															# if (rift_pt_ft.get_name() == rift_pt_ft_name):
																# found_rift_point_ft = rift_pt_ft
															# break
														# if (found_rift_point_ft is not None):
															# temporary_list_to_connect_features.append(found_rift_point_ft)
											if (len(temporary_list_to_connect_features) == 0):
												temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_name() == polylid and (line_ft.get_description() == 'transform_fault' or line_ft.get_description() == 'plate_boundary_zone')):
											found_ft = line_ft
									if (found_ft is None):
										for line_ft in valid_plate_boundary_zone:
											if (line_ft.get_name() == polylid):
												found_ft = line_ft
								if (found_ft is not None):
									temporary_list_to_connect_features.append(found_ft)
		
								if (found_ft is None or found_ft.get_description() == 'plate_boundary_zone'):
									if (found_ft is None):
										for line_ft in valid_line_fts_from_div:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
												found_ft = line_ft
												break
									if (found_ft is not None):
										CON_OCN_records = order_to_connect_lines_df.loc[(order_to_connect_lines_df['sgdu'] == int(sgdu_name)) & (order_to_connect_lines_df['polylid'] == found_ft.get_name()), ['first', 'polylid', 'second']]
										distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
										for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
											#try to find the other two features: first and second
											if (first is not None):
												for first_line_ft in valid_line_fts_from_div:
													if (first_line_ft.get_name() == first):
														if (first_line_ft.get_description() == 'divergent_margin'):
															found_first_ft = first_line_ft
															break
														else:
															if (found_first_ft is None):
																found_first_ft = first_line_ft
															else:
																if (found_first_ft.get_description() == 'convergent_margin'):
																	found_first_ft = first_line_ft #update
											if (second is not None):
												for second_line_ft in valid_line_fts_from_div:
													if (second_line_ft.get_name() == second):
														if (second_line_ft.get_description() == 'divergent_margin'):
															found_second_ft = second_line_ft
															break
														else:
															if (found_second_ft is None):
																found_second_ft = second_line_ft
															else:
																if (found_second_ft.get_description() == 'convergent_margin'):
																	found_second_ft = second_line_ft #update
											if (found_first_ft is not None and found_second_ft is not None):
												if ((found_first_ft.get_description() == found_second_ft.get_description())):
													found_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
													found_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
													found_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_first_ft is not None):
												if (found_first_ft.get_description() != 'convergent_margin'):
													found_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_second_ft is not None):
												if (found_second_ft.get_description() != 'convergent_margin'):
													found_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
											#try the new collections
											if (first is not None and found_first_ft is None and found_second_ft is None):
												for first_line_ft in valid_line_fts_from_conv:
													if (first_line_ft.get_name() == first):
														if (first_line_ft.get_description() == 'convergent_margin'):
															found_first_ft = first_line_ft
															break
														else:
															if (found_first_ft is None):
																found_first_ft = first_line_ft
															else:
																if (found_first_ft.get_description() == 'divergent_margin'):
																	found_first_ft = first_line_ft #update
											if (second is not None and found_second_ft is None and found_first_ft is None):
												for second_line_ft in valid_line_fts_from_conv:
													if (second_line_ft.get_name() == second):
														if (second_line_ft.get_description() == 'convergent_margin'):
															found_second_ft = second_line_ft
															break
														else:
															if (found_second_ft is None):
																found_second_ft = second_line_ft
															else:
																if (found_second_ft.get_description() == 'divergent_margin'):
																	found_second_ft = second_line_ft #update
											if (found_first_ft is not None):
												if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
													found_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_second_ft is not None):
												if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
													found_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								if (found_ft is not None and len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(found_ft)
							if (len(temporary_list_to_connect_features) > 0):
								dic_supergdu[sgdu_name][polylid] = temporary_list_to_connect_features
						if (found_ft is None):
							print('found_ft is None. line_ft is',line_ft.get_shapefile_attribute('POLYLID'))
						#might need to find the line feature just like initial
						if (found_ft is None and line_ft.is_valid_at_time(reconstruction_time) == False):
							
							CON_OCN_records = order_to_connect_lines_df.loc[(order_to_connect_lines_df['sgdu'] == int(sgdu_name)) & (order_to_connect_lines_df['polylid'] == line_ft.get_name()), ['first', 'polylid', 'second']]
							distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
							for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
								break#we just need one record
							no_change = False
							found_ft = None
							found_first_ft = None
							found_second_ft = None
							temporary_list_to_connect_features = []
							for line_ft in valid_line_fts_from_div:
								if (line_ft.get_name() == polylid):
									found_ft = line_ft
									if (line_ft.get_description() == 'divergent_margin'):
										#obtain rift records for polylid
										selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
										gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
										# if (len(selected_rift_record) > 1):
											# #sort the dataframe of rift point features based on the order 
											# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
											# max_order_rift_point = None
											# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
												# rift_pt_ft_name = rift_name+'_'+str(order)
												# max_order_rift_point = None
												# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
													# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
														# max_order_rift_point = reconstructed_rift_pt
														# break
												# if (max_order_rift_point is not None):
													# break
											# #fnd the two line features 
											# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
											# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
											# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
												# if (div_line_ft.get_name() == first):
													# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
												# if (div_line_ft.get_name() == polylid):
													# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
												# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
													# break
											# if (found_first_reconstructed_line_ft is None):
												# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
													# if (conv_line_ft.get_name() == first):
														# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
													# if (found_first_reconstructed_line_ft is not None):
														# break
											# if (found_first_reconstructed_line_ft is None):
												# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
													# if (plate_bdn_zone_ft.get_name() == first):
														# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
													# if (found_first_reconstructed_line_ft is not None):
														# break
											# if (found_second_reconstructed_line_ft is None):
												# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
													# if (conv_line_ft.get_name() == polylid):
														# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
													# if (found_second_reconstructed_line_ft is not None):
														# break
											# if (found_second_reconstructed_line_ft is None):
												# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
													# if (plate_bdn_zone_ft.get_name() == polylid):
														# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
													# if (found_second_reconstructed_line_ft is not None):
														# break
											# if (max_order_rift_point is not None):
												# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
												# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
												# if (dist_from_first_line > dist_from_second_line):
													# #sort the dataframe of rift point features based on the order 
													# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
												# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
													# rift_pt_ft_name = rift_name+'_'+str(order)
													# found_rift_point_ft = None
													# for rift_pt_ft in valid_rift_pt_fts:
														# if (rift_pt_ft.get_name() == rift_pt_ft_name):
															# found_rift_point_ft = rift_pt_ft
															# break
													# if (found_rift_point_ft is not None):
														# temporary_list_to_connect_features.append(found_rift_point_ft)
										if (len(temporary_list_to_connect_features) == 0):
											temporary_list_to_connect_features.append(line_ft)
										break
									elif (line_ft.get_description() == 'transform_fault'):
										temporary_list_to_connect_features.append(line_ft)
										break
									elif (line_ft.get_description() == 'plate_boundary_zone'):
										#try to find the other two features: first and second
										if (first is not None):
											for first_line_ft in valid_line_fts_from_div:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'convergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None):
											for second_line_ft in valid_line_fts_from_div:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'convergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None and found_second_ft is not None):
											if ((found_first_ft.get_description() == found_second_ft.get_description())):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_first_ft is not None):
											if (found_first_ft.get_description() != 'convergent_margin'):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() != 'convergent_margin'):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
										#try the new collections
										if (first is not None and found_first_ft is None and found_second_ft is None):
											for first_line_ft in valid_line_fts_from_conv:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'divergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None and found_second_ft is None and found_first_ft is None):
											for second_line_ft in valid_line_fts_from_conv:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'divergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None):
											if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										temporary_list_to_connect_features.append(line_ft)
										break
									elif (line_ft.get_description() == 'convergent_margin'):
										#try to find the other two features: first and second
										if (first is not None):
											for first_line_ft in valid_line_fts_from_div:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														found_first_ft = first_line_ft
										if (second is not None):
											for second_line_ft in valid_line_fts_from_div:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														found_second_ft = second_line_ft
										if (found_first_ft is not None and found_second_ft is not None):
											if ((found_first_ft.get_description() == found_second_ft.get_description())):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_first_ft is not None):
											if (found_first_ft.get_description() != 'convergent_margin'):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() != 'convergent_margin'):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										#try the new collections
										if (first is not None and found_first_ft is None and found_second_ft is None):
											for first_line_ft in valid_line_fts_from_conv:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'divergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None and found_second_ft is None and found_first_ft is None):
											for second_line_ft in valid_line_fts_from_conv:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'divergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None):
											if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										temporary_list_to_connect_features.append(line_ft)
										break
							if (found_ft is None):
								for line_ft in valid_line_fts_from_conv:
									if (line_ft.get_name() == polylid):
										found_ft = line_ft
										if (line_ft.get_description() == 'convergent_margin'):
											temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'transform_fault'):
											temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'plate_boundary_zone'):
											#try to find the other two features: first and second
											if (first is not None):
												for first_line_ft in valid_line_fts_from_conv:
													if (first_line_ft.get_name() == first):
														if (first_line_ft.get_description() == 'convergent_margin'):
															found_first_ft = first_line_ft
															break
														else:
															if (found_first_ft is None):
																found_first_ft = first_line_ft
															else:
																if (found_first_ft.get_description() == 'divergent_margin'):
																	found_first_ft = first_line_ft #update
											if (second is not None):
												for second_line_ft in valid_line_fts_from_conv:
													if (second_line_ft.get_name() == second):
														if (second_line_ft.get_description() == 'convergent_margin'):
															found_second_ft = second_line_ft
															break
														else:
															if (found_second_ft is None):
																found_second_ft = second_line_ft
															else:
																if (found_second_ft.get_description() == 'divergent_margin'):
																	found_second_ft = second_line_ft #update
											if (found_first_ft is not None and found_second_ft is not None):
												if ((found_first_ft.get_description() == found_second_ft.get_description())):
													line_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'divergent_margin')):
													line_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'divergent_margin')):
													line_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_first_ft is not None):
												if (found_first_ft.get_description() != 'divergent_margin'):
													line_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_second_ft is not None):
												if (found_second_ft.get_description() != 'divergent_margin'):
													line_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											#try the new collections
											if (first is not None and found_first_ft is None and found_second_ft is None):
												for first_line_ft in valid_line_fts_from_div:
													if (first_line_ft.get_name() == first):
														if (first_line_ft.get_description() == 'divergent_margin'):
															found_first_ft = first_line_ft
															break
														else:
															if (found_first_ft is None):
																found_first_ft = first_line_ft
															else:
																if (found_first_ft.get_description() == 'convergent_margin'):
																	found_first_ft = first_line_ft #update
											if (found_second_ft is None and found_second_ft is None and found_first_ft is None):
												for second_line_ft in valid_line_fts_from_div:
													if (second_line_ft.get_name() == second):
														if (second_line_ft.get_description() == 'divergent_margin'):
															found_second_ft = second_line_ft
															break
														else:
															if (found_second_ft is None):
																found_second_ft = second_line_ft
															else:
																if (found_second_ft.get_description() == 'convergent_margin'):
																	found_second_ft = second_line_ft #update
											if (found_first_ft is not None):
												if (found_first_ft.get_description() == 'divergent_margin' or found_first_ft.get_description() == 'transform_fault'):
													line_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_second_ft is not None):
												if (found_second_ft.get_description() == 'divergent_margin' or found_second_ft.get_description() == 'transform_fault'):
													line_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'divergent_margin'):
											#try to find the other two features: first and second
											if (first is not None):
												for first_line_ft in valid_line_fts_from_conv:
													if (first_line_ft.get_name() == first):
														if (first_line_ft.get_description() == 'convergent_margin'):
															found_first_ft = first_line_ft
															break
														else:
															found_first_ft = first_line_ft
											if (second is not None):
												for second_line_ft in valid_line_fts_from_conv:
													if (second_line_ft.get_name() == second):
														if (second_line_ft.get_description() == 'convergent_margin'):
															found_second_ft = second_line_ft
															break
														else:
															found_second_ft = second_line_ft
											if (found_first_ft is not None and found_second_ft is not None):
												if ((found_first_ft.get_description() == found_second_ft.get_description())):
													line_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'divergent_margin')):
													line_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'divergent_margin')):
													line_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_first_ft is not None):
												if (found_first_ft.get_description() != 'divergent_margin'):
													line_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_second_ft is not None):
												if (found_second_ft.get_description() != 'divergent_margin'):
													line_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											#try the second time to find the other two features: first and second
											if (first is not None and found_first_ft is None and found_second_ft is None):
												for first_line_ft in valid_line_fts_from_div:
													if (first_line_ft.get_name() == first):
														if (first_line_ft.get_description() == 'divergent_margin'):
															found_first_ft = first_line_ft
															break
														else:
															found_first_ft = first_line_ft
											if (second is not None and found_second_ft is None and found_first_ft is None):
												for second_line_ft in valid_line_fts_from_div:
													if (second_line_ft.get_name() == second):
														if (second_line_ft.get_description() == 'divergent_margin'):
															found_second_ft = second_line_ft
															break
														else:
															found_second_ft = second_line_ft
											if (found_first_ft is not None):
												if (found_first_ft.get_description() == 'divergent_margin' or found_first_ft.get_description() == 'transform_fault'):
													line_ft.set_description (found_first_ft.get_description())
													if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif (found_second_ft is not None):
												if (found_second_ft.get_description() == 'divergent_margin' or found_second_ft.get_description() == 'transform_fault'):
													line_ft.set_description (found_second_ft.get_description())
													if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
														line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
													else:
														line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										temporary_list_to_connect_features.append(line_ft)
										break
							if (found_ft is None):
								for line_ft in valid_plate_boundary_zone:
									if (line_ft.get_name() == polylid):
										found_ft = line_ft
										#try to find the other two features: first and second
										if (first is not None):
											for first_line_ft in valid_line_fts_from_div:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'convergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None):
											for second_line_ft in valid_line_fts_from_div:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'convergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None and found_second_ft is not None):
											if ((found_first_ft.get_description() == found_second_ft.get_description())):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_first_ft is not None):
											if (found_first_ft.get_description() != 'convergent_margin'):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() != 'convergent_margin'):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
										#try the new collections
										if (first is not None and found_first_ft is None and found_second_ft is None):
											for first_line_ft in valid_line_fts_from_conv:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'divergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None and found_second_ft is None and found_first_ft is None):
											for second_line_ft in valid_line_fts_from_conv:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'divergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None):
											if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
												line_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
												line_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										temporary_list_to_connect_features.append(line_ft)
										break
							if (len(temporary_list_to_connect_features) > 0):
								for each_ft in temporary_list_to_connect_features:
									dic_supergdu[sgdu_name][polylid].append(each_ft)

				if (no_change == False):
					list_of_topological_feats_to_be_examined = []
					for current_output_topological_ft in output_topological_tectonic_plates:
						if (current_output_topological_ft.get_name() == sgdu_name):
							current_begin_topological_age, current_end_topological_age = current_output_topological_ft.get_valid_time()
							if (current_end_topological_age < reconstruction_time and (reconstruction_time + 0.1000) < current_begin_topological_age):
								#ideally, before we change the time we want to check whether we need to create a new topological tectonic plate because one feature has changed
								#current_output_topological_ft.set_valid_time(current_begin_topological_age,reconstruction_time+0.1000)
								list_of_topological_feats_to_be_examined.append(current_output_topological_ft)
					if (len(list_of_topological_feats_to_be_examined) > 0):
						for examined_topological_feat in list_of_topological_feats_to_be_examined:
							topological_sections = examined_topological_feat.get_topological_geometry().get_boundary_sections()
							list_of_features_for_sections = []
							is_to_be_updated = False
							for section in topological_sections:
								fid_of_section = section.get_property_delegate().get_feature_id()
								for ref_ft in output_topological_tectonic_plates:
									if (ref_ft.get_feature_id() == fid_of_section):
										if (ref_ft.is_valid_at_time(reconstruction_time) == False):
											#debug
											print('invalid ref_ft',ref_ft.get_name())
											is_to_be_updated = True
											break
								if (is_to_be_updated == True):
									fid_topological_ft = examined_topological_feat.get_feature_id().get_string()
									current_begin_topological_age, current_end_topological_age = examined_topological_feat.get_valid_time()
									print('fid_topological_ft to be updated ',fid_topological_ft)
									print('current_begin_topological_age, current_end_topological_age before',current_begin_topological_age, current_end_topological_age)
									examined_topological_feat.set_valid_time(current_begin_topological_age,reconstruction_time+0.1000)
									print('reconstruction_time',reconstruction_time)
									print('xamined_topological_feat.get_valid_time() after ',examined_topological_feat.get_valid_time())
									small_list_of_connect_features = dic_order[sgdu_name][fid_topological_ft]
									list_of_features_to_be_connected = None 
									for polylid in small_list_of_connect_features:
										print('required polylid ', polylid)
										if (polylid in dic_supergdu[sgdu_name]):
											features_for_polylid = dic_supergdu[sgdu_name][polylid]
											
											#debug
											print('features_for_polylid',features_for_polylid)
											
											if (list_of_features_to_be_connected is not None):
												list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_polylid
											elif (list_of_features_to_be_connected is None):
												list_of_features_to_be_connected = features_for_polylid
									if (list_of_features_to_be_connected is not None):
										if (len(list_of_features_to_be_connected) > 0):
											#double check to make sure no None feature
											no_none_ft = True
											for ft in list_of_features_to_be_connected:
												if (ft is None or ft.is_valid_at_time(reconstruction_time) == False):
													print(ft.get_shapefile_attribute('POLYLID'))
													print(ft.get_description())
													no_none_ft = False
													break
											#debug 
											print('value of no_none_ft', no_none_ft)
											if (no_none_ft == True):
												cloned_original_fts = []
												already_included_line_features[:] = []
												for each_original_ft in list_of_features_to_be_connected:
													#if (each_original_ft.get_feature_id() not in already_included_line_features):
													if (each_original_ft.get_name() not in already_included_line_features):
														clone_ft = each_original_ft.clone()
														cloned_original_fts.append(clone_ft)
														already_included_line_features.append(each_original_ft.get_name())
														output_cloned_feats.add(clone_ft)
												topological_sections = create_topological_sections(cloned_original_fts)
												if (len(topological_sections) >= 1):
													topological_ft = create_topological_polygon_feature(topological_sections)
													topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
													if (topological_ft is not None):
														topological_ft.set_name(sgdu_name)
														topological_ft.set_valid_time(reconstruction_time, topological_end_age)
														
														new_fid_topological_ft = topological_ft.get_feature_id().get_string()
														#debug
														print('new new_fid_topological_ft', new_fid_topological_ft)
														output_topological_tectonic_plates.add(topological_ft)
														print('new valid age for new topological feature', reconstruction_time, topological_end_age)
														#delete the old entry
														del dic_order[sgdu_name][fid_topological_ft]
														dic_order[sgdu_name][new_fid_topological_ft] = small_list_of_connect_features
														for clone_ft in cloned_original_fts:
															output_topological_tectonic_plates.add(clone_ft)
												#OLD
												# topological_sections = create_topological_sections(list_of_features_to_be_connected)
												# if (len(topological_sections) >= 1):
													# topological_ft = create_topological_line_feature(topological_sections)
													# topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
													# if (topological_ft is not None):
														# topological_ft.set_name(sgdu_name)
														# topological_ft.set_valid_time(topological_begin_age, topological_end_age)
														# output_topological_tectonic_plates.add(topological_ft)
														# new_fid_topological_ft = topological_ft.get_feature_id().get_string()
														# dic_order[sgdu_name][new_fid_topological_ft] = small_list_of_connect_features
														# for each_original_ft in list_of_features_to_be_connected:
															# #output_topological_tectonic_plates.add(each_original_ft)
															# if (each_original_ft.get_feature_id() not in already_included_line_features):
																# output_topological_tectonic_plates.add(each_original_ft)
																# already_included_line_features.append(each_original_ft.get_feature_id())
														# #delete the old entry
														# del dic_order[sgdu_name][fid_topological_ft]
									break#
					#we might not need to find the order again because the topological features should have kept the order to connect features
					# CON_OCN_records = order_to_connect_lines_df.loc[order_to_connect_lines_df['sgdu'] == int(sgdu_name), ['first', 'polylid', 'second']]
					# distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
					# nested_lists_of_CON_OCN_records = find_the_order_to_complete_topological_feature(distinct_CON_OCN_records)
					# if (len(nested_lists_of_CON_OCN_records) > 0):
						# for small_list in nested_lists_of_CON_OCN_records:
							# list_of_features_to_be_connected = None 
							# for polylid in small_list:
								# if (polylid in dic_supergdu[sgdu_name]):
									# features_for_polylid = dic_supergdu[sgdu_name][polylid]
									# if (list_of_features_to_be_connected is not None):
										# list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_polylid
									# elif (list_of_features_to_be_connected is None):
										# list_of_features_to_be_connected = features_for_polylid
							# if (list_of_features_to_be_connected is not None):
								# if (len(list_of_features_to_be_connected) > 0):
									# #double check to make sure no None feature
									# no_none_ft = True
									# for ft in list_of_features_to_be_connected:
										# if (ft is None):
											# no_none_ft = False
											# break
									# if (no_none_ft == True):
										# topological_sections = create_topological_sections(list_of_features_to_be_connected)
										# if (len(topological_sections) >= 1):
											# topological_ft = create_topological_line_feature(topological_sections)
											# topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
											# if (topological_ft is not None):
												# topological_ft.set_name(sgdu_name)
												# topological_ft.set_valid_time(topological_begin_age, topological_end_age)
												# output_topological_tectonic_plates.add(topological_ft)
											# for each_original_ft in list_of_features_to_be_connected:
												# if (each_original_ft.get_feature_id() not in already_included_line_features):
													# output_topological_tectonic_plates.add(each_original_ft)
													# already_included_line_features.append(each_original_ft.get_feature_id())
					
					
					###old
					# for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
						# features_for_first = None
						# features_for_polylid = None
						# features_for_second = None
						# if (first in dic_supergdu[sgdu_name]):
							# features_for_first =  dic_supergdu[sgdu_name][first]
						# if (polylid in dic_supergdu[sgdu_name]):
							# features_for_polylid = dic_supergdu[sgdu_name][polylid]
						# if (second in dic_supergdu[sgdu_name]):
							# features_for_second = dic_supergdu[sgdu_name][second]
						# list_of_features_to_be_connected = None
						# if (features_for_first is not None):
							# list_of_features_to_be_connected = features_for_first
						# if (features_for_polylid is not None):
							# if (list_of_features_to_be_connected is not None):
								# list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_polylid
							# elif (list_of_features_to_be_connected is None):
								# list_of_features_to_be_connected = features_for_polylid
						# if (features_for_second is not None):
							# if (list_of_features_to_be_connected is not None and features_for_polylid is not None):
								# list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_second
							# elif (list_of_features_to_be_connected is None):
								# list_of_features_to_be_connected = features_for_second
						# if (list_of_features_to_be_connected is not None):
							# if (len(list_of_features_to_be_connected) > 0):
								# #double check to make sure no None feature
								# no_none_ft = True
								# for ft in list_of_features_to_be_connected:
									# if (ft is None):
										# no_none_ft = False
										# break
								# if (no_none_ft == True):
									# topological_sections = create_topological_sections(list_of_features_to_be_connected)
									# if (len(topological_sections) >= 1):
										# topological_ft = create_topological_line_feature(topological_sections)
										# topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
										# if (topological_ft is not None):
											# topological_ft.set_name(sgdu_name)
											# topological_ft.set_valid_time(reconstruction_time, topological_end_age)
											# output_topological_tectonic_plates.add(topological_ft)
										# for each_original_ft in list_of_features_to_be_connected:
											# if (each_original_ft.get_feature_id() not in already_included_line_features):
												# output_topological_tectonic_plates.add(each_original_ft)
												# already_included_line_features.append(each_original_ft.get_feature_id())
			elif (sgdu_name not in already_processed_sgdu_name):
				already_processed_sgdu_name.append(sgdu_name)
				dic_order[sgdu_name] = {}
				#obtain all CON-OCN line features
				dic_supergdu[sgdu_name] = {}
				list_to_connect_features = []
				CON_OCN_records = order_to_connect_lines_df.loc[(order_to_connect_lines_df['sgdu'] == int(sgdu_name)) & (order_to_connect_lines_df['first'].isna() == False), ['first', 'polylid', 'second']]
				distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
				#nested_lists_of_CON_OCN_records = find_the_order_to_complete_topological_feature(distinct_CON_OCN_records)
				nested_lists_of_CON_OCN_records = find_the_order_to_complete_topological_feature_using_dic_tree(distinct_CON_OCN_records)
				for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
					dic_supergdu[sgdu_name][polylid] = []
					found_ft = None
					found_first_ft = None
					found_second_ft = None
					temporary_list_to_connect_features = []
					for line_ft in valid_line_fts_from_div:
						if (line_ft.get_name() == polylid):
							found_ft = line_ft
							if (line_ft.get_description() == 'divergent_margin'):
								#obtain rift records for polylid
								selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
								gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
								# if (len(selected_rift_record) > 1):
									# #sort the dataframe of rift point features based on the order 
									# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
									# max_order_rift_point = None
									# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
										# rift_pt_ft_name = rift_name+'_'+str(order)
										# max_order_rift_point = None
										# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
											# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
												# max_order_rift_point = reconstructed_rift_pt
												# break
										# if (max_order_rift_point is not None):
											# break
									# #fnd the two line features 
									# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
									# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
									# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
										# if (div_line_ft.get_name() == first):
											# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
										# if (div_line_ft.get_name() == polylid):
											# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
										# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
											# break
									# if (found_first_reconstructed_line_ft is None):
										# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
											# if (conv_line_ft.get_name() == first):
												# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
											# if (found_first_reconstructed_line_ft is not None):
												# break
									# if (found_first_reconstructed_line_ft is None):
										# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
											# if (plate_bdn_zone_ft.get_name() == first):
												# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
											# if (found_first_reconstructed_line_ft is not None):
												# break
									# if (found_second_reconstructed_line_ft is None):
										# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
											# if (conv_line_ft.get_name() == polylid):
												# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
											# if (found_second_reconstructed_line_ft is not None):
												# break
									# if (found_second_reconstructed_line_ft is None):
										# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
											# if (plate_bdn_zone_ft.get_name() == polylid):
												# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
											# if (found_second_reconstructed_line_ft is not None):
												# break
									# if (max_order_rift_point is not None):
										# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
										# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
										# if (dist_from_first_line > dist_from_second_line):
											# #sort the dataframe of rift point features based on the order 
											# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
										# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
											# rift_pt_ft_name = rift_name+'_'+str(order)
											# found_rift_point_ft = None
											# for rift_pt_ft in valid_rift_pt_fts:
												# if (rift_pt_ft.get_name() == rift_pt_ft_name):
													# found_rift_point_ft = rift_pt_ft
													# break
											# if (found_rift_point_ft is not None):
												# temporary_list_to_connect_features.append(found_rift_point_ft)
								if (len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'transform_fault'):
								temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'plate_boundary_zone'):
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'convergent_margin'):
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												found_first_ft = first_line_ft
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												found_second_ft = second_line_ft
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
					if (found_ft is None):
						for line_ft in valid_line_fts_from_conv:
							if (line_ft.get_name() == polylid):
								found_ft = line_ft
								if (line_ft.get_description() == 'convergent_margin'):
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'transform_fault'):
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'plate_boundary_zone'):
									#try to find the other two features: first and second
									if (first is not None):
										for first_line_ft in valid_line_fts_from_conv:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'convergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													if (found_first_ft is None):
														found_first_ft = first_line_ft
													else:
														if (found_first_ft.get_description() == 'divergent_margin'):
															found_first_ft = first_line_ft #update
									if (second is not None):
										for second_line_ft in valid_line_fts_from_conv:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'convergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													if (found_second_ft is None):
														found_second_ft = second_line_ft
													else:
														if (found_second_ft.get_description() == 'divergent_margin'):
															found_second_ft = second_line_ft #update
									if (found_first_ft is not None and found_second_ft is not None):
										if ((found_first_ft.get_description() == found_second_ft.get_description())):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_first_ft is not None):
										if (found_first_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									#try the new collections
									if (first is not None and found_first_ft is None and found_second_ft is None):
										for first_line_ft in valid_line_fts_from_div:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'divergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													if (found_first_ft is None):
														found_first_ft = first_line_ft
													else:
														if (found_first_ft.get_description() == 'convergent_margin'):
															found_first_ft = first_line_ft #update
									if (found_second_ft is None and found_second_ft is None and found_first_ft is None):
										for second_line_ft in valid_line_fts_from_div:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'divergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													if (found_second_ft is None):
														found_second_ft = second_line_ft
													else:
														if (found_second_ft.get_description() == 'convergent_margin'):
															found_second_ft = second_line_ft #update
									if (found_first_ft is not None):
										if (found_first_ft.get_description() == 'divergent_margin' or found_first_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() == 'divergent_margin' or found_second_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'divergent_margin'):
									#try to find the other two features: first and second
									if (first is not None):
										for first_line_ft in valid_line_fts_from_conv:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'convergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													found_first_ft = first_line_ft
									if (second is not None):
										for second_line_ft in valid_line_fts_from_conv:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'convergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													found_second_ft = second_line_ft
									if (found_first_ft is not None and found_second_ft is not None):
										if ((found_first_ft.get_description() == found_second_ft.get_description())):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_first_ft is not None):
										if (found_first_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									#try the second time to find the other two features: first and second
									if (first is not None and found_first_ft is None and found_second_ft is None):
										for first_line_ft in valid_line_fts_from_div:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'divergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													found_first_ft = first_line_ft
									if (second is not None and found_second_ft is None and found_first_ft is None):
										for second_line_ft in valid_line_fts_from_div:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'divergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													found_second_ft = second_line_ft
									if (found_first_ft is not None):
										if (found_first_ft.get_description() == 'divergent_margin' or found_first_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() == 'divergent_margin' or found_second_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									temporary_list_to_connect_features.append(line_ft)
									break
					if (found_ft is None):
						for line_ft in valid_plate_boundary_zone:
							if (line_ft.get_name() == polylid):
								found_ft = line_ft
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
					if (len(temporary_list_to_connect_features) > 0):
						for each_ft in temporary_list_to_connect_features:
							dic_supergdu[sgdu_name][polylid].append(each_ft)
				if (len(nested_lists_of_CON_OCN_records) > 0):
					print(len(nested_lists_of_CON_OCN_records))
					for small_list in nested_lists_of_CON_OCN_records:
						print('small_list',small_list)
						list_of_features_to_be_connected = None 
						for polylid in small_list:
							print('polylid',polylid)
							if (polylid in dic_supergdu[sgdu_name]):
								features_for_polylid = dic_supergdu[sgdu_name][polylid]
								print('features_for_polylid',features_for_polylid)
								if (list_of_features_to_be_connected is not None):
									list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_polylid
								elif (list_of_features_to_be_connected is None):
									list_of_features_to_be_connected = features_for_polylid
							else:
								print('could not find record for ',polylid)
								exit()
						if (list_of_features_to_be_connected is not None):
							if (len(list_of_features_to_be_connected) > 0):
								print('list_of_features_to_be_connected',list_of_features_to_be_connected)
								#double check to make sure no None feature
								no_none_ft = True
								for ft in list_of_features_to_be_connected:
									if (ft is None):
										no_none_ft = False
										break
								if (no_none_ft == True):
									cloned_original_fts = []
									already_included_line_features[:] = []
									for each_original_ft in list_of_features_to_be_connected:
										# print((each_original_ft.get_name()))#debug
										# print((each_original_ft.is_valid_at_time(reconstruction_time)))
										clone_ft = each_original_ft.clone()
										output_cloned_feats.add(clone_ft)
										#if (each_original_ft.get_feature_id() not in already_included_line_features):
										if (each_original_ft.get_name() not in already_included_line_features):
											cloned_original_fts.append(clone_ft)
											already_included_line_features.append(each_original_ft.get_name())
									#old
									#topological_sections = create_topological_sections(list_of_features_to_be_connected)
									#new
									topological_sections = create_topological_sections(cloned_original_fts)
									if (len(topological_sections) >= 1):
										#find geometries to check whether I need to reverse the order of the points of each line 
										list_of_ordered_geometries = []
										
										topological_ft = create_topological_polygon_feature(topological_sections)
										topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
										# #old
										# for each_original_ft in list_of_features_to_be_connected:
											# if (each_original_ft.get_feature_id() not in already_included_line_features):
												# output_topological_tectonic_plates.add(each_original_ft)
												# already_included_line_features.append(each_original_ft.get_feature_id())
										if (topological_ft is not None):
											topological_ft.set_name(sgdu_name)
											topological_ft.set_valid_time(topological_begin_age, topological_end_age)
											output_topological_tectonic_plates.add(topological_ft)
											fid_topological_ft = topological_ft.get_feature_id().get_string()
											dic_order[sgdu_name][fid_topological_ft] = small_list
											for clone_ft in cloned_original_fts:
												print((clone_ft.get_name()))#debug
												print((clone_ft.is_valid_at_time(reconstruction_time)))
												output_topological_tectonic_plates.add(clone_ft)
		reconstruction_time = reconstruction_time - time_interval
	output_topological_tectonic_plates.write('topological_tectonic_plates_'+modelname+'_'+yearmonthday+'.gpml')
	output_cloned_feats.write('static_segments_of_tectonic_plates_'+modelname+'_'+yearmonthday+'.shp')

def create_tectonic_plates_old(order_to_connect_lines_csv, supergdu_features, line_feats_from_div_process, line_feats_from_conv_process, plate_boundary_zone_feats, modified_rift_point_features, rift_csv_file, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday):
	already_included_line_features = []
	output_topological_tectonic_plates = pygplates.FeatureCollection()
	#,reconstruction_time,sgdu,first,polylid,second
	order_to_connect_lines_df = pd.read_csv(order_to_connect_lines_csv)
	#rift records: start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid 
	rift_df = pd.read_csv(rift_csv_file)
	dic_supergdu = {}
	valid_supergdu_feats = []
	reconstructed_line_features_from_div = []
	reconstructed_line_features_from_conv = []
	reconstructed_plate_boundary_zone = []
	reconstructed_point_features = []
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		valid_supergdu_feats[:] = []
		reconstructed_line_features_from_div[:] = []
		reconstructed_line_features_from_conv[:] = []
		reconstructed_plate_boundary_zone[:] = []
		reconstructed_point_features[:] = []
		valid_line_fts_from_div = [div_ft for div_ft in line_feats_from_div_process if div_ft.is_valid_at_time(reconstruction_time)]
		valid_line_fts_from_conv = [conv_ft for conv_ft in line_feats_from_conv_process if conv_ft.is_valid_at_time(reconstruction_time)]
		valid_plate_boundary_zone = [plat_bdn_ft for plat_bdn_ft in plate_boundary_zone_feats if plat_bdn_ft.is_valid_at_time(reconstruction_time)]
		valid_rift_pt_fts = [pt_ft for pt_ft in modified_rift_point_features if pt_ft.is_valid_at_time(reconstruction_time)]
		
		final_reconstructed_line_features_from_div = None
		final_reconstructed_line_features_from_conv = None
		final_reconstructed_plate_bdn_zone = None
		final_reconstructed_pt_feats = None
		if (len(valid_line_fts_from_div) > 0):
			if (reference is not None):
				pygplates.reconstruct(valid_line_fts_from_div, rotation_model, reconstructed_line_features_from_div, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_line_fts_from_div, rotation_model, reconstructed_line_features_from_div, reconstruction_time, group_with_feature = True)
				#print('len(valid_con_ocn_line_feats)', len(valid_con_ocn_line_feats))
			final_reconstructed_line_features_from_div = find_final_reconstructed_geometries(reconstructed_line_features_from_div, pygplates.PolylineOnSphere)
		if (len(valid_line_fts_from_conv) > 0):
			if (reference is not None):
				pygplates.reconstruct(valid_line_fts_from_conv, rotation_model, reconstructed_line_features_from_conv, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_line_fts_from_conv, rotation_model, reconstructed_line_features_from_conv, reconstruction_time, group_with_feature = True)
				#print('len(valid_con_ocn_line_feats)', len(valid_con_ocn_line_feats))
			final_reconstructed_line_features_from_conv = find_final_reconstructed_geometries(reconstructed_line_features_from_conv, pygplates.PolylineOnSphere)
		if (len(valid_plate_boundary_zone) > 0):
			if (reference is not None):
				pygplates.reconstruct(valid_plate_boundary_zone, rotation_model, reconstructed_plate_boundary_zone, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_plate_boundary_zone, rotation_model, reconstructed_plate_boundary_zone, reconstruction_time, group_with_feature = True)
				#print('len(valid_con_ocn_line_feats)', len(valid_con_ocn_line_feats))
			final_reconstructed_plate_bdn_zone = find_final_reconstructed_geometries(reconstructed_plate_boundary_zone, pygplates.PolylineOnSphere)
		if (len(valid_rift_pt_fts) > 0):
			if (reference is not None):
				pygplates.reconstruct(valid_rift_pt_fts, rotation_model, reconstructed_point_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_rift_pt_fts, rotation_model, reconstructed_point_features, reconstruction_time, group_with_feature = True)
			#print('len(valid_con_ocn_line_feats)', len(valid_con_ocn_line_feats))
			final_reconstructed_pt_feats = find_final_reconstructed_geometries(reconstructed_point_features, pygplates.PointOnSphere)
		
		
		for supergdu_ft in supergdu_features:
			if (supergdu_ft.is_valid_at_time(reconstruction_time)):
				valid_supergdu_feats.append(supergdu_ft)
		for valid_sgdu_ft in valid_supergdu_feats:
			sgdu_name = valid_sgdu_ft.get_name()
			if (sgdu_name in dic_supergdu):
				#obtain all CON-OCN line features
				no_change = True
				for polylid in dic_supergdu[sgdu_name]:
					features = dic_supergdu[sgdu_name][polylid]
					if (len(features) > 1):
						#a collection of rift point features
						#check whether all rift point features are valid
						all_valid_pt_fts = True
						left_over_pt_feats = []
						for pt_ft in features:
							if (pt_ft.is_valid_at_time(reconstruction_time) == False):
								all_valid_pt_fts = False
							else:
								left_over_pt_feats.append(pt_ft)
						if (all_valid_pt_fts == False):
							dic_supergdu[sgdu_name][polylid] = left_over_pt_feats
							no_change = False
					if (no_change == False and len(dic_supergdu[sgdu_name][polylid]) == 0):
						for line_ft in line_feats_from_div_process:
							if (line_ft.get_name() == polylid and line_ft.is_valid_at_time(reconstruction_time + time_interval) == True):
								features = [line_ft]
								break
					if (len(features) == 1):
						line_ft = features[0]
						if (line_ft.is_valid_at_time(reconstruction_time) == False):
							no_change = False
							temporary_list_to_connect_features = []
							found_ft = None
							found_first_ft = None
							found_second_ft = None
							polylid = line_ft.get_name()
							if (line_ft.get_description() != 'divergent_margin'):
								for line_ft in valid_line_fts_from_div:
									if (line_ft.get_name() == polylid):
										found_ft = line_ft
										if (line_ft.get_description() == 'divergent_margin'):
											# #obtain rift records for polylid
											# selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
											gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
											# if (len(selected_rift_record) > 1):
												# #sort the dataframe of rift point features based on the order 
												# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
												# max_order_rift_point = None
												# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
													# rift_pt_ft_name = rift_name+'_'+str(order)
													# #max_order_rift_point = None
													# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
														# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
															# max_order_rift_point = reconstructed_rift_pt
															# break
													# if (max_order_rift_point is not None):
														# break
												# #find the two line features 
												# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
												# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
												# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
													# if (div_line_ft.get_name() == first):
														# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
													# if (div_line_ft.get_name() == polylid):
														# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
													# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
														# break
												# if (found_first_reconstructed_line_ft is None):
													# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
														# if (conv_line_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
														# if (found_first_reconstructed_line_ft is not None):
															# break
												# if (found_first_reconstructed_line_ft is None):
													# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
														# if (plate_bdn_zone_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
														# if (found_first_reconstructed_line_ft is not None):
															# break
												# if (found_second_reconstructed_line_ft is None):
													# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
														# if (conv_line_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
														# if (found_second_reconstructed_line_ft is not None):
															# break
												# if (found_second_reconstructed_line_ft is None):
													# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
														# if (plate_bdn_zone_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
														# if (found_second_reconstructed_line_ft is not None):
															# break
												# if (max_order_rift_point is not None):
													# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
													# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
													# if (dist_from_first_line > dist_from_second_line):
														# #sort the dataframe of rift point features based on the order 
														# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
													# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
														# rift_pt_ft_name = rift_name+'_'+str(order)
														# found_rift_point_ft = None
														# for rift_pt_ft in valid_rift_pt_fts:
															# if (rift_pt_ft.get_name() == rift_pt_ft_name):
																# found_rift_point_ft = rift_pt_ft
															# break
														# if (found_rift_point_ft is not None):
															# temporary_list_to_connect_features.append(found_rift_point_ft)
											if (len(temporary_list_to_connect_features) == 0):
												temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'transform_fault'):
											temporary_list_to_connect_features.append(line_ft)
											break
										break
								if (found_ft is not None):
									if (found_ft.get_description() == 'convergent_margin'):
										for line_ft in valid_line_fts_from_conv:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
												found_ft = line_ft
												break
											elif (line_ft.get_name() == polylid and line_ft.get_description() == 'transform_fault'):
												found_ft = line_ft
								else:
									for line_ft in valid_line_fts_from_conv:
										if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
											found_ft = line_ft
											break
										elif (line_ft.get_name() == polylid and line_ft.get_description() == 'transform_fault'):
											found_ft = line_ft
									if (found_ft is None):
										for line_ft in plate_boundary_zone_feats:
											if (line_ft.get_name() == polylid):
												found_ft = line_ft
								if (found_ft is not None):
									temporary_list_to_connect_features.append(found_ft)
								CON_OCN_records = order_to_connect_lines_df.loc[(order_to_connect_lines_df['sgdu'] == int(sgdu_name)) & (order_to_connect_lines_df['polylid'] == polylid), ['first', 'polylid', 'second']]
								if ((found_ft is None or found_ft.get_description() == 'plate_boundary_zone') and len(CON_OCN_records) > 1):
									if (found_ft is None):
										for line_ft in valid_line_fts_from_conv:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
												found_ft = line_ft
												break
									for first, polylid, second in CON_OCN_records.itertuples(index = False, name = None):
										#try to find the other two features: first and second
										if (first is not None):
											for first_line_ft in valid_line_fts_from_div:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'convergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None):
											for second_line_ft in valid_line_fts_from_div:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'convergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None and found_second_ft is not None):
											if ((found_first_ft.get_description() == found_second_ft.get_description())):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_first_ft is not None):
											if (found_first_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
										#try the new collections
										if (first is not None and found_first_ft is None and found_second_ft is None):
											for first_line_ft in valid_line_fts_from_conv:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'divergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None and found_second_ft is None and found_first_ft is None):
											for second_line_ft in valid_line_fts_from_conv:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'divergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None):
											if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								if (found_ft is not None and len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(found_ft)
							elif (line_ft.get_description() != 'convergent_margin'):
								polylid = line_ft.get_name()
								for line_ft in valid_line_fts_from_conv:
									if (line_ft.get_name() == polylid):
										found_ft = line_ft
										if (line_ft.get_description() == 'convergent_margin'):
											temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_description() == 'transform_fault'):
											temporary_list_to_connect_features.append(line_ft)
											break
								if (found_ft is not None):
									if (found_ft.get_description() == 'divergent_margin'):
										for line_ft in valid_line_fts_from_div:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
												found_ft = line_ft
												#obtain rift records for polylid
												selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
												gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
												# if (len(selected_rift_record) > 1):
													# #sort the dataframe of rift point features based on the order 
													# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
													# max_order_rift_point = None
													# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
														# rift_pt_ft_name = rift_name+'_'+str(order)
														# #max_order_rift_point = None
														# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
															# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
																# max_order_rift_point = reconstructed_rift_pt
																# break
														# if (max_order_rift_point is not None):
															# break
													# #find the two line features 
													# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
													# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
													# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
														# if (div_line_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
														# if (div_line_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
														# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
															# break
													# if (found_first_reconstructed_line_ft is None):
														# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
															# if (conv_line_ft.get_name() == first):
																# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
															# if (found_first_reconstructed_line_ft is not None):
																# break
													# if (found_first_reconstructed_line_ft is None):
														# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
															# if (plate_bdn_zone_ft.get_name() == first):
																# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
															# if (found_first_reconstructed_line_ft is not None):
																# break
													# if (found_second_reconstructed_line_ft is None):
														# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
															# if (conv_line_ft.get_name() == polylid):
																# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
															# if (found_second_reconstructed_line_ft is not None):
																# break
													# if (found_second_reconstructed_line_ft is None):
														# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
															# if (plate_bdn_zone_ft.get_name() == polylid):
																# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
															# if (found_second_reconstructed_line_ft is not None):
																# break
													# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
													# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
													# if (dist_from_first_line > dist_from_second_line):
														# #sort the dataframe of rift point features based on the order 
														# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
													
													# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
														# rift_pt_ft_name = rift_name+'_'+str(order)
														# found_rift_point_ft = None
														# for rift_pt_ft in valid_rift_pt_fts:
															# if (rift_pt_ft.get_name() == rift_pt_ft_name):
																# found_rift_point_ft = rift_pt_ft
															# break
														# if (found_rift_point_ft is not None):
															# temporary_list_to_connect_features.append(found_rift_point_ft)
												if (len(temporary_list_to_connect_features) == 0):
													temporary_list_to_connect_features.append(line_ft)
												break
											elif (line_ft.get_name() == polylid and line_ft.get_description() == 'transform_fault'):
												found_ft = line_ft
								else:
									for line_ft in valid_line_fts_from_div:
										if (line_ft.get_name() == polylid and line_ft.get_description() == 'divergent_margin'):
											found_ft = line_ft
											#obtain rift records for polylid
											selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
											gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
											# if (len(selected_rift_record) > 1):
												# #sort the dataframe of rift point features based on the order 
												# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
												# #sort the dataframe of rift point features based on the order 
												# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
												# max_order_rift_point = None
												# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
													# rift_pt_ft_name = rift_name+'_'+str(order)
													# #max_order_rift_point = None
													# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
														# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
															# max_order_rift_point = reconstructed_rift_pt
															# break
													# if (max_order_rift_point is not None):
														# break
												# #find the two line features 
												# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
												# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
												# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
													# if (div_line_ft.get_name() == first):
														# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
													# if (div_line_ft.get_name() == polylid):
														# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
													# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
														# break
												# if (found_first_reconstructed_line_ft is None):
													# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
														# if (conv_line_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
														# if (found_first_reconstructed_line_ft is not None):
															# break
												# if (found_first_reconstructed_line_ft is None):
													# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
														# if (plate_bdn_zone_ft.get_name() == first):
															# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
														# if (found_first_reconstructed_line_ft is not None):
															# break
												# if (found_second_reconstructed_line_ft is None):
													# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
														# if (conv_line_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
														# if (found_second_reconstructed_line_ft is not None):
															# break
												# if (found_second_reconstructed_line_ft is None):
													# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
														# if (plate_bdn_zone_ft.get_name() == polylid):
															# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
														# if (found_second_reconstructed_line_ft is not None):
															# break
												# if (max_order_rift_point is not None):
													# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
													# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
													# if (dist_from_first_line > dist_from_second_line):
														# #sort the dataframe of rift point features based on the order 
														# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
												
													# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
														# rift_pt_ft_name = rift_name+'_'+str(order)
														# found_rift_point_ft = None
														# for rift_pt_ft in valid_rift_pt_fts:
															# if (rift_pt_ft.get_name() == rift_pt_ft_name):
																# found_rift_point_ft = rift_pt_ft
															# break
														# if (found_rift_point_ft is not None):
															# temporary_list_to_connect_features.append(found_rift_point_ft)
											if (len(temporary_list_to_connect_features) == 0):
												temporary_list_to_connect_features.append(line_ft)
											break
										elif (line_ft.get_name() == polylid and line_ft.get_description() == 'transform_fault'):
											found_ft = line_ft
									if (found_ft is None):
										for line_ft in plate_boundary_zone_feats:
											if (line_ft.get_name() == polylid):
												found_ft = line_ft
								if (found_ft is not None):
									temporary_list_to_connect_features.append(found_ft)
								CON_OCN_records = order_to_connect_lines_df.loc[(order_to_connect_lines_df['sgdu'] == int(sgdu_name)) & (order_to_connect_lines_df['polylid'] == found_ft.get_name()), ['first', 'polylid', 'second']]
								if ((found_ft is None or found_ft.get_description() == 'plate_boundary_zone') and len(CON_OCN_records) > 1):
									if (found_ft is None):
										for line_ft in valid_line_fts_from_div:
											if (line_ft.get_name() == polylid and line_ft.get_description() == 'convergent_margin'):
												found_ft = line_ft
												break
									for first, polylid, second in CON_OCN_records.itertuples(index = False, name = None):
										#try to find the other two features: first and second
										if (first is not None):
											for first_line_ft in valid_line_fts_from_div:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'convergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None):
											for second_line_ft in valid_line_fts_from_div:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'convergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None and found_second_ft is not None):
											if ((found_first_ft.get_description() == found_second_ft.get_description())):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_first_ft is not None):
											if (found_first_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() != 'convergent_margin'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
										#try the new collections
										if (first is not None and found_first_ft is None and found_second_ft is None):
											for first_line_ft in valid_line_fts_from_conv:
												if (first_line_ft.get_name() == first):
													if (first_line_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft
														break
													else:
														if (found_first_ft is None):
															found_first_ft = first_line_ft
														else:
															if (found_first_ft.get_description() == 'divergent_margin'):
																found_first_ft = first_line_ft #update
										if (second is not None and found_second_ft is None and found_first_ft is None):
											for second_line_ft in valid_line_fts_from_conv:
												if (second_line_ft.get_name() == second):
													if (second_line_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft
														break
													else:
														if (found_second_ft is None):
															found_second_ft = second_line_ft
														else:
															if (found_second_ft.get_description() == 'divergent_margin'):
																found_second_ft = second_line_ft #update
										if (found_first_ft is not None):
											if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_first_ft.get_description())
												if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif (found_second_ft is not None):
											if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
												found_ft.set_description (found_second_ft.get_description())
												if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
													found_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
												else:
													found_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								if (found_ft is not None and len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(found_ft)
							if (len(temporary_list_to_connect_features) > 0):
								dic_supergdu[sgdu_name][polylid] = temporary_list_to_connect_features
				if (no_change == False):
					for current_output_topological_ft in output_topological_tectonic_plates:
						if (current_output_topological_ft.get_name() == sgdu_name):
							current_begin_topological_age, current_end_topological_age = current_output_topological_ft.get_valid_time()
							if (current_end_topological_age < reconstruction_time and (reconstruction_time+0.1000) < current_begin_topological_age):
								current_output_topological_ft.set_valid_time(current_begin_topological_age,reconstruction_time+0.1000)
					list_to_connect_features = []
					CON_OCN_records = order_to_connect_lines_df.loc[order_to_connect_lines_df['sgdu'] == int(sgdu_name), ['first', 'polylid', 'second']]
					distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
					for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
						features_for_first = None
						features_for_polylid = None
						features_for_second = None
						if (first in dic_supergdu[sgdu_name]):
							features_for_first =  dic_supergdu[sgdu_name][first]
						if (polylid in dic_supergdu[sgdu_name]):
							features_for_polylid = dic_supergdu[sgdu_name][polylid]
						if (second in dic_supergdu[sgdu_name]):
							features_for_second = dic_supergdu[sgdu_name][second]
						list_of_features_to_be_connected = None
						if (features_for_first is not None):
							list_of_features_to_be_connected = features_for_first
						if (features_for_polylid is not None):
							if (list_of_features_to_be_connected is not None):
								list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_polylid
							elif (list_of_features_to_be_connected is None):
								list_of_features_to_be_connected = features_for_polylid
						if (features_for_second is not None):
							if (list_of_features_to_be_connected is not None and features_for_polylid is not None):
								list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_second
							elif (list_of_features_to_be_connected is None):
								list_of_features_to_be_connected = features_for_second
						if (list_of_features_to_be_connected is not None):
							if (len(list_of_features_to_be_connected) > 0):
								#double check to make sure no None feature
								no_none_ft = True
								for ft in list_of_features_to_be_connected:
									if (ft is None):
										no_none_ft = False
										break
								if (no_none_ft == True):
									topological_sections = create_topological_sections(list_of_features_to_be_connected)
									if (len(topological_sections) >= 1):
										topological_ft = create_topological_line_feature(topological_sections)
										topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
										if (topological_ft is not None):
											topological_ft.set_name(sgdu_name)
											topological_ft.set_valid_time(reconstruction_time, topological_end_age)
											output_topological_tectonic_plates.add(topological_ft)
										for each_original_ft in list_of_features_to_be_connected:
											if (each_original_ft.get_feature_id() not in already_included_line_features):
												output_topological_tectonic_plates.add(each_original_ft)
												already_included_line_features.append(each_original_ft.get_feature_id())
			else:
				#obtain all CON-OCN line features
				dic_supergdu[sgdu_name] = {}
				list_to_connect_features = []
				CON_OCN_records = order_to_connect_lines_df.loc[order_to_connect_lines_df['sgdu'] == int(sgdu_name), ['first', 'polylid', 'second']]
				distinct_CON_OCN_records = CON_OCN_records.drop_duplicates(subset = ['first', 'polylid', 'second'])
				for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
					dic_supergdu[sgdu_name][polylid] = []
					found_ft = None
					found_first_ft = None
					found_second_ft = None
					temporary_list_to_connect_features = []
					for line_ft in valid_line_fts_from_div:
						if (line_ft.get_name() == polylid):
							if (line_ft.get_description() == 'divergent_margin'):
								#obtain rift records for polylid
								selected_rift_record = rift_df.loc[((rift_df['lpolylid'] == polylid) | (rift_df['rpolylid'] == polylid)) & (rift_df['start_div'] >= reconstruction_time),['rift_name','order']]
								gduid_of_line_ft = line_ft.get_reconstruction_plate_id()
								# if (len(selected_rift_record) > 1):
									# #sort the dataframe of rift point features based on the order 
									# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
									# max_order_rift_point = None
									# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
										# rift_pt_ft_name = rift_name+'_'+str(order)
										# #max_order_rift_point = None
										# for reconstructed_rift_pt_ft, reconstructed_rift_pt in final_reconstructed_pt_feats:
											# if (reconstructed_rift_pt_ft.get_name() == rift_pt_ft_name):
												# max_order_rift_point = reconstructed_rift_pt
												# break
										# if (max_order_rift_point is not None):
											# break
									# #find the two line features 
									# found_first_reconstructed_line_ft,found_first_reconstructed_line = None, None
									# found_second_reconstructed_line_ft,found_second_reconstructed_line = None, None
									# for div_line_ft, div_line in final_reconstructed_line_features_from_div:
										# if (div_line_ft.get_name() == first):
											# found_first_reconstructed_line_ft,found_first_reconstructed_line = div_line_ft, div_line
										# if (div_line_ft.get_name() == polylid):
											# found_second_reconstructed_line_ft,found_second_reconstructed_line = div_line_ft, div_line
										# if (found_first_reconstructed_line_ft is not None and found_second_reconstructed_line_ft is not None):
											# break
									# if (found_first_reconstructed_line_ft is None):
										# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
											# if (conv_line_ft.get_name() == first):
												# found_first_reconstructed_line_ft,found_first_reconstructed_line = conv_line_ft, conv_line
											# if (found_first_reconstructed_line_ft is not None):
												# break
									# if (found_first_reconstructed_line_ft is None):
										# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
											# if (plate_bdn_zone_ft.get_name() == first):
												# found_first_reconstructed_line_ft,found_first_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
											# if (found_first_reconstructed_line_ft is not None):
												# break
									# if (found_second_reconstructed_line_ft is None):
										# for conv_line_ft, conv_line in final_reconstructed_line_features_from_conv:
											# if (conv_line_ft.get_name() == polylid):
												# found_second_reconstructed_line_ft,found_second_reconstructed_line = conv_line_ft, conv_line
											# if (found_second_reconstructed_line_ft is not None):
												# break
									# if (found_second_reconstructed_line_ft is None):
										# for plate_bdn_zone_ft, plate_bdn_zone_line in final_reconstructed_plate_bdn_zone:
											# if (plate_bdn_zone_ft.get_name() == polylid):
												# found_second_reconstructed_line_ft,found_second_reconstructed_line = plate_bdn_zone_ft, plate_bdn_zone_line
											# if (found_second_reconstructed_line_ft is not None):
												# break
									# if (max_order_rift_point is not None):
										# dist_from_first_line = pygplates.GeometryOnSphere.distance(found_first_reconstructed_line,max_order_rift_point)
										# dist_from_second_line = pygplates.GeometryOnSphere.distance(found_second_reconstructed_line,max_order_rift_point)
										# if (dist_from_first_line > dist_from_second_line):
											# #sort the dataframe of rift point features based on the order 
											# sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=True)
										# for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
											# rift_pt_ft_name = rift_name+'_'+str(order)
											# found_rift_point_ft = None
											# for rift_pt_ft in valid_rift_pt_fts:
												# if (rift_pt_ft.get_name() == rift_pt_ft_name):
													# found_rift_point_ft = rift_pt_ft
													# break
											# if (found_rift_point_ft is not None):
												# temporary_list_to_connect_features.append(found_rift_point_ft)
								if (len(temporary_list_to_connect_features) == 0):
									temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'transform_fault'):
								temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'plate_boundary_zone'):
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
							elif (line_ft.get_description() == 'convergent_margin'):
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												found_first_ft = first_line_ft
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												found_second_ft = second_line_ft
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
					if (found_ft is None):
						for line_ft in valid_line_fts_from_conv:
							if (line_ft.get_name() == polylid):
								found_ft = line_ft
								if (line_ft.get_description() == 'convergent_margin'):
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'transform_fault'):
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'plate_boundary_zone'):
									#try to find the other two features: first and second
									if (first is not None):
										for first_line_ft in valid_line_fts_from_conv:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'convergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													if (found_first_ft is None):
														found_first_ft = first_line_ft
													else:
														if (found_first_ft.get_description() == 'divergent_margin'):
															found_first_ft = first_line_ft #update
									if (second is not None):
										for second_line_ft in valid_line_fts_from_conv:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'convergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													if (found_second_ft is None):
														found_second_ft = second_line_ft
													else:
														if (found_second_ft.get_description() == 'divergent_margin'):
															found_second_ft = second_line_ft #update
									if (found_first_ft is not None and found_second_ft is not None):
										if ((found_first_ft.get_description() == found_second_ft.get_description())):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_first_ft is not None):
										if (found_first_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									
									#try the new collections
									if (first is not None and found_first_ft is None and found_second_ft is None):
										for first_line_ft in valid_line_fts_from_div:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'divergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													if (found_first_ft is None):
														found_first_ft = first_line_ft
													else:
														if (found_first_ft.get_description() == 'convergent_margin'):
															found_first_ft = first_line_ft #update
									if (found_second_ft is None and found_second_ft is None and found_first_ft is None):
										for second_line_ft in valid_line_fts_from_div:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'divergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													if (found_second_ft is None):
														found_second_ft = second_line_ft
													else:
														if (found_second_ft.get_description() == 'convergent_margin'):
															found_second_ft = second_line_ft #update
									if (found_first_ft is not None):
										if (found_first_ft.get_description() == 'divergent_margin' or found_first_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() == 'divergent_margin' or found_second_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									temporary_list_to_connect_features.append(line_ft)
									break
								elif (line_ft.get_description() == 'divergent_margin'):
									#try to find the other two features: first and second
									if (first is not None):
										for first_line_ft in valid_line_fts_from_conv:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'convergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													found_first_ft = first_line_ft
									if (second is not None):
										for second_line_ft in valid_line_fts_from_conv:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'convergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													found_second_ft = second_line_ft
									if (found_first_ft is not None and found_second_ft is not None):
										if ((found_first_ft.get_description() == found_second_ft.get_description())):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'divergent_margin')):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_first_ft is not None):
										if (found_first_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() != 'divergent_margin'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									#try the second time to find the other two features: first and second
									if (first is not None and found_first_ft is None and found_second_ft is None):
										for first_line_ft in valid_line_fts_from_div:
											if (first_line_ft.get_name() == first):
												if (first_line_ft.get_description() == 'divergent_margin'):
													found_first_ft = first_line_ft
													break
												else:
													found_first_ft = first_line_ft
									if (second is not None and found_second_ft is None and found_first_ft is None):
										for second_line_ft in valid_line_fts_from_div:
											if (second_line_ft.get_name() == second):
												if (second_line_ft.get_description() == 'divergent_margin'):
													found_second_ft = second_line_ft
													break
												else:
													found_second_ft = second_line_ft
									if (found_first_ft is not None):
										if (found_first_ft.get_description() == 'divergent_margin' or found_first_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_first_ft.get_description())
											if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif (found_second_ft is not None):
										if (found_second_ft.get_description() == 'divergent_margin' or found_second_ft.get_description() == 'transform_fault'):
											line_ft.set_description (found_second_ft.get_description())
											if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
												line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
											else:
												line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									temporary_list_to_connect_features.append(line_ft)
									break
					if (found_ft is None):
						for line_ft in plate_boundary_zone_feats:
							if (line_ft.get_name() == polylid):
								found_ft = line_ft
								#try to find the other two features: first and second
								if (first is not None):
									for first_line_ft in valid_line_fts_from_div:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'divergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'convergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None):
									for second_line_ft in valid_line_fts_from_div:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'divergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'convergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None and found_second_ft is not None):
									if ((found_first_ft.get_description() == found_second_ft.get_description())):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_second_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
									elif ((found_first_ft.get_description() != found_second_ft.get_description()) and (found_first_ft.get_description() == 'convergent_margin')):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_first_ft is not None):
									if (found_first_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() != 'convergent_margin'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								
								#try the new collections
								if (first is not None and found_first_ft is None and found_second_ft is None):
									for first_line_ft in valid_line_fts_from_conv:
										if (first_line_ft.get_name() == first):
											if (first_line_ft.get_description() == 'convergent_margin'):
												found_first_ft = first_line_ft
												break
											else:
												if (found_first_ft is None):
													found_first_ft = first_line_ft
												else:
													if (found_first_ft.get_description() == 'divergent_margin'):
														found_first_ft = first_line_ft #update
								if (second is not None and found_second_ft is None and found_first_ft is None):
									for second_line_ft in valid_line_fts_from_conv:
										if (second_line_ft.get_name() == second):
											if (second_line_ft.get_description() == 'convergent_margin'):
												found_second_ft = second_line_ft
												break
											else:
												if (found_second_ft is None):
													found_second_ft = second_line_ft
												else:
													if (found_second_ft.get_description() == 'divergent_margin'):
														found_second_ft = second_line_ft #update
								if (found_first_ft is not None):
									if (found_first_ft.get_description() == 'convergent_margin' or found_first_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_first_ft.get_description())
										if (found_first_ft.get_reconstruction_plate_id() == found_first_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_first_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_first_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								elif (found_second_ft is not None):
									if (found_second_ft.get_description() == 'convergent_margin' or found_second_ft.get_description() == 'transform_fault'):
										line_ft.set_description (found_second_ft.get_description())
										if (found_second_ft.get_reconstruction_plate_id() == found_second_ft.get_left_plate()):
											line_ft.set_conjugate_plate_id(found_second_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
										else:
											line_ft.set_conjugate_plate_id(found_second_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
								temporary_list_to_connect_features.append(line_ft)
								break
					if (len(temporary_list_to_connect_features) > 0):
						for each_ft in temporary_list_to_connect_features:
							dic_supergdu[sgdu_name][polylid].append(each_ft)
				for first, polylid, second in distinct_CON_OCN_records.itertuples(index = False, name = None):
					features_for_first = None
					features_for_polylid = None
					features_for_second = None
					if (first in dic_supergdu[sgdu_name]):
						features_for_first =  dic_supergdu[sgdu_name][first]
					if (polylid in dic_supergdu[sgdu_name]):
						features_for_polylid = dic_supergdu[sgdu_name][polylid]
					if (second in dic_supergdu[sgdu_name]):
						features_for_second = dic_supergdu[sgdu_name][second]
					list_of_features_to_be_connected = None
					if (features_for_first is not None):
						list_of_features_to_be_connected = features_for_first
					if (features_for_polylid is not None):
						if (list_of_features_to_be_connected is not None):
							list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_polylid
						elif (list_of_features_to_be_connected is None):
							list_of_features_to_be_connected = features_for_polylid
					if (features_for_second is not None):
						if (list_of_features_to_be_connected is not None and features_for_polylid is not None):
							list_of_features_to_be_connected = list_of_features_to_be_connected + features_for_second
						elif (list_of_features_to_be_connected is None):
							list_of_features_to_be_connected = features_for_second
					if (list_of_features_to_be_connected is not None):
						if (len(list_of_features_to_be_connected) > 0):
							#double check to make sure no None feature
							no_none_ft = True
							for ft in list_of_features_to_be_connected:
								if (ft is None):
									no_none_ft = False
									break
							if (no_none_ft == True):
								topological_sections = create_topological_sections(list_of_features_to_be_connected)
								if (len(topological_sections) >= 1):
									topological_ft = create_topological_polygon_feature(topological_sections)
									topological_begin_age, topological_end_age = valid_sgdu_ft.get_valid_time()
									if (topological_ft is not None):
										topological_ft.set_name(sgdu_name)
										topological_ft.set_valid_time(topological_begin_age, topological_end_age)
										output_topological_tectonic_plates.add(topological_ft)
									for each_original_ft in list_of_features_to_be_connected:
										if (each_original_ft.get_feature_id() not in already_included_line_features):
											output_topological_tectonic_plates.add(each_original_ft)
											already_included_line_features.append(each_original_ft.get_feature_id())
		reconstruction_time = reconstruction_time - time_interval
	output_topological_tectonic_plates.write('topological_tectonic_plates_'+modelname+'_'+yearmonthday+'.gpml')


# def main():
	# order_to_connect_lines_csv = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\order_to_connect_con_ocn_line_feats_for_each_sgdu_PalaeoPlatesendJan2023_from_max_time_2800.0_20231024.csv"
	# supergdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
	# line_feats_from_div_process_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\diverging_line_features_for_2800.0_5.0_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	# line_feats_from_div_process = pygplates.FeatureCollection(line_feats_from_div_process_file)
	# line_feats_from_conv_process_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\converging_line_features_for_2800.0_0.0_test_30_short_conv_PalaeoPlatesJan2023_20231023.shp"
	# line_feats_from_conv_process = pygplates.FeatureCollection(line_feats_from_conv_process_file)
	# plate_boundary_zone_feats_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
	# plate_boundary_zone_feats = pygplates.FeatureCollection(plate_boundary_zone_feats_file)
	# modified_rift_point_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	# modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
	# rift_csv_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	# begin_reconstruction_time = 200.00
	# end_reconstruction_time = 100.00
	# time_interval = 5.00
	# rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# reference = 700
	# yearmonthday = '20231107'
	# modelname = 'PalaeoPlatesendJan2023'
	# create_tectonic_plates(order_to_connect_lines_csv, supergdu_features, line_feats_from_div_process, line_feats_from_conv_process, plate_boundary_zone_feats, modified_rift_point_features, rift_csv_file, begin_reconstruction_time, end_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday)

# if __name__ == '__main__':
	# main()