import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import math
import pandas as pd
import numpy as np

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def edit_temporary_MOR_w_superGDU(temp_MOR_features, sgdu_features, sgdu_history_csv, extra_sgdu_history_csv, rotation_model, time_interval, reference, modelname, yearmonthday):
	#framework_dic = {'origin_lv':[],'SGDU':[],'parent':[],'from_time':[],'to_time':[],'repGDUID':[]}
	sgdu_history_df = pd.read_csv(sgdu_history_csv, delimiter=',', header = 0)
	extra_sgdu_history_df = pd.read_csv(extra_sgdu_history_csv, delimiter=',', header = 0)
	edited_MOR_features = pygplates.FeatureCollection()
	output_sgdus_possibly_participate_to_convergence = []
	for temp_MOR_ft in temp_MOR_features:
		from_time_MOR,to_time_MOR = temp_MOR_ft.get_valid_time()
		plateID_1 = temp_MOR_ft.get_left_plate()
		plateID_2 = temp_MOR_ft.get_right_plate()
		sgdu_1_from_prev_time = None
		sgdu_2_from_prev_time = None
		already_edited_MOR = False
		t = from_time_MOR
		while (t >= to_time_MOR):
			sgdu_features_1 = []
			sgdu_features_2 = []
			already_recorded_children = None
			for sgdu_ft in sgdu_features:
				if (sgdu_ft.get_reconstruction_plate_id() == plateID_1 and sgdu_ft.is_valid_at_time(t)):
					sgdu_features_1.append(sgdu_ft)
					if (sgdu_1_from_prev_time is None or sgdu_1_from_prev_time!= int(sgdu_ft.get_name())):
						sgdu_1_from_prev_time = int(sgdu_ft.get_name())
			if (len(sgdu_features_1) == 0):
				if (sgdu_1_from_prev_time is None):
					print("Error len(sgdu_features_1) == 0 and sgdu_1_from_prev_time is None")
					print("temp_MOR_ft",temp_MOR_ft.get_name())
					print("at t",t)
					pygplates.FeatureCollection(temp_MOR_ft).write("Error_MOR_ft_"+modelname+'_'+yearmonthday+'.shp')
					exit()
				records_children_sgdu = sgdu_history_df.loc[sgdu_history_df['parent'] == sgdu_1_from_prev_time,['SGDU','repGDUID']]
				is_transitioning_to_convergence = False
				if (records_children_sgdu is None or len(records_children_sgdu) == 0):
					is_transitioning_to_convergence = True
					#use EXTRA SuperGDU history records
					records_children_sgdu = extra_sgdu_history_df.loc[extra_sgdu_history_df['parent'] == sgdu_1_from_prev_time,['SGDU','repGDUID']]
					if (records_children_sgdu is None or len(records_children_sgdu) == 0):
						# print("Error records_children_sgdu is None")
						# print("temp_MOR_ft",temp_MOR_ft.get_name())
						# print("sgdu_1_from_prev_time",sgdu_1_from_prev_time)
						# print("from_time_MOR,to_time_MOR",from_time_MOR,to_time_MOR)
						# print("at t",t)
						# pygplates.FeatureCollection(temp_MOR_ft).write("Error_MOR_ft_"+modelname+'_'+yearmonthday+'.shp')
						# output_sgdu_features = pygplates.FeatureCollection()
						# for sgdu_ft in sgdu_features:
							# if (int(sgdu_ft.get_name()) == sgdu_1_from_prev_time):
								# output_sgdu_features.add(sgdu_ft)
						# output_sgdu_features.write('could_not_find_childred_for_SGDU_'+str(sgdu_1_from_prev_time)+'_'+modelname+'_'+yearmonthday+'.shp')
						# exit()

						#end of divergence - entering convergence 
						temp_MOR_ft.set_valid_time(from_time_MOR,t)
						already_edited_MOR = True
				if (already_edited_MOR == True):
					break

				if (is_transitioning_to_convergence == True):
					already_recorded_children = []
				for tuple_of_sgdu_repgdu in records_children_sgdu.itertuples(index = False, name = None):
					child_sgdu,child_repgduid = tuple_of_sgdu_repgdu
					pair_sgdu_repgduid = str(child_sgdu)+'_'+str(child_repgduid)
					if (is_transitioning_to_convergence == True):
						if (pair_sgdu_repgduid not in already_recorded_children):
							output_sgdus_possibly_participate_to_convergence.append((t,sgdu_1_from_prev_time,child_sgdu,child_repgduid))
							already_recorded_children.append(pair_sgdu_repgduid)
					for sgdu_ft in sgdu_features:
						if ((sgdu_ft.get_reconstruction_plate_id() == child_repgduid or int(sgdu_ft.get_name()) == child_sgdu) and sgdu_ft.is_valid_at_time(t)):
							sgdu_features_1.append(sgdu_ft)
							if (sgdu_1_from_prev_time != child_sgdu):
								sgdu_1_from_prev_time = child_sgdu
			for sgdu_ft in sgdu_features:
				if (sgdu_ft.get_reconstruction_plate_id() == plateID_2 and sgdu_ft.is_valid_at_time(t)):
					sgdu_features_2.append(sgdu_ft)
					if (sgdu_2_from_prev_time is None or sgdu_2_from_prev_time!= int(sgdu_ft.get_name())):
						sgdu_2_from_prev_time = int(sgdu_ft.get_name())
			if (len(sgdu_features_2) == 0):
				if (sgdu_2_from_prev_time is None):
					print("Error len(sgdu_features_2) == 0 and sgdu_2_from_prev_time is None")
					print("temp_MOR_ft",temp_MOR_ft.get_name())
					print("at t",t)
					pygplates.FeatureCollection(temp_MOR_ft).write("Error_MOR_ft_"+modelname+'_'+yearmonthday+'.shp')
					exit()
				records_children_sgdu = sgdu_history_df.loc[sgdu_history_df['parent'] == sgdu_2_from_prev_time,['SGDU','repGDUID']]
				is_transitioning_to_convergence = False
				if (records_children_sgdu is None or len(records_children_sgdu) == 0):
					is_transitioning_to_convergence = True
					#use EXTRA SuperGDU history records
					records_children_sgdu = extra_sgdu_history_df.loc[extra_sgdu_history_df['parent'] == sgdu_2_from_prev_time,['SGDU','repGDUID']]
					if (records_children_sgdu is None or len(records_children_sgdu) == 0):
						# print("Error records_children_sgdu is None")
						# print("records_children_sgdu",records_children_sgdu)
						# print("temp_MOR_ft",temp_MOR_ft.get_name())
						# print("sgdu_2_from_prev_time",sgdu_2_from_prev_time)
						# print("at t",t)
						# pygplates.FeatureCollection(temp_MOR_ft).write("Error_MOR_ft_"+modelname+'_'+yearmonthday+'.shp')
						# exit()
						
						#end of divergence - entering convergence 
						temp_MOR_ft.set_valid_time(from_time_MOR,t)
						already_edited_MOR = True
				if (already_edited_MOR == True):
					break
				already_recorded_children_2 = None
				if (is_transitioning_to_convergence == True):
					already_recorded_children_2 = []
				for tuple_of_sgdu_repgdu in records_children_sgdu.itertuples(index = False, name = None):
					child_sgdu,child_repgduid = tuple_of_sgdu_repgdu
					pair_sgdu_repgduid = str(child_sgdu)+'_'+str(child_repgduid)
					if (is_transitioning_to_convergence == True):
						if (pair_sgdu_repgduid not in already_recorded_children_2):
							output_sgdus_possibly_participate_to_convergence.append((t,sgdu_2_from_prev_time,child_sgdu,child_repgduid))
							already_recorded_children_2.append(pair_sgdu_repgduid)
					for sgdu_ft in sgdu_features:
						if (already_recorded_children is not None):
							if (sgdu_ft.get_name() in already_recorded_children):
								continue
						if ((sgdu_ft.get_reconstruction_plate_id() == child_repgduid or sgdu_ft.get_name() == child_sgdu) and sgdu_ft.is_valid_at_time(t)):
							sgdu_features_2.append(sgdu_ft)
							if (sgdu_2_from_prev_time != child_sgdu):
								sgdu_2_from_prev_time = child_sgdu
			
			reconstructed_MOR_features = []
			reconstructed_sgdu_features_1 = []
			reconstructed_sgdu_features_2 = []
			if (reference is not None):
				pygplates.reconstruct(temp_MOR_ft,rotation_model,reconstructed_MOR_features,t,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(sgdu_features_1,rotation_model,reconstructed_sgdu_features_1,t,anchor_plate_id = reference, group_with_feature = True)
				if (len(sgdu_features_2) > 0):
					pygplates.reconstruct(sgdu_features_2,rotation_model,reconstructed_sgdu_features_2,t,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(temp_MOR_ft,rotation_model,reconstructed_MOR_features,t,group_with_feature = True)
				pygplates.reconstruct(sgdu_features_1,rotation_model,reconstructed_sgdu_features_1,t,group_with_feature = True)
				if (len(sgdu_features_2) > 0):
					pygplates.reconstruct(sgdu_features_2,rotation_model,reconstructed_sgdu_features_2,t,group_with_feature = True)
			print('reconstructed_MOR_features',reconstructed_MOR_features)
			final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PolylineOnSphere)
			final_reconstructed_sgdu_fts_1 = find_final_reconstructed_geometries(reconstructed_sgdu_features_1,pygplates.PolygonOnSphere)
			final_reconstructed_sgdu_fts_2 = None
			if (len(reconstructed_sgdu_features_2) > 0):
				final_reconstructed_sgdu_fts_2 = find_final_reconstructed_geometries(reconstructed_sgdu_features_2,pygplates.PolygonOnSphere)
			#print('final_reconstructed_MOR_fts',final_reconstructed_MOR_fts)
			print('temp_MOR_ft',temp_MOR_ft)
			print('name',temp_MOR_ft.get_name())
			print('temp_MOR_ft.get_valid_time()',temp_MOR_ft.get_valid_time())
			print('original time',from_time_MOR,to_time_MOR)
			print('current t',t)
			print('already_edited_MOR',already_edited_MOR)
			reconstructed_MOR_ft,reconstructed_MOR = final_reconstructed_MOR_fts[0]
			if (t == from_time_MOR):
				approx_mid_point = reconstructed_MOR.get_centroid()
				potential_left = None
				potential_right = None
				for ft_1,polygon_1 in final_reconstructed_sgdu_fts_1:
					centroid_1 = polygon_1.get_interior_centroid()
					x1,y1,z1 = centroid_1.to_xyz()
					magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(approx_mid_point,x1,y1,z1)
					if (azimuth <= math.pi or azimuth == 2*math.pi):
						potential_right = plateID_1
						break
					elif (azimuth > math.pi):
						potential_left = plateID_1
						break
				if (potential_left == plateID_1):
					for ft_2,polygon_2 in final_reconstructed_sgdu_fts_2:
						centroid_2 = polygon_2.get_interior_centroid()
						x2,y2,z2 = centroid_2.to_xyz()
						magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(approx_mid_point,x2,y2,z2)
						if (azimuth > math.pi):
							potential_left = plateID_2
							break
				elif (potential_right == plateID_1):
					for ft_2,polygon_2 in final_reconstructed_sgdu_fts_2:
						centroid_2 = polygon_2.get_interior_centroid()
						x2,y2,z2 = centroid_2.to_xyz()
						magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(approx_mid_point,x2,y2,z2)
						if (azimuth <= math.pi or azimuth == 2*math.pi):
							potential_right = plateID_2
							break
				if (potential_left is not None and potential_right is None):
					if (potential_left == plateID_1):
						potential_right = plateID_2
					else:
						potential_right = plateID_1
				elif (potential_left is None and potential_right is not None):
					if (potential_right == plateID_1):
						potential_left = plateID_2
					else:
						potential_left = plateID_1

			for sgdu_ft_1,sgdu_1 in final_reconstructed_sgdu_fts_1:
				if (sgdu_1.partition(reconstructed_MOR) == pygplates.PolygonOnSphere.PartitionResult.inside):
					#end time for MOR
					temp_MOR_ft.set_valid_time(from_time_MOR,t)
					already_edited_MOR = True
					break
			if (already_edited_MOR == True):
				break
			if (final_reconstructed_sgdu_fts_2 is not None):
				for sgdu_ft_2,sgdu_2 in final_reconstructed_sgdu_fts_2:
					if (sgdu_2.partition(reconstructed_MOR) == pygplates.PolygonOnSphere.PartitionResult.inside):
						#end time for MOR
						temp_MOR_ft.set_valid_time(from_time_MOR,t)
						already_edited_MOR = True
						break
				if (already_edited_MOR == True):
					break
			t = t - time_interval
		edited_MOR_features.add(temp_MOR_ft)
	edited_MOR_features.write('edited_temp_MOR_'+modelname+'_'+yearmonthday+'.shp')
	
	output_dataframe = pd.DataFrame.from_records(output_sgdus_possibly_participate_to_convergence, columns = ['transition_time','parent','SGDU','repGDUID'])
	filename = 'sgdus_possibly_participate_to_conv_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)


def edit_temporary_MOR_w_associated_div_line_features(temp_MOR_features, associated_div_line_features, rift_point_features_records_csv, threshold_period, time_interval, rotation_model,reference, modelname, yearmonthday):
	edited_MOR_features = pygplates.FeatureCollection()
	reconstructed_MOR_features = []
	reconstructed_div_features = []
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	output_MOR_name_valid_time = []
	output_possible_convergent_lines = []
	for temp_MOR_ft in temp_MOR_features:
		from_time_MOR,to_time_MOR = temp_MOR_ft.get_valid_time()
		plateID_1 = temp_MOR_ft.get_left_plate()
		plateID_2 = temp_MOR_ft.get_right_plate()
		time_MOR_intersect_div = -1.00
		#find associated_div_line_features for the specific temp_MOR_ft
		MOR_name = temp_MOR_ft.get_name()
		div_line_names_for_left_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == MOR_name,'lpolylid'].unique()
		div_line_names_for_right_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == MOR_name,'rpolylid'].unique()
		already_edited_MOR = False
		t = from_time_MOR-time_interval
		while (t >= to_time_MOR):
			if (already_edited_MOR == True):
				break
			list_of_valid_associated_div_line_feats = []
			for line_ft in associated_div_line_features:
				if (line_ft.is_valid_at_time(t)):
					if (line_ft.get_name() in div_line_names_for_left_of_MOR):
						list_of_valid_associated_div_line_feats.append(line_ft)
					elif (line_ft.get_name() in div_line_names_for_right_of_MOR):
						list_of_valid_associated_div_line_feats.append(line_ft)
			if (len(list_of_valid_associated_div_line_feats) == 0.00):
				#edit the end time of MOR
				temp_MOR_ft.set_valid_time(from_time_MOR,t)
				already_edited_MOR = True
			else:
				reconstructed_MOR_features[:] = []
				reconstructed_div_features[:] = []
				if (reference is not None):
					pygplates.reconstruct(temp_MOR_ft,rotation_model,reconstructed_MOR_features,t,anchor_plate_id = reference, group_with_feature = True)
					pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,t,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(temp_MOR_ft,rotation_model,reconstructed_MOR_features,t,group_with_feature = True)
					pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,t,group_with_feature = True)
				final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PolylineOnSphere)
				final_reconstructed_div_features = find_final_reconstructed_geometries(reconstructed_div_features,pygplates.PolylineOnSphere)
				reconstructed_MOR_ft,reconstructed_MOR = final_reconstructed_MOR_fts[0]
				for reconstructed_div_ft,reconstructed_div_line in final_reconstructed_div_features:
					if (pygplates.GeometryOnSphere.distance(reconstructed_MOR,reconstructed_div_line) == 0.00):
						#need to evaluate the relationship between the angular velocity vector and the position at time t
						
						
						output_possible_convergent_lines.append((t,MOR_name,reconstructed_div_ft.get_name(),reconstructed_div_ft.get_feature_id().get_string(),reconstructed_div_ft.get_reconstruction_plate_id()))
						if (time_MOR_intersect_div == -1.00):
							time_MOR_intersect_div = t
						else:
							diff = time_MOR_intersect_div - t
							if (diff >= threshold_period):
								temp_MOR_ft.set_valid_time(from_time_MOR,t)
								already_edited_MOR = True
						break
			t = t - time_interval
		final_from_time_MOR,final_end_time_MOR = temp_MOR_ft.get_valid_time()
		output_MOR_name_valid_time.append((MOR_name,final_from_time_MOR,final_end_time_MOR))
		edited_MOR_features.add(temp_MOR_ft)
	
	edited_MOR_features.write('edited_temp_MOR_w_div_feats_'+modelname+'_'+yearmonthday+'.shp')
	
	
	output_dataframe = pd.DataFrame.from_records(output_possible_convergent_lines, columns = ['time','MOR_name','div_name','div_GPLATESID','GDUID'])
	filename = 'possible_convergent_lines_from_MORs_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)
	
	output_dataframe = pd.DataFrame.from_records(output_MOR_name_valid_time, columns = ['MOR_name','from_time','to_time'])
	filename = 'MOR_name_valid_time_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)

def create_left_and_right_div_fts_from_MOR_ft(MOR_ft, MOR_geom, begin_age, end_age):
	left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, MOR_geom, valid_time = (begin_age, end_age))
	left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_name(MOR_ft.get_name())
	left_MOR_location_ft.set_left_plate(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_right_plate(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_left_plate())
	left_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_description(MOR_ft.get_description())

	right_MOR_location_ft = left_MOR_location_ft.clone()
	right_MOR_location_ft.set_reconstruction_plate_id(MOR_ft.get_right_plate())
	right_MOR_location_ft.set_conjugate_plate_id(MOR_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	right_MOR_location_ft.set_description(MOR_ft.get_description())
	return (left_MOR_location_ft,right_MOR_location_ft)

def create_left_and_right_div_fts_from_rift_point_ft(rift_ft, geom, begin_age, end_age):
	left_MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, geom, valid_time = (begin_age, end_age))
	left_MOR_location_ft.set_reconstruction_method('ByPlateId',verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_name(rift_ft.get_name())
	left_MOR_location_ft.set_left_plate(rift_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_right_plate(rift_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_reconstruction_plate_id(rift_ft.get_left_plate())
	left_MOR_location_ft.set_conjugate_plate_id(rift_ft.get_right_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	left_MOR_location_ft.set_description(rift_ft.get_description())

	right_MOR_location_ft = left_MOR_location_ft.clone()
	right_MOR_location_ft.set_reconstruction_plate_id(rift_ft.get_right_plate())
	right_MOR_location_ft.set_conjugate_plate_id(rift_ft.get_left_plate(),verify_information_model = pygplates.VerifyInformationModel.no)
	return (left_MOR_location_ft,right_MOR_location_ft)


def create_isochron_from_temp_MOR(temp_MOR_features, associated_div_line_features, rift_point_features_records_csv, con_ocn_line_features, time_interval, rotation_model,reference, modelname, yearmonthday):
	edited_MOR_features = pygplates.FeatureCollection()
	temp_isochron_from_MOR = pygplates.FeatureCollection()
	reconstructed_MOR_features = []
	reconstructed_div_features = []
	reconstructed_line_features = []
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	output_MOR_name_valid_time = []
	output_possible_convergent_lines = []
	for temp_MOR_ft in temp_MOR_features:
		from_time_MOR,to_time_MOR = temp_MOR_ft.get_valid_time()
		plateID_1 = temp_MOR_ft.get_left_plate()
		plateID_2 = temp_MOR_ft.get_right_plate()
		time_MOR_intersect_div = -1.00
		#find associated_div_line_features for the specific temp_MOR_ft
		MOR_name = temp_MOR_ft.get_name()
		div_line_names_for_left_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == MOR_name,'lpolylid'].unique()
		div_line_names_for_right_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == MOR_name,'rpolylid'].unique()
		already_end_MOR = False
		reconstruction_time = from_time_MOR-time_interval
		while (reconstruction_time >= to_time_MOR):
			if (already_end_MOR == True):
				break
			list_of_valid_associated_div_line_feats = []
			for line_ft in associated_div_line_features:
				if (line_ft.is_valid_at_time(reconstruction_time)):
					if (line_ft.get_name() in div_line_names_for_left_of_MOR):
						list_of_valid_associated_div_line_feats.append(line_ft)
					elif (line_ft.get_name() in div_line_names_for_right_of_MOR):
						list_of_valid_associated_div_line_feats.append(line_ft)
			list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in con_ocn_line_features if con_ocn_line_ft.is_valid_at_time(reconstruction_time)]
			final_reconstructed_div_features = None
			if (len(list_of_valid_associated_div_line_feats) != 0.00):
				reconstructed_div_features[:] = []
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_div_features = find_final_reconstructed_geometries(reconstructed_div_features,pygplates.PolylineOnSphere)
			reconstructed_MOR_features[:] = []
			reconstructed_line_features[:] = []
			if (reference is not None):
				pygplates.reconstruct(temp_MOR_ft,rotation_model,reconstructed_MOR_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(temp_MOR_ft,rotation_model,reconstructed_MOR_features,reconstruction_time,group_with_feature = True)
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PolylineOnSphere)
			final_reconstructed_line_fts = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			reconstructed_MOR_ft,reconstructed_MOR = final_reconstructed_MOR_fts[0]
			
		
		
		
			left_isochron_ft, right_isochron_ft = create_left_and_right_div_fts_from_MOR_ft(reconstructed_MOR_ft, reconstructed_MOR, reconstruction_time, to_time_MOR)

def find_total_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,reconstruction_time,reference_frame):
	"""
	Total reconstruction is a reconstruction relative to the present (in time) and relative to any reference frame (spin axis or mantle or anything else)
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		# print('moving_plate_id')
		# print(moving_plate_id)
		# print('fixed_plate_id')
		# print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		#print("Euler_pole,angle_rads")
		#print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		#print("lat,lon,angle_degrees")
		#print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity in total_relative_reconstruction_rotation")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		#print("Euler_pole,angle_rads")
		#print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		#print("lat,lon,angle_degrees")
		#print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_stage_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,from_time,to_time,reference_frame):
	"""
	Relative stage reconstruction is a reconstruction from any from_time to any to_time between any two GDUIDS
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("from_time,to_time")
		print(from_time,to_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def create_isochron_from_temp_rift_point_features(temp_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday):
	dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	temp_isochron_from_MOR = pygplates.FeatureCollection()
	output_left_line_features = pygplates.FeatureCollection()
	output_right_line_features = pygplates.FeatureCollection()
	output_right_point_features = pygplates.FeatureCollection()
	output_left_point_features = pygplates.FeatureCollection()
	dic_of_new_kin_fts = {}
	dic_of_supergdu_and_gdu_members = {}
	dic_of_mor_interacts_bdn = {'reconstruction_time':[],'bdn_polylid':[],'rift_name':[],'rift_side':[]}
	dic_of_isochron_interacting_sgdu = {'reconstruction_time':[],'isochron_name':[],'isochron_gduid':[],'sgdu':[],'repgduid':[]}
	reconstructed_sgdu_features = []
	reconstructed_gdu_features = []
	reconstructed_div_features = []
	reconstructed_line_features = []
	reconstructed_rift_point_features = []
	#list_of_unwanted_rift_point_features = []
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (max_reconstruction_time_for_start_div is not None):
		selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] <= max_reconstruction_time_for_start_div]
	if (min_reconstruction_time_for_start_div is not None):
		new_selected_rift_history_df = None
		if (selected_rift_history_df is not None):
			new_selected_rift_history_df = selected_rift_history_df.loc[selected_rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		else:
			new_selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		if (new_selected_rift_history_df is not None):
			selected_rift_history_df = new_selected_rift_history_df
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		# div_line_names_for_left_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'lpolylid'].unique()
		# div_line_names_for_right_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'rpolylid'].unique()
		# array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'order'].to_numpy()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		descending_order_array = np.flip(sorted_array_of_start_div)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		#NEW
		start_div = descending_order_array[0]
		div_line_names_for_left_of_MOR = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'lpolylid'].unique()
		div_line_names_for_right_of_MOR = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'rpolylid'].unique()
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		list_of_wanted_rift_point_features = []
		for order in array_of_order_for_rift_points:
			name_of_rift_point_ft = rift_name+'_'+str(order)
			found_point_ft = None
			for rift_point_ft in temp_rift_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					found_point_ft = rift_point_ft
					break
			if (found_point_ft is None):
				print("Error could not find the wanted rift point feature")
				print("name_of_rift_point_ft",name_of_rift_point_ft)
				exit()
			list_of_wanted_rift_point_features.append(found_point_ft)
		reconstructed_rift_point_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_rift_point_features,start_div,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_rift_point_features,start_div,group_with_feature = True)
		final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features,pygplates.PointOnSphere)
		list_of_left_isochron_point_features = []
		list_of_right_isochron_point_features = []
		for rift_pt_ft,rift_pt in final_reconstructed_rift_point_fts:
			left_isochron_pt_ft, right_isochron_pt_ft = create_left_and_right_div_fts_from_MOR_ft(rift_pt_ft,rift_pt, start_div, 0.00)
			list_of_left_isochron_point_features.append(left_isochron_pt_ft)
			list_of_right_isochron_point_features.append(right_isochron_pt_ft)
			
		if (reference is not None):
			if (len(list_of_left_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_left_isochron_point_features,rotation_model,start_div,reference)
			if (len(list_of_right_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_right_isochron_point_features,rotation_model,start_div,reference)
		else:
			if (len(list_of_left_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_left_isochron_point_features,rotation_model,start_div)
			if (len(list_of_right_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_right_isochron_point_features,rotation_model,start_div)
		# list_of_valid_associated_div_line_feats = []
		# for line_ft in associated_div_line_features:
			# if (line_ft.is_valid_at_time(reconstruction_time)):
				# if (line_ft.get_name() in div_line_names_for_left_of_MOR):
					# list_of_valid_associated_div_line_feats.append(line_ft)
				# elif (line_ft.get_name() in div_line_names_for_right_of_MOR):
					# list_of_valid_associated_div_line_feats.append(line_ft)
		# list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in plate_boundary_zone_boundaries if con_ocn_line_ft.is_valid_at_time(start_div)]
		# final_reconstructed_div_features = None
		# if (len(list_of_valid_associated_div_line_feats) != 0.00):
			# reconstructed_div_features[:] = []
			# if (reference is not None):
				# pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# else:
				# pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,group_with_feature = True)
			# final_reconstructed_div_features = find_final_reconstructed_geometries(reconstructed_div_features,pygplates.PolylineOnSphere)

		reconstructed_left_point_features = []
		reconstructed_right_point_features = []
		list_of_tuples_for_descrp_reconstr_pts = []
		final_list_of_valid_rift_point_features = []
		reconstruction_time = start_div - time_interval
		list_of_valid_rift_point_features = [rift_point_ft for rift_point_ft in list_of_wanted_rift_point_features if rift_point_ft.is_valid_at_time(reconstruction_time)]
		while(reconstruction_time >= 0.00):
			final_reconstructed_rift_point_fts = None
			reconstructed_sgdu_features[:] = []
			reconstructed_gdu_features[:] = []
			list_of_valid_sgdu_fts = [sgdu_ft for sgdu_ft in sgdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_sgdu_fts,rotation_model,reconstructed_sgdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_sgdu_fts,rotation_model,reconstructed_sgdu_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_sgdu_fts = find_final_reconstructed_geometries(reconstructed_sgdu_features,pygplates.PolygonOnSphere)
			#list_of_valid_gdu_fts = [gdu_ft for gdu_ft in gdu_features if gdu_ft.is_valid_at_time(reconstruction_time)]
			#if (reference is not None):
			#	pygplates.reconstruct(list_of_valid_gdu_fts,rotation_model,reconstructed_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			#else:
			#	pygplates.reconstruct(list_of_valid_gdu_fts,rotation_model,reconstructed_gdu_features,reconstruction_time,group_with_feature = True)
			#final_reconstructed_gdu_fts = find_final_reconstructed_geometries(reconstructed_gdu_features,pygplates.PolygonOnSphere)
			remaining_tuples_rift_point_features = None
			
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temporary_sgdu_and_member_csv_at_time = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			temp_sgdu_and_gdu_df = pd.read_csv(temporary_sgdu_and_member_csv_at_time, delimiter = ';', header = 0)
			for valid_supergdu_ft in list_of_valid_sgdu_fts:
				sgdu_begin,_ = valid_supergdu_ft.get_valid_time()
				initial_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(sgdu_begin))
				#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
				initial_df = pd.read_csv(initial_sgdu_and_members_csv, delimiter = ';', header = 0)
				if (valid_supergdu_ft.get_name() not in dic_of_supergdu_and_gdu_members):
					unique_sgdus = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['repGDUID'] == valid_supergdu_ft.get_reconstruction_plate_id())|(temp_sgdu_and_gdu_df['GDUID'] == valid_supergdu_ft.get_reconstruction_plate_id()),'SGDUID'].unique()
					records_of_gdu_members = []
					for sgdu in unique_sgdus:
						temp_members = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['SGDUID'] == sgdu),'GDUID'].unique()
						for temp_mem in temp_members:
							if (temp_mem not in records_of_gdu_members):
								records_of_gdu_members.append(temp_mem)
					temp_members = initial_df.loc[(initial_df['SGDUID'] == int(valid_supergdu_ft.get_name())),'GDUID'].unique()
					for temp_mem in temp_members:
						if (temp_mem not in records_of_gdu_members):
							records_of_gdu_members.append(temp_mem)
					dic_of_supergdu_and_gdu_members[valid_supergdu_ft.get_name()] = records_of_gdu_members
			
			if (len(list_of_valid_rift_point_features) > 0):
				final_list_of_valid_rift_point_features[:] = []
				list_of_tuples_for_descrp_reconstr_pts[:] = []
				remaining_tuples_rift_point_features = []
				reconstructed_rift_point_features[:] = []
				
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
					#pygplates.reconstruct(final_list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,group_with_feature = True)
					#pygplates.reconstruct(final_list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features,pygplates.PointOnSphere)
				for reconstruct_rift_ft, reconstructed_rift_point in final_reconstructed_rift_point_fts:
					array_of_SGDUID_of_rift_ft_from_left = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstruct_rift_ft.get_left_plate(),'SGDUID'].unique()
					array_of_SGDUID_of_rift_ft_from_right = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstruct_rift_ft.get_left_plate(),'SGDUID'].unique()
					is_inside_sgdu = False
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
							is_inside_sgdu = True
							#checking whether GDU overlaps in the initial reconstruction model
							is_inside_left_gdu_polygon = None
							is_inside_right_gdu_polygon = None
							list_of_gdu_members_for_current_sgdu = dic_of_supergdu_and_gdu_members[reconstructed_sgdu_ft.get_name()]
							if (reconstruct_rift_ft.get_left_plate() in list_of_gdu_members_for_current_sgdu):
								is_inside_left_gdu_polygon = reconstructed_sgdu
								for tested_reconstructed_sgdu_ft, tested_reconstructed_sgdu in final_reconstructed_sgdu_fts:
									if (tested_reconstructed_sgdu_ft.get_name() != reconstructed_sgdu_ft.get_name()):
										if (tested_reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
											list_of_gdu_members_for_other_current_sgdu = dic_of_supergdu_and_gdu_members[tested_reconstructed_sgdu_ft.get_name()]
											if (reconstruct_rift_ft.get_right_plate() in list_of_gdu_members_for_other_current_sgdu):
												is_inside_right_gdu_polygon = tested_reconstructed_sgdu
									if (is_inside_right_gdu_polygon is not None and is_inside_left_gdu_polygon is not None):
										if (pygplates.GeometryOnSphere.distance(is_inside_left_gdu_polygon, is_inside_right_gdu_polygon) == 0.00):
											is_inside_sgdu = False
											break
							elif (reconstruct_rift_ft.get_right_plate() in list_of_gdu_members_for_current_sgdu):
								is_inside_right_gdu_polygon = reconstructed_sgdu
								for tested_reconstructed_sgdu_ft, tested_reconstructed_sgdu in final_reconstructed_sgdu_fts:
									if (tested_reconstructed_sgdu_ft.get_name() != reconstructed_sgdu_ft.get_name()):
										if (tested_reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
											list_of_gdu_members_for_other_current_sgdu = dic_of_supergdu_and_gdu_members[tested_reconstructed_sgdu_ft.get_name()]
											if (reconstruct_rift_ft.get_left_plate() in list_of_gdu_members_for_other_current_sgdu):
												is_inside_left_gdu_polygon = tested_reconstructed_sgdu
									if (is_inside_right_gdu_polygon is not None and is_inside_left_gdu_polygon is not None):
										if (pygplates.GeometryOnSphere.distance(is_inside_left_gdu_polygon, is_inside_right_gdu_polygon) == 0.00):
											is_inside_sgdu = False
											break
							break
					if (is_inside_sgdu == True):
						dic_of_invalid_rift_point_fts['reconstruction_time'].append(reconstruction_time)
						dic_of_invalid_rift_point_fts['rift_point_name'].append(reconstruct_rift_ft.get_name())
					else:
						#NEW 
						stage_relative_reconstruction_rotation = find_stage_relative_reconstruction_rotation_(rotation_model,reconstruct_rift_ft.get_left_plate(),reconstruct_rift_ft.get_right_plate(),float(reconstruction_time)+time_interval,float(reconstruction_time),reference)
						if (stage_relative_reconstruction_rotation.represents_identity_rotation() == True and reconstruction_time > 0):
							current_rift_begin_age, current_rift_end_age = reconstruct_rift_ft.get_valid_time()
							reconstruct_rift_ft.set_valid_time(current_rift_begin_age, reconstruction_time)
							dic_of_invalid_rift_point_fts['reconstruction_time'].append(reconstruction_time)
							dic_of_invalid_rift_point_fts['rift_point_name'].append(reconstruct_rift_ft.get_name())
						else:
							remaining_tuples_rift_point_features.append((reconstruct_rift_ft, reconstructed_rift_point))
				if (len(remaining_tuples_rift_point_features) > 0):
					list_of_remaining_rift_features,list_of_remaining_rift_points = list(zip(*remaining_tuples_rift_point_features))
					list_of_valid_rift_point_features = list_of_remaining_rift_features
				else:
					list_of_valid_rift_point_features = []
					
			reconstructed_line_features[:] = []
			list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in plate_boundary_zone_boundaries if con_ocn_line_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_line_fts = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			
			reconstructed_left_point_features[:] = []
			list_of_tuples_for_descrp_reconstr_pts[:] = []
			remaining_left_point_features = []
			if (len(list_of_left_isochron_point_features) > 0):
				list_of_valid_left_isochron_point_features = [left_ft for left_ft in list_of_left_isochron_point_features if left_ft.is_valid_at_time(reconstruction_time)]
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_left_isochron_point_features,rotation_model,reconstructed_left_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_left_isochron_point_features,rotation_model,reconstructed_left_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_left_point_fts = find_final_reconstructed_geometries(reconstructed_left_point_features,pygplates.PointOnSphere)
				for reconstruct_left_ft, reconstructed_left_point in final_reconstructed_left_point_fts:
					is_inside_sgdu = False
					list_of_tuples_for_descrp_reconstr_pts.append((float(reconstruct_left_ft.get_description()),reconstructed_left_point))
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_left_point) == True):
							is_inside_sgdu = True
							break
					if (is_inside_sgdu == True):
						current_begin_age,_ = reconstruct_left_ft.get_valid_time()
						reconstruct_left_ft.set_valid_time(current_begin_age, reconstruction_time)
						output_left_point_features.add(reconstruct_left_ft)
						#list_of_already_modified_features.add(reconstruct_left_ft.get_feature_id().get_string())
						#identify possible subduction zone
						#make sure to get the order of the point to create the line feature 
						#list_of_tuples_for_descrp_reconstr_pts.append((reconstruct_left_ft.get_description(),reconstructed_left_point))
					
						#NEW edit all left_point_ft
						# for temp_left_ft in remaining_left_point_features:
							# temp_current_begin_age,_ = temp_left_ft.get_valid_time()
							# if (temp_current_begin_age > reconstruction_time):
								# temp_left_ft.set_valid_time(temp_current_begin_age, reconstruction_time)
								# output_left_point_features.add(temp_left_ft)
						
						#dic_of_isochron_interacting_sgdu = {'reconstruction_time':[],'isochron_name':[],'isochron_gduid':[],'sgdu':[],'repgduid':[]}
						dic_of_isochron_interacting_sgdu['reconstruction_time'].append(reconstruction_time)
						dic_of_isochron_interacting_sgdu['isochron_name'].append(reconstruct_left_ft.get_name())
						dic_of_isochron_interacting_sgdu['isochron_gduid'].append(reconstruct_left_ft.get_reconstruction_plate_id())
						dic_of_isochron_interacting_sgdu['sgdu'].append(reconstructed_sgdu_ft.get_name())
						dic_of_isochron_interacting_sgdu['repgduid'].append(reconstructed_sgdu_ft.get_reconstruction_plate_id())
						
					else:
						remaining_left_point_features.append(reconstruct_left_ft)
					
			if (len(list_of_tuples_for_descrp_reconstr_pts) > 1 and len(list_of_valid_con_ocn_line_fts) > 0):
				list_of_tuples_for_descrp_reconstr_pts.sort()#based on the order or the small circle angular radius
				list_of_order_for_fts,list_of_left_pts = list(zip(*list_of_tuples_for_descrp_reconstr_pts))
				temporary_left_line = pygplates.PolylineOnSphere(list_of_left_pts)
				#find the plate boundary zone line feature crossing temporary left line --- Only need to check the orientation of the line if the line represent an MOR
				for unclassified_line_ft, unclassified_line in final_reconstructed_line_fts:
					if (pygplates.GeometryOnSphere.distance(unclassified_line, temporary_left_line) == 0.00):
						name_of_line_ft = unclassified_line_ft.get_name()
						if (name_of_line_ft in dic_of_new_kin_fts):
							dic_of_mor_interacts_bdn['reconstruction_time'].append(reconstruction_time)
							dic_of_mor_interacts_bdn['bdn_polylid'].append(name_of_line_ft)
							dic_of_mor_interacts_bdn['rift_name'].append(rift_name)
							dic_of_mor_interacts_bdn['rift_side'].append('L')
						else:
							#create subduction zone
							begin_age_line_ft_1,end_age_line_ft_1 = unclassified_line_ft.get_valid_time()
							if (end_age_line_ft_1 <= reconstruction_time):
								line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name = name_of_line_ft,valid_time = (reconstruction_time,end_age_line_ft_1))
								line_feature_1.set_reconstruction_plate_id(unclassified_line_ft.get_reconstruction_plate_id())
								line_feature_1.set_description('upper_gdu_margin')
								if (reference is None):
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time)
								else:
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time,reference)
								dic_of_new_kin_fts[name_of_line_ft] = line_feature_1
				
				# temp_left_line_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_isochron,temporary_left_line,name = rift_name,valid_time = (reconstruction_time,reconstruction_time-time_interval+0.100))
				# if (reference is not None):
					# temp_left_line_feature.set_reconstruction_plate_id(reference)
					# pygplates.reverse_reconstruct(temp_left_line_feature,rotation_model,reconstruction_time,reference)
				# else:
					# temp_left_line_feature.set_reconstruction_plate_id(0)
					# pygplates.reverse_reconstruct(temp_left_line_feature,rotation_model,reconstruction_time)
				# temp_left_line_feature.set_description('left_margin')
				# output_left_line_features.add(temp_left_line_feature)
			
			final_remained_left_pt_feats = []
			for remained_left_ft in remaining_left_point_features:
				if (remained_left_ft.is_valid_at_time(reconstruction_time-time_interval)):
					final_remained_left_pt_feats.append(remained_left_ft)
			list_of_left_isochron_point_features = final_remained_left_pt_feats
			
			list_of_tuples_for_descrp_reconstr_pts[:] = []
			remaining_right_point_features = []
			reconstructed_right_point_features[:] = []
			if (len(list_of_right_isochron_point_features) > 0):
				list_of_valid_right_isochron_point_features = [right_ft for right_ft in list_of_right_isochron_point_features if right_ft.is_valid_at_time(reconstruction_time)]
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_right_isochron_point_features,rotation_model,reconstructed_right_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_right_isochron_point_features,rotation_model,reconstructed_right_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_right_point_fts = find_final_reconstructed_geometries(reconstructed_right_point_features,pygplates.PointOnSphere)
				for reconstruct_right_ft, reconstructed_right_point in final_reconstructed_right_point_fts:
					is_inside_sgdu = False
					list_of_tuples_for_descrp_reconstr_pts.append((float(reconstruct_right_ft.get_description()),reconstructed_right_point))
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_right_point) == True):
							is_inside_sgdu = True
							break
					if (is_inside_sgdu == True):
						current_begin_age,_ = reconstruct_right_ft.get_valid_time()
						reconstruct_right_ft.set_valid_time(current_begin_age, reconstruction_time)
						output_right_point_features.add(reconstruct_right_ft)
						#list_of_already_modified_features.add(reconstruct_right_ft.get_feature_id().get_string())
						#identify possible subduction zone
						#make sure to get the order of the point to create the line feature 
						#list_of_tuples_for_descrp_reconstr_pts.append((reconstruct_right_ft.get_description(),reconstructed_right_point))
						
						#NEW edit all left_point_ft
						# for temp_right_ft in remaining_right_point_features:
							# temp_current_begin_age,_ = temp_right_ft.get_valid_time()
							# if (temp_current_begin_age > reconstruction_time):
								# temp_right_ft.set_valid_time(temp_current_begin_age, reconstruction_time)
								# output_right_point_features.add(temp_right_ft)
						
						dic_of_isochron_interacting_sgdu['reconstruction_time'].append(reconstruction_time)
						dic_of_isochron_interacting_sgdu['isochron_name'].append(reconstruct_right_ft.get_name())
						dic_of_isochron_interacting_sgdu['isochron_gduid'].append(reconstruct_right_ft.get_reconstruction_plate_id())
						dic_of_isochron_interacting_sgdu['sgdu'].append(reconstructed_sgdu_ft.get_name())
						dic_of_isochron_interacting_sgdu['repgduid'].append(reconstructed_sgdu_ft.get_reconstruction_plate_id())
						
					else:
						remaining_right_point_features.append(reconstruct_right_ft)
			if (len(list_of_tuples_for_descrp_reconstr_pts) > 1 and len(list_of_valid_con_ocn_line_fts) > 0):
				list_of_tuples_for_descrp_reconstr_pts.sort()#based on the order or the small circle angular radius
				list_of_order_for_fts,list_of_right_pts = list(zip(*list_of_tuples_for_descrp_reconstr_pts))
				temporary_right_line = pygplates.PolylineOnSphere(list_of_right_pts)
				#find the plate boundary zone line feature crossing temporary left line --- Only need to check the orientation of the line if the line represent an MOR
				for unclassified_line_ft, unclassified_line in final_reconstructed_line_fts:
					if (pygplates.GeometryOnSphere.distance(unclassified_line, temporary_right_line) == 0.00):
						name_of_line_ft = unclassified_line_ft.get_name()
						if (name_of_line_ft in dic_of_new_kin_fts):
							dic_of_mor_interacts_bdn['reconstruction_time'].append(reconstruction_time)
							dic_of_mor_interacts_bdn['bdn_polylid'].append(name_of_line_ft)
							dic_of_mor_interacts_bdn['rift_name'].append(rift_name)
							dic_of_mor_interacts_bdn['rift_side'].append('R')
						else:
							#create subduction zone
							begin_age_line_ft_1,end_age_line_ft_1 = unclassified_line_ft.get_valid_time()
							if (end_age_line_ft_1 <= reconstruction_time):
								line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name = name_of_line_ft,valid_time = (reconstruction_time,end_age_line_ft_1))
								line_feature_1.set_reconstruction_plate_id(unclassified_line_ft.get_reconstruction_plate_id())
								line_feature_1.set_description('upper_gdu_margin')
								if (reference is None):
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time)
								else:
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time,reference)
								dic_of_new_kin_fts[name_of_line_ft] = line_feature_1
				
				# temp_right_line_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_isochron,temporary_right_line,name = rift_name,valid_time = (reconstruction_time,reconstruction_time-time_interval+0.100))
				# if (reference is not None):
					# temp_right_line_feature.set_reconstruction_plate_id(reference)
					# pygplates.reverse_reconstruct(temp_right_line_feature,rotation_model,reconstruction_time,reference)
				# else:
					# temp_right_line_feature.set_reconstruction_plate_id(0)
					# pygplates.reverse_reconstruct(temp_right_line_feature,rotation_model,reconstruction_time)
				# temp_right_line_feature.set_description('right_margin')
				# output_right_line_features.add(temp_right_line_feature)
			
			#NEW
			final_remained_right_pt_feats = []
			for remained_right_ft in remaining_right_point_features:
				if (remained_right_ft.is_valid_at_time(reconstruction_time-time_interval)):
					final_remained_right_pt_feats.append(remained_right_ft)
			list_of_right_isochron_point_features = final_remained_right_pt_feats
			
			#create a new left and right isochron
			if (len(list_of_valid_rift_point_features) > 0 and remaining_tuples_rift_point_features is not None):
				if (len(remaining_tuples_rift_point_features) > 0):
					for rift_pt_ft,rift_pt in remaining_tuples_rift_point_features:
						left_isochron_pt_ft, right_isochron_pt_ft = create_left_and_right_div_fts_from_MOR_ft(rift_pt_ft, rift_pt, reconstruction_time, 0.00)
						if (reference is not None):
							pygplates.reverse_reconstruct(left_isochron_pt_ft,rotation_model,reconstruction_time,reference)
							pygplates.reverse_reconstruct(right_isochron_pt_ft,rotation_model,reconstruction_time,reference)
						else:
							pygplates.reverse_reconstruct(left_isochron_pt_ft,rotation_model,reconstruction_time)
							pygplates.reverse_reconstruct(right_isochron_pt_ft,rotation_model,reconstruction_time)
						list_of_left_isochron_point_features.append(left_isochron_pt_ft)
						list_of_right_isochron_point_features.append(right_isochron_pt_ft)
			reconstruction_time = reconstruction_time-time_interval
			if (reconstruction_time == 0.00):
				if (len(list_of_right_isochron_point_features) > 0):
					for right_point_ft in list_of_right_isochron_point_features:
						output_right_point_features.add(right_point_ft)
				if (len(list_of_left_isochron_point_features) > 0):
					for left_point_ft in list_of_left_isochron_point_features:
						output_left_point_features.add(left_point_ft)

	df_invalid_rift = pd.DataFrame.from_dict(dic_of_invalid_rift_point_fts)
	df_invalid_rift.to_csv('records_of_invalid_rift_'+modelname+'_'+yearmonthday+'.csv',index=False)
	
	df_mor_interacts_bdn = pd.DataFrame.from_dict(dic_of_mor_interacts_bdn)
	df_mor_interacts_bdn.to_csv('records_of_mor_interacts_bdn_'+modelname+'_'+yearmonthday+'.csv',index=False)

	df_isochron_interacts_sgdu = pd.DataFrame.from_dict(dic_of_isochron_interacting_sgdu)
	df_isochron_interacts_sgdu.to_csv('records_of_isochron_interacts_sgdu_'+modelname+'_'+yearmonthday+'.csv',index=False)
	
	output_new_kin_line_features = pygplates.FeatureCollection()
	for polylid_of_new_kin_line in dic_of_new_kin_fts:
		new_kin_line_ft = dic_of_new_kin_fts[polylid_of_new_kin_line]
		output_new_kin_line_features.add(new_kin_line_ft)
	output_new_kin_line_features.write('subduction_zone_features_'+modelname+'_'+yearmonthday+'.shp')
	
	#output_right_line_features.write('temp_right_line_features_'+modelname+'_'+yearmonthday+'.shp')
	#output_left_line_features.write('temp_left_line_features_'+modelname+'_'+yearmonthday+'.shp')
	output_right_point_features.write('isochron_right_point_features_'+modelname+'_'+yearmonthday+'.shp')
	output_left_point_features.write('isochron_left_point_features_'+modelname+'_'+yearmonthday+'.shp')

def create_isochron_from_temp_rift_point_features_from_conv_process(temp_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday):
	dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	temp_isochron_from_MOR = pygplates.FeatureCollection()
	output_left_line_features = pygplates.FeatureCollection()
	output_right_line_features = pygplates.FeatureCollection()
	output_right_point_features = pygplates.FeatureCollection()
	output_left_point_features = pygplates.FeatureCollection()
	dic_of_new_kin_fts = {}
	dic_of_supergdu_and_gdu_members = {}
	dic_of_mor_interacts_bdn = {'reconstruction_time':[],'bdn_polylid':[],'rift_name':[],'rift_side':[]}
	dic_of_isochron_interacting_sgdu = {'reconstruction_time':[],'isochron_name':[],'isochron_gduid':[],'sgdu':[],'repgduid':[]}
	reconstructed_sgdu_features = []
	reconstructed_gdu_features = []
	reconstructed_div_features = []
	reconstructed_line_features = []
	reconstructed_rift_point_features = []
	#list_of_unwanted_rift_point_features = []
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (max_reconstruction_time_for_start_div is not None):
		selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] <= max_reconstruction_time_for_start_div]
	if (min_reconstruction_time_for_start_div is not None):
		new_selected_rift_history_df = None
		if (selected_rift_history_df is not None):
			new_selected_rift_history_df = selected_rift_history_df.loc[selected_rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		else:
			new_selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		if (new_selected_rift_history_df is not None):
			selected_rift_history_df = new_selected_rift_history_df
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		# div_line_names_for_left_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'lpolylid'].unique()
		# div_line_names_for_right_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'rpolylid'].unique()
		# array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'order'].to_numpy()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		descending_order_array = np.flip(sorted_array_of_start_div)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		#NEW
		start_div = descending_order_array[0]
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		list_of_wanted_rift_point_features = []
		for order in array_of_order_for_rift_points:
			name_of_rift_point_ft = rift_name+'_'+str(order)
			found_point_ft = None
			for rift_point_ft in temp_rift_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					found_point_ft = rift_point_ft
					break
			if (found_point_ft is None):
				print("Error could not find the wanted rift point feature")
				print("name_of_rift_point_ft",name_of_rift_point_ft)
				exit()
			list_of_wanted_rift_point_features.append(found_point_ft)
		reconstructed_rift_point_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_rift_point_features,start_div,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_rift_point_features,start_div,group_with_feature = True)
		final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features,pygplates.PointOnSphere)
		list_of_left_isochron_point_features = []
		list_of_right_isochron_point_features = []
		for rift_pt_ft,rift_pt in final_reconstructed_rift_point_fts:
			left_isochron_pt_ft, right_isochron_pt_ft = create_left_and_right_div_fts_from_MOR_ft(rift_pt_ft,rift_pt, start_div, 0.00)
			list_of_left_isochron_point_features.append(left_isochron_pt_ft)
			list_of_right_isochron_point_features.append(right_isochron_pt_ft)
			
		if (reference is not None):
			if (len(list_of_left_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_left_isochron_point_features,rotation_model,start_div,reference)
			if (len(list_of_right_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_right_isochron_point_features,rotation_model,start_div,reference)
		else:
			if (len(list_of_left_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_left_isochron_point_features,rotation_model,start_div)
			if (len(list_of_right_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_right_isochron_point_features,rotation_model,start_div)
		# list_of_valid_associated_div_line_feats = []
		# for line_ft in associated_div_line_features:
			# if (line_ft.is_valid_at_time(reconstruction_time)):
				# if (line_ft.get_name() in div_line_names_for_left_of_MOR):
					# list_of_valid_associated_div_line_feats.append(line_ft)
				# elif (line_ft.get_name() in div_line_names_for_right_of_MOR):
					# list_of_valid_associated_div_line_feats.append(line_ft)
		# list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in plate_boundary_zone_boundaries if con_ocn_line_ft.is_valid_at_time(start_div)]
		# final_reconstructed_div_features = None
		# if (len(list_of_valid_associated_div_line_feats) != 0.00):
			# reconstructed_div_features[:] = []
			# if (reference is not None):
				# pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# else:
				# pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,group_with_feature = True)
			# final_reconstructed_div_features = find_final_reconstructed_geometries(reconstructed_div_features,pygplates.PolylineOnSphere)

		reconstructed_left_point_features = []
		reconstructed_right_point_features = []
		list_of_tuples_for_descrp_reconstr_pts = []
		final_list_of_valid_rift_point_features = []
		reconstruction_time = start_div - time_interval
		list_of_valid_rift_point_features = [rift_point_ft for rift_point_ft in list_of_wanted_rift_point_features if rift_point_ft.is_valid_at_time(reconstruction_time)]
		while(reconstruction_time >= 0.00):
			final_reconstructed_rift_point_fts = None
			reconstructed_sgdu_features[:] = []
			reconstructed_gdu_features[:] = []
			list_of_valid_sgdu_fts = [sgdu_ft for sgdu_ft in sgdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_sgdu_fts,rotation_model,reconstructed_sgdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_sgdu_fts,rotation_model,reconstructed_sgdu_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_sgdu_fts = find_final_reconstructed_geometries(reconstructed_sgdu_features,pygplates.PolygonOnSphere)
			#list_of_valid_gdu_fts = [gdu_ft for gdu_ft in gdu_features if gdu_ft.is_valid_at_time(reconstruction_time)]
			#if (reference is not None):
			#	pygplates.reconstruct(list_of_valid_gdu_fts,rotation_model,reconstructed_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			#else:
			#	pygplates.reconstruct(list_of_valid_gdu_fts,rotation_model,reconstructed_gdu_features,reconstruction_time,group_with_feature = True)
			#final_reconstructed_gdu_fts = find_final_reconstructed_geometries(reconstructed_gdu_features,pygplates.PolygonOnSphere)
			remaining_tuples_rift_point_features = None
			
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temporary_sgdu_and_member_csv_at_time = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			temp_sgdu_and_gdu_df = pd.read_csv(temporary_sgdu_and_member_csv_at_time, delimiter = ';', header = 0)
			for valid_supergdu_ft in list_of_valid_sgdu_fts:
				sgdu_begin,_ = valid_supergdu_ft.get_valid_time()
				initial_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(sgdu_begin))
				#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
				initial_df = pd.read_csv(initial_sgdu_and_members_csv, delimiter = ';', header = 0)
				if (valid_supergdu_ft.get_name() not in dic_of_supergdu_and_gdu_members):
					unique_sgdus = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['repGDUID'] == valid_supergdu_ft.get_reconstruction_plate_id())|(temp_sgdu_and_gdu_df['GDUID'] == valid_supergdu_ft.get_reconstruction_plate_id()),'SGDUID'].unique()
					records_of_gdu_members = []
					for sgdu in unique_sgdus:
						temp_members = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['SGDUID'] == sgdu),'GDUID'].unique()
						for temp_mem in temp_members:
							if (temp_mem not in records_of_gdu_members):
								records_of_gdu_members.append(temp_mem)
					temp_members = initial_df.loc[(initial_df['SGDUID'] == int(valid_supergdu_ft.get_name())),'GDUID'].unique()
					for temp_mem in temp_members:
						if (temp_mem not in records_of_gdu_members):
							records_of_gdu_members.append(temp_mem)
					dic_of_supergdu_and_gdu_members[valid_supergdu_ft.get_name()] = records_of_gdu_members
			
			if (len(list_of_valid_rift_point_features) > 0):
				final_list_of_valid_rift_point_features[:] = []
				list_of_tuples_for_descrp_reconstr_pts[:] = []
				remaining_tuples_rift_point_features = []
				reconstructed_rift_point_features[:] = []
				
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
					#pygplates.reconstruct(final_list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,group_with_feature = True)
					#pygplates.reconstruct(final_list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features,pygplates.PointOnSphere)
				for reconstruct_rift_ft, reconstructed_rift_point in final_reconstructed_rift_point_fts:
					array_of_SGDUID_of_rift_ft_from_left = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstruct_rift_ft.get_left_plate(),'SGDUID'].unique()
					array_of_SGDUID_of_rift_ft_from_right = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstruct_rift_ft.get_left_plate(),'SGDUID'].unique()
					is_inside_sgdu = False
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
							is_inside_sgdu = True
							#checking whether GDU overlaps in the initial reconstruction model
							is_inside_left_gdu_polygon = None
							is_inside_right_gdu_polygon = None
							list_of_gdu_members_for_current_sgdu = dic_of_supergdu_and_gdu_members[reconstructed_sgdu_ft.get_name()]
							if (reconstruct_rift_ft.get_left_plate() in list_of_gdu_members_for_current_sgdu):
								is_inside_left_gdu_polygon = reconstructed_sgdu
								for tested_reconstructed_sgdu_ft, tested_reconstructed_sgdu in final_reconstructed_sgdu_fts:
									if (tested_reconstructed_sgdu_ft.get_name() != reconstructed_sgdu_ft.get_name()):
										if (tested_reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
											list_of_gdu_members_for_other_current_sgdu = dic_of_supergdu_and_gdu_members[tested_reconstructed_sgdu_ft.get_name()]
											if (reconstruct_rift_ft.get_right_plate() in list_of_gdu_members_for_other_current_sgdu):
												is_inside_right_gdu_polygon = tested_reconstructed_sgdu
									if (is_inside_right_gdu_polygon is not None and is_inside_left_gdu_polygon is not None):
										if (pygplates.GeometryOnSphere.distance(is_inside_left_gdu_polygon, is_inside_right_gdu_polygon) == 0.00):
											is_inside_sgdu = False
											break
							elif (reconstruct_rift_ft.get_right_plate() in list_of_gdu_members_for_current_sgdu):
								is_inside_right_gdu_polygon = reconstructed_sgdu
								for tested_reconstructed_sgdu_ft, tested_reconstructed_sgdu in final_reconstructed_sgdu_fts:
									if (tested_reconstructed_sgdu_ft.get_name() != reconstructed_sgdu_ft.get_name()):
										if (tested_reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
											list_of_gdu_members_for_other_current_sgdu = dic_of_supergdu_and_gdu_members[tested_reconstructed_sgdu_ft.get_name()]
											if (reconstruct_rift_ft.get_left_plate() in list_of_gdu_members_for_other_current_sgdu):
												is_inside_left_gdu_polygon = tested_reconstructed_sgdu
									if (is_inside_right_gdu_polygon is not None and is_inside_left_gdu_polygon is not None):
										if (pygplates.GeometryOnSphere.distance(is_inside_left_gdu_polygon, is_inside_right_gdu_polygon) == 0.00):
											is_inside_sgdu = False
											break
							break
					if (is_inside_sgdu == True):
						dic_of_invalid_rift_point_fts['reconstruction_time'].append(reconstruction_time)
						dic_of_invalid_rift_point_fts['rift_point_name'].append(reconstruct_rift_ft.get_name())
					else:
						#NEW 
						stage_relative_reconstruction_rotation = find_stage_relative_reconstruction_rotation_(rotation_model,reconstruct_rift_ft.get_left_plate(),reconstruct_rift_ft.get_right_plate(),float(reconstruction_time)+time_interval,float(reconstruction_time),reference)
						if (stage_relative_reconstruction_rotation.represents_identity_rotation() == True and reconstruction_time > 0):
							current_rift_begin_age, current_rift_end_age = reconstruct_rift_ft.get_valid_time()
							reconstruct_rift_ft.set_valid_time(current_rift_begin_age, reconstruction_time)
							dic_of_invalid_rift_point_fts['reconstruction_time'].append(reconstruction_time)
							dic_of_invalid_rift_point_fts['rift_point_name'].append(reconstruct_rift_ft.get_name())
						else:
							remaining_tuples_rift_point_features.append((reconstruct_rift_ft, reconstructed_rift_point))
				if (len(remaining_tuples_rift_point_features) > 0):
					list_of_remaining_rift_features,list_of_remaining_rift_points = list(zip(*remaining_tuples_rift_point_features))
					list_of_valid_rift_point_features = list_of_remaining_rift_features
				else:
					list_of_valid_rift_point_features = []
					
			reconstructed_line_features[:] = []
			list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in plate_boundary_zone_boundaries if con_ocn_line_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_line_fts = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			
			reconstructed_left_point_features[:] = []
			list_of_tuples_for_descrp_reconstr_pts[:] = []
			remaining_left_point_features = []
			if (len(list_of_left_isochron_point_features) > 0):
				list_of_valid_left_isochron_point_features = [left_ft for left_ft in list_of_left_isochron_point_features if left_ft.is_valid_at_time(reconstruction_time)]
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_left_isochron_point_features,rotation_model,reconstructed_left_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_left_isochron_point_features,rotation_model,reconstructed_left_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_left_point_fts = find_final_reconstructed_geometries(reconstructed_left_point_features,pygplates.PointOnSphere)
				for reconstruct_left_ft, reconstructed_left_point in final_reconstructed_left_point_fts:
					is_inside_sgdu = False
					list_of_tuples_for_descrp_reconstr_pts.append((float(reconstruct_left_ft.get_description()),reconstructed_left_point))
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_left_point) == True):
							is_inside_sgdu = True
							break
					if (is_inside_sgdu == True):
						current_begin_age,_ = reconstruct_left_ft.get_valid_time()
						reconstruct_left_ft.set_valid_time(current_begin_age, reconstruction_time)
						output_left_point_features.add(reconstruct_left_ft)
						#list_of_already_modified_features.add(reconstruct_left_ft.get_feature_id().get_string())
						#identify possible subduction zone
						#make sure to get the order of the point to create the line feature 
						#list_of_tuples_for_descrp_reconstr_pts.append((reconstruct_left_ft.get_description(),reconstructed_left_point))
					
						#NEW edit all left_point_ft
						# for temp_left_ft in remaining_left_point_features:
							# temp_current_begin_age,temp_current_end_age = temp_left_ft.get_valid_time()
							# if (temp_current_begin_age > reconstruction_time and temp_current_end_age < reconstruction_time):
								# temp_left_ft.set_valid_time(temp_current_begin_age, reconstruction_time)
								# output_left_point_features.add(temp_left_ft)
						
						#dic_of_isochron_interacting_sgdu = {'reconstruction_time':[],'isochron_name':[],'isochron_gduid':[],'sgdu':[],'repgduid':[]}
						dic_of_isochron_interacting_sgdu['reconstruction_time'].append(reconstruction_time)
						dic_of_isochron_interacting_sgdu['isochron_name'].append(reconstruct_left_ft.get_name())
						dic_of_isochron_interacting_sgdu['isochron_gduid'].append(reconstruct_left_ft.get_reconstruction_plate_id())
						dic_of_isochron_interacting_sgdu['sgdu'].append(reconstructed_sgdu_ft.get_name())
						dic_of_isochron_interacting_sgdu['repgduid'].append(reconstructed_sgdu_ft.get_reconstruction_plate_id())
						
					else:
						remaining_left_point_features.append(reconstruct_left_ft)
					
			if (len(list_of_tuples_for_descrp_reconstr_pts) > 1 and len(list_of_valid_con_ocn_line_fts) > 0):
				list_of_tuples_for_descrp_reconstr_pts.sort()#based on the order or the small circle angular radius
				list_of_order_for_fts,list_of_left_pts = list(zip(*list_of_tuples_for_descrp_reconstr_pts))
				temporary_left_line = pygplates.PolylineOnSphere(list_of_left_pts)
				#find the plate boundary zone line feature crossing temporary left line --- Only need to check the orientation of the line if the line represent an MOR
				for unclassified_line_ft, unclassified_line in final_reconstructed_line_fts:
					if (pygplates.GeometryOnSphere.distance(unclassified_line, temporary_left_line) == 0.00):
						name_of_line_ft = unclassified_line_ft.get_name()
						if (name_of_line_ft in dic_of_new_kin_fts):
							dic_of_mor_interacts_bdn['reconstruction_time'].append(reconstruction_time)
							dic_of_mor_interacts_bdn['bdn_polylid'].append(name_of_line_ft)
							dic_of_mor_interacts_bdn['rift_name'].append(rift_name)
							dic_of_mor_interacts_bdn['rift_side'].append('L')
						else:
							#create subduction zone
							begin_age_line_ft_1,end_age_line_ft_1 = unclassified_line_ft.get_valid_time()
							if (end_age_line_ft_1 <= reconstruction_time):
								line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name = name_of_line_ft,valid_time = (reconstruction_time,end_age_line_ft_1))
								line_feature_1.set_reconstruction_plate_id(unclassified_line_ft.get_reconstruction_plate_id())
								line_feature_1.set_description('upper_gdu_margin')
								if (reference is None):
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time)
								else:
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time,reference)
								dic_of_new_kin_fts[name_of_line_ft] = line_feature_1
				
				# temp_left_line_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_isochron,temporary_left_line,name = rift_name,valid_time = (reconstruction_time,reconstruction_time-time_interval+0.100))
				# if (reference is not None):
					# temp_left_line_feature.set_reconstruction_plate_id(reference)
					# pygplates.reverse_reconstruct(temp_left_line_feature,rotation_model,reconstruction_time,reference)
				# else:
					# temp_left_line_feature.set_reconstruction_plate_id(0)
					# pygplates.reverse_reconstruct(temp_left_line_feature,rotation_model,reconstruction_time)
				# temp_left_line_feature.set_description('left_margin')
				# output_left_line_features.add(temp_left_line_feature)
			
			#NEW
			# final_remained_left_pt_feats = []
			# for remained_left_ft in remaining_left_point_features:
				# if (remained_left_ft.is_valid_at_time(reconstruction_time-time_interval)):
					# final_remained_left_pt_feats.append(remained_left_ft)
			# list_of_left_isochron_point_features = final_remained_left_pt_feats
			
			list_of_left_isochron_point_features = remaining_left_point_features
			
			list_of_tuples_for_descrp_reconstr_pts[:] = []
			remaining_right_point_features = []
			reconstructed_right_point_features[:] = []
			if (len(list_of_right_isochron_point_features) > 0):
				list_of_valid_right_isochron_point_features = [right_ft for right_ft in list_of_right_isochron_point_features if right_ft.is_valid_at_time(reconstruction_time)]
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_right_isochron_point_features,rotation_model,reconstructed_right_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_right_isochron_point_features,rotation_model,reconstructed_right_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_right_point_fts = find_final_reconstructed_geometries(reconstructed_right_point_features,pygplates.PointOnSphere)
				for reconstruct_right_ft, reconstructed_right_point in final_reconstructed_right_point_fts:
					is_inside_sgdu = False
					list_of_tuples_for_descrp_reconstr_pts.append((float(reconstruct_right_ft.get_description()),reconstructed_right_point))
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_right_point) == True):
							is_inside_sgdu = True
							break
					if (is_inside_sgdu == True):
						current_begin_age,_ = reconstruct_right_ft.get_valid_time()
						reconstruct_right_ft.set_valid_time(current_begin_age, reconstruction_time)
						output_right_point_features.add(reconstruct_right_ft)
						#list_of_already_modified_features.add(reconstruct_right_ft.get_feature_id().get_string())
						#identify possible subduction zone
						#make sure to get the order of the point to create the line feature 
						#list_of_tuples_for_descrp_reconstr_pts.append((reconstruct_right_ft.get_description(),reconstructed_right_point))
						
						#NEW edit all left_point_ft
						# for temp_right_ft in remaining_right_point_features:
							# temp_current_begin_age, temp_current_end_age = temp_right_ft.get_valid_time()
							# if (temp_current_begin_age > reconstruction_time and temp_current_end_age < reconstruction_time):
								# temp_right_ft.set_valid_time(temp_current_begin_age, reconstruction_time)
								# output_right_point_features.add(temp_right_ft)
						
						dic_of_isochron_interacting_sgdu['reconstruction_time'].append(reconstruction_time)
						dic_of_isochron_interacting_sgdu['isochron_name'].append(reconstruct_right_ft.get_name())
						dic_of_isochron_interacting_sgdu['isochron_gduid'].append(reconstruct_right_ft.get_reconstruction_plate_id())
						dic_of_isochron_interacting_sgdu['sgdu'].append(reconstructed_sgdu_ft.get_name())
						dic_of_isochron_interacting_sgdu['repgduid'].append(reconstructed_sgdu_ft.get_reconstruction_plate_id())
						
					else:
						remaining_right_point_features.append(reconstruct_right_ft)
			if (len(list_of_tuples_for_descrp_reconstr_pts) > 1 and len(list_of_valid_con_ocn_line_fts) > 0):
				list_of_tuples_for_descrp_reconstr_pts.sort()#based on the order or the small circle angular radius
				list_of_order_for_fts,list_of_right_pts = list(zip(*list_of_tuples_for_descrp_reconstr_pts))
				temporary_right_line = pygplates.PolylineOnSphere(list_of_right_pts)
				#find the plate boundary zone line feature crossing temporary left line --- Only need to check the orientation of the line if the line represent an MOR
				for unclassified_line_ft, unclassified_line in final_reconstructed_line_fts:
					if (pygplates.GeometryOnSphere.distance(unclassified_line, temporary_right_line) == 0.00):
						name_of_line_ft = unclassified_line_ft.get_name()
						if (name_of_line_ft in dic_of_new_kin_fts):
							dic_of_mor_interacts_bdn['reconstruction_time'].append(reconstruction_time)
							dic_of_mor_interacts_bdn['bdn_polylid'].append(name_of_line_ft)
							dic_of_mor_interacts_bdn['rift_name'].append(rift_name)
							dic_of_mor_interacts_bdn['rift_side'].append('R')
						else:
							#create subduction zone
							begin_age_line_ft_1,end_age_line_ft_1 = unclassified_line_ft.get_valid_time()
							if (end_age_line_ft_1 <= reconstruction_time):
								line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name = name_of_line_ft,valid_time = (reconstruction_time,end_age_line_ft_1))
								line_feature_1.set_reconstruction_plate_id(unclassified_line_ft.get_reconstruction_plate_id())
								line_feature_1.set_description('upper_gdu_margin')
								if (reference is None):
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time)
								else:
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time,reference)
								dic_of_new_kin_fts[name_of_line_ft] = line_feature_1
				
				# temp_right_line_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_isochron,temporary_right_line,name = rift_name,valid_time = (reconstruction_time,reconstruction_time-time_interval+0.100))
				# if (reference is not None):
					# temp_right_line_feature.set_reconstruction_plate_id(reference)
					# pygplates.reverse_reconstruct(temp_right_line_feature,rotation_model,reconstruction_time,reference)
				# else:
					# temp_right_line_feature.set_reconstruction_plate_id(0)
					# pygplates.reverse_reconstruct(temp_right_line_feature,rotation_model,reconstruction_time)
				# temp_right_line_feature.set_description('right_margin')
				# output_right_line_features.add(temp_right_line_feature)
			#NEW
			# final_remained_right_pt_feats = []
			# for remained_right_ft in remaining_right_point_features:
				# if (remained_right_ft.is_valid_at_time(reconstruction_time-time_interval)):
					# final_remained_right_pt_feats.append(remained_right_ft)
			# list_of_right_isochron_point_features = final_remained_right_pt_feats
			
			list_of_right_isochron_point_features = remaining_right_point_features
			
			#create a new left and right isochron
			if (len(list_of_valid_rift_point_features) > 0 and remaining_tuples_rift_point_features is not None):
				if (len(remaining_tuples_rift_point_features) > 0):
					for rift_pt_ft,rift_pt in remaining_tuples_rift_point_features:
						left_isochron_pt_ft, right_isochron_pt_ft = create_left_and_right_div_fts_from_MOR_ft(rift_pt_ft, rift_pt, reconstruction_time, 0.00)
						if (reference is not None):
							pygplates.reverse_reconstruct(left_isochron_pt_ft,rotation_model,reconstruction_time,reference)
							pygplates.reverse_reconstruct(right_isochron_pt_ft,rotation_model,reconstruction_time,reference)
						else:
							pygplates.reverse_reconstruct(left_isochron_pt_ft,rotation_model,reconstruction_time)
							pygplates.reverse_reconstruct(right_isochron_pt_ft,rotation_model,reconstruction_time)
						list_of_left_isochron_point_features.append(left_isochron_pt_ft)
						list_of_right_isochron_point_features.append(right_isochron_pt_ft)
			reconstruction_time = reconstruction_time-time_interval
			if (reconstruction_time == 0.00):
				if (len(list_of_right_isochron_point_features) > 0):
					for right_point_ft in list_of_right_isochron_point_features:
						output_right_point_features.add(right_point_ft)
				if (len(list_of_left_isochron_point_features) > 0):
					for left_point_ft in list_of_left_isochron_point_features:
						output_left_point_features.add(left_point_ft)

	df_invalid_rift = pd.DataFrame.from_dict(dic_of_invalid_rift_point_fts)
	df_invalid_rift.to_csv('records_of_invalid_rift_'+modelname+'_'+yearmonthday+'.csv',index=False)
	
	df_mor_interacts_bdn = pd.DataFrame.from_dict(dic_of_mor_interacts_bdn)
	df_mor_interacts_bdn.to_csv('records_of_mor_interacts_bdn_'+modelname+'_'+yearmonthday+'.csv',index=False)

	df_isochron_interacts_sgdu = pd.DataFrame.from_dict(dic_of_isochron_interacting_sgdu)
	df_isochron_interacts_sgdu.to_csv('records_of_isochron_interacts_sgdu_'+modelname+'_'+yearmonthday+'.csv',index=False)
	
	output_new_kin_line_features = pygplates.FeatureCollection()
	for polylid_of_new_kin_line in dic_of_new_kin_fts:
		new_kin_line_ft = dic_of_new_kin_fts[polylid_of_new_kin_line]
		output_new_kin_line_features.add(new_kin_line_ft)
	output_new_kin_line_features.write('subduction_zone_features_'+modelname+'_'+yearmonthday+'.shp')
	
	#output_right_line_features.write('temp_right_line_features_'+modelname+'_'+yearmonthday+'.shp')
	#output_left_line_features.write('temp_left_line_features_'+modelname+'_'+yearmonthday+'.shp')
	output_right_point_features.write('isochron_right_point_features_'+modelname+'_'+yearmonthday+'.shp')
	output_left_point_features.write('isochron_left_point_features_'+modelname+'_'+yearmonthday+'.shp')

def create_isochron_from_temp_rift_point_features_for_oceanic_crust(temp_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday):
	dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[],'order':[]}
	temp_isochron_from_MOR = pygplates.FeatureCollection()
	output_left_line_features = pygplates.FeatureCollection()
	output_right_line_features = pygplates.FeatureCollection()
	output_right_point_features = pygplates.FeatureCollection()
	output_left_point_features = pygplates.FeatureCollection()
	dic_of_new_kin_fts = {}
	dic_of_supergdu_and_gdu_members = {}
	dic_of_mor_interacts_bdn = {'reconstruction_time':[],'bdn_polylid':[],'rift_name':[],'rift_side':[]}
	dic_of_isochron_interacting_sgdu = {'reconstruction_time':[],'isochron_name':[],'isochron_gduid':[],'sgdu':[],'repgduid':[]}
	reconstructed_sgdu_features = []
	reconstructed_gdu_features = []
	reconstructed_div_features = []
	reconstructed_line_features = []
	reconstructed_rift_point_features = []
	#list_of_unwanted_rift_point_features = []
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (max_reconstruction_time_for_start_div is not None):
		selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] <= max_reconstruction_time_for_start_div]
	if (min_reconstruction_time_for_start_div is not None):
		new_selected_rift_history_df = None
		if (selected_rift_history_df is not None):
			new_selected_rift_history_df = selected_rift_history_df.loc[selected_rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		else:
			new_selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		if (new_selected_rift_history_df is not None):
			selected_rift_history_df = new_selected_rift_history_df
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		# div_line_names_for_left_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'lpolylid'].unique()
		# div_line_names_for_right_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'rpolylid'].unique()
		# array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'order'].to_numpy()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		descending_order_array = np.flip(sorted_array_of_start_div)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		#NEW
		start_div = descending_order_array[0]
		div_line_names_for_left_of_MOR = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'lpolylid'].unique()
		div_line_names_for_right_of_MOR = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'rpolylid'].unique()
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].unique()
		list_of_wanted_rift_point_features = []
		for order in array_of_order_for_rift_points:
			#name_of_rift_point_ft = rift_name+'_'+str(order)
			found_point_ft = None
			for rift_point_ft in temp_rift_point_features:
				if (rift_point_ft.get_name() == rift_name and rift_point_ft.get_description() == str(order)):
					found_point_ft = rift_point_ft
					break
			if (found_point_ft is None):
				print("Error could not find the wanted rift point feature")
				print("name_of_rift_point_ft",rift_name,order)
				exit()
			list_of_wanted_rift_point_features.append(found_point_ft)
		reconstructed_rift_point_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_rift_point_features,start_div,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_rift_point_features,start_div,group_with_feature = True)
		final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features,pygplates.PointOnSphere)
		list_of_left_isochron_point_features = []
		list_of_right_isochron_point_features = []
		for rift_pt_ft,rift_pt in final_reconstructed_rift_point_fts:
			left_isochron_pt_ft, right_isochron_pt_ft = create_left_and_right_div_fts_from_MOR_ft(rift_pt_ft,rift_pt, start_div, 0.00)
			list_of_left_isochron_point_features.append(left_isochron_pt_ft)
			list_of_right_isochron_point_features.append(right_isochron_pt_ft)
			
		if (reference is not None):
			if (len(list_of_left_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_left_isochron_point_features,rotation_model,start_div,reference)
			if (len(list_of_right_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_right_isochron_point_features,rotation_model,start_div,reference)
		else:
			if (len(list_of_left_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_left_isochron_point_features,rotation_model,start_div)
			if (len(list_of_right_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_right_isochron_point_features,rotation_model,start_div)
		# list_of_valid_associated_div_line_feats = []
		# for line_ft in associated_div_line_features:
			# if (line_ft.is_valid_at_time(reconstruction_time)):
				# if (line_ft.get_name() in div_line_names_for_left_of_MOR):
					# list_of_valid_associated_div_line_feats.append(line_ft)
				# elif (line_ft.get_name() in div_line_names_for_right_of_MOR):
					# list_of_valid_associated_div_line_feats.append(line_ft)
		# list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in plate_boundary_zone_boundaries if con_ocn_line_ft.is_valid_at_time(start_div)]
		# final_reconstructed_div_features = None
		# if (len(list_of_valid_associated_div_line_feats) != 0.00):
			# reconstructed_div_features[:] = []
			# if (reference is not None):
				# pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# else:
				# pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,group_with_feature = True)
			# final_reconstructed_div_features = find_final_reconstructed_geometries(reconstructed_div_features,pygplates.PolylineOnSphere)

		reconstructed_left_point_features = []
		reconstructed_right_point_features = []
		list_of_tuples_for_descrp_reconstr_pts = []
		final_list_of_valid_rift_point_features = []
		reconstruction_time = start_div - time_interval
		list_of_valid_rift_point_features = [rift_point_ft for rift_point_ft in list_of_wanted_rift_point_features if rift_point_ft.is_valid_at_time(reconstruction_time)]
		while(reconstruction_time >= 0.00):
			final_reconstructed_rift_point_fts = None
			reconstructed_sgdu_features[:] = []
			reconstructed_gdu_features[:] = []
			list_of_valid_sgdu_fts = [sgdu_ft for sgdu_ft in sgdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_sgdu_fts,rotation_model,reconstructed_sgdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_sgdu_fts,rotation_model,reconstructed_sgdu_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_sgdu_fts = find_final_reconstructed_geometries(reconstructed_sgdu_features,pygplates.PolygonOnSphere)
			#list_of_valid_gdu_fts = [gdu_ft for gdu_ft in gdu_features if gdu_ft.is_valid_at_time(reconstruction_time)]
			#if (reference is not None):
			#	pygplates.reconstruct(list_of_valid_gdu_fts,rotation_model,reconstructed_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			#else:
			#	pygplates.reconstruct(list_of_valid_gdu_fts,rotation_model,reconstructed_gdu_features,reconstruction_time,group_with_feature = True)
			#final_reconstructed_gdu_fts = find_final_reconstructed_geometries(reconstructed_gdu_features,pygplates.PolygonOnSphere)
			remaining_tuples_rift_point_features = None
			
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temporary_sgdu_and_member_csv_at_time = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			temp_sgdu_and_gdu_df = pd.read_csv(temporary_sgdu_and_member_csv_at_time, delimiter = ';', header = 0)
			for valid_supergdu_ft in list_of_valid_sgdu_fts:
				sgdu_begin,_ = valid_supergdu_ft.get_valid_time()
				initial_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(sgdu_begin))
				#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
				initial_df = pd.read_csv(initial_sgdu_and_members_csv, delimiter = ';', header = 0)
				if (valid_supergdu_ft.get_name() not in dic_of_supergdu_and_gdu_members):
					unique_sgdus = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['repGDUID'] == valid_supergdu_ft.get_reconstruction_plate_id())|(temp_sgdu_and_gdu_df['GDUID'] == valid_supergdu_ft.get_reconstruction_plate_id()),'SGDUID'].unique()
					records_of_gdu_members = []
					for sgdu in unique_sgdus:
						temp_members = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['SGDUID'] == sgdu),'GDUID'].unique()
						for temp_mem in temp_members:
							if (temp_mem not in records_of_gdu_members):
								records_of_gdu_members.append(temp_mem)
					temp_members = initial_df.loc[(initial_df['SGDUID'] == int(valid_supergdu_ft.get_name())),'GDUID'].unique()
					for temp_mem in temp_members:
						if (temp_mem not in records_of_gdu_members):
							records_of_gdu_members.append(temp_mem)
					dic_of_supergdu_and_gdu_members[valid_supergdu_ft.get_name()] = records_of_gdu_members
			
			if (len(list_of_valid_rift_point_features) > 0):
				final_list_of_valid_rift_point_features[:] = []
				list_of_tuples_for_descrp_reconstr_pts[:] = []
				remaining_tuples_rift_point_features = []
				reconstructed_rift_point_features[:] = []
				
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
					#pygplates.reconstruct(final_list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,group_with_feature = True)
					#pygplates.reconstruct(final_list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features,pygplates.PointOnSphere)
				for reconstruct_rift_ft, reconstructed_rift_point in final_reconstructed_rift_point_fts:
					array_of_SGDUID_of_rift_ft_from_left = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstruct_rift_ft.get_left_plate(),'SGDUID'].unique()
					array_of_SGDUID_of_rift_ft_from_right = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstruct_rift_ft.get_left_plate(),'SGDUID'].unique()
					is_inside_sgdu = False
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
							is_inside_sgdu = True
							#checking whether GDU overlaps in the initial reconstruction model
							is_inside_left_gdu_polygon = None
							is_inside_right_gdu_polygon = None
							list_of_gdu_members_for_current_sgdu = dic_of_supergdu_and_gdu_members[reconstructed_sgdu_ft.get_name()]
							if (reconstruct_rift_ft.get_left_plate() in list_of_gdu_members_for_current_sgdu):
								is_inside_left_gdu_polygon = reconstructed_sgdu
								for tested_reconstructed_sgdu_ft, tested_reconstructed_sgdu in final_reconstructed_sgdu_fts:
									if (tested_reconstructed_sgdu_ft.get_name() != reconstructed_sgdu_ft.get_name()):
										if (tested_reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
											list_of_gdu_members_for_other_current_sgdu = dic_of_supergdu_and_gdu_members[tested_reconstructed_sgdu_ft.get_name()]
											if (reconstruct_rift_ft.get_right_plate() in list_of_gdu_members_for_other_current_sgdu):
												is_inside_right_gdu_polygon = tested_reconstructed_sgdu
									if (is_inside_right_gdu_polygon is not None and is_inside_left_gdu_polygon is not None):
										if (pygplates.GeometryOnSphere.distance(is_inside_left_gdu_polygon, is_inside_right_gdu_polygon) == 0.00):
											is_inside_sgdu = False
											break
							elif (reconstruct_rift_ft.get_right_plate() in list_of_gdu_members_for_current_sgdu):
								is_inside_right_gdu_polygon = reconstructed_sgdu
								for tested_reconstructed_sgdu_ft, tested_reconstructed_sgdu in final_reconstructed_sgdu_fts:
									if (tested_reconstructed_sgdu_ft.get_name() != reconstructed_sgdu_ft.get_name()):
										if (tested_reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
											list_of_gdu_members_for_other_current_sgdu = dic_of_supergdu_and_gdu_members[tested_reconstructed_sgdu_ft.get_name()]
											if (reconstruct_rift_ft.get_left_plate() in list_of_gdu_members_for_other_current_sgdu):
												is_inside_left_gdu_polygon = tested_reconstructed_sgdu
									if (is_inside_right_gdu_polygon is not None and is_inside_left_gdu_polygon is not None):
										if (pygplates.GeometryOnSphere.distance(is_inside_left_gdu_polygon, is_inside_right_gdu_polygon) == 0.00):
											is_inside_sgdu = False
											break
							break
					if (is_inside_sgdu == True):
						dic_of_invalid_rift_point_fts['reconstruction_time'].append(reconstruction_time)
						dic_of_invalid_rift_point_fts['rift_point_name'].append(reconstruct_rift_ft.get_name())
						dic_of_invalid_rift_point_fts['order'].append(float(reconstruct_rift_ft.get_description()))
					else:
						#NEW 
						stage_relative_reconstruction_rotation = find_stage_relative_reconstruction_rotation_(rotation_model,reconstruct_rift_ft.get_left_plate(),reconstruct_rift_ft.get_right_plate(),float(reconstruction_time)+time_interval,float(reconstruction_time),reference)
						if (stage_relative_reconstruction_rotation.represents_identity_rotation() == True and reconstruction_time > 0):
							current_rift_begin_age, current_rift_end_age = reconstruct_rift_ft.get_valid_time()
							reconstruct_rift_ft.set_valid_time(current_rift_begin_age, reconstruction_time)
							dic_of_invalid_rift_point_fts['reconstruction_time'].append(reconstruction_time)
							dic_of_invalid_rift_point_fts['rift_point_name'].append(reconstruct_rift_ft.get_name())
							dic_of_invalid_rift_point_fts['order'].append(float(reconstruct_rift_ft.get_description()))
						else:
							remaining_tuples_rift_point_features.append((reconstruct_rift_ft, reconstructed_rift_point))
				if (len(remaining_tuples_rift_point_features) > 0):
					list_of_remaining_rift_features,list_of_remaining_rift_points = list(zip(*remaining_tuples_rift_point_features))
					list_of_valid_rift_point_features = list_of_remaining_rift_features
				else:
					list_of_valid_rift_point_features = []
					
			reconstructed_line_features[:] = []
			list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in plate_boundary_zone_boundaries if con_ocn_line_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_line_fts = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			
			reconstructed_left_point_features[:] = []
			list_of_tuples_for_descrp_reconstr_pts[:] = []
			remaining_left_point_features = []
			if (len(list_of_left_isochron_point_features) > 0):
				list_of_valid_left_isochron_point_features = [left_ft for left_ft in list_of_left_isochron_point_features if left_ft.is_valid_at_time(reconstruction_time)]
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_left_isochron_point_features,rotation_model,reconstructed_left_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_left_isochron_point_features,rotation_model,reconstructed_left_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_left_point_fts = find_final_reconstructed_geometries(reconstructed_left_point_features,pygplates.PointOnSphere)
				for reconstruct_left_ft, reconstructed_left_point in final_reconstructed_left_point_fts:
					is_inside_sgdu = False
					list_of_tuples_for_descrp_reconstr_pts.append((float(reconstruct_left_ft.get_description()),reconstructed_left_point))
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_left_point) == True):
							is_inside_sgdu = True
							break
					if (is_inside_sgdu == True):
						current_begin_age,_ = reconstruct_left_ft.get_valid_time()
						reconstruct_left_ft.set_valid_time(current_begin_age, reconstruction_time)
						output_left_point_features.add(reconstruct_left_ft)
						#list_of_already_modified_features.add(reconstruct_left_ft.get_feature_id().get_string())
						#identify possible subduction zone
						#make sure to get the order of the point to create the line feature 
						#list_of_tuples_for_descrp_reconstr_pts.append((reconstruct_left_ft.get_description(),reconstructed_left_point))
					
						#NEW edit all left_point_ft
						# for temp_left_ft in remaining_left_point_features:
							# temp_current_begin_age,_ = temp_left_ft.get_valid_time()
							# if (temp_current_begin_age > reconstruction_time):
								# temp_left_ft.set_valid_time(temp_current_begin_age, reconstruction_time)
								# output_left_point_features.add(temp_left_ft)
						
						#dic_of_isochron_interacting_sgdu = {'reconstruction_time':[],'isochron_name':[],'isochron_gduid':[],'sgdu':[],'repgduid':[]}
						dic_of_isochron_interacting_sgdu['reconstruction_time'].append(reconstruction_time)
						dic_of_isochron_interacting_sgdu['isochron_name'].append(reconstruct_left_ft.get_name())
						dic_of_isochron_interacting_sgdu['isochron_gduid'].append(reconstruct_left_ft.get_reconstruction_plate_id())
						dic_of_isochron_interacting_sgdu['sgdu'].append(reconstructed_sgdu_ft.get_name())
						dic_of_isochron_interacting_sgdu['repgduid'].append(reconstructed_sgdu_ft.get_reconstruction_plate_id())
						
					else:
						remaining_left_point_features.append(reconstruct_left_ft)
					
			if (len(list_of_tuples_for_descrp_reconstr_pts) > 1 and len(list_of_valid_con_ocn_line_fts) > 0):
				list_of_tuples_for_descrp_reconstr_pts.sort()#based on the order or the small circle angular radius
				list_of_order_for_fts,list_of_left_pts = list(zip(*list_of_tuples_for_descrp_reconstr_pts))
				temporary_left_line = pygplates.PolylineOnSphere(list_of_left_pts)
				#find the plate boundary zone line feature crossing temporary left line --- Only need to check the orientation of the line if the line represent an MOR
				for unclassified_line_ft, unclassified_line in final_reconstructed_line_fts:
					if (pygplates.GeometryOnSphere.distance(unclassified_line, temporary_left_line) == 0.00):
						name_of_line_ft = unclassified_line_ft.get_name()
						if (name_of_line_ft in dic_of_new_kin_fts):
							dic_of_mor_interacts_bdn['reconstruction_time'].append(reconstruction_time)
							dic_of_mor_interacts_bdn['bdn_polylid'].append(name_of_line_ft)
							dic_of_mor_interacts_bdn['rift_name'].append(rift_name)
							dic_of_mor_interacts_bdn['rift_side'].append('L')
						else:
							#create subduction zone
							begin_age_line_ft_1,end_age_line_ft_1 = unclassified_line_ft.get_valid_time()
							if (end_age_line_ft_1 <= reconstruction_time):
								line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name = name_of_line_ft,valid_time = (reconstruction_time,end_age_line_ft_1))
								line_feature_1.set_reconstruction_plate_id(unclassified_line_ft.get_reconstruction_plate_id())
								line_feature_1.set_description('upper_gdu_margin')
								if (reference is None):
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time)
								else:
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time,reference)
								dic_of_new_kin_fts[name_of_line_ft] = line_feature_1
				
				# temp_left_line_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_isochron,temporary_left_line,name = rift_name,valid_time = (reconstruction_time,reconstruction_time-time_interval+0.100))
				# if (reference is not None):
					# temp_left_line_feature.set_reconstruction_plate_id(reference)
					# pygplates.reverse_reconstruct(temp_left_line_feature,rotation_model,reconstruction_time,reference)
				# else:
					# temp_left_line_feature.set_reconstruction_plate_id(0)
					# pygplates.reverse_reconstruct(temp_left_line_feature,rotation_model,reconstruction_time)
				# temp_left_line_feature.set_description('left_margin')
				# output_left_line_features.add(temp_left_line_feature)
			
			final_remained_left_pt_feats = []
			for remained_left_ft in remaining_left_point_features:
				if (remained_left_ft.is_valid_at_time(reconstruction_time-time_interval)):
					final_remained_left_pt_feats.append(remained_left_ft)
			list_of_left_isochron_point_features = final_remained_left_pt_feats
			
			list_of_tuples_for_descrp_reconstr_pts[:] = []
			remaining_right_point_features = []
			reconstructed_right_point_features[:] = []
			if (len(list_of_right_isochron_point_features) > 0):
				list_of_valid_right_isochron_point_features = [right_ft for right_ft in list_of_right_isochron_point_features if right_ft.is_valid_at_time(reconstruction_time)]
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_right_isochron_point_features,rotation_model,reconstructed_right_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_right_isochron_point_features,rotation_model,reconstructed_right_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_right_point_fts = find_final_reconstructed_geometries(reconstructed_right_point_features,pygplates.PointOnSphere)
				for reconstruct_right_ft, reconstructed_right_point in final_reconstructed_right_point_fts:
					is_inside_sgdu = False
					list_of_tuples_for_descrp_reconstr_pts.append((float(reconstruct_right_ft.get_description()),reconstructed_right_point))
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_right_point) == True):
							is_inside_sgdu = True
							break
					if (is_inside_sgdu == True):
						current_begin_age,_ = reconstruct_right_ft.get_valid_time()
						reconstruct_right_ft.set_valid_time(current_begin_age, reconstruction_time)
						output_right_point_features.add(reconstruct_right_ft)
						#list_of_already_modified_features.add(reconstruct_right_ft.get_feature_id().get_string())
						#identify possible subduction zone
						#make sure to get the order of the point to create the line feature 
						#list_of_tuples_for_descrp_reconstr_pts.append((reconstruct_right_ft.get_description(),reconstructed_right_point))
						
						#NEW edit all left_point_ft
						# for temp_right_ft in remaining_right_point_features:
							# temp_current_begin_age,_ = temp_right_ft.get_valid_time()
							# if (temp_current_begin_age > reconstruction_time):
								# temp_right_ft.set_valid_time(temp_current_begin_age, reconstruction_time)
								# output_right_point_features.add(temp_right_ft)
						
						dic_of_isochron_interacting_sgdu['reconstruction_time'].append(reconstruction_time)
						dic_of_isochron_interacting_sgdu['isochron_name'].append(reconstruct_right_ft.get_name())
						dic_of_isochron_interacting_sgdu['isochron_gduid'].append(reconstruct_right_ft.get_reconstruction_plate_id())
						dic_of_isochron_interacting_sgdu['sgdu'].append(reconstructed_sgdu_ft.get_name())
						dic_of_isochron_interacting_sgdu['repgduid'].append(reconstructed_sgdu_ft.get_reconstruction_plate_id())
						
					else:
						remaining_right_point_features.append(reconstruct_right_ft)
			if (len(list_of_tuples_for_descrp_reconstr_pts) > 1 and len(list_of_valid_con_ocn_line_fts) > 0):
				list_of_tuples_for_descrp_reconstr_pts.sort()#based on the order or the small circle angular radius
				list_of_order_for_fts,list_of_right_pts = list(zip(*list_of_tuples_for_descrp_reconstr_pts))
				temporary_right_line = pygplates.PolylineOnSphere(list_of_right_pts)
				#find the plate boundary zone line feature crossing temporary left line --- Only need to check the orientation of the line if the line represent an MOR
				for unclassified_line_ft, unclassified_line in final_reconstructed_line_fts:
					if (pygplates.GeometryOnSphere.distance(unclassified_line, temporary_right_line) == 0.00):
						name_of_line_ft = unclassified_line_ft.get_name()
						if (name_of_line_ft in dic_of_new_kin_fts):
							dic_of_mor_interacts_bdn['reconstruction_time'].append(reconstruction_time)
							dic_of_mor_interacts_bdn['bdn_polylid'].append(name_of_line_ft)
							dic_of_mor_interacts_bdn['rift_name'].append(rift_name)
							dic_of_mor_interacts_bdn['rift_side'].append('R')
						else:
							#create subduction zone
							begin_age_line_ft_1,end_age_line_ft_1 = unclassified_line_ft.get_valid_time()
							if (end_age_line_ft_1 <= reconstruction_time):
								line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name = name_of_line_ft,valid_time = (reconstruction_time,end_age_line_ft_1))
								line_feature_1.set_reconstruction_plate_id(unclassified_line_ft.get_reconstruction_plate_id())
								line_feature_1.set_description('upper_gdu_margin')
								if (reference is None):
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time)
								else:
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time,reference)
								dic_of_new_kin_fts[name_of_line_ft] = line_feature_1
				
				# temp_right_line_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_isochron,temporary_right_line,name = rift_name,valid_time = (reconstruction_time,reconstruction_time-time_interval+0.100))
				# if (reference is not None):
					# temp_right_line_feature.set_reconstruction_plate_id(reference)
					# pygplates.reverse_reconstruct(temp_right_line_feature,rotation_model,reconstruction_time,reference)
				# else:
					# temp_right_line_feature.set_reconstruction_plate_id(0)
					# pygplates.reverse_reconstruct(temp_right_line_feature,rotation_model,reconstruction_time)
				# temp_right_line_feature.set_description('right_margin')
				# output_right_line_features.add(temp_right_line_feature)
			
			#NEW
			final_remained_right_pt_feats = []
			for remained_right_ft in remaining_right_point_features:
				if (remained_right_ft.is_valid_at_time(reconstruction_time-time_interval)):
					final_remained_right_pt_feats.append(remained_right_ft)
			list_of_right_isochron_point_features = final_remained_right_pt_feats
			
			#create a new left and right isochron
			if (len(list_of_valid_rift_point_features) > 0 and remaining_tuples_rift_point_features is not None):
				if (len(remaining_tuples_rift_point_features) > 0):
					for rift_pt_ft,rift_pt in remaining_tuples_rift_point_features:
						left_isochron_pt_ft, right_isochron_pt_ft = create_left_and_right_div_fts_from_MOR_ft(rift_pt_ft, rift_pt, reconstruction_time, 0.00)
						if (reference is not None):
							pygplates.reverse_reconstruct(left_isochron_pt_ft,rotation_model,reconstruction_time,reference)
							pygplates.reverse_reconstruct(right_isochron_pt_ft,rotation_model,reconstruction_time,reference)
						else:
							pygplates.reverse_reconstruct(left_isochron_pt_ft,rotation_model,reconstruction_time)
							pygplates.reverse_reconstruct(right_isochron_pt_ft,rotation_model,reconstruction_time)
						list_of_left_isochron_point_features.append(left_isochron_pt_ft)
						list_of_right_isochron_point_features.append(right_isochron_pt_ft)
			reconstruction_time = reconstruction_time-time_interval
			if (reconstruction_time == 0.00):
				if (len(list_of_right_isochron_point_features) > 0):
					for right_point_ft in list_of_right_isochron_point_features:
						output_right_point_features.add(right_point_ft)
				if (len(list_of_left_isochron_point_features) > 0):
					for left_point_ft in list_of_left_isochron_point_features:
						output_left_point_features.add(left_point_ft)

	df_invalid_rift = pd.DataFrame.from_dict(dic_of_invalid_rift_point_fts)
	df_invalid_rift.to_csv('records_of_invalid_rift_'+modelname+'_'+yearmonthday+'.csv',index=False)
	
	df_mor_interacts_bdn = pd.DataFrame.from_dict(dic_of_mor_interacts_bdn)
	df_mor_interacts_bdn.to_csv('records_of_mor_interacts_bdn_'+modelname+'_'+yearmonthday+'.csv',index=False)

	df_isochron_interacts_sgdu = pd.DataFrame.from_dict(dic_of_isochron_interacting_sgdu)
	df_isochron_interacts_sgdu.to_csv('records_of_isochron_interacts_sgdu_'+modelname+'_'+yearmonthday+'.csv',index=False)
	
	output_new_kin_line_features = pygplates.FeatureCollection()
	for polylid_of_new_kin_line in dic_of_new_kin_fts:
		new_kin_line_ft = dic_of_new_kin_fts[polylid_of_new_kin_line]
		output_new_kin_line_features.add(new_kin_line_ft)
	output_new_kin_line_features.write('subduction_zone_features_'+modelname+'_'+yearmonthday+'.shp')
	
	#output_right_line_features.write('temp_right_line_features_'+modelname+'_'+yearmonthday+'.shp')
	#output_left_line_features.write('temp_left_line_features_'+modelname+'_'+yearmonthday+'.shp')
	output_right_point_features.write('isochron_right_point_features_'+modelname+'_'+yearmonthday+'.shp')
	output_left_point_features.write('isochron_left_point_features_'+modelname+'_'+yearmonthday+'.shp')


def modify_end_age_of_rift_point_features_based_on_spatial_rlx_with_polygon_fts_alone(temp_rift_point_features, sgdu_features, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday):
	output_interested_rift_point_features = pygplates.FeatureCollection()
	for rift_pt_ft in temp_rift_point_features:
		begin_rift_age, end_rift_age = rift_pt_ft.get_valid_time()
		is_included = True
		if (begin_rift_age < min_reconstruction_time_for_start_div or end_rift_age > max_reconstruction_time_for_start_div):
			is_included = False
		if (is_included == True):
			output_interested_rift_point_features.add(rift_pt_ft)
	reconstructed_rift_point_features = []
	reconstructed_sgdu_polygon_features = []
	reconstruction_time = max_reconstruction_time_for_start_div
	#while (reconstruction_time > min_reconstruction_time_for_start_div):
	while (reconstruction_time > 0.00):
		reconstructed_rift_point_features[:] = []
		reconstructed_sgdu_polygon_features[:] = []
		valid_rift_point_features = [rift_pt_ft for rift_pt_ft in output_interested_rift_point_features if rift_pt_ft.is_valid_at_time(reconstruction_time)]
		valid_sgdu_features = [sgdu_ft for sgdu_ft in sgdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
		if (reference is not None):
			pygplates.reconstruct(valid_rift_point_features, rotation_model, reconstructed_rift_point_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_polygon_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_rift_point_features, rotation_model, reconstructed_rift_point_features, reconstruction_time, group_with_feature = True)
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_polygon_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features, pygplates.PointOnSphere)
		final_reconstructed_sgdu_polygon_fts = find_final_reconstructed_geometries(reconstructed_sgdu_polygon_features, pygplates.PolygonOnSphere)
		for rift_ft, rift_pt in final_reconstructed_rift_point_fts:
			begin_rift_age, end_rift_age = rift_ft.get_valid_time()
			for sgdu_ft, sgdu_polygon in final_reconstructed_sgdu_polygon_fts:
				if (sgdu_polygon.is_point_in_polygon(rift_pt)):
					for ft in valid_rift_point_features:
						if (ft.get_feature_id() == rift_ft.get_feature_id()):
							ft.set_valid_time(begin_rift_age, reconstruction_time)
		reconstruction_time = reconstruction_time-time_interval
	output_interested_rift_point_features.write("modified_end_age_of_rift_point_fts_based_on_spatial_rlx_with_polygon_fts_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)+"_"+modelname+"_"+yearmonthday+".shp")
def modified_end_age_of_rift_point_features_based_on_kinematic_records(rift_point_features_records_csv,modified_rift_point_features,records_of_kin_line_feats_from_conv,records_of_kin_line_feats_from_div,maximum_reconstruction_time,minimum_reconstruction_time,time_interval,modelname,yearmonthday):
	output_modified_rift_point_features = pygplates.FeatureCollection()
	
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	#from_time,to_time,type_kin,polylid1,polylid2,fid1,fid2
	kinematic_line_from_div_df = pd.read_csv(records_of_kin_line_feats_from_div, delimiter=',', header = 0)
	kinematic_line_from_conv_df = None
	if (records_of_kin_line_feats_from_conv is not None):
		kinematic_line_from_conv_df = pd.read_csv(records_of_kin_line_feats_from_conv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time) ]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		descending_order_array = np.flip(sorted_array_of_start_div)
		#NEW
		start_div = descending_order_array[0]
		#div_line_names_for_left_and_right_of_MOR = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),['lpolylid','rpolylid']]
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		list_of_wanted_rift_point_features = []
		for order in array_of_order_for_rift_points:
			name_of_rift_point_ft = rift_name+'_'+str(order)
			found_point_ft = None
			for rift_point_ft in modified_rift_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					found_point_ft = rift_point_ft
					break
			if (found_point_ft is None):
				print("Error could not find the wanted rift point feature")
				print("name_of_rift_point_ft",name_of_rift_point_ft)
				exit()
			list_of_wanted_rift_point_features.append((found_point_ft,order))
		reconstruction_time = start_div - time_interval
		new_end_time_for_rift_ft = -1.00
		valid_rift_point_features = []
		while (reconstruction_time >= 0.00):
			valid_rift_point_features[:] = []
			for rift_point_ft,rift_order in list_of_wanted_rift_point_features:
				if (rift_point_ft.is_valid_at_time(reconstruction_time)):
					valid_rift_point_features.append((rift_point_ft,rift_order))
			if (len(valid_rift_point_features) == 0):
				break
			is_valid = True
			#from_time,to_time,type_kin,polylid1,polylid2,fid1,fid2
			rift_pt_feats_to_be_modified = []
			records_to_be_modified = []
			
			#only rift point features associate with the two line features that later converge, NOT the whole series of rift point features btw 2 SuperGDUS
			for rift_point_ft, rift_order in valid_rift_point_features:
				begin_rift_age, _ = rift_point_ft.get_valid_time()
				#find the two line features 
				is_valid = True
				div_line_names_for_left_and_right_of_MOR = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()) & (rift_history_df['order'] == rift_order),['lpolylid','rpolylid']]
				for lpolylid, rpolylid in div_line_names_for_left_and_right_of_MOR.itertuples(index = False, name = None):
					wanted_records_of_kinematic_line_from_div_df = kinematic_line_from_div_df.loc[(((kinematic_line_from_div_df['polylid1'] == lpolylid) & (kinematic_line_from_div_df['polylid2'] == rpolylid)) | ((kinematic_line_from_div_df['polylid1'] == rpolylid) & (kinematic_line_from_div_df['polylid2'] == lpolylid))) & (kinematic_line_from_div_df['type_kin'] == 'convergent_margin') & (kinematic_line_from_div_df['from_time'] <= reconstruction_time),'from_time']
					if (len(wanted_records_of_kinematic_line_from_div_df) > 0):
						array_of_conv_time = wanted_records_of_kinematic_line_from_div_df.to_numpy()
						sorted_array_of_conv_time = np.sort(array_of_conv_time)
						new_end_time_for_rift_ft = sorted_array_of_conv_time[-1]
						is_valid = False
						break
					else:
						if (kinematic_line_from_conv_df is not None):
							wanted_records_of_kinematic_line_from_conv_df = kinematic_line_from_conv_df.loc[(((kinematic_line_from_conv_df['polylid1'] == lpolylid) & (kinematic_line_from_conv_df['polylid2'] == rpolylid)) | ((kinematic_line_from_conv_df['polylid1'] == rpolylid) & (kinematic_line_from_conv_df['polylid2'] == lpolylid))) & (kinematic_line_from_conv_df['type_kin'] == 'convergent_margin') & (kinematic_line_from_conv_df['from_time'] <= reconstruction_time),'from_time']
							if (len(wanted_records_of_kinematic_line_from_conv_df) > 0):
								array_of_conv_time = wanted_records_of_kinematic_line_from_conv_df.to_numpy()
								sorted_array_of_conv_time = np.sort(array_of_conv_time)
								new_end_time_for_rift_ft = sorted_array_of_conv_time[-1]
								is_valid = False
								break
							else:
								wanted_records_of_kinematic_line_from_div_df = kinematic_line_from_div_df.loc[(((kinematic_line_from_div_df['polylid1'] == lpolylid) & (kinematic_line_from_div_df['polylid2'] == rpolylid)) | ((kinematic_line_from_div_df['polylid1'] == rpolylid) & (kinematic_line_from_div_df['polylid2'] == lpolylid))) & (kinematic_line_from_div_df['type_kin'] == 'convergent_margin') & (kinematic_line_from_div_df['to_time'] <= reconstruction_time) & (kinematic_line_from_div_df['from_time'] >= reconstruction_time) & (kinematic_line_from_div_df['from_time'] < begin_rift_age),'from_time']
								if (len(wanted_records_of_kinematic_line_from_div_df) > 0):
									array_of_conv_time = wanted_records_of_kinematic_line_from_div_df.to_numpy()
									sorted_array_of_conv_time = np.sort(array_of_conv_time)
									new_end_time_for_rift_ft = sorted_array_of_conv_time[-1]
									is_valid = False
									break
								# else:
									# wanted_records_of_kinematic_line_from_div_df = kinematic_line_from_div_df.loc[(((kinematic_line_from_div_df['polylid1'] == lpolylid) & (kinematic_line_from_div_df['polylid2'] == rpolylid)) | ((kinematic_line_from_div_df['polylid1'] == rpolylid) & (kinematic_line_from_div_df['polylid2'] == lpolylid))) & (kinematic_line_from_div_df['type_kin'] != 'divergent_margin') & (kinematic_line_from_div_df['from_time'] <= reconstruction_time),'from_time']
									# if (len(wanted_records_of_kinematic_line_from_div_df) > 0):
										# array_of_conv_time = wanted_records_of_kinematic_line_from_div_df.to_numpy()
										# sorted_array_of_conv_time = np.sort(array_of_conv_time)
										# new_end_time_for_rift_ft = sorted_array_of_conv_time[-1]
										# is_valid = False
										# break
						else:
							wanted_records_of_kinematic_line_from_div_df = kinematic_line_from_div_df.loc[(((kinematic_line_from_div_df['polylid1'] == lpolylid) & (kinematic_line_from_div_df['polylid2'] == rpolylid)) | ((kinematic_line_from_div_df['polylid1'] == rpolylid) & (kinematic_line_from_div_df['polylid2'] == lpolylid))) & (kinematic_line_from_div_df['type_kin'] == 'convergent_margin') & (kinematic_line_from_div_df['to_time'] <= reconstruction_time) & (kinematic_line_from_div_df['from_time'] >= reconstruction_time) & (kinematic_line_from_div_df['from_time'] < begin_rift_age),'from_time']
							if (len(wanted_records_of_kinematic_line_from_div_df) > 0):
								array_of_conv_time = wanted_records_of_kinematic_line_from_div_df.to_numpy()
								sorted_array_of_conv_time = np.sort(array_of_conv_time)
								new_end_time_for_rift_ft = sorted_array_of_conv_time[-1]
								is_valid = False
								break
							# else:
								# wanted_records_of_kinematic_line_from_div_df = kinematic_line_from_div_df.loc[(((kinematic_line_from_div_df['polylid1'] == lpolylid) & (kinematic_line_from_div_df['polylid2'] == rpolylid)) | ((kinematic_line_from_div_df['polylid1'] == rpolylid) & (kinematic_line_from_div_df['polylid2'] == lpolylid))) & (kinematic_line_from_div_df['type_kin'] != 'divergent_margin') & (kinematic_line_from_div_df['from_time'] <= reconstruction_time),'to_time']
								# if (len(wanted_records_of_kinematic_line_from_div_df) > 0):
									# array_of_conv_time = wanted_records_of_kinematic_line_from_div_df.to_numpy()
									# sorted_array_of_conv_time = np.sort(array_of_conv_time)
									# new_end_time_for_rift_ft = sorted_array_of_conv_time[-1]
									# is_valid = False
									# break
				if (is_valid == False):
					current_rift_begin_age, current_rift_end_age = rift_point_ft.get_valid_time()
					if (current_rift_end_age < new_end_time_for_rift_ft):
						#print("edit end age of rift point feature")
						rift_point_ft.set_valid_time(current_rift_begin_age, new_end_time_for_rift_ft)
			
			
			#old technique
			# for lpolylid,rpolylid in div_line_names_for_left_and_right_of_MOR.itertuples(index = False, name = None):
				# wanted_records_of_kinematic_line_from_div_df = kinematic_line_from_div_df.loc[(((kinematic_line_from_div_df['polylid1'] == lpolylid) & (kinematic_line_from_div_df['polylid2'] == rpolylid)) | ((kinematic_line_from_div_df['polylid1'] == rpolylid) & (kinematic_line_from_div_df['polylid2'] == lpolylid))) & (kinematic_line_from_div_df['type_kin'] == 'convergent_margin') & (kinematic_line_from_div_df['from_time'] <= reconstruction_time),'from_time']
				# if (len(wanted_records_of_kinematic_line_from_div_df) > 0):
					# array_of_conv_time = wanted_records_of_kinematic_line_from_div_df.to_numpy()
					# sorted_array_of_conv_time = np.sort(array_of_conv_time)
					# new_end_time_for_rift_ft = sorted_array_of_conv_time[-1]
					# is_valid = False
					# #break
				# else:
					# wanted_records_of_kinematic_line_from_conv_df = kinematic_line_from_conv_df.loc[(((kinematic_line_from_conv_df['polylid1'] == lpolylid) & (kinematic_line_from_conv_df['polylid2'] == rpolylid)) | ((kinematic_line_from_conv_df['polylid1'] == rpolylid) & (kinematic_line_from_conv_df['polylid2'] == lpolylid))) & (kinematic_line_from_conv_df['type_kin'] == 'convergent_margin') & (kinematic_line_from_conv_df['from_time'] <= reconstruction_time),'from_time']
					# if (len(wanted_records_of_kinematic_line_from_conv_df) > 0):
						# array_of_conv_time = wanted_records_of_kinematic_line_from_conv_df.to_numpy()
						# sorted_array_of_conv_time = np.sort(array_of_conv_time)
						# new_end_time_for_rift_ft = sorted_array_of_conv_time[-1]
						# is_valid = False
						# #break
			# if (is_valid == False):
				# for rift_point_ft in valid_rift_point_features:
					# current_rift_begin_age, current_rift_end_age = rift_point_ft.get_valid_time()
					# if (current_rift_end_age < new_end_time_for_rift_ft):
						# #print("edit end age of rift point feature")
						# rift_point_ft.set_valid_time(current_rift_begin_age, new_end_time_for_rift_ft)
						
			reconstruction_time = reconstruction_time - time_interval
		
		for final_ouput_ft,_ in list_of_wanted_rift_point_features:
			output_modified_rift_point_features.add(final_ouput_ft.clone())
	output_modified_rift_point_features.write("modified_end_age_of_rift_point_features_based_on_kinematic_records_"+str(maximum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
	
def find_pairs_of_SGDUs_for_RRR(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday):
	output_dic_pairs = {'1_start_div':[],'1_rift_name':[],'1_lrepgduid':[],'1_rrepgduid':[],'2_start_div':[],'2_rift_name':[],'2_lrepgduid':[],'2_rrepgduid':[],'3_start_div':[],'3_rift_name':[],'3_lrepgduid':[],'3_rrepgduid':[]}
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (max_reconstruction_time_for_start_div is not None):
		selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] <= max_reconstruction_time_for_start_div]
	if (min_reconstruction_time_for_start_div is not None):
		new_selected_rift_history_df = None
		if (selected_rift_history_df is not None):
			new_selected_rift_history_df = selected_rift_history_df.loc[selected_rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		else:
			new_selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		if (new_selected_rift_history_df is not None):
			selected_rift_history_df = new_selected_rift_history_df
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		#NEW
		start_div = sorted_array_of_start_div[-1]
		div_left_and_right_of_MOR = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lrepgduid'].notna()) & (rift_history_df['rrepgduid'].notna()),['lrepgduid','rrepgduid']]
		#ridge 1
		for left_rep_gduid,right_rep_gduid in div_left_and_right_of_MOR.itertuples(index = False, name = None):
			#ridge 2 - from left
			second_rift_df = rift_history_df.loc[(rift_history_df['rift_name'] != rift_name) & (rift_history_df['lrepgduid'] == left_rep_gduid),['start_div','rift_name','rrepgduid']]
			if (len(second_rift_df) > 0):
				for second_start_div,second_rift_name,second_rrepgduid in second_rift_df.itertuples(index = False, name = None):
					#ridge 3
					third_rift_df = rift_history_df.loc[(rift_history_df['rift_name'] != rift_name) & (rift_history_df['rift_name'] != second_rift_name) & ((rift_history_df['lrepgduid'] == right_rep_gduid) | (rift_history_df['rrepgduid'] == right_rep_gduid))]
					filtered_third_rift_df = third_rift_df.loc[(third_rift_df['lrepgduid'] != left_rep_gduid) & (third_rift_df['rrepgduid'] != left_rep_gduid) & ((rift_history_df['lrepgduid'] == second_rrepgduid) | (rift_history_df['rrepgduid'] == second_rrepgduid)),['start_div','rift_name','lrepgduid','rrepgduid']]
					if (len(filtered_third_rift_df) > 0):
						for third_start_div,third_rift,third_lrepgduid,third_rrepgduid in filtered_third_rift_df.itertuples(index = False, name = None):
							diff_start_div_and_second_start_div = abs(start_div-second_start_div)
							diff_start_div_and_third_start_div = abs(start_div-third_start_div)
							diff_second_start_div_and_third_start_div = abs(third_start_div-second_start_div)
							if (diff_start_div_and_second_start_div <= 500.00 and diff_start_div_and_third_start_div <= 500.00 and diff_second_start_div_and_third_start_div <= 500.00):
								output_dic_pairs['1_start_div'].append(start_div)
								output_dic_pairs['1_rift_name'].append(rift_name)
								output_dic_pairs['1_lrepgduid'].append(left_rep_gduid)
								output_dic_pairs['1_rrepgduid'].append(right_rep_gduid)
							
								output_dic_pairs['2_start_div'].append(second_start_div)
								output_dic_pairs['2_rift_name'].append(second_rift_name)
								output_dic_pairs['2_lrepgduid'].append(left_rep_gduid)
								output_dic_pairs['2_rrepgduid'].append(second_rrepgduid)
							
								output_dic_pairs['3_start_div'].append(third_start_div)
								output_dic_pairs['3_rift_name'].append(third_rift)
								output_dic_pairs['3_lrepgduid'].append(third_lrepgduid)
								output_dic_pairs['3_rrepgduid'].append(third_rrepgduid)
			#ridge 2 - from right
			second_rift_df = rift_history_df.loc[(rift_history_df['rift_name'] != rift_name) & (rift_history_df['rrepgduid'] == left_rep_gduid),['start_div','rift_name','lrepgduid']]
			if (len(second_rift_df) > 0):
				for second_start_div,second_rift_name,second_lrepgduid in second_rift_df.itertuples(index = False, name = None):
					#ridge 3
					third_rift_df = rift_history_df.loc[(rift_history_df['rift_name'] != rift_name) & (rift_history_df['rift_name'] != second_rift_name) & ((rift_history_df['lrepgduid'] == right_rep_gduid) | (rift_history_df['rrepgduid'] == right_rep_gduid))]
					filtered_third_rift_df = third_rift_df.loc[(third_rift_df['lrepgduid'] != left_rep_gduid) & (third_rift_df['rrepgduid'] != left_rep_gduid) & ((rift_history_df['lrepgduid'] == second_lrepgduid) | (rift_history_df['rrepgduid'] == second_lrepgduid)),['start_div','rift_name','lrepgduid','rrepgduid']]
					if (len(filtered_third_rift_df) > 0):
						for third_start_div,third_rift,third_lrepgduid,third_rrepgduid in filtered_third_rift_df.itertuples(index = False, name = None):
							diff_start_div_and_second_start_div = abs(start_div-second_start_div)
							diff_start_div_and_third_start_div = abs(start_div-third_start_div)
							diff_second_start_div_and_third_start_div = abs(third_start_div-second_start_div)
							if (diff_start_div_and_second_start_div <= 500.00 and diff_start_div_and_third_start_div <= 500.00 and diff_second_start_div_and_third_start_div <= 500.00):
								output_dic_pairs['1_start_div'].append(start_div)
								output_dic_pairs['1_rift_name'].append(rift_name)
								output_dic_pairs['1_lrepgduid'].append(left_rep_gduid)
								output_dic_pairs['1_rrepgduid'].append(right_rep_gduid)
							
								output_dic_pairs['2_start_div'].append(second_start_div)
								output_dic_pairs['2_rift_name'].append(second_rift_name)
								output_dic_pairs['2_lrepgduid'].append(second_lrepgduid)
								output_dic_pairs['2_rrepgduid'].append(left_rep_gduid)
							
								output_dic_pairs['3_start_div'].append(third_start_div)
								output_dic_pairs['3_rift_name'].append(third_rift)
								output_dic_pairs['3_lrepgduid'].append(third_lrepgduid)
								output_dic_pairs['3_rrepgduid'].append(third_rrepgduid)
	print('number of records in output_dic_pairs', len(output_dic_pairs))
	output_df = pd.DataFrame.from_dict(output_dic_pairs)
	output_df.to_csv('possible_pairs_of_SGDUs_for_RRR_'+str(max_reconstruction_time_for_start_div)+'_'+str(min_reconstruction_time_for_start_div)+'_'+modelname+'_'+yearmonthday+'.csv', index = False)

def find_the_intersections_between_two_arcs(arc_1,arc_2):
	normal_vec_arc_1 = arc_1.get_great_circle_normal()
	normal_vec_arc_2 = arc_2.get_great_circle_normal()
	normal_of_two_normal_vectors = pygplates.Vector3D.cross(normal_vec_arc_1,normal_vec_arc_2)
	intersection_1 = normal_of_two_normal_vectors.to_normalised()
	intersection_2 = -intersection_1
	return (intersection_1,intersection_2)

def is_point_on_the_arc(pt,arc_1,threshold_degrees):
	start_pt_of_arc_1 = arc_1.get_start_point()
	end_pt_of_arc_1 = arc_1.get_end_point()
	arc_len_degrees = math.degrees(arc_1.get_arc_length())
	distance_from_start_arc_to_pt = pygplates.Vector3D.angle_between(pygplates.Vector3D(start_pt_of_arc_1.to_xyz()),pygplates.Vector3D(pt.to_xyz()))
	distance_from_start_arc_to_to_pt_degrees = math.degrees(distance_from_start_arc_to_pt)
	distance_from_pt_to_end_arc = pygplates.Vector3D.angle_between(pygplates.Vector3D(pt.to_xyz()),pygplates.Vector3D(end_pt_of_arc_1.to_xyz()))
	distance_from_pt_to_end_arc_degrees = math.degrees(distance_from_pt_to_end_arc)
	sum_of_arc_dist = distance_from_start_arc_to_to_pt_degrees + distance_from_pt_to_end_arc_degrees
	
	#debug
	print("sum_of_arc_dist",sum_of_arc_dist)
	print("arc_len_degrees",arc_len_degrees)
	print(abs(sum_of_arc_dist-arc_len_degrees))
	
	if (abs(sum_of_arc_dist-arc_len_degrees) <= threshold_degrees):
		return True
	else:
		return False

def find_coordinates_of_triple_junction_for_RRR(records_of_pairs_of_ridges_csv, temp_rift_point_features, rift_point_features_records_csv, rotation_model, reference, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div,modelname, yearmonthday):
	output_records_of_rifts_for_junction = []
	#1_start_div,1_rift_name,1_lrepgduid,1_rrepgduid,2_start_div,2_rift_name,2_lrepgduid,2_rrepgduid,3_start_div,3_rift_name,3_lrepgduid,3_rrepgduid
	pairs_of_ridges_df = pd.read_csv(records_of_pairs_of_ridges_csv, delimiter=',', header = 0)
	no_duplicates_of_ridges_df = pairs_of_ridges_df.drop_duplicates()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	output_triple_junction_feats = pygplates.FeatureCollection()
	if (max_reconstruction_time_for_start_div is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= max_reconstruction_time_for_start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna())]
	if (min_reconstruction_time_for_start_div is not None):
		new_selected_rift_history_df = None
		if (selected_rift_history_df is not None):
			new_selected_rift_history_df = selected_rift_history_df.loc[(selected_rift_history_df['start_div'] > min_reconstruction_time_for_start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna())]
		else:
			new_selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] > min_reconstruction_time_for_start_div) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna())]
		if (new_selected_rift_history_df is not None):
			selected_rift_history_df = new_selected_rift_history_df
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
		
	for start_div_1, rift_name_1, lrepgduid_1, rrepgduid_1, start_div_2, rift_name_2, lrepgduid_2, rrepgduid_2, start_div_3, rift_name_3, lrepgduid_3, rrepgduid_3 in no_duplicates_of_ridges_df.itertuples(index=False,name=None):
		#find the youngest time for start_div 
		start_div_array = np.array([start_div_1, start_div_2, start_div_3])
		youngest_start_div = start_div_array.min()
		list_of_valid_temp_rift_point_fts = [temp_rift_pt_ft for temp_rift_pt_ft in temp_rift_point_features if temp_rift_pt_ft.is_valid_at_time(youngest_start_div)]
		array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name_1,'order'].to_numpy()
		if (len(array_of_order_for_rift_points) == 0):
			continue
		min_order_for_rift_pt_1 = array_of_order_for_rift_points.min()
		max_order_for_rift_pt_1 = array_of_order_for_rift_points.max()
		min_rift_pt_ft_1 = None
		max_rift_pt_ft_1 = None
		for point_ft in list_of_valid_temp_rift_point_fts:
			if (point_ft.get_name() == (rift_name_1+'_'+str(min_order_for_rift_pt_1))):
				min_rift_pt_ft_1 = point_ft
			if (point_ft.get_name() == (rift_name_1+'_'+str(max_order_for_rift_pt_1))):
				max_rift_pt_ft_1 = point_ft
			if (min_rift_pt_ft_1 is not None and max_rift_pt_ft_1 is not None):
				break
		
		array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name_2,'order'].to_numpy()
		if (len(array_of_order_for_rift_points) == 0):
			continue
		min_order_for_rift_pt_2 = array_of_order_for_rift_points.min()
		max_order_for_rift_pt_2 = array_of_order_for_rift_points.max()
		min_rift_pt_ft_2 = None
		max_rift_pt_ft_2 = None
		for point_ft in list_of_valid_temp_rift_point_fts:
			if (point_ft.get_name() == (rift_name_2+'_'+str(min_order_for_rift_pt_2))):
				min_rift_pt_ft_2 = point_ft
			if (point_ft.get_name() == (rift_name_2+'_'+str(max_order_for_rift_pt_2))):
				max_rift_pt_ft_2 = point_ft
			if (min_rift_pt_ft_2 is not None and max_rift_pt_ft_2 is not None):
				break
		
		array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name_3,'order'].to_numpy()
		if (len(array_of_order_for_rift_points) == 0):
			continue
		min_order_for_rift_pt_3 = array_of_order_for_rift_points.min()
		max_order_for_rift_pt_3 = array_of_order_for_rift_points.max()
		min_rift_pt_ft_3 = None
		max_rift_pt_ft_3 = None
		for point_ft in list_of_valid_temp_rift_point_fts:
			if (point_ft.get_name() == (rift_name_3+'_'+str(min_order_for_rift_pt_3))):
				min_rift_pt_ft_3 = point_ft
			if (point_ft.get_name() == (rift_name_3+'_'+str(max_order_for_rift_pt_3))):
				max_rift_pt_ft_3 = point_ft
			if (min_rift_pt_ft_3 is not None and max_rift_pt_ft_3 is not None):
				break
		reconstructed_point_features_1 = []
		reconstructed_point_features_2 = []
		reconstructed_point_features_3 = []
		if (min_rift_pt_ft_1 is not None and min_rift_pt_ft_2 is not None and min_rift_pt_ft_3 is not None and max_rift_pt_ft_1 is not None and max_rift_pt_ft_2 is not None and max_rift_pt_ft_3 is not None):
			if (reference is not None):
				pygplates.reconstruct([min_rift_pt_ft_1,max_rift_pt_ft_1],rotation_model,reconstructed_point_features_1,youngest_start_div,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct([min_rift_pt_ft_2,max_rift_pt_ft_2],rotation_model,reconstructed_point_features_2,youngest_start_div,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct([min_rift_pt_ft_3,max_rift_pt_ft_3],rotation_model,reconstructed_point_features_3,youngest_start_div,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct([min_rift_pt_ft_1,max_rift_pt_ft_1],rotation_model,reconstructed_point_features_1,youngest_start_div,group_with_feature = True)
				pygplates.reconstruct([min_rift_pt_ft_2,max_rift_pt_ft_2],rotation_model,reconstructed_point_features_2,youngest_start_div,group_with_feature = True)
				pygplates.reconstruct([min_rift_pt_ft_3,max_rift_pt_ft_3],rotation_model,reconstructed_point_features_3,youngest_start_div,group_with_feature = True)
		final_reconstructed_point_ft_1 = find_final_reconstructed_geometries(reconstructed_point_features_1,pygplates.PointOnSphere)
		final_reconstructed_point_ft_2 = find_final_reconstructed_geometries(reconstructed_point_features_2,pygplates.PointOnSphere)
		final_reconstructed_point_ft_3 = find_final_reconstructed_geometries(reconstructed_point_features_3,pygplates.PointOnSphere)
		
		total_relative_reconstruction_rotation_for_rift_1 = find_total_relative_reconstruction_rotation_(rotation_model, lrepgduid_1, rrepgduid_1, float(youngest_start_div), reference)
		total_relative_reconstruction_rotation_for_rift_2 = find_total_relative_reconstruction_rotation_(rotation_model,lrepgduid_2,rrepgduid_2,float(youngest_start_div),reference)
		total_relative_reconstruction_rotation_for_rift_3 = find_total_relative_reconstruction_rotation_(rotation_model,lrepgduid_3,rrepgduid_3,float(youngest_start_div),reference)
		E1,_ = total_relative_reconstruction_rotation_for_rift_1.get_euler_pole_and_angle()
		E2,_ = total_relative_reconstruction_rotation_for_rift_2.get_euler_pole_and_angle()
		E3,_ = total_relative_reconstruction_rotation_for_rift_3.get_euler_pole_and_angle()
		
		if (len(final_reconstructed_point_ft_1) > 0 and len(final_reconstructed_point_ft_2) > 0 and len(final_reconstructed_point_ft_3) > 0):
			reconstructed_min_ft_1,reconstructed_min_pt_1 = final_reconstructed_point_ft_1[0]
			min_circle_arc_1 = pygplates.GreatCircleArc(reconstructed_min_pt_1,E1)
			reconstructed_min_ft_2,reconstructed_min_pt_2 = final_reconstructed_point_ft_2[0]
			min_circle_arc_2 = pygplates.GreatCircleArc(reconstructed_min_pt_2,E2)
			reconstructed_min_ft_3,reconstructed_min_pt_3 = final_reconstructed_point_ft_3[0]
			min_circle_arc_3 = pygplates.GreatCircleArc(reconstructed_min_pt_3,E3)
			
			#find the distance from min_pt_1 to min_pt_2, max_pt_1 to min_pt_2, min_pt_1 to max_pt_2, max_pt_1 to max_pt_2
			min_1_min_2 = pygplates.GeometryOnSphere.distance(reconstructed_min_pt_1, reconstructed_min_pt_2)
			max_1_min_2 = -1.00
			reconstructed_max_ft_1,reconstructed_max_pt_1 = None,None
			if (len(final_reconstructed_point_ft_1) == 2):
				reconstructed_max_ft_1,reconstructed_max_pt_1 = final_reconstructed_point_ft_1[1]
				max_1_min_2 = pygplates.GeometryOnSphere.distance(reconstructed_max_pt_1, reconstructed_min_pt_2)
			min_1_max_2 = -1.00
			reconstructed_max_ft_2,reconstructed_max_pt_2 = None,None
			if (len(final_reconstructed_point_ft_2) == 2):
				reconstructed_max_ft_2,reconstructed_max_pt_2 = final_reconstructed_point_ft_2[1]
				min_1_max_2 = pygplates.GeometryOnSphere.distance(reconstructed_min_pt_1, reconstructed_max_pt_2)
			max_1_max_2 = -1.00
			if (reconstructed_max_pt_1 is not None and reconstructed_max_pt_2 is not None):
				max_1_max_2 = pygplates.GeometryOnSphere.distance(reconstructed_max_pt_1, reconstructed_max_pt_2)
			list_dist_btw_1_and_2 =[min_1_min_2]
			if (max_1_min_2 > -1.00):
				list_dist_btw_1_and_2.append(max_1_min_2)
			if (min_1_max_2 > -1.00):
				list_dist_btw_1_and_2.append(min_1_max_2)
			if (max_1_max_2 > -1.00):
				list_dist_btw_1_and_2.append(max_1_max_2)
			list_dist_btw_1_and_2.sort()
			final_pt_1, final_pt_2 = None,None
			closest_distance_btw_1_and_2 = list_dist_btw_1_and_2[0]
			if (closest_distance_btw_1_and_2 == min_1_min_2):
				final_pt_1, final_pt_2 = reconstructed_min_pt_1, reconstructed_min_pt_2
			elif (closest_distance_btw_1_and_2 == max_1_min_2):
				final_pt_1, final_pt_2 = reconstructed_max_pt_1, reconstructed_min_pt_2
			elif (closest_distance_btw_1_and_2 == min_1_max_2):
				final_pt_1, final_pt_2 = reconstructed_min_pt_1, reconstructed_max_pt_2
			elif (closest_distance_btw_1_and_2 == max_1_max_2):
				final_pt_1, final_pt_2 = reconstructed_max_pt_1, reconstructed_max_pt_2
			
			#find the distance from min_pt_1 to min_pt_2, max_pt_1 to min_pt_2, min_pt_1 to max_pt_2, max_pt_1 to max_pt_2
			min_1_min_3 = pygplates.GeometryOnSphere.distance(reconstructed_min_pt_1, reconstructed_min_pt_3)
			max_1_min_3 = -1.00
			reconstructed_max_ft_1,reconstructed_max_pt_1 = None,None
			if (len(final_reconstructed_point_ft_1) == 2):
				reconstructed_max_ft_1,reconstructed_max_pt_1 = final_reconstructed_point_ft_1[1]
				max_1_min_3 = pygplates.GeometryOnSphere.distance(reconstructed_max_pt_1, reconstructed_min_pt_3)
			min_1_max_3 = -1.00
			reconstructed_max_ft_3,reconstructed_max_pt_3 = None,None
			if (len(final_reconstructed_point_ft_3) == 2):
				reconstructed_max_ft_3,reconstructed_max_pt_3 = final_reconstructed_point_ft_3[1]
				min_1_max_3 = pygplates.GeometryOnSphere.distance(reconstructed_min_pt_1, reconstructed_max_pt_3)
			max_1_max_3 = -1.00
			if (reconstructed_max_pt_1 is not None and reconstructed_max_pt_3 is not None):
				max_1_max_2 = pygplates.GeometryOnSphere.distance(reconstructed_max_pt_1, reconstructed_max_pt_3)
			list_dist_btw_1_and_3 =[min_1_min_3]
			if (max_1_min_3 > -1.00):
				list_dist_btw_1_and_3.append(max_1_min_3)
			if (min_1_max_3 > -1.00):
				list_dist_btw_1_and_3.append(min_1_max_3)
			if (max_1_max_3 > -1.00):
				list_dist_btw_1_and_3.append(max_1_max_3)
			list_dist_btw_1_and_3.sort()
			final_pt_3 = None
			closest_distance_btw_1_and_3 = list_dist_btw_1_and_3[0]
			if (closest_distance_btw_1_and_3 == min_1_min_3):
				final_pt_3 = reconstructed_min_pt_3
			elif (closest_distance_btw_1_and_3 == max_1_min_3):
				final_pt_3 = reconstructed_min_pt_3
			elif (closest_distance_btw_1_and_3 == min_1_max_3):
				final_pt_3 = reconstructed_max_pt_3
			elif (closest_distance_btw_1_and_3 == max_1_max_3):
				final_pt_3 = reconstructed_max_pt_3
			
			# triple_junction = None
			# #btw 1 and 2
			# i1, i2 = find_the_intersections_between_two_arcs(min_circle_arc_1, min_circle_arc_2)
			# #print('i1',i1)
			# if (is_point_on_the_arc(i1,min_circle_arc_3,0.500) == True):
				# #i1 is the triple junction
				# triple_junction = i1
			# elif (is_point_on_the_arc(i2,min_circle_arc_3,0.500) == True):
				# #i2 is the triple junction
				# triple_junction = i2
			# if (triple_junction is None):
				# max_circle_arc_1 = None
				# max_circle_arc_2 = None
				# max_circle_arc_3 = None
				# if (len(final_reconstructed_point_ft_1) == 2):
					# reconstructed_max_ft_1,reconstructed_max_pt_1 = final_reconstructed_point_ft_1[1]
					# max_circle_arc_1 = pygplates.GreatCircleArc(reconstructed_max_pt_1,E1)
				# if (len(final_reconstructed_point_ft_2) == 2):
					# reconstructed_max_ft_2,reconstructed_max_pt_2 = final_reconstructed_point_ft_2[1]
					# max_circle_arc_2 = pygplates.GreatCircleArc(reconstructed_max_pt_2,E2)
				# if (len(final_reconstructed_point_ft_3) == 2):
					# reconstructed_max_ft_3,reconstructed_max_pt_3 = final_reconstructed_point_ft_3[1]
					# max_circle_arc_3 = pygplates.GreatCircleArc(reconstructed_max_pt_3,E3)
				
				# if (max_circle_arc_1 is not None):
					# i1, i2 = find_the_intersections_between_two_arcs(max_circle_arc_1,min_circle_arc_2)
					# if (is_point_on_the_arc(i1,min_circle_arc_3,0.500) == True):
						# #i1 is the triple junction
						# triple_junction = i1
					# elif (is_point_on_the_arc(i2,min_circle_arc_3,0.500) == True):
						# #i2 is the triple junction
						# triple_junction = i2
				# if (triple_junction is None and max_circle_arc_2 is not None):
					# i1, i2 = find_the_intersections_between_two_arcs(max_circle_arc_2,min_circle_arc_1)
					# if (is_point_on_the_arc(i1,min_circle_arc_3,0.500) == True):
						# #i1 is the triple junction
						# triple_junction = i1
					# elif (is_point_on_the_arc(i2,min_circle_arc_3,0.500) == True):
						# #i2 is the triple junction
						# triple_junction = i2
				# if (triple_junction is None and max_circle_arc_3 is not None):
					# i1, i2 = find_the_intersections_between_two_arcs(max_circle_arc_3,min_circle_arc_2)
					# if (is_point_on_the_arc(i1,min_circle_arc_1,0.500) == True):
						# #i1 is the triple junction
						# triple_junction = i1
					# elif (is_point_on_the_arc(i2,min_circle_arc_1,0.500) == True):
						# #i2 is the triple junction
						# triple_junction = i2
				# if (triple_junction is None and max_circle_arc_1 is not None and max_circle_arc_2 is not None):
					# i1, i2 = find_the_intersections_between_two_arcs(max_circle_arc_1,max_circle_arc_2)
					# if (is_point_on_the_arc(i1,min_circle_arc_3,0.500) == True):
						# #i1 is the triple junction
						# triple_junction = i1
					# elif (is_point_on_the_arc(i2,min_circle_arc_3,0.500) == True):
						# #i2 is the triple junction
						# triple_junction = i2
					# if (triple_junction is None and max_circle_arc_3 is not None):
						# if (is_point_on_the_arc(i1,max_circle_arc_3,0.500) == True):
							# #i1 is the triple junction
							# triple_junction = i1
						# elif (is_point_on_the_arc(i2,max_circle_arc_3,0.500) == True):
							# #i2 is the triple junction
							# triple_junction = i2
				# if (triple_junction is None and max_circle_arc_1 is not None and max_circle_arc_3 is not None):
					# i1, i2 = find_the_intersections_between_two_arcs(max_circle_arc_1,max_circle_arc_3)
					# if (is_point_on_the_arc(i1,min_circle_arc_2,0.500) == True):
						# #i1 is the triple junction
						# triple_junction = i1
					# elif (is_point_on_the_arc(i2,min_circle_arc_2,0.500) == True):
						# #i2 is the triple junction
						# triple_junction = i2
					# if (triple_junction is None and max_circle_arc_2 is not None):
						# if (is_point_on_the_arc(i1,max_circle_arc_2,0.500) == True):
							# #i1 is the triple junction
							# triple_junction = i1
						# elif (is_point_on_the_arc(i2,max_circle_arc_2,0.500) == True):
							# #i2 is the triple junction
							# triple_junction = i2
				# if (triple_junction is None and max_circle_arc_2 is not None and max_circle_arc_3 is not None):
					# i1, i2 = find_the_intersections_between_two_arcs(max_circle_arc_2,max_circle_arc_3)
					# if (is_point_on_the_arc(i1,min_circle_arc_1,0.500) == True):
						# #i1 is the triple junction
						# triple_junction = i1
					# elif (is_point_on_the_arc(i2,min_circle_arc_1,0.500) == True):
						# #i2 is the triple junction
						# triple_junction = i2
					# if (triple_junction is None and max_circle_arc_1 is not None):
						# if (is_point_on_the_arc(i1,max_circle_arc_1,0.500) == True):
							# #i1 is the triple junction
							# triple_junction = i1
						# elif (is_point_on_the_arc(i2,max_circle_arc_1,0.500) == True):
							# #i2 is the triple junction
							# triple_junction = i2
			triple_junction = None
			great_circle_arc_1, great_circle_arc_2, great_circle_arc_3 = None, None, None
			great_circle_arc_1 = pygplates.GreatCircleArc(final_pt_1, E1)
			great_circle_arc_2 = pygplates.GreatCircleArc(final_pt_2, E2)
			great_circle_arc_3 = pygplates.GreatCircleArc(final_pt_3, E3)
			
			i12, i21 = find_the_intersections_between_two_arcs(great_circle_arc_1, great_circle_arc_2)
			i23, i32 = find_the_intersections_between_two_arcs(great_circle_arc_2, great_circle_arc_3)
			i13, i31 = find_the_intersections_between_two_arcs(great_circle_arc_1, great_circle_arc_3)
			if (is_point_on_the_arc(i12, great_circle_arc_3, 0.500) == True):
				#i1 is the triple junction
				triple_junction = i12
			elif (is_point_on_the_arc(i21, great_circle_arc_3, 0.500) == True):
				triple_junction = i21
			elif (is_point_on_the_arc(i23, great_circle_arc_1, 0.500) == True):
				triple_junction = i23
			elif (is_point_on_the_arc(i32, great_circle_arc_1, 0.500) == True):
				triple_junction = i32
			elif (is_point_on_the_arc(i13, great_circle_arc_2, 0.500) == True):
				triple_junction = i13
			elif (is_point_on_the_arc(i31, great_circle_arc_2, 0.500) == True):
				triple_junction = i31
			output_records_of_rifts_for_junction.append((start_div_1, rift_name_1, lrepgduid_1, rrepgduid_1, start_div_2, rift_name_2, lrepgduid_2, rrepgduid_2, start_div_3, rift_name_3, lrepgduid_3, rrepgduid_3))
			if (triple_junction is not None):
				triple_junction_pt = pygplates.PointOnSphere(triple_junction.to_xyz())
				triple_junction = triple_junction_pt
				#create mid_point feature
				triple_junction_ft1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, triple_junction, valid_time = (youngest_start_div, 0.00))
				triple_junction_ft1.set_reconstruction_plate_id(lrepgduid_1)
				triple_junction_ft1.set_conjugate_plate_id(rrepgduid_1,verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft1.set_left_plate(lrepgduid_1,verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft1.set_right_plate(rrepgduid_1,verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft1.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
				#create mid_point feature
				triple_junction_ft2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, triple_junction, valid_time = (youngest_start_div, 0.00))
				triple_junction_ft2.set_reconstruction_plate_id(lrepgduid_2)
				triple_junction_ft2.set_conjugate_plate_id(rrepgduid_2,verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft2.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft2.set_left_plate(lrepgduid_2,verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft2.set_right_plate(rrepgduid_2,verify_information_model = pygplates.VerifyInformationModel.no)
				#create mid_point feature
				triple_junction_ft3 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, triple_junction, valid_time = (youngest_start_div, 0.00))
				triple_junction_ft3.set_reconstruction_plate_id(lrepgduid_3)
				triple_junction_ft3.set_conjugate_plate_id(rrepgduid_3,verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft3.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft3.set_left_plate(lrepgduid_3,verify_information_model = pygplates.VerifyInformationModel.no)
				triple_junction_ft3.set_right_plate(rrepgduid_3,verify_information_model = pygplates.VerifyInformationModel.no)
				if (reference is not None):
					pygplates.reverse_reconstruct([triple_junction_ft1,triple_junction_ft2,triple_junction_ft3],rotation_model,youngest_start_div,reference)
				else:
					pygplates.reverse_reconstruct([triple_junction_ft1,triple_junction_ft2,triple_junction_ft3],rotation_model,youngest_start_div)
				output_triple_junction_feats.add(triple_junction_ft1)
				output_triple_junction_feats.add(triple_junction_ft2)
				output_triple_junction_feats.add(triple_junction_ft3)
	output_triple_junction_feats.write("triple_junction_for_RRR_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)+"_"+modelname+"_"+yearmonthday+".shp")
def modify_end_age_of_triple_junction_RRR(temp_triple_junction_point_features, supergdu_features, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, time_interval, rotation_model, reference,  modelname, yearmonthday):
	output_modified_triple_junction_feats = pygplates.FeatureCollection()
	temp_triple_junction_point_features
	reconstructed_point_features = []
	reconstructed_polygon_features = []
	reconstruction_time = max_reconstruction_time_for_start_div
	while (reconstruction_time >= min_reconstruction_time_for_start_div):
		valid_triple_junction_point_fts = [ft for ft in temp_triple_junction_point_features if ft.is_valid_at_time(reconstruction_time)]
		valid_sgdu_fts = [ft for ft in supergdu_features if ft.is_valid_at_time(reconstruction_time)]
		if (reference is not None):
			pygplates.reconstruct(valid_triple_junction_point_fts, rotation_model, reconstructed_point_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(valid_sgdu_fts, rotation_model, reconstructed_polygon_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_triple_junction_point_fts, rotation_model, reconstructed_point_features, reconstruction_time, group_with_feature = True)
			pygplates.reconstruct(valid_sgdu_fts, rotation_model, reconstructed_polygon_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_point_feats = find_final_reconstructed_geometries(reconstructed_point_features, pygplates.PointOnSphere)
		final_reconstructed_polygon_feats = find_final_reconstructed_geometries(reconstructed_polygon_features, pygplates.PolygonOnSphere)
		for point_ft, reconstructed_point in final_reconstructed_point_feats:
			for polygon_ft, reconstructed_polygon in final_reconstructed_polygon_feats:
				if (reconstructed_polygon.is_point_in_polygon(reconstructed_point) == True):
					#edit end age of point_ft
					current_begin_age, current_end_age = point_ft.get_valid_time()
					if ((current_begin_age-reconstruction_time) > time_interval):
						point_ft.set_valid_time(current_begin_age, reconstruction_time + 0.1000)
						output_modified_triple_junction_feats.add(point_ft)
					break
		reconstruction_time = reconstruction_time - time_interval
	output_modified_triple_junction_feats.write("modify_triple_junction_RRR_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)+"_"+modelname+"_"+yearmonthday+".shp")
# def check_end_time_of_rift_point_features(rift_point_features_records_csv, temp_rift_point_features, time_interval, rotation_model, reference, modelname, yearmonthday):
	# #start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	# rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	# dic_of_rift = {}
	# output_reactivate_records = []
	# for rift_point_ft in temp_rift_point_features:
		# name = rift_point_ft.get_name()
		# list_of_components = name.split('_')
		# part_1 = list_of_components[0]
		# part_2 = list_of_components[1]
		# part_3 = list_of_components[2]
		# rift_name = part_1+'_'+part_2
		# if (rift_name not in dic_of_rift):
			# dic_of_rift[rift_name] = [rift_point_ft]
		# else:
			# dic_of_rift[rift_name].append(rift_point_ft)
	# for rift_name in dic_of_rift:
		# selected_rift_history_df = rift_history_df.loc[rift_history_df['rift_name'] == rift_name, ['start_div','lrepgduid','rrepgduid']]
		# if (len(selected_rift_history_df) == 0):
			# print("Error could not find any records for rift_name", rift_name)
			# exit()
		# list_of_wanted_rift_point_features = dic_of_rift[rift_name]
		# selected_rift_history_df_no_duplicates = selected_rift_history_df.drop_duplicates()
		# for start_div,lrepgduid, rrepgduid in selected_rift_history_df_no_duplicates.itertuples(index = False, name = None):
			# has_changed_previously = False
			# reconstruction_time = start_div-time_interval
			# while(reconstruction_time >= 0.00):
				# #total_relative_reconstruction_rotation_for_rift = find_total_relative_reconstruction_rotation_(rotation_model, lrepgduid, rrepgduid, float(reconstruction_time), reference)
				# #if (total_relative_reconstruction_rotation_for_rift.represents_identity_rotation() == True and reconstruction_time > 0.00):
				# for point_ft in list_of_wanted_rift_point_features:
					# stage_relative_reconstruction_rotation = find_stage_relative_reconstruction_rotation_(rotation_model,point_ft.get_left_plate(),point_ft.get_right_plate(),float(reconstruction_time)+time_interval,float(reconstruction_time),reference)
					# if (stage_relative_reconstruction_rotation.represents_identity_rotation() == True and reconstruction_time > 0.00):
						# if (has_changed_previously == False):
							# has_changed_previously = True
					
					
						# if (has_changed_previously == False):
							# begin_age, end_age = point_ft.get_valid_time()
							# point_ft.set_valid_time(begin_age, reconstruction_time)
						# else:
							# name = point_ft.get_name()
							# list_of_components = name.split('_')
							# part_1 = list_of_components[0]
							# sgdu_1 = None
							# num_characters = len(part_1)
							# for i in range(0,num_characters):
								# if (i == 1):
									# sgdu_1 = part_1[i]
								# elif (i > 1):
									# sgdu_1 = sgdu_1+part_1[i]
							# print(sgdu_1)
							# sgdu_2 = list_of_components[1]
							# output_reactivate_records.append((reconstruction_time,rift_name,name,float(point_ft.get_description()),lrepgduid, rrepgduid,int(sgdu_1),int(sgdu_2)))
				# reconstruction_time = reconstruction_time - time_interval
	# output_modified_rift_point_features = pygplates.FeatureCollection()
	# for rift_name in dic_of_rift:
		# list_of_wanted_rift_point_features = dic_of_rift[rift_name]
		# for modified_pt_ft in list_of_wanted_rift_point_features:
			# output_modified_rift_point_features.add(modified_pt_ft)
	# output_modified_rift_point_features.write("modified_end_time_of_rift_point_features_"+modelname+"_"+yearmonthday+".shp")
	
	# output_df = pd.DataFrame.from_records(output_reactivate_records,columns=['reconstruction_time','rift_name','rift_point_name','order','lrepgduid','rrepgduid','sgdu_1','sgdu_2'])
	# output_df.to_csv('reactive_rift_records_'+modelname+'_'+yearmonthday+'.csv')
	
def create_remnant_of_previous_MOR(temp_MOR_features, sgdu_features, rotation_model, reference, modelname, yearmonthday):
	output_remnant_features = pygplates.FeatureCollection()
	edited_MOR_features = pygplates.FeatureCollection()
	for temp_MOR_ft in temp_MOR_features:
		from_time_MOR,to_time_MOR = temp_MOR_ft.get_valid_time()
		plateID_1 = temp_MOR_ft.get_left_plate()
		plateID_2 = temp_MOR_ft.get_right_plate()
		sgdu_features_1 = []
		sgdu_features_2 = []
		for sgdu_ft in sgdu_features:
			if (sgdu_ft.get_reconstruction_plate_id() == plateID_1 and sgdu_ft.is_valid_at_time(from_time_MOR)):
				sgdu_features_1.append(sgdu_ft)
		for sgdu_ft in sgdu_features:
			if (sgdu_ft.get_reconstruction_plate_id() == plateID_2 and sgdu_ft.is_valid_at_time(from_time_MOR)):
				sgdu_features_2.append(sgdu_ft)
		# clone_MOR_ft_for_left = temp_MOR_ft.clone()
		# clone_MOR_ft_for_right = temp_MOR_ft.clone()
		# clone_MOR_ft_for_left.set_reconstruction_plate_id(plateID_1)
		# clone_MOR_ft_for_right.set_reconstruction_plate_id(plateID_2)
		#clone_MOR_ft_for_left.set_reconstruction_method('ByPlateId')
		#clone_MOR_ft_for_right.set_reconstruction_method('ByPlateId')
		reconstructed_MOR_features = []
		reconstructed_sgdu_features_1 = []
		reconstructed_sgdu_features_2 = []
		if (reference is not None):
			pygplates.reconstruct(temp_MOR_ft,rotation_model,reconstructed_MOR_features,from_time_MOR,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(sgdu_features_1,rotation_model,reconstructed_sgdu_features_1,from_time_MOR,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(sgdu_features_2,rotation_model,reconstructed_sgdu_features_2,from_time_MOR,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(temp_MOR_ft,rotation_model,reconstructed_MOR_features,from_time_MOR,group_with_feature = True)
			pygplates.reconstruct(sgdu_features_1,rotation_model,reconstructed_sgdu_features_1,from_time_MOR,group_with_feature = True)
			pygplates.reconstruct(sgdu_features_2,rotation_model,reconstructed_sgdu_features_2,from_time_MOR,group_with_feature = True)
		final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PolylineOnSphere)
		final_reconstructed_sgdu_fts_1 = find_final_reconstructed_geometries(reconstructed_sgdu_features_1,pygplates.PolygonOnSphere)
		final_reconstructed_sgdu_fts_2 = find_final_reconstructed_geometries(reconstructed_sgdu_features_2,pygplates.PolygonOnSphere)
		reconstructed_MOR_ft,reconstructed_MOR = final_reconstructed_MOR_fts[0]
		
		approx_mid_point = reconstructed_MOR.get_centroid()
		potential_left = None
		potential_right = None
		for ft_1,polygon_1 in final_reconstructed_sgdu_fts_1:
			centroid_1 = polygon_1.get_interior_centroid()
			x1,y1,z1 = centroid_1.to_xyz()
			magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(approx_mid_point,x1,y1,z1)
			if (azimuth <= math.pi):
				potential_left = plateID_1
				break
			elif (azimuth > math.pi):
				potential_right = plateID_1
				break
		if (potential_left == plateID_1):
			for ft_2,polygon_2 in final_reconstructed_sgdu_fts_2:
				centroid_2 = polygon_2.get_interior_centroid()
				x2,y2,z2 = centroid_2.to_xyz()
				magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(approx_mid_point,x2,y2,z2)
				if (azimuth > math.pi):
					potential_right = plateID_2
					break
		elif (potential_right == plateID_1):
			for ft_2,polygon_2 in final_reconstructed_sgdu_fts_2:
				centroid_2 = polygon_2.get_interior_centroid()
				x2,y2,z2 = centroid_2.to_xyz()
				magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(approx_mid_point,x2,y2,z2)
				if (azimuth <= math.pi):
					potential_left = plateID_2
					break
		if (potential_left is not None and potential_right is None):
			if (potential_left == plateID_1):
				potential_right = plateID_2
			else:
				potential_right = plateID_1
		elif (potential_left is None and potential_right is not None):
			if (potential_right == plateID_1):
				potential_left = plateID_2
			else:
				potential_left = plateID_1
		
		left_oceanic_crust_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, reconstructed_MOR, valid_time = (from_time_MOR,to_time_MOR))
		left_oceanic_crust_ft.set_reconstruction_plate_id(potential_left)
		left_oceanic_crust_ft.set_name(temp_MOR_ft.get_name())
		left_oceanic_crust_ft.set_left_plate(potential_left,verify_information_model = pygplates.VerifyInformationModel.no)
		left_oceanic_crust_ft.set_right_plate(potential_right,verify_information_model = pygplates.VerifyInformationModel.no)
		
		right_oceanic_crust_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, reconstructed_MOR, valid_time = (from_time_MOR,to_time_MOR))
		right_oceanic_crust_ft.set_reconstruction_plate_id(potential_right)
		right_oceanic_crust_ft.set_name(temp_MOR_ft.get_name())
		right_oceanic_crust_ft.set_left_plate(potential_left,verify_information_model = pygplates.VerifyInformationModel.no)
		right_oceanic_crust_ft.set_right_plate(potential_right,verify_information_model = pygplates.VerifyInformationModel.no)
		
		temp_MOR_ft.set_left_plate(potential_left)
		temp_MOR_ft.set_right_plate(potential_right)
		
		if (reference is not None):
			pygplates.reverse_reconstruct([left_oceanic_crust_ft,right_oceanic_crust_ft],rotation_model,from_time_MOR,reference)
		else:
			pygplates.reverse_reconstruct([left_oceanic_crust_ft,right_oceanic_crust_ft],rotation_model,from_time_MOR)
		output_remnant_features.add(left_oceanic_crust_ft)
		output_remnant_features.add(right_oceanic_crust_ft)
		edited_MOR_features.add(temp_MOR_ft)
	output_remnant_features.write('remnant_of_previous_MOR_'+modelname+'_'+yearmonthday+'.shp')
	edited_MOR_features.write('edited_temp_MOR_'+modelname+'_'+yearmonthday+'.shp')

def find_unwanted_temp_rift_point_features(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday):
	dic_rift_name = {'rift_name':[]}
	#NEW --- find not wanted rift point feature
	list_of_unwanted_rift_point_features = []
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (max_reconstruction_time_for_start_div is not None):
		selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] <= max_reconstruction_time_for_start_div]
	if (min_reconstruction_time_for_start_div is not None):
		new_selected_rift_history_df = None
		if (selected_rift_history_df is not None):
			new_selected_rift_history_df = selected_rift_history_df.loc[selected_rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		else:
			new_selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] > min_reconstruction_time_for_start_div]
		if (new_selected_rift_history_df is not None):
			selected_rift_history_df = new_selected_rift_history_df
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		descending_order_array = np.flip(sorted_array_of_start_div)
		#NEW
		start_div = descending_order_array[0]
		array_of_order_for_unwanted_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['start_div'] == start_div) & (rift_history_df['lpolylid'].isna()) & (rift_history_df['rpolylid'].isna()),'order'].to_numpy()
		for order in array_of_order_for_unwanted_rift_points:
			name_of_rift_point_ft = rift_name+'_'+str(order)
			if (name_of_rift_point_ft not in dic_rift_name['rift_name']):
				dic_rift_name['rift_name'].append(name_of_rift_point_ft)
	output_df = pd.DataFrame.from_dict(dic_rift_name)
	output_df.to_csv("unwanted_temp_rift_point_features_"+modelname+"_"+yearmonthday+".csv")

def create_isochron_from_unwanted_temp_rift_point_features(temp_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday):
	dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	temp_isochron_from_MOR = pygplates.FeatureCollection()
	output_left_line_features = pygplates.FeatureCollection()
	output_right_line_features = pygplates.FeatureCollection()
	output_right_point_features = pygplates.FeatureCollection()
	output_left_point_features = pygplates.FeatureCollection()
	dic_of_new_kin_fts = {}
	dic_of_supergdu_and_gdu_members = {}
	dic_of_mor_interacts_bdn = {'reconstruction_time':[],'bdn_polylid':[],'rift_name':[],'rift_side':[]}
	reconstructed_sgdu_features = []
	reconstructed_gdu_features = []
	reconstructed_div_features = []
	reconstructed_line_features = []
	reconstructed_rift_point_features = []
	#list_of_unwanted_rift_point_features = []
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (max_reconstruction_time_for_start_div is not None):
		selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] <= max_reconstruction_time_for_start_div]
	if (min_reconstruction_time_for_start_div is not None):
		new_selected_rift_history_df = None
		if (selected_rift_history_df is not None):
			new_selected_rift_history_df = selected_rift_history_df.loc[(selected_rift_history_df['start_div'] > min_reconstruction_time_for_start_div)& (rift_history_df['lpolylid'].isna()) & (rift_history_df['rpolylid'].isna())]
		else:
			new_selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] > min_reconstruction_time_for_start_div)& (rift_history_df['lpolylid'].isna()) & (rift_history_df['rpolylid'].isna())]
		if (new_selected_rift_history_df is not None):
			selected_rift_history_df = new_selected_rift_history_df
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		# div_line_names_for_left_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'lpolylid'].unique()
		# div_line_names_for_right_of_MOR = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'rpolylid'].unique()
		# array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'order'].to_numpy()
		array_of_start_div = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name),'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		descending_order_array = np.flip(sorted_array_of_start_div)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		#NEW
		start_div = descending_order_array[0]
		list_of_wanted_rift_point_features = []
		for rift_point_ft in temp_rift_point_features:
			rift_point_ft_name = rift_point_ft.get_name()
			list_of_splits = rift_point_ft_name.split("_")
			rift_name_of_pt_ft = list_of_splits[0]+'_'+list_of_splits[1]
			if (rift_name_of_pt_ft == rift_name):
				found_point_ft = rift_point_ft
				list_of_wanted_rift_point_features.append(found_point_ft)
		if (len(list_of_wanted_rift_point_features) == 0):
			print("Error could not find the wanted rift point feature")
			print("rift_name",rift_name)
			exit()
		reconstructed_rift_point_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(list_of_wanted_rift_point_features, rotation_model, reconstructed_rift_point_features, start_div, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(list_of_wanted_rift_point_features, rotation_model, reconstructed_rift_point_features, start_div, group_with_feature = True)
		final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features,pygplates.PointOnSphere)
		list_of_left_isochron_point_features = []
		list_of_right_isochron_point_features = []
		for rift_pt_ft,rift_pt in final_reconstructed_rift_point_fts:
			left_isochron_pt_ft, right_isochron_pt_ft = create_left_and_right_div_fts_from_MOR_ft(rift_pt_ft,rift_pt, start_div, 0.00)
			list_of_left_isochron_point_features.append(left_isochron_pt_ft)
			list_of_right_isochron_point_features.append(right_isochron_pt_ft)
			
		if (reference is not None):
			if (len(list_of_left_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_left_isochron_point_features,rotation_model,start_div,reference)
			if (len(list_of_right_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_right_isochron_point_features,rotation_model,start_div,reference)
		else:
			if (len(list_of_left_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_left_isochron_point_features,rotation_model,start_div)
			if (len(list_of_right_isochron_point_features) > 0):
				pygplates.reverse_reconstruct(list_of_right_isochron_point_features,rotation_model,start_div)
		# list_of_valid_associated_div_line_feats = []
		# for line_ft in associated_div_line_features:
			# if (line_ft.is_valid_at_time(reconstruction_time)):
				# if (line_ft.get_name() in div_line_names_for_left_of_MOR):
					# list_of_valid_associated_div_line_feats.append(line_ft)
				# elif (line_ft.get_name() in div_line_names_for_right_of_MOR):
					# list_of_valid_associated_div_line_feats.append(line_ft)
		# list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in plate_boundary_zone_boundaries if con_ocn_line_ft.is_valid_at_time(start_div)]
		# final_reconstructed_div_features = None
		# if (len(list_of_valid_associated_div_line_feats) != 0.00):
			# reconstructed_div_features[:] = []
			# if (reference is not None):
				# pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# else:
				# pygplates.reconstruct(list_of_valid_associated_div_line_feats,rotation_model,reconstructed_div_features,reconstruction_time,group_with_feature = True)
			# final_reconstructed_div_features = find_final_reconstructed_geometries(reconstructed_div_features,pygplates.PolylineOnSphere)

		reconstructed_left_point_features = []
		reconstructed_right_point_features = []
		list_of_tuples_for_descrp_reconstr_pts = []
		reconstruction_time = start_div - time_interval
		list_of_valid_rift_point_features = [rift_point_ft for rift_point_ft in list_of_wanted_rift_point_features if rift_point_ft.is_valid_at_time(reconstruction_time)]
		while(reconstruction_time >= 0.00):
			final_reconstructed_rift_point_fts = None
			reconstructed_sgdu_features[:] = []
			reconstructed_gdu_features[:] = []
			list_of_valid_sgdu_fts = [sgdu_ft for sgdu_ft in sgdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_sgdu_fts,rotation_model,reconstructed_sgdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_sgdu_fts,rotation_model,reconstructed_sgdu_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_sgdu_fts = find_final_reconstructed_geometries(reconstructed_sgdu_features,pygplates.PolygonOnSphere)
			#list_of_valid_gdu_fts = [gdu_ft for gdu_ft in gdu_features if gdu_ft.is_valid_at_time(reconstruction_time)]
			#if (reference is not None):
			#	pygplates.reconstruct(list_of_valid_gdu_fts,rotation_model,reconstructed_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			#else:
			#	pygplates.reconstruct(list_of_valid_gdu_fts,rotation_model,reconstructed_gdu_features,reconstruction_time,group_with_feature = True)
			#final_reconstructed_gdu_fts = find_final_reconstructed_geometries(reconstructed_gdu_features,pygplates.PolygonOnSphere)
			remaining_tuples_rift_point_features = None
			
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temporary_sgdu_and_member_csv_at_time = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			temp_sgdu_and_gdu_df = pd.read_csv(temporary_sgdu_and_member_csv_at_time, delimiter = ';', header = 0)
			for valid_supergdu_ft in list_of_valid_sgdu_fts:
				sgdu_begin,_ = valid_supergdu_ft.get_valid_time()
				initial_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(sgdu_begin))
				#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
				initial_df = pd.read_csv(initial_sgdu_and_members_csv, delimiter = ';', header = 0)
				if (valid_supergdu_ft.get_name() not in dic_of_supergdu_and_gdu_members):
					unique_sgdus = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['repGDUID'] == valid_supergdu_ft.get_reconstruction_plate_id())|(temp_sgdu_and_gdu_df['GDUID'] == valid_supergdu_ft.get_reconstruction_plate_id()),'SGDUID'].unique()
					records_of_gdu_members = []
					for sgdu in unique_sgdus:
						temp_members = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['SGDUID'] == sgdu),'GDUID'].unique()
						for temp_mem in temp_members:
							if (temp_mem not in records_of_gdu_members):
								records_of_gdu_members.append(temp_mem)
					temp_members = initial_df.loc[(initial_df['SGDUID'] == int(valid_supergdu_ft.get_name())),'GDUID'].unique()
					for temp_mem in temp_members:
						if (temp_mem not in records_of_gdu_members):
							records_of_gdu_members.append(temp_mem)
					dic_of_supergdu_and_gdu_members[valid_supergdu_ft.get_name()] = records_of_gdu_members
			
			if (len(list_of_valid_rift_point_features) > 0):
				list_of_tuples_for_descrp_reconstr_pts[:] = []
				remaining_tuples_rift_point_features = []
				reconstructed_rift_point_features[:] = []
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_rift_point_features,rotation_model,reconstructed_rift_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_rift_point_fts = find_final_reconstructed_geometries(reconstructed_rift_point_features,pygplates.PointOnSphere)
				for reconstruct_rift_ft, reconstructed_rift_point in final_reconstructed_rift_point_fts:
					array_of_SGDUID_of_rift_ft_from_left = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstruct_rift_ft.get_left_plate(),'SGDUID'].unique()
					array_of_SGDUID_of_rift_ft_from_right = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstruct_rift_ft.get_left_plate(),'SGDUID'].unique()
					is_inside_sgdu = False
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
							is_inside_sgdu = True
							#checking whether GDU overlaps in the initial reconstruction model
							is_inside_left_gdu_polygon = None
							is_inside_right_gdu_polygon = None
							list_of_gdu_members_for_current_sgdu = dic_of_supergdu_and_gdu_members[reconstructed_sgdu_ft.get_name()]
							if (reconstruct_rift_ft.get_left_plate() in list_of_gdu_members_for_current_sgdu):
								is_inside_left_gdu_polygon = reconstructed_sgdu
								for tested_reconstructed_sgdu_ft, tested_reconstructed_sgdu in final_reconstructed_sgdu_fts:
									if (tested_reconstructed_sgdu_ft.get_name() != reconstructed_sgdu_ft.get_name()):
										if (tested_reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
											list_of_gdu_members_for_other_current_sgdu = dic_of_supergdu_and_gdu_members[tested_reconstructed_sgdu_ft.get_name()]
											if (reconstruct_rift_ft.get_right_plate() in list_of_gdu_members_for_other_current_sgdu):
												is_inside_right_gdu_polygon = tested_reconstructed_sgdu
									if (is_inside_right_gdu_polygon is not None and is_inside_left_gdu_polygon is not None):
										if (pygplates.GeometryOnSphere.distance(is_inside_left_gdu_polygon, is_inside_right_gdu_polygon) == 0.00):
											is_inside_sgdu = False
											break
							elif (reconstruct_rift_ft.get_right_plate() in list_of_gdu_members_for_current_sgdu):
								is_inside_right_gdu_polygon = reconstructed_sgdu
								for tested_reconstructed_sgdu_ft, tested_reconstructed_sgdu in final_reconstructed_sgdu_fts:
									if (tested_reconstructed_sgdu_ft.get_name() != reconstructed_sgdu_ft.get_name()):
										if (tested_reconstructed_sgdu.is_point_in_polygon(reconstructed_rift_point) == True):
											list_of_gdu_members_for_other_current_sgdu = dic_of_supergdu_and_gdu_members[tested_reconstructed_sgdu_ft.get_name()]
											if (reconstruct_rift_ft.get_left_plate() in list_of_gdu_members_for_other_current_sgdu):
												is_inside_left_gdu_polygon = tested_reconstructed_sgdu
									if (is_inside_right_gdu_polygon is not None and is_inside_left_gdu_polygon is not None):
										if (pygplates.GeometryOnSphere.distance(is_inside_left_gdu_polygon, is_inside_right_gdu_polygon) == 0.00):
											is_inside_sgdu = False
											break
							break
					if (is_inside_sgdu == True):
						dic_of_invalid_rift_point_fts['reconstruction_time'].append(reconstruction_time)
						dic_of_invalid_rift_point_fts['rift_point_name'].append(reconstruct_rift_ft.get_name())
					else:
						remaining_tuples_rift_point_features.append((reconstruct_rift_ft, reconstructed_rift_point))
				if (len(remaining_tuples_rift_point_features) > 0):
					list_of_remaining_rift_features,list_of_remaining_rift_points = list(zip(*remaining_tuples_rift_point_features))
					list_of_valid_rift_point_features = list_of_remaining_rift_features
				else:
					list_of_valid_rift_point_features = []
					
			reconstructed_line_features[:] = []
			list_of_valid_con_ocn_line_fts = [con_ocn_line_ft for con_ocn_line_ft in plate_boundary_zone_boundaries if con_ocn_line_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(list_of_valid_con_ocn_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_line_fts = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
			
			reconstructed_left_point_features[:] = []
			list_of_tuples_for_descrp_reconstr_pts[:] = []
			remaining_left_point_features = []
			if (len(list_of_left_isochron_point_features) > 0):
				list_of_valid_left_isochron_point_features = [left_ft for left_ft in list_of_left_isochron_point_features if left_ft.is_valid_at_time(reconstruction_time)]
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_left_isochron_point_features,rotation_model,reconstructed_left_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_left_isochron_point_features,rotation_model,reconstructed_left_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_left_point_fts = find_final_reconstructed_geometries(reconstructed_left_point_features,pygplates.PointOnSphere)
				for reconstruct_left_ft, reconstructed_left_point in final_reconstructed_left_point_fts:
					is_inside_sgdu = False
					list_of_tuples_for_descrp_reconstr_pts.append((float(reconstruct_left_ft.get_description()),reconstructed_left_point))
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_left_point) == True):
							is_inside_sgdu = True
							break
					if (is_inside_sgdu == True):
						current_begin_age,_ = reconstruct_left_ft.get_valid_time()
						reconstruct_left_ft.set_valid_time(current_begin_age, reconstruction_time)
						output_left_point_features.add(reconstruct_left_ft)
						#list_of_already_modified_features.add(reconstruct_left_ft.get_feature_id().get_string())
						#identify possible subduction zone
						#make sure to get the order of the point to create the line feature 
						#list_of_tuples_for_descrp_reconstr_pts.append((reconstruct_left_ft.get_description(),reconstructed_left_point))
					else:
						remaining_left_point_features.append(reconstruct_left_ft)
			if (len(list_of_tuples_for_descrp_reconstr_pts) > 1 and len(list_of_valid_con_ocn_line_fts) > 0):
				list_of_tuples_for_descrp_reconstr_pts.sort()#based on the order or the small circle angular radius
				list_of_order_for_fts,list_of_left_pts = list(zip(*list_of_tuples_for_descrp_reconstr_pts))
				temporary_left_line = pygplates.PolylineOnSphere(list_of_left_pts)
				#find the plate boundary zone line feature crossing temporary left line --- Only need to check the orientation of the line if the line represent an MOR
				for unclassified_line_ft, unclassified_line in final_reconstructed_line_fts:
					if (pygplates.GeometryOnSphere.distance(unclassified_line, temporary_left_line) == 0.00):
						name_of_line_ft = unclassified_line_ft.get_name()
						if (name_of_line_ft in dic_of_new_kin_fts):
							dic_of_mor_interacts_bdn['reconstruction_time'].append(reconstruction_time)
							dic_of_mor_interacts_bdn['bdn_polylid'].append(name_of_line_ft)
							dic_of_mor_interacts_bdn['rift_name'].append(rift_name)
							dic_of_mor_interacts_bdn['rift_side'].append('L')
						else:
							#create subduction zone
							begin_age_line_ft_1,end_age_line_ft_1 = unclassified_line_ft.get_valid_time()
							if (end_age_line_ft_1 <= reconstruction_time):
								line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name = name_of_line_ft,valid_time = (reconstruction_time,end_age_line_ft_1))
								line_feature_1.set_reconstruction_plate_id(unclassified_line_ft.get_reconstruction_plate_id())
								line_feature_1.set_description('upper_gdu_margin')
								if (reference is None):
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time)
								else:
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time,reference)
								dic_of_new_kin_fts[name_of_line_ft] = line_feature_1
				temp_left_line_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_isochron,temporary_left_line,name = rift_name,valid_time = (reconstruction_time,reconstruction_time-time_interval+0.100))
				if (reference is not None):
					temp_left_line_feature.set_reconstruction_plate_id(reference)
					pygplates.reverse_reconstruct(temp_left_line_feature,rotation_model,reconstruction_time,reference)
				else:
					temp_left_line_feature.set_reconstruction_plate_id(0)
					pygplates.reverse_reconstruct(temp_left_line_feature,rotation_model,reconstruction_time)
				temp_left_line_feature.set_description('left_margin')
				output_left_line_features.add(temp_left_line_feature)
			list_of_left_isochron_point_features = remaining_left_point_features
			
			list_of_tuples_for_descrp_reconstr_pts[:] = []
			remaining_right_point_features = []
			reconstructed_right_point_features[:] = []
			if (len(list_of_right_isochron_point_features) > 0):
				list_of_valid_right_isochron_point_features = [right_ft for right_ft in list_of_right_isochron_point_features if right_ft.is_valid_at_time(reconstruction_time)]
				if (reference is not None):
					pygplates.reconstruct(list_of_valid_right_isochron_point_features,rotation_model,reconstructed_right_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_valid_right_isochron_point_features,rotation_model,reconstructed_right_point_features,reconstruction_time,group_with_feature = True)
				final_reconstructed_right_point_fts = find_final_reconstructed_geometries(reconstructed_right_point_features,pygplates.PointOnSphere)
				for reconstruct_right_ft, reconstructed_right_point in final_reconstructed_right_point_fts:
					is_inside_sgdu = False
					list_of_tuples_for_descrp_reconstr_pts.append((float(reconstruct_right_ft.get_description()),reconstructed_right_point))
					for reconstructed_sgdu_ft, reconstructed_sgdu in final_reconstructed_sgdu_fts:
						if (reconstructed_sgdu.is_point_in_polygon(reconstructed_right_point) == True):
							is_inside_sgdu = True
							break
					if (is_inside_sgdu == True):
						current_begin_age,_ = reconstruct_right_ft.get_valid_time()
						reconstruct_right_ft.set_valid_time(current_begin_age, reconstruction_time)
						output_right_point_features.add(reconstruct_right_ft)
						#list_of_already_modified_features.add(reconstruct_right_ft.get_feature_id().get_string())
						#identify possible subduction zone
						#make sure to get the order of the point to create the line feature 
						#list_of_tuples_for_descrp_reconstr_pts.append((reconstruct_right_ft.get_description(),reconstructed_right_point))
					else:
						remaining_right_point_features.append(reconstruct_right_ft)
			if (len(list_of_tuples_for_descrp_reconstr_pts) > 1 and len(list_of_valid_con_ocn_line_fts) > 0):
				list_of_tuples_for_descrp_reconstr_pts.sort()#based on the order or the small circle angular radius
				list_of_order_for_fts,list_of_right_pts = list(zip(*list_of_tuples_for_descrp_reconstr_pts))
				temporary_right_line = pygplates.PolylineOnSphere(list_of_right_pts)
				#find the plate boundary zone line feature crossing temporary left line --- Only need to check the orientation of the line if the line represent an MOR
				for unclassified_line_ft, unclassified_line in final_reconstructed_line_fts:
					if (pygplates.GeometryOnSphere.distance(unclassified_line, temporary_right_line) == 0.00):
						name_of_line_ft = unclassified_line_ft.get_name()
						if (name_of_line_ft in dic_of_new_kin_fts):
							dic_of_mor_interacts_bdn['reconstruction_time'].append(reconstruction_time)
							dic_of_mor_interacts_bdn['bdn_polylid'].append(name_of_line_ft)
							dic_of_mor_interacts_bdn['rift_name'].append(rift_name)
							dic_of_mor_interacts_bdn['rift_side'].append('R')
						else:
							#create subduction zone
							begin_age_line_ft_1,end_age_line_ft_1 = unclassified_line_ft.get_valid_time()
							if (end_age_line_ft_1 <= reconstruction_time):
								line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone,unclassified_line,name = name_of_line_ft,valid_time = (reconstruction_time,end_age_line_ft_1))
								line_feature_1.set_reconstruction_plate_id(unclassified_line_ft.get_reconstruction_plate_id())
								line_feature_1.set_description('upper_gdu_margin')
								if (reference is None):
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time)
								else:
									pygplates.reverse_reconstruct(line_feature_1,rotation_model,reconstruction_time,reference)
								dic_of_new_kin_fts[name_of_line_ft] = line_feature_1
				temp_right_line_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_isochron,temporary_right_line,name = rift_name,valid_time = (reconstruction_time,reconstruction_time-time_interval+0.100))
				if (reference is not None):
					temp_right_line_feature.set_reconstruction_plate_id(reference)
					pygplates.reverse_reconstruct(temp_right_line_feature,rotation_model,reconstruction_time,reference)
				else:
					temp_right_line_feature.set_reconstruction_plate_id(0)
					pygplates.reverse_reconstruct(temp_right_line_feature,rotation_model,reconstruction_time)
				temp_right_line_feature.set_description('right_margin')
				output_right_line_features.add(temp_right_line_feature)
			list_of_right_isochron_point_features = remaining_right_point_features
			#create a new left and right isochron
			if (len(list_of_valid_rift_point_features) > 0 and remaining_tuples_rift_point_features is not None):
				if (len(remaining_tuples_rift_point_features) > 0):
					for rift_pt_ft,rift_pt in remaining_tuples_rift_point_features:
						left_isochron_pt_ft, right_isochron_pt_ft = create_left_and_right_div_fts_from_MOR_ft(rift_pt_ft, rift_pt, reconstruction_time, 0.00)
						if (reference is not None):
							pygplates.reverse_reconstruct(left_isochron_pt_ft,rotation_model,reconstruction_time,reference)
							pygplates.reverse_reconstruct(right_isochron_pt_ft,rotation_model,reconstruction_time,reference)
						else:
							pygplates.reverse_reconstruct(left_isochron_pt_ft,rotation_model,reconstruction_time)
							pygplates.reverse_reconstruct(right_isochron_pt_ft,rotation_model,reconstruction_time)
						list_of_left_isochron_point_features.append(left_isochron_pt_ft)
						list_of_right_isochron_point_features.append(right_isochron_pt_ft)
			reconstruction_time = reconstruction_time-time_interval
			if (reconstruction_time == 0.00):
				if (len(list_of_right_isochron_point_features) > 0):
					for right_point_ft in list_of_right_isochron_point_features:
						output_right_point_features.add(right_point_ft)
				if (len(list_of_left_isochron_point_features) > 0):
					for left_point_ft in list_of_left_isochron_point_features:
						output_left_point_features.add(left_point_ft)
		
	df_invalid_rift = pd.DataFrame.from_dict(dic_of_invalid_rift_point_fts)
	df_invalid_rift.to_csv('records_of_invalid_rift_from_unwanted_rift_'+modelname+'_'+yearmonthday+'.csv',index=False)
	
	df_mor_interacts_bdn = pd.DataFrame.from_dict(dic_of_mor_interacts_bdn)
	df_mor_interacts_bdn.to_csv('records_of_mor_interacts_bdn_from_unwanted_rift_'+modelname+'_'+yearmonthday+'.csv',index=False)
	
	output_new_kin_line_features = pygplates.FeatureCollection()
	for polylid_of_new_kin_line in dic_of_new_kin_fts:
		new_kin_line_ft = dic_of_new_kin_fts[polylid_of_new_kin_line]
		output_new_kin_line_features.add(new_kin_line_ft)
	output_new_kin_line_features.write('subduction_zone_features_from_unwanted_rift_'+modelname+'_'+yearmonthday+'.shp')
	
	output_right_line_features.write('temp_right_line_features_from_unwanted_rift_'+modelname+'_'+yearmonthday+'.shp')
	output_left_line_features.write('temp_left_line_features_from_unwanted_rift_'+modelname+'_'+yearmonthday+'.shp')
	output_right_point_features.write('isochron_right_point_features_from_unwanted_rift_'+modelname+'_'+yearmonthday+'.shp')
	output_left_point_features.write('isochron_left_point_features_from_unwanted_rift_'+modelname+'_'+yearmonthday+'.shp')

def main():
	# temp_MOR_file = r"temporary_MOR_line_feat_for_PalaeoPlatesendOct2022_w_1_deg_20230507.shp"
	# temp_MOR_features = pygplates.FeatureCollection(temp_MOR_file)
	# sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	# rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# sgdu_history_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\sgdu_history_for__test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230426.csv"
	common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	# extra_sgdu_history_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\tectonic_boundaries\extra_sgdu_history_for__test_8_PalaeoPlatesJan2023_20230501.csv"
	
	#temp_MOR_file = r"temporary_MOR_line_feat_for_PalaeoPlatesendOct2022_w_1_deg_20230507.shp"
	# temp_MOR_file = r"temporary_MOR_line_feat_for_test_5_PalaeoPlatesendOct2022_w_1_deg_20230512.shp"
	# temp_MOR_features = pygplates.FeatureCollection(temp_MOR_file)
	sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	#sgdu_history_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/sgdu_history_for__test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230426.csv"
	#extra_sgdu_history_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/extra_sgdu_history_for__test_8_PalaeoPlatesJan2023_20230501.csv"

	time_interval = 5.00
	max_reconstruction_time_for_start_div = 1000.00
	min_reconstruction_time_for_start_div = 800
	reference = 700
	modelname = "test_23_PalaeoPlatesJan2023_fts_from_early_July_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	yearmonthday = "20230716"
	
	#edit_temporary_MOR_w_superGDU(temp_MOR_features, sgdu_features, sgdu_history_csv, extra_sgdu_history_csv, rotation_model, time_interval, reference, modelname, yearmonthday)
	
	# associated_div_line_file = r"diverging_line_features_for_test_5_PalaeoPlatesendOct2022_w_1_deg_20230512.shp"
	# associated_div_line_features = pygplates.FeatureCollection(associated_div_line_file)
	# rift_point_features_records_csv = r"rift_point_features_records_for_test_5_PalaeoPlatesendOct2022_w_1_deg_20230512.csv"
	# threshold_period = 10.00
	#edit_temporary_MOR_w_associated_div_line_features(temp_MOR_features, associated_div_line_features, rift_point_features_records_csv, threshold_period, time_interval, rotation_model,reference, modelname, yearmonthday)
	
	# temp_rift_point_features_file = r"rift_point_features_for_test_20_short_PalaeoPlatesendOct2022_w_1_deg_20230705.shp"
	# temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
	# rift_point_features_records_csv = r"rift_point_features_records_for_test_20_short_PalaeoPlatesendOct2022_w_1_deg_20230705.csv"
	# plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_PalaeoPlatesendJan2023_from_1000Ma_20230708.shp"
	# plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
	# create_isochron_from_temp_rift_point_features(temp_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)
	#create_remnant_of_previous_MOR(temp_MOR_features, sgdu_features, rotation_model, reference, modelname, yearmonthday)
	
	modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
	rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	records_of_kin_line_feats_from_conv = r"pairs_of_kin_line_fts_from_conv_bdn_process_for_test_30_short_conv_PalaeoPlatesJan2023_20231023.csv"
	records_of_kin_line_feats_from_div = r"pairs_of_kin_line_fts_from_div_bdn_process_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	maximum_reconstruction_time = 1465.00
	minimum_reconstruction_time = 1460.00
	time_interval = 5.00
	modelname = "PalaeoPlatesendJan2023" 
	yearmonthday = "20231215"
	#modified_end_age_of_rift_point_features_based_on_kinematic_records(rift_point_features_records_csv,modified_rift_point_features,records_of_kin_line_feats_from_conv,records_of_kin_line_feats_from_div,maximum_reconstruction_time,minimum_reconstruction_time,time_interval,modelname,yearmonthday)
	
	temp_rift_point_features_for_interval = r""
	max_reconstruction_time_for_start_div = 2800.0
	min_reconstruction_time_for_start_div = 0.00
	
	#modify_end_age_of_rift_point_features_based_on_spatial_rlx_with_polygon_fts_alone(temp_rift_point_features_for_interval, sgdu_features, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)
	
# if __name__ == '__main__':
	# main()