import sys
import copy
import os
import csv
import enum
import math
import gc
from statistics import mean	 
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import numpy as np
from shapely.geometry import Point, Polygon, LineString, MultiPoint, MultiPolygon
from shapely.ops import unary_union, transform 
from shapely.validation import explain_validity 
from functools import partial
import pyproj
import psycopg2
from config_plate_tectonics import config

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def get_midpoint_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_last_point_of_line is None")
		exit()
	if (len(polyline_on_sphere.to_lat_lon_list()) == 2):
		mid_point = polyline_on_sphere.get_centroid()
		return mid_point
	else:
		mid_point_index = int(len(polyline_on_sphere.to_lat_lon_list())/2)
		return pygplates.PointOnSphere(polyline_on_sphere[mid_point_index])

	
#A function to calculate the distance between two points on the sphere - specifically the Earth 
#I could have used haversine module for python, but for the purpose of practise, I do it myself
#According to the formula from https://www.igismap.com/haversine-formula-calculate-geographic-distance-earth/, 
#a = sin^2(Difference in latitudes/2)+cos(lat1)*cos(lat2)*sin^2(Difference in longitude/2)
#c = 2*atan2(sqrt(a),sqrt(1-a))
#d = Radius of the sphere * c
def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def calculate_the_actual_length_of_a_line_in_km(current_line):
	if (current_line is None):
		print ("Error in calculate_the_actual_length_of_a_line_feature_in_km")
		print ("Error input line is None")
		exit()
	else:#if line is NOT None
		current_first_point = get_first_point_of_line(current_line)	
		current_last_point = get_last_point_of_line(current_line)
		lat1,lon1 = current_first_point.to_lat_lon()
		lat2,lon2 = current_last_point.to_lat_lon()
		list_of_nodes = current_line.to_lat_lon_list()
		current_length = 0.0
		for i in range(0,len(list_of_nodes)-1):
			j = i + 1
			node_1 = list_of_nodes[i]
			lat1,lon1 = node_1
			node_2 = list_of_nodes[j]
			lat2,lon2 = node_2
			dist = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
			current_length = current_length + dist
		return current_length

def get_midpoint_of_line_using_distance_from_haversine(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print ("Error input for get_last_point_of_line is None")
		exit()
	first_end_point = get_first_point_of_line(polyline_on_sphere)
	last_end_point = get_last_point_of_line(polyline_on_sphere)
	if (first_end_point == last_end_point):
		last_end_point = get_second_last_point_of_line(polyline_on_sphere)
	#calculate_distance_between_end_nodes
	distance = calculate_the_actual_length_of_a_line_in_km(polyline_on_sphere)
	if (distance == 0.00):
		print ("Warning: There is no mid point for the polyline_on_sphere")
		return None 
	half_of_distance = distance/2.00
	#tesselate the line to half_of_distance
	arc_length = polyline_on_sphere.get_arc_length()
	half_of_arc_length = arc_length/2.00
	tesselated_line = polyline_on_sphere.to_tessellated(half_of_arc_length)
	total_distance = 0.00
	current_mid_node = None
	for segment in tesselated_line.get_segments():
		first_point = segment.get_start_point()
		end_point = segment.get_end_point()
		lat1,lon1 = first_point.to_lat_lon()
		lat2,lon2 = end_point.to_lat_lon()
		distance = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
		total_distance = total_distance + distance
		if (total_distance >= half_of_distance):
			break
		else:
			current_mid_node = end_point
	if (current_mid_node is None):
		print ("Error in get_midpoint_of_line_using_distance_from_haversine")
		print ("Error current_mid_node is None")
		print ("Here are segments after tesselation")
		print((tesselated_line.get_segments()))
		for segment in tesselated_line.get_segments():
			first_point = segment.get_start_point()
			end_point = segment.get_end_point()
			lat1,lon1 = first_point.to_lat_lon()
			lat2,lon2 = end_point.to_lat_lon()
			distance = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
			print ("Here is value of distance for the segment")
			print (distance)
			exit()
	return current_mid_node
			
		
def calculate_distance_between_end_nodes(line_1, line_2):
	if (line_1 is None or line_2 is None):
		print ("Error in calculate_distance_between_end_nodes")
		print ("Error either line_1 is None or line_2 is None")
		exit()
	first_point_line_1 = get_first_point_of_line(line_1)
	last_point_line_1 = get_last_point_of_line(line_1)
	if (first_point_line_1 == last_point_line_1):
		last_point_line_1 = get_second_last_point_of_line(line_1)
		if (first_point_line_1 == last_point_line_1):
			print ("Error in calculate_distance_between_end_nodes")
			print ("Error first_point_line_1 == last_point_line_1 even after get_second_last_point_of_line")
			print((line_1.to_lat_lon_list()))
			print ("arc length of line_1")
			print((line_1.get_arc_length()))
			exit()
	
	first_point_line_2 = get_first_point_of_line(line_2)
	last_point_line_2 = get_last_point_of_line(line_2)
	if (first_point_line_2 == last_point_line_2):
		last_point_line_2 = get_second_last_point_of_line(line_2)
		if (first_point_line_2 == last_point_line_2):
			print ("Error in calculate_distance_between_end_nodes")
			print ("Error first_point_line_2 == last_point_line_2 even after get_second_last_point_of_line")
			print((line_2.to_lat_lon_list()))
			print ("arc length of line_2")
			print((line_2.get_arc_length()))
			exit()
	
	#first_last_distance
	first_last_distance = pygplates.GeometryOnSphere.distance(first_point_line_1,last_point_line_2)
	#first_first_distance
	first_first_distance = pygplates.GeometryOnSphere.distance(first_point_line_1,first_point_line_2)
	#last_first_distance
	last_first_distance = pygplates.GeometryOnSphere.distance(last_point_line_1,first_point_line_2)
	#last_last_distance
	last_last_distance = pygplates.GeometryOnSphere.distance(last_point_line_1,last_point_line_2)
	
	l = [first_last_distance,first_first_distance,last_first_distance,last_last_distance]
	min_distance = np.array(np.min(l))
	if (first_last_distance == min_distance):
		return (first_last_distance,first_point_line_1,last_point_line_2)
	elif (first_first_distance == min_distance):
		return (first_first_distance,first_point_line_1, first_point_line_2)
	elif (last_first_distance == min_distance):
		return (last_first_distance,last_point_line_1,first_point_line_2)
	else:
		return (last_last_distance,last_point_line_1,last_point_line_2)

def calculate_distance_between_end_nodes_in_km(line_1, line_2):
	if (line_1 is None or line_2 is None):
		print ("Error in calculate_distance_between_end_nodes")
		print ("Error either line_1 is None or line_2 is None")
		exit()
	first_point_line_1 = get_first_point_of_line(line_1)
	last_point_line_1 = get_last_point_of_line(line_1)
	if (first_point_line_1 == last_point_line_1):
		last_point_line_1 = get_second_last_point_of_line(line_1)
		if (first_point_line_1 == last_point_line_1):
			print ("Error in calculate_distance_between_end_nodes")
			print ("Error first_point_line_1 == last_point_line_1 even after get_second_last_point_of_line")
			print((line_1.to_lat_lon_list()))
			print ("arc length of line_1")
			print((line_1.get_arc_length()))
			exit()
	
	first_point_line_2 = get_first_point_of_line(line_2)
	last_point_line_2 = get_last_point_of_line(line_2)
	if (first_point_line_2 == last_point_line_2):
		last_point_line_2 = get_second_last_point_of_line(line_2)
		if (first_point_line_2 == last_point_line_2):
			print ("Error in calculate_distance_between_end_nodes")
			print ("Error first_point_line_2 == last_point_line_2 even after get_second_last_point_of_line")
			print((line_2.to_lat_lon_list()))
			print ("arc length of line_2")
			print((line_2.get_arc_length()))
			exit()
	
	#first_last_distance
	lat1,lon1 = first_point_line_1.to_lat_lon()
	lat2,lon2 = last_point_line_2.to_lat_lon()
	#first_point_line_1,last_point_line_2
	first_last_distance = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
	#first_first_distance
	#first_point_line_1,first_point_line_2
	lat2,lon2 = first_point_line_2.to_lat_lon()
	first_first_distance = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
	
	#last_first_distance
	#last_point_line_1,first_point_line_2
	lat1,lon1 = last_point_line_1.to_lat_lon()
	lat2,lon2 = first_point_line_2.to_lat_lon()
	last_first_distance = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
	#last_last_distance
	#last_point_line_1,last_point_line_2
	lat2,lon2 = last_point_line_2.to_lat_lon()
	last_last_distance = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
	
	l = [first_last_distance,first_first_distance,last_first_distance,last_last_distance]
	min_distance = np.array(np.min(l))
	if (first_last_distance == min_distance):
		return (first_last_distance,first_point_line_1,last_point_line_2)
	elif (first_first_distance == min_distance):
		return (first_first_distance,first_point_line_1, first_point_line_2)
	elif (last_first_distance == min_distance):
		return (last_first_distance,last_point_line_1,first_point_line_2)
	else:
		return (last_last_distance,last_point_line_1,last_point_line_2)

#credits to: Mike T. https://gis.stackexchange.com/questions/289044/creating-buffer-circle-x-kilometers-from-point-using-python
#more information for proj=aqed: https://proj.org/operations/projections/aeqd.html
#lat_0 and lon_0 are latitude and longitude of projection center
#x_0 and y_0 are false easting and false northing - the origin of xy coordinates
def geodesic_point_buffer(lat, lon, km):
	proj_wgs84 = pyproj.Proj('+proj=longlat +datum=WGS84')
	# Azimuthal equidistant projection
	aeqd_proj = '+proj=aeqd +lat_0={lat} +lon_0={lon} +x_0=0 +y_0=0 +ellps=WGS84'
	project = partial(pyproj.transform, pyproj.Proj(aeqd_proj.format(lat = lat,lon = lon)), proj_wgs84)
	buf = Point(0, 0).buffer(km * 1000) #distance in metres
	return transform(project, buf).exterior.coords[:]

def convert_Polygon_to_PolygonOnSphere_in_pygplates(each_polygon):
	if (each_polygon.area > 0.00):
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print ("Error in creating polygon in pygplates in conversion module")
			print ("Here is a list of lat_lon vertices")
			print (list_of_lat_lon_vertices)
			print ("Here is the first vertex and the last vertex:")
			print((list_of_lat_lon_vertices[0]))
			print((list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1]))
			exit()
		return new_polygon
	else:
		print ("Error in creating polygon in pygplates in conversion module")
		print ("Error each_polygon.get_area() <= 0.00")
		print ("here is each_polygon")
		print (each_polygon)
		exit()

def convert_polygon_to_Polygon_in_shapely(each_polygon):
	if (each_polygon.get_area() > 0.00):
		list_of_lon_lat_vertices = [(lon,lat) for lat,lon in each_polygon.to_lat_lon_list()]
		new_polygon = Polygon(list_of_lon_lat_vertices)
		if (new_polygon is None):
			print ("Error in creating Polygon in Shapely in conversion module")
			print ("Here is a list of lon_lat vertices")
			print (list_of_lon_lat_vertices)
			print ("Here is the first vertex and the last vertex:")
			print((list_of_lon_lat_vertices[0]))
			print((list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1]))
			exit()
		if (new_polygon.is_valid):
			return new_polygon
		else:
			print (explain_validity(new_polygon))
			return None
	else:
		print ("Error in creating Polygon in Shapely in conversion module")
		print ("Error each_polygon.get_area() <= 0.00")
		print ("here is each_polygon")
		print (each_polygon)
		exit()

#a function to convert LineOnSphere in pygplates to LineString in Shapely
def convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line):
	if (line.get_arc_length() > 0.00):
		list_of_lon_lat_vertices = [(lon,lat) for lat,lon in line.to_lat_lon_list()]
		array = np.array(list_of_lon_lat_vertices)
		array_of_round_values = np.around(array,decimals=4)
		line_string = LineString(array_of_round_values)
		if (line_string is None):
			print ("Error to convert LineOnSphere in pygplates to LineString in Shapely module")
			print ("Here is a list of lon_lat vertices")
			print (list_of_lon_lat_vertices)
			print ("Here is the first vertex and the last vertex:")
			print((list_of_lon_lat_vertices[0]))
			print((list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1]))
			print ("Here is array_of_round_values of lon_lat:")
			print (array_of_round_values)
			exit()
		return line_string

#a function to convert LineOnSphere in pygplates to LineString in Shapely
def convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely_without_roundup_coords(line):
	if (line.get_arc_length() > 0.00):
		list_of_lon_lat_vertices = [(lon,lat) for lat,lon in line.to_lat_lon_list()]
		array = np.array(list_of_lon_lat_vertices)
		line_string = LineString(array)
		if (line_string is None):
			print ("Error to convert LineOnSphere in pygplates to LineString in Shapely module")
			print ("Here is a list of lon_lat vertices")
			print (list_of_lon_lat_vertices)
			print ("Here is the first vertex and the last vertex:")
			print((list_of_lon_lat_vertices[0]))
			print((list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1]))
			print ("Here is array_of_round_values of lon_lat:")
			print (array_of_round_values)
			exit()
		return line_string


#a function to convert LineOnSphere in pygplates to LineString in Shapely
def convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(line):
	if (line.length > 0.00):
		try:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.coords]
		except NotImplementedError as error:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.exterior.coords]
		line_on_sphere = pygplates.PolylineOnSphere(list_of_lat_lon_vertices)
		if (line_on_sphere is None):
			print ("Error to convert convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
			print ("Here is a list_of_lat_lon_vertices")
			print (list_of_lat_lon_vertices)
			print (list_of_lat_lon_vertices)
			exit()
		return line_on_sphere
	else:
		print ("Error in convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
		print ("line.length == 0")
		print ("here are coords for line:")
		print((line.coords))
		print ("here is line")
		print (line)
		exit()

def find_the_oldest_feature(features):
	max_age = -1
	oldest_ft = None 
	for ft in features:
		begin_age,_ = ft.get_valid_time()
		if (max_age == -1):
			max_age = begin_age
			oldest_ft = ft
		elif (max_age >= 0 and max_age < begin_age):
			max_age = begin_age
			oldest_ft = ft
	if (max_age < 0 or oldest_ft is None):
		print ("Error in find_the_oldest_feature")
		print ("max_age < 0 or oldest_ft is None")
		exit()
	return oldest_ft

def find_the_representative_geometry_for_a_polygon_ft(polygon_ft):
	geometries = polygon_ft.get_geometries()
	current_number_points = 0
	current_polygon = None
	for polygon in geometries:
		if (current_number_points == 0.00 or len(polygon.to_lat_lon_list()) > current_number_points):
			current_number_points = len(polygon.to_lat_lon_list())
			current_polygon = polygon 
	if (current_polygon is None):
		print ("Error in find_the_representative_geometry_for_a_polygon_ft")
		print ("Error current_polygon is None")
		print ("Error cannot find the representative geometry for the polygon_ft")
		print ("Here are geometries for the polygon ft")
		print (geometries)
		for geometry in geometries:
			print (geometry)
			print((geometry.to_lat_lon_list()))
		exit()
	return current_polygon

def find_centroid_features(polygon_features,write_output,mmddyy):
	featType = pygplates.FeatureType.gpml_continental_crust
	list_of_centroid_fts = []
	for polygon_ft in polygon_features:
		polygons = polygon_ft.get_geometries()
		if (len(polygons) > 1):
			biggest_polygon = None
			for polygon in polygons:
				if (polygon.get_area() > 0.00):
					if (biggest_polygon is None):
						biggest_polygon = polygon
					else:
						if (biggest_polygon.get_area() < polygon.get_area()):
							biggest_polygon = polygon
			centroid = biggest_polygon.get_interior_centroid()
			begin_age,end_age = polygon_ft.get_valid_time()
			GDU_id = polygon_ft.get_reconstruction_plate_id()
			GDU_name = polygon_ft.get_name()
			centroid_ft =  pygplates.Feature.create_reconstructable_feature(featType,centroid,name=GDU_name,valid_time = (begin_age,end_age),reconstruction_plate_id = GDU_id)
			centroid_ft.set_description(polygon_ft.get_feature_id().get_string())
			list_of_centroid_fts.append(centroid_ft)
		elif (len(polygons) == 1):
			polygon = polygons[0]
			centroid = polygon.get_interior_centroid()
			begin_age,end_age = polygon_ft.get_valid_time()
			GDU_id = polygon_ft.get_reconstruction_plate_id()
			GDU_name = polygon_ft.get_name()
			centroid_ft =  pygplates.Feature.create_reconstructable_feature(featType,centroid,name=GDU_name,valid_time = (begin_age,end_age),reconstruction_plate_id = GDU_id)
			centroid_ft.set_description(polygon_ft.get_feature_id().get_string())
			list_of_centroid_fts.append(centroid_ft)
	if (write_output == True):
		outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_centroid_fts)
		outputLinesFile = "centroid_features_for_polygon_features_"+mmddyy+".shp"
		outputLinesFeatureCollection.write(outputLinesFile)
	return list_of_centroid_fts

def find_the_representative_geometry_for_a_line_ft(line_ft):
	geometries = line_ft.get_geometries()
	current_len = 0
	current_line = None
	current_first_point = None
	current_last_point = None
	for line in geometries:
		first_point_of_line = get_first_point_of_line(line)							
		end_point_of_line = get_last_point_of_line(line)
		if (current_len == 0.00 or len(line.to_lat_lon_list()) > current_len):
			current_len = len(line.to_lat_lon_list())
			current_line = line 
			current_first_point = first_point_of_line
			current_last_point = end_point_of_line
	if (current_line is None):
		print("Error in find_the_representative_geometry_for_a_line_ft")
		print("Error current_line is None")
		print("Error cannot find the representative geometry for the line_ft")
		print("Here are geometries for the line ft")
		print(geometries)
		for geometry in geometries:
			print(geometry)
			print(geometry.to_lat_lon_list())
		exit()
	return current_line

def find_centroid_features_v2(polygon_features,line_features,write_output):
	featType = pygplates.FeatureType.gpml_continental_crust
	list_of_centroid_fts = []
	list_of_associated_line_fts = []
	for polygon_ft in polygon_features:
		list_of_associated_line_fts[:] = []
		begin_age,end_age = polygon_ft.get_valid_time()
		GDU_id = polygon_ft.get_reconstruction_plate_id()
		GDU_name = polygon_ft.get_name()
		# if (GDU_id == 10389):
			# print "polygon_ft.valid_time"
			# print begin_age
			# print end_age
		for line_ft in line_features:
			begin_age_line_ft,end_age_line_ft = line_ft.get_valid_time()
			#debug
			# if (line_ft.get_reconstruction_plate_id() == GDU_id):
				# print "line_ft.valid_time"
				# print line_ft.get_valid_time()		
			if (line_ft.get_reconstruction_plate_id() == GDU_id):
				list_of_associated_line_fts.append(line_ft)
		for candidate_line_ft in list_of_associated_line_fts:
			line = find_the_representative_geometry_for_a_line_ft(candidate_line_ft)#this is the order of lines for each polygon
			centroid = get_midpoint_of_line(line)
			centroid_ft =  pygplates.Feature.create_reconstructable_feature(featType,centroid,name=GDU_name,valid_time = (begin_age,end_age),reconstruction_plate_id = GDU_id)
			centroid_ft.set_description(polygon_ft.get_feature_id().get_string())
			list_of_centroid_fts.append(centroid_ft)
			
			#remove already	 used line features from the line_features
			line_features.remove(candidate_line_ft)
		
		#debug 
		if (GDU_id == 10389):
			print("Here is len(list_of_associated_line_fts)")
			print(len(list_of_associated_line_fts))
			print("Here is len(list_of_centroid_fts)")
			print(len(list_of_centroid_fts))
	
	if (write_output == True):
		outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_centroid_fts)
		outputLinesFile = "centroid_features_for_polygon_features_using_associated_line_ft_v9_07032020.shp"
		outputLinesFeatureCollection.write(outputLinesFile)
	return list_of_centroid_fts
	
def find_centroid_features_v3(polygon_features,line_features,write_output):
	featType = pygplates.FeatureType.gpml_continental_crust
	list_of_centroid_fts = []
	for line_ft in line_features:
		GDU_id = line_ft.get_reconstruction_plate_id()
		GDU_name = line_ft.get_name()
		left_GDU = line_ft.get_left_plate()
		right_GDU =	 line_ft.get_right_plate()
		polygon_ft_id = None
		for polygon_ft in polygon_features:
			if (polygon_ft.get_reconstruction_plate_id() == GDU_id):
				polygon_ft_id = polygon_ft.get_feature_id()
		if (polygon_ft_id is not None):
			line = find_the_representative_geometry_for_a_line_ft(line_ft)#this is the order of lines for each polygon
			centroid = get_midpoint_of_line(line)
			centroid_ft =  pygplates.Feature.create_reconstructable_feature(featType,centroid,name=GDU_name,valid_time = line_ft.get_valid_time(),reconstruction_plate_id = GDU_id)
			centroid_ft.set_description(polygon_ft_id.get_string())
			centroid_ft.set_left_plate(left_GDU,pygplates.VerifyInformationModel.no)
			centroid_ft.set_right_plate(right_GDU,pygplates.VerifyInformationModel.no)
			list_of_centroid_fts.append(centroid_ft)
	
	if (write_output == True):
		outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_centroid_fts)
		outputLinesFile = "centroid_features_for_polygon_features_using_associated_line_ft_v9_07032020.shp"
		outputLinesFeatureCollection.write(outputLinesFile)
	return list_of_centroid_fts


def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = mean(lat_values)
				mean_lon = mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

	
def find_neighbours_for_polygon_features(rotation_model,polygon_features,threshold_distance_in_km,dictionary_of_neighbours,reconstruction_time,reference):
	reconstructed_polygon_features = []
	final_reconstructed_polygon_features = []
	
	list_of_valid_polygons_fts = None
	
	if (list_of_valid_polygons_fts is None):
		list_of_valid_polygons_fts = [ft for ft in polygon_features if ft.is_valid_at_time(reconstruction_time)]
		
	
	#clear temporary storages storing reconstructed features after every reconstruction_time
	reconstructed_polygon_features[:] = []
	final_reconstructed_polygon_features[:] = []

	#reconstruct all features to reconstruction_time
	if (reference is not None):
		#polygon_features
		pygplates.reconstruct(list_of_valid_polygons_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	else:
		#polygon_features
		pygplates.reconstruct(list_of_valid_polygons_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
			
	# for each_ft,reconstructed_ft_geometries in reconstructed_polygon_features:	
		# current_area = 0
		# current_polygon = None
		# for reconstructed_ft_geometry in reconstructed_ft_geometries:
			# polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
			# if (polygon.get_area() > current_area):
				# current_polygon = polygon
		# final_reconstructed_polygon_features.append((each_ft,current_polygon))
	
	final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
	
	for each_ft,polygon in final_reconstructed_polygon_features:
		if not(each_ft.get_feature_id().get_string() in dictionary_of_neighbours):
			dictionary_of_neighbours[each_ft.get_feature_id().get_string()]=[]
		for each_other_ft,other_polygon in final_reconstructed_polygon_features:
			if (each_ft.get_feature_id() != each_other_ft.get_feature_id()):
				#distance_radians = pygplates.GeometryOnSphere.distance(polygon,other_polygon)
				_, closest_point_on_geometry1, closest_point_on_geometry2 = pygplates.GeometryOnSphere.distance(polygon, other_polygon, return_closest_positions=True)
				#distance_in_km = distance_radians * pygplates.Earth.mean_radius_in_kms
				lat1,lon1 = closest_point_on_geometry1.to_lat_lon()
				lat2,lon2 = closest_point_on_geometry2.to_lat_lon()
				distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
				if (distance_in_km <= threshold_distance_in_km):
					dictionary_of_neighbours[each_ft.get_feature_id().get_string()].append(each_other_ft.get_feature_id().get_string())
	return dictionary_of_neighbours

#This is version of the module is_anything_in_between as of December 2018		
#A function to check whether there is anything between any two other points
#First: Need to check whether the interest point is within the vector angular limit
#Second: If the interest point is within the angular limit then check whether the distances between the interest point and each end point is smaller than the distance between the two end points
#uncertainty_angle_in_degree is the angle that we add to/subtract from the azimuth angle to define the upper and the lower boundary of the azimuth angle
uncertainty_angle_in_degree = 2.500
def is_anything_in_between(first_end_point,second_end_point,point_of_interest):
	#Each input point has a datatype as PointOnSphere as defined in pygplates
	#get the lat,lon of each point 
	lat1,lon1 = first_end_point.to_lat_lon()
	lat2,lon2 = second_end_point.to_lat_lon()
	interest_lat, interest_lon = point_of_interest.to_lat_lon()

	#convert all lat,lon in degrees to radians
	rad_lat_1 = math.radians(lat1)
	rad_lon_1 = math.radians(lon1)
	rad_lat_2 = math.radians(lat2)
	rad_lon_2 = math.radians(lon2)
	rad_interest_lat = math.radians(interest_lat)
	rad_interest_lon = math.radians(interest_lon)
	#calculate the azimuth - the direction from the two end points - the law of haversine 
	y = math.sin(rad_lon_2-rad_lon_1)*math.cos(rad_lat_2)
	x = math.cos(rad_lat_1)*math.sin(rad_lat_2)-math.sin(rad_lat_1)*math.cos(rad_lat_2)*math.cos(rad_lon_2-rad_lon_1)
	azimuth = math.atan2(y,x)
	deg_azimuth = math.degrees(azimuth)
	#calculate the azimuth - the direction from the first end point to the interest point
	y1 = math.sin(rad_interest_lon-rad_lon_1)*math.cos(rad_interest_lat)
	x1 = math.cos(rad_lat_1)*math.sin(rad_interest_lat)-math.sin(rad_lat_1)*math.cos(rad_interest_lat)*math.cos(rad_interest_lon-rad_lon_1)
	azimuth1 = math.atan2(y1,x1)
	deg_azimuth1 = math.degrees(azimuth1)
	#range of angle of azimuth in degree to be accepted
	lower_limit = deg_azimuth - uncertainty_angle_in_degree
	upper_limit = deg_azimuth + uncertainty_angle_in_degree

	if (deg_azimuth1 >= lower_limit and deg_azimuth1 <= upper_limit):
		#The interest point is in the same direction of the two end points
		#Need to compare distance among these points with each other
		dist_first_and_interest = pygplates.GeometryOnSphere.distance(first_end_point, point_of_interest, geometry1_is_solid = False, geometry2_is_solid = False)
		dist_second_and_interest = pygplates.GeometryOnSphere.distance(second_end_point, point_of_interest, geometry1_is_solid = False, geometry2_is_solid = False)
		dist_first_and_second = pygplates.GeometryOnSphere.distance(first_end_point, second_end_point, geometry1_is_solid = False, geometry2_is_solid = False)
		if (dist_first_and_interest < dist_first_and_second and dist_second_and_interest < dist_first_and_second):
			return True
		else:
			return False
	else:
		return False
		
def is_line_crossing_polygon_2(point_1,point_2,polygon):
	featType = pygplates.FeatureType.gpml_continental_crust
	
	#Create a new line between two points
	new_line = pygplates.PolylineOnSphere([point_1,point_2])

	if (new_line is None):
		print("Error: there is something wrong - line cannot be created")
		print("Here are input points:")
		print(point_1)
		print(point_2)
		exit()
	#Check whether this line intersect - "cutting across" the polygon
	if (polygon.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.inside):
		return True
	elif (polygon.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
		geometry_inside_polygon = []
		geometry_outside_polygon = []
		polygon.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
		#debug
		# print "length of geometry_inside_polygon"
		# print len(geometry_inside_polygon)
		if (len(geometry_inside_polygon) > 0):
			return True
		else:
			return False
	else:
		return False

def is_line_crossing_polygon_3(point_1,point_2,polygon,threshold_distance_in_km):
	featType = pygplates.FeatureType.gpml_continental_crust
	
	#Create a new line between two points
	new_line = pygplates.PolylineOnSphere([point_1,point_2])

	if (new_line is None):
		print("Error: there is something wrong - line cannot be created")
		print("Here are input points:")
		print(point_1)
		print(point_2)
		exit()
	#Check whether this line intersect - "cutting across" the polygon
	if (polygon.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.inside):
		return True
	elif (polygon.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
		geometry_inside_polygon = []
		geometry_outside_polygon = []
		polygon.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
		#debug
		# print "length of geometry_inside_polygon"
		# print len(geometry_inside_polygon)
		if (len(geometry_inside_polygon) > 0):
			total_intersecting_length = 0.00
			for geometry in geometry_inside_polygon:
				length = calculate_the_actual_length_of_a_line_in_km(geometry)
				total_intersecting_length = total_intersecting_length + length
			lat1,lon1 = point_1.to_lat_lon()
			lat2,lon2 = point_2.to_lat_lon()
			distance = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
			if (distance > threshold_distance_in_km):
				if (total_intersecting_length > 300.00):
					return True
				else:
					return False
			else:
				if (total_intersecting_length > 50.00):
					return True
				else:
					print("Here is total_intersecting_length")
					print(total_intersecting_length)
					return False
		else:
			return False
	else:
		return False
		
# def is_valid_feature_test(point_reconstructed_geometry, other_point_reconstructed_geometry, neighbours_points_reconstructed_geometry, neighbours_polygons_reconstructed_geometry):
	# #the azimuth test first
	# for neighbour_point in neighbours_points_reconstructed_geometry:
		# if (is_anything_in_between(point_reconstructed_geometry,other_point_reconstructed_geometry,neighbour_point)):
			# return False
	# #the line crossing polygon test
	# for neighbour_polygon in neighbours_polygons_reconstructed_geometry:
		# if (is_line_crossing_polygon_2(point_reconstructed_geometry,other_point_reconstructed_geometry,neighbour_polygon)):
			# return False 
	# #pass both tests
	# return True

def are_two_lines_similar(line_1,line_2):
	line_1_LineString = convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_1)
	line_2_LineString = convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line_2)
	if (line_1 == line_2 or line_1_LineString.__eq__(line_2_LineString) or line_1_LineString.almost_equals(line_2_LineString,decimal = 3) or line_1_LineString.overlaps(line_2_LineString)):
		return True
	else:
		return False

def is_valid_feature_test(reference_ft_id,neighbour_ft_id, reference_point_from_polygon, neighbour_point_from_polygon, reference_point_from_line, neighbour_point_from_line, neighbours_reconstructed_point_fts, neighbours_reconstructed_polygon_fts,reference_line,neighbour_line,threshold_distance_in_km):
	#the azimuth test first
	for point_ft,point_of_interest in neighbours_reconstructed_point_fts:
		if (point_ft.get_description() != reference_ft_id and point_ft.get_description() != neighbour_ft_id):
			if (is_anything_in_between(reference_point_from_polygon,neighbour_point_from_polygon,point_of_interest)):
			#if (is_anything_in_between(reference_point_from_line,neighbour_point_from_line,point_of_interest)):
				return False
	#the line crossing polygon test
	for polygon_ft,polygon_of_interest in neighbours_reconstructed_polygon_fts:
		if (polygon_ft.get_feature_id().get_string() != reference_ft_id and polygon_ft.get_feature_id().get_string()!= neighbour_ft_id):
			if (is_line_crossing_polygon_3(reference_point_from_line,neighbour_point_from_line,polygon_of_interest,threshold_distance_in_km)):
				return False
			# else:
				# #double check 
				# if (is_line_crossing_polygon_3(reference_point_from_polygon,neighbour_point_from_line,polygon_of_interest,threshold_distance_in_km)):
					# return False
				# if (is_line_crossing_polygon_3(neighbour_point_from_polygon,reference_point_from_line,polygon_of_interest,threshold_distance_in_km)):
					# return False
	#final check to make sure reference line and neighbour_line is not the same geometry - which means the line is between two continental GDU polygons
	# if (are_two_lines_similar(reference_line,neighbour_line) == True):
		# return False
	#pass both tests
	return True

def is_valid_feature_test_with_azimuth_direction_only(reference_ft_id,neighbour_ft_id, reference_point_from_line, neighbour_point_from_line, neighbours_reconstructed_point_fts):
	#the azimuth test first
	for point_ft,point_of_interest in neighbours_reconstructed_point_fts:
		if (point_ft.get_description() != reference_ft_id and point_ft.get_description() != neighbour_ft_id):
			if (is_anything_in_between(reference_point_from_line,neighbour_point_from_line,point_of_interest)):
				return False
	return True
	
def is_valid_feature_test_for_lines(reference_point_from_line, neighbour_point_from_line,polygon_fts_polygons,reference_line,neighbour_line,threshold_distance_in_km):
	#the line crossing polygon test
	for polygon_ft,polygon_of_interest in polygon_fts_polygons:
		if (is_line_crossing_polygon_3(reference_point_from_line,neighbour_point_from_line,polygon_of_interest,threshold_distance_in_km)):
			return False
	#final check to make sure reference line and neighbour_line is not the same geometry - which means the line is between two continental GDU polygons
	if (reference_line is not None and neighbour_line is not None):
		if (are_two_lines_similar(reference_line,neighbour_line) == True):
			return False
	#pass both tests
	return True

def find_middle_geometry_between_two_lines_with_mid_point(line_1,line_2):
	#find the middle point of each point
	mid_point_1 = get_midpoint_of_line_using_distance_from_haversine(line_1)
	mid_point_2 = get_midpoint_of_line_using_distance_from_haversine(line_2)
	#find the middle point between these two points
	temporary_line = pygplates.PolylineOnSphere([mid_point_1,mid_point_2])
	mid_point_between_lines = get_midpoint_of_line_using_distance_from_haversine(temporary_line)
	if (mid_point_between_lines is None):
		#attempt to join two lines to each other because there are on the same side
		joined_lines = pygplates.PolylineOnSphere.join([line_1,line_2])
		if (len(joined_lines) == 1):
			joined_line = joined_lines[0]
			mid_point_between_lines = get_midpoint_of_line_using_distance_from_haversine(joined_line)
			
	#create a buffer with this mid point - a buffer of distance 100 km
	lat,lon = mid_point_between_lines.to_lat_lon()
	km = 100.00
	buffer = geodesic_point_buffer(lat, lon, km)
	if (buffer is None):
		print('Error in identify_middle_geometry_between_two_lines_with_mid_point_buffer')
		print('Error could not create a buffer from the mid_point between line_1 and line_2')
		print('Here is value of mid_point_1 and mid_point_2')
		print(mid_point_1,mid_point_2)
		print('Here is valud of mid_point_between_lines')
		print(mid_point_between_lines)
		exit()
	polygon = Polygon(buffer)
	if polygon.is_valid:
		polygon_on_sphere = convert_Polygon_to_PolygonOnSphere_in_pygplates(polygon)
		return polygon_on_sphere
	else:
		return mid_point_between_lines

def is_valid_feature_test_with_middle_geometry(polygon_fts_polygons,reference_line,neighbour_line):
	#final check to make sure reference line and neighbour_line is not the same geometry - which means the line is between two continental GDU polygons
	if (reference_line is not None and neighbour_line is not None):
		if (are_two_lines_similar(reference_line,neighbour_line) == True):
			return False
	if (len(polygon_fts_polygons) == 0):
		return True
	else:	
		result = find_middle_geometry_between_two_lines_with_mid_point(reference_line,neighbour_line)
		mid_point_reference_line = get_midpoint_of_line_using_distance_from_haversine(reference_line)
		mid_point_neighbour_line = get_midpoint_of_line_using_distance_from_haversine(neighbour_line)
		#line = pygplates.PolylineOnSphere([mid_point_reference_line,mid_point_neighbour_line])
		if (type(result) is pygplates.PolygonOnSphere):
			for polygon_ft,polygon in polygon_fts_polygons:
				if (result.partition(polygon) == pygplates.PolygonOnSphere.PartitionResult.intersecting or polygon.partition(result) == pygplates.PolygonOnSphere.PartitionResult.inside):
					return False
				#if (is_line_crossing_polygon_2(mid_point_reference_line,mid_point_neighbour_line,polygon)):
				#	return False
			return True
		elif (type(result) is pygplates.PointOnSphere):
			for polygon_ft,polygon in polygon_fts_polygons:
				if (polygon.is_point_in_polygon(result)):
					return False
			return True
		else:
			print('Error in is_valid_feature_test_with_middle_geometry')
			print('Value of result')
			print(result)
			exit()
def find_line_feature_represent_other_GDU_v1(reference_point_ft,reference_point,neighbour_point_ft,neighbour_point,final_reconstructed_line_features):
	reference_line_ft = None
	reference_line = None
	neighbour_line = None
	neighbour_line_ft = None 
	
	list_of_neighbours = []
	list_of_reference = []
	for line_ft,line in final_reconstructed_line_features:
		# print "line_ft.get_description()"
		# print line_ft.get_description()
		if (line_ft.get_reconstruction_plate_id() == neighbour_point_ft.get_reconstruction_plate_id()):
			list_of_neighbours.append((line_ft,line))
		#elif 
		if(line_ft.get_reconstruction_plate_id() == reference_point_ft.get_reconstruction_plate_id()):
			list_of_reference.append((line_ft,line))
	if (reference_point is not None and neighbour_point is not None):
		min_distance = -1.00
		for ref_ft,ref_line in list_of_reference:
			distance = pygplates.GeometryOnSphere.distance(ref_line,neighbour_point)
			if min_distance == -1.00:
				min_distance = distance
				reference_line_ft = ref_ft
				reference_line = ref_line
			elif (distance < min_distance):
				min_distance = distance
				reference_line_ft = ref_ft
				reference_line = ref_line
		min_distance = -1.00
		for other_ft,other_line in list_of_neighbours:
			distance = pygplates.GeometryOnSphere.distance(other_line,reference_point)
			if min_distance == -1.00:
				min_distance = distance
				neighbour_line_ft = other_ft
				neighbour_line = other_line
			elif (distance < min_distance):
				min_distance = distance
				neighbour_line_ft = other_ft
				neighbour_line = other_line
	else:
		min_distance = -1.00
		for ref_ft,ref_line in list_of_reference:
			for other_ft,other_line in list_of_neighbours:
				if (ref_ft.get_feature_id() != other_ft.get_feature_id()):
					distance = pygplates.GeometryOnSphere.distance(ref_line,other_line)
					if (min_distance == -1):
						min_distance = distance
						reference_line = ref_line
						reference_line_ft = ref_ft
						neighbour_line	= other_line
						neighbour_line_ft = other_ft
					elif (min_distance > distance):
						min_distance = distance
						reference_line = ref_line
						reference_line_ft = ref_ft
						neighbour_line	= other_line
						neighbour_line_ft = other_ft
	# if (neighbour_line_ft is None or reference_line_ft is None):
		# print "Error in find_line_feature_represent_other_GDU"
		# print "Error neighbour_line_ft is None or reference_line_ft is None"
		# print "neighbour_line_ft"
		# print neighbour_line_ft
		# print "reference_line_ft"
		# print reference_line_ft
		# print "neighbour_point_ft.get_reconstruction_plate_id()"
		# print neighbour_point_ft.get_reconstruction_plate_id()
		# print "reference_point_ft.get_reconstruction_plate_id()"
		# print reference_point_ft.get_reconstruction_plate_id()
		# print "list_of_neighbours"
		# print list_of_neighbours
		# print "list_of_reference"
		# print list_of_reference
		# exit()
	if (reference_line_ft is not None and neighbour_line_ft is not None):
		#clonning reference line ft and neighbour_line_ft and their associated lines
		# cloned_ref_line_ft = reference_line_ft.clone()
		# cloned_ref_line = reference_line.clone()
		# cloned_neighbour_line_ft = neighbour_line_ft.clone()
		# cloned_neighbour_line = neighbour_line.clone()
	
		# #remove line features which were chosen 
		# final_reconstructed_line_features.remove((reference_line_ft,reference_line))
		# #print neighbour_line_ft,neighbour_line
		# final_reconstructed_line_features.remove((neighbour_line_ft,neighbour_line))
	
		#return (cloned_ref_line_ft,cloned_ref_line,cloned_neighbour_line_ft,cloned_neighbour_line)
		return (reference_line_ft,reference_line,neighbour_line_ft,neighbour_line)
	else:
		return (reference_line_ft,reference_line,neighbour_line_ft,neighbour_line)

def find_line_feature_represent_other_GDU(reference_point_ft,reference_point,neighbour_point_ft,neighbour_point,final_reconstructed_line_features):
	reference_line_ft = None
	reference_line = None
	neighbour_line = None
	neighbour_line_ft = None 
	
	list_of_neighbours = []
	list_of_reference = []
	for line_ft,line in final_reconstructed_line_features:
		# print "line_ft.get_description()"
		# print line_ft.get_description()
		if (line_ft.get_reconstruction_plate_id() == neighbour_point_ft.get_reconstruction_plate_id()):
			if ((line_ft.get_left_plate() == 0 and line_ft.get_right_plate()!= 0) or (line_ft.get_right_plate() == 0 and line_ft.get_left_plate()!= 0)):
				list_of_neighbours.append((line_ft,line))
		#elif 
		if(line_ft.get_reconstruction_plate_id() == reference_point_ft.get_reconstruction_plate_id()):
			if ((line_ft.get_left_plate() == 0 and line_ft.get_right_plate()!= 0) or (line_ft.get_right_plate() == 0 and line_ft.get_left_plate()!= 0)):
				list_of_reference.append((line_ft,line))
	
	# modified_list_of_neighbours = zip(*(list_of_neighbours))
	# neighbours_lines = modified_list_of_neighbours[1]
	
	# modified_list_of_reference = zip(*(list_of_reference))
	# reference_lines = modified_list_of_reference[1]
	
	if (reference_point is not None and neighbour_point is not None):
		min_distance = -1.00
		for ref_ft,ref_line in list_of_reference:
			distance = pygplates.GeometryOnSphere.distance(ref_line,neighbour_point)
			if min_distance == -1.00:
				min_distance = distance
				reference_line_ft = ref_ft
				reference_line = ref_line
			elif (distance < min_distance):
				min_distance = distance
				reference_line_ft = ref_ft
				reference_line = ref_line
		min_distance = -1.00
		for other_ft,other_line in list_of_neighbours:
			distance = pygplates.GeometryOnSphere.distance(other_line,reference_point)
			if min_distance == -1.00:
				min_distance = distance
				neighbour_line_ft = other_ft
				neighbour_line = other_line
			elif (distance < min_distance):
				min_distance = distance
				neighbour_line_ft = other_ft
				neighbour_line = other_line
	else:
		min_distance = -1.00
		for ref_ft,ref_line in list_of_reference:
			for other_ft,other_line in list_of_neighbours:
				if (ref_ft.get_feature_id() != other_ft.get_feature_id()):
					distance = pygplates.GeometryOnSphere.distance(ref_line,other_line)
					if (min_distance == -1):
						min_distance = distance
						reference_line = ref_line
						reference_line_ft = ref_ft
						neighbour_line	= other_line
						neighbour_line_ft = other_ft
					elif (min_distance > distance):
						min_distance = distance
						reference_line = ref_line
						reference_line_ft = ref_ft
						neighbour_line	= other_line
						neighbour_line_ft = other_ft
	# if (neighbour_line_ft is None or reference_line_ft is None):
		# print "Error in find_line_feature_represent_other_GDU"
		# print "Error neighbour_line_ft is None or reference_line_ft is None"
		# print "neighbour_line_ft"
		# print neighbour_line_ft
		# print "reference_line_ft"
		# print reference_line_ft
		# print "neighbour_point_ft.get_reconstruction_plate_id()"
		# print neighbour_point_ft.get_reconstruction_plate_id()
		# print "reference_point_ft.get_reconstruction_plate_id()"
		# print reference_point_ft.get_reconstruction_plate_id()
		# print "list_of_neighbours"
		# print list_of_neighbours
		# print "list_of_reference"
		# print list_of_reference
		# exit()
	if (reference_line_ft is not None and neighbour_line_ft is not None):
		#clonning reference line ft and neighbour_line_ft and their associated lines
		# cloned_ref_line_ft = reference_line_ft.clone()
		# cloned_ref_line = reference_line.clone()
		# cloned_neighbour_line_ft = neighbour_line_ft.clone()
		# cloned_neighbour_line = neighbour_line.clone()
	
		# #remove line features which were chosen 
		# final_reconstructed_line_features.remove((reference_line_ft,reference_line))
		# #print neighbour_line_ft,neighbour_line
		# final_reconstructed_line_features.remove((neighbour_line_ft,neighbour_line))
	
		#return (cloned_ref_line_ft,cloned_ref_line,cloned_neighbour_line_ft,cloned_neighbour_line)
		return (reference_line_ft,reference_line,neighbour_line_ft,neighbour_line)
	else:
		return (reference_line_ft,reference_line,neighbour_line_ft,neighbour_line)

def removing_already_used_features(list_of_already_used_ft_line, list_of_ft_geometry):
	total_used_fts = len(list_of_already_used_ft_line)
	count = 0
	for used_ft,geometry in list_of_already_used_ft_line:
		if ((used_ft,geometry) in list_of_ft_geometry):
			list_of_ft_geometry.remove((used_ft,geometry))
			count = count + 1
	if (count == total_used_fts):
		return True
	else:
		return False 

def construct_key_from_fts_id(feature_1,feature_2):
	ft_id_1 = feature_1.get_feature_id().get_string()
	ft_id_2 = feature_2.get_feature_id().get_string()
	#concatenate strings to create a key
	key = ft_id_1+"_"+ft_id_2
	return key 

def construct_key_from_fts_description(feature_1,feature_2):
	ft_id_1 = feature_1.get_description()
	ft_id_2 = feature_2.get_description()
	#concatenate strings to create a key
	key = ft_id_1+"_"+ft_id_2
	return key 


class Change(enum.Enum):
	Out_of_prox = -2
	Decrease = -1 
	Stable = 0
	Increase = 1

class Transform(enum.Enum):
	Oblique_divergence = 1 
	Strike_slip_left = 3
	Strike_slip_right = 4
	Oblique_convergence = -1

class Pure(enum.Enum):
	Divergence = 1
	Convergence = -1 
	Transform = 2
	Stable = 0

def relative_position_velocity_vectors_eval_old(rotation_model,centroid_reference_ft,other_centroid_ft,reconstruction_time,interval,reference,cos_value_for_transform):#cos_value_for_transform defines the upper and lower limit angles between velocity_vector and position_vector  
	reference_plateID = centroid_reference_ft.get_reconstruction_plate_id()
	other_plateID = other_centroid_ft.get_reconstruction_plate_id()
	
	centroid_ref_geometry = centroid_reference_ft.get_geometry()
	centroid_other_geometry = other_centroid_ft.get_geometry()

	equivalent_stage_rotation_other_plate = None 
	equivalent_stage_rotation_ref_plate = None
	relative_stage_rotation = None 

	if (reference is not None):
		#relative to the reference - mantle or spin axis 
		# Get the rotation of plate other_plateID ref_plateID from present day (0Ma) to 'reconstruction_time'.
		equivalent_total_rotation_ref_plate = rotation_model.get_rotation(reconstruction_time,reference_plateID, 0.0, reference, anchor_plate_id = reference, use_identity_for_missing_plate_ids = False)
		equivalent_total_rotation_other_plate = rotation_model.get_rotation(reconstruction_time,other_plateID, 0.0, reference, anchor_plate_id = reference, use_identity_for_missing_plate_ids = False)
		
		# Get the rotation of plate other_plateID from present day (0Ma) to 'reconstruction_time + interval'.
		#equivalent_total_rotation_other_plate_previous = rotation_model.get_rotation(reconstruction_time + interval,other_plateID, 0.0, reference, anchor_plate_id = reference, use_identity_for_missing_plate_ids = False)
		
	else:
		#relative to the reference - mantle or spin axis
		# Get the rotation of plate other_plateID from present day (0Ma) to 'reconstruction_time'.
		equivalent_total_rotation_ref_plate = rotation_model.get_rotation(reconstruction_time,reference_plateID)
		equivalent_total_rotation_other_plate = rotation_model.get_rotation(reconstruction_time,other_plateID)
		
		# Get the rotation of plate other_plateID from present day (0Ma) to 'reconstruction_time + interval'.
		#equivalent_total_rotation_other_plate_previous = rotation_model.get_rotation(reconstruction_time + interval,other_plateID)

	#Get the rotation of "other plate" from other_plate_ID from previous_reconstruction_time which is reconstruction_time + interval to reconstruction_time
	if (reference is None):
		equivalent_stage_rotation_other_plate = rotation_model.get_rotation(float(reconstruction_time),other_plateID,float(reconstruction_time+interval),0, anchor_plate_id = 0,use_identity_for_missing_plate_ids = False)
		equivalent_stage_rotation_ref_plate = rotation_model.get_rotation(float(reconstruction_time),reference_plateID,float(reconstruction_time+interval),0, anchor_plate_id = 0,use_identity_for_missing_plate_ids = False)
		
		relative_stage_rotation = rotation_model.get_rotation(float(reconstruction_time),other_plateID,float(reconstruction_time+interval),reference_plateID, anchor_plate_id = 0,use_identity_for_missing_plate_ids = False)
	else:
		equivalent_stage_rotation_other_plate = rotation_model.get_rotation(float(reconstruction_time),other_plateID,float(reconstruction_time+interval),reference, anchor_plate_id = reference,use_identity_for_missing_plate_ids = False)
		equivalent_stage_rotation_ref_plate = rotation_model.get_rotation(float(reconstruction_time),reference_plateID,float(reconstruction_time+interval),reference, anchor_plate_id = reference,use_identity_for_missing_plate_ids = False)
		
		relative_stage_rotation = rotation_model.get_rotation(float(reconstruction_time),other_plateID,float(reconstruction_time+interval),reference_plateID, anchor_plate_id = reference,use_identity_for_missing_plate_ids = False)
	
	if (relative_stage_rotation is not None):
		pole_lat,pole_lon,angle_degrees = relative_stage_rotation.get_lat_lon_euler_pole_and_angle_degrees()
		# if ((other_plateID == 11025 or other_plateID == 10465) and (reference_plateID == 11025 or reference_plateID == 10465)):
			# if (reconstruction_time == 110):
				# print pole_lat,pole_lon,angle_degrees
				# exit()
		if (abs(angle_degrees) < 0.05):
			return Pure.Stable
	else:
		name_for_centroid_reference_ft = str.encode(centroid_reference_ft.get_name())
		name_for_other_centroid_ft = str.encode(other_centroid_ft.get_name())
		l = [reconstruction_time,interval,reference_plateID,name_for_centroid_reference_ft,other_plateID,name_for_other_centroid_ft]
		#write to a csv file 
		if (os.path.isfile('missing_relative_rotation_information.csv')):
			with open ('missing_relative_rotation_information.csv','a') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(l)
		else:
			with open ('missing_relative_rotation_information.csv','w') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(['reconstruction_time','interval','reference_plateID','reference_GDU','other_plateID','other_GDU'])
				recordwriter_csv.writerow(l)
		return None
		
	if (equivalent_stage_rotation_other_plate is None or equivalent_stage_rotation_ref_plate is None or equivalent_total_rotation_other_plate is None or equivalent_total_rotation_ref_plate is None ):
		name_for_centroid_reference_ft = str.encode(centroid_reference_ft.get_name())
		name_for_other_centroid_ft = str.encode(other_centroid_ft.get_name())
		l = [reconstruction_time,interval,reference_plateID,name_for_centroid_reference_ft,other_plateID,name_for_other_centroid_ft]
		#write to a csv file 
		if (os.path.isfile('missing_relative_rotation_information.csv')):
			with open ('missing_relative_rotation_information.csv','a') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				for value in l:
					print (value)
					print (type(value))
				recordwriter_csv.writerow(l)
		else:
			with open ('missing_relative_rotation_information.csv','w') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(['reconstruction_time','interval','reference_plateID','reference_GDU','other_plateID','other_GDU'])
				for value in l:
					print (type(value))
				recordwriter_csv.writerow(l)
		
		return None

	reconstructed_centroid_of_reference_plate = centroid_ref_geometry
	reconstructed_centroid_of_other_plate = centroid_other_geometry
	
	#centroid_other_geometry_to_previous_time = equivalent_total_rotation_other_plate_previous*centroid_other_geometry
	
	centroid_other_geometry_at_reconstruction_time = equivalent_total_rotation_other_plate*centroid_other_geometry
	centroid_ref_geometry_at_reconstruction_time = equivalent_total_rotation_ref_plate*centroid_ref_geometry
	
	velocity_vector_list_other = pygplates.calculate_velocities(centroid_other_geometry_at_reconstruction_time,equivalent_stage_rotation_other_plate, interval)
	velocity_vector_list_ref = pygplates.calculate_velocities(centroid_ref_geometry_at_reconstruction_time,equivalent_stage_rotation_ref_plate, interval)

	if (len(velocity_vector_list_other) > 1 or len(velocity_vector_list_ref) > 1):
		print("Error in is_transform")
		print("Error there is more than one velocity_vector_list")
		print("Here is velocity_vector_list_other:")
		print(velocity_vector_list_other)
		print("Here is velocity_vector_list_ref:")
		print(velocity_vector_list_ref)
		exit()
	#from reconstruction_time+interval to reconstruction_time
	velocity_vector = velocity_vector_list_other[0] - velocity_vector_list_ref[0]
		
	#At reconstruction_time
	array_current_pos_of_other_plate_reconstruction_time = centroid_other_geometry_at_reconstruction_time.to_xyz_array()[0]
	array_current_pos_of_reference_plate = centroid_ref_geometry_at_reconstruction_time.to_xyz_array()[0]
	
	difference_array_pos_vector = array_current_pos_of_other_plate_reconstruction_time - array_current_pos_of_reference_plate
	
	pos_vector = pygplates.Vector3D(difference_array_pos_vector)
	
	#debug
	# position_vectors_present_day.append([reference_plateID,other_plateID,reconstruction_time,centroid_other_geometry.to_xyz_array(),centroid_ref_geometry.to_xyz_array()])
	# position_vectors_reconstruction_time.append([reference_plateID,other_plateID,reconstruction_time,array_current_pos_of_other_plate_reconstruction_time,array_current_pos_of_reference_plate])
	# diff_pos_vectors.append([reference_plateID,other_plateID,reconstruction_time,pos_vector])
	
	# #calculate the angle between the position vector of other plate relative to reference plate and the velocity_vector of other plate relative to reference plate
	if (velocity_vector.is_zero_magnitude() == True or pos_vector.is_zero_magnitude() == True):
		return Pure.Stable
	
	try:
		angle = pygplates.Vector3D.angle_between(velocity_vector,pos_vector)
	except pygplates.UnableToNormaliseZeroVectorError as error:
		print("Error in is_transform")
		print("Error pygplates.UnableToNormaliseZeroVectorError")
		print("reconstruction_time")
		print(reconstruction_time)
		print("Here is velocity_vector:")
		print(velocity_vector)
		print("Here is pos_vector")
		print(pos_vector)
		print("array_current_pos_of_other_plate")
		print(array_current_pos_of_other_plate)
		print("array_current_pos_of_reference_plate")
		print(array_current_pos_of_reference_plate)
		print("PlateID for reference and other")
		print(reference_plateID)
		print(other_plateID)
		print("Name of plate for reference feature")
		print(line_1.get_name())
		print("Name of plate for other feature")
		print(line_2.get_name())
		exit()
	
	#Comparing the angle only is too simple but also complicated at the same time, because we don't know the range of the value for these angle 
	#We want to get the cosine of the angle between the two. 
	if (math.cos(angle) <= cos_value_for_transform and math.cos(angle) >= -cos_value_for_transform): 
		answer = True
	else:
		answer = False

	if (answer == False): #not pure transform
		if (math.cos(angle) > cos_value_for_transform and math.cos(angle) < (1 - cos_value_for_transform)):
			return Transform.Oblique_divergence
		elif (math.cos(angle) < -cos_value_for_transform and math.cos(angle) > (cos_value_for_transform - 1)):
			return Transform.Oblique_convergence
		elif (math.cos(angle) <= 1 and math.cos(angle) >= (1 - cos_value_for_transform)):
			return Pure.Divergence
		elif (math.cos(angle) <= (cos_value_for_transform - 1) and math.cos(angle) >= -1):
			return Pure.Convergence
	else: #transform
		return Pure.Transform
		
def relative_position_velocity_vectors_eval(rotation_model,centroid_reference_ft,other_centroid_ft,reconstruction_time,interval,reference,cos_value_for_transform):#cos_value_for_transform defines the upper and lower limit angles between velocity_vector and position_vector  
	reference_plateID = centroid_reference_ft.get_reconstruction_plate_id()
	other_plateID = other_centroid_ft.get_reconstruction_plate_id()
	
	centroid_ref_geometry = centroid_reference_ft.get_geometry()
	centroid_other_geometry = other_centroid_ft.get_geometry()

	equivalent_stage_rotation_other_plate = None 
	equivalent_stage_rotation_ref_plate = None
	relative_stage_rotation = None 

	if (reference is not None):
		#relative to the reference - mantle or spin axis 
		# Get the rotation of plate other_plateID ref_plateID from present day (0Ma) to 'reconstruction_time'.
		equivalent_total_rotation_ref_plate = rotation_model.get_rotation(reconstruction_time,reference_plateID, 0.0, reference, anchor_plate_id = reference, use_identity_for_missing_plate_ids = False)
		equivalent_total_rotation_other_plate = rotation_model.get_rotation(reconstruction_time,other_plateID, 0.0, reference, anchor_plate_id = reference, use_identity_for_missing_plate_ids = False)
		
		# Get the rotation of plate other_plateID from present day (0Ma) to 'reconstruction_time + interval'.
		#equivalent_total_rotation_other_plate_previous = rotation_model.get_rotation(reconstruction_time + interval,other_plateID, 0.0, reference, anchor_plate_id = reference, use_identity_for_missing_plate_ids = False)
		
	else:
		#relative to the reference - mantle or spin axis
		# Get the rotation of plate other_plateID from present day (0Ma) to 'reconstruction_time'.
		equivalent_total_rotation_ref_plate = rotation_model.get_rotation(reconstruction_time,reference_plateID)
		equivalent_total_rotation_other_plate = rotation_model.get_rotation(reconstruction_time,other_plateID)
		
		# Get the rotation of plate other_plateID from present day (0Ma) to 'reconstruction_time + interval'.
		#equivalent_total_rotation_other_plate_previous = rotation_model.get_rotation(reconstruction_time + interval,other_plateID)

	#Get the rotation of "other plate" from other_plate_ID from previous_reconstruction_time which is reconstruction_time + interval to reconstruction_time
	if (reference is None):
		equivalent_stage_rotation_other_plate = rotation_model.get_rotation(float(reconstruction_time),other_plateID,float(reconstruction_time+interval),0, anchor_plate_id = 0,use_identity_for_missing_plate_ids = False)
		equivalent_stage_rotation_ref_plate = rotation_model.get_rotation(float(reconstruction_time),reference_plateID,float(reconstruction_time+interval),0, anchor_plate_id = 0,use_identity_for_missing_plate_ids = False)
	else:
		equivalent_stage_rotation_other_plate = rotation_model.get_rotation(float(reconstruction_time),other_plateID,float(reconstruction_time+interval),reference, anchor_plate_id = reference,use_identity_for_missing_plate_ids = False)
		equivalent_stage_rotation_ref_plate = rotation_model.get_rotation(float(reconstruction_time),reference_plateID,float(reconstruction_time+interval),reference, anchor_plate_id = reference,use_identity_for_missing_plate_ids = False)

	if (equivalent_stage_rotation_other_plate is None or equivalent_stage_rotation_ref_plate is None or equivalent_total_rotation_other_plate is None or equivalent_total_rotation_ref_plate is None ):
		name_for_centroid_reference_ft = str.encode(centroid_reference_ft.get_name())
		name_for_other_centroid_ft = str.encode(other_centroid_ft.get_name())
		l = [reconstruction_time,interval,reference_plateID,name_for_centroid_reference_ft,other_plateID,name_for_other_centroid_ft]
		#write to a csv file 
		if (os.path.isfile('missing_relative_rotation_information.csv')):
			with open ('missing_relative_rotation_information.csv','a') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				for value in l:
					print (value)
					print (type(value))
				recordwriter_csv.writerow(l)
		else:
			with open ('missing_relative_rotation_information.csv','w') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(['reconstruction_time','interval','reference_plateID','reference_GDU','other_plateID','other_GDU'])
				for value in l:
					print (type(value))
				recordwriter_csv.writerow(l)
		
		return None

	reconstructed_centroid_of_reference_plate = centroid_ref_geometry
	reconstructed_centroid_of_other_plate = centroid_other_geometry
	
	#centroid_other_geometry_to_previous_time = equivalent_total_rotation_other_plate_previous*centroid_other_geometry
	
	centroid_other_geometry_at_reconstruction_time = equivalent_total_rotation_other_plate*centroid_other_geometry
	centroid_ref_geometry_at_reconstruction_time = equivalent_total_rotation_ref_plate*centroid_ref_geometry
	
	velocity_vector_list_other = pygplates.calculate_velocities(centroid_other_geometry_at_reconstruction_time,equivalent_stage_rotation_other_plate, interval)
	velocity_vector_list_ref = pygplates.calculate_velocities(centroid_ref_geometry_at_reconstruction_time,equivalent_stage_rotation_ref_plate, interval)

	if (len(velocity_vector_list_other) > 1 or len(velocity_vector_list_ref) > 1):
		print("Error in is_transform")
		print("Error there is more than one velocity_vector_list")
		print("Here is velocity_vector_list_other:")
		print(velocity_vector_list_other)
		print("Here is velocity_vector_list_ref:")
		print(velocity_vector_list_ref)
		exit()
	#from reconstruction_time+interval to reconstruction_time
	velocity_vector = velocity_vector_list_other[0] - velocity_vector_list_ref[0]
		
	#At reconstruction_time
	array_current_pos_of_other_plate_reconstruction_time = centroid_other_geometry_at_reconstruction_time.to_xyz_array()[0]
	array_current_pos_of_reference_plate = centroid_ref_geometry_at_reconstruction_time.to_xyz_array()[0]
	
	difference_array_pos_vector = array_current_pos_of_other_plate_reconstruction_time - array_current_pos_of_reference_plate
	
	pos_vector = pygplates.Vector3D(difference_array_pos_vector)
	
	#debug
	# position_vectors_present_day.append([reference_plateID,other_plateID,reconstruction_time,centroid_other_geometry.to_xyz_array(),centroid_ref_geometry.to_xyz_array()])
	# position_vectors_reconstruction_time.append([reference_plateID,other_plateID,reconstruction_time,array_current_pos_of_other_plate_reconstruction_time,array_current_pos_of_reference_plate])
	# diff_pos_vectors.append([reference_plateID,other_plateID,reconstruction_time,pos_vector])
	
	# #calculate the angle between the position vector of other plate relative to reference plate and the velocity_vector of other plate relative to reference plate
	if (velocity_vector.is_zero_magnitude() == True or pos_vector.is_zero_magnitude() == True):
		return Pure.Stable
	try:
		angle = pygplates.Vector3D.angle_between(velocity_vector,pos_vector)
	except pygplates.UnableToNormaliseZeroVectorError as error:
		print("Error in is_transform")
		print("Error pygplates.UnableToNormaliseZeroVectorError")
		print("reconstruction_time")
		print(reconstruction_time)
		print("Here is velocity_vector:")
		print(velocity_vector)
		print("Here is pos_vector")
		print(pos_vector)
		print("array_current_pos_of_other_plate")
		print(array_current_pos_of_other_plate)
		print("array_current_pos_of_reference_plate")
		print(array_current_pos_of_reference_plate)
		print("PlateID for reference and other")
		print(reference_plateID)
		print(other_plateID)
		print("Name of plate for reference feature")
		print(line_1.get_name())
		print("Name of plate for other feature")
		print(line_2.get_name())
		exit()
	
	#Comparing the angle only is too simple but also complicated at the same time, because we don't know the range of the value for these angle 
	#We want to get the cosine of the angle between the two. 
	if (math.cos(angle) <= cos_value_for_transform and math.cos(angle) >= -cos_value_for_transform): 
		answer = True
	else:
		answer = False

	if (answer == False): #not pure transform
		if (math.cos(angle) > cos_value_for_transform and math.cos(angle) < (1 - cos_value_for_transform)):
			return Transform.Oblique_divergence
		elif (math.cos(angle) < -cos_value_for_transform and math.cos(angle) > (cos_value_for_transform - 1)):
			return Transform.Oblique_convergence
		elif (math.cos(angle) <= 1 and math.cos(angle) >= (1 - cos_value_for_transform)):
			return Pure.Divergence
		elif (math.cos(angle) <= (cos_value_for_transform - 1) and math.cos(angle) >= -1):
			return Pure.Convergence
	else: #transform
		return Pure.Transform		
				
		
def left_or_right_transform(centroid_ref_geometry_at_reconstruction_time,centroid_other_geometry_at_reconstruction_time):		
	#Need to investigate to know whether it is left lateral or right lateral strike slip
	ref_lat,ref_lon = centroid_ref_geometry_at_reconstruction_time.to_lat_lon()
	other_lat,other_lon = centroid_other_geometry_at_reconstruction_time.to_lat_lon()
	#Calculate the difference in lat and lon to identify the orientation of these two polygons relative to each other 
	if(abs(ref_lat - other_lat) > abs(ref_lon - other_lon)):
	#The two points are vertically oriented relative to each other - we need to know where ref point relative to other point
		if (ref_lon < other_lon):
			if (ref_lat > other_lat):
				#ref has right strike_slip 
				#other has right strike_slip
				return Transform.Strike_slip_right
			else:
				#ref has left strike_slip
				#other has left strike_slip
				return Transform.Strike_slip_left
		else:
			if (ref_lat < other_lat):
				#ref has right strike_slip 
				#other has right strike_slip
				return Transform.Strike_slip_right
			else:
				#ref has left strike_slip
				#other has left strike_slip
				return Transform.Strike_slip_left
	else:
		#The two points are horizontally oriented relative to each other
		if (ref_lat > other_lat):
			if (ref_lon > other_lon):
				#ref has right strike_slip 
				#other has right strike_slip
				return Transform.Strike_slip_right
			else:
				#ref has left strike_slip
				#other has left strike_slip
				return Transform.Strike_slip_left
		else:
			if (ref_lon < other_lon):
				#ref has right strike_slip 
				#other has right strike_slip
				return Transform.Strike_slip_right
			else:
				#ref has left strike_slip
				#other has left strike_slip
				return Transform.Strike_slip_left

def is_line_spanning_latitude_or_longitude(line):
	if (line is None):
		print("Error in is_line_spanning_latitude_or_longitude")
		print("line is None")
	if (line.get_arc_length() > 0.00):
		first_point_line = get_first_point_of_line(line)
		last_point_line = get_last_point_of_line(line)
		if (first_point_line == last_point_line):
			print("Error in is_line_spanning_latitude_or_longitude")
			print("first_point_line == last_point_line")
			print("line is a ring")
			exit()
		else:
			lat_1,lon_1 = first_point_line.to_lat_lon()
			lat_2,lon_2 = last_point_line.to_lat_lon()
			if (abs(lat_1 - lat_2) > abs(lon_1 - lon_2)):
				return "lat"
			elif (abs(lat_1 - lat_2) < abs(lon_1 - lon_2)):
				return "lon"
			else:
				return "unsure"
	else:
		print("Error in is_line_spanning_latitude_or_longitude")
		print("Error line.get_arc_length() == 0.00")
		exit()

#A function to identify which point between two points has higher latitude or longitude 
def which_point_is_better_in(lat_or_lon, higher_or_lower, p1, p2):
	lat_1,lon_1 = p1.to_lat_lon()
	lat_2,lon_2 = p2.to_lat_lon()
	if not (higher_or_lower == "higher" or higher_or_lower == "lower"):
		print("Error: the input value for higher_or_lower is NOT higher or lower")
		print("Here is the input of higher_or_lower")
		print(higher_or_lower)
		exit()
		
	if (lat_or_lon == "lat"):
		if (higher_or_lower == "higher"):
			if (lat_1 > lat_2):
				return p1
			else:
				return p2
		elif (higher_or_lower == "lower"):
			if (lat_1 < lat_2):
				return p1
			else:
				return p2
	elif (lat_or_lon == "lon"):
		if (higher_or_lower == "higher"):
			if (lon_1 > lon_2):
				return p1
			else:
				return p2
		elif (higher_or_lower == "lower"):
			if (lon_1 < lon_2):
				return p1
			else:
				return p2
	else:
		print("Error: the input value for lat_or_lon is NOT lat or lon")
		print("Here is the input of lat_or_lon:")
		print(lat_or_lon)
		exit()

#A function to identify left GDU and right GDU for rift or MOR mainly (attempt to identify subduction direction)		
def identify_left_right(line,polygon_1):
	if (line is None):
		print("Error in identify_left_right")
		print("Error line is None")
	#figure whether line is spanning along latitude or longitude
	result = is_line_spanning_latitude_or_longitude(line)
	centroid_1 = None
	if (polygon_1 is not None):
		centroid_1 = polygon_1.get_interior_centroid()
	first_point_line = get_first_point_of_line(line)
	last_point_line = get_last_point_of_line(line)
	if (first_point_line == last_point_line):
		print("Error in identify_left_right")
		print("Error first_point_line == last_point_line")
		exit() 
	if (centroid_1 is not None):
		point = which_point_is_better_in('lon', 'lower', first_point_line, last_point_line)
		lat_first,lon_first = first_point_line.to_lat_lon()
		lat_last,lon_last = last_point_line.to_lat_lon()
		# average_lat = float(lat_first + lat_last)/2.00
		# average_lon = float(lon_first + lon_last)/2.00
		# average_point = pygplates.PointOnSphere((average_lat,average_lon))
		average_point =	get_midpoint_of_line(line)
		if (result == 'lat'):
			if (point == first_point_line): #line is spanning along the horizontal line and going from first_point to last_point (West to East)
				#higher than the line is "Left" and lower than the line is "Right"
				if (centroid_1 is not None):
					point = which_point_is_better_in('lat', 'higher', centroid_1, average_point)
					if point == centroid_1:
						return 'Left'
					else:
						return 'Right'
			elif (point == last_point_line): #line is spanning along the horizontal line and going from first_point to last_point (East to West)
				#higher than the line is "Right" and lower than the line is "Left"
				if (centroid_1 is not None):
					point = which_point_is_better_in('lat', 'higher', centroid_1, average_point)
				if point == centroid_1:
					return 'Right'
				else:
					return 'Left'
		elif (result == 'lon'):
			if (point == first_point_line): #line is spanning along the longituge line and going from first_point to last_point (South to North)
				#lower longitude than the line is "Left" and higher than the line is "Right"
				if (centroid_1 is not None):
					point = which_point_is_better_in('lon', 'lower', centroid_1, average_point)
					if point == centroid_1:
						return 'Left'
					else:
						return 'Right'
			elif (point == last_point_line): #line is spanning along the longitude line and going from last_point to first_point (North to South)
				#lower longitude than the line is "Right" and higher than the line is "Left"
				if (centroid_1 is not None):
					point = which_point_is_better_in('lon', 'lower', centroid_1, average_point)
				if point == centroid_1:
					return 'Right'
				else:
					return 'Left'
		elif (result == 'unsure'):
			lat_centroid_1,lon_centroid_1 = centroid_1.to_lat_lon()
			if (lat_first < lat_last and lon_first < lon_last):
				#line is pointing from South-West to North-East
				p1 = pygplates.PointOnSphere((lat_last,average_lon))
				p2 = pygplates.PointOnSphere((lat_first,average_lon))
				if (pygplates.GeometryOnSphere.distance(polygon_1,p1) < pygplates.GeometryOnSphere.distance(polygon_1,p2)):
					return 'Left'
				else:
					return 'Right'
			else:
				#line is pointing from North-East to South-West
				p1 = pygplates.PointOnSphere((lat_first,average_lon))
				p2 = pygplates.PointOnSphere((lat_last,average_lon))
				if (pygplates.GeometryOnSphere.distance(polygon_1,p1) < pygplates.GeometryOnSphere.distance(polygon_1,p2)):
					return 'Right'
				else:
					return 'Left'
	else:
		print("Error in identify_left_right")
		print("Error centroid_1 of polygon_1 is None")
		print("Here is polygon_1")
		print(polygon_1)
		print("Here is polygon_1.get_area()")
		print(polygon_1.get_area())
		exit()

#A function to identify_middle_geometry between two lines
def identify_middle_geometry_between_two_lines(line_1,line_2):
	if (line_1 is None or line_2 is None):
		print("Error in identify_middle_geometry_between_two_lines")
		print("Error line_1 is None or line_2 is None")
	first_point_line_1 = get_first_point_of_line(line_1)
	last_point_line_1 = get_last_point_of_line(line_1)
	result_line_1 = is_line_spanning_latitude_or_longitude(line_1)
	
	first_point_line_2 = get_first_point_of_line(line_2)
	last_point_line_2 = get_last_point_of_line(line_2)
	result_line_2 = is_line_spanning_latitude_or_longitude(line_2)
	
	new_middle_line = None 
	if (result_line_1 == result_line_2):
		if (result_line_1 == 'lat'):
			point_w_lower_lon_1 = which_point_is_better_in('lon', 'lower', first_point_line_1, last_point_line_1)
			point_w_lower_lon_2 = which_point_is_better_in('lon', 'lower', first_point_line_2, last_point_line_2)
			lat_1,lon_1 = point_w_lower_lon_1.to_lat_lon()
			lat_2,lon_2 = point_w_lower_lon_2.to_lat_lon()
			mid_lon = (lon_1 + lon_2)/2.00
			mid_lat = (lat_1 + lat_2)/2.00
			mid_point_lower_lon = pygplates.PointOnSphere((mid_lat,mid_lon))
			point_w_higher_lon_1 = None
			point_w_higher_lon_2 = None
			if (point_w_lower_lon_1 == first_point_line_1):
				point_w_higher_lon_1 = last_point_line_1
			else:
				point_w_higher_lon_1 = first_point_line_1
			if (point_w_lower_lon_2 == first_point_line_2):
				point_w_higher_lon_2 = last_point_line_2
			else:
				point_w_higher_lon_2 = first_point_line_2
			lat_1,lon_1 = point_w_higher_lon_1.to_lat_lon()
			lat_2,lon_2 = point_w_higher_lon_2.to_lat_lon()
			mid_lon = (lon_1 + lon_2)/2.00
			mid_lat = (lat_1 + lat_2)/2.00
			mid_point_higher_lon = pygplates.PointOnSphere((mid_lat,mid_lon))
			new_middle_line = pygplates.PolylineOnSphere([mid_point_lower_lon,mid_point_higher_lon])
		else: #treat the case line spanning along longitude and diagonal similarly 
			point_w_lower_lat_1 = which_point_is_better_in('lat', 'lower', first_point_line_1, last_point_line_1)
			point_w_lower_lat_2 = which_point_is_better_in('lat', 'lower', first_point_line_2, last_point_line_2)
			lat_1,lon_1 = point_w_lower_lat_1.to_lat_lon()
			lat_2,lon_2 = point_w_lower_lat_2.to_lat_lon()
			mid_lon = (lon_1 + lon_2)/2.00
			mid_lat = (lat_1 + lat_2)/2.00
			mid_point_lower_lat = pygplates.PointOnSphere((mid_lat,mid_lon))
			point_w_higher_lat_1 = None
			point_w_higher_lat_2 = None
			if (point_w_lower_lat_1 == first_point_line_1):
				point_w_higher_lat_1 = last_point_line_1
			else:
				point_w_higher_lat_1 = first_point_line_1
			if (point_w_lower_lat_2 == first_point_line_2):
				point_w_higher_lat_2 = last_point_line_2
			else:
				point_w_higher_lat_2 = first_point_line_2
			lat_1,lon_1 = point_w_higher_lat_1.to_lat_lon()
			lat_2,lon_2 = point_w_higher_lat_2.to_lat_lon()
			mid_lon = (lon_1 + lon_2)/2.00
			mid_lat = (lat_1 + lat_2)/2.00
			mid_point_higher_lat = pygplates.PointOnSphere((mid_lat,mid_lon))
			new_middle_line = pygplates.PolylineOnSphere([mid_point_lower_lat,mid_point_higher_lat])
	else:
		#compare most pair of lines should be parallel with each other 
		#changes in latitudes are important 
		#Note: lazy treatment
		point_w_lower_lat_1 = which_point_is_better_in('lat', 'lower', first_point_line_1, last_point_line_1)
		point_w_lower_lat_2 = which_point_is_better_in('lat', 'lower', first_point_line_2, last_point_line_2)
		lat_1,lon_1 = point_w_lower_lat_1.to_lat_lon()
		lat_2,lon_2 = point_w_lower_lat_2.to_lat_lon()
		mid_lon = (lon_1 + lon_2)/2.00
		mid_lat = (lat_1 + lat_2)/2.00
		mid_point_lower_lat = pygplates.PointOnSphere((mid_lat,mid_lon))
		point_w_higher_lat_1 = None
		point_w_higher_lat_2 = None
		if (point_w_lower_lat_1 == first_point_line_1):
			point_w_higher_lat_1 = last_point_line_1
		else:
			point_w_higher_lat_1 = first_point_line_1
		if (point_w_lower_lat_2 == first_point_line_2):
			point_w_higher_lat_2 = last_point_line_2
		else:
			point_w_higher_lat_2 = first_point_line_2
		lat_1,lon_1 = point_w_higher_lat_1.to_lat_lon()
		lat_2,lon_2 = point_w_higher_lat_2.to_lat_lon()
		mid_lon = (lon_1 + lon_2)/2.00
		mid_lat = (lat_1 + lat_2)/2.00
		mid_point_higher_lat = pygplates.PointOnSphere((mid_lat,mid_lon))
		new_middle_line = pygplates.PolylineOnSphere([mid_point_lower_lat,mid_point_higher_lat])
	if (new_middle_line is None):
		print("Error in identify_middle_geometry_between_two_lines")
		print("Error new_middle_line is None")
		print("Relative orientation of two input lines")
		print(result_line_1)
		print(result_line_2)
	return new_middle_line

def identify_left_right(line,centroid_1):
	if (line is None):
		print("Error in identify_left_right 2")
		print("Error line is None")
	#figure whether line is spanning along latitude or longitude
	result = is_line_spanning_latitude_or_longitude(line)
	first_point_line = get_first_point_of_line(line)
	last_point_line = get_last_point_of_line(line)
	if (first_point_line == last_point_line):
		print("Error in identify_left_right")
		print("Error first_point_line == last_point_line")
		exit() 
	if (centroid_1 is not None):
		point = which_point_is_better_in('lon', 'lower', first_point_line, last_point_line)
		lat_first,lon_first = first_point_line.to_lat_lon()
		lat_last,lon_last = last_point_line.to_lat_lon()
		# average_lat = float(lat_first + lat_last)/2.00
		# average_lon = float(lon_first + lon_last)/2.00
		# average_point = pygplates.PointOnSphere((average_lat,average_lon))
		average_point =	get_midpoint_of_line_using_distance_from_haversine(line)
		if (result == 'lat'):
			if (point == first_point_line): #line is spanning along the horizontal line and going from first_point to last_point (West to East)
				#higher than the line is "Left" and lower than the line is "Right"
				if (centroid_1 is not None):
					point = which_point_is_better_in('lat', 'higher', centroid_1, average_point)
					if point == centroid_1:
						return 'Left'
					else:
						return 'Right'
			elif (point == last_point_line): #line is spanning along the horizontal line and going from first_point to last_point (East to West)
				#higher than the line is "Right" and lower than the line is "Left"
				if (centroid_1 is not None):
					point = which_point_is_better_in('lat', 'higher', centroid_1, average_point)
				if point == centroid_1:
					return 'Right'
				else:
					return 'Left'
		elif (result == 'lon'):
			if (point == first_point_line): #line is spanning along the longituge line and going from first_point to last_point (South to North)
				#lower longitude than the line is "Left" and higher than the line is "Right"
				if (centroid_1 is not None):
					point = which_point_is_better_in('lon', 'lower', centroid_1, average_point)
					if point == centroid_1:
						return 'Left'
					else:
						return 'Right'
			elif (point == last_point_line): #line is spanning along the longitude line and going from last_point to first_point (North to South)
				#lower longitude than the line is "Right" and higher than the line is "Left"
				if (centroid_1 is not None):
					point = which_point_is_better_in('lon', 'lower', centroid_1, average_point)
				if point == centroid_1:
					return 'Right'
				else:
					return 'Left'
		elif (result == 'unsure'):
			lat_centroid_1,lon_centroid_1 = centroid_1.to_lat_lon()
			if (lat_first < lat_last and lon_first < lon_last):
				#line is pointing from South-West to North-East
				p1 = pygplates.PointOnSphere((lat_last,average_lon))
				p2 = pygplates.PointOnSphere((lat_first,average_lon))
				if (pygplates.GeometryOnSphere.distance(polygon_1,p1) < pygplates.GeometryOnSphere.distance(polygon_1,p2)):
					return 'Left'
				else:
					return 'Right'
			else:
				#line is pointing from North-East to South-West
				p1 = pygplates.PointOnSphere((lat_first,average_lon))
				p2 = pygplates.PointOnSphere((lat_last,average_lon))
				if (pygplates.GeometryOnSphere.distance(polygon_1,p1) < pygplates.GeometryOnSphere.distance(polygon_1,p2)):
					return 'Right'
				else:
					return 'Left'
	else:
		print("Error in identify_left_right")
		print("Error centroid_1 of polygon_1 is None")
		print("Here is polygon_1")
		print(polygon_1)
		print("Here is polygon_1.get_area()")
		print(polygon_1.get_area())
		exit()

		
#A function to create transform boundaries for transform zone
def create_feature_for_transform_zone(line_1_ft, line_1, line_2_ft, line_2, rotation_model, type_of_movement, reconstruction_time, reference):
	# conn = None 
	# try:
		# #read database config
		# params = config()
		# #connect to the PostgreSQL
		# conn = psycopg2.connect(**params)
		# #create a new cursor
		# cur = conn.cursor()
		# sql = """ INSERT INTO tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, tectonic_motion) VALUES(%s,%s,%s,%s,%s,%s)"""
		# cur.execute(sql,((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),line_1_ft.get_feature_id().get_string(),line_2_ft.get_feature_id().get_string(),'Transform')))
		# #commit the changes to the database
		# conn.commit()
		# #close communication with the database
		# cur.close()
	# except (Exception, psycopg2.DatabaseError) as error:
		# print(error)
	# finally:
		# if conn is not None:
			# conn.close()
	
	middle_geometry = identify_middle_geometry_between_two_lines(line_1,line_2)
	if (middle_geometry is None):
		print("Error in create_feature_for_divergent_zone")
		print("Error here is GDU_id_1")
		print(line_1_ft.get_reconstruction_plate_id())
		print("Error here is GDU_id_2")
		print(line_2_ft.get_reconstruction_plate_id())
	#I do not think that we have to identify_left_right because we have correctly studied the topology of line feature 
	left_of_ft_1 = line_1_ft.get_left_plate()
	right_of_ft_1 = line_1_ft.get_right_plate()
	
	left_of_ft_2 = line_2_ft.get_left_plate()
	right_of_ft_2 = line_2_ft.get_right_plate()
	
	#mid_point_line_1 = get_midpoint_of_line(line_1)
	#mid_point_line_2 = get_midpoint_of_line(line_2)
	#result_line_1 = identify_left_right(line_1,mid_point_line_1) 
	#result_line_2 = identify_left_right(line_2,mid_point_line_2)
	
	if (line_1 is None or line_2 is None):
		print("Error in create_feature_for_transform_zone")
		print("Error cannot obtain geometry properly for feature line 1 or feature line 2")
		print("Here is line_1")
		print(line_1)
		print("Here is line_2")
		print(line_2)
		exit()
	
	#name_p1 = line_1_ft.get_name()
	#name_p2 = line_2_ft.get_name()
	
	p1_ID = line_1_ft.get_reconstruction_plate_id()
	p2_ID = line_2_ft.get_reconstruction_plate_id()
	
	begin_age = reconstruction_time
	end_age = 0.00
	
	#check to see whether 
	feature_1 = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_transform,
													line_1,
													name = line_1_ft.get_name(),
													valid_time = (begin_age,end_age),
													reconstruction_plate_id = p1_ID,
													description = "transform")
	
	if (left_of_ft_1 == p1_ID):
		feature_1.set_left_plate(left_of_ft_1)
	elif (right_of_ft_1 == p1_ID):
		feature_1.set_right_plate(right_of_ft_1)
		
	feature_2 = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_transform,
													line_2,
													name = line_2_ft.get_name(),
													valid_time = (begin_age,end_age),
													reconstruction_plate_id = p2_ID,
													description = "transform")
	left_of_ft_2 = line_2_ft.get_left_plate()
	right_of_ft_2 = line_2_ft.get_right_plate()
	
	if (left_of_ft_2 == p2_ID):
		feature_2.set_left_plate(p2_ID)
	elif (right_of_ft_2 == p2_ID):
		feature_2.set_right_plate(p2_ID)
	
	if (feature_1.get_left_plate() == p1_ID and feature_1.get_right_plate() == 0):
		feature_1.set_right_plate(p2_ID)
	elif (feature_1.get_left_plate() == 0 and feature_1.get_right_plate() == p1_ID):
		feature_1.set_left_plate(p2_ID)
	
	if (feature_2.get_left_plate() == p2_ID and feature_2.get_right_plate() == 0):
		feature_2.set_right_plate(p1_ID)
	elif (feature_2.get_left_plate() == 0 and feature_2.get_right_plate() == p1_ID):
		feature_2.set_left_plate(p1_ID)
	
		
	if (type_of_movement == "Left"):
		feature_1.set_enumeration(pygplates.PropertyName.gpml_motion,"LeftLateral")
		feature_2.set_enumeration(pygplates.PropertyName.gpml_motion,"LeftLateral")
	elif (type_of_movement == "Right"):
		feature_1.set_enumeration(pygplates.PropertyName.gpml_motion,"RightLateral")
		feature_2.set_enumeration(pygplates.PropertyName.gpml_motion,"RightLateral")
		
	if (reference is None):
		pygplates.reverse_reconstruct(feature_1,rotation_model,begin_age)
		pygplates.reverse_reconstruct(feature_2,rotation_model,begin_age)
	else:
		pygplates.reverse_reconstruct(feature_1,rotation_model,begin_age,reference)
		pygplates.reverse_reconstruct(feature_2,rotation_model,begin_age,reference)
		
	plate_id_1 = line_1_ft.get_reconstruction_plate_id()
	plate_id_2 = line_2_ft.get_reconstruction_plate_id()
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		#create a new cursor
		cur = conn.cursor()
		sql = """ INSERT INTO tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, line_1_ft_name, line_2_ft_name, tectonic_motion) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
		cur.execute(sql,((reconstruction_time,plate_id_1,plate_id_2,line_1_ft.get_feature_id().get_string(),line_2_ft.get_feature_id().get_string(),line_1_ft.get_name(),line_2_ft.get_name(),'Transform')))
		#commit the changes to the database
		conn.commit()
		#close communication with the database
		cur.close()
	except (Exception, psycopg2.DatabaseError) as error:
		print("Error in find_rift_segment_and_transform_faults_v1")
		print(error)
		exit()
	finally:
		if conn is not None:
			conn.close()
	return [feature_1,feature_2]

#A function to create divergent features: rift or MOR and two associated passive margins
def create_feature_for_divergent_zone_old(line_1_ft, line_1, line_2_ft, line_2, rotation_model, reconstruction_time, reference):
	middle_geometry = identify_middle_geometry_between_two_lines(line_1,line_2)
	if (middle_geometry is None):
		print("Error in create_feature_for_divergent_zone")
		print("Error here is GDU_id_1")
		print(line_1_ft.get_reconstruction_plate_id())
		print("Error here is GDU_id_2")
		print(line_2_ft.get_reconstruction_plate_id())
	mid_point_line_1 = get_midpoint_of_line(line_1)
	mid_point_line_2 = get_midpoint_of_line(line_2)
	result_line_1 = identify_left_right(line_1,mid_point_line_1) 
	result_line_2 = identify_left_right(line_2,mid_point_line_2)
	#MOR
	description_str = str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())
	middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge,middle_geometry,name = "rifting/MOR_"+description_str,valid_time = (reconstruction_time,0))
	middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
	middle_ft.set_description("divergent_zone")
	#passive_margin
	featType = pygplates.FeatureType.gpml_passive_continental_boundary
	passive_margin_1 = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
	passive_margin_2 = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
	
	passive_margin_1.set_description("divergent_zone")
	passive_margin_2.set_description("divergent_zone")
	
	if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
		passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	else:
		passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	
	if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
		passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	else:
		passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	
	if (result_line_1 == 'Left' and result_line_2 == 'Right'):
		middle_ft.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		middle_ft.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
		middle_ft.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		middle_ft.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	else:
		print("Error in create_feature_for_divergent_zone")
		print("Error here is GDU_id_1")
		print(line_1_ft.get_reconstruction_plate_id())
		print("Error here is GDU_id_2")
		print(line_2_ft.get_reconstruction_plate_id())
		print("Result of line_1 and line_2")
		print(result_line_1)
		print(result_line_2)
		print("Here is reconstruction_time")
		print(reconstruction_time)
		print("here is the relative orientation of the line_1 and line_2")
		print(is_line_spanning_latitude_or_longitude(line_1))
		print(is_line_spanning_latitude_or_longitude(line_2))
		if (reference is None):
			pygplates.reverse_reconstruct(middle_ft,rotation_model,reconstruction_time)
		else:
			pygplates.reverse_reconstruct(middle_ft,rotation_model,reconstruction_time,reference)
		outputLinesFeatureCollection = pygplates.FeatureCollection([middle_ft,line_1_ft,line_2_ft])
		outputLinesFile = "suspected_boundaries_features_to_create_divergent_zone_"+"_"+str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())+"_"+str(reconstruction_time)+"Ma.shp"
		outputLinesFeatureCollection.write(outputLinesFile)
		return ([None,None,None])
	if (reference is None):
		pygplates.reverse_reconstruct([middle_ft,passive_margin_1,passive_margin_2],rotation_model,reconstruction_time)
	else:
		pygplates.reverse_reconstruct([middle_ft,passive_margin_1,passive_margin_2],rotation_model,reconstruction_time,reference)
	return ([middle_ft,passive_margin_1,passive_margin_2])


def create_feature_for_divergent_zone(line_1_ft, line_1, line_2_ft, line_2, rotation_model, reconstruction_time, reference):
	middle_geometry = identify_middle_geometry_between_two_lines(line_1,line_2)
	if (middle_geometry is None):
		print("Error in create_feature_for_divergent_zone")
		print("Error here is GDU_id_1")
		print(line_1_ft.get_reconstruction_plate_id())
		print("Error here is GDU_id_2")
		print(line_2_ft.get_reconstruction_plate_id())
	mid_point_line_1 = get_midpoint_of_line_using_distance_from_haversine(line_1)
	mid_point_line_2 = get_midpoint_of_line_using_distance_from_haversine(line_2)
	result_line_1 = identify_left_right(line_1,mid_point_line_1) 
	result_line_2 = identify_left_right(line_2,mid_point_line_2)
	
	#rather create a middle geometry as a line - I create a middle geometry as a buffer polygon with 100km 
	result = find_middle_geometry_between_two_lines_with_mid_point(line_1,line_2)
	oceanic_GDU_ft = None 
	description_str = str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())
	if (type(result) is pygplates.PolygonOnSphere):
		oceanic_GDU_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,result,name = "oceanic_GDU_ft_"+description_str,valid_time = (reconstruction_time,0))
		if (reference is not None):
			oceanic_GDU_ft.set_reconstruction_plate_id(reference)
		else:
			oceanic_GDU_ft.set_reconstruction_plate_id(0)
		oceanic_GDU_ft.set_description("divergent_zone")
	elif (type(result) is pygplates.PointOnSphere):
		description_str = str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())
		oceanic_GDU_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust,result,name = "oceanic_GDU_ft_"+description_str,valid_time = (reconstruction_time,0))
		if (reference is not None):
			oceanic_GDU_ft.set_reconstruction_plate_id(reference)
		else:
			oceanic_GDU_ft.set_reconstruction_plate_id(0)
		oceanic_GDU_ft.set_description("divergent_zone")
	
	#MOR
	description_str = str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())
	middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge,middle_geometry,name = "rifting/MOR_"+description_str,valid_time = (reconstruction_time,0))
	middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
	middle_ft.set_description("divergent_zone")
	#passive_margin
	featType = pygplates.FeatureType.gpml_passive_continental_boundary
	passive_margin_1 = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
	passive_margin_2 = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
	
	passive_margin_1.set_description("divergent_zone")
	passive_margin_2.set_description("divergent_zone")
	
	if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
		passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	else:
		passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	
	if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
		passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	else:
		passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	
	if (result_line_1 == 'Left' and result_line_2 == 'Right'):
		middle_ft.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		middle_ft.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
		middle_ft.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		middle_ft.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	else:
		print("Error in create_feature_for_divergent_zone")
		print("Error here is GDU_id_1")
		print(line_1_ft.get_reconstruction_plate_id())
		print("Error here is GDU_id_2")
		print(line_2_ft.get_reconstruction_plate_id())
		print("Result of line_1 and line_2")
		print(result_line_1)
		print(result_line_2)
		print("Here is reconstruction_time")
		print(reconstruction_time)
		print("here is the relative orientation of the line_1 and line_2")
		print(is_line_spanning_latitude_or_longitude(line_1))
		print(is_line_spanning_latitude_or_longitude(line_2))
		if (reference is None):
			pygplates.reverse_reconstruct(middle_ft,rotation_model,reconstruction_time)
		else:
			pygplates.reverse_reconstruct(middle_ft,rotation_model,reconstruction_time,reference)
		outputLinesFeatureCollection = pygplates.FeatureCollection([middle_ft,line_1_ft,line_2_ft])
		outputLinesFile = "suspected_boundaries_features_to_create_divergent_zone_"+"_"+str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())+"_"+str(reconstruction_time)+"Ma.gpml"
		outputLinesFeatureCollection.write(outputLinesFile)
		return ([None,None,None])
	if (reference is None):
		pygplates.reverse_reconstruct([oceanic_GDU_ft,passive_margin_1,passive_margin_2],rotation_model,reconstruction_time)
	else:
		pygplates.reverse_reconstruct([oceanic_GDU_ft,passive_margin_1,passive_margin_2],rotation_model,reconstruction_time,reference)
	return ([oceanic_GDU_ft,passive_margin_1,passive_margin_2])

def find_finite_rotation_pole_for_a_pair_of_GDUs(rotation_model, moving_plate_id, fixed_plate_id, reconstruction_time, interval, reference_frame):
	finite_rotation = rotation_model.get_rotation(reconstruction_time, moving_plate_id, reconstruction_time + interval, fixed_plate_id, anchor_plate_id = reference_frame)
	return finite_rotation

def find_rift_segment_and_transform_faults_v1(line_1_ft, line_1, line_2_ft, line_2, rotation_model, reconstruction_time, interval, reference_frame):
	plate_id_1 = line_1_ft.get_reconstruction_plate_id()
	plate_id_2 = line_2_ft.get_reconstruction_plate_id()
	finite_rotation = find_finite_rotation_pole_for_a_pair_of_GDUs(rotation_model,plate_id_1,plate_id_2, reconstruction_time, interval, reference_frame)
	if (finite_rotation.represents_identity_rotation() == False):
		Euler_pole,angle_rads = finite_rotation.get_euler_pole_and_angle()
		mid_point_line_1 = get_midpoint_of_line_using_distance_from_haversine(line_1)
		mid_point_line_2 = get_midpoint_of_line_using_distance_from_haversine(line_2)
		new_great_circle_arc = pygplates.GreatCircleArc(mid_point_line_1, mid_point_line_2)
		rift_point_location = new_great_circle_arc.get_arc_point(0.500)
		new_great_circle_arc = pygplates.GreatCircleArc(rift_point_location, Euler_pole)
		normal_unit_vector = new_great_circle_arc.get_great_circle_normal() #this will give us some sense of the transform fault
		opposite_unit_vector = normal_unit_vector*(-1.00)
		#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
		rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
		mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
		mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z = mid_point_line_2.to_xyz()
		#identify left and right
		vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
		normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
		vector_to_line_2 = pygplates.Vector3D([(mid_point_line_2_x-rift_point_location_x),(mid_point_line_2_y-rift_point_location_y),(mid_point_line_2_z-rift_point_location_z)])
		normalized_vector_to_line_2 = vector_to_line_2.to_normalised()
		
		left = None
		right = None 
		
		lat1,lon1 = mid_point_line_1.to_lat_lon()
		lat2,lon2 = mid_point_line_2.to_lat_lon()
		rift_point_lat,rift_point_lon = rift_point_location.to_lat_lon()
		
		if (pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,opposite_unit_vector) > 0):
			left = plate_id_1
			right = plate_id_2
			#calculate distance from the rift_point_location to the left_GDU and calculate distance from the rift_point_location to the right_GDU 
			#approx_distance_to_left_in_km = pygplates.GeometryOnSphere.distance(rift_point_location,line_1) * pygplates.Earth.mean_radius_in_kms
			approx_distance_to_left_in_km = calculate_distance_km_between_two_points_from_haversine_formula(rift_point_lat,rift_point_lon,lat1,lon1)
			#approx_distance_to_right_in_km = pygplates.GeometryOnSphere.distance(rift_point_location,line_2) * pygplates.Earth.mean_radius_in_kms
			approx_distance_to_right_in_km = calculate_distance_km_between_two_points_from_haversine_formula(rift_point_lat,rift_point_lon,lat2,lon2)
		elif (pygplates.Vector3D.dot(normalized_vector_to_line_1,opposite_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector) > 0):
			left = plate_id_2
			right = plate_id_1 
			#calculate distance from the rift_point_location to the left_GDU and calculate distance from the rift_point_location to the right_GDU 
			#approx_distance_to_left_in_km = pygplates.GeometryOnSphere.distance(rift_point_location,line_2) * pygplates.Earth.mean_radius_in_kms
			approx_distance_to_left_in_km = calculate_distance_km_between_two_points_from_haversine_formula(rift_point_lat,rift_point_lon,lat2,lon2)
			#approx_distance_to_right_in_km = pygplates.GeometryOnSphere.distance(rift_point_location,line_1) * pygplates.Earth.mean_radius_in_kms
			approx_distance_to_right_in_km = calculate_distance_km_between_two_points_from_haversine_formula(rift_point_lat,rift_point_lon,lat1,lon1)
		else:
			print("Error in find_rift_segment_and_transform_faults")
			print("line_1 and line_2 are not located on two different sides relative to the mid_point")
			print("dot product of unit vectors for line_1")
			print(pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector))
			print("dot product of unit vectors for line_2")
			print(pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector))
			exit()
			
		new_point_x = rift_point_location_x + normal_unit_vector.get_x()*approx_distance_to_left_in_km
		new_point_y = rift_point_location_y + normal_unit_vector.get_y()*approx_distance_to_left_in_km
		new_point_z = rift_point_location_z + normal_unit_vector.get_z()*approx_distance_to_left_in_km
	
		new_point_vector = pygplates.Vector3D((new_point_x,new_point_y,new_point_z))
		new_point_vector_normalized = new_point_vector.to_normalised()
		new_point = pygplates.PointOnSphere((new_point_vector_normalized.get_x(),new_point_vector_normalized.get_y(),new_point_vector_normalized.get_z()))
	
		opposite_new_point_x = rift_point_location_x + opposite_unit_vector.get_x()*approx_distance_to_right_in_km
		opposite_new_point_y = rift_point_location_y + opposite_unit_vector.get_y()*approx_distance_to_right_in_km
		opposite_new_point_z = rift_point_location_z + opposite_unit_vector.get_z()*approx_distance_to_right_in_km
		opposite_new_point_vector = pygplates.Vector3D((opposite_new_point_x,opposite_new_point_y,opposite_new_point_z))
		opposite_new_point_vector_normalized = opposite_new_point_vector.to_normalised()
		opposite_new_point = pygplates.PointOnSphere((opposite_new_point_vector_normalized.get_x(),opposite_new_point_vector_normalized.get_y(),opposite_new_point_vector_normalized.get_z()))
	
		temp_arc_1 = pygplates.GreatCircleArc(rift_point_location,new_point)
		point_1 = temp_arc_1.get_arc_point(0.0500)
		temp_arc_2 = pygplates.GreatCircleArc(rift_point_location,opposite_new_point)
		point_2 = temp_arc_2.get_arc_point(0.0500)
	
		transform_fault_line = pygplates.PolylineOnSphere([point_1, point_2]) #this is transform_fault 
		
		point_1 = new_great_circle_arc.get_arc_point(0.0500)
		rift_line = pygplates.PolylineOnSphere([rift_point_location,point_1])
		
		#MOR
		description_str = str(left)+"_"+str(right)
		#middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_continental_rift,rift_line,name = "rifting/MOR_"+description_str,valid_time = (reconstruction_time,0))
		middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_continental_rift,rift_point_location,name = "rifting/MOR_"+description_str,valid_time = (reconstruction_time,0))
		middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
		middle_ft.set_description("divergent_zone")
		middle_ft.set_left_plate(left)
		middle_ft.set_right_plate(right)
		#transform_fault
		# transform_fault = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_transform,transform_fault_line,name = "transform_from_rifting_"+description_str,valid_time = (reconstruction_time,0))
		# transform_fault.set_reconstruction_method('HalfStageRotationVersion2')
		# transform_fault.set_description("transform")
		# transform_fault.set_left_plate(left)
		# transform_fault.set_right_plate(right)
		
		transform_point_left = None
		transform_point_right = None
		if (left == plate_id_1 and right == plate_id_2):
			transform_point_left = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_transform,mid_point_line_1,name = "transform_from_rifting_"+description_str,valid_time = (reconstruction_time,0))
			transform_point_right = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_transform,mid_point_line_2,name = "transform_from_rifting_"+description_str,valid_time = (reconstruction_time,0))
		else:
			transform_point_left = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_transform,mid_point_line_2,name = "transform_from_rifting_"+description_str,valid_time = (reconstruction_time,0))
			transform_point_right = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_transform,mid_point_line_1,name = "transform_from_rifting_"+description_str,valid_time = (reconstruction_time,0))
		transform_point_left.set_reconstruction_plate_id(left)
		transform_point_left.set_description("transform")
		transform_point_right.set_reconstruction_plate_id(right)
		transform_point_right.set_description("transform")
		#passive_margin
		featType = pygplates.FeatureType.gpml_passive_continental_boundary
		passive_margin_1 = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = plate_id_1)
		passive_margin_2 = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = plate_id_2)
	
		passive_margin_1.set_description("divergent_zone")
		passive_margin_2.set_description("divergent_zone")
	
		if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
			passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		else:
			passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	
		if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
			passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		else:
			passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		
		# if (reference_frame is None):
			# pygplates.reverse_reconstruct([middle_ft,passive_margin_1,passive_margin_2,transform_fault],rotation_model,reconstruction_time)
		# else:
			# pygplates.reverse_reconstruct([middle_ft,passive_margin_1,passive_margin_2,transform_fault],rotation_model,reconstruction_time,reference_frame)
		# return ([middle_ft,passive_margin_1,passive_margin_2,transform_fault])
		
		conn = None 
		try:
			#read database config
			params = config()
			#connect to the PostgreSQL
			conn = psycopg2.connect(**params)
			#create a new cursor
			cur = conn.cursor()
			sql = """ INSERT INTO tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, line_1_ft_name, line_2_ft_name, tectonic_motion) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
			cur.execute(sql,((reconstruction_time,plate_id_1,plate_id_2,line_1_ft.get_feature_id().get_string(),line_2_ft.get_feature_id().get_string(),line_1_ft.get_name(),line_2_ft.get_name(),'Divergence')))
			#commit the changes to the database
			conn.commit()
			#close communication with the database
			cur.close()
		except (Exception, psycopg2.DatabaseError) as error:
			print("Error in find_rift_segment_and_transform_faults_v1")
			print(error)
			exit()
		finally:
			if conn is not None:
				conn.close()
		
		if (reference_frame is None):
			pygplates.reverse_reconstruct([middle_ft,passive_margin_1,passive_margin_2,transform_point_left,transform_point_right],rotation_model,reconstruction_time)
		else:
			pygplates.reverse_reconstruct([middle_ft,passive_margin_1,passive_margin_2,transform_point_left,transform_point_right],rotation_model,reconstruction_time,reference_frame)
		return ([middle_ft,passive_margin_1,passive_margin_2,transform_point_left,transform_point_right])
	else:
		print("Error in find_rift_segment_and_transform_faults")
		print("Error finite_rotation is identity")
		print(plate_id_1,plate_id_2)
		print("reconstruction_time")
		print(reconstruction_time)
		exit()


#A function to create passive margin features: boundaries not at the active state
def create_feature_for_stable_zone(line_1_ft, line_1, line_2_ft, line_2, rotation_model, reconstruction_time, reference):
	# middle_geometry = identify_middle_geometry_between_two_lines(line_1,line_2)
	# if (middle_geometry is None):
		# print "Error in create_feature_for_divergent_zone"
		# print "Error here is GDU_id_1"
		# print line_1_ft.get_reconstruction_plate_id()
		# print "Error here is GDU_id_2"
		# print line_2_ft.get_reconstruction_plate_id()
	# mid_point_line_1 = get_midpoint_of_line(line_1)
	# mid_point_line_2 = get_midpoint_of_line(line_2)
	# result_line_1 = identify_left_right(line_1,mid_point_line_1) 
	# result_line_2 = identify_left_right(line_2,mid_point_line_2)
	
	#Middle feature to define left and right GDU - borrow the MOR as the FeatureType
	# description_str = str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())
	# middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge,middle_geometry,name = "middle_ft"+description_str,valid_time = (reconstruction_time,0))
	# middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
	# middle_ft.set_description("stable_zone")
	
	#passive_margin
	featType = pygplates.FeatureType.gpml_passive_continental_boundary
	passive_margin_1 = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
	passive_margin_1.set_description("stable_zone")
	passive_margin_2 = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
	passive_margin_2.set_description("stable_zone")
	
	if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
		passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	else:
		passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	
	if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
		passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	else:
		passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	
	
	# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
		# middle_ft.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		# middle_ft.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
		# middle_ft.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		# middle_ft.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		# passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	# else:
		# print "Error in create_feature_for_stable_zone"
		# print "Error here is GDU_id_1"
		# print line_1_ft.get_reconstruction_plate_id()
		# print "Error here is GDU_id_2"
		# print line_2_ft.get_reconstruction_plate_id()
		# print "Result of line_1 and line_2"
		# print result_line_1
		# print result_line_2
		# print "Here is reconstruction_time"
		# print reconstruction_time
		# print "here is the relative orientation of the line_1 and line_2"
		# print is_line_spanning_latitude_or_longitude(line_1)
		# print is_line_spanning_latitude_or_longitude(line_2)
		# if (reference is None):
			# pygplates.reverse_reconstruct(middle_ft,rotation_model,reconstruction_time)
		# else:
			# pygplates.reverse_reconstruct(middle_ft,rotation_model,reconstruction_time,reference)
		# outputLinesFeatureCollection = pygplates.FeatureCollection([middle_ft,line_1_ft,line_2_ft])
		# outputLinesFile = "suspected_boundaries_features_to_create_stable_zone_"+str(reconstruction_time)+"Ma.shp"
		# outputLinesFeatureCollection.write(outputLinesFile)
		
		#have to use left and right of the original line features 
		# left_1 = line_1_ft.get_left_plate()
		# right_1 = line_1_ft.get_right_plate()
		
		# left_2 = line_2_ft.get_left_plate()
		# right_2 = line_2_ft.get_right_plate()
		
		#passive_margin_1.set_left_plate(left_1)
		#passive_margin_1.set_right_plate(right_1)
		
		#passive_margin_2.set_left_plate(left_2)
		#passive_margin_2.set_right_plate(right_2)
		
	if (reference is None):
		pygplates.reverse_reconstruct([passive_margin_1,passive_margin_2],rotation_model,reconstruction_time)
	else:
		pygplates.reverse_reconstruct([passive_margin_1,passive_margin_2],rotation_model,reconstruction_time,reference)
	return ([passive_margin_1,passive_margin_2])

def find_possible_subduction_zone_for_future_convergence(rotation_model,topological_line_features,deposits_or_geochron_buffer_features,from_age,to_age,interval,reference,modelname,mmddyy,write_output,output_freq):
	list_of_candidate_line_fts = []
	reconstructed_line_features = []
	final_reconstructed_line_features = []
	reconstructed_buffer_features = []
	final_reconstructed_buffer_features = []
	#create a new property
	gpml_number_of_points = pygplates.PropertyName.create_gpml('number_of_points')
	#create a new property
	gpml_number_of_buffers = pygplates.PropertyName.create_gpml('number_of_buffers')
	final_list_of_line_fts = []
	reconstruction_time = from_age
	last_output_shp = 0.00
	while (reconstruction_time > (to_age - interval)):
		#filtering line features which are shared between a continental and an oceanic GDUs
		list_of_candidate_line_fts[:] = []
		for ft in topological_line_features:
			if (ft.is_valid_at_time(reconstruction_time)):
				if ((ft.get_left_plate() == 0 and ft.get_right_plate() != 0) or (ft.get_left_plate() != 0 and ft.get_right_plate() == 0)):
					list_of_candidate_line_fts.append(ft)
		#filtering buffer features 
		list_of_buffer_features = [ft for ft in deposits_or_geochron_buffer_features if ft.is_valid_at_time(reconstruction_time)]
		print('len(list_of_buffer_features)')
		print(len(list_of_buffer_features))
		print('len(list_of_candidate_line_fts)')
		print(len(list_of_candidate_line_fts))
		#reconstruct all features
		if (reference is not None):
			pygplates.reconstruct(list_of_buffer_features,rotation_model,reconstructed_buffer_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(list_of_candidate_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(list_of_buffer_features,rotation_model,reconstructed_buffer_features,reconstruction_time, group_with_feature = True)
			pygplates.reconstruct(list_of_candidate_line_fts,rotation_model,reconstructed_line_features,reconstruction_time, group_with_feature = True)
		final_reconstructed_line_features[:] = []
		final_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
		final_reconstructed_buffer_features[:] = []
		final_reconstructed_buffer_features = find_final_reconstructed_geometries(reconstructed_buffer_features,pygplates.PolygonOnSphere)
		#clearing lists
		reconstructed_line_features[:] = []
		reconstructed_buffer_features[:] = []
		
		for line_ft,line in final_reconstructed_line_features:
			#obtain the plate id 
			plate_id = line_ft.get_reconstruction_plate_id()
			
			list_of_associated_buffers = [(buffer_ft,buffer) for (buffer_ft,buffer) in final_reconstructed_buffer_features if (buffer_ft.get_reconstruction_plate_id() == plate_id)]
			#list_of_associated_buffers = final_reconstructed_buffer_features
			#check to see how many buffers having a spatial relationship with line_ft
			count_buffers = 0
			count_points = 0
			for buffer_ft,buffer in list_of_associated_buffers:
				if (buffer.partition(line) == pygplates.PolygonOnSphere.PartitionResult.intersecting or buffer.partition(line) == pygplates.PolygonOnSphere.PartitionResult.inside):
					count_buffers = count_buffers + 1
					count_points = count_points + int(buffer_ft.get_description())
			if (count_buffers > 0):
				#in the future when the new GPlates released we will create 2 new properties - for now we will use description field
				new_line_ft = line_ft.clone()
				new_line_ft.set_description(str(count_buffers)+"_"+str(count_points))
				new_line_ft.set_valid_time(reconstruction_time + (0.500 * interval), reconstruction_time - (0.500 * interval))
			
				integer_property = pygplates.XsInteger(count_buffers)
				property_added = ft.add(gpml_number_of_buffers,integer_property,pygplates.VerifyInformationModel.no)
				integer_property = pygplates.XsInteger(count_points)
				property_added = ft.add(gpml_number_of_points,integer_property,pygplates.VerifyInformationModel.no)
		
				final_list_of_line_fts.append(new_line_ft)
		if (output_freq > 0.00):
			if ((from_age - reconstruction_time) >= (output_freq * interval)):
				print("number of candidates in final_list_of_line_fts")
				print(len(final_list_of_line_fts))
				if (write_output == True):
					outputLinesFeatureCollection = pygplates.FeatureCollection(final_list_of_line_fts)
					
					outputLinesFile = "possible_subduction_zones_for_future_convergence_consider_all_buffers"+modelname+"_"+str(from_age)+"_"+str(reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".shp"
					outputLinesFeatureCollection.write(outputLinesFile)
		
					outputLinesFile = "possible_subduction_zones_for_future_convergence_consider_all_buffers"+modelname+"_"+str(from_age)+"_"+str(reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".gpml"
					outputLinesFeatureCollection.write(outputLinesFile)
				last_output_shp = reconstruction_time
				#clear the list 
				final_list_of_line_fts[:] = []
			elif (last_output_shp - reconstruction_time >= (output_freq * interval)):
				print("number of candidates in final_list_of_line_fts")
				print(len(final_list_of_line_fts))
				if (write_output == True):
					outputLinesFeatureCollection = pygplates.FeatureCollection(final_list_of_line_fts)
					
					outputLinesFile = "possible_subduction_zones_for_future_convergence_consider_all_buffers"+modelname+"_"+str(last_output_shp)+"_"+str(reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".shp"
					outputLinesFeatureCollection.write(outputLinesFile)
		
					outputLinesFile = "possible_subduction_zones_for_future_convergence_consider_all_buffers"+modelname+"_"+str(last_output_shp)+"_"+str(reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".gpml"
					outputLinesFeatureCollection.write(outputLinesFile)
				last_output_shp = reconstruction_time
				#clear the list 
				final_list_of_line_fts[:] = []
			elif (reconstruction_time == to_age):
				print("number of candidates in final_list_of_line_fts")
				print(len(final_list_of_line_fts))
				if (write_output == True):
					outputLinesFeatureCollection = pygplates.FeatureCollection(final_list_of_line_fts)
					
					outputLinesFile = "possible_subduction_zones_for_future_convergence_consider_all_buffers"+modelname+"_"+str(last_output_shp)+"_"+str(to_age)+"_"+str(interval)+"Ma_"+mmddyy+".shp"
					outputLinesFeatureCollection.write(outputLinesFile)
		
					outputLinesFile = "possible_subduction_zones_for_future_convergence_consider_all_buffers"+modelname+"_"+str(last_output_shp)+"_"+str(to_age)+"_"+str(interval)+"Ma_"+mmddyy+".gpml"
					outputLinesFeatureCollection.write(outputLinesFile)
				last_output_shp = reconstruction_time
				#clear the list 
				final_list_of_line_fts[:] = []
		#update reconstruction_time
		reconstruction_time = reconstruction_time - interval
		
	if (output_freq == 0.00):
		print("number of candidates in final_list_of_line_fts")
		print(len(final_list_of_line_fts))
		if (write_output == True):
			outputLinesFeatureCollection = pygplates.FeatureCollection(final_list_of_line_fts)
			outputLinesFile = "possible_subduction_zones_for_future_convergence_consider_all_buffers"+modelname+"_"+str(from_age)+"_"+str(to_age)+"_"+str(interval)+"Ma_"+mmddyy+".shp"
			outputLinesFeatureCollection.write(outputLinesFile)
		
			outputLinesFile = "possible_subduction_zones_for_future_convergence_consider_all_buffers"+modelname+"_"+str(from_age)+"_"+str(to_age)+"_"+str(interval)+"Ma_"+mmddyy+".gpml"
			outputLinesFeatureCollection.write(outputLinesFile)

def find_upper_plate_ft(line_1_ft, line_2_ft, possible_line_fts_for_subduction_zone, reconstruction_time):
	#using the left_plate and right_plate associated with line_1_ft and line_2_ft to find the ft in all possible line fts
	left_plate_of_1 = line_1_ft.get_left_plate()
	right_plate_of_1 = line_1_ft.get_right_plate()
	
	left_plate_of_2 = line_2_ft.get_left_plate()
	right_plate_of_2 = line_2_ft.get_right_plate()
	
	narrow_list_of_fts = []
	narrow_list_of_fts[:] = []
	
	found_1 = None
	found_2 = None
	for ft in possible_line_fts_for_subduction_zone:
		if (ft.is_valid_at_time(reconstruction_time)):
			if (ft.get_left_plate() == left_plate_of_1 and ft.get_right_plate() == right_plate_of_1):
				found_1 = ft
			elif (ft.get_left_plate() == left_plate_of_2 and ft.get_right_plate() == right_plate_of_2):
				found_2 = ft
	return found_1,found_2
	
def create_feature_for_convergent_zone_from_PointFeature_data(line_1_ft, line_1, line_2_ft, line_2, possible_line_fts_for_subduction_zone, rotation_model, reconstruction_time, reference):
	found_1,found_2 = find_upper_plate_ft(line_1_ft, line_2_ft, possible_line_fts_for_subduction_zone, reconstruction_time)
	#obtain GDU id for line_1 and line_2 fts
	GDU_id_1 = line_1_ft.get_reconstruction_plate_id()
	GDU_id_2 = line_2_ft.get_reconstruction_plate_id()
	
	plate_id_1 = line_1_ft.get_reconstruction_plate_id()
	plate_id_2 = line_2_ft.get_reconstruction_plate_id()
	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		#create a new cursor
		cur = conn.cursor()
		sql = """ INSERT INTO tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, line_1_ft_name, line_2_ft_name, tectonic_motion) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
		cur.execute(sql,((reconstruction_time,plate_id_1,plate_id_2,line_1_ft.get_feature_id().get_string(),line_2_ft.get_feature_id().get_string(),line_1_ft.get_name(),line_2_ft.get_name(),'Convergence')))
		#commit the changes to the database
		conn.commit()
		#close communication with the database
		cur.close()
	except (Exception, psycopg2.DatabaseError) as error:
		print("Error in find_rift_segment_and_transform_faults_v1")
		print(error)
		exit()
	finally:
		if conn is not None:
			conn.close()
	
	#left and right GDU_id
	left_plate_for_line_1_ft = line_1_ft.get_left_plate()
	right_plate_for_line_1_ft = line_1_ft.get_right_plate()
	left_plate_for_line_2_ft = line_2_ft.get_left_plate()
	right_plate_for_line_2_ft = line_2_ft.get_right_plate()
	
	final_left_1 = 0 
	final_right_1 = 0
	final_left_2 = 0 
	final_right_2 = 0
	rotation_direction = None 
	
	_,line_1_ft_end_age = line_1_ft.get_valid_time()
	_,line_2_ft_end_age = line_2_ft.get_valid_time()
	
	if (left_plate_for_line_1_ft == line_1_ft.get_reconstruction_plate_id()):
		final_left_1 = left_plate_for_line_1_ft
	elif (right_plate_for_line_1_ft == line_1_ft.get_reconstruction_plate_id()):
		final_right_1 = right_plate_for_line_1_ft
	
	if (left_plate_for_line_2_ft == line_2_ft.get_reconstruction_plate_id()):
		final_left_2 = left_plate_for_line_2_ft
	elif (right_plate_for_line_2_ft == line_2_ft.get_reconstruction_plate_id()):
		final_right_2 = right_plate_for_line_2_ft
		
	if (final_left_1 == 0):
		final_left_1 = line_2_ft.get_reconstruction_plate_id()
	elif (final_right_1 == 0):
		final_right_1 = line_2_ft.get_reconstruction_plate_id()
	
	if (final_left_2 == 0):
		final_left_2 = line_1_ft.get_reconstruction_plate_id()
	elif (final_right_2 == 0):
		final_right_2 = line_1_ft.get_reconstruction_plate_id()
	
	# if (final_left_1 == -1 and final_right_1 != -1):
		# final_left_1 == line_2_ft.get_reconstruction_plate_id()
	# elif (final_left_1 != -1 and final_right_1 == -1):
		# final_right_1 == line_2_ft.get_reconstruction_plate_id()
	
	# if (final_left_2 == -1 and final_right_2 != -1):
		# final_left_2 == line_1_ft.get_reconstruction_plate_id()
	# elif (final_left_2 != -1 and final_right_2 == -1):
		# final_right_2 == line_1_ft.get_reconstruction_plate_id()
	
	if (found_1 is not None and found_2 is None):
		#line_1_ft is on upper_plate and most likely a subduction_zone
		featType = pygplates.FeatureType.gpml_subduction_zone
		subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
		#subduction_zone.set_left_plate(final_left)
		#subduction_zone.set_right_plate(final_right)
		
		featType = pygplates.FeatureType.gpml_passive_continental_boundary
		passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
		#passive_margin.set_left_plate(final_left)
		#passive_margin.set_right_plate(final_right)
		
		#subduction_zone.set_description('subduction_zone')
		#passive_margin.set_description('passive_margin_subduction_zone')
		
		subduction_zone.set_description('upper_plate_margin')
		passive_margin.set_description('lower_plate_margin')
		# conn = None 
		# try:
			# #read database config
			# params = config()
			# #connect to the PostgreSQL
			# conn = psycopg2.connect(**params)
			# #create a new cursor
			# cur = conn.cursor()
			# sql = """ INSERT INTO tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, line_1_ft_name, line_2_ft_name, tectonic_motion) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
			# cur.execute(sql,((reconstruction_time,plate_id_1,plate_id_2,line_1_ft.get_feature_id().get_string(),line_2_ft.get_feature_id().get_string(),line_1_ft.get_name(),line_2_ft.get_name(),'Convergence')))
			# #cur.execute(sql,((reconstruction_time,plate_id_1,plate_id_2,line_1_ft.get_feature_id().get_string(),line_2_ft.get_feature_id().get_string(),line_1_ft.get_name(),line_2_ft.get_name(),'Convergence')))
			# #commit the changes to the database
			# conn.commit()
			# #close communication with the database
			# cur.close()
		# except (Exception, psycopg2.DatabaseError) as error:
			# print("Error in find_rift_segment_and_transform_faults_v1")
			# print(error)
			# exit()
		# finally:
			# if conn is not None:
				# conn.close()
		
		if (reference is not None):
			pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
			pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
		else:
			pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
			pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
		
		subduction_zone.set_left_plate(final_left_1)
		subduction_zone.set_right_plate(final_right_1)
		passive_margin.set_left_plate(final_left_2)
		passive_margin.set_right_plate(final_right_2)
		
		return [subduction_zone,passive_margin]
		
	elif (found_1 is None and found_2 is not None):
		#line_2_ft is on upper_plate and most likely a subduction_zone
		featType = pygplates.FeatureType.gpml_subduction_zone
		subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
		#subduction_zone.set_left_plate(final_left)
		#subduction_zone.set_right_plate(final_right)
		
		featType = pygplates.FeatureType.gpml_passive_continental_boundary
		passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
		#passive_margin.set_left_plate(final_left)
		#passive_margin.set_right_plate(final_right)
		
		# subduction_zone.set_description('subduction_zone')
		# passive_margin.set_description('passive_margin_subduction_zone')
		subduction_zone.set_description('upper_plate_margin')
		passive_margin.set_description('lower_plate_margin')
		
		if (reference is not None):
			pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
			pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
		else:
			pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
			pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
		
		passive_margin.set_left_plate(final_left_1)
		passive_margin.set_right_plate(final_right_1)
		subduction_zone.set_left_plate(final_left_2)
		subduction_zone.set_right_plate(final_right_2)
		
		return [subduction_zone,passive_margin]
	elif (found_1 is None and found_2 is None):
		#based on deposits data we cannot tell which one is on the upper plate
		return [None,None]
	elif (found_1 is not None and found_2 is not None):
		#both have relationship with VMS deposits we need to check which one has a higher number of deposits 
		#gpml_number_of_buffers = pygplates.PropertyName.create_gpml('number_of_buffers')
		#number_of_buffers_for_1 = found_1.get(gpml_number_of_buffers)
		#number_of_buffers_for_2 = found_2.get(gpml_number_of_buffers)
		counts_1 = found_1.get_description().split('_')
		number_of_buffers_for_1 = int(counts_1[0])
		count_points_1 = int(counts_1[1])
		counts_2 = found_2.get_description().split('_')
		number_of_buffers_for_2 = int(counts_2[0])
		count_points_2 = int(counts_2[1])
		if (number_of_buffers_for_1 > number_of_buffers_for_2):
			#line_1_ft is on upper_plate and most likely a subduction_zone
			featType = pygplates.FeatureType.gpml_subduction_zone
			subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
			#subduction_zone.set_left_plate(final_left)
			#subduction_zone.set_right_plate(final_right)
		
			featType = pygplates.FeatureType.gpml_passive_continental_boundary
			passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
			#passive_margin.set_left_plate(final_left)
			#passive_margin.set_right_plate(final_right)
		
			#subduction_zone.set_description('subduction_zone')
			#passive_margin.set_description('passive_margin_subduction_zone')
			subduction_zone.set_description('upper_plate_margin')
			passive_margin.set_description('lower_plate_margin')
		
			if (reference is not None):
				pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
				pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
			else:
				pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
				pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
			
			subduction_zone.set_left_plate(final_left_1)
			subduction_zone.set_right_plate(final_right_1)
			passive_margin.set_left_plate(final_left_2)
			passive_margin.set_right_plate(final_right_2)
			
			return [subduction_zone,passive_margin]
		elif (number_of_buffers_for_1 < number_of_buffers_for_2):
			#line_2_ft is on upper_plate and most likely a subduction_zone
			featType = pygplates.FeatureType.gpml_subduction_zone
			subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
			#subduction_zone.set_left_plate(final_left)
			#subduction_zone.set_right_plate(final_right)
		
			featType = pygplates.FeatureType.gpml_passive_continental_boundary
			passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
			#passive_margin.set_left_plate(final_left)
			#passive_margin.set_right_plate(final_right)
		
			#subduction_zone.set_description('subduction_zone')
			#passive_margin.set_description('passive_margin_subduction_zone')
			subduction_zone.set_description('upper_plate_margin')
			passive_margin.set_description('lower_plate_margin')
		
			if (reference is not None):
				pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
				pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
			else:
				pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
				pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
			
			passive_margin.set_left_plate(final_left_1)
			passive_margin.set_right_plate(final_right_1)
			subduction_zone.set_left_plate(final_left_2)
			subduction_zone.set_right_plate(final_right_2)
			
			return [subduction_zone,passive_margin]
		else:
			return [None,None]

def create_feature_for_unknown_margin_convergent_zone(line_1_ft, line_1, line_2_ft, line_2, rotation_model, reconstruction_time, reference):
	#obtain GDU id for line_1 and line_2 fts
	GDU_id_1 = line_1_ft.get_reconstruction_plate_id()
	GDU_id_2 = line_2_ft.get_reconstruction_plate_id()

	conn = None 
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		#create a new cursor
		cur = conn.cursor()
		sql = """ INSERT INTO tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, line_1_ft_name, line_2_ft_name, tectonic_motion) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
		cur.execute(sql,((reconstruction_time,GDU_id_1,GDU_id_2,line_1_ft.get_feature_id().get_string(),line_2_ft.get_feature_id().get_string(),line_1_ft.get_name(),line_2_ft.get_name(),'Convergence')))
		#commit the changes to the database
		conn.commit()
		#close communication with the database
		cur.close()
	except (Exception, psycopg2.DatabaseError) as error:
		print("Error in find_rift_segment_and_transform_faults_v1")
		print(error)
		exit()
	finally:
		if conn is not None:
			conn.close()

	#left and right GDU_id
	left_plate_for_line_1_ft = line_1_ft.get_left_plate()
	right_plate_for_line_1_ft = line_1_ft.get_right_plate()
	left_plate_for_line_2_ft = line_2_ft.get_left_plate()
	right_plate_for_line_2_ft = line_2_ft.get_right_plate()
	
	final_left_1 = 0 
	final_right_1 = 0
	final_left_2 = 0 
	final_right_2 = 0
	rotation_direction = None 
	
	_,line_1_ft_end_age = line_1_ft.get_valid_time()
	_,line_2_ft_end_age = line_2_ft.get_valid_time()
	
	if (left_plate_for_line_1_ft == line_1_ft.get_reconstruction_plate_id()):
		final_left_1 = left_plate_for_line_1_ft
	elif (right_plate_for_line_1_ft == line_1_ft.get_reconstruction_plate_id()):
		final_right_1 = right_plate_for_line_1_ft
	
	if (left_plate_for_line_2_ft == line_2_ft.get_reconstruction_plate_id()):
		final_left_2 = left_plate_for_line_2_ft
	elif (right_plate_for_line_2_ft == line_2_ft.get_reconstruction_plate_id()):
		final_right_2 = right_plate_for_line_2_ft
	
	# if (final_left_1 == -1 and final_right_1 != -1):
		# final_left_1 == line_2_ft.get_reconstruction_plate_id()
	# elif (final_left_1 != -1 and final_right_1 == -1):
		# final_right_1 == line_2_ft.get_reconstruction_plate_id()
	
	if (final_left_1 == 0):
		final_left_1 = line_2_ft.get_reconstruction_plate_id()
	elif (final_right_1 == 0):
		final_right_1 = line_2_ft.get_reconstruction_plate_id()
	
	# if (final_left_2 == -1 and final_right_2 != -1):
		# final_left_2 == line_1_ft.get_reconstruction_plate_id()
	# elif (final_left_2 != -1 and final_right_2 == -1):
		# final_right_2 == line_1_ft.get_reconstruction_plate_id()
	
	if (final_left_2 == 0):
		final_left_2 = line_1_ft.get_reconstruction_plate_id()
	elif (final_right_2 == 0):
		final_right_2 = line_1_ft.get_reconstruction_plate_id()
	
	featType = pygplates.FeatureType.gpml_passive_continental_boundary
	
	passive_margin_1 = None 
	passive_margin_2 = None
	if (line_1_ft_end_age > line_2_ft_end_age):
		passive_margin_1 = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
		passive_margin_2 = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
	else:
		passive_margin_1 = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
		passive_margin_2 = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
	
	passive_margin_1.set_description('unknown_margin_convergent_zone')
	passive_margin_2.set_description('unknown_margin_convergent_zone')
	
	print('final_left_1')
	print(final_left_1)
	print('final_right_1')
	print(final_right_1)
	print('final_left_2')
	print(final_left_2)
	print('final_right_2')
	print(final_right_2)
	
	print('line_1_ft.get_reconstruction_plate_id()')
	print(line_1_ft.get_reconstruction_plate_id())
	print('left_plate_for_line_1_ft')
	print(left_plate_for_line_1_ft)
	print('right_plate_for_line_1_ft')
	print(right_plate_for_line_1_ft)
	
	print('line_2_ft.get_reconstruction_plate_id()')
	print(line_2_ft.get_reconstruction_plate_id())
	print('left_plate_for_line_2_ft')
	print(left_plate_for_line_2_ft)
	print('right_plate_for_line_2_ft')
	print(right_plate_for_line_2_ft)
	
	passive_margin_1.set_left_plate(final_left_1)
	passive_margin_1.set_right_plate(final_right_1)
	passive_margin_2.set_left_plate(final_left_2)
	passive_margin_2.set_right_plate(final_right_2)

	if (reference is not None):
		pygplates.reverse_reconstruct(passive_margin_1,rotation_model,reconstruction_time,reference)
		pygplates.reverse_reconstruct(passive_margin_2,rotation_model,reconstruction_time,reference)
	else:
		pygplates.reverse_reconstruct(passive_margin_1,rotation_model,reconstruction_time)
		pygplates.reverse_reconstruct(passive_margin_2,rotation_model,reconstruction_time)
	return [passive_margin_1,passive_margin_2]	
	
def create_feature_for_convergent_zone(line_1_ft, line_1, line_2_ft, line_2, reconstructed_igneous_buffer_fts, rotation_model, reconstruction_time, reference):
	#obtain GDU id for line_1 and line_2 fts
	GDU_id_1 = line_1_ft.get_reconstruction_plate_id()
	GDU_id_2 = line_2_ft.get_reconstruction_plate_id()
	igneous_buffer_zone_ft_1 = None
	buffer_1 = None 
	count_buffer_zone_1 = 0
	igneous_buffer_zone_ft_2 = None 
	buffer_2 = None 
	count_buffer_zone_2 = 0 
	distance_buffer_1_line_1 = -1
	distance_buffer_2_line_2 = -1
	
	#identify_left_right GDUs
	middle_geometry = identify_middle_geometry_between_two_lines(line_1,line_2)
	if (middle_geometry is None):
		print("Error in create_feature_for_divergent_zone")
		print("Error here is GDU_id_1")
		print(line_1_ft.get_reconstruction_plate_id())
		print("Error here is GDU_id_2")
		print(line_2_ft.get_reconstruction_plate_id())
	mid_point_line_1 = get_midpoint_of_line(line_1)
	mid_point_line_2 = get_midpoint_of_line(line_2)
	result_line_1 = identify_left_right(line_1,mid_point_line_1) 
	result_line_2 = identify_left_right(line_2,mid_point_line_2)
	
	#Middle feature to define left and right GDU - borrow the MOR as the FeatureType
	description_str = str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())
	middle_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge,middle_geometry,name = "middle_ft"+description_str,valid_time = (reconstruction_time,0))
	middle_ft.set_reconstruction_method('HalfStageRotationVersion2')
	middle_ft.set_description("stable_zone")
	
	if (result_line_1 == 'Left' and result_line_2 == 'Right'):
		middle_ft.set_left_plate(line_1_ft.get_reconstruction_plate_id())
		middle_ft.set_right_plate(line_2_ft.get_reconstruction_plate_id())
	elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
		middle_ft.set_left_plate(line_2_ft.get_reconstruction_plate_id())
		middle_ft.set_right_plate(line_1_ft.get_reconstruction_plate_id())
	else:
		print("Error in create_feature_for_stable_zone")
		print("Error here is GDU_id_1")
		print(line_1_ft.get_reconstruction_plate_id())
		print("Error here is GDU_id_2")
		print(line_2_ft.get_reconstruction_plate_id())
		print("Result of line_1 and line_2")
		print(result_line_1)
		print(result_line_2)
		print("Here is reconstruction_time")
		print(reconstruction_time)
		print("here is the relative orientation of the line_1 and line_2")
		print(is_line_spanning_latitude_or_longitude(line_1))
		print(is_line_spanning_latitude_or_longitude(line_2))
		if (reference is None):
			pygplates.reverse_reconstruct(middle_ft,rotation_model,reconstruction_time)
		else:
			pygplates.reverse_reconstruct(middle_ft,rotation_model,reconstruction_time,reference)
		outputLinesFeatureCollection = pygplates.FeatureCollection([middle_ft,line_1_ft,line_2_ft])
		outputLinesFile = "suspected_boundaries_features_to_create_convergent_zone_"+"_"+str(line_1_ft.get_reconstruction_plate_id())+"_"+str(line_2_ft.get_reconstruction_plate_id())+"_"+str(reconstruction_time)+"Ma.shp"
		outputLinesFeatureCollection.write(outputLinesFile)
		
	for buffer_ft, buffer_geometry in reconstructed_igneous_buffer_fts:
		if (buffer_ft.get_reconstruction_plate_id() == GDU_id_1):
			buffer_1 = buffer_geometry
			igneous_buffer_zone_ft_1 = buffer_ft
			current_distance_1 = pygplates.GeometryOnSphere.distance(buffer_1,line_1)
			if (distance_buffer_1_line_1 == -1.00):
				distance_buffer_1_line_1 = current_distance_1
			elif (distance_buffer_1_line_1 >= 0 and current_distance_1 < distance_buffer_1_line_1):
				distance_buffer_1_line_1 = current_distance_1
			if (current_distance_1 == 0.00):
				igneous_buffer_zone_ft_1 = buffer_ft
				count_buffer_zone_1 = count_buffer_zone_1 + 1
		elif (buffer_ft.get_reconstruction_plate_id() == GDU_id_2):
			buffer_2 = buffer_geometry
			igneous_buffer_zone_ft_2 = buffer_ft
			current_distance_2 = pygplates.GeometryOnSphere.distance(buffer_2,line_2)
			if (distance_buffer_2_line_2 == -1.00):
				distance_buffer_2_line_2 = current_distance_2
			elif (distance_buffer_2_line_2 >= 0 and current_distance_2 < distance_buffer_2_line_2):
				distance_buffer_2_line_2 = current_distance_2
			if (current_distance_2 == 0.00):
				igneous_buffer_zone_ft_2 = buffer_ft
				count_buffer_zone_2 = count_buffer_zone_2 + 1
	#evaluate both buffer zone features to identify upper plate
	_,line_1_ft_end_age = line_1_ft.get_valid_time()
	_,line_2_ft_end_age = line_2_ft.get_valid_time()
	
	if (count_buffer_zone_1 > count_buffer_zone_2): #upper_plate is feature_1
		featType = pygplates.FeatureType.gpml_subduction_zone
		subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
		featType = pygplates.FeatureType.gpml_passive_continental_boundary
		passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
		
		if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
			subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		else:
			subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
		if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
			passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		else:
			passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		
		subduction_zone.set_description('subduction_zone')
		passive_margin.set_description('passive_margin_subduction_zone')
		
		# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
			# subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			# subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
			# passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			# passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
			# subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			# subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
			# passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			# passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
			
		if (reference is not None):
			pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
			pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
		else:
			pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
			pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
		return [subduction_zone,passive_margin]
	elif (count_buffer_zone_1 < count_buffer_zone_2): #upper_plate is feature_2
		featType = pygplates.FeatureType.gpml_subduction_zone
		subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
		featType = pygplates.FeatureType.gpml_passive_continental_boundary
		passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
		if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
			subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		else:
			subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
		if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
			passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		else:
			passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		
		subduction_zone.set_description('subduction_zone')
		passive_margin.set_description('passive_margin_subduction_zone')
		# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
			# subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			# subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
			# passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
			# passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
		# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
			# subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			# subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
			# passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
			# passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		if (reference is not None):
			pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
			pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
		else:
			pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
			pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
		return [subduction_zone,passive_margin]
	elif (count_buffer_zone_1 == count_buffer_zone_2):
		if (count_buffer_zone_1 > 0 and count_buffer_zone_2 > 0):
			#both buffer zones are not intersecting with the lines 
			if (distance_buffer_1_line_1 < distance_buffer_2_line_2):
				#upper plate is feature_1
				featType = pygplates.FeatureType.gpml_subduction_zone
				subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
				featType = pygplates.FeatureType.gpml_passive_continental_boundary
				passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
				if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
					subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				else:
					subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
				if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
					passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				else:
					passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				subduction_zone.set_description('subduction_zone')
				passive_margin.set_description('passive_margin_subduction_zone')
				
				# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
					# subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					# subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
					# subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					# subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				if (reference is not None):
					pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
					pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
				else:
					pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
					pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
				return [subduction_zone,passive_margin]
			elif (distance_buffer_1_line_1 > distance_buffer_2_line_2):
				#upper plate is feature_2
				featType = pygplates.FeatureType.gpml_subduction_zone
				subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
				featType = pygplates.FeatureType.gpml_passive_continental_boundary
				passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
				# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
					# subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					# subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
					# subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					# subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
					subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				else:
					subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
				if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
					passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				else:
					passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				
				subduction_zone.set_description('subduction_zone')
				passive_margin.set_description('passive_margin_subduction_zone')
				
				if (reference is not None):
					pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
					pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
				else:
					pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
					pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
				return [subduction_zone,passive_margin]
			else: 
				#do not know thus both of them are passive margins 
				final_end_age = -1.00
				if (line_1_ft_end_age > line_2_ft_end_age):
					final_end_age = line_1_ft_end_age
				else:
					final_end_age = line_2_ft_end_age
				featType = pygplates.FeatureType.gpml_passive_continental_boundary
				passive_margin_1 = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
				passive_margin_2 = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,0.00),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
				left_2 = line_2_ft.get_left_plate()
				right_2 = line_2_ft.get_right_plate()
				# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
					# passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
					# passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				
				if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
					passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				else:
					passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
				if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
					passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				else:
					passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())	
				passive_margin_1.set_description('unknown_margin_convergent_zone')
				passive_margin_2.set_description('unknown_margin_convergent_zone')					
					
				if (reference is not None):
					pygplates.reverse_reconstruct(passive_margin_1,rotation_model,reconstruction_time,reference)
					pygplates.reverse_reconstruct(passive_margin_2,rotation_model,reconstruction_time,reference)
				else:
					pygplates.reverse_reconstruct(passive_margin_1,rotation_model,reconstruction_time)
					pygplates.reverse_reconstruct(passive_margin_2,rotation_model,reconstruction_time)
				return [passive_margin_1,passive_margin_2]	
		elif (count_buffer_zone_1 == 0 and count_buffer_zone_2 == 0):
			if (distance_buffer_1_line_1 < distance_buffer_2_line_2):
				#upper plate is feature_1
				featType = pygplates.FeatureType.gpml_subduction_zone
				subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
				featType = pygplates.FeatureType.gpml_passive_continental_boundary
				passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
				if (result_line_1 == 'Left' and result_line_2 == 'Right'):
					subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
					subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				
				if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
					subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				else:
					subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
				if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
					passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				else:
					passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				
				subduction_zone.set_description('subduction_zone')
				passive_margin.set_description('passive_margin_subduction_zone')
				
				if (reference is not None):
					pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
					pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
				else:
					pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
					pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
				return [subduction_zone,passive_margin]
			elif (distance_buffer_1_line_1 > distance_buffer_2_line_2):
				#upper plate is feature_2
				featType = pygplates.FeatureType.gpml_subduction_zone
				subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
				featType = pygplates.FeatureType.gpml_passive_continental_boundary
				passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
				# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
					# subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					# subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
					# subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					# subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					# passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					# passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
					subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				else:
					subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
				if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
					passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
				else:
					passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
					passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
				
				subduction_zone.set_description('subduction_zone')
				passive_margin.set_description('passive_margin_subduction_zone')
				
				if (reference is not None):
					pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
					pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
				else:
					pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
					pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
				return [subduction_zone,passive_margin]
			else:
				#iterate through every buffer zone to check whether there is any buffer zone intersect either line even though buffer features do not have the same GDU_id with either line feature 
				count_intersection_with_line_ft_1 = 0
				count_intersection_with_line_ft_2 = 0 
				for buffer_ft, buffer_geometry in reconstructed_igneous_buffer_fts:
					if (buffer_geometry.partition(line_1) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
						count_intersection_with_line_ft_1 = count_intersection_with_line_ft_1 + 1
					if (buffer_geometry.partition(line_2) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
						count_intersection_with_line_ft_2 = count_intersection_with_line_ft_2 + 1
				if (count_intersection_with_line_ft_1 > count_intersection_with_line_ft_2):#upper_plate is feature_1
					featType = pygplates.FeatureType.gpml_subduction_zone
					subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_1_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
					featType = pygplates.FeatureType.gpml_passive_continental_boundary
					passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
					# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
						# subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						# subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
						# passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						# passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
						# subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						# subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
						# passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						# passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
						subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					else:
						subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
					if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
						passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					else:
						passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					
					subduction_zone.set_description('subduction_zone')
					passive_margin.set_description('passive_margin_subduction_zone')
					
					if (reference is not None):
						pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
						pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
					else:
						pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
						pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
					return [subduction_zone,passive_margin]	
				elif (count_intersection_with_line_ft_1 < count_intersection_with_line_ft_2):#upper_plate is feature_2
					featType = pygplates.FeatureType.gpml_subduction_zone
					subduction_zone = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
					featType = pygplates.FeatureType.gpml_passive_continental_boundary
					passive_margin = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,line_2_ft_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
					# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
						# subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						# subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
						# passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						# passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
						# subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						# subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
						# passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						# passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
						subduction_zone.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						subduction_zone.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					else:
						subduction_zone.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						subduction_zone.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
					if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
						passive_margin.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						passive_margin.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					else:
						passive_margin.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						passive_margin.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					
					subduction_zone.set_description('subduction_zone')
					passive_margin.set_description('passive_margin_subduction_zone')
					
					if (reference is not None):
						pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time,reference)
						pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time,reference)
					else:
						pygplates.reverse_reconstruct(subduction_zone,rotation_model,reconstruction_time)
						pygplates.reverse_reconstruct(passive_margin,rotation_model,reconstruction_time)
					return [subduction_zone,passive_margin]
				else:
					final_end_age = -1.00
					if (line_1_ft_end_age > line_2_ft_end_age):
						final_end_age = line_1_ft_end_age
					else:
						final_end_age = line_2_ft_end_age
					#we really don't know thus both of them are passive margin features
					featType = pygplates.FeatureType.gpml_passive_continental_boundary
					passive_margin_1 = pygplates.Feature.create_reconstructable_feature(featType,line_1,name=line_1_ft.get_name(),valid_time = (reconstruction_time,final_end_age),reconstruction_plate_id = line_1_ft.get_reconstruction_plate_id())
					passive_margin_2 = pygplates.Feature.create_reconstructable_feature(featType,line_2,name=line_2_ft.get_name(),valid_time = (reconstruction_time,final_end_age),reconstruction_plate_id = line_2_ft.get_reconstruction_plate_id())
					# if (result_line_1 == 'Left' and result_line_2 == 'Right'):
						# passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						# passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
						# passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						# passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					# elif (result_line_1 == 'Right' and result_line_2 == 'Left'):
						# passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						# passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
						# passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						# passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					if (line_1_ft.get_left_plate() == line_1_ft.get_reconstruction_plate_id()):
						passive_margin_1.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						passive_margin_1.set_right_plate(line_2_ft.get_reconstruction_plate_id())
					else:
						passive_margin_1.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						passive_margin_1.set_right_plate(line_1_ft.get_reconstruction_plate_id())
		
					if (line_2_ft.get_left_plate() == line_2_ft.get_reconstruction_plate_id()):
						passive_margin_2.set_left_plate(line_2_ft.get_reconstruction_plate_id())
						passive_margin_2.set_right_plate(line_1_ft.get_reconstruction_plate_id())
					else:
						passive_margin_2.set_left_plate(line_1_ft.get_reconstruction_plate_id())
						passive_margin_2.set_right_plate(line_2_ft.get_reconstruction_plate_id())	
					
					passive_margin_1.set_description('unknown_margin_convergent_zone')
					passive_margin_2.set_description('unknown_margin_convergent_zone')	
					
					if (reference is not None):
						pygplates.reverse_reconstruct(passive_margin_1,rotation_model,reconstruction_time,reference)
						pygplates.reverse_reconstruct(passive_margin_2,rotation_model,reconstruction_time,reference)
					else:
						pygplates.reverse_reconstruct(passive_margin_1,rotation_model,reconstruction_time)
						pygplates.reverse_reconstruct(passive_margin_2,rotation_model,reconstruction_time)
					return [passive_margin_1,passive_margin_2]
	print("count_buffer_zone_1")
	print(count_buffer_zone_1)
	print("count_buffer_zone_2")
	print(count_buffer_zone_2)

def record_to_csv_files(tectonic_motion_at_reconstruction_time,invalid_pairs_of_GDUs_at_reconstruction_time,suspecting_tectonic_motion,begin_reconstruction_time,end_reconstruction_time,interval,mmddyy,modelname):
	#later for recording tectonic_motion
	tectonic_motion_csv_file = "tectonic_motion_csv_file_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".csv"
		
	for time,ref_GDU_ID,other_GDU_ID,ref_ft_id,other_ft_id,result_from_dist_eval,result_from_vec_eval,tectonic_motion_for_boundaries in tectonic_motion_at_reconstruction_time:
		l = [time,ref_GDU_ID,other_GDU_ID,ref_ft_id,other_ft_id,result_from_dist_eval,result_from_vec_eval,tectonic_motion_for_boundaries]
		#write to a csv file 
		if (os.path.isfile(tectonic_motion_csv_file)):
			with open (tectonic_motion_csv_file,'ab') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(l)
		else:
			with open (tectonic_motion_csv_file,'ab') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(['time','ref_GDU_ID','other_GDU_ID','ref_ft_id','other_ft_id','result_from_dist_eval','result_from_vec_eval','tectonic_motion_for_boundaries'])
				recordwriter_csv.writerow(l)
		
	#later for recording invalid_pairs_of_GDUs_at_reconstruction_time
	invalid_pairs_of_GDU_csv_file = "invalid_pairs_of_GDU_csv_file_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".csv"
		
	for time,ref_GDU_ID,other_GDU_ID in invalid_pairs_of_GDUs_at_reconstruction_time:
		l = [time,ref_GDU_ID,other_GDU_ID]
		#write to a csv file 
		if (os.path.isfile(invalid_pairs_of_GDU_csv_file)):
			with open (invalid_pairs_of_GDU_csv_file,'ab') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(l)
		else:
			with open (invalid_pairs_of_GDU_csv_file,'ab') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(['time','ref_GDU_ID','other_GDU_ID'])
				recordwriter_csv.writerow(l)
	
	suspecting_tectonic_motion_csv_file = "suspecting_tectonic_motion_csv_file_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(end_reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".csv"
	for time,ref_GDU_ID,other_GDU_ID,ref_ft_id,other_ft_id,result_from_dist_eval,result_from_vec_eval in suspecting_tectonic_motion:
		l = [time,ref_GDU_ID,other_GDU_ID,ref_ft_id,other_ft_id,result_from_dist_eval,result_from_vec_eval]
		#write to a csv file 
		if (os.path.isfile(suspecting_tectonic_motion_csv_file)):
			with open (suspecting_tectonic_motion_csv_file,'ab') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(l)
		else:
			with open (suspecting_tectonic_motion_csv_file,'ab') as csvfile:	
				recordwriter_csv = csv.writer(csvfile,delimiter=';')
				recordwriter_csv.writerow(['time','ref_GDU_ID','other_GDU_ID','ref_ft_id','other_ft_id','result_from_dist_eval','result_from_vec_eval'])
				recordwriter_csv.writerow(l)

def identify_plate_tectonic_boundaries(rot_file,polygon_feature_file,centroid_features_file,topological_line_features_file,possible_line_fts_for_subduction_zone_deposits_file, possible_line_fts_for_subduction_zone_igneous_file,begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,difference_distance_km,cos_value_for_transform,reference,number_of_intervals,modelname,mmddyy,freq_writing_csv_files):
	#read all input files
	print('This is a rotation_file')
	print(rot_file)
	rotation_model = pygplates.RotationModel(rot_file)
	print('This is polygon_feature_file')
	print(polygon_feature_file)
	polygon_features_collection = pygplates.FeatureCollection(polygon_feature_file)
	print('This is topological_line_features_file')
	print(topological_line_features_file)
	print("This is centroid feature file")
	print(centroid_features_file)
	
	#convert temporary_list_of_processed_line_features to FeatureCollection
	#line_features_collection = pygplates.FeatureCollection(topological_line_features_file)
	
	# print('This is igneous_buffer_zone_features_file')
	# print igneous_buffer_zone_features_file
	# igneous_buffer_zone_features_collection = pygplates.FeatureCollection(igneous_buffer_zone_features_file)
	
	print('This is possible_line_fts_for_subduction_zone_deposits_file')
	print(possible_line_fts_for_subduction_zone_deposits_file)
	#possible_line_fts_for_subduction_zone_deposits = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_deposits_file)
	
	print('This is possible_line_fts_for_subduction_zone_igneous_file')
	print(possible_line_fts_for_subduction_zone_igneous_file)
	#possible_line_fts_for_subduction_zone_igneous = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_igneous_file)
	
	
	
	list_of_continental_polygons_fts = polygon_features_collection.get(
			lambda polygon_feature: polygon_feature.get_shapefile_attribute(field_name_for_lithosphere_type) == continental_type_symbol ,pygplates.FeatureReturn.all)

	list_of_centroid_fts = None
	if (centroid_features_file is not None):
		list_of_centroid_fts = pygplates.FeatureCollection(centroid_features_file)
	else:
		list_of_centroid_fts = find_centroid_features(list_of_continental_polygons_fts,True,mmddyy)
	
	
	dictionary_of_neighbours_id = {}
	
	dictionary_of_distance = {}
	dictionary_of_tectonic_motion = {}
	dictionary_of_suspected_motion = {}
	dictionary_of_tectonic_boundaries = {}
	list_of_tectonic_boundaries = []
	
	list_of_invalid_pairs_of_ft = []
	list_of_appropriate_polygon_features = []
	reconstructed_polygon_features = []
	final_reconstructed_polygon_features = []
	list_of_valid_line_features = []
	other_line_fts = []
	reconstructed_line_features = []
	final_reconstructed_line_features = []
	pre_processed_line_features = []
	list_of_valid_point_features = []
	reconstructed_point_features = []
	final_reconstructed_point_features = []
	reconstructed_temp_point_features = []
	final_reconstructed_temp_point_features = []
	
	#list of keep tracks of processed GDUs to avoid override
	recently_updated = []
	#information for csv files
	last_output_csv_files = -1.00

	boundaries_from_dictionary = []
	reconstructed_boundaries = []
	final_reconstructed_boundaries = []
	boundaries = []
	
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time > (end_reconstruction_time - interval)):
		print("Here is reconstruction_time")
		print(reconstruction_time)
		
		#collect garbage
		gc.collect()
		
		#load line fts to FeatureCollection
		line_features_collection = pygplates.FeatureCollection(topological_line_features_file)
		
		if (reconstruction_time == begin_reconstruction_time):
			find_neighbours_for_polygon_features(rotation_model,list_of_continental_polygons_fts,threshold_distance_in_km,dictionary_of_neighbours_id,begin_reconstruction_time,reference)
			last_update_time_for_dictionary_of_neighbours = begin_reconstruction_time
		
		all_possible_line_fts_for_subduction_zone_deposits = None
		possible_line_fts_for_subduction_zone_deposits = None
		if (possible_line_fts_for_subduction_zone_deposits_file is not None):
			all_possible_line_fts_for_subduction_zone_deposits = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_deposits_file)
			temp_possible_line_fts_for_subduction_zone_deposits = all_possible_line_fts_for_subduction_zone_deposits.get(
				lambda feature: feature.is_valid_at_time(reconstruction_time) ,pygplates.FeatureReturn.all)
			possible_line_fts_for_subduction_zone_deposits = [ft.clone() for ft in temp_possible_line_fts_for_subduction_zone_deposits]
			temp_possible_line_fts_for_subduction_zone_deposits = None
			all_possible_line_fts_for_subduction_zone_deposits = None
	
		all_possible_line_fts_for_subduction_zone_igneous = None
		possible_line_fts_for_subduction_zone_igneous = None
		if (possible_line_fts_for_subduction_zone_igneous_file is not None):
			all_possible_line_fts_for_subduction_zone_igneous = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_igneous_file)
			temp_possible_line_fts_for_subduction_zone_igneous = all_possible_line_fts_for_subduction_zone_igneous.get(
				lambda feature: feature.is_valid_at_time(reconstruction_time) ,pygplates.FeatureReturn.all)
			possible_line_fts_for_subduction_zone_igneous = [ft.clone() for ft in temp_possible_line_fts_for_subduction_zone_igneous]
			temp_possible_line_fts_for_subduction_zone_igneous = None
			all_possible_line_fts_for_subduction_zone_igneous = None 
		
		#list_of_centroid_fts = find_centroid_features(list_of_continental_polygons_fts,False,mmddyy)
		
		#to find the mean of difference in distance 
		total_difference_in_distance = 0.00
		count = 0
		
		#empty all containers
		list_of_invalid_pairs_of_ft[:] = []
		list_of_appropriate_polygon_features[:] = []
		reconstructed_polygon_features[:] = []
		final_reconstructed_polygon_features[:] = []
		list_of_valid_line_features[:] = []
		reconstructed_line_features[:] = []
		final_reconstructed_line_features[:] = []
		list_of_valid_point_features[:] = []
		reconstructed_point_features[:] = []
		final_reconstructed_point_features[:] = []
		#igneous_buffer_zone_fts[:] = []
		#reconstructed_buffer_features[:] = []
		#final_reconstructed_buffer_features[:] = []
		
		#check whether or not we need to update the information about neighbours
		if ((last_update_time_for_dictionary_of_neighbours - reconstruction_time)/interval >= number_of_intervals):
			dictionary_of_neighbours_id.clear()
			find_neighbours_for_polygon_features(rotation_model,list_of_continental_polygons_fts,threshold_distance_in_km,dictionary_of_neighbours_id,reconstruction_time,reference)
			last_update_time_for_dictionary_of_neighbours = reconstruction_time
		
		#obtain list of topological line features that are between a continental GDU and an oceanic GDU at the reconstruction time
		for line_ft in line_features_collection:#O(n) where n is number of line features from the initial input 
			type_of_line_ft = line_ft.get_description()
			valid = line_ft.is_valid_at_time(reconstruction_time)
			if (type_of_line_ft == 'CON_OCN' and valid == True):
				list_of_valid_line_features.append(line_ft.clone())
		line_features_collection = None			
		final_list_of_valid_line_fts = list_of_valid_line_features
		print("Here is len(final_list_of_valid_line_fts)")
		print(len(final_list_of_valid_line_fts))
		#reconstructed all features to the reconstruction time 
		if (reference is not None):
			#line_features
			pygplates.reconstruct(final_list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		else:
			#line_features
			pygplates.reconstruct(final_list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
		
		#find final reconstructed geometry for each reconstructed feature 
		final_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
		pre_processed_line_features[:] = []
		#clearing reconstructed_line_features
		reconstructed_line_features[:] = []
		print("here is len(final_reconstructed_line_features)")
		print(len(final_reconstructed_line_features))	
		pre_processed_line_features = final_reconstructed_line_features
		#debug 
		# modified_pre_processed_line_features = list(zip(*(pre_processed_line_features)))
		# print ('modified_pre_processed_line_features')
		# print (modified_pre_processed_line_features)
		# pre_processed_ft_collection = pygplates.FeatureCollection(modified_pre_processed_line_features[0])
		# pre_processed_ft_file = "pre_processed_line_features_"+str(reconstruction_time)+"_"+modelname+"_"+mmddyy+".gpml"
		# pre_processed_ft_collection.write(pre_processed_ft_file)
		# exit()
		
		for appropriate_line_ft,_ in pre_processed_line_features: #O(n) where n is number of pre_processed_line_features
			GDU_id = appropriate_line_ft.get_reconstruction_plate_id()
			polygon_fts = [polygon_ft for polygon_ft in list_of_continental_polygons_fts  if polygon_ft.get_reconstruction_plate_id() == GDU_id and polygon_ft.is_valid_at_time(reconstruction_time)]
			for ft in polygon_fts: #O(m) where m is number of polygon_fts associated with the line feature through GDU_id and reconstruction_time 
				list_of_appropriate_polygon_features.append(ft)
		for appropriate_polygon_ft in list_of_appropriate_polygon_features: #O(m') where m' is the number of polygon_fts in list_of_appropriate_polygon_features
			polygon_ft_id = appropriate_polygon_ft.get_feature_id().get_string()
			for centroid_ft in list_of_centroid_fts: #O(M) where M is the number of continental polygon features from the initial input 
				if (centroid_ft.get_description() == polygon_ft_id):
					list_of_valid_point_features.append(centroid_ft)
		#reconstructed all features to the reconstruction time 
		if (reference is not None):
			#polygon_features
			pygplates.reconstruct(list_of_appropriate_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			#point_features
			pygplates.reconstruct(list_of_valid_point_features,rotation_model,reconstructed_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		else:
			#polygon_features
			pygplates.reconstruct(list_of_appropriate_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time, group_with_feature = True)
			#point_features
			pygplates.reconstruct(list_of_valid_point_features,rotation_model,reconstructed_point_features,reconstruction_time,group_with_feature = True)
		final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
		final_reconstructed_point_features = find_final_reconstructed_geometries(reconstructed_point_features,pygplates.PointOnSphere)
		
		#clearing list containing reconstructed feature geometries
		reconstructed_polygon_features[:] = []
		reconstructed_point_features[:] = []
		print("Here is the length for final_reconstructed_polygon_features")
		print(len(final_reconstructed_polygon_features))
		print("Here is the length for final_reconstructed_point_features")
		print(len(final_reconstructed_point_features))
		recently_updated[:] = []
		for reference_point_ft,reference_point in final_reconstructed_point_features: #O(m') - m' in relationship with appropriate_line_fts
			#get polygon feature id store in point_ft to access dictionary_of_neighbours_id
			reference_feature_id = reference_point_ft.get_description()
			#for checking whether the pair of GDUs are valid 
			reference_ft_id = reference_feature_id
			there_are_neighbours = False
			#get all neighbours
			if (reference_feature_id in dictionary_of_neighbours_id):
				there_are_neighbours = True 
			else:
				#check the update of the dictionary_of_neighbours_id
				if (last_update_time_for_dictionary_of_neighbours > reconstruction_time):
					#update the dictionary because the number_of_intervals is quite big that we cannot capture the details
					dictionary_of_neighbours_id.clear()
					find_neighbours_for_polygon_features(rotation_model,list_of_continental_polygons_fts,threshold_distance_in_km,dictionary_of_neighbours_id,reconstruction_time,reference)
					last_update_time_for_dictionary_of_neighbours = reconstruction_time
					if (reference_feature_id in dictionary_of_neighbours_id):
						there_are_neighbours = True
			if (there_are_neighbours == True):
				neighbours_feature_id = dictionary_of_neighbours_id[reference_feature_id]
				neighbours_reconstructed_polygon_fts = [(polygon_ft,polygon) for polygon_ft,polygon in final_reconstructed_polygon_features if polygon_ft.get_feature_id().get_string() in neighbours_feature_id]
				neighbours_reconstructed_point_fts = [(point_ft,point) for point_ft,point in final_reconstructed_point_features if point_ft.get_description() in neighbours_feature_id]
				
				#debug
				# if (reconstruction_time < 80.00):
					# if (reference_point_ft.get_reconstruction_plate_id() == 10389):
						# print "there are neighbours for 10389 at reconstruction_time < 80.00"
						# print "Here is neighbours_feature_id"
						# print neighbours_feature_id
						# for ft,_ in neighbours_reconstructed_point_fts:
							# print ft.get_reconstruction_plate_id()
						# exit()
				#debug 
				# if (reference_point_ft.get_reconstruction_plate_id() == 11304 or reference_point_ft.get_reconstruction_plate_id() == 11025):
					# if (reconstruction_time == 130.00):
						# print 'reference_point_ft.get_reconstruction_plate_id()'
						# print reference_point_ft.get_reconstruction_plate_id()
						# for neighbour_point_ft,neighbour_point in neighbours_reconstructed_point_fts:
							# print 'neighbour_point_ft.get_reconstruction_plate_id'
							# print neighbour_point_ft.get_reconstruction_plate_id()
						# exit()
						
				#print "Here is the len(neighbours_reconstructed_point_fts)"
				#print len(neighbours_reconstructed_point_fts)
				#print neighbours_reconstructed_point_fts
				#iterate through each neighbour and perform evaluation
				for neighbour_point_ft,neighbour_point in neighbours_reconstructed_point_fts:
					type_of_movement = None 
					#for checking whether the pair of GDUs are valid 
					neighbour_ft_id = neighbour_point_ft.get_description()
					#construct key for dictionary from pair of ids 
					key = construct_key_from_fts_description(reference_point_ft,neighbour_point_ft)
					reverse_key = construct_key_from_fts_description(neighbour_point_ft,reference_point_ft) 
					#if ((key in dictionary_of_distance and key not in recently_updated) or (reverse_key in dictionary_of_distance and reverse_key not in recently_updated)):
					if (((key in dictionary_of_distance) or (reverse_key in dictionary_of_distance)) and (key not in recently_updated) and (reverse_key not in recently_updated)):
						#print "Key"
						#print key
						#print "reverse_key"
						#print reverse_key
						previous_distance = -1.00
						final_key = None 
						if (key in dictionary_of_distance):
							previous_distance = dictionary_of_distance[key]
							final_key = key
						else:
							previous_distance = dictionary_of_distance[reverse_key]
							final_key = reverse_key
						recently_updated.append(final_key)
						
						current_distance = pygplates.GeometryOnSphere.distance(neighbour_point,reference_point)*pygplates.Earth.mean_radius_in_kms
						print("difference btw previous_distance and current_distance")
						print(abs(previous_distance - current_distance))
						#to find the mean of difference in distance
						total_difference_in_distance = abs(previous_distance - current_distance) + total_difference_in_distance
						count = count + 1
						
						result_from_distance_evaluation = None 
						if (abs(previous_distance - current_distance) >= difference_distance_km):
							print("Info: distance check")
							#perform comparison between previous_distance and current_distance
							#based on distance evaluation
							if (previous_distance > current_distance):
								result_from_distance_evaluation = Change.Decrease
							elif (previous_distance == current_distance):
								result_from_distance_evaluation = Change.Stable
							elif (previous_distance < current_distance):
								result_from_distance_evaluation = Change.Increase
						else:
							result_from_distance_evaluation = Change.Stable
						
						if (result_from_distance_evaluation is not None):
							print("Info: distance check passed")
							#based on relative position vector and veclocity vector 
							result_from_vector_evaluation = None 
							result_from_vector_evaluation = relative_position_velocity_vectors_eval(rotation_model,reference_point_ft,neighbour_point_ft,reconstruction_time,interval,reference,cos_value_for_transform)
							#debug
							#print "Here is result_from_vector_evaluation"
							#print result_from_vector_evaluation
							
							#collect data for CSV files for tectonic motion
							#tectonic_motion_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation,result_from_vector_evaluation,None))
							
							reconstructed_temp_point_features[:] = []
							
							if (result_from_vector_evaluation is None):
								#depends on result_from_distance_evaluation
								print("Warning: result_from_vector_evaluation is None")
							elif (result_from_vector_evaluation is not None):
								reference_line_ft = None
								reference_line = None
								neighbour_line = None
								neighbour_line_ft = None 
								reference_line_ft,reference_line,neighbour_line_ft,neighbour_line = find_line_feature_represent_other_GDU(reference_point_ft,None,neighbour_point_ft,None,pre_processed_line_features)
								valid_pair_of_GDUs = False 
								if (reference_line_ft is not None and neighbour_line_ft is not None):
									if (result_from_vector_evaluation == Transform.Oblique_divergence or result_from_vector_evaluation == Transform.Oblique_convergence):
										temp_result_from_vector_evaluation = None
										featType = pygplates.FeatureType.gpml_continental_crust
										mid_point_for_ref = get_midpoint_of_line_using_distance_from_haversine(reference_line)
										temp_ref_point_ft = pygplates.Feature.create_reconstructable_feature(featType,get_midpoint_of_line_using_distance_from_haversine(reference_line),valid_time = reference_point_ft.get_valid_time(),reconstruction_plate_id = reference_line_ft.get_reconstruction_plate_id())
										mid_point_for_neighbour = get_midpoint_of_line_using_distance_from_haversine(neighbour_line)
										temp_neighbour_point_ft = pygplates.Feature.create_reconstructable_feature(featType,get_midpoint_of_line_using_distance_from_haversine(neighbour_line),valid_time = neighbour_point_ft.get_valid_time(),reconstruction_plate_id = neighbour_line_ft.get_reconstruction_plate_id())
										if (reference is not None):
											pygplates.reverse_reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstruction_time,reference)
										else:
											pygplates.reverse_reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstruction_time)
										temp_result_from_vector_evaluation = relative_position_velocity_vectors_eval(rotation_model,temp_ref_point_ft,temp_neighbour_point_ft,reconstruction_time,interval,reference,cos_value_for_transform)
										if (result_from_vector_evaluation == Transform.Oblique_divergence and (temp_result_from_vector_evaluation == Transform.Oblique_convergence or temp_result_from_vector_evaluation == Pure.Convergence)):
											result_from_vector_evaluation = temp_result_from_vector_evaluation
										elif (result_from_vector_evaluation == Transform.Oblique_convergence and (temp_result_from_vector_evaluation == Transform.Oblique_divergence or temp_result_from_vector_evaluation == Pure.Divergence)):
											result_from_vector_evaluation = temp_result_from_vector_evaluation
										#have to evaluate distance 
										if (reference is not None):
											#point_features
											pygplates.reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstructed_temp_point_features,(reconstruction_time + interval),anchor_plate_id = reference, group_with_feature = True)
										else:
											#point_features
											pygplates.reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstructed_temp_point_features,(reconstruction_time + interval),group_with_feature = True)
										
										#debug 
										#point_fts_for_motion_evaluation.append(temp_ref_point_ft)
										#point_fts_for_motion_evaluation.append(temp_neighbour_point_ft)
										
										final_reconstructed_temp_point_features = find_final_reconstructed_geometries(reconstructed_temp_point_features,pygplates.PointOnSphere)
										previous_ref_point = None 
										previous_neighbour_point = None
										for ft,point in final_reconstructed_temp_point_features:
											if (ft.get_reconstruction_plate_id() == temp_ref_point_ft.get_reconstruction_plate_id()):
												previous_ref_point = point
											elif (ft.get_reconstruction_plate_id() == temp_neighbour_point_ft.get_reconstruction_plate_id()):
												previous_neighbour_point = point
										if (previous_ref_point is None or previous_neighbour_point is None):
											print("Error in identify_plate_tectonic_boundaries")
											print("Error cannot find previous_ref_point or previous_neighbour_point 1st")
											print("value of previous_ref_point")
											print(previous_ref_point)
											print("value of previous_neighbour_point")
											print(previous_neighbour_point)
											print("value of temp_ref_point_ft")
											print(temp_ref_point_ft)
											print("value of temp_neighbour_point_ft")
											print(temp_neighbour_point_ft)
											print("final_reconstructed_temp_point_features",final_reconstructed_temp_point_features)
											print("temp_ref_point_ft.get_valid_time()",temp_ref_point_ft.get_valid_time())
											print("temp_neighbour_point_ft.get_valid_time()",temp_neighbour_point_ft.get_valid_time())
											print("current reconstruction time", reconstruction_time)
											print("reconstruction_time + interval", reconstruction_time + interval)
											exit()
										previous_distance = pygplates.GeometryOnSphere.distance(previous_ref_point,previous_neighbour_point)*pygplates.Earth.mean_radius_in_kms
										current_distance = pygplates.GeometryOnSphere.distance(mid_point_for_ref,mid_point_for_neighbour)*pygplates.Earth.mean_radius_in_kms
										#to find the mean of difference in distance
										temp_result_from_distance_evaluation = None 
										if (abs(previous_distance - current_distance) >= difference_distance_km):
											print("Info: distance check the second time ")
											#perform comparison between previous_distance and current_distance
											#based on distance evaluation
											if (previous_distance > current_distance):
												temp_result_from_distance_evaluation = Change.Decrease
											elif (previous_distance == current_distance):
												temp_result_from_distance_evaluation = Change.Stable
											elif (previous_distance < current_distance):
												temp_result_from_distance_evaluation = Change.Increase
										else:
											temp_result_from_distance_evaluation = Change.Stable
										if (temp_result_from_distance_evaluation != result_from_distance_evaluation):
											result_from_distance_evaluation = temp_result_from_distance_evaluation
										
										#clearing the lists for temporary point features
										reconstructed_temp_point_features[:] = []
										
								# #collect data for CSV files for tectonic motion
								# tectonic_motion_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation,result_from_vector_evaluation,None))
										
								previous_tectonic_motion = None 
								if (final_key in dictionary_of_tectonic_motion):
									previous_tectonic_motion = dictionary_of_tectonic_motion[final_key]
								final_result = result_from_distance_evaluation.value * result_from_vector_evaluation.value
								print("Here is value of final_result")
								print(final_result)
								print("Here is value of result_from_distance_evaluation")
								print(result_from_distance_evaluation)
								print("Here is value of result_from_vector_evaluation")
								print(result_from_vector_evaluation)
								if (final_result == 0):
									specific_transform = None 
									#steady state 
									#result_from_vector_evaluation = None
									dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
									if (final_key not in list_of_invalid_pairs_of_ft):
										#check whether the pair is valid to create plate boundary
										modified_neighbours_points_reconstructed_fts = list(zip(*(neighbours_reconstructed_point_fts)))
										neighbours_points_reconstructed_geometry = modified_neighbours_points_reconstructed_fts[1]
										modified_neighbours_polygons_reconstructed_fts = list(zip(*(neighbours_reconstructed_polygon_fts)))
										neighbours_polygons_reconstructed_geometry = modified_neighbours_polygons_reconstructed_fts[1]
										if (len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0):
											print("Error in identify_plate_tectonic_boundaries")
											print("Error len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0")
											print("Here is len(neighbours_polygons_reconstructed_geometry)")
											print(len(neighbours_polygons_reconstructed_geometry))
											print("Here is len(neighbours_points_reconstructed_geometry)")
											print(len(neighbours_points_reconstructed_geometry))
											print("Here is modified_neighbours_points_reconstructed_fts")
											print(modified_neighbours_points_reconstructed_fts)
											print("Here is modified_neighbours_polygons_reconstructed_fts")
											print(modified_neighbours_polygons_reconstructed_fts)
											exit()
										valid_pair_of_GDUs = False 
										if (reference_line_ft is not None and neighbour_line_ft is not None):
											#valid_pair_of_GDUs = is_valid_feature_test(reference_ft_id,neighbour_ft_id, reference_point,neighbour_point,get_midpoint_of_line_using_distance_from_haversine(reference_line), get_midpoint_of_line_using_distance_from_haversine(neighbour_line), neighbours_reconstructed_point_fts, neighbours_reconstructed_polygon_fts,reference_line,neighbour_line,1500)
											valid_pair_of_GDUs = is_valid_feature_test_for_lines(get_midpoint_of_line_using_distance_from_haversine(reference_line), get_midpoint_of_line_using_distance_from_haversine(neighbour_line),neighbours_reconstructed_polygon_fts,reference_line,neighbour_line,threshold_distance_in_km)
											ref_midpoint = get_midpoint_of_line_using_distance_from_haversine(reference_line)
											neighbour_midpoint = get_midpoint_of_line_using_distance_from_haversine(neighbour_line)
											valid_pair_of_GDUs = is_valid_feature_test_with_azimuth_direction_only(reference_ft_id,neighbour_ft_id, ref_midpoint, neighbour_midpoint, neighbours_reconstructed_point_fts)
											if (valid_pair_of_GDUs == True):
												valid_pair_of_GDUs = is_valid_feature_test_for_lines(get_midpoint_of_line_using_distance_from_haversine(reference_line), get_midpoint_of_line_using_distance_from_haversine(neighbour_line),neighbours_reconstructed_polygon_fts,reference_line,neighbour_line,threshold_distance_in_km)
											
											#temp_distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(ref_midpoint,neighbour_midpoint)
											#if (temp_distance_in_km > 500.00):
												
											#valid_pair_of_GDUs = is_valid_feature_test_with_middle_geometry(neighbours_reconstructed_polygon_fts,reference_line,neighbour_line)
										if (valid_pair_of_GDUs == True):
											#check whether dictionary_of_tectonic_boundaries have features - the new process since we don't margins for stable zone but only any active tectonic zone 
											if ((final_key in dictionary_of_tectonic_boundaries) == True):
												tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
												#if (previous_tectonic_motion[1] == Pure.Divergence or previous_tectonic_motion[1] == Transform.Oblique_divergence):
												if (tectonic_motion == 'Divergence'):
													tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
													#update end_age for boundary_1 and boundary_2
													current_appearance,_ = boundary_1.get_valid_time()
													boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													#write these two boundaries to a final list of features
													list_of_tectonic_boundaries.append(boundary_1)
													list_of_tectonic_boundaries.append(boundary_2)
													list_of_tectonic_boundaries.append(boundary_3)
													list_of_tectonic_boundaries.append(boundary_4)
													list_of_tectonic_boundaries.append(boundary_5)
													#remove the key all of dictionary_of_tectonic_boundaries
													del dictionary_of_tectonic_boundaries[final_key]
												else:
													tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
													if (tectonic_motion == 'Convergence' or tectonic_motion == 'Transform'):
														#update end_age for boundary_1 and boundary_2
														current_appearance,_ = boundary_1.get_valid_time()
														boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														#write these two boundaries to a final list of features
														list_of_tectonic_boundaries.append(boundary_1)
														list_of_tectonic_boundaries.append(boundary_2)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
											
										else:
											print("Info: Invalid pair of GDUs")
											print(reference_point_ft.get_reconstruction_plate_id())
											print(neighbour_point_ft.get_reconstruction_plate_id())
											
											#collect data for CSV files for invalid pair of GDUs
											#invalid_pairs_of_GDUs_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id()))
											
											list_of_invalid_pairs_of_ft.append(final_key)
											#check whether dictionary_of_tectonic_boundaries have features 
											if ((final_key in dictionary_of_tectonic_boundaries) == True):
												tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
												#if (previous_tectonic_motion[1] == Pure.Divergence or previous_tectonic_motion[1] == Transform.Oblique_divergence):
												if (tectonic_motion == 'Divergence'):
													tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
													#update end_age for boundary_1 and boundary_2
													current_appearance,_ = boundary_1.get_valid_time()
													boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													#write these two boundaries to a final list of features
													list_of_tectonic_boundaries.append(boundary_1)
													list_of_tectonic_boundaries.append(boundary_2)
													list_of_tectonic_boundaries.append(boundary_3)
													list_of_tectonic_boundaries.append(boundary_4)
													list_of_tectonic_boundaries.append(boundary_5)
													#remove the key all of dictionary_of_tectonic_boundaries
													del dictionary_of_tectonic_boundaries[final_key]
												else:
													tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
													#update end_age for boundary_1 and boundary_2
													current_appearance,_ = boundary_1.get_valid_time()
													boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
													#write these two boundaries to a final list of features
													list_of_tectonic_boundaries.append(boundary_1)
													list_of_tectonic_boundaries.append(boundary_2)
													#remove the key all of dictionary_of_tectonic_boundaries
													del dictionary_of_tectonic_boundaries[final_key]
								elif (final_result > 0):
									#either divergence or convergence: there is an agreement between the distance and vector evaluation
									if (result_from_distance_evaluation == Change.Increase and (result_from_vector_evaluation == Pure.Divergence or result_from_vector_evaluation == Transform.Oblique_divergence)):
										#check whether the pair of boundaries are valid
										if (key not in list_of_invalid_pairs_of_ft):
											#check whether the pair is valid to create plate boundary
											modified_neighbours_points_reconstructed_fts = list(zip(*(neighbours_reconstructed_point_fts)))
											neighbours_points_reconstructed_geometry = modified_neighbours_points_reconstructed_fts[1]
											modified_neighbours_polygons_reconstructed_fts = list(zip(*(neighbours_reconstructed_polygon_fts)))
											neighbours_polygons_reconstructed_geometry = modified_neighbours_polygons_reconstructed_fts[1]
											if (len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0):
												print("Error in identify_plate_tectonic_boundaries")
												print("Error len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0")
												print("Here is len(neighbours_polygons_reconstructed_geometry)")
												print(len(neighbours_polygons_reconstructed_geometry))
												print("Here is len(neighbours_points_reconstructed_geometry)")
												print(len(neighbours_points_reconstructed_geometry))
												print("Here is modified_neighbours_points_reconstructed_fts")
												print(modified_neighbours_points_reconstructed_fts)
												print("Here is modified_neighbours_polygons_reconstructed_fts")
												print(modified_neighbours_polygons_reconstructed_fts)
												exit()
											
											valid_pair_of_GDUs = False 
											if (reference_line_ft is not None and neighbour_line_ft is not None):

												ref_midpoint = get_midpoint_of_line_using_distance_from_haversine(reference_line)
												neighbour_midpoint = get_midpoint_of_line_using_distance_from_haversine(neighbour_line)
												valid_pair_of_GDUs = is_valid_feature_test_with_azimuth_direction_only(reference_ft_id,neighbour_ft_id, ref_midpoint, neighbour_midpoint, neighbours_reconstructed_point_fts)
												if (valid_pair_of_GDUs == True):
													valid_pair_of_GDUs = is_valid_feature_test_for_lines(get_midpoint_of_line_using_distance_from_haversine(reference_line), get_midpoint_of_line_using_distance_from_haversine(neighbour_line),neighbours_reconstructed_polygon_fts,reference_line,neighbour_line,threshold_distance_in_km)
											if (valid_pair_of_GDUs == False):
												#collect data for CSV files for invalid pair of GDUs
												#invalid_pairs_of_GDUs_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id()))
												
												print("Info: Invalid pair of GDUs")
												print(reference_point_ft.get_reconstruction_plate_id())
												print(neighbour_point_ft.get_reconstruction_plate_id())
											
												list_of_invalid_pairs_of_ft.append(final_key)
												#check whether dictionary_of_tectonic_boundaries have features 
												if ((final_key in dictionary_of_tectonic_boundaries) == True): #there needs to be a previous_tectonic_motion for this pair
													if (previous_tectonic_motion[1] == Pure.Divergence or previous_tectonic_motion[1] == Transform.Oblique_divergence):
														print(dictionary_of_tectonic_boundaries[final_key])
														print(dictionary_of_tectonic_motion[final_key])
														tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
														if (tectonic_motion == 'Divergence'):
															tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
															#update end_age for boundary_1 and boundary_2
															current_appearance,_ = boundary_1.get_valid_time()
															boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															#write these two boundaries to a final list of features
															list_of_tectonic_boundaries.append(boundary_1)
															list_of_tectonic_boundaries.append(boundary_2)
															list_of_tectonic_boundaries.append(boundary_3)
															list_of_tectonic_boundaries.append(boundary_4)
															list_of_tectonic_boundaries.append(boundary_5)
														else:
															tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
															#update end_age for boundary_1 and boundary_2
															current_appearance,_ = boundary_1.get_valid_time()
															boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															#write these two boundaries to a final list of features
															list_of_tectonic_boundaries.append(boundary_1)
															list_of_tectonic_boundaries.append(boundary_2)
														#update the motion in the dictionary
														dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
													elif(previous_tectonic_motion[1] == Pure.Transform or previous_tectonic_motion[1] == Transform.Strike_slip_left or previous_tectonic_motion[1] == Transform.Strike_slip_right):
														print("value of previous_tectonic_motion[1]")
														print(previous_tectonic_motion[1])
														tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
														print("value of tectonic_motion")
														print(tectonic_motion)
														if (tectonic_motion == 'Divergence'):
															tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
															#update end_age for boundary_1 and boundary_2
															current_appearance,_ = boundary_1.get_valid_time()
															boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															#write these two boundaries to a final list of features
															list_of_tectonic_boundaries.append(boundary_1)
															list_of_tectonic_boundaries.append(boundary_2)
															list_of_tectonic_boundaries.append(boundary_3)
															list_of_tectonic_boundaries.append(boundary_4)
															list_of_tectonic_boundaries.append(boundary_5)
															#update the motion in the dictionary
															dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
														else:
															tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
															#update end_age for boundary_1 and boundary_2
															current_appearance,_ = boundary_1.get_valid_time()
															boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															#write these two boundaries to a final list of features
															list_of_tectonic_boundaries.append(boundary_1)
															list_of_tectonic_boundaries.append(boundary_2)
															#update the motion in the dictionary
															dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
													elif (previous_tectonic_motion[1] == Transform.Oblique_convergence):
														print("value of previous_tectonic_motion[1]")
														print(previous_tectonic_motion[1])
														tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
														print("value of tectonic_motion")
														print(tectonic_motion)
														if (tectonic_motion == 'Convergence' or tectonic_motion == 'Transform'):
															tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
															#update end_age for boundary_1 and boundary_2
															current_appearance,_ = boundary_1.get_valid_time()
															boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															#write these two boundaries to a final list of features
															list_of_tectonic_boundaries.append(boundary_1)
															list_of_tectonic_boundaries.append(boundary_2)
															#update the motion in the dictionary
															dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
														elif (tectonic_motion == 'Divergence'):
															tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
															#update end_age for boundary_1 and boundary_2
															current_appearance,_ = boundary_1.get_valid_time()
															boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															#write these two boundaries to a final list of features
															list_of_tectonic_boundaries.append(boundary_1)
															list_of_tectonic_boundaries.append(boundary_2)
															list_of_tectonic_boundaries.append(boundary_3)
															list_of_tectonic_boundaries.append(boundary_4)
															list_of_tectonic_boundaries.append(boundary_5)
															#update the motion in the dictionary
															dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
														
														if (final_key in dictionary_of_suspected_motion):
															suspected_motion,time = dictionary_of_suspected_motion[final_key]
															if (suspected_motion == Transform.Oblique_divergence):
																if (abs(reconstruction_time - time) >= (interval*2.00)):
																	del dictionary_of_suspected_motion[final_key]
														else:
															dictionary_of_suspected_motion[final_key] = (Transform.Oblique_divergence,reconstruction_time)
														
														#suspecting tectonic motion 
														#suspecting_tectonic_motion.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation,result_from_vector_evaluation))
														conn = None 
														try:
															#read database config
															params = config()
															#connect to the PostgreSQL
															conn = psycopg2.connect(**params)
															#create a new cursor
															cur = conn.cursor()
															sql = """ INSERT INTO suspecting_tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
															cur.execute(sql,((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation.name,result_from_vector_evaluation.name)))
															#commit the changes to the database
															conn.commit()
															#close communication with the database
															cur.close()
														except (Exception, psycopg2.DatabaseError) as error:
															print(error)
														finally:
															if conn is not None:
																conn.close()
											else:
												if (previous_tectonic_motion is not None):
													if (previous_tectonic_motion[1] == Pure.Transform or previous_tectonic_motion[1] == Transform.Strike_slip_left or previous_tectonic_motion[1] == Transform.Strike_slip_right or previous_tectonic_motion[1] == Pure.Divergence or previous_tectonic_motion[1] == Transform.Oblique_divergence or previous_tectonic_motion[1] is None):
														if (previous_tectonic_motion[1] == Pure.Transform or previous_tectonic_motion[1] == Transform.Strike_slip_left or previous_tectonic_motion[1] == Transform.Strike_slip_right or previous_tectonic_motion[1] is None):
															#update end_time for transform faults or stable boundaries
															if ((final_key in dictionary_of_tectonic_boundaries) == True):
																print('value of previous_tectonic_motion')
																print(previous_tectonic_motion)
																print(previous_tectonic_motion[1])
																tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
																print('value of tectonic_motion')
																print(tectonic_motion) 
																if (tectonic_motion == 'Stable' or tectonic_motion == 'Transform'):
																	boundary_1 = dictionary_of_tectonic_boundaries[final_key][1]
																	boundary_2 = dictionary_of_tectonic_boundaries[final_key][2]
																	#update end_age for boundary_1 and boundary_2
																	current_appearance,_ = boundary_1.get_valid_time()
																	boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																	boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																	#write these two boundaries to a final list of features
																	list_of_tectonic_boundaries.append(boundary_1)
																	list_of_tectonic_boundaries.append(boundary_2)
															#need to create new features for divergent zone
															#create new Divergence feature
															#middle_ft,boundary_1,boundary_2,transform_fault = find_rift_segment_and_transform_faults(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, interval, reference)
															middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right = find_rift_segment_and_transform_faults_v1(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, interval, reference)
															if (boundary_1 is None and boundary_2 is None):
																#this is the artifact or it is actually transform but was misidentified
																specific_transform = left_or_right_transform(reference_point,neighbour_point)
																#update the motion in the dictionary
																dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,specific_transform)
																if (specific_transform == Transform.Strike_slip_left):
																	type_of_movement = 'Left'
																elif (specific_transform == Transform.Strike_slip_right):
																	type_of_movement = 'Right'
																transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, type_of_movement, reconstruction_time, reference)
																#store transform_faults to dictionary_of_tectonic_boundaries
																dictionary_of_tectonic_boundaries[final_key] = ('Transform',transform_fault_1,transform_fault_2)
															else:
																dictionary_of_tectonic_boundaries[final_key] = ('Divergence',middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right)
																#update the motion in the dictionary
																dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
															
															
													elif (previous_tectonic_motion[1] == Transform.Oblique_convergence): #Very suspecting case
														if (final_key in dictionary_of_suspected_motion):
															suspected_motion,time = dictionary_of_suspected_motion[final_key]
															if (suspected_motion == Transform.Oblique_divergence):
																if (abs(reconstruction_time - time) >= (interval*2.00)):
																	del dictionary_of_suspected_motion[final_key]
																	#update end_time for transform faults or stable boundaries
																	if ((final_key in dictionary_of_tectonic_boundaries) == True):
																		print('value of previous_tectonic_motion')
																		print(previous_tectonic_motion)
																		print(previous_tectonic_motion[1])
																		tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
																		print('value of tectonic_motion')
																		print(tectonic_motion) 
																		if (tectonic_motion == 'Convergence'):
																			boundary_1 = dictionary_of_tectonic_boundaries[final_key][1]
																			boundary_2 = dictionary_of_tectonic_boundaries[final_key][2]
																			#update end_age for boundary_1 and boundary_2
																			current_appearance,_ = boundary_1.get_valid_time()
																			boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																			boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																			#write these two boundaries to a final list of features
																			list_of_tectonic_boundaries.append(boundary_1)
																			list_of_tectonic_boundaries.append(boundary_2)
																	#need to create new features for divergent zone
																	#create new Divergence feature
																	#middle_ft,boundary_1,boundary_2,transform_fault = find_rift_segment_and_transform_faults(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, interval, reference)
																	middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right = find_rift_segment_and_transform_faults_v1(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, interval, reference)
																	if (boundary_1 is None and boundary_2 is None):
																		#this is the artifact or it is actually transform but was misidentified
																		specific_transform = left_or_right_transform(reference_point,neighbour_point)
																		#update the motion in the dictionary
																		dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,specific_transform)
																		if (specific_transform == Transform.Strike_slip_left):
																			type_of_movement = 'Left'
																		elif (specific_transform == Transform.Strike_slip_right):
																			type_of_movement = 'Right'
																		transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, type_of_movement, reconstruction_time, reference)
																		#store transform_faults to dictionary_of_tectonic_boundaries
																		dictionary_of_tectonic_boundaries[final_key] = ('Transform',transform_fault_1,transform_fault_2)
																	else:
																		dictionary_of_tectonic_boundaries[final_key] = ('Divergence',middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right)
																		#update the motion in the dictionary
																		dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
														else:
															dictionary_of_suspected_motion[final_key] = (Transform.Oblique_divergence,reconstruction_time)
														#suspecting_tectonic_motion.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation,result_from_vector_evaluation))
														conn = None 
														try:
															#read database config
															params = config()
															#connect to the PostgreSQL
															conn = psycopg2.connect(**params)
															#create a new cursor
															cur = conn.cursor()
															sql = """ INSERT INTO suspecting_tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
															cur.execute(sql,((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation.name,result_from_vector_evaluation.name)))
															#commit the changes to the database
															conn.commit()
															#close communication with the database
															cur.close()
														except (Exception, psycopg2.DatabaseError) as error:
															print(error)
														finally:
															if conn is not None:
																conn.close()
														
												else:
													#create new Divergence feature
													#middle_ft,boundary_1,boundary_2,transform_fault = find_rift_segment_and_transform_faults(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, interval, reference)
													middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right = find_rift_segment_and_transform_faults_v1(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, interval, reference)
													if (boundary_1 is None and boundary_2 is None):
														#this is the artifact or it is actually transform but was misidentified
														specific_transform = left_or_right_transform(reference_point,neighbour_point)
														#update the motion in the dictionary
														dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,specific_transform)
														if (specific_transform == Transform.Strike_slip_left):
															type_of_movement = 'Left'
														elif (specific_transform == Transform.Strike_slip_right):
															type_of_movement = 'Right'
														transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, type_of_movement, reconstruction_time, reference)
														#store transform_faults to dictionary_of_tectonic_boundaries
														dictionary_of_tectonic_boundaries[final_key] = ('Transform',transform_fault_1,transform_fault_2)
													else:
														dictionary_of_tectonic_boundaries[final_key] = ('Divergence',middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right)
														#update the motion in the dictionary
														dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
														
													
													
									elif (result_from_distance_evaluation == Change.Decrease and (result_from_vector_evaluation == Pure.Convergence or result_from_vector_evaluation == Transform.Oblique_convergence)):
										#check whether the pair of boundaries are valid
										if (key not in list_of_invalid_pairs_of_ft):
											#check whether the pair is valid to create plate boundary
											modified_neighbours_points_reconstructed_fts = list(zip(*(neighbours_reconstructed_point_fts)))
											neighbours_points_reconstructed_geometry = modified_neighbours_points_reconstructed_fts[1]
											modified_neighbours_polygons_reconstructed_fts = list(zip(*(neighbours_reconstructed_polygon_fts)))
											neighbours_polygons_reconstructed_geometry = modified_neighbours_polygons_reconstructed_fts[1]
											if (len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0):
												print("Error in identify_plate_tectonic_boundaries")
												print("Error len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0")
												print("Here is len(neighbours_polygons_reconstructed_geometry)")
												print(len(neighbours_polygons_reconstructed_geometry))
												print("Here is len(neighbours_points_reconstructed_geometry)")
												print(len(neighbours_points_reconstructed_geometry))
												print("Here is modified_neighbours_points_reconstructed_fts")
												print(modified_neighbours_points_reconstructed_fts)
												print("Here is modified_neighbours_polygons_reconstructed_fts")
												print(modified_neighbours_polygons_reconstructed_fts)
												exit()
										
											valid_pair_of_GDUs = False 
											if (reference_line_ft is not None and neighbour_line_ft is not None):
												
												ref_midpoint = get_midpoint_of_line_using_distance_from_haversine(reference_line)
												neighbour_midpoint = get_midpoint_of_line_using_distance_from_haversine(neighbour_line)
												valid_pair_of_GDUs = is_valid_feature_test_with_azimuth_direction_only(reference_ft_id,neighbour_ft_id, ref_midpoint, neighbour_midpoint, neighbours_reconstructed_point_fts)
												if (valid_pair_of_GDUs == True):
													valid_pair_of_GDUs = is_valid_feature_test_for_lines(get_midpoint_of_line_using_distance_from_haversine(reference_line), get_midpoint_of_line_using_distance_from_haversine(neighbour_line),neighbours_reconstructed_polygon_fts,reference_line,neighbour_line,threshold_distance_in_km)
											if (valid_pair_of_GDUs == False):
												#collect data for CSV files for invalid pair of GDUs
												#invalid_pairs_of_GDUs_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id()))
												
												print("Info: Invalid pair of GDUs")
												print(reference_point_ft.get_reconstruction_plate_id())
												print(neighbour_point_ft.get_reconstruction_plate_id())
												
												list_of_invalid_pairs_of_ft.append(final_key)
												#check whether dictionary_of_tectonic_boundaries have features 
												if ((final_key in dictionary_of_tectonic_boundaries) == True):
													tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
													if (tectonic_motion == 'Convergence' or tectonic_motion == 'Transform'):
														tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
														#update end_age for boundary_1 and boundary_2
														current_appearance,_ = boundary_1.get_valid_time()
														boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														#write these two boundaries to a final list of features
														list_of_tectonic_boundaries.append(boundary_1)
														list_of_tectonic_boundaries.append(boundary_2)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
														#update the motion in the dictionary
														dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
													elif (tectonic_motion == 'Divergence'):
														tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
														#update end_age for boundary_1 and boundary_2 and boundary_3
														current_appearance,_ = boundary_1.get_valid_time()
														boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														#write these three boundaries to a final list of features
														list_of_tectonic_boundaries.append(boundary_1)
														list_of_tectonic_boundaries.append(boundary_2)
														list_of_tectonic_boundaries.append(boundary_3)
														list_of_tectonic_boundaries.append(boundary_4)
														list_of_tectonic_boundaries.append(boundary_5)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
														#update the motion in the dictionary
														dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)	
													if (previous_tectonic_motion[1] == Transform.Oblique_divergence):

														
														if (final_key in dictionary_of_suspected_motion):
															suspected_motion,time = dictionary_of_suspected_motion[final_key]
															if (suspected_motion == Transform.Oblique_convergence):
																if (abs(reconstruction_time - time) >= (interval*2.00)):
																	del dictionary_of_suspected_motion[final_key]
														else:
															dictionary_of_suspected_motion[final_key] = (Transform.Oblique_convergence,reconstruction_time)
														#suspecting tectonic motion 
														#suspecting_tectonic_motion.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation,result_from_vector_evaluation))
														conn = None 
														try:
															#read database config
															params = config()
															#connect to the PostgreSQL
															conn = psycopg2.connect(**params)
															#create a new cursor
															cur = conn.cursor()
															sql = """ INSERT INTO suspecting_tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
															cur.execute(sql,((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation.name,result_from_vector_evaluation.name)))
															#commit the changes to the database
															conn.commit()
															#close communication with the database
															cur.close()
														except (Exception, psycopg2.DatabaseError) as error:
															print(error)
														finally:
															if conn is not None:
																conn.close()
											else:
												if (previous_tectonic_motion is not None):
													if (previous_tectonic_motion[1] == Pure.Transform or previous_tectonic_motion[1] == Transform.Strike_slip_left or previous_tectonic_motion[1] == Transform.Strike_slip_right or previous_tectonic_motion[1] == Pure.Convergence or previous_tectonic_motion[1] == Transform.Oblique_convergence or previous_tectonic_motion[1] is None):
														if (previous_tectonic_motion[1] == Pure.Transform or previous_tectonic_motion[1] == Transform.Strike_slip_left or previous_tectonic_motion[1] == Transform.Strike_slip_right or previous_tectonic_motion[1] is None):
															#update end_time for transform faults or stable boundaries
															if ((final_key in dictionary_of_tectonic_boundaries) == True):
																tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
																if (tectonic_motion == 'Stable' or tectonic_motion == 'Transform'):
																	tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
																	#update end_age for boundary_1 and boundary_2
																	current_appearance,_ = boundary_1.get_valid_time()
																	boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																	boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																	#write these two boundaries to a final list of features
																	list_of_tectonic_boundaries.append(boundary_1)
																	list_of_tectonic_boundaries.append(boundary_2)
															#create new Convergence feature
															boundary_1,boundary_2 = None, None 
															if (possible_line_fts_for_subduction_zone_deposits is not None):
																boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, possible_line_fts_for_subduction_zone_deposits, rotation_model, reconstruction_time, reference)
															if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_igneous is not None):
																boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, possible_line_fts_for_subduction_zone_igneous, rotation_model, reconstruction_time, reference)
															if (boundary_1 is None and boundary_2 is None):
																boundary_1,boundary_2 = create_feature_for_unknown_margin_convergent_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, reference)
															# boundary_1,boundary_2 = create_feature_for_convergent_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, final_reconstructed_buffer_features, rotation_model, reconstruction_time, reference)
															dictionary_of_tectonic_boundaries[final_key] = ('Convergence',boundary_1,boundary_2)
																
																
														#update the motion in the dictionary
														dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
													elif (previous_tectonic_motion[1] == Transform.Oblique_divergence): #very suspecting case
														if (final_key in dictionary_of_suspected_motion):
															suspected_motion,time = dictionary_of_suspected_motion[final_key]
															if (suspected_motion == Transform.Oblique_convergence):
																if (abs(reconstruction_time - time) >= (interval*2.00)):
																	del dictionary_of_suspected_motion[final_key]
																	#update end_time for transform faults or stable boundaries
																	if ((final_key in dictionary_of_tectonic_boundaries) == True):
																		print('value of previous_tectonic_motion')
																		print(previous_tectonic_motion)
																		print(previous_tectonic_motion[1])
																		tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
																		print('value of tectonic_motion')
																		print(tectonic_motion) 
																		if (tectonic_motion == 'Divergence'):
																			boundary_1 = dictionary_of_tectonic_boundaries[final_key][1]
																			boundary_2 = dictionary_of_tectonic_boundaries[final_key][2]
																			boundary_3 = dictionary_of_tectonic_boundaries[final_key][3]
																			boundary_4 = dictionary_of_tectonic_boundaries[final_key][4]
																			boundary_5 = dictionary_of_tectonic_boundaries[final_key][5]
																			#update end_age for boundary_1 and boundary_2
																			current_appearance,_ = boundary_1.get_valid_time()
																			boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																			boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																			boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																			boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																			boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																			#write these two boundaries to a final list of features
																			list_of_tectonic_boundaries.append(boundary_1)
																			list_of_tectonic_boundaries.append(boundary_2)
																			list_of_tectonic_boundaries.append(boundary_3)
																			list_of_tectonic_boundaries.append(boundary_4)
																			list_of_tectonic_boundaries.append(boundary_5)
																	#need to create new features for divergent zone
																	#create new Convergence feature
																	boundary_1,boundary_2 = None, None 
																	if (possible_line_fts_for_subduction_zone_deposits is not None):
																		boundary_1,boundary_2 = boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, possible_line_fts_for_subduction_zone_deposits, rotation_model, reconstruction_time, reference)
																	if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_igneous is not None):
																		boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, possible_line_fts_for_subduction_zone_igneous, rotation_model, reconstruction_time, reference)
																	if (boundary_1 is None and boundary_2 is None):
																		boundary_1,boundary_2 = create_feature_for_unknown_margin_convergent_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, reference)
																	#boundary_1,boundary_2 = create_feature_for_convergent_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, final_reconstructed_buffer_features, rotation_model, reconstruction_time, reference)
																	dictionary_of_tectonic_boundaries[final_key] = ('Convergence',boundary_1,boundary_2)
																	
																	#update the motion in the dictionary
																	dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
														else:
															dictionary_of_suspected_motion[final_key] = (Transform.Oblique_convergence,reconstruction_time)
														
														#suspecting_tectonic_motion.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation,result_from_vector_evaluation))
														conn = None 
														try:
															#read database config
															params = config()
															#connect to the PostgreSQL
															conn = psycopg2.connect(**params)
															#create a new cursor
															cur = conn.cursor()
															sql = """ INSERT INTO suspecting_tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
															cur.execute(sql,((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation.name,result_from_vector_evaluation.name)))
															#commit the changes to the database
															conn.commit()
															#close communication with the database
															cur.close()
														except (Exception, psycopg2.DatabaseError) as error:
															print(error)
														finally:
															if conn is not None:
																conn.close()
												else:#no record of previous tectonic_motion
													#create new Convergence feature
													boundary_1,boundary_2 = None,None
													if (possible_line_fts_for_subduction_zone_deposits is not None):
														boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, possible_line_fts_for_subduction_zone_deposits, rotation_model, reconstruction_time, reference)
													if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_igneous is not None):
														boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, possible_line_fts_for_subduction_zone_igneous, rotation_model, reconstruction_time, reference)
													if (boundary_1 is None and boundary_2 is None):
														boundary_1,boundary_2 = create_feature_for_unknown_margin_convergent_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, reconstruction_time, reference)
													#boundary_1,boundary_2 = create_feature_for_convergent_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, final_reconstructed_buffer_features, rotation_model, reconstruction_time, reference)
													dictionary_of_tectonic_boundaries[final_key] = ('Convergence',boundary_1,boundary_2)
													
													#update the motion in the dictionary
													dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
									elif (result_from_distance_evaluation == Change.Increase and result_from_vector_evaluation == Pure.Transform):
										specific_transform = None 
										specific_transform = left_or_right_transform(reference_point,neighbour_point)
										if (previous_tectonic_motion is None):
											dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,specific_transform)
										else:
											#check the vector
											previous_relative_vector_result = previous_tectonic_motion[1]
											
											if (previous_relative_vector_result == Pure.Convergence or previous_relative_vector_result == Transform.Oblique_convergence):
												dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,specific_transform)
										if (final_key not in list_of_invalid_pairs_of_ft):
											#check whether the pair is valid to create plate boundary
											modified_neighbours_points_reconstructed_fts = list(zip(*(neighbours_reconstructed_point_fts)))
											neighbours_points_reconstructed_geometry = modified_neighbours_points_reconstructed_fts[1]
											modified_neighbours_polygons_reconstructed_fts = list(zip(*(neighbours_reconstructed_polygon_fts)))
											neighbours_polygons_reconstructed_geometry = modified_neighbours_polygons_reconstructed_fts[1]
											if (len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0):
												print("Error in identify_plate_tectonic_boundaries")
												print("Error len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0")
												print("Here is len(neighbours_polygons_reconstructed_geometry)")
												print(len(neighbours_polygons_reconstructed_geometry))
												print("Here is len(neighbours_points_reconstructed_geometry)")
												print(len(neighbours_points_reconstructed_geometry))
												print("Here is modified_neighbours_points_reconstructed_fts")
												print(modified_neighbours_points_reconstructed_fts)
												print("Here is modified_neighbours_polygons_reconstructed_fts")
												print(modified_neighbours_polygons_reconstructed_fts)
												exit()
											
											valid_pair_of_GDUs = False 
											if (reference_line_ft is not None and neighbour_line_ft is not None):
												
												ref_midpoint = get_midpoint_of_line_using_distance_from_haversine(reference_line)
												neighbour_midpoint = get_midpoint_of_line_using_distance_from_haversine(neighbour_line)
												valid_pair_of_GDUs = is_valid_feature_test_with_azimuth_direction_only(reference_ft_id,neighbour_ft_id, ref_midpoint, neighbour_midpoint, neighbours_reconstructed_point_fts)
												if (valid_pair_of_GDUs == True):
													valid_pair_of_GDUs = is_valid_feature_test_for_lines(get_midpoint_of_line_using_distance_from_haversine(reference_line), get_midpoint_of_line_using_distance_from_haversine(neighbour_line),neighbours_reconstructed_polygon_fts,reference_line,neighbour_line,threshold_distance_in_km)
											if (valid_pair_of_GDUs == True):
												#check whether dictionary_of_tectonic_boundaries have features 
												if ((final_key in dictionary_of_tectonic_boundaries) == False and previous_tectonic_motion is None):
													#create transform faults 
													if (specific_transform == Transform.Strike_slip_left):
														type_of_movement = 'Left'
													elif (specific_transform == Transform.Strike_slip_right):
														type_of_movement = 'Right'
													transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, type_of_movement, reconstruction_time, reference)
													#store transform_faults to dictionary_of_tectonic_boundaries
													dictionary_of_tectonic_boundaries[final_key] = ('Transform',transform_fault_1,transform_fault_2)
													
												elif ((final_key in dictionary_of_tectonic_boundaries) == True):
													need_new_fts = False
													if (previous_tectonic_motion[1] != Pure.Divergence and previous_tectonic_motion[1] != Transform.Oblique_divergence):
														tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
														if (tectonic_motion != 'Transform'):
															#update end_age for boundary_1 and boundary_2
															boundary_1 = dictionary_of_tectonic_boundaries[final_key][1]
															boundary_2 = dictionary_of_tectonic_boundaries[final_key][2]
															current_appearance,_ = boundary_1.get_valid_time()
															boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
															#write these two boundaries to a final list of features
															list_of_tectonic_boundaries.append(boundary_1)
															list_of_tectonic_boundaries.append(boundary_2)
															#setup variable
															need_new_fts = True
													if (need_new_fts == True):
														#create new transform_faults 
														if (specific_transform == Transform.Strike_slip_left):
															type_of_movement = 'Left'
														elif (specific_transform == Transform.Strike_slip_right):
															type_of_movement = 'Right'
														transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, type_of_movement, reconstruction_time, reference)
														#store transform_faults to dictionary_of_tectonic_boundaries
														dictionary_of_tectonic_boundaries[final_key] = ('Transform',transform_fault_1,transform_fault_2)
														
											else:
												#collect data for CSV files for invalid pair of GDUs
												#invalid_pairs_of_GDUs_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id()))
												
												print("Info: Invalid pair of GDUs")
												print(reference_point_ft.get_reconstruction_plate_id())
												print(neighbour_point_ft.get_reconstruction_plate_id())
												
												list_of_invalid_pairs_of_ft.append(final_key)
												#check whether dictionary_of_tectonic_boundaries have features 
												if ((final_key in dictionary_of_tectonic_boundaries) == True):
													tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
													#if (previous_tectonic_motion[1] == Pure.Divergence or previous_tectonic_motion[1] == Transform.Oblique_divergence):
													if (tectonic_motion == 'Divergence'):
														tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
														#update end_age for boundary_1 and boundary_2
														current_appearance,_ = boundary_1.get_valid_time()
														boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														#write these two boundaries to a final list of features
														list_of_tectonic_boundaries.append(boundary_1)
														list_of_tectonic_boundaries.append(boundary_2)
														list_of_tectonic_boundaries.append(boundary_3)
														list_of_tectonic_boundaries.append(boundary_4)
														list_of_tectonic_boundaries.append(boundary_5)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
													else:
														tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
														#update end_age for boundary_1 and boundary_2
														current_appearance,_ = boundary_1.get_valid_time()
														boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														#write these two boundaries to a final list of features
														list_of_tectonic_boundaries.append(boundary_1)
														list_of_tectonic_boundaries.append(boundary_2)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
								elif (final_result < 0):
									#disagreement between the distance and vector evaluation
									if (result_from_distance_evaluation == Change.Decrease and result_from_vector_evaluation == Pure.Transform):
										specific_transform = left_or_right_transform(reference_point,neighbour_point)
										if (previous_tectonic_motion is None):
											dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,result_from_vector_evaluation)
										else:
											#check the vector
											previous_relative_vector_result = previous_tectonic_motion[1]
											if (previous_relative_vector_result == Pure.Divergence or previous_relative_vector_result == Transform.Oblique_divergence):
												dictionary_of_tectonic_motion[final_key] = (result_from_distance_evaluation,specific_transform)
										if (final_key not in list_of_invalid_pairs_of_ft):
											#check whether the pair is valid to create plate boundary
											modified_neighbours_points_reconstructed_fts = list(zip(*(neighbours_reconstructed_point_fts)))
											neighbours_points_reconstructed_geometry = modified_neighbours_points_reconstructed_fts[1]
											modified_neighbours_polygons_reconstructed_fts = list(zip(*(neighbours_reconstructed_polygon_fts)))
											neighbours_polygons_reconstructed_geometry = modified_neighbours_polygons_reconstructed_fts[1]
											if (len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0):
												print("Error in identify_plate_tectonic_boundaries")
												print("Error len(neighbours_polygons_reconstructed_geometry) == 0 or len(neighbours_points_reconstructed_geometry) == 0")
												print("Here is len(neighbours_polygons_reconstructed_geometry)")
												print(len(neighbours_polygons_reconstructed_geometry))
												print("Here is len(neighbours_points_reconstructed_geometry)")
												print(len(neighbours_points_reconstructed_geometry))
												print("Here is modified_neighbours_points_reconstructed_fts")
												print(modified_neighbours_points_reconstructed_fts)
												print("Here is modified_neighbours_polygons_reconstructed_fts")
												print(modified_neighbours_polygons_reconstructed_fts)
												exit()
											
											valid_pair_of_GDUs = False 
											if (reference_line_ft is not None and neighbour_line_ft is not None):
												
												ref_midpoint = get_midpoint_of_line_using_distance_from_haversine(reference_line)
												neighbour_midpoint = get_midpoint_of_line_using_distance_from_haversine(neighbour_line)
												valid_pair_of_GDUs = is_valid_feature_test_with_azimuth_direction_only(reference_ft_id,neighbour_ft_id, ref_midpoint, neighbour_midpoint, neighbours_reconstructed_point_fts)
												if (valid_pair_of_GDUs == True):
													valid_pair_of_GDUs = is_valid_feature_test_for_lines(get_midpoint_of_line_using_distance_from_haversine(reference_line), get_midpoint_of_line_using_distance_from_haversine(neighbour_line),neighbours_reconstructed_polygon_fts,reference_line,neighbour_line,threshold_distance_in_km)
											if (valid_pair_of_GDUs == True):
												#check whether dictionary_of_tectonic_boundaries have features 
												if ((final_key in dictionary_of_tectonic_boundaries) == False):
													#create transform faults 
													
													if (specific_transform == Transform.Strike_slip_left):
														type_of_movement = 'Left'
													elif (specific_transform == Transform.Strike_slip_right):
														type_of_movement = 'Right'
													transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, type_of_movement, reconstruction_time, reference)
													#store transform_faults to dictionary_of_tectonic_boundaries
													dictionary_of_tectonic_boundaries[final_key] = ('Transform',transform_fault_1,transform_fault_2)
												else:
													need_new_fts = False
													if (previous_tectonic_motion[1] == Pure.Divergence or previous_tectonic_motion[1] == Transform.Oblique_divergence):
														tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
														#update end_age for boundary_1 and boundary_2
														current_appearance,_ = boundary_1.get_valid_time()
														boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														#write these two boundaries to a final list of features
														list_of_tectonic_boundaries.append(boundary_1)
														list_of_tectonic_boundaries.append(boundary_2)
														list_of_tectonic_boundaries.append(boundary_3)
														list_of_tectonic_boundaries.append(boundary_4)
														list_of_tectonic_boundaries.append(boundary_5)
														#setup variable
														need_new_fts = True
													else:
														print("value of previous_tectonic_motion")
														print(previous_tectonic_motion)
														print("value of dictionary_of_tectonic_boundaries at final_key")
														print(dictionary_of_tectonic_boundaries[final_key])
														tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
														if (tectonic_motion != 'Transform'):
															if (tectonic_motion == 'Convergence'):
																tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
																#update end_age for boundary_1 and boundary_2
																current_appearance,_ = boundary_1.get_valid_time()
																boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																#write these two boundaries to a final list of features
																list_of_tectonic_boundaries.append(boundary_1)
																list_of_tectonic_boundaries.append(boundary_2)
																#setup variable
																need_new_fts = True
															elif (tectonic_motion == 'Divergence'):
																tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
																#update end_age for boundary_1 and boundary_2
																current_appearance,_ = boundary_1.get_valid_time()
																boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
																#write these two boundaries to a final list of features
																list_of_tectonic_boundaries.append(boundary_1)
																list_of_tectonic_boundaries.append(boundary_2)
																list_of_tectonic_boundaries.append(boundary_3)
																list_of_tectonic_boundaries.append(boundary_4)
																list_of_tectonic_boundaries.append(boundary_5)
																#setup variable
																need_new_fts = True
													if (need_new_fts == True):
														#create new transform_faults 
														if (specific_transform == Transform.Strike_slip_left):
															type_of_movement = 'Left'
														elif (specific_transform == Transform.Strike_slip_right):
															type_of_movement = 'Right'
														transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(reference_line_ft, reference_line, neighbour_line_ft, neighbour_line, rotation_model, type_of_movement, reconstruction_time, reference)
														#store transform_faults to dictionary_of_tectonic_boundaries
														dictionary_of_tectonic_boundaries[final_key] = ('Transform',transform_fault_1,transform_fault_2)
														
											else:
												#collect data for CSV files for invalid pair of GDUs
												#invalid_pairs_of_GDUs_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id()))
												
												print("Info: Invalid pair of GDUs")
												print(reference_point_ft.get_reconstruction_plate_id())
												print(neighbour_point_ft.get_reconstruction_plate_id())
												
												list_of_invalid_pairs_of_ft.append(final_key)
												#check whether dictionary_of_tectonic_boundaries have features 
												if ((final_key in dictionary_of_tectonic_boundaries) == True):
													tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
													#if (previous_tectonic_motion[1] == Pure.Divergence or previous_tectonic_motion[1] == Transform.Oblique_divergence):
													if (tectonic_motion == 'Divergence'):
														tectonic_motion,boundary_1,boundary_2,boundary_3,boundary_4,boundary_5 = dictionary_of_tectonic_boundaries[final_key]
														#update end_age for boundary_1 and boundary_2
														current_appearance,_ = boundary_1.get_valid_time()
														boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														#write these two boundaries to a final list of features
														list_of_tectonic_boundaries.append(boundary_1)
														list_of_tectonic_boundaries.append(boundary_2)
														list_of_tectonic_boundaries.append(boundary_3)
														list_of_tectonic_boundaries.append(boundary_4)
														list_of_tectonic_boundaries.append(boundary_5)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
													else:
														tectonic_motion,boundary_1,boundary_2 = dictionary_of_tectonic_boundaries[final_key]
														#update end_age for boundary_1 and boundary_2
														current_appearance,_ = boundary_1.get_valid_time()
														boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
														#write these two boundaries to a final list of features
														list_of_tectonic_boundaries.append(boundary_1)
														list_of_tectonic_boundaries.append(boundary_2)
														#remove the key all of dictionary_of_tectonic_boundaries
														del dictionary_of_tectonic_boundaries[final_key]
								
								if (final_key in dictionary_of_tectonic_boundaries):
									final_tectonic_motion = dictionary_of_tectonic_boundaries[final_key][0]
									#collect data for CSV files for tectonic motion
									#tectonic_motion_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation,result_from_vector_evaluation,final_tectonic_motion))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation.name,result_from_vector_evaluation.name,final_tectonic_motion)))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
								else:
									#collect data for CSV files for tectonic motion
									#tectonic_motion_at_reconstruction_time.append((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation,result_from_vector_evaluation,None))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,reference_point_ft.get_reconstruction_plate_id(),neighbour_point_ft.get_reconstruction_plate_id(),reference_point_ft.get_feature_id().get_string(),neighbour_point_ft.get_feature_id().get_string(),result_from_distance_evaluation.name,result_from_vector_evaluation.name,None)))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
						else:
							print("Error in distance_evaluation")
							print("Error value of distance_evaluation is None")
							exit()
						#update the distance in the dictionary_of_distance
						dictionary_of_distance[final_key] = current_distance
					elif (key not in dictionary_of_distance and reverse_key not in dictionary_of_distance):
						print("Info: there is no key for the pair")
						#calculate the distance between two GDUs
						distance_in_rad = pygplates.GeometryOnSphere.distance(reference_point,neighbour_point)
						dictionary_of_distance[key] = distance_in_rad*pygplates.Earth.mean_radius_in_kms
						recently_updated.append(key)
						#recently_updated.append(reverse_key)
			else:
				print("Info: there_are_ NO neighbours")
		
		print('reconstruction_time')
		print(reconstruction_time)
		for key in list(dictionary_of_tectonic_motion.keys()):
			reconstructed_boundaries[:] = []
			final_reconstructed_boundaries[:] = []
			boundaries[:] = [] 
			if (key not in recently_updated):
				#print 'Key'
				print(key)
				recently_updated.append(key)
				#have to evaluate the pair of tectonic_boundaries
				key_for_polygon_ft_1 = None 
				key_for_polygon_ft_2 = None
				pairs_GDU_id = key.split('_')
				key_for_polygon_ft_1 = pairs_GDU_id[0]
				key_for_polygon_ft_2 = pairs_GDU_id[1]
				point_ft_1 = None
				point_ft_2 = None
				# point_1 = None
				# point_2 = None 
				valid_pair_key = False
				for point_ft,point in final_reconstructed_point_features:
					if (point_ft.get_description() == key_for_polygon_ft_1):
						point_ft_1 = point_ft
						#point_1 = point
					elif (point_ft.get_description() == key_for_polygon_ft_2):
						point_ft_2 = point_ft
						#point_2 = point
				
				print('value of point_ft_1')
				print(point_ft_1)
				print('value of point_ft_2')
				print(point_ft_2)
				
				(previous_result_from_distance_evaluation,previous_result_from_vector_evaluation) = dictionary_of_tectonic_motion[key]
				if (point_ft_1 is not None and point_ft_2 is not None):
					
					
					if (point_ft_1.is_valid_at_time(reconstruction_time + interval) and point_ft_2.is_valid_at_time(reconstruction_time + interval)):
						valid_pair_key = True
					else:
						valid_pair_key = False
				
				print('Here is value of valid_pair_key')
				print(valid_pair_key)
				print('dictionary_of_tectonic_boundaries.has_key(key)')
				print(key in dictionary_of_tectonic_boundaries)
				#check whether we have previous pair of boundaries
				if (key in dictionary_of_tectonic_boundaries and valid_pair_key == True):
					tectonic_motion = dictionary_of_tectonic_boundaries[key][0]
					if (tectonic_motion == 'Divergence'):
						boundary_1 = dictionary_of_tectonic_boundaries[key][1]
						boundary_2 = dictionary_of_tectonic_boundaries[key][2]
						boundary_3 = dictionary_of_tectonic_boundaries[key][3]
						boundary_4 = dictionary_of_tectonic_boundaries[key][4]
						boundary_5 = dictionary_of_tectonic_boundaries[key][5]
						if (boundary_2.is_valid_at_time(reconstruction_time) and boundary_3.is_valid_at_time(reconstruction_time)):
							boundaries.append(boundary_2)
							boundaries.append(boundary_3)
						else:
							clone_1 = boundary_2.clone()
							clone_1.set_valid_time(reconstruction_time + interval,reconstruction_time - interval)
							clone_2 = boundary_3.clone()
							clone_2.set_valid_time(reconstruction_time + interval,reconstruction_time - interval)
							boundaries.append(clone_1)
							boundaries.append(clone_2)
					elif (tectonic_motion == 'Convergence' or tectonic_motion == 'Transform'):
						boundary_1 = dictionary_of_tectonic_boundaries[key][1]
						boundary_2 = dictionary_of_tectonic_boundaries[key][2]
						if (boundary_1.is_valid_at_time(reconstruction_time) and boundary_2.is_valid_at_time(reconstruction_time)):
							boundaries.append(boundary_1)
							boundaries.append(boundary_2)
						else:
							clone_1 = boundary_1.clone()
							clone_1.set_valid_time(reconstruction_time + interval,reconstruction_time - interval)
							clone_2 = boundary_2.clone()
							clone_2.set_valid_time(reconstruction_time + interval,reconstruction_time - interval)
							boundaries.append(clone_1)
							boundaries.append(clone_2)
					line_ft_1,line_1 = None,None
					line_ft_2,line_2 = None,None
					mid_point_for_ref = None
					mid_point_for_neighbour = None
					if (len(boundaries) == 2):
						if (reference is not None):
							pygplates.reconstruct(boundaries,rotation_model,reconstructed_boundaries,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(boundaries,rotation_model,reconstructed_boundaries,reconstruction_time,group_with_feature = True)
						final_reconstructed_boundaries = find_final_reconstructed_geometries(reconstructed_boundaries,pygplates.PolylineOnSphere)
						line_ft_1,line_1 = final_reconstructed_boundaries[0]
						line_ft_2,line_2 = final_reconstructed_boundaries[1]
						print('value of reconstructed_boundaries')
						print(reconstructed_boundaries)
						print('value of line_1')
						print(line_1)
						print('value of line_2')
						print(line_2)
						mid_point_for_ref = get_midpoint_of_line_using_distance_from_haversine(line_1)
						mid_point_for_neighbour = get_midpoint_of_line_using_distance_from_haversine(line_2)
							
					featType = pygplates.FeatureType.gpml_continental_crust
					temp_ref_point_ft = pygplates.Feature.create_reconstructable_feature(featType,mid_point_for_ref,valid_time = point_ft_1.get_valid_time(),reconstruction_plate_id = point_ft_1.get_reconstruction_plate_id())
					temp_neighbour_point_ft = pygplates.Feature.create_reconstructable_feature(featType,mid_point_for_neighbour,valid_time = point_ft_2.get_valid_time(),reconstruction_plate_id = point_ft_2.get_reconstruction_plate_id())
					if (reference is not None):
						pygplates.reverse_reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstruction_time,reference)
					else:
						pygplates.reverse_reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstruction_time)
					#vector evaluation
					result_from_vector_evaluation = relative_position_velocity_vectors_eval(rotation_model,temp_ref_point_ft,temp_neighbour_point_ft,reconstruction_time,interval,reference,cos_value_for_transform)
						
					reconstructed_temp_point_features[:] = []
					#have to evaluate distance 
					if (reference is not None):
						#point_features
						pygplates.reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstructed_temp_point_features,(reconstruction_time + interval),anchor_plate_id = reference, group_with_feature = True)
					else:
						#point_features
						pygplates.reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstructed_temp_point_features,(reconstruction_time + interval),group_with_feature = True)
										
					final_reconstructed_temp_point_features = find_final_reconstructed_geometries(reconstructed_temp_point_features,pygplates.PointOnSphere)
					previous_ref_point = None 
					previous_neighbour_point = None
					for ft,point in final_reconstructed_temp_point_features:
						if (ft.get_reconstruction_plate_id() == temp_ref_point_ft.get_reconstruction_plate_id()):
							previous_ref_point = point
						elif (ft.get_reconstruction_plate_id() == temp_neighbour_point_ft.get_reconstruction_plate_id()):
							previous_neighbour_point = point
					if (previous_ref_point is None or previous_neighbour_point is None):
						print("Error in identify_plate_tectonic_boundaries line 3952")
						print("Error cannot find previous_ref_point or previous_neighbour_point")
						print("value of previous_ref_point")
						print(previous_ref_point)
						print("value of previous_neighbour_point")
						print(previous_neighbour_point)
						print("value of temp_ref_point_ft")
						print(temp_ref_point_ft)
						print("value of temp_neighbour_point_ft")
						print(temp_neighbour_point_ft)
						print(temp_ref_point_ft.get_valid_time())
						print(line_ft_1.get_valid_time())
						print(temp_neighbour_point_ft.get_valid_time())
						print(line_ft_2.get_valid_time())
						print(reconstruction_time)
						exit()
					previous_distance = pygplates.GeometryOnSphere.distance(previous_ref_point,previous_neighbour_point)*pygplates.Earth.mean_radius_in_kms
					current_distance = pygplates.GeometryOnSphere.distance(mid_point_for_ref,mid_point_for_neighbour)*pygplates.Earth.mean_radius_in_kms
					#to find the mean of difference in distance
					temp_result_from_distance_evaluation = None 
					if (abs(previous_distance - current_distance) >= difference_distance_km):
						print("Info: distance check the second time ")
						#perform comparison between previous_distance and current_distance
						#based on distance evaluation
						if (previous_distance > current_distance):
							temp_result_from_distance_evaluation = Change.Decrease
						elif (previous_distance == current_distance):
							temp_result_from_distance_evaluation = Change.Stable
						elif (previous_distance < current_distance):
							temp_result_from_distance_evaluation = Change.Increase
					else:
						temp_result_from_distance_evaluation = Change.Stable
							
					#we need to find neighbouring polygons using plate id instead of GDU feature id
					#polygon_fts_polygons = [(polygon_ft,polygon) for polygon_ft,polygon in final_reconstructed_polygon_features if (polygon_ft.get_reconstruction_plate_id() == line_ft_1.get_reconstruction_plate_id() or polygon_ft.get_reconstruction_plate_id() == line_ft_2.get_reconstruction_plate_id())]
							
					#valid_test_result = is_valid_feature_test_for_lines(mid_point_for_ref, mid_point_for_neighbour,polygon_fts_polygons,None,None) #O(n) where n is number of tuples in polygon_fts_polygons
						
					neighbours_feature_id = None
					if (point_ft_1.get_description() in dictionary_of_neighbours_id):
						neighbours_feature_id = dictionary_of_neighbours_id[point_ft_1.get_description()]
					if (point_ft_2.get_description() in dictionary_of_neighbours_id):
						neighbours_feature_id = neighbours_feature_id + dictionary_of_neighbours_id[point_ft_2.get_description()]
					neighbours_reconstructed_polygon_fts = [(polygon_ft,polygon) for polygon_ft,polygon in final_reconstructed_polygon_features if polygon_ft.get_feature_id().get_string() in neighbours_feature_id]
						
					valid_test_result = is_valid_feature_test_with_middle_geometry(neighbours_reconstructed_polygon_fts,line_1,line_2)
					if (valid_test_result == True):
						valid_test_result = is_valid_feature_test_for_lines(mid_point_for_ref, mid_point_for_neighbour,neighbours_reconstructed_polygon_fts,line_1,line_2,threshold_distance_in_km)
						
						

					
					#update the motion in the dictionary
					dictionary_of_tectonic_motion[key] = (temp_result_from_distance_evaluation,result_from_vector_evaluation)
							
					#if (valid_test_result == False):
					#	invalid_pairs_of_GDUs_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id()))
					#else:
					if (valid_test_result == True):
						if (temp_result_from_distance_evaluation == Change.Increase and (result_from_vector_evaluation == Pure.Divergence or result_from_vector_evaluation == Transform.Oblique_divergence)):
							if (tectonic_motion == 'Divergence'):
								clone_boundary_1 = dictionary_of_tectonic_boundaries[key][1].clone()
								clone_boundary_2 = dictionary_of_tectonic_boundaries[key][2].clone()
								clone_boundary_3 = dictionary_of_tectonic_boundaries[key][3].clone()
								clone_boundary_4 = dictionary_of_tectonic_boundaries[key][4].clone()
								clone_boundary_5 = dictionary_of_tectonic_boundaries[key][5].clone()
								
								current_appearance,current_disappearance = clone_boundary_1.get_valid_time()
								if (current_disappearance > reconstruction_time and abs(current_disappearance - reconstruction_time)/interval > 1):
									clone_boundary_1.set_valid_time(reconstruction_time,0.00)
									clone_boundary_2.set_valid_time(reconstruction_time,0.00)
									clone_boundary_3.set_valid_time(reconstruction_time,0.00)
									clone_boundary_4.set_valid_time(reconstruction_time,0.00)
									clone_boundary_5.set_valid_time(reconstruction_time,0.00)
									dictionary_of_tectonic_boundaries[key] = ('Divergence',clone_boundary_1,clone_boundary_2,clone_boundary_3,clone_boundary_4,clone_boundary_5)
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_boundaries (time, ref_gdu_id, other_gdu_id, line_1_ft_id, line_2_ft_id, line_1_ft_name, line_2_ft_name, tectonic_motion) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,(reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),clone_boundary_2.get_feature_id().get_string(),clone_boundary_3.get_feature_id().get_string(),line_ft_1.get_name(),line_ft_2.get_name(),'Divergence'))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print("Error in record to tectonic_boundaries from line 5483")
										print(error)
										exit()
									finally:
										if conn is not None:
											conn.close()
								#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Divergence'))
								conn = None 
								try:
									#read database config
									params = config()
									#connect to the PostgreSQL
									conn = psycopg2.connect(**params)
									#create a new cursor
									cur = conn.cursor()
									sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
									cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Divergence')))
									#commit the changes to the database
									conn.commit()
									#close communication with the database
									cur.close()
								except (Exception, psycopg2.DatabaseError) as error:
									print(error)
								finally:
									if conn is not None:
										conn.close()
							else:
								#create new Divergence feature
								#middle_ft,boundary_1,boundary_2,transform_fault = find_rift_segment_and_transform_faults(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, interval, reference)
								middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right = find_rift_segment_and_transform_faults_v1(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, interval, reference)
								if (boundary_1 is None and boundary_2 is None):
									#this is the artifact or it is actually transform but was misidentified
									specific_transform = left_or_right_transform(mid_point_for_ref,mid_point_for_neighbour)
									#update the motion in the dictionary
									dictionary_of_tectonic_motion[key] = (temp_result_from_distance_evaluation,specific_transform)
									if (specific_transform == Transform.Strike_slip_left):
										type_of_movement = 'Left'
									elif (specific_transform == Transform.Strike_slip_right):
										type_of_movement = 'Right'
									transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(line_ft_1, line_1, line_ft_2, line_2, rotation_model, type_of_movement, reconstruction_time, reference)
									#store transform_faults to dictionary_of_tectonic_boundaries
									dictionary_of_tectonic_boundaries[key] = ('Transform',transform_fault_1,transform_fault_2)
									
									#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Transform'))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_motion(time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Transform')))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
								else:
									dictionary_of_tectonic_boundaries[key] = ('Divergence',middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right)
									#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Divergence'))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Divergence')))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()

						elif (temp_result_from_distance_evaluation == Change.Decrease and (result_from_vector_evaluation == Pure.Convergence or result_from_vector_evaluation == Transform.Oblique_convergence)):
							if (tectonic_motion == 'Divergence'):#previous motion 
								#check how long this motion lasts
								if (key in dictionary_of_suspected_motion):
									suspected_motion,time = dictionary_of_suspected_motion[key]
									if (suspected_motion == Transform.Oblique_convergence):
										if (abs(reconstruction_time - time) >= (interval*2.00)):
											del dictionary_of_suspected_motion[key]
											#update end_time for transform faults or stable boundaries
											if ((key in dictionary_of_tectonic_boundaries) == True):
												print('value of previous_result_from_vector_evaluation')
												print(previous_result_from_vector_evaluation)
												tectonic_motion = dictionary_of_tectonic_boundaries[key][0]
												print('value of tectonic_motion')
												print(tectonic_motion) 
												boundary_1 = dictionary_of_tectonic_boundaries[key][1]
												boundary_2 = dictionary_of_tectonic_boundaries[key][2]
												boundary_3 = dictionary_of_tectonic_boundaries[key][3]
												boundary_4 = dictionary_of_tectonic_boundaries[key][4]
												boundary_5 = dictionary_of_tectonic_boundaries[key][5]
												#update end_age for boundary_1 and boundary_2
												current_appearance,_ = boundary_1.get_valid_time()
												boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
												boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
												boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
												boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
												boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
												#write these two boundaries to a final list of features
												list_of_tectonic_boundaries.append(boundary_1)
												list_of_tectonic_boundaries.append(boundary_2)
												list_of_tectonic_boundaries.append(boundary_3)
												list_of_tectonic_boundaries.append(boundary_4)
												list_of_tectonic_boundaries.append(boundary_5)
												#remove the key all of dictionary_of_tectonic_boundaries
												del dictionary_of_tectonic_boundaries[key]
												#create new Convergence feature
												boundary_1,boundary_2 = None,None
												if (possible_line_fts_for_subduction_zone_deposits is not None):
													boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_deposits, rotation_model, reconstruction_time, reference)
												if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_igneous is not None):
													boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_igneous, rotation_model, reconstruction_time, reference)
												if (boundary_1 is None and boundary_2 is None):
													boundary_1,boundary_2 = create_feature_for_unknown_margin_convergent_zone(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, reference)
												dictionary_of_tectonic_boundaries[key] = ('Convergence',boundary_1,boundary_2)
												conn = None 
												try:
													#read database config
													params = config()
													#connect to the PostgreSQL
													conn = psycopg2.connect(**params)
													#create a new cursor
													cur = conn.cursor()
													sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
													cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Convergence')))
													#commit the changes to the database
													conn.commit()
													#close communication with the database
													cur.close()
												except (Exception, psycopg2.DatabaseError) as error:
													print(error)
												finally:
													if conn is not None:
														conn.close()	
												#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Convergence'))
								else:
									dictionary_of_suspected_motion[key] = (result_from_vector_evaluation,reconstruction_time)
									#suspecting_tectonic_motion.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),'line_feature_1_'+line_ft_1.get_feature_id().get_string(),'line_feature_2_'+line_ft_2.get_feature_id().get_string(),temp_result_from_distance_evaluation,result_from_vector_evaluation))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO suspecting_tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),'line_feature_1_'+line_ft_1.get_feature_id().get_string(),'line_feature_2_'+line_ft_2.get_feature_id().get_string(),temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name)))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
							else:
								if (tectonic_motion == 'Transform' and previous_result_from_distance_evaluation != Change.Increase and previous_result_from_vector_evaluation != Pure.Divergence and previous_result_from_vector_evaluation != Transform.Oblique_divergence): #previous motion 
									boundary_1 = dictionary_of_tectonic_boundaries[key][1]
									boundary_2 = dictionary_of_tectonic_boundaries[key][2]
									#update end_age for boundary_1 and boundary_2
									current_appearance,_ = boundary_1.get_valid_time()
									boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
									boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.5))
									#write these two boundaries to a final list of features
									list_of_tectonic_boundaries.append(boundary_1)
									list_of_tectonic_boundaries.append(boundary_2)
									#remove the key all of dictionary_of_tectonic_boundaries
									del dictionary_of_tectonic_boundaries[key]
									#create new Convergence feature
									boundary_1,boundary_2 = None,None
									if (possible_line_fts_for_subduction_zone_deposits is not None):
										boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_deposits, rotation_model, reconstruction_time, reference)
									if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_igneous is not None):
										boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_igneous, rotation_model, reconstruction_time, reference)
									if (boundary_1 is None and boundary_2 is None):
										boundary_1,boundary_2 = create_feature_for_unknown_margin_convergent_zone(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, reference)
									dictionary_of_tectonic_boundaries[key] = ('Convergence',boundary_1,boundary_2)
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Convergence')))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
									#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Convergence'))
								elif (tectonic_motion == 'Convergence'): #previous_motion
									boundary_1 = dictionary_of_tectonic_boundaries[key][1]
									boundary_2 = dictionary_of_tectonic_boundaries[key][2]
									#update end_age for boundary_1 and boundary_2
									current_appearance,current_disappearance = boundary_1.get_valid_time()
									if (current_disappearance > reconstruction_time and abs(current_disappearance - reconstruction_time)/interval > 1):
										boundary_1,boundary_2 = None, None
										if (possible_line_fts_for_subduction_zone_deposits is not None):
											boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_deposits, rotation_model, reconstruction_time, reference)
										if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_igneous is not None):
											boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_igneous, rotation_model, reconstruction_time, reference)
										if (boundary_1 is None and boundary_2 is None):
											boundary_1,boundary_2 = create_feature_for_unknown_margin_convergent_zone(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, reference)
										dictionary_of_tectonic_boundaries[key] = ('Convergence',boundary_1,boundary_2)
										#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Convergence'))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Convergence')))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
						#elif (temp_result_from_distance_evaluation == Change.Stable or result_from_vector_evaluation == ):#
					else:
						list_of_invalid_pairs_of_ft.append(key)
						#update the time for the boundaries 
						if (tectonic_motion == 'Divergence'):
							boundary_1 = dictionary_of_tectonic_boundaries[key][1]
							boundary_2 = dictionary_of_tectonic_boundaries[key][2]
							boundary_3 = dictionary_of_tectonic_boundaries[key][3]
							boundary_4 = dictionary_of_tectonic_boundaries[key][4]
							boundary_5 = dictionary_of_tectonic_boundaries[key][5]
							current_appearance,current_disappearance = boundary_1.get_valid_time()
							boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.50))
							boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.50))
							boundary_3.set_valid_time(current_appearance,reconstruction_time - (interval*0.50))
							boundary_4.set_valid_time(current_appearance,reconstruction_time - (interval*0.50))
							boundary_5.set_valid_time(current_appearance,reconstruction_time - (interval*0.50))
							#write these two boundaries to a final list of features
							list_of_tectonic_boundaries.append(boundary_1)
							list_of_tectonic_boundaries.append(boundary_2)
							list_of_tectonic_boundaries.append(boundary_3)
							list_of_tectonic_boundaries.append(boundary_4)
							list_of_tectonic_boundaries.append(boundary_5)
							#remove the key all of dictionary_of_tectonic_boundaries
							del dictionary_of_tectonic_boundaries[key]
						else:
							boundary_1 = dictionary_of_tectonic_boundaries[key][1]
							boundary_2 = dictionary_of_tectonic_boundaries[key][2]
							current_appearance,current_disappearance = boundary_1.get_valid_time()
							boundary_1.set_valid_time(current_appearance,reconstruction_time - (interval*0.50))
							boundary_2.set_valid_time(current_appearance,reconstruction_time - (interval*0.50))
							#write these two boundaries to a final list of features
							list_of_tectonic_boundaries.append(boundary_1)
							list_of_tectonic_boundaries.append(boundary_2)
							#remove the key all of dictionary_of_tectonic_boundaries
							del dictionary_of_tectonic_boundaries[key]
							
				elif (valid_pair_key == True):				
					line_ft_1 = None
					line_1 = None
					line_ft_2 = None
					line_2 = None
					
					neighbours_feature_id = None
					if (point_ft_1.get_description() in dictionary_of_neighbours_id):
						neighbours_feature_id = dictionary_of_neighbours_id[point_ft_1.get_description()]
					if (point_ft_2.get_description() in dictionary_of_neighbours_id):
						neighbours_feature_id = neighbours_feature_id + dictionary_of_neighbours_id[point_ft_2.get_description()]
					neighbours_reconstructed_polygon_fts = [(polygon_ft,polygon) for polygon_ft,polygon in final_reconstructed_polygon_features if polygon_ft.get_feature_id().get_string() in neighbours_feature_id]
					#neighbours_reconstructed_point_fts = [(point_ft,point) for point_ft,point in final_reconstructed_point_features if point_ft.get_description() in neighbours_feature_id]
					
					line_ft_1,line_1,line_ft_2,line_2 = find_line_feature_represent_other_GDU(point_ft_1,None,point_ft_2,None,pre_processed_line_features)
					valid_test_result = False
					print('value of line_1')
					print(line_1)
					print('value of line_2')
					print(line_2)
					if (line_1 is not None and line_2 is not None):	
						mid_point_for_ref = get_midpoint_of_line_using_distance_from_haversine(line_1)
						mid_point_for_neighbour = get_midpoint_of_line_using_distance_from_haversine(line_2)
						print(mid_point_for_ref)
						print(mid_point_for_neighbour)
							
						featType = pygplates.FeatureType.gpml_continental_crust
						temp_ref_point_ft = pygplates.Feature.create_reconstructable_feature(featType,mid_point_for_ref,valid_time = point_ft_1.get_valid_time(),reconstruction_plate_id = point_ft_1.get_reconstruction_plate_id())
						temp_neighbour_point_ft = pygplates.Feature.create_reconstructable_feature(featType,mid_point_for_neighbour,valid_time = point_ft_2.get_valid_time(),reconstruction_plate_id = point_ft_2.get_reconstruction_plate_id())
						if (reference is not None):
							pygplates.reverse_reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstruction_time,reference)
						else:
							pygplates.reverse_reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstruction_time)
						#we focus on only vector evaluation
						result_from_vector_evaluation = relative_position_velocity_vectors_eval(rotation_model,temp_ref_point_ft,temp_neighbour_point_ft,reconstruction_time,interval,reference,cos_value_for_transform)
					
						reconstructed_temp_point_features[:] = []
						#have to evaluate distance 
						if (reference is not None):
							#point_features
							pygplates.reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstructed_temp_point_features,(reconstruction_time + interval),anchor_plate_id = reference, group_with_feature = True)
						else:
							#point_features
							pygplates.reconstruct([temp_ref_point_ft,temp_neighbour_point_ft],rotation_model,reconstructed_temp_point_features,(reconstruction_time + interval),group_with_feature = True)
										
						#debug 
						#point_fts_for_motion_evaluation.append(temp_ref_point_ft)
						#point_fts_for_motion_evaluation.append(temp_neighbour_point_ft)
										
						final_reconstructed_temp_point_features = find_final_reconstructed_geometries(reconstructed_temp_point_features,pygplates.PointOnSphere)
						previous_ref_point = None 
						previous_neighbour_point = None
						for ft,point in final_reconstructed_temp_point_features:
							if (ft.get_reconstruction_plate_id() == temp_ref_point_ft.get_reconstruction_plate_id()):
								previous_ref_point = point
							elif (ft.get_reconstruction_plate_id() == temp_neighbour_point_ft.get_reconstruction_plate_id()):
								previous_neighbour_point = point
						if (previous_ref_point is None or previous_neighbour_point is None):
							print("Error in identify_plate_tectonic_boundaries line 4153")
							print("Error cannot find previous_ref_point or previous_neighbour_point line") 
							print("value of previous_ref_point")
							print(previous_ref_point)
							print("value of previous_neighbour_point")
							print(previous_neighbour_point)
							print("value of temp_ref_point_ft")
							print(temp_ref_point_ft)
							print("value of temp_neighbour_point_ft")
							print(temp_neighbour_point_ft)
							print(temp_ref_point_ft.get_valid_time())
							print(line_ft_1.get_valid_time())
							print(temp_neighbour_point_ft.get_valid_time())
							print(line_ft_2.get_valid_time())
							print(reconstruction_time)
							exit()
						previous_distance = pygplates.GeometryOnSphere.distance(previous_ref_point,previous_neighbour_point)*pygplates.Earth.mean_radius_in_kms
						current_distance = pygplates.GeometryOnSphere.distance(mid_point_for_ref,mid_point_for_neighbour)*pygplates.Earth.mean_radius_in_kms
						#to find the mean of difference in distance
						temp_result_from_distance_evaluation = None 
						if (abs(previous_distance - current_distance) >= difference_distance_km):
							print("Info: distance check the second time ")
							#perform comparison between previous_distance and current_distance
							#based on distance evaluation
							if (previous_distance > current_distance):
								temp_result_from_distance_evaluation = Change.Decrease
							elif (previous_distance == current_distance):
								temp_result_from_distance_evaluation = Change.Stable
							elif (previous_distance < current_distance):
								temp_result_from_distance_evaluation = Change.Increase
						else:
							temp_result_from_distance_evaluation = Change.Stable
						
						
						valid_test_result = is_valid_feature_test_with_middle_geometry(neighbours_reconstructed_polygon_fts,line_1,line_2)
						if (valid_test_result == True):
							valid_test_result = is_valid_feature_test_for_lines(mid_point_for_ref, mid_point_for_neighbour,neighbours_reconstructed_polygon_fts,line_1,line_2,threshold_distance_in_km)#O(n) where n is number of tuples in polygon_fts_polygons						
						
						
						conn = None 
						try:
							#read database config
							params = config()
							#connect to the PostgreSQL
							conn = psycopg2.connect(**params)
							#create a new cursor
							cur = conn.cursor()
							sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
							cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Not_known_yet_2')))
							#commit the changes to the database
							conn.commit()
							#close communication with the database
							cur.close()
						except (Exception, psycopg2.DatabaseError) as error:
							print(error)
						finally:
							if conn is not None:
								conn.close()
						#update the motion in the dictionary
						dictionary_of_tectonic_motion[key] = (temp_result_from_distance_evaluation,result_from_vector_evaluation)
					#if (valid_test_result == False):
					#	invalid_pairs_of_GDUs_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id()))
					#else:
					#print('valid_test_result')
					#print(valid_test_result)
					if (valid_test_result == True):
						if (temp_result_from_distance_evaluation == Change.Increase and (result_from_vector_evaluation == Pure.Divergence or result_from_vector_evaluation == Transform.Oblique_divergence)):
							if (previous_result_from_vector_evaluation != Pure.Convergence and previous_result_from_vector_evaluation != Transform.Oblique_convergence):
								#create new Divergence feature
								middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right = find_rift_segment_and_transform_faults_v1(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, interval, reference)
								if (boundary_1 is None and boundary_2 is None):
									#this is the artifact or it is actually transform but was misidentified
									specific_transform = left_or_right_transform(mid_point_for_ref,mid_point_for_neighbour)
									#update the motion in the dictionary
									dictionary_of_tectonic_motion[key] = (result_from_distance_evaluation,specific_transform)
									if (specific_transform == Transform.Strike_slip_left):
										type_of_movement = 'Left'
									elif (specific_transform == Transform.Strike_slip_right):
										type_of_movement = 'Right'
									transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(line_ft_1, line_1, line_ft_2, line_2, rotation_model, type_of_movement, reconstruction_time, reference)
									#store transform_faults to dictionary_of_tectonic_boundaries
									dictionary_of_tectonic_boundaries[key] = ('Transform',transform_fault_1,transform_fault_2)
									#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Transform'))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Transform')))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
								else:
									dictionary_of_tectonic_boundaries[key] = ('Divergence',middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right)
									#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Divergence'))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Divergence')))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
								
							else:
								#check how long this motion lasts
								if (key in dictionary_of_suspected_motion):
									suspected_motion,time = dictionary_of_suspected_motion[key]
									if (suspected_motion == Transform.Oblique_divergence):
										if (abs(reconstruction_time - time) >= (interval*2.00)):
											del dictionary_of_suspected_motion[key]
											#create new Divergence feature
											middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right = find_rift_segment_and_transform_faults_v1(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, interval, reference)
											if (boundary_1 is None and boundary_2 is None):
												#this is the artifact or it is actually transform but was misidentified
												specific_transform = left_or_right_transform(mid_point_for_ref,mid_point_for_neighbour)
												#update the motion in the dictionary
												dictionary_of_tectonic_motion[key] = (result_from_distance_evaluation,specific_transform)
												if (specific_transform == Transform.Strike_slip_left):
													type_of_movement = 'Left'
												elif (specific_transform == Transform.Strike_slip_right):
													type_of_movement = 'Right'
												transform_fault_1,transform_fault_2 = create_feature_for_transform_zone(line_ft_1, line_1, line_ft_2, line_2, rotation_model, type_of_movement, reconstruction_time, reference)
												#store transform_faults to dictionary_of_tectonic_boundaries
												dictionary_of_tectonic_boundaries[key] = ('Transform',transform_fault_1,transform_fault_2)
												#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Transform'))
												conn = None 
												try:
													#read database config
													params = config()
													#connect to the PostgreSQL
													conn = psycopg2.connect(**params)
													#create a new cursor
													cur = conn.cursor()
													sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
													cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Transform')))
													#commit the changes to the database
													conn.commit()
													#close communication with the database
													cur.close()
												except (Exception, psycopg2.DatabaseError) as error:
													print(error)
												finally:
													if conn is not None:
														conn.close()
											else:
												dictionary_of_tectonic_boundaries[key] = ('Divergence',middle_ft,boundary_1,boundary_2,transform_point_left,transform_point_right)
												#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Divergence'))
												conn = None 
												try:
													#read database config
													params = config()
													#connect to the PostgreSQL
													conn = psycopg2.connect(**params)
													#create a new cursor
													cur = conn.cursor()
													sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
													cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Divergence')))
													#commit the changes to the database
													conn.commit()
													#close communication with the database
													cur.close()
												except (Exception, psycopg2.DatabaseError) as error:
													print(error)
												finally:
													if conn is not None:
														conn.close()
								else:			
									dictionary_of_suspected_motion[key] = (result_from_vector_evaluation,reconstruction_time)
									#suspecting_tectonic_motion.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),'line_feature_1_'+line_ft_1.get_feature_id().get_string(),'line_feature_2_'+line_ft_2.get_feature_id().get_string(),temp_result_from_distance_evaluation,result_from_vector_evaluation))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO suspecting_tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
										#cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),'line_feature_1_'+line_ft_1.get_feature_id().get_string(),'line_feature_2_'+line_ft_2.get_feature_id().get_string(),temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name)))
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name)))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
						elif (temp_result_from_distance_evaluation == Change.Decrease and (result_from_vector_evaluation == Pure.Convergence or result_from_vector_evaluation == Transform.Oblique_convergence)):
							if (previous_result_from_vector_evaluation == Pure.Divergence or previous_result_from_vector_evaluation == Transform.Oblique_divergence):
								#check how long this motion lasts
								if (key in dictionary_of_suspected_motion):
									suspected_motion,time = dictionary_of_suspected_motion[key]
									if (suspected_motion == Transform.Oblique_convergence):
										if (abs(reconstruction_time - time) >= (interval*2.00)):
											del dictionary_of_suspected_motion[key]
											#create new Convergence feature
											boundary_1,boundary_2 = None, None
											if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_deposits is not None):
												boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_deposits, rotation_model, reconstruction_time, reference)
											if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_igneous is not None):
												boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_igneous, rotation_model, reconstruction_time, reference)
											if (boundary_1 is None and boundary_2 is None):
												boundary_1,boundary_2 = create_feature_for_unknown_margin_convergent_zone(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, reference)
											dictionary_of_tectonic_boundaries[key] = ('Convergence',boundary_1,boundary_2)
											#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Convergence'))
											conn = None 
											try:
												#read database config
												params = config()
												#connect to the PostgreSQL
												conn = psycopg2.connect(**params)
												#create a new cursor
												cur = conn.cursor()
												sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
												cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Convergence')))
												#commit the changes to the database
												conn.commit()
												#close communication with the database
												cur.close()
											except (Exception, psycopg2.DatabaseError) as error:
												print(error)
											finally:
												if conn is not None:
													conn.close()
								else:
									dictionary_of_suspected_motion[key] = (result_from_vector_evaluation,reconstruction_time)
														
									#suspecting_tectonic_motion.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),'line_feature_1_'+line_ft_1.get_feature_id().get_string(),'line_feature_2_'+line_ft_2.get_feature_id().get_string(),temp_result_from_distance_evaluation,result_from_vector_evaluation))
									conn = None 
									try:
										#read database config
										params = config()
										#connect to the PostgreSQL
										conn = psycopg2.connect(**params)
										#create a new cursor
										cur = conn.cursor()
										sql = """ INSERT INTO suspecting_tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
										cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name)))
										#commit the changes to the database
										conn.commit()
										#close communication with the database
										cur.close()
									except (Exception, psycopg2.DatabaseError) as error:
										print(error)
									finally:
										if conn is not None:
											conn.close()
							elif (previous_result_from_vector_evaluation == Pure.Convergence or previous_result_from_vector_evaluation == Transform.Oblique_convergence or previous_result_from_vector_evaluation is None or previous_result_from_vector_evaluation == Transform.Strike_slip_left or previous_result_from_vector_evaluation == Transform.Strike_slip_right):
								#create new Convergence feature
								boundary_1,boundary_2 = None, None
								if (possible_line_fts_for_subduction_zone_deposits is not None):
									boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_deposits, rotation_model, reconstruction_time, reference)
								if (boundary_1 is None and boundary_2 is None and possible_line_fts_for_subduction_zone_igneous is not None):
									boundary_1,boundary_2 = create_feature_for_convergent_zone_from_PointFeature_data(line_ft_1, line_1, line_ft_2, line_2, possible_line_fts_for_subduction_zone_igneous, rotation_model, reconstruction_time, reference)
								if (boundary_1 is None and boundary_2 is None):
									boundary_1,boundary_2 = create_feature_for_unknown_margin_convergent_zone(line_ft_1, line_1, line_ft_2, line_2, rotation_model, reconstruction_time, reference)
								dictionary_of_tectonic_boundaries[key] = ('Convergence',boundary_1,boundary_2)
								#tectonic_motion_at_reconstruction_time.append((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation,result_from_vector_evaluation,'Convergence'))
								conn = None 
								try:
									#read database config
									params = config()
									#connect to the PostgreSQL
									conn = psycopg2.connect(**params)
									#create a new cursor
									cur = conn.cursor()
									sql = """ INSERT INTO tectonic_motion (time, ref_gdu_id, other_gdu_id, ref_ft_id, other_ft_id, result_from_dist_eval, result_from_vec_eval,tectonic_motion_for_boundaries) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
									cur.execute(sql,((reconstruction_time,line_ft_1.get_reconstruction_plate_id(),line_ft_2.get_reconstruction_plate_id(),key_for_polygon_ft_1,key_for_polygon_ft_2,temp_result_from_distance_evaluation.name,result_from_vector_evaluation.name,'Convergence')))
									#commit the changes to the database
									conn.commit()
									#close communication with the database
									cur.close()
								except (Exception, psycopg2.DatabaseError) as error:
									print(error)
								finally:
									if conn is not None:
										conn.close()
					else:
						list_of_invalid_pairs_of_ft.append(key)
						
		reconstructed_boundaries[:] = []
		final_reconstructed_boundaries[:] = []
		boundaries[:] = []	
		if (count > 0):
			print("mean difference in distance")
			print(float(total_difference_in_distance)/float(count))
			print("number of tectonic_boundaries")
			print(len(list_of_tectonic_boundaries))
			print("pair of boundaries in dictionary_of_tectonic_boundaries")
			print(len(list(dictionary_of_tectonic_boundaries.keys())))
		
		if (last_output_csv_files == -1.00):
			if (abs(begin_reconstruction_time - reconstruction_time)/interval >= freq_writing_csv_files):
				
				boundaries_from_dictionary = []
				tuple_of_boundaries = list(dictionary_of_tectonic_boundaries.values())
				for tuple in tuple_of_boundaries:
					tectonic_motion = tuple[0]
					if (tectonic_motion == 'Divergence'):
						boundaries_from_dictionary.append(tuple[1])
						boundaries_from_dictionary.append(tuple[2])
						boundaries_from_dictionary.append(tuple[3])
						boundaries_from_dictionary.append(tuple[4])
						boundaries_from_dictionary.append(tuple[5])
						#for final output list of boundaries
						begin_valid_time,end_valid_time = tuple[1].get_valid_time()
						if (end_valid_time <= reconstruction_time):
							clone_1 = tuple[1].clone()
							clone_2 = tuple[2].clone()
							clone_3 = tuple[3].clone()
							clone_4 = tuple[4].clone()
							clone_5 = tuple[5].clone()
							clone_1.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_2.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_3.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_4.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_5.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							list_of_tectonic_boundaries.append(clone_1)
							list_of_tectonic_boundaries.append(clone_2)
							list_of_tectonic_boundaries.append(clone_3)
							list_of_tectonic_boundaries.append(clone_4)
							list_of_tectonic_boundaries.append(clone_5)
					else:
						boundaries_from_dictionary.append(tuple[1])
						boundaries_from_dictionary.append(tuple[2])
			
						#for final output list of boundaries
						begin_valid_time,end_valid_time = tuple[1].get_valid_time()
						if (end_valid_time <= reconstruction_time):

							clone_1 = tuple[1].clone()
							clone_2 = tuple[2].clone()
							clone_1.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_2.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							list_of_tectonic_boundaries.append(clone_1)
							list_of_tectonic_boundaries.append(clone_2)
	
				
				
				outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_tectonic_boundaries)
				outputLinesFile = "tectonic_boundaries_features_"+modelname+"_"+str(begin_reconstruction_time)+"_"+str(reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".gpml"
				outputLinesFeatureCollection.write(outputLinesFile)

				
				#clear everything
				boundaries_from_dictionary[:] = []
				list_of_tectonic_boundaries[:] = []
				
				
				#update last_output_csv_files
				last_output_csv_files = reconstruction_time
			elif (abs(begin_reconstruction_time - reconstruction_time)/interval < freq_writing_csv_files and reconstruction_time == end_reconstruction_time):


				tuple_of_boundaries = list(dictionary_of_tectonic_boundaries.values())
				for tuple in tuple_of_boundaries:
					tectonic_motion = tuple[0]
					if (tectonic_motion == 'Divergence'):
						boundaries_from_dictionary.append(tuple[1])
						boundaries_from_dictionary.append(tuple[2])
						boundaries_from_dictionary.append(tuple[3])
						boundaries_from_dictionary.append(tuple[4])
						boundaries_from_dictionary.append(tuple[5])
						#for final output list of boundaries
						begin_valid_time,end_valid_time = tuple[1].get_valid_time()
						if (end_valid_time <= end_reconstruction_time):
							list_of_tectonic_boundaries.append(tuple[1])
							list_of_tectonic_boundaries.append(tuple[2])
							list_of_tectonic_boundaries.append(tuple[3])
							list_of_tectonic_boundaries.append(tuple[4])
							list_of_tectonic_boundaries.append(tuple[5])
					else:
						boundaries_from_dictionary.append(tuple[1])
						boundaries_from_dictionary.append(tuple[2])
			
						#for final output list of boundaries
						begin_valid_time,end_valid_time = tuple[1].get_valid_time()
						if (end_valid_time <= end_reconstruction_time):
							list_of_tectonic_boundaries.append(tuple[1])
							list_of_tectonic_boundaries.append(tuple[2])

				
				outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_tectonic_boundaries)
				outputLinesFile = "tectonic_boundaries_features_"+modelname+"_"+str(last_output_csv_files)+"_"+str(end_reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".gpml"
				outputLinesFeatureCollection.write(outputLinesFile)
	
	
				
				
				#clear everything
				boundaries_from_dictionary[:] = []
				list_of_tectonic_boundaries[:] = []

				
				#update last_output_csv_files
				last_output_csv_files = reconstruction_time
		else:
			if (abs(last_output_csv_files - reconstruction_time)/interval >= freq_writing_csv_files):

				
				tuple_of_boundaries = list(dictionary_of_tectonic_boundaries.values())
				for tuple in tuple_of_boundaries:
					tectonic_motion = tuple[0]
					if (tectonic_motion == 'Divergence'):
						boundaries_from_dictionary.append(tuple[1])
						boundaries_from_dictionary.append(tuple[2])
						boundaries_from_dictionary.append(tuple[3])
						boundaries_from_dictionary.append(tuple[4])
						boundaries_from_dictionary.append(tuple[5])
						#for final output list of boundaries
						begin_valid_time,end_valid_time = tuple[1].get_valid_time()
						if (end_valid_time <= reconstruction_time):
							clone_1 = tuple[1].clone()
							clone_2 = tuple[2].clone()
							clone_3 = tuple[3].clone()
							clone_4 = tuple[4].clone()
							clone_5 = tuple[5].clone()
							clone_1.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_2.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_3.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_4.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_5.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							list_of_tectonic_boundaries.append(clone_1)
							list_of_tectonic_boundaries.append(clone_2)
							list_of_tectonic_boundaries.append(clone_3)
							list_of_tectonic_boundaries.append(clone_4)
							list_of_tectonic_boundaries.append(clone_5)
					else:
						boundaries_from_dictionary.append(tuple[1])
						boundaries_from_dictionary.append(tuple[2])
			
						#for final output list of boundaries
						begin_valid_time,end_valid_time = tuple[1].get_valid_time()
						if (end_valid_time <= reconstruction_time):

							clone_1 = tuple[1].clone()
							clone_2 = tuple[2].clone()
							clone_1.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							clone_2.set_valid_time(begin_valid_time,reconstruction_time - (interval*1.00))
							list_of_tectonic_boundaries.append(clone_1)
							list_of_tectonic_boundaries.append(clone_2)
				
				outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_tectonic_boundaries)
				outputLinesFile = "tectonic_boundaries_features_"+modelname+"_"+str(last_output_csv_files)+"_"+str(reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".gpml"
				outputLinesFeatureCollection.write(outputLinesFile)

				#clear everything
				boundaries_from_dictionary[:] = []
				list_of_tectonic_boundaries[:] = []

				
				#update last_output_csv_files
				last_output_csv_files = reconstruction_time
			elif (abs(last_output_csv_files - reconstruction_time)/interval < freq_writing_csv_files and reconstruction_time == end_reconstruction_time):
				
				tuple_of_boundaries = list(dictionary_of_tectonic_boundaries.values())
				for tuple in tuple_of_boundaries:
					tectonic_motion = tuple[0]
					if (tectonic_motion == 'Divergence'):
						boundaries_from_dictionary.append(tuple[1])
						boundaries_from_dictionary.append(tuple[2])
						boundaries_from_dictionary.append(tuple[3])
						boundaries_from_dictionary.append(tuple[4])
						boundaries_from_dictionary.append(tuple[5])
						#for final output list of boundaries
						begin_valid_time,end_valid_time = tuple[1].get_valid_time()
						if (end_valid_time <= end_reconstruction_time):
							list_of_tectonic_boundaries.append(tuple[1])
							list_of_tectonic_boundaries.append(tuple[2])
							list_of_tectonic_boundaries.append(tuple[3])
							list_of_tectonic_boundaries.append(tuple[4])
							list_of_tectonic_boundaries.append(tuple[5])
					else:
						boundaries_from_dictionary.append(tuple[1])
						boundaries_from_dictionary.append(tuple[2])
			
						#for final output list of boundaries
						begin_valid_time,end_valid_time = tuple[1].get_valid_time()
						if (end_valid_time <= end_reconstruction_time):
							list_of_tectonic_boundaries.append(tuple[1])
							list_of_tectonic_boundaries.append(tuple[2])

				outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_tectonic_boundaries)
				outputLinesFile = "tectonic_boundaries_features_"+modelname+"_"+str(last_output_csv_files)+"_"+str(reconstruction_time)+"_"+str(interval)+"Ma_"+mmddyy+".gpml"
				outputLinesFeatureCollection.write(outputLinesFile)

				#clear everything
				boundaries_from_dictionary[:] = []
				list_of_tectonic_boundaries[:] = []

				
				#update last_output_csv_files
				last_output_csv_files = reconstruction_time
				
		#update reconstruction_time
		reconstruction_time = reconstruction_time - interval

	
