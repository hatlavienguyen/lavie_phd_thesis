from multiprocessing import Pool
from os import environ
from time import sleep
import pygplates
import create_remnant_of_previous_MOR as create_remnant


ncpus = int(environ['SLURM_CPUS_PER_TASK'])

#Merdith et al 2021
common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/supergdu_and_members_gdu_at_{time}_for_Merdith_et_al_EB2021_20230428.csv"
sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/final_supergdu_feats_995.0_0.0_Merdith_et_al_EB2021_20230428.shp"
sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/1000_0_rotfile_Merdith_et_al.rot"
rotation_model = pygplates.RotationModel(rotation_file)
temp_rift_point_features_file = r"rift_point_features_for_test_8_EB2022_20231020.shp"
temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
# temp_unwanted_rift_point_features_file = r"unwanted_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
# temp_unwanted_rift_point_features = pygplates.FeatureCollection(temp_unwanted_rift_point_features_file)
rift_point_features_records_csv = r"rift_point_features_records_for_test_8_EB2022_20231020.csv"
# plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_EB2022_20231023.shp"
# plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
conv_and_plate_boundary_zone_boundaries_file = r"all_conv_and_plate_bdn_zone_EB2021_from_test_8_div_test_12_conv_20240805.shp"
conv_and_plate_boundary_zone_boundaries = pygplates.FeatureCollection(conv_and_plate_boundary_zone_boundaries_file)
#modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
#modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
records_of_kin_line_feats_from_conv = r"pairs_of_kin_line_fts_from_conv_bdn_process_for_test_12_EB2022_20231023.csv"
records_of_kin_line_feats_from_div = r"pairs_of_kin_line_fts_from_div_bdn_process_for_test_8_EB2022_20231020.csv"

yearmonthday = "20240805"
reference = 0
time_interval = 5.00

#PalaeoPlatesendJan2023
# common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
# sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
# rotation_model = pygplates.RotationModel(rotation_file)

# #temp_rift_point_features_file = r"all_temp_rift_point_features_w_end_age_based_on_kinematic_records_from_2800.0_test_29_PalaeoPlatesendJan2023_fts_20240330.shp"
# #temp_rift_point_features_file = r"rift_point_features_from_unrelated_SGDU_for_test_2_PalaeoPlatesendJan2023_20240216.shp"
# #temp_rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_2800.0_test_29_PalaeoPlatesendJan2023_fts_20240226.shp"
# #temp_rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_2800.0_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240227.shp"
# #temp_rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_2800.0_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_20240229.shp"
# #temp_rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_2800.0_subseq_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240229.shp"
# #temp_rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_2800.0_subseq_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_20240229.shp"

# temp_rift_point_features_file = r"rift_point_features_for_test_30_short_conv_PalaeoPlatesJan2023_20231023.shp"
# temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)

# #temp_unwanted_rift_point_features_file = r"unwanted_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
# #temp_unwanted_rift_point_features = pygplates.FeatureCollection(temp_unwanted_rift_point_features_file)
# #modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
# #modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)

# records_of_kin_line_feats_from_conv = r"pairs_of_kin_line_fts_from_conv_bdn_process_for_test_30_short_conv_PalaeoPlatesJan2023_20231023.csv"
# records_of_kin_line_feats_from_div = r"pairs_of_kin_line_fts_from_div_bdn_process_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"

# rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
# #rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.csv"
# #rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.csv"
# #rift_point_features_records_csv = r"subseq_rift_point_features_records_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.csv"
# #rift_point_features_records_csv = r"subseq_rift_point_features_records_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.csv"

# rift_point_features_records_csv = r"edit_rift_point_features_records_for_test_30_short_conv_PalaeoPlatesJan2023_from_conv_process_20231023.csv"

# #rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_2_PalaeoPlatesendJan2023_20240216.csv"

# #plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
# #plate_boundary_zone_boundaries_file = r"all_plate_bdn_zone_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240301.shp"
# #plate_boundary_zone_boundaries_file = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)

# conv_and_plate_boundary_zone_boundaries_file = r"all_conv_margin_and_plate_bdn_zone_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240301.shp"
# conv_and_plate_boundary_zone_boundaries = pygplates.FeatureCollection(conv_and_plate_boundary_zone_boundaries_file)
# #oceanic_polygon_feats_file = r"modified_end_age_of_invalid_temporary_oceanic_crust_polygon_feats_max_div_age_2800.0_0.0_test_1_PalaeoPlatesendJan2023_20231212.shp"
# #oceanic_polygon_feats = pygplates.FeatureCollection(oceanic_polygon_feats_file)

# yearmonthday = "20240407"
# reference = 700
# time_interval = 5.00

def calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval):
	max_min_rec_time_list = []
	value = maximum_of_reconstruction_period
	while (value >= minimum_of_reconstruction_period):
		min_recon = value - reconstruction_interval
		max_min_rec_time_list.append((value,min_recon))
		value = min_recon
	return max_min_rec_time_list

def create_isochron_from_temp_rift_point_features_within_a_period(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	modelname = "v2_test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	#modelname = "test_29_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	#modelname = "test_3_unrelated_SGDU_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	#modelname = "test_4_unrelated_SGDU_ynger_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	
	#modelname = "test_30_conv_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.create_isochron_from_temp_rift_point_features(temp_rift_point_features, rift_point_features_records_csv, conv_and_plate_boundary_zone_boundaries, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

def create_isochron_from_temp_rift_point_features_within_a_period_from_conv(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	modelname = "test_30_conv_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.create_isochron_from_temp_rift_point_features_from_conv_process(temp_rift_point_features, rift_point_features_records_csv, conv_and_plate_boundary_zone_boundaries, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)


def create_isochron_from_temp_rift_point_features_within_a_period_for_each_interval(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	modelname = "test_1_additional_rift_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	common_filename_for_temp_rift_point_features = r"additional_rift_point_features_for_{max_age}_{min_age}_PalaeoPlatesendJan2023_fts_max_{max_age}_{min_age}_20240118.shp"
	filename_for_temp_rift_point_features = common_filename_for_temp_rift_point_features.format(max_age = str(max_reconstruction_time_for_start_div), min_age = str(min_reconstruction_time_for_start_div))
	temp_rift_point_features_for_interval = pygplates.FeatureCollection(filename_for_temp_rift_point_features)
	common_filename_for_temp_rift_point_records = r"additional_rift_point_features_records_for_{max_age}_{min_age}_PalaeoPlatesendJan2023_fts_max_{max_age}_{min_age}_20240118.csv"
	temp_rift_point_features_records_csv = common_filename_for_temp_rift_point_records.format(max_age = str(max_reconstruction_time_for_start_div), min_age = str(min_reconstruction_time_for_start_div))
	create_remnant.create_isochron_from_temp_rift_point_features(temp_rift_point_features_for_interval, temp_rift_point_features_records_csv, conv_and_plate_boundary_zone_boundaries, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

def find_pairs_of_superGDUs_for_RRR(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	modelname = "test_29_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.find_pairs_of_SGDUs_for_RRR(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday)

def find_unwanted_rift_point_name(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	modelname = "test_29_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.find_unwanted_temp_rift_point_features(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday)

def create_isochron_from_temp_unwanted_rift_point_features_within_a_period(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	modelname = "test_29_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.create_isochron_from_unwanted_temp_rift_point_features(temp_unwanted_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

def check_and_modify_end_age_of_rift_point_feats_based_on_kin_feat_records(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#"modelname = "test_29_PalaeoPlatesendJan2023_fts"
	modelname = "test_8_div_test_12_conv_EB2022_fts"
	create_remnant.modified_end_age_of_rift_point_features_based_on_kinematic_records(rift_point_features_records_csv,modified_rift_point_features,records_of_kin_line_feats_from_conv,records_of_kin_line_feats_from_div,max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div,time_interval,modelname,yearmonthday)

def check_and_modify_end_age_of_rift_point_feats_based_on_spatial_rlxn_with_polygon_features_interval(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_29_PalaeoPlatesendJan2023_fts"
	modelname = "test_2_additional_rift_with_sgdu_PalaeoPlatesendJan2023_fts_max_"
	#common_filename_for_temp_rift_point_features = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/tectonic_boundaries/modified_end_age_of_rift_point_features_based_on_spatial_rlx_with_continental_sgdu_{max_age}_{min_age}_test_1_additional_rift_PalaeoPlatesendJan2023_fts_max_{max_age}_{min_age}_20240120.shp"
	#filename_for_temp_rift_point_features = common_filename_for_temp_rift_point_features.format(max_age = str(max_reconstruction_time_for_start_div), min_age = str(min_reconstruction_time_for_start_div))
	
	filename_for_temp_rift_point_features = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/utility/modified_end_age_additional_rift_point_features_2_PalaeoPlatesendJan2023_fts_2800_0_20240207.shp"
	temp_rift_point_features_for_interval = pygplates.FeatureCollection(filename_for_temp_rift_point_features)
	
	create_remnant.modify_end_age_of_rift_point_features_based_on_spatial_rlx_with_polygon_fts_alone(temp_rift_point_features_for_interval, sgdu_features, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

def check_and_modify_end_age_of_rift_point_feats_based_on_spatial_rlxn_with_polygon_features(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_29_PalaeoPlatesendJan2023_fts"
	modelname = "test_2_additional_rift_with_sgdu_PalaeoPlatesendJan2023_fts_max_"
	filename_for_temp_rift_point_features = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/utility/modified_end_age_additional_rift_point_features_2_PalaeoPlatesendJan2023_fts_2800_0_20240207.shp"
	temp_rift_point_features_for_interval = pygplates.FeatureCollection(filename_for_temp_rift_point_features)
	create_remnant.modify_end_age_of_rift_point_features_based_on_spatial_rlx_with_polygon_fts_alone(temp_rift_point_features_for_interval, sgdu_features, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

if __name__ == '__main__':
	#PalaeoPlatesendJan2023
	maximum_of_reconstruction_period = 2800.00
	minimum_of_reconstruction_period = 200.00
	reconstruction_interval = 200.00
	max_min_rec_time_list = calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval)
	
	#EB2022
	maximum_of_reconstruction_period = 995.00
	minimum_of_reconstruction_period = 195.00
	reconstruction_interval = 200.00
	
	max_min_rec_time_list = calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval)
	
	#check_and_modify_end_age_of_rift_point_feats_based_on_spatial_rlxn_with_polygon_features(maximum_of_reconstruction_period,minimum_of_reconstruction_period)
	
	with Pool(ncpus) as pool:
		#find isochrons
		results = pool.starmap(create_isochron_from_temp_rift_point_features_within_a_period, max_min_rec_time_list)
		
		#find isochrons from conv process
		#results = pool.starmap(create_isochron_from_temp_rift_point_features_within_a_period_from_conv, max_min_rec_time_list)
		
		#find isochrons for each interval
		#results = pool.starmap(create_isochron_from_temp_rift_point_features_within_a_period_for_each_interval, max_min_rec_time_list)
		
		#find unwanted rift point names
		#results = pool.starmap(find_unwanted_rift_point_name, max_min_rec_time_list)
		
		#modify rift point features based on kin records 
		#results = pool.starmap(check_and_modify_end_age_of_rift_point_feats_based_on_kin_feat_records, max_min_rec_time_list)
		
		#find isochron for unwanted rift point features
		#results = pool.starmap(create_isochron_from_temp_unwanted_rift_point_features_within_a_period, max_min_rec_time_list)
		
		#find pairs of superGDUS for RRR
		#results = pool.starmap(find_pairs_of_superGDUs_for_RRR, max_min_rec_time_list)
		
		#check and modified end age of temporary rift point features based on spatial rlx with any polygon features
		#results = pool.starmap(check_and_modify_end_age_of_rift_point_feats_based_on_spatial_rlxn_with_polygon_features_interval, max_min_rec_time_list)
		
		print(results)
		
		
