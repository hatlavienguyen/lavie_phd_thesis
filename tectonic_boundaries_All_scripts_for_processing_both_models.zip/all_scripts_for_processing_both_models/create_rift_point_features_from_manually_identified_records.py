import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import numpy as np
import pandas as pd
import math

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				#print(polygon.get_area())
				
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def find_the_mid_of_two_PointOnSphere(p1,p2):
	"""
		p1 and p2: pygplates.PointOnSphere
		Return: a mid point between p1 and p2 in the datatype pygplates.PointOnSphere
		
		p1 and p2 can be expressed as (x,y,z) coordinates in pygplates. Thus, mid_point(x,y,z) = (x1+x2/2.0, y1+y2/2.0, z1+z2/2.0)
	"""
	x1,y1,z1 = p1.to_xyz()
	x2,y2,z2 = p2.to_xyz()
	mid_point_x = (x1+x2)/2.00
	mid_point_y = (y1+y2)/2.00
	mid_point_z = (z1+z2)/2.00
	
	vector = pygplates.Vector3D([mid_point_x, mid_point_y, mid_point_z])
	normalized_vector = vector.to_normalised()
	
	mid_point = pygplates.PointOnSphere(normalized_vector.to_xyz())
	return mid_point

def create_rift_point_feats_from_manually_identified_records(rift_point_features_records_csv, margin_features, maximum_reconstruction_time, minimum_reconstruction_time, rotation_model, reference, modelname, yearmonthday):
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter = ',', header = 0)
	selected_rift_history_df = None
	output_rift_point_features = pygplates.FeatureCollection()
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_lrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'lrepgduid'].unique()
		array_of_rrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'rrepgduid'].unique()
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),['rift_name','order','lpolylid','rpolylid','left_gdu','right_gdu']]
		sorted_rift_order_records = df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu.sort_values(by = 'order', ascending = False)
		
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		#NEW
		start_div = sorted_array_of_start_div[-1]
		
		valid_margin_features = [margin_ft for margin_ft in margin_features if margin_ft.is_valid_at_time(start_div)]
		for rift_name, order, lpolylid, rpolylid, left_gdu, right_gdu in sorted_rift_order_records.itertuples(index = False, name = None):
			#print('rift_name, order, lpolylid, rpolylid, left_gdu, right_gdu',rift_name, order, lpolylid, rpolylid, left_gdu, right_gdu)
			name_of_rift_point_ft = rift_name+'_'+str(order)
			pairs_of_gdus = str(left_gdu)+'_'+str(right_gdu)
			left_margin_ft, right_margin_ft = None, None
			for margin_ft in valid_margin_features:
				if (margin_ft.get_name() == lpolylid):
					left_margin_ft = margin_ft
				elif (margin_ft.get_name() == rpolylid):
					right_margin_ft = margin_ft
				if (left_margin_ft is not None and right_margin_ft is not None):
					break
			if (left_margin_ft is not None and right_margin_ft is not None):
				reconstructed_margin_features = []
				if (reference is not None):
					pygplates.reconstruct([left_margin_ft, right_margin_ft], rotation_model, reconstructed_margin_features, start_div, anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct([left_margin_ft, right_margin_ft], rotation_model, reconstructed_margin_features, start_div, group_with_feature = True)
				final_reconstructed_margin_feats = find_final_reconstructed_geometries(reconstructed_margin_features, pygplates.PolylineOnSphere)
				final_left_margin_ft, final_reconstructed_left_margin = final_reconstructed_margin_feats[0]
				final_right_margin_ft, final_reconstructed_right_margin = final_reconstructed_margin_feats[1]
				closest_rad_dist, pt_on_left_margin, pt_on_right_margin = pygplates.GeometryOnSphere.distance(final_reconstructed_left_margin, final_reconstructed_right_margin, return_closest_positions = True)
				approx_mid_point = find_the_mid_of_two_PointOnSphere(pt_on_left_margin, pt_on_right_margin)
				name = rift_name+'_'+str(order)
				rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, approx_mid_point, name = name, valid_time = (start_div,0.00))
				rift_point_ft.set_left_plate(left_gdu)
				rift_point_ft.set_right_plate(right_gdu)
				rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
				rift_point_ft.set_description(str(order))
				if (reference is None):
					pygplates.reverse_reconstruct(rift_point_ft,rotation_model,start_div)
				else:
					pygplates.reverse_reconstruct(rift_point_ft,rotation_model,start_div,reference)
				output_rift_point_features.add(rift_point_ft)
			else:
				print("Error:left_margin_ft is None or right_margin_ft is None ",left_margin_ft, right_margin_ft)
				print("rift_name, order, lpolylid, rpolylid, left_gdu, right_gdu ",rift_name, order, lpolylid, rpolylid, left_gdu, right_gdu)
	output_rift_point_features.write("rift_point_features_from_manually_identified_records_"+modelname+"_"+yearmonthday+".shp")

def main():
	rift_point_features_records_csv = r"manually_approx_rift_point_features.csv"
	margin_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_segment_POLYGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230921.shp"
	margin_features = pygplates.FeatureCollection(margin_features_file)
	maximum_reconstruction_time = 2800.00
	minimum_reconstruction_time = 0.00
	rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	reference = 700
	modelname = "PalaeoPlatesendJan2023"
	yearmonthday = "20240323"
	create_rift_point_feats_from_manually_identified_records(rift_point_features_records_csv, margin_features, maximum_reconstruction_time, minimum_reconstruction_time, rotation_model, reference, modelname, yearmonthday)

if __name__=='__main__':
	main()