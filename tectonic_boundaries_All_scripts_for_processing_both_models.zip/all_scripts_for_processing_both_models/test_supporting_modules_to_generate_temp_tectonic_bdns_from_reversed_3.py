import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted_2 as supporting
import supporting_modules_to_create_tectonic_boundaries_from_database_tables as supporting_create
import supporting_modules_to_find_the_closest_boundary_for_each_boundary as supporting_find_closest
def main():
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	polygon_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\PlatePolygons2016Continental.shp"
	polygon_features_collection = pygplates.FeatureCollection(polygon_features_file)
	centroid_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\centroid_features_for_line_features_20220426.shp"
	line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\examine_line_topology\final_CON_OCN_from_modifying_CON_OCN_line_features_PalaeoPlatesNov2021_20220408.gpml"
	#line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\examine_line_topology\ft_id_str_CON_OCN_line_features_11353_10533_10532_PalaeoPlatesNov2021_20220129.shp"
	print('line_features_file',line_features_file)
	line_features_collection = pygplates.FeatureCollection(line_features_file)
	super_gdu_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\superGDU\clean_up_final_SuperGDU_features_PalaeoPlatesNov2021_from_2000_20220120_20220126.gpml"
	super_gdu_features_collection = pygplates.FeatureCollection(super_gdu_features_file)
	begin_reconstruction_time = 210.00
	end_reconstruction_time = 0.00
	interval = 5.00
	field_name_for_lithosphere_type = "COTID"
	continental_type_symbol = 'C'
	threshold_distance_in_km = 1000.00
	reference = 700
	cos_value_for_transform = 0.0100
	threshold_overlap_len_in_km = 350.00
	modelname = "test_8_reversed_PalaeoPlatesNov2021"
	yearmonthday = "20220606"
	name_of_database_table_for_pairs_of_line_fts = 'pairs_of_line_features_at_each_time_reversed_2'
	name_of_database_table_for_tectonic_motion = 'rel_pos_vel_vector_motion_at_each_time_reversed_2'
	name_of_database_table_for_MOR = 'mor_location_fts_at_each_time_reversed_2'
	#supporting.identify_tectonic_motion_3_reverse(name_of_database_table_for_pairs_of_line_fts, name_of_database_table_for_tectonic_motion, name_of_database_table_for_MOR, rotation_model, line_features_collection, super_gdu_features_collection, cos_value_for_transform, threshold_overlap_len_in_km, begin_reconstruction_time, end_reconstruction_time, interval, reference, modelname,yearmonthday)
	#name_for_table_for_summary_closest_tectonic_boundary = 'closest_boundary_rel_pos_vel_vector_motion_at_each_time_reversed'
	#supporting_find_closest.find_the_closest_boundary_for_each_boundary_from_database_table_tectonic_motion(name_of_database_table_for_tectonic_motion, name_for_table_for_summary_closest_tectonic_boundary, line_features_collection, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time,interval, modelname, yearmonthday)
	#name_for_table_for_summary_tectonic_boundary = 'temp_tectonic_boundaries_from_rel_pos_vect_reversed'
	#supporting_create.create_plate_tectonic_boundaries_from_database_table_tectonic_motion(name_of_database_table_for_tectonic_motion, name_for_table_for_summary_tectonic_boundary, line_features_collection, begin_reconstruction_time, end_reconstruction_time, interval, modelname, yearmonthday)
	line_ft_1 = None
	line_ft_2 = None
	for line_ft in line_features_collection:
		if (line_ft.get_name() == 'GPlates-39226891-881e-45a0-b2fb-56a62f948ccf'):
			line_ft_1 = line_ft 
		elif (line_ft.get_name() == 'GPlates-17051444-08ff-4478-a12a-48aa92582b87'):
			line_ft_2 = line_ft
	line_features_collection
	reconstruction_time = 15.00
	E_pole = pygplates.PointOnSphere((59.53,-38.03))
	smallest_circle_angular_radius_degrees = 101.00
	supporting.test_is_any_SuperGDU_btw_a_pair_of_line_features(line_ft_1,line_ft_2,rotation_model,reference,reconstruction_time,E_pole,smallest_circle_angular_radius_degrees,super_gdu_features_collection)

if __name__=='__main__':
	main()
