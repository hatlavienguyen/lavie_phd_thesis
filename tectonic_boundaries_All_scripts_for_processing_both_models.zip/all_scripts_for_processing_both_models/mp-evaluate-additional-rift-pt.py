from multiprocessing import Pool
from os import environ
from time import sleep
import pygplates
import create_remnant_of_previous_MOR as create_remnant
import identify_kinematic_boundaries as identify_kin


ncpus = int(environ['SLURM_CPUS_PER_TASK'])

#Merdith et al 2021
# common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/supergdu_and_members_gdu_at_{time}_for_Merdith_et_al_EB2021_20230428.csv"
# sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/final_supergdu_feats_995.0_0.0_Merdith_et_al_EB2021_20230428.shp"
# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/1000_0_rotfile_Merdith_et_al.rot"
# rotation_model = pygplates.RotationModel(rotation_file)
# temp_rift_point_features_file = r"rift_point_features_for_test_8_EB2022_20231020.shp"
# temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
# temp_unwanted_rift_point_features_file = r"unwanted_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
# temp_unwanted_rift_point_features = pygplates.FeatureCollection(temp_unwanted_rift_point_features_file)
# rift_point_features_records_csv = r"rift_point_features_records_for_test_8_EB2022_20231020.csv"
# plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_EB2022_20231023.shp"
# plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
# yearmonthday = "20231029"
# reference = 0
# time_interval = 5.00

#PalaeoPlatesendJan2023
common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)
gdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
gdu_features_collection = pygplates.FeatureCollection(gdu_features_file)
#temp_rift_point_features_file = r"rift_point_features_for_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
#temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
temp_additional_rift_point_features_file = r"modified_end_age_for_additional_rift_point_features_for_2800.0_0.0_PalaeoPlatesendJan2023_20231218.shp"
temp_additional_rift_point_features = pygplates.FeatureCollection(temp_additional_rift_point_features_file)
#temp_unwanted_rift_point_features_file = r"unwanted_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
#temp_unwanted_rift_point_features = pygplates.FeatureCollection(temp_unwanted_rift_point_features_file)
#modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
#modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
records_of_kin_line_feats_from_conv = r"pairs_of_kin_line_fts_from_conv_bdn_process_for_test_30_short_conv_PalaeoPlatesJan2023_20231023.csv"
records_of_kin_line_feats_from_div = r"pairs_of_kin_line_fts_from_div_bdn_process_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
temp_line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_valid_single_line_fts_All_PalaeoPlatesJan2023_20230628.shp"
temp_line_features_collection = pygplates.FeatureCollection(temp_line_features_file)

#plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
yearmonthday = "20240118"
reference = 700
time_interval = 5.00
common_filename_for_temporary_rift_point_features = r"rift_point_features_for_{max_age}_{min_age}_PalaeoPlatesendJan2023_20231218.shp"
common_filename_for_rift_point_features_csv = r"rift_point_features_records_for_{max_age}_{min_age}_PalaeoPlatesendJan2023_20231218.csv"

def calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval):
	max_min_rec_time_list = []
	value = maximum_of_reconstruction_period
	while (value >= minimum_of_reconstruction_period):
		min_recon = value - reconstruction_interval
		max_min_rec_time_list.append((value,min_recon))
		value = min_recon
	return max_min_rec_time_list

def create_isochron_from_temp_rift_point_features_within_a_period(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	modelname = "add_rift_pt_test_29_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	#"rift_point_features_for_600.0_400.0_PalaeoPlatesendJan2023_20231218"
	temp_rift_point_features_file = common_filename_for_temporary_rift_point_features.format(max_age = str(max_reconstruction_time_for_start_div), min_age = str(min_reconstruction_time_for_start_div))
	temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
	rift_point_features_records_csv = common_filename_for_rift_point_features_csv.format(max_age = str(max_reconstruction_time_for_start_div), min_age = str(min_reconstruction_time_for_start_div))
	create_remnant.create_isochron_from_temp_rift_point_features(temp_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

def find_pairs_of_superGDUs_for_RRR(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	modelname = "test_29_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.find_pairs_of_SGDUs_for_RRR(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday)

def find_unwanted_rift_point_name(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	modelname = "test_29_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.find_unwanted_temp_rift_point_features(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday)

def create_isochron_from_temp_unwanted_rift_point_features_within_a_period(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	#modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	modelname = "test_29_PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.create_isochron_from_unwanted_temp_rift_point_features(temp_unwanted_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

def check_and_modify_end_age_of_rift_point_feats_based_on_spatial_rlxn_with_continental_sgdu(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	modelname = "test_29_PalaeoPlatesendJan2023_fts"
	create_remnant. modify_end_age_of_rift_point_features_based_on_spatial_rlx_with_continental_sgdu_alone(temp_additional_rift_point_features, sgdu_features, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

def check_and_modify_end_age_of_rift_point_feats_based_on_kin_feat_records(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	modelname = "test_29_PalaeoPlatesendJan2023_fts"
	create_remnant.modified_end_age_of_rift_point_features_based_on_kinematic_records(rift_point_features_records_csv,modified_rift_point_features,records_of_kin_line_feats_from_conv,records_of_kin_line_feats_from_div,max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div,time_interval,modelname,yearmonthday)

def find_additional_rift_points_based_on_prev_rift_points(max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div):
	threshold_diff_small_circle = 0.500
	modelname = "PalaeoPlatesendJan2023_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	identify_kin.find_additional_rift_point_features_from_initial_rift_point_features(threshold_diff_small_circle, rift_point_features_records_csv, temp_line_features_collection, sgdu_features, gdu_features_collection, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

if __name__ == '__main__':
	maximum_of_reconstruction_period = 2800.00
	minimum_of_reconstruction_period = 0.00
	reconstruction_interval = 200.00
	max_min_rec_time_list = calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period, minimum_of_reconstruction_period, reconstruction_interval)

	with Pool(ncpus) as pool:
		#find isochrons
		#results = pool.starmap(create_isochron_from_temp_rift_point_features_within_a_period, max_min_rec_time_list)
		
		#find unwanted rift point names
		#results = pool.starmap(find_unwanted_rift_point_name, max_min_rec_time_list)
		
		#modify rift point features based on kin records 
		#results = pool.starmap(check_and_modify_end_age_of_rift_point_feats_based_on_kin_feat_records, max_min_rec_time_list)
		
		#find isochron for unwanted rift point features
		#results = pool.starmap(create_isochron_from_temp_unwanted_rift_point_features_within_a_period, max_min_rec_time_list)
		
		#find pairs of superGDUS for RRR
		#results = pool.starmap(find_pairs_of_superGDUs_for_RRR, max_min_rec_time_list)
		
		#check_and_modify_end_age_of_rift_point_feats_based_on_spatial_rlxn_with_continental_sgdu
		#results = pool.starmap(check_and_modify_end_age_of_rift_point_feats_based_on_spatial_rlxn_with_continental_sgdu, max_min_rec_time_list)
		#print(results)
		
		#find_additional_rift_points_based_on_prev_rift_points
		results = pool.starmap(find_additional_rift_points_based_on_prev_rift_points, max_min_rec_time_list)
		print(results)
