import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import numpy as np
import pandas as pd
import math
import create_topological_isochron_and_estimate_MOR as create_topological

def main():
	#rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	#rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	#rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.csv"
	#rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.csv"
	#rift_point_features_records_csv = r"rift_point_features_records_from_unrelated_SGDU_for_test_4_PalaeoPlatesendJan2023_ynger_20240226.csv"
	rift_point_features_records_csv = r"manually_approx_rift_point_features.csv"
	#rift_point_features_records_csv = r"subseq_rift_point_features_records_from_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240226.csv"
	#div_margin_feats_file = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\all_div_margin_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240304.shp"
	#div_margin_features = pygplates.FeatureCollection(div_margin_feats_file)
	
	#margin_feats_file = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\all_div_margin_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240304.shp"
	#margin_features = pygplates.FeatureCollection(div_margin_feats_file)
	
	#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kin_records_and_sgdu_2800.0_v3_test_29_PalaeoPlatesendJan2023_fts_20240407.shp"
	#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_and_sgdu_2800.0_test_3_unrelated_SGDU_PalaeoPlatesendJan2023_fts_20240305.shp"
	#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_and_sgdu_2800.0_test_4_unrelated_SGDU_ynger_PalaeoPlatesendJan2023_fts_20240305.shp"
	#rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_kinematic_records_2800.0_subseq_unrelated_SGDU_for_test_3_PalaeoPlatesendJan2023_20240229.shp"
	rift_point_features_file = r"modified_end_age_of_rift_point_features_based_on_sgdu_test_1_manually_identified_rift_pt_PalaeoPlatesendJan2023_fts_20240323.shp"
	modified_rift_point_features = pygplates.FeatureCollection(rift_point_features_file)
	modelname = "test_1_manually_identified_rift_PalaeoPlatesendJan2023_fts"
	
	yearmonthday = "20240410"
	reference = 700
	
	maximum_reconstruction_time = 2800.00
	minimum_reconstruction_time = 0.00
	age_interval_for_isochron_fts = 5.00
	
	create_topological.create_topological_rift_zones(modified_rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, modelname, yearmonthday)
	#create_topological.create_topological_MOR_to_represent_each_div_margin(div_margin_features, modified_rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, modelname, yearmonthday)

if __name__=='__main__':
	main()