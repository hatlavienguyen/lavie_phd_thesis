from multiprocessing import Pool
from os import environ
from time import sleep
import pygplates
import create_remnant_of_previous_MOR as create_remnant


ncpus = int(environ['SLURM_CPUS_PER_TASK'])

common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/supergdu_and_members_gdu_at_{time}_for_Merdith_et_al_EB2021_20230428.csv"
sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/superGDU/final_supergdu_feats_995.0_0.0_Merdith_et_al_EB2021_20230428.shp"
sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/EB2022/1000_0_rotfile_Merdith_et_al.rot"
rotation_model = pygplates.RotationModel(rotation_file)
temp_rift_point_features_file = r"rift_point_features_for_test_8_EB2022_20231020.shp"
temp_rift_point_features = pygplates.FeatureCollection(temp_rift_point_features_file)
rift_point_features_records_csv = r"rift_point_features_records_for_test_8_EB2022_20231020.csv"
plate_boundary_zone_boundaries_file = "plate_boundary_zone_features_for_EB2022_20231023.shp"
plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
yearmonthday = "20231029"
reference = 0
time_interval = 5.00


def calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval):
	max_min_rec_time_list = []
	value = maximum_of_reconstruction_period
	while (value >= minimum_of_reconstruction_period):
		min_recon = value - reconstruction_interval
		max_min_rec_time_list.append((value,min_recon))
		value = min_recon
	return max_min_rec_time_list

def create_isochron_from_temp_rift_point_features_within_a_period(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.create_isochron_from_temp_rift_point_features(temp_rift_point_features, rift_point_features_records_csv, plate_boundary_zone_boundaries, sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, time_interval, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, rotation_model, reference, modelname, yearmonthday)

def find_pairs_of_superGDUs_for_RRR(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.find_pairs_of_SGDUs_for_RRR(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday)

def find_unwanted_rift_point_name(max_reconstruction_time_for_start_div,min_reconstruction_time_for_start_div):
	modelname = "test_8_EB2022_fts_max_"+str(max_reconstruction_time_for_start_div)+"_"+str(min_reconstruction_time_for_start_div)
	create_remnant.find_unwanted_temp_rift_point_features(rift_point_features_records_csv, max_reconstruction_time_for_start_div, min_reconstruction_time_for_start_div, modelname, yearmonthday)
	
if __name__ == '__main__':
	maximum_of_reconstruction_period = 195.00
	minimum_of_reconstruction_period = 0.00
	reconstruction_interval = 195.00
	max_min_rec_time_list = calculate_values_for_max_min_reconstruction_time_tuples(maximum_of_reconstruction_period,minimum_of_reconstruction_period,reconstruction_interval)

	with Pool(ncpus) as pool:
		#find isochrons
		#results = pool.starmap(create_isochron_from_temp_rift_point_features_within_a_period, max_min_rec_time_list)
		#find unwanted rift point names
		results = pool.starmap(find_unwanted_rift_point_name, max_min_rec_time_list)
		#find pairs of superGDUS for RRR
		#results = pool.starmap(find_pairs_of_superGDUs_for_RRR, max_min_rec_time_list)
		print(results)
