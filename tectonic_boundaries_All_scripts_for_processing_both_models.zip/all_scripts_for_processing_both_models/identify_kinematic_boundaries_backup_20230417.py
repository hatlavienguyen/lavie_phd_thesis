#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
#import supporting_topological_modules as tm
#import supporting_topological_modules_for_MOR as MOR_topology
import rotation_utility

#A function to calculate the distance between two points on the sphere - specifically the Earth 
#I could have used haversine module for python, but for the purpose of practise, I do it myself
#According to the formula from https://www.igismap.com/haversine-formula-calculate-geographic-distance-earth/, 
#a = sin^2(Difference in latitudes/2)+cos(lat1)*cos(lat2)*sin^2(Difference in longitude/2)
#c = 2*atan2(sqrt(a),sqrt(1-a))
#d = Radius of the sphere * c
def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def convert_Point_in_Shapely_to_PointOnSphere_in_pygplates(point):
	'''point has coordinate as longitude and latitude'''
	longitude = point.x
	latitude = point.y
	point_on_sphere = pygplates.PointOnSphere(latitude,longitude)
	return point_on_sphere

def convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(line):
	'''each data point of the line has coordinate as longitude and latitude'''
	if (line.length > 0.00):
		try:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.coords]
		except NotImplementedError as error:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.exterior.coords]
		line_on_sphere = pygplates.PolylineOnSphere(list_of_lat_lon_vertices)
		if (line_on_sphere is None):
			print ("Error to convert convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
			print ("Here is a list_of_lat_lon_vertices")
			print (list_of_lat_lon_vertices)
			print (list_of_lat_lon_vertices)
			exit()
		return line_on_sphere
	else:
		print ("Error in convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
		print ("line.length == 0")
		print ("here are coords for line:")
		print((line.coords))
		print ("here is line")
		print (line)
		exit()

def convert_Polygon_in_Shapely_to_PolygonOnSphere_in_pygplates(each_polygon):
	'''each data point of each_polygon has a coordinate as longitude and latitude'''
	if (each_polygon.area > 0.00):
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			#print("lat,lon")
			#print(lat,lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
				print("Warning invalid value of latitude or/and longitude")
				print("value of latitude")
				print(lat)
				print("value of longitude")
				print(lon)
				if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
					if (abs(abs(lat) - 90.00) < 0.500):
						if (lat < -90.00):
							lat = -90.000
						elif (lat > 90.00):
							lat = 90.000
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of latitude")
						print("value of latitude")
						print(lat)					
						exit()
				if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
					if (abs(abs(lon) - 180.00) < 0.500):
						if (lon < -180.00):
							lon = -180.00
						elif (lon > 180.00):
							lon = 180.00
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of longitude")
						print("value of longitude")
						print(lon)					
						exit()
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print("Error in creating polygon in pygplates in conversion module")
			print("Here is a list of lat_lon vertices")
			print(list_of_lat_lon_vertices)
			print("Here is the first vertex and the last vertex:")
			print(list_of_lat_lon_vertices[0])
			print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
			exit()
		return new_polygon
	else:
		print("Error in creating polygon in pygplates in conversion module")
		print("Error each_polygon.area <= 0.00")
		print("here is each_polygon")
		print(each_polygon)
		print([(lon,lat) for lon,lat in each_polygon.exterior.coords])
		exit()

def convert_PolygonOnSphere_to_Polygon_in_Shapely(polygon_on_sphere):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in polygon_on_sphere.to_lat_lon_list()]
	new_polygon = Polygon(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating Polygon in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_polygon

def convert_PolylineOnSphere_to_LineString_in_Shapely(polyline_on_sphere):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in polyline_on_sphere.to_lat_lon_list()]
	new_linestring = LineString(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating LineString in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_linestring

def convert_PointOnSphere_to_Point_in_Shapely(point_on_sphere):
	lat,lon = point_on_sphere.to_lat_lon()
	new_point = Point(lon,lat)
	if (new_point is None):
		print("Error in creating Point in Shapely in conversion module")
		print("Here is a vertices")
		print(lat,lon)
		exit()
	return new_point

def project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(wgs84_geom, choosen_epsg_projection):
	'''wgs84_geom has a geometry data type defined in Shapely and coordinates with order longitude as x and latitude as y'''
	wgs84 = pyproj.CRS('EPSG:4326')
	projection = pyproj.CRS(choosen_epsg_projection)
	project = pyproj.Transformer.from_crs(wgs84, projection, always_xy = True).transform
	projected_geom = transform(project, wgs84_geom)
	return projected_geom

def project_any_Shapely_geometry_in_planar_projection_to_spherical_projection_wgs84_lon_lat(projected_geom, choosen_epsg_projection):
	wgs84 = pyproj.CRS('EPSG:4326')
	projection = pyproj.CRS(choosen_epsg_projection)
	project = pyproj.Transformer.from_crs(projection, wgs84, always_xy = True).transform
	wgs84_geom = transform(project,projected_geom)
	return wgs84_geom

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = mean(lat_values)
				mean_lon = mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries
	
def find_valid_con_ocn_line_features(line_features, common_filename_for_invalid_con_ocn_line_csv, reconstruction_time):
	#csv_filename = common_filename_for_invalid_con_ocn_line_csv.format(time = str(reconstruction_time))
	csv_filename= common_filename_for_invalid_con_ocn_line_csv
	#'reconstruction_time','LineID','OPOLYLID','POLYLID','GPLATE_FID'
	invalid_con_ocn_df = pd.read_csv(csv_filename, delimiter = ';', header = 0)
	valid_line_features = []
	for line_ft in line_features:
		polylid = line_ft.get_shapefile_attribute('POLYLID')
		opolylid = line_ft.get_shapefile_attribute('OPOLYLID')
		lineid = line_ft.get_shapefile_attribute('LineID')
		gplate_fid = line_ft.get_feature_id().get_string()
		result = invalid_con_ocn_df.loc[(invalid_con_ocn_df['POLYLID'] == polylid) & (invalid_con_ocn_df['OPOLYLID'] == opolylid) & (invalid_con_ocn_df['LineID'] == lineid) & (invalid_con_ocn_df['GPLATE_FID'] == gplate_fid)]
		if (result is not None):
			if (len(result) == 0):
				valid_line_features.append(line_ft)
		else:
			valid_line_features.append(line_ft)
	return valid_line_features

def find_gdu_features_associated_with_line_features(gdu_features, line_features):
	selected_gdu_features = {}
	for line_ft in line_features:
		polygid = line_ft.get_shapefile_attribute('POLYGID')
		if (polygid is not None):
			for gdu_ft in gdu_features:
				if (gdu_ft.get_shapefile_attribute('POLYGID') is not None and gdu_ft.get_shapefile_attribute('POLYGID') == polygid):
					if (polygid not in selected_gdu_features):
						selected_gdu_features[polygid] = [gdu_ft]
					else:
						list_of_gdu_fts = selected_gdu_features[polygid]
						found_duplicated = False
						for prev_ft in list_of_gdu_fts:
							prev_geometries = prev_ft.get_geometries()
							current_geometries = gdu_ft.get_geometries()
							for prev_geom in prev_geometries:
								for current_geom in current_geometries:
									if (prev_geom == current_geom):
										found_duplicated = True
										break
								if (found_duplicated == True):
									break
							if (found_duplicated == True):
								break
						if (found_duplicated == False):
							selected_gdu_features[polygid].append(gdu_ft)
	return selected_gdu_features

def find_gdu_members_of_each_sgdu_feat(gdu_features, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv,reconstruction_time):
	list_of_distinct_gdu_ids = []
	dict_of_sgdu_and_members_ids = {}
	# for gdu_ft in gdu_features:
		# if (gdu_ft.get_reconstruction_plate_id() not in list_of_distinct_gdu_ids):
			# list_of_distinct_gdu_ids.append(gdu_ft.get_reconstruction_plate_id())
		# if (gdu_ft.get_reconstruction_plate_id() == 11732):
			# print('found gdu fts with gdu id')
			# print(gdu_ft.get_reconstruction_plate_id() in list_of_distinct_gdu_ids)
	# array_of_distinct_gdu_ids = np.array(list_of_distinct_gdu_ids)
	for sgdu_ft in sgdu_features:
		sgdu_id = sgdu_ft.get_name()
		rep_gdu_id = sgdu_ft.get_reconstruction_plate_id()
		list_of_associated_gdu_members = None
		if (sgdu_id not in dict_of_sgdu_and_members_ids):
			temp_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temp_df = pd.read_csv(temp_sgdu_and_members_csv, delimiter = ';', header = 0)
			
			unique_sgdus = temp_df.loc[(temp_df['repGDUID'] == rep_gdu_id),'SGDUID'].unique()
			records_of_gdu_members = []
			for sgdu in unique_sgdus:
				temp_members = temp_df.loc[(temp_df['SGDUID'] == sgdu),'GDUID'].unique()
				for temp_mem in temp_members:
					if (temp_mem not in records_of_gdu_members):
						records_of_gdu_members.append(temp_mem)

			#records_of_gdu_members = temp_df.loc[(temp_df['repGDUID'] == rep_gdu_id)|(temp_df['GDUID'] == rep_gdu_id),'GDUID'].unique()
			# if (sgdu_id == '70290'):
				# print('records_of_gdu_members',records_of_gdu_members)
			#array_of_all_distinct_gdu_members = records_of_gdu_members
			#wanted_gdu_members = np.intersect1d(array_of_distinct_gdu_ids,array_of_all_distinct_gdu_members)
			
			wanted_gdu_members = records_of_gdu_members
			
			#if (sgdu_id == '70290'):
				# print('wanted_gdu_members',wanted_gdu_members)
				# print(array_of_distinct_gdu_ids)
				# print(array_of_all_distinct_gdu_members)
			if (len(wanted_gdu_members) > 0):
				list_of_wanted_gdu_fts = []
				for each_gdu_ft in gdu_features:
					if (each_gdu_ft.is_valid_at_time(reconstruction_time) and each_gdu_ft.get_reconstruction_plate_id() in wanted_gdu_members):
						list_of_wanted_gdu_fts.append(each_gdu_ft)
				if (len(list_of_wanted_gdu_fts) == 0):
					print("Error could not find any gdu features for SuperGDU feature",sgdu_id)
					print('records_of_gdu_members')
					print(records_of_gdu_members)
					pygplates.FeatureCollection(sgdu_ft).write('SGDU_feature_'+str(sgdu_id)+'_could_not_find_gdus.shp')
					# for each_gdu_ft in gdu_features:
						# if (each_gdu_ft.get_reconstruction_plate_id() == 19508):
							# print('each_gdu_ft.get_reconstruction_plate_id()',each_gdu_ft.get_reconstruction_plate_id())
							# print(each_gdu_ft.get_reconstruction_plate_id() in wanted_gdu_members)
					# exit()
				dict_of_sgdu_and_members_ids[sgdu_id] = list_of_wanted_gdu_fts
	return dict_of_sgdu_and_members_ids

def find_centroid_of_each_reconstructed_gdu_ft(final_reconstructed_gdu_features):
	dict_of_gdu_and_centroid = {}
	for recontructed_gdu_ft, polygon in final_reconstructed_gdu_features:
		gdu_id = recontructed_gdu_ft.get_reconstruction_plate_id()
		centroid = polygon.get_interior_centroid()
		polygid = recontructed_gdu_ft.get_shapefile_attribute('POLYGID')
		# if (str(gdu_id) not in dict_of_gdu_and_centroid):
			# dict_of_gdu_and_centroid[str(gdu_id)] = [(centroid,polygid)]
		# else:
			# dict_of_gdu_and_centroid[str(gdu_id)].append((centroid,polygid))
		
		if (polygid not in dict_of_gdu_and_centroid):
			dict_of_gdu_and_centroid[polygid] = [(centroid,polygid)]
		else:
			dict_of_gdu_and_centroid[polygid].append((centroid,polygid))
		
	return dict_of_gdu_and_centroid

def find_neighbours_of_each_reconstructed_gdu_ft(dict_of_gdu_and_centroid,threshold_distance_in_km_for_neighbour):
	dict_of_neighbours = {}
	# for str_gduid in dict_of_gdu_and_centroid:
		# tuples_of_centroid_and_polygid = dict_of_gdu_and_centroid[str_gduid]
		# for other_str_gduid in dict_of_gdu_and_centroid:
			# if (other_str_gduid != str_gduid):
				# tuples_of_other_centroid_and_polygid = dict_of_gdu_and_centroid[str_gduid]
				# for centroid_of_polygid, polygid in tuples_of_centroid_and_polygid:
					# lat1,lon1 = centroid_of_polygid.to_lat_lon()
					# for other_centroid, other_polygid in tuples_of_other_centroid_and_polygid:
						# lat2,lon2 = other_centroid.to_lat_lon()
						# if (calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2) <= threshold_distance_in_km_for_neighbour):
							# if (str_gduid not in dict_of_neighbours):
								# dict_of_neighbours[str_gduid] = [other_centroid]
							# else:
								# dict_of_neighbours[str_gduid].append(other_centroid)
	
	for polygid in dict_of_gdu_and_centroid:
		tuples_of_centroid_and_polygid = dict_of_gdu_and_centroid[polygid]
		for other_polygid in dict_of_gdu_and_centroid:
			if (other_polygid != polygid):
				tuples_of_other_centroid_and_polygid = dict_of_gdu_and_centroid[other_polygid]
				for centroid_of_polygid, _ in tuples_of_centroid_and_polygid:
					lat1,lon1 = centroid_of_polygid.to_lat_lon()
					for other_centroid, _ in tuples_of_other_centroid_and_polygid:
						lat2,lon2 = other_centroid.to_lat_lon()
						if (calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2) <= threshold_distance_in_km_for_neighbour):
							if (polygid not in dict_of_neighbours):
								#dict_of_neighbours[polygid] = [(other_centroid,other_polygid)]
								dict_of_neighbours[polygid] = [other_polygid]
							else:
								#dict_of_neighbours[polygid].append((other_centroid,other_polygid))
								dict_of_neighbours[polygid].append(other_polygid)
	
	return dict_of_neighbours

def find_magnitude_azimuth_inclination_from_a_ref_point_to_a_given_point(ref_point, given_point):
	'''ref_point and given_point have data type as PointOnSphere in pygplates'''
	if (ref_point == given_point):
		print('ref_point == given_point in find_azimuth_from_a_ref_point_to_a_given_point')
		return None
	elif (ref_point is None or given_point is None):
		print('ref_point is None or given_point is None')
		print('ref_point', ref_point, 'given_point', given_point)
		return None
	else:
		#local_cartesian = pygplates.LocalCartesian(ref_point)
		geocentric_vec = pygplates.Vector3D(given_point.to_xyz())
		mag,azi,inc = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(ref_point,geocentric_vec)
		return mag,azi,inc

def find_planar_vector_direction_from_a_ref_point_to_a_given_point(ref_point, given_point):
	'''ref_point and given_point have data type as Point in Shapely with planar projection coordinates xy'''
	vec_x = given_point.x - ref_point.x
	vec_y = given_point.y - ref_point.y
	return (vec_x,vec_y)

def calculate_dot_product_between_two_planar_vectors(tuple_vec1, tuple_vec2):
	#compute dot product
	x1,y1 = tuple_vec1
	x2,y2 = tuple_vec2
	dot_prod = (x1*x2)+(y1*y2)
	return dot_prod

def calculate_magnitude_of_a_planar_vector(tuple_vec1):
	x1,y1 = tuple_vec1
	magnitude_of_vec1 = math.sqrt((x1*x1)+(y1*y1))
	return magnitude_of_vec1

def calculate_angle_between_two_planar_vectors(tuple_vec1, tuple_vec2):
	#compute dot product
	dot_prod = calculate_dot_product_between_two_planar_vectors(tuple_vec1, tuple_vec2)
	#compute magnitude of each vector
	magnitude_of_vec1 = calculate_magnitude_of_a_planar_vector(tuple_vec1)
	magnitude_of_vec2 = calculate_magnitude_of_a_planar_vector(tuple_vec2)
	#cosine angle between two vectors
	cosine_angle_rads = dot_prod/(magnitude_of_vec1*magnitude_of_vec2)
	if (cosine_angle_rads < -1.00 or cosine_angle_rads > 1.00):
		print("cosine_angle_rads is out of the range -1.00 to 1.00")
		return None
	theta = math.acos(cosine_angle_rads)
	theta_degrees = math.degrees(theta)
	return theta_degrees

def examine_position_of_unknown_pt_relative_to_from_and_to_pts_in_planar_coordinates(from_point,to_point,unknown_point,maximum_accepted_angle_in_degrees):
	'''from_point, to_point and unknown_point have data type as Point in Shapely with planar projection coordinates xy'''
	ref_vec_direction = find_planar_vector_direction_from_a_ref_point_to_a_given_point(from_point,to_point)
	vec_direction_from_pt_to_unknown_pt = find_planar_vector_direction_from_a_ref_point_to_a_given_point(from_point,unknown_point)
	angle_between_two_planar_vectors = calculate_angle_between_two_planar_vectors(ref_vec_direction, vec_direction_from_pt_to_unknown_pt)
	if (angle_between_two_planar_vectors is None):
		return 'invalid'
	if (angle_between_two_planar_vectors <= maximum_accepted_angle_in_degrees):
		magnitude_of_ref_vec = calculate_magnitude_of_a_planar_vector(ref_vec_direction)
		magnitude_of_other_vec = calculate_magnitude_of_a_planar_vector(vec_direction_from_pt_to_unknown_pt)
		if (magnitude_of_other_vec <= magnitude_of_ref_vec):
			return 'between'
		else:
			return 'possibly_between'
	else:
		return 'outside'

def is_line_crossing_polygon(point_1, point_2, polygon, threshold_distance_in_km):
	"""point_1, point_2 and polygon have planar projected coordinates
	point_1 and point_2 have data type as Point and polygon has data type as Polygon in Shapely"""
	linestring = LineString([point_1,point_2])
	if (linestring.crosses(polygon) == True or linestring.within(polygon) == True):
		#find the portion of linestring intersecting Polygon and obtain its length
		portion = linestring.intersection(polygon)
		portion_in_meters = portion.length #length of the intersecting segment is in meters because often the planar map projection has unit in meters
		portion_in_km = portion_in_meters/1000.00
		if (portion_in_km >= threshold_distance_in_km):
			return True
		else:
			return False
	else:
		return False

def find_and_record_valid_sgdus_and_outer_gdu_members_at_each_reconstruction_time(rotation_model, gdu_features_collection, line_features_collection, super_gdu_features_collection, common_filename_for_temporary_sgdu_and_members_csv, common_filename_for_invalid_con_ocn_line_csv, sgdu_distance_csv, maximum_accepted_angle_in_degrees, threshold_distance_in_km, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, modelname,yearmonthday):
	#reconstruction_time,SGDU_1,SGDU_2,dist_km,lat1,lon1,lat2,lon2
	#sgdu_distance_df = pd.read_csv(sgdu_distance_csv,delimiter=';',header=0)
	reconstructed_sgdu_features = []
	reconstructed_gdu_features = []
	reconstructed_line_features = []
	valid_sgdu_features = []
	list_of_tuples_to_be_evaluated = []
	#output container
	output_list = []
	
	dict_of_sgdu_and_line_feats = None
	reconstruction_time = begin_reconstruction_time
	while (reconstruction_time >= end_reconstruction_time):
		print('reconstruction_time',reconstruction_time)
		valid_sgdu_features[:] = []
		reconstructed_sgdu_features[:] = []
		reconstructed_gdu_features[:] = []
		reconstructed_line_features[:] = []
		list_of_tuples_to_be_evaluated[:] = []
		#1) Find valid CON-OCN line features
		valid_line_features = None
		existing_line_features = [con_ocn_line_ft for con_ocn_line_ft in line_features_collection if con_ocn_line_ft.is_valid_at_time(reconstruction_time)]
		valid_line_features = find_valid_con_ocn_line_features(existing_line_features, common_filename_for_invalid_con_ocn_line_csv, reconstruction_time)
		#2) Reconstruct valid line features to reconstruction_time
		if (reference is not None):
			pygplates.reconstruct(valid_line_features, rotation_model, reconstructed_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_line_features, rotation_model, reconstructed_line_features, reconstruction_time, group_with_feature = True)
		#final_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_line_features, pygplates.PolylineOnSphere)
		#3) Select GDU features associated to valid con-ocn line features
		selected_gdu_features = None
		selected_gdu_features = find_gdu_features_associated_with_line_features(gdu_features_collection, valid_line_features)
		#4) Create temp_list_of_selected_gdu_fts to store selected gdu features and reconstruct them to reconstruction_time
		temp_list_of_selected_gdu_fts = []
		for polygid in selected_gdu_features:
			list_of_gdu_fts = selected_gdu_features[polygid]
			temp_list_of_selected_gdu_fts = temp_list_of_selected_gdu_fts+list_of_gdu_fts
		if (reference is not None):
			pygplates.reconstruct(temp_list_of_selected_gdu_fts, rotation_model, reconstructed_gdu_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(temp_list_of_selected_gdu_fts, rotation_model, reconstructed_gdu_features, reconstruction_time, group_with_feature = True)
		
		#debug
		feature_collection_of_selected_gdu_fts = pygplates.FeatureCollection(temp_list_of_selected_gdu_fts)
		feature_collection_of_selected_gdu_fts.write('selected_outer_gdu_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
		
		final_reconstructed_gdu_features = find_final_reconstructed_geometries(reconstructed_gdu_features, pygplates.PolygonOnSphere)
		#5) Find valid SuperGDU features at the reconstruction_time
		valid_sgdu_features = [sgdu_ft for sgdu_ft in super_gdu_features_collection if sgdu_ft.is_valid_at_time(reconstruction_time)]
		#6) Find gdu members of each valid_sgdu_features - make sure to avoid duplicated gdu member features
		dict_of_sgdu_and_members_ids = find_gdu_members_of_each_sgdu_feat(temp_list_of_selected_gdu_fts, valid_sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, reconstruction_time)
		#7) Find interior centroid of each reconstructed gdu
		dict_of_gdu_and_centroid = find_centroid_of_each_reconstructed_gdu_ft(final_reconstructed_gdu_features)
		
		#RECORDING 
		#the gdu members for each sgdu stored in the dictionary are ONLY gdu members along the BOUNDARIES of sgdus. 
		for random_sgdu_key in dict_of_sgdu_and_members_ids:
			temp_list_of_outer_gdu_members = dict_of_sgdu_and_members_ids[random_sgdu_key]
			for member in temp_list_of_outer_gdu_members:
				temp_list_of_centroids_and_polygids_for_member = dict_of_gdu_and_centroid[str(member)]
				for c,polygid in temp_list_of_centroids_and_polygids_for_member:
					reconstructed_lat,reconstructed_lon = c.to_lat_lon()
					output_list.append((reconstruction_time,int(random_sgdu_key),member,reconstructed_lat,reconstructed_lon,polygid))
		# #8) Find appropriate pairs of sgdus first based on the distance
		# #8i) Find appropriate pairs of sgdus
		# #reconstruction_time,SGDU_1,SGDU_2,dist_km,lat1,lon1,lat2,lon2
		# interested_sgdu_records = sgdu_distance_df.loc[(sgdu_distance_df['reconstruction_time'] == reconstruction_time) & (sgdu_distance_df['dist_km'] > 0.00) & (sgdu_distance_df['SGDU_1'] != sgdu_distance_df['SGDU_2']),['SGDU_1','SGDU_2','lat_1','lon_1','lat_2','lon_2']]
		# if (len(interested_sgdu_records) > 0):
			# appropriate_pairs_of_sgdus = []
			# for sgdu_1,sgdu_2,lat_1,lon_1,lat_2,lon_2 in interested_sgdu_records.values:
				# temp_pt_1 = pygplates.PointOnSphere((lat_1,lon_1))
				# temp_pt_2 = pygpaltes.PointOnSphere((lat_2,lon_2))
				# is_valid = True
				# try:
					# temp_great_circle_arc = pygplates.GreatCircleArc(temp_pt_1,temp_pt_2)
				# except (IndeterminateResultError):
					# is_valid = False
				# if (is_valid == True):
					# appropriate_pairs_of_sgdus.append((sgdu_1,sgdu_2))
			# #8ii)
			# temp_list_of_centroids_and_polygids = []
			# for random_gdu_key in dict_of_gdu_and_centroid:
				# temp_list_of_tuples = dict_of_gdu_and_centroid[random_gdu_key]
				# for random_centroid,random_polygid in temp_list_of_tuples:
					# temp_list_of_centroids_and_polygids.append((random_centroid,random_polygid))
			# for sgdu_1,sgdu_2 in appropriate_pairs_of_sgdus:
				# list_of_gdus_for_sgdu1 = dict_of_sgdu_and_members_ids[str(sgdu_1)]
				# list_of_gdus_for_sgdu2 = dict_of_sgdu_and_members_ids[str(sgdu_2)]
				# for gdu1 in list_of_gdus_for_sgdu1:
					# list_of_centroid_and_polygid_for_gdu1 = dict_of_gdu_and_centroid[str(gdu1)]
					# closest_distance = -1.00
					# for gdu2 in list_of_gdus_for_sgdu2:
						# list_of_centroid_and_polygid_for_gdu2 = dict_of_gdu_and_centroid[str(gdu2)]
						# for c1,polygid1 in list_of_centroid_and_polygid_for_gdu1:
							# shapely_point_1 = convert_PointOnSphere_to_Point_in_Shapely(c1)
							# projected_c1 = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(shapely_point_1, choosen_epsg_projection)
							# for c2,polygid2 in list_of_centroid_and_polygid_for_gdu2:
								# shapely_point_2 = convert_PointOnSphere_to_Point_in_Shapely(c2)
								# projected_c2 = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(shapely_point_2, choosen_epsg_projection)
								# mag,azi,inc = find_magnitude_azimuth_inclination_from_a_ref_point_to_a_given_point(projected_c1, projected_c2)
								# if (azi >= (math.pi/4.00) and azi <= (math.pi*3.00/4.00)):
									# for unknown_c,unknown_polygid in temp_list_of_centroids_and_polygids:
										# if (unknown_polygid != polygid1 and unknown_polygid != polygid2):
											# shapely_point_unknown = convert_PointOnSphere_to_Point_in_Shapely(unknown_c)
											# projected_unknown = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(shapely_point_unknown, choosen_epsg_projection)
											# result_of_examine_pos = examine_position_of_unknown_pt_relative_to_from_and_to_pts_in_planar_coordinates(projected_c1,projected_c2,projected_unknown,maximum_accepted_angle_in_degrees)
											# if (result_of_examine_pos != 'between'):
												# for reconstructed_gdu_ft,reconstructed_gdu_polygon in final_reconstructed_gdu_features:
													# shapely_polygon = convert_PolygonOnSphere_to_Polygon_in_Shapely(reconstructed_gdu_polygon)
													# projected_polygon = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(shapely_polygon, choosen_epsg_projection)
													# result_of_examine_crossing_polygon = is_line_crossing_polygon(projected_c1, projected_c2, projected_polygon, threshold_distance_in_km)
													# if (result_of_examine_crossing_polygon == False):
														# list_of_tuples_to_be_evaluated.append((c1,polygid1,projected_c1,c2,polygid2,projected_c2))
		#Write recording at every reconstruction time to avoid a singel huge dataset
		# if (len(output_list) > 0):
			# output_dataframe = pd.DataFrame.from_records(output_list, columns = ['reconstruction_time','SGDU','GDU','rec_lat','rec_lon','polygid'])
			# filename = modelname+'_sgu_and_outer_gdu_members_at_'+str(reconstruction_time)+'_'+yearmonthday+'.csv'
			# output_dataframe.to_csv(filename,index=False)
		# output_list[:] = []
		reconstruction_time = reconstruction_time - time_interval
	
	#Write all records at the end
	if (len(output_list) > 0):
		output_dataframe = pd.DataFrame.from_records(output_list, columns = ['reconstruction_time','SGDU','GDU','rec_lat','rec_lon','polygid'])
		filename = modelname+'_sgu_and_outer_gdu_members_from_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+yearmonthday+'.csv'
		output_dataframe.to_csv(filename,index=False)
		output_list[:] = []

def calculate_2D_velocity_of_two_given_points(shapely_from_time_point,shapely_to_time_point,time_interval):
	x_component = (shapely_to_time_point.x-shapely_from_time_point.x)/time_interval
	y_component = (shapely_to_time_point.y-shapely_from_time_point.y)/time_interval
	tuple_vel_vec = (x_component,y_component)
	return tuple_vel_vec

def evaluate_kinematics_between_two_2D_Shapely_pts(shapely_from_point,shapely_to_point,tuple_vel_vec_of_from_point,tuple_vel_vec_of_to_point,angle_window_for_transform):
	'''both shapely_from_point and shapely_to_point have the datatype as Point in Shapely
	kinematics is defined by the angle between the relative position vector and the relative velocity vector'''
	#calculate x and y components of the relative position vector 
	vec_x = shapely_to_point.x - shapely_from_point.x
	vec_y = shapely_to_point.y - shapely_from_point.y
	tuple_vec_pos = (vec_x,vec_y)
	#calculate relative velocity vector
	relative_vel_vector_x = tuple_vel_vec_of_to_point[0] - tuple_vel_vec_of_from_point[0]
	relative_vel_vector_y = tuple_vel_vec_of_to_point[1] - tuple_vel_vec_of_from_point[1]
	tuple_vec_vel = (relative_vel_vector_x,relative_vel_vector_y)
	theta = calculate_angle_between_two_planar_vectors(tuple_vec_pos, tuple_vec_vel)
	cutoff_value_of_angle_for_convergence = 90.00 - angle_window_for_transform
	cutoff_value_of_angle_for_divergence = 90.00 + angle_window_for_transform
	if (theta >= (90.00 - angle_window_for_transform) and theta <= (90.00 + angle_window_for_transform)):
		return 'Transform'
	elif (theta > cutoff_value_of_angle_for_divergence):
		if (cutoff_value_of_angle_for_divergence < 135.00):
			if (theta <= 180.00 and theta >= 135.00):
				return 'Divergence'
			else:
				return 'Oblique_divergence'
		else:
			if (theta <= 180.00 and theta >= cutoff_value_of_angle_for_divergence):
				return 'Divergence'
			else:
				return 'Oblique_divergence'
	elif (theta < (cutoff_value_of_angle_for_convergence)):
		if (cutoff_value_of_angle_for_convergence > 45.00):
			if (theta <= 45.00):
				return 'Convergence'
			else:
				return 'Oblique_convergence'
		else:
			if (theta <= cutoff_value_of_angle_for_convergence):
				return 'Convergence'
			else:
				return 'Oblique_convergence'

def find_the_mid_of_two_PointOnSphere(p1,p2):
	"""
		p1 and p2: pygplates.PointOnSphere
		Return: a mid point between p1 and p2 in the datatype pygplates.PointOnSphere
		
		p1 and p2 can be expressed as (x,y,z) coordinates in pygplates. Thus, mid_point(x,y,z) = (x1+x2/2.0, y1+y2/2.0, z1+z2/2.0)
	"""
	x1,y1,z1 = p1.to_xyz()
	x2,y2,z2 = p2.to_xyz()
	mid_point_x = (x1+x2)/2.00
	mid_point_y = (y1+y2)/2.00
	mid_point_z = (z1+z2)/2.00
	
	vector = pygplates.Vector3D([mid_point_x, mid_point_y, mid_point_z])
	normalized_vector = vector.to_normalised()
	
	mid_point = pygplates.PointOnSphere(normalized_vector.to_xyz())
	return mid_point

def identify_left_gdu_and_right_gdu(normal_unit_vector, rift_point_location, mid_point_line_1, mid_point_line_2, plate_id_1, plate_id_2):
	opposite_unit_vector = normal_unit_vector*(-1.00)
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z = mid_point_line_2.to_xyz()
	
	#identify left and right
	vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	vector_to_line_2 = pygplates.Vector3D([(mid_point_line_2_x-rift_point_location_x),(mid_point_line_2_y-rift_point_location_y),(mid_point_line_2_z-rift_point_location_z)])
	normalized_vector_to_line_2 = vector_to_line_2.to_normalised()
	
	left = None
	right = None 

	if (pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,opposite_unit_vector) > 0):
		left = plate_id_1
		right = plate_id_2
	elif (pygplates.Vector3D.dot(normalized_vector_to_line_1,opposite_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector) > 0):
		left = plate_id_2
		right = plate_id_1	
	else:
		print("Error in find_rift_segment_and_transform_faults")
		print("line_1 and line_2 are not located on two different sides relative to the mid_point")
		print("dot product of unit vectors for line_1")
		print(pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector))
		print("dot product of unit vectors for line_2")
		print(pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector))
		
		print ('rift_point_location')
		print(rift_point_location)
		
		print('mid_point_line_1')
		print(mid_point_line_1)
		
		print('mid_point_line_2')
		print(mid_point_line_2)
		
		print('plate_id_1')
		print(plate_id_1)
		print('plate_id_2')
		print(plate_id_2)
		exit()
	return (left,right)

def find_total_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,reconstruction_time,reference_frame):
	"""
	Total reconstruction is a reconstruction relative to the present (in time) and relative to any reference frame (spin axis or mantle or anything else)
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_divergent_line_features(rotation_model, sgdu_distance_csv, sgdu_history_csv, start_time_of_div_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, original_present_day_line_fts_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour, threshold_distance_in_km, yearmonthday, modelname):
	#original_present_day_line_fts_df = gpd.read_file(original_present_day_line_fts_shp)
	sgdu_distance_df = pd.read_csv(sgdu_distance_csv, delimiter=',', header = 0)
	#framework_dic = {'origin_lv':[],'SGDU':[],'parent':[],'from_time':[],'to_time':[],'repGDUID':[]}
	sgdu_history_df = pd.read_csv(sgdu_history_csv, delimiter=',', header = 0)
	#SGDU,start_div,repGDUID
	start_time_of_div_df = pd.read_csv(start_time_of_div_csv, delimiter = ',', header = 0)
	print('finished reading dataframe')
	dict_of_polygid_and_Shapely_centroid = {}
	dic_of_gdu_members_for_each_sgdu = {}
	previous_diverging_line_feats = []
	temp_list_of_centroids_and_polygids = []
	reconstructed_sgdu_features = []
	output_kinematics = []
	suspected_output = []
	appropriate_pairs_of_sgdus = []
	key_of_sgdus = []
	reconstructed_gdu_fts_for_sgdu1 = []
	reconstructed_gdu_fts_for_sgdu2 = []
	prev_reconstructed_gdu_fts_for_sgdu1 = []
	prev_reconstructed_gdu_fts_for_sgdu2 = []
	reconstructed_gdu_features = []
	reconstructed_gdu_features_ynger = []
	reconstructed_line_features = []
	reconstructed_line_features_ynger = []
	other_reconstructed_gdu_features = []
	output_rift_point_features = pygplates.FeatureCollection()
	output_diverging_line_features = pygplates.FeatureCollection()
	kin_line_feats_at_reconstruction_time = []
	dic_kin_line_feats = {}
	output_records_for_kin_feats = []
	if (end_reconstruction_time <= 0.00):
		end_reconstruction_time = time_interval #if end_reconstruction_time == 0.00 and time_interval is 5.00, then update the last time instant to be evaluate to be 5.00
	reconstruction_time = begin_reconstruction_time
	while(reconstruction_time >= end_reconstruction_time):
		#debug
		temporary_output_pair_div_line_fts = pygplates.FeatureCollection()
		
		print('reconstruction_time',reconstruction_time)
		dic_of_gdu_members_for_each_sgdu.clear()
		reconstructed_sgdu_features[:] = []
		reconstructed_gdu_features[:] = []
		reconstructed_line_features[:] = []
		other_reconstructed_gdu_features[:] = []
		# #8) Find appropriate pairs of sgdus first based on the distance
		# #8i) Find valid sgdu features
		valid_sgdu_features = [sgdu_ft for sgdu_ft in sgdu_features if (sgdu_ft.is_valid_at_time(reconstruction_time))]
		# #8ii) Reconstruct sgdu features to reconstruction time
		if (reference is not None):
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_sgdu_features = find_final_reconstructed_geometries(reconstructed_sgdu_features, pygplates.PolygonOnSphere)
		#Find valid gdu features with con-ocn line features
		valid_con_ocn_line_features = [con_ocn_ft for con_ocn_ft in line_features_collection if con_ocn_ft.is_valid_at_time(reconstruction_time)]
		if (reference is not None):
			pygplates.reconstruct(valid_con_ocn_line_features, rotation_model, reconstructed_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_con_ocn_line_features, rotation_model, reconstructed_line_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_line_features, pygplates.PolylineOnSphere)
		# #8i) Find valid gdu features at reconstruction_time 
		valid_in_time_gdu_features = [gdu_ft for gdu_ft in gdu_features_collection if (gdu_ft.is_valid_at_time(reconstruction_time))]
		valid_gdu_features = []
		already_included_gdu_fts = []
		for valid_line_ft,valid_line in final_reconstructed_line_features:
			#debug
			#if (valid_line_ft.get_reconstruction_plate_id() == 19508):
			#	print(valid_line_ft.get_reconstruction_plate_id())
			
			for gdu_ft in valid_in_time_gdu_features:
				if (valid_line_ft.get_shapefile_attribute('polygid') == gdu_ft.get_shapefile_attribute('POLYGID')):
					if (gdu_ft.get_feature_id() not in already_included_gdu_fts):
						valid_gdu_features.append(gdu_ft)
						already_included_gdu_fts.append(gdu_ft.get_feature_id())
				# else:
					# if (gdu_ft.get_reconstruction_plate_id() == valid_line_ft.get_reconstruction_plate_id()):
						# if (gdu_ft.get_feature_id() not in already_included_gdu_fts):
							# valid_gdu_features.append(gdu_ft)
							# already_included_gdu_fts.append(gdu_ft.get_feature_id())
		print('len(valid_gdu_features)',len(valid_gdu_features))
		print('len(valid_con_ocn_line_features)',len(valid_con_ocn_line_features))
						
		# #8ii) Reconstruct gdu features to reconstruction time
		if (reference is not None):
			pygplates.reconstruct(valid_gdu_features, rotation_model, reconstructed_gdu_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_gdu_features, rotation_model, reconstructed_gdu_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_gdu_features = find_final_reconstructed_geometries(reconstructed_gdu_features, pygplates.PolygonOnSphere)
		dict_of_gdu_and_centroid = find_centroid_of_each_reconstructed_gdu_ft(final_reconstructed_gdu_features)
		dict_of_neighbours = find_neighbours_of_each_reconstructed_gdu_ft(dict_of_gdu_and_centroid,threshold_distance_in_km_for_neighbour)
		dic_of_gdu_members_for_each_sgdu = find_gdu_members_of_each_sgdu_feat(valid_gdu_features, valid_sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, reconstruction_time)
		print('number of sgdu features in dic_of_gdu_members_for_each_sgdu',len(dic_of_gdu_members_for_each_sgdu))
		
		# #8i) Find valid gdu features at reconstruction_time - time_interval
		valid_in_time_gdu_features_in_ynger = [gdu_ft for gdu_ft in gdu_features_collection if (gdu_ft.is_valid_at_time(reconstruction_time-time_interval))]
		valid_gdu_features_ynger = []
		already_included_gdu_fts_ynger = []
		reconstructed_gdu_features_ynger[:] = []
		reconstructed_line_features_ynger[:] = []
		#Find valid gdu features with con-ocn line features
		valid_con_ocn_line_features_ynger = [con_ocn_ft for con_ocn_ft in line_features_collection if con_ocn_ft.is_valid_at_time(reconstruction_time-time_interval)]
		if (reference is not None):
			pygplates.reconstruct(valid_con_ocn_line_features_ynger, rotation_model, reconstructed_line_features_ynger, reconstruction_time-time_interval, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_con_ocn_line_features_ynger, rotation_model, reconstructed_line_features_ynger, reconstruction_time-time_interval, group_with_feature = True)
		final_reconstructed_line_features_ynger = find_final_reconstructed_geometries(reconstructed_line_features_ynger, pygplates.PolylineOnSphere)
		for valid_line_ft,valid_line in final_reconstructed_line_features_ynger:
			for gdu_ft in valid_in_time_gdu_features_in_ynger:
				if (valid_line_ft.get_shapefile_attribute('polygid') == gdu_ft.get_shapefile_attribute('POLYGID')):
					if (gdu_ft.get_feature_id() not in already_included_gdu_fts_ynger):
						valid_gdu_features_ynger.append(gdu_ft)
						already_included_gdu_fts_ynger.append(gdu_ft.get_feature_id())
				# else:
					# if (gdu_ft.get_reconstruction_plate_id() == valid_line_ft.get_reconstruction_plate_id()):
						# if (gdu_ft.get_feature_id() not in already_included_gdu_fts):
							# valid_gdu_features.append(gdu_ft)
							# already_included_gdu_fts.append(gdu_ft.get_feature_id())
		print('len(valid_gdu_features_ynger)',len(valid_gdu_features_ynger))
		print('len(valid_con_ocn_line_features_ynger)',len(valid_con_ocn_line_features_ynger))
		# #8ii) Reconstruct gdu features to reconstruction time
		if (reference is not None):
			pygplates.reconstruct(valid_gdu_features_ynger, rotation_model, reconstructed_gdu_features_ynger, reconstruction_time-time_interval, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_gdu_features_ynger, rotation_model, reconstructed_gdu_features_ynger, reconstruction_time-time_interval, group_with_feature = True)
		final_reconstructed_gdu_features_ynger = find_final_reconstructed_geometries(reconstructed_gdu_features_ynger, pygplates.PolygonOnSphere)
		valid_sgdu_features_ynger = [sgdu_ft for sgdu_ft in sgdu_features if (sgdu_ft.is_valid_at_time(reconstruction_time-time_interval))]
		dic_of_gdu_members_for_each_sgdu_ynger = find_gdu_members_of_each_sgdu_feat(valid_gdu_features_ynger, valid_sgdu_features_ynger, common_filename_for_temporary_sgdu_and_members_csv, reconstruction_time-time_interval)
		print('number of sgdu features in dic_of_gdu_members_for_each_sgdu_ynger',len(dic_of_gdu_members_for_each_sgdu_ynger))
		reconstructed_sgdu_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(valid_sgdu_features_ynger, rotation_model, reconstructed_sgdu_features, reconstruction_time-time_interval, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_sgdu_features_ynger, rotation_model, reconstructed_sgdu_features, reconstruction_time-time_interval, group_with_feature = True)
		final_reconstructed_sgdu_features_ynger = find_final_reconstructed_geometries(reconstructed_sgdu_features, pygplates.PolygonOnSphere)
		# temp_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
		# #;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
		# temp_df = pd.read_csv(temp_sgdu_and_members_csv, delimiter = ';', header = 0)
		
		# #8iii) Find appropriate pairs of sgdus
		#reconstruction_time,SGDU_1,SGDU_2,dist_km,lat1,lon1,lat2,lon2
		# interested_sgdu_records = sgdu_distance_df.loc[(sgdu_distance_df['reconstruction_time'] == reconstruction_time) & (sgdu_distance_df['dist_km'] > 0.00) & (sgdu_distance_df['dist_km'] <= threshold_distance_in_km_for_neighbour) & (sgdu_distance_df['SGDU_1'] != sgdu_distance_df['SGDU_2']),['SGDU_1','SGDU_2','lat1','lon1','lat2','lon2','dist_km']]
		# if (len(interested_sgdu_records) > 0):
			# print('number of interested_sgdu_records',len(interested_sgdu_records))
			# appropriate_pairs_of_sgdus[:] = []
			# key_of_sgdus[:] = []
			# for sgdu_1,sgdu_2,lat_1,lon_1,lat_2,lon_2,dist_km in interested_sgdu_records.values:
				# temp_pt_1 = pygplates.PointOnSphere((lat_1,lon_1))
				# temp_pt_2 = pygplates.PointOnSphere((lat_2,lon_2))
				# is_valid = True
				# try:
					# temp_great_circle_arc = pygplates.GreatCircleArc(temp_pt_1,temp_pt_2)
				# except (IndeterminateResultError):
					# is_valid = False
				# if (is_valid == True):
					# key = str(sgdu_1)+'_'+str(sgdu_2)
					# reversed_key = str(sgdu_2)+'_'+str(sgdu_1)
					# if (key not in key_of_sgdus and reversed_key not in key_of_sgdus):
						# shapely_point_1 = Point(lon_1,lat_1)
						# shapely_point_2 = Point(lon_2,lat_2)
						# projected_pt1 = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(shapely_point_1, choosen_epsg_projection)
						# projected_pt2 = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(shapely_point_2, choosen_epsg_projection)
						# valid = True
						# other_sgdu_records = sgdu_distance_df.loc[(sgdu_distance_df['reconstruction_time'] == reconstruction_time) & (sgdu_distance_df['dist_km'] > 0.00) & (sgdu_distance_df['dist_km'] <= dist_km) & (sgdu_distance_df['SGDU_1'] != sgdu_distance_df['SGDU_2']) & (((sgdu_distance_df['SGDU_1'] == sgdu_1) | (sgdu_distance_df['SGDU_2'] == sgdu_1)) | ((sgdu_distance_df['SGDU_1'] == sgdu_2) | (sgdu_distance_df['SGDU_2'] == sgdu_2))),['SGDU_1','SGDU_2','lat1','lon1','lat2','lon2','dist_km']]
						# for other_sgdu_1,other_sgdu_2,other_lat_1,other_lon_1,other_lat_2,other_lon_2,other_dist_km in other_sgdu_records.values:
							# if (other_sgdu_1 == sgdu_1 or other_sgdu_2 == sgdu_1):
								# if (other_sgdu_1 == sgdu_1 and other_sgdu_2 != sgdu_2):
									# projected_unknown = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(Point(other_lon_2,other_lat_2), choosen_epsg_projection)
									# result_of_examine_pos = examine_position_of_unknown_pt_relative_to_from_and_to_pts_in_planar_coordinates(projected_pt1,projected_pt2,projected_unknown,maximum_accepted_angle_in_degrees)
									# if (result_of_examine_pos == 'between' or result_of_examine_pos == 'invalid'):
										# valid = False
										# break
								# elif (other_sgdu_2 == sgdu_1 and other_sgdu_1 != sgdu_2):
									# projected_unknown = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(Point(other_lon_1,other_lat_1), choosen_epsg_projection)
									# result_of_examine_pos = examine_position_of_unknown_pt_relative_to_from_and_to_pts_in_planar_coordinates(projected_pt1,projected_pt2,projected_unknown,maximum_accepted_angle_in_degrees)
									# if (result_of_examine_pos == 'between' or result_of_examine_pos == 'invalid'):
										# valid = False
										# break
							# if (valid == False):
								# break
							# if (other_sgdu_1 == sgdu_2 or other_sgdu_2 == sgdu_2):
								# if (other_sgdu_1 == sgdu_2 and other_sgdu_2 != sgdu_1):
									# projected_unknown = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(Point(other_lon_2,other_lat_2), choosen_epsg_projection)
									# result_of_examine_pos = examine_position_of_unknown_pt_relative_to_from_and_to_pts_in_planar_coordinates(projected_pt2,projected_pt1,projected_unknown,maximum_accepted_angle_in_degrees)
									# if (result_of_examine_pos == 'between' or result_of_examine_pos == 'invalid'):
										# valid = False
										# break
								# elif (other_sgdu_2 == sgdu_2 and other_sgdu_1 != sgdu_1):
									# projected_unknown = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(Point(other_lon_1,other_lat_1), choosen_epsg_projection)
									# result_of_examine_pos = examine_position_of_unknown_pt_relative_to_from_and_to_pts_in_planar_coordinates(projected_pt2,projected_pt1,projected_unknown,maximum_accepted_angle_in_degrees)
									# if (result_of_examine_pos == 'between' or result_of_examine_pos == 'invalid'):
										# valid = False
										# break
						# if (valid == True):
							# key_of_sgdus.append(key)
							# appropriate_pairs_of_sgdus.append((sgdu_1,sgdu_2))
		
		# #8iii) Find appropriate pairs of sgdus
		#SGDU,start_div,repGDUID
		polygid_all_valid_line_features = [con_ocn_ft.get_shapefile_attribute('polygid') for con_ocn_ft in valid_con_ocn_line_features]
		array_of_all_valid_polygid = np.array(polygid_all_valid_line_features)
		print('array_of_all_valid_polygid',array_of_all_valid_polygid)
		already_evaluated_pairs_of_sgdus = []
		records_of_sgdus_diverging = start_time_of_div_df.loc[abs(start_time_of_div_df['start_div'] - reconstruction_time) <= 0.500, ['SGDU','repGDUID','start_div']]
		if (len(records_of_sgdus_diverging) > 0):
			for tuple_of_sgdu_repgdu in records_of_sgdus_diverging.itertuples(index = False, name = None):
				parent_div_sgdu, parent_repgduid, start_div = tuple_of_sgdu_repgdu
				#use sgdu history to find the sgdu children 
				children_sgdus = sgdu_history_df.loc[(sgdu_history_df['parent'] == parent_div_sgdu),['SGDU','repGDUID','from_time']]
				if (len(children_sgdus) >= 2):
					for child_1,child_repgduid_1,from_time_div in children_sgdus.itertuples(index = False, name = None):
						gdu_features_for_sgdu1 = dic_of_gdu_members_for_each_sgdu[str(child_1)]
						if (len(gdu_features_for_sgdu1) == 0):
							continue
						for child_2,child_repgduid_2,from_time_div in children_sgdus.itertuples(index = False, name = None):
							gdu_features_for_sgdu2 = dic_of_gdu_members_for_each_sgdu[str(child_2)]
							if (len(gdu_features_for_sgdu2) == 0):
								continue
							if (child_1 != child_2):
								key = str(child_1)+'_'+str(child_2)
								rev_key = str(child_2)+'_'+str(child_1)
								if (key not in already_evaluated_pairs_of_sgdus and rev_key not in already_evaluated_pairs_of_sgdus):
									already_evaluated_pairs_of_sgdus.append(key)
									#use the two repgduids from the two children 
									total_relative_reconstruction_rotation = find_total_relative_reconstruction_rotation_(rotation_model, child_repgduid_1, child_repgduid_2, float(from_time_div), reference)
									if (total_relative_reconstruction_rotation is not None):
										if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
											#check whether the pair of sgdus is valid
											child_sgud_1 = []
											child_sgud_2 = []
											non_related = []
											#for yng_sgdu_ft,yng_sgdu in final_reconstructed_sgdu_features_ynger:
											for yng_sgdu_ft,yng_sgdu in final_reconstructed_sgdu_features:
												if (yng_sgdu_ft.get_name() == str(child_1)):
													child_sgud_1.append(yng_sgdu)
												elif (yng_sgdu_ft.get_name() == str(child_2)):
													child_sgud_2.append(yng_sgdu)
												else:
													non_related.append(yng_sgdu)
											reconstructed_gdu_fts_for_sgdu1[:] = []
											reconstructed_gdu_fts_for_sgdu2[:] = []
											prev_reconstructed_gdu_fts_for_sgdu1[:] = []
											prev_reconstructed_gdu_fts_for_sgdu2[:] = []
											list_of_ordered_pairs_gdu_fts = []
											list_of_already_used_line_fts = []
											#gdu_features_for_sgdu1 = dic_of_gdu_members_for_each_sgdu[str(child_1)]
											#gdu_features_for_sgdu1_valid_at_prev_time = [current_gdu_ft_1 for current_gdu_ft_1 in gdu_features_for_sgdu1 if current_gdu_ft_1.is_valid_at_time(reconstruction_time + time_interval)]
											#gdu_features_for_sgdu2 = dic_of_gdu_members_for_each_sgdu[str(child_2)]
											#gdu_features_for_sgdu2_valid_at_prev_time = [current_gdu_ft_2 for current_gdu_ft_2 in gdu_features_for_sgdu2 if current_gdu_ft_2.is_valid_at_time(reconstruction_time + time_interval)]
											final_reconstructed_gdu_features_for_sgdu1 = []
											final_reconstructed_gdu_features_for_sgdu2 = []
											prev_final_reconstructed_gdu_features_for_sgdu1 = []
											prev_final_reconstructed_gdu_features_for_sgdu2 = []
											polygid_features_for_sgdu1 = [child_gdu_ft.get_shapefile_attribute('POLYGID') for child_gdu_ft in gdu_features_for_sgdu1]
											array_for_polygid_ft_sgdu1 = np.array(polygid_features_for_sgdu1)
											#polygid_features_for_sgdu1_at_prev_time = [child_gdu_ft.get_shapefile_attribute('POLYGID') for child_gdu_ft in gdu_features_for_sgdu1_valid_at_prev_time]
											wanted_gdu_members_for_sgdu1 = np.intersect1d(array_for_polygid_ft_sgdu1,array_of_all_valid_polygid)
											polygid_features_for_sgdu2 = [child_gdu_ft.get_shapefile_attribute('POLYGID') for child_gdu_ft in gdu_features_for_sgdu2]
											array_for_polygid_ft_sgdu2 = np.array(polygid_features_for_sgdu2)
											wanted_gdu_members_for_sgdu2 = np.intersect1d(array_for_polygid_ft_sgdu2,array_of_all_valid_polygid)
											#polygid_features_for_sgdu2_at_prev_time = [child_gdu_ft.get_shapefile_attribute('POLYGID') for child_gdu_ft in gdu_features_for_sgdu2_valid_at_prev_time]
											
											#CON-OCN line features that exit at the younger time (i.e. reconstruction_time - time_interval) and invalid at reconstruction_time
											#for child_gdu_ft_1, child_line_gdu_1 in final_reconstructed_line_features_ynger:
											for child_gdu_ft_1, child_line_gdu_1 in final_reconstructed_line_features:
												polygid_for_child_1 = child_gdu_ft_1.get_shapefile_attribute('polygid')
												#if ((polygid_for_child_1 in wanted_gdu_members_for_sgdu1) and (polygid_for_child_1 not in polygid_features_for_sgdu1_at_prev_time)):
												if (polygid_for_child_1 in wanted_gdu_members_for_sgdu1):
													reconstructed_gdu_fts_for_sgdu1.append((child_gdu_ft_1, child_line_gdu_1))
											#for child_gdu_ft_2, child_line_gdu_2 in final_reconstructed_line_features_ynger:
											for child_gdu_ft_2, child_line_gdu_2 in final_reconstructed_line_features:
												polygid_for_child_2 = child_gdu_ft_2.get_shapefile_attribute('polygid')
												#if ((polygid_for_child_2 in polygid_features_for_sgdu2) and (polygid_for_child_2 not in polygid_features_for_sgdu2_at_prev_time)):
												if (polygid_for_child_2 in wanted_gdu_members_for_sgdu2):
													reconstructed_gdu_fts_for_sgdu2.append((child_gdu_ft_2, child_line_gdu_2))
											print('len(reconstructed_gdu_fts_for_sgdu1)',len(reconstructed_gdu_fts_for_sgdu1))
											print('len(reconstructed_gdu_fts_for_sgdu2)',len(reconstructed_gdu_fts_for_sgdu2))
											
											#debug
											# if ((child_1 == 71261 and child_2 == 71252) or (child_2 == 71261 and child_1 == 71252)):
												# for gdu_line_ft_1, line_gdu_1 in reconstructed_gdu_fts_for_sgdu1:
													# temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
												# for gdu_line_ft_2, line_gdu_2 in reconstructed_gdu_fts_for_sgdu2:
													# temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
											
											E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
											smallest_circle_angular_radius_degrees = 178.00
											while (smallest_circle_angular_radius_degrees > 0.00):
												small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
												found_pair_of_line_feats = None
												valid_pair_of_line_fts = True
												for gdu_line_ft_1, line_gdu_1 in reconstructed_gdu_fts_for_sgdu1:
													polylid_of_gdu_line_ft_1 = gdu_line_ft_1.get_shapefile_attribute('polygid')
													list_of_neighbours_for_polylid_1 = dict_of_neighbours[polylid_of_gdu_line_ft_1]
													for gdu_line_ft_2, line_gdu_2 in reconstructed_gdu_fts_for_sgdu2:
														polylid_of_gdu_line_ft_2 = gdu_line_ft_2.get_shapefile_attribute('polygid')
														if (polylid_of_gdu_line_ft_2 not in list_of_neighbours_for_polylid_1):
															continue
														approx_rad_closest_dist_neighbour,closest_point_on_gdu1,_ = pygplates.GeometryOnSphere.distance(line_gdu_1, small_circle_boundary,return_closest_positions = True)
														approx_rad_closest_dist_ref,closest_point_on_gdu2,_= pygplates.GeometryOnSphere.distance(line_gdu_2, small_circle_boundary,return_closest_positions = True)
														
														# calculate distance by map projection
														# lat1,lon1 = closest_point_on_gdu1.to_lat_lon()
														# lat2,lon2 = closest_point_on_gdu2.to_lat_lon()
														# choosen_epsg_projection = 'ESRI:54009'
														# if (lat1 > 0.00 and lat2 > 0.00):
															# if (abs(lat1 - 90.00) <= 10.00 or abs(lat2 - 90.00) <= 10.00):
																# choosen_epsg_projection = 'EPSG:3995'
														# elif (lat1 < 0.00 and lat2 < 0.00):
															# if (abs(lat1 + 90.00) <= 10.00 or abs(lat2 + 90.00) <= 10.00):
																# choosen_epsg_projection = 'EPSG:3031'
														# wgs84_shapely_point_1 = convert_PointOnSphere_to_Point_in_Shapely(closest_point_on_gdu1)
														# projected_c1 = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(wgs84_shapely_point_1, choosen_epsg_projection)
														# wgs84_shapely_point_2 = convert_PointOnSphere_to_Point_in_Shapely(closest_point_on_gdu2)
														# projected_c2 = project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(wgs84_shapely_point_2, choosen_epsg_projection)
														# approx_distance_btw_lines_kms = projected_c1.distance(projected_c2)
														
														#calculate distance by haversine
														lat1,lon1 = closest_point_on_gdu1.to_lat_lon()
														lat2,lon2 = closest_point_on_gdu2.to_lat_lon()
														approx_distance_btw_lines_kms = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
														
														# #debug
														if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12009_13906_1773' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17300_14793_2185') or (gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12009_13906_1773' and gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17300_14793_2185')):
															gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
															gdu_line_ft_1.set_name(key)
															gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
															gdu_line_ft_2.set_name(key)
															#temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
															#temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
															print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
															print('approx_rad_closest_dist_neighbour',approx_rad_closest_dist_neighbour)
															print('approx_rad_closest_dist_ref',approx_rad_closest_dist_ref)
														#debug
														#if (parent_div_sgdu == 70591 and ((child_1 == 70638 and child_2 == 70637) or (child_1 == 70637 and child_2 == 70638))):
														#	print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
														
														#approx_distance_btw_lines_kms = approx_distance_btw_lines*pygplates.Earth.mean_radius_in_kms
														if (approx_rad_closest_dist_neighbour == 0.000 and approx_rad_closest_dist_ref == 0.000): 
															if ((approx_distance_btw_lines_kms <= 1000.00) or (gdu_line_ft_1.is_valid_at_time(reconstruction_time + time_interval)==False) or (gdu_line_ft_2.is_valid_at_time(reconstruction_time + time_interval)==False)):
																# # #debug
																#if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12009_13906_1773' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17300_14793_2185') or (gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12009_13906_1773' and gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17300_14793_2185')):
																	# gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																	# gdu_line_ft_1.set_name(key)
																	# gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																	# gdu_line_ft_2.set_name(key)
																	# temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
																	# temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
																	# print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
																if (found_pair_of_line_feats is None):
																	found_pair_of_line_feats = (gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2)
																	if (gdu_line_ft_1.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																		list_of_already_used_line_fts.append(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																	if (gdu_line_ft_2.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																		list_of_already_used_line_fts.append(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																else:
																	prev_approx_distance_btw_line_kmns = found_pair_of_line_feats[4]
																	if (prev_approx_distance_btw_line_kmns > approx_distance_btw_lines_kms):
																		if (gdu_line_ft_1.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts and gdu_line_ft_2.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																			found_pair_of_line_feats = (gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2)
																			list_of_already_used_line_fts.append(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																			list_of_already_used_line_fts.append(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
														elif ((approx_rad_closest_dist_neighbour == 0.00 and approx_rad_closest_dist_ref <= 0.1000) or (approx_rad_closest_dist_ref == 0.00 and approx_rad_closest_dist_neighbour <= 0.1000)):
															if ((gdu_line_ft_1.is_valid_at_time(reconstruction_time + time_interval) == True) and (gdu_line_ft_2.is_valid_at_time(reconstruction_time + time_interval) == True)):
																#try to reconstruct the two line features to the older time: equivalent_rot_of_each_gdu_with_anchor_PALEOMAPScotese_20230411.csv 
																temporary_reconstructed_line_features = []
																if (reference is not None):
																	pygplates.reconstruct([gdu_line_ft_1,gdu_line_ft_2], rotation_model, temporary_reconstructed_line_features, reconstruction_time + time_interval, anchor_plate_id = reference, group_with_feature = True)
																else:
																	pygplates.reconstruct([gdu_line_ft_1,gdu_line_ft_2], rotation_model, temporary_reconstructed_line_features, reconstruction_time + time_interval, anchor_plate_id = reference)
																final_reconstructed_temporary_line_feats = find_final_reconstructed_geometries(temporary_reconstructed_line_features,pygplates.PolylineOnSphere)
																_,temp_reconstr_line_1 = final_reconstructed_temporary_line_feats[0]
																_,temp_reconstr_line_2 = final_reconstructed_temporary_line_feats[1]
																if (pygplates.GeometryOnSphere.distance(temp_reconstr_line_1,temp_reconstr_line_2) == 0.00):
																	if ((approx_distance_btw_lines_kms <= 1000.00) or (gdu_line_ft_1.is_valid_at_time(reconstruction_time + time_interval)==False) or (gdu_line_ft_2.is_valid_at_time(reconstruction_time + time_interval)==False)):
																		# # # #debug
																		# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17027_14195_2133') or (gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17027_14195_2133')):
																			# gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																			# gdu_line_ft_1.set_name(key)
																			# gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																			# gdu_line_ft_2.set_name(key)
																			# temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
																			# temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
																			# print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
																		if (found_pair_of_line_feats is None):
																			found_pair_of_line_feats = (gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2)
																			if (gdu_line_ft_1.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																				list_of_already_used_line_fts.append(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																			if (gdu_line_ft_2.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																				list_of_already_used_line_fts.append(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																		else:
																			if (prev_approx_distance_btw_line_kmns > approx_distance_btw_lines_kms):
																				if (gdu_line_ft_1.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts and gdu_line_ft_2.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																					list_of_already_used_line_fts.append(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																					list_of_already_used_line_fts.append(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																					found_pair_of_line_feats = (gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2)
												if (found_pair_of_line_feats is not None):
													gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2 = found_pair_of_line_feats
													temporary_PolylineOnSphere = pygplates.PolylineOnSphere([closest_point_on_gdu1,closest_point_on_gdu2])
													# # #debug
													# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17027_14195_2133') or (gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17027_14195_2133')):
														# gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
														# gdu_line_ft_1.set_name(key)
														# gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
														# gdu_line_ft_2.set_name(key)
														# temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
														# temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
														# print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
													for random_sgdu in non_related:
														if (random_sgdu.partition(temporary_PolylineOnSphere) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
															valid_pair_of_line_fts = False
															
															# # # #debug
															# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17027_14195_2133') or (gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17027_14195_2133')):
																# gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																# gdu_line_ft_1.set_name(key)
																# gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																# gdu_line_ft_2.set_name(key)
																# temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
																# temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
																# print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
																
															break
													if (valid_pair_of_line_fts == True):
														#find the mid_point between two points 
														approx_mid_point = find_the_mid_of_two_PointOnSphere(closest_point_on_gdu1,closest_point_on_gdu2)
														if (approx_mid_point == closest_point_on_gdu1 or approx_mid_point == closest_point_on_gdu2):
															temp_list_of_closest_point_on_gdu1 = dict_of_gdu_and_centroid[gdu_line_ft_1.get_shapefile_attribute('polygid')]
															closest_point_on_gdu1 = temp_list_of_closest_point_on_gdu1[0][0]
															temp_list_of_closest_point_on_gdu2 = dict_of_gdu_and_centroid[gdu_line_ft_2.get_shapefile_attribute('polygid')]
															closest_point_on_gdu2 = temp_list_of_closest_point_on_gdu2[0][0]
														#create an arc
														temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
														normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
														left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, closest_point_on_gdu1, closest_point_on_gdu2, gdu_line_ft_1.get_reconstruction_plate_id(), gdu_line_ft_2.get_reconstruction_plate_id())
														#create point feature
														name = 'R'+str(child_1)+'_'+str(child_2)+'_'+str(smallest_circle_angular_radius_degrees)
														rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, approx_mid_point, name = name, valid_time = (reconstruction_time,0.00))
														rift_point_ft.set_left_plate(left_gduid)
														rift_point_ft.set_right_plate(right_gduid)
														rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
														rift_point_ft.set_description(str(smallest_circle_angular_radius_degrees))
														if (reference is None):
															pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
														else:
															pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
														output_rift_point_features.add(rift_point_ft)
														if (left_gduid == gdu_line_ft_1.get_reconstruction_plate_id() and right_gduid == gdu_line_ft_2.get_reconstruction_plate_id()):
															list_of_ordered_pairs_gdu_fts.append((reconstruction_time,name,smallest_circle_angular_radius_degrees, gdu_line_ft_1.get_shapefile_attribute('POLYLID'), gdu_line_ft_1.get_reconstruction_plate_id(), child_repgduid_1, gdu_line_ft_2.get_shapefile_attribute('POLYLID'), gdu_line_ft_2.get_reconstruction_plate_id(), child_repgduid_2))
														else:
															list_of_ordered_pairs_gdu_fts.append((reconstruction_time,name,smallest_circle_angular_radius_degrees, gdu_line_ft_2.get_shapefile_attribute('POLYLID'), gdu_line_ft_2.get_reconstruction_plate_id(), child_repgduid_2, gdu_line_ft_1.get_shapefile_attribute('POLYLID'), gdu_line_ft_1.get_reconstruction_plate_id(), child_repgduid_1))
													
														#create pair of line features associated with the rift point ft
														line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=gdu_line_ft_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,0.00))
														line_feature_1.set_reconstruction_plate_id(gdu_line_ft_1.get_reconstruction_plate_id())
														line_feature_1.set_conjugate_plate_id(gdu_line_ft_2.get_reconstruction_plate_id())
														line_feature_1.set_description('divergent_margin')
														line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=gdu_line_ft_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,0.00))
														line_feature_2.set_reconstruction_plate_id(gdu_line_ft_2.get_reconstruction_plate_id())
														line_feature_2.set_conjugate_plate_id(gdu_line_ft_1.get_reconstruction_plate_id())
														line_feature_2.set_description('divergent_margin')
														if (reference is None):
															pygplates.reverse_reconstruct([line_feature_1,line_feature_2],rotation_model,reconstruction_time)
														else:
															pygplates.reverse_reconstruct([line_feature_1,line_feature_2],rotation_model,reconstruction_time,reference)
														#output_diverging_line_features.add(line_feature_1)
														#output_diverging_line_features.add(line_feature_2)
														previous_diverging_line_feats.append((line_feature_1,line_feature_2,reconstruction_time,pygplates.GeometryOnSphere.distance(line_gdu_1,line_gdu_2)))
												else:
													#try a higher resolution of smallest_circle_angular_radius_degrees
													temp_small_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees
													prev_small_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees + 2.00
													found_pair_of_line_feats = None
													while (temp_small_circle_angular_radius_degrees < prev_small_circle_angular_radius_degrees):
														temp_small_circle_angular_radius_degrees = temp_small_circle_angular_radius_degrees + 0.500
														small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,temp_small_circle_angular_radius_degrees)
														for gdu_line_ft_1, line_gdu_1 in reconstructed_gdu_fts_for_sgdu1:
															polylid_of_gdu_line_ft_1 = gdu_line_ft_1.get_shapefile_attribute('polygid')
															list_of_neighbours_for_polylid_1 = dict_of_neighbours[polylid_of_gdu_line_ft_1]
															for gdu_line_ft_2, line_gdu_2 in reconstructed_gdu_fts_for_sgdu2:
																polylid_of_gdu_line_ft_2 = gdu_line_ft_2.get_shapefile_attribute('polygid')
																if (polylid_of_gdu_line_ft_2 not in list_of_neighbours_for_polylid_1):
																	continue
																approx_rad_closest_dist_neighbour, closest_point_on_gdu1, _ = pygplates.GeometryOnSphere.distance(line_gdu_1, small_circle_boundary,return_closest_positions = True)
																approx_rad_closest_dist_ref, closest_point_on_gdu2, _= pygplates.GeometryOnSphere.distance(line_gdu_2, small_circle_boundary,return_closest_positions = True)
																#calculate distance by haversine
																lat1,lon1 = closest_point_on_gdu1.to_lat_lon()
																lat2,lon2 = closest_point_on_gdu2.to_lat_lon()
																approx_distance_btw_lines_kms = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
																if (approx_rad_closest_dist_neighbour <= 0.0100 and approx_rad_closest_dist_ref <= 0.0100): 
																	if ((approx_distance_btw_lines_kms <= 1000.00) or (gdu_line_ft_1.is_valid_at_time(reconstruction_time + time_interval)==False) or (gdu_line_ft_2.is_valid_at_time(reconstruction_time + time_interval)==False)):
																		# # #debug
																		# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17027_14195_2133') or (gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17027_14195_2133')):
																			# gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																			# gdu_line_ft_1.set_name(key)
																			# gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																			# gdu_line_ft_2.set_name(key)
																			# temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
																			# temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
																			# print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
																			# print('temp_small_circle_angular_radius_degrees',temp_small_circle_angular_radius_degrees)
																		if (found_pair_of_line_feats is None):
																			found_pair_of_line_feats = (gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2)
																			if (gdu_line_ft_1.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																				list_of_already_used_line_fts.append(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																			if (gdu_line_ft_2.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																				list_of_already_used_line_fts.append(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																		else:
																			prev_approx_distance_btw_line_kmns = found_pair_of_line_feats[4]
																			if (prev_approx_distance_btw_line_kmns > approx_distance_btw_lines_kms):
																				if (gdu_line_ft_1.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts and gdu_line_ft_2.get_shapefile_attribute('POLYLID') not in list_of_already_used_line_fts):
																					found_pair_of_line_feats = (gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2)
																					list_of_already_used_line_fts.append(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																					list_of_already_used_line_fts.append(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																					found_pair_of_line_feats = (gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2)
														if (found_pair_of_line_feats is not None):
															break
													if (found_pair_of_line_feats is not None):
														valid_pair_of_line_fts = True
														gdu_line_ft_1,gdu_line_ft_2,line_gdu_1,line_gdu_2,approx_distance_btw_lines_kms,closest_point_on_gdu1,closest_point_on_gdu2 = found_pair_of_line_feats
														temporary_PolylineOnSphere = pygplates.PolylineOnSphere([closest_point_on_gdu1,closest_point_on_gdu2])
														for random_sgdu in non_related:
															if (random_sgdu.partition(temporary_PolylineOnSphere) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																valid_pair_of_line_fts = False
																# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17027_14195_2133') or (gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17027_14195_2133')):
																	# gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																	# gdu_line_ft_1.set_name(key)
																	# gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																	# gdu_line_ft_2.set_name(key)
																	# temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
																	# temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
																	# print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
																	# print('temp_small_circle_angular_radius_degrees',temp_small_circle_angular_radius_degrees)
																break
														if (valid_pair_of_line_fts == True):
															# if ((gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '17027_14195_2133') or (gdu_line_ft_2.get_shapefile_attribute('POLYLID') == '12405_13895_1569' and gdu_line_ft_1.get_shapefile_attribute('POLYLID') == '17027_14195_2133')):
																# gdu_line_ft_1.set_description(gdu_line_ft_2.get_shapefile_attribute('POLYLID'))
																# gdu_line_ft_1.set_name(key)
																# gdu_line_ft_2.set_description(gdu_line_ft_1.get_shapefile_attribute('POLYLID'))
																# gdu_line_ft_2.set_name(key)
																# temporary_output_pair_div_line_fts.add(gdu_line_ft_1)
																# temporary_output_pair_div_line_fts.add(gdu_line_ft_2)
																# print('approx_distance_btw_lines_kms',approx_distance_btw_lines_kms)
																# print('temp_small_circle_angular_radius_degrees',temp_small_circle_angular_radius_degrees)
															#find the mid_point between two points 
															approx_mid_point = find_the_mid_of_two_PointOnSphere(closest_point_on_gdu1,closest_point_on_gdu2)
															if (approx_mid_point == closest_point_on_gdu1 or approx_mid_point == closest_point_on_gdu2):
																temp_list_of_closest_point_on_gdu1 = dict_of_gdu_and_centroid[gdu_line_ft_1.get_shapefile_attribute('polygid')]
																closest_point_on_gdu1 = temp_list_of_closest_point_on_gdu1[0][0]
																temp_list_of_closest_point_on_gdu2 = dict_of_gdu_and_centroid[gdu_line_ft_2.get_shapefile_attribute('polygid')]
																closest_point_on_gdu2 = temp_list_of_closest_point_on_gdu2[0][0]
															#create an arc
															temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
															normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
															left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, closest_point_on_gdu1, closest_point_on_gdu2, gdu_line_ft_1.get_reconstruction_plate_id(), gdu_line_ft_2.get_reconstruction_plate_id())
															#create point feature
															name = 'R'+str(child_1)+'_'+str(child_2)+'_'+str(smallest_circle_angular_radius_degrees)
															rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, approx_mid_point, name = name, valid_time = (reconstruction_time,0.00))
															rift_point_ft.set_left_plate(left_gduid)
															rift_point_ft.set_right_plate(right_gduid)
															rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
															rift_point_ft.set_description(str(smallest_circle_angular_radius_degrees))
															if (reference is None):
																pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
															else:
																pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
															output_rift_point_features.add(rift_point_ft)
															if (left_gduid == gdu_line_ft_1.get_reconstruction_plate_id() and right_gduid == gdu_line_ft_2.get_reconstruction_plate_id()):
																list_of_ordered_pairs_gdu_fts.append((reconstruction_time,name,smallest_circle_angular_radius_degrees, gdu_line_ft_1.get_shapefile_attribute('POLYLID'), gdu_line_ft_1.get_reconstruction_plate_id(), child_repgduid_1, gdu_line_ft_2.get_shapefile_attribute('POLYLID'), gdu_line_ft_2.get_reconstruction_plate_id(), child_repgduid_2))
															else:
																list_of_ordered_pairs_gdu_fts.append((reconstruction_time,name,smallest_circle_angular_radius_degrees, gdu_line_ft_2.get_shapefile_attribute('POLYLID'), gdu_line_ft_2.get_reconstruction_plate_id(), child_repgduid_2, gdu_line_ft_1.get_shapefile_attribute('POLYLID'), gdu_line_ft_1.get_reconstruction_plate_id(), child_repgduid_1))
													
															#create pair of line features associated with the rift point ft
															line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=gdu_line_ft_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,0.00))
															line_feature_1.set_reconstruction_plate_id(gdu_line_ft_1.get_reconstruction_plate_id())
															line_feature_1.set_conjugate_plate_id(gdu_line_ft_2.get_reconstruction_plate_id())
															line_feature_1.set_description('divergent_margin')
															line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=gdu_line_ft_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,0.00))
															line_feature_2.set_reconstruction_plate_id(gdu_line_ft_2.get_reconstruction_plate_id())
															line_feature_2.set_conjugate_plate_id(gdu_line_ft_1.get_reconstruction_plate_id())
															line_feature_2.set_description('divergent_margin')
															if (reference is None):
																pygplates.reverse_reconstruct([line_feature_1,line_feature_2],rotation_model,reconstruction_time)
															else:
																pygplates.reverse_reconstruct([line_feature_1,line_feature_2],rotation_model,reconstruction_time,reference)
															#output_diverging_line_features.add(line_feature_1)
															#output_diverging_line_features.add(line_feature_2)
															previous_diverging_line_feats.append((line_feature_1,line_feature_2,reconstruction_time,pygplates.GeometryOnSphere.distance(line_gdu_1,line_gdu_2)))
												#break
														#debug
														# if (found_pair_of_line_feats == True):
															# break
												smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 2.00
		#check the end_time of diverging line features
		#debug
		print('number of features in previous_diverging_line_feats before update',len(previous_diverging_line_feats))
		if (len(previous_diverging_line_feats) > 0):
			remaining_diverging_line_feats = []
			recorded_distance = -1.00
			for line_feature_1,line_feature_2,prev_begin_age,prev_distance in previous_diverging_line_feats:
				recorded_distance = prev_distance
				if (prev_begin_age > reconstruction_time):
					reconstructed_prev_div_line_features = []
					if (reference is not None):
						pygplates.reconstruct([line_feature_1,line_feature_2], rotation_model, reconstructed_prev_div_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
					else:
						pygplates.reconstruct([line_feature_1,line_feature_2], rotation_model, reconstructed_prev_div_line_features, reconstruction_time, group_with_feature = True)
					final_prev_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_prev_div_line_features,pygplates.PolylineOnSphere)
					prev_reconstr_ft_1,prev_reconstr_line_1 = final_prev_reconstructed_line_features[0]
					prev_reconstr_ft_2,prev_reconstr_line_2 = final_prev_reconstructed_line_features[1]
					current_distance = pygplates.GeometryOnSphere.distance(prev_reconstr_line_1,prev_reconstr_line_2)
					recorded_distance = current_distance
					if (current_distance < prev_distance):
						if ((current_distance == 0.00) or (prev_distance/current_distance >= 2.00)):
							cloned_line_ft_1 = line_feature_1.clone()
							cloned_line_ft_1.set_valid_time(prev_begin_age,reconstruction_time+0.100)
							line_feature_1.set_description('plate_boundary_zone')
							line_feature_1.set_valid_time(reconstruction_time,0.00)
							cloned_line_ft_2 = line_feature_2.clone()
							cloned_line_ft_2.set_valid_time(prev_begin_age,reconstruction_time+0.100)
							line_feature_2.set_description('plate_boundary_zone')
							line_feature_2.set_valid_time(reconstruction_time,0.00)
							output_diverging_line_features.add(cloned_line_ft_1)
							output_diverging_line_features.add(cloned_line_ft_2)
				remaining_diverging_line_feats.append((line_feature_1,line_feature_2,prev_begin_age,recorded_distance))
			previous_diverging_line_feats = remaining_diverging_line_feats
		
		#debug
		print('number of features in previous_diverging_line_feats',len(previous_diverging_line_feats))
		temporary_output_pair_div_line_fts.write('expected_pair_divergent_line_features_but_failed_at_'+str(reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
		temporary_output_pair_div_line_fts = None
		
		#update reconstruction_time for the main while-loop
		reconstruction_time = reconstruction_time - time_interval
	output_rift_point_features.write('rift_point_features_for_'+modelname+'_'+yearmonthday+'.shp')
	if (len(previous_diverging_line_feats) > 0):
		for line_feature_1,line_feature_2,prev_begin_age,prev_distance in previous_diverging_line_feats:
			output_diverging_line_features.add(line_feature_1)
			output_diverging_line_features.add(line_feature_2)
	output_diverging_line_features.write('diverging_line_features_for_'+modelname+'_'+yearmonthday+'.shp')
	
	#list_of_ordered_pairs_gdu_fts.append((start_div,name,smallest_circle_angular_radius_degrees, gdu_line_ft_2.get_shapefile_attribute('POLYLID'), gdu_line_ft_2.get_reconstruction_plate_id(), child_repgduid_2, gdu_line_ft_1.get_shapefile_attribute('POLYLID'), gdu_line_ft_1.get_reconstruction_plate_id(), child_repgduid_1))
	output_dataframe = pd.DataFrame.from_records(list_of_ordered_pairs_gdu_fts, columns = ['start_div','rift_name','order','lpolylid','left_gdu','lrepgduid','rpolylid','right_gdu','rrepgduid'])
	filename = 'rift_point_features_records_for_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)





# import sys
# import copy
# import gc
# import os
# import csv
# import enum
# import math
# import pandas as pd
# #pygplates is a specific package for plate tectonic study
# #sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
# sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
# import pygplates
# import supporting_modules_to_be_converted as supporting
# import supporting_topological_modules as tm
# import supporting_topological_modules_for_MOR as MOR_topology
# import rotation_utility
# import numpy as np
# from functools import partial
# import psycopg2
# from config_plate_tectonics import config

# def find_the_appropriate_neighbour_for_the_line_feature_at_reconstruction_time(common_filename_for_temporary_sgdu_and_members_csv,reconstructed_ref_line_ft, reconstructed_ref_line, neighbours_reconstructed_geom_fts, reconstruction_time, rotation_model, reference):
	# #neighbours_reconstructed_geom_fts = [(polygon_ft,polygon) for polygon_ft,polygon in final_reconstructed_polygon_features if polygon_ft.get_feature_id().get_string() in neighbours_feature_id]
	# #find the GDU having the same SuperGDU id as the reconstructed_ref_line_ft
	# txt = """SELECT DISTINCT represent_gdu_id,super_gdu_id FROM temp_final_super_gdu_id_2
					# WHERE from_time > {input_time} and to_time <= {input_time} AND represent_gdu_id in 
						# (SELECT DISTINCT gdu_id_member from super_gdu_and_members_id 
							# WHERE super_gdu_id in
								# (SELECT DISTINCT super_gdu_id FROM super_gdu_and_members_id 
										# WHERE gdu_id_member = {input_member_id} AND from_time > {input_time} AND to_time <= {input_time})) """
	# txt_1 = """SELECT DISTINCT gdu_id_member FROM super_gdu_and_members_id WHERE super_gdu_id = {input_super_gdu_id}"""
	
	# gdu_id = reconstructed_ref_line_ft.get_reconstruction_plate_id()
	# temp_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
	# #;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
	# temp_df = pd.read_csv(temp_sgdu_and_members_csv, delimiter = ';', header = 0)
	# unique_sgdus = temp_df.loc[temp_df['GDUID'] == gdu_id,'SGDUID'].unique()
	# records_of_gdu_members = []
	# for sgdu in unique_sgdus:
		# temp_members = temp_df.loc[(temp_df['SGDUID'] == sgdu),'GDUID'].unique()
		# for temp_mem in temp_members:
			# if (temp_mem not in records_of_gdu_members):
				# records_of_gdu_members.append(temp_mem)
	
	# for neighbour_ft,neighbour_geom in neighbours_reconstructed_geom_fts:
		# neighbour_gdu_id = neighbour_ft.get_reconstruction_plate_id()
		# is_valid = True
		# for gduid_member in records_of_gdu_members:
			# if (gduid_member == neighbour_gdu_id):
				# is_valid = False
				# break
		# if (is_valid == True):
			# smaller_list_of_neighbours.append((neighbour_gdu_id,neighbour_ft,neighbour_geom))
	
	# dic_of_neighbours_super_gdus = {}
	# for neighbour_gdu_id,neighbour_ft,neighbour_geom in smaller_list_of_neighbours:
		# unique_sgdus = temp_df.loc[temp_df['GDUID'] == neighbour_gdu_id,'SGDUID'].unique()
		# records_of_neighbour_gdu_members = []
		# if (len(unique_sgdus) > 1):
			# print("Error neighbour_gdu_id belongs to more than one SGDU")
			# print("neighbour_gdu_id",neighbour_gdu_id)
			# print("unique_sgdus",unique_sgdus)
		# sgdu = unique_sgdus[0]
		# unique_rep_gduid_for_neighbours = temp_df.loc[(temp_df['SGDUID'] == sgdu),'repGDUID'].unique()
		# for represent_gdu_id_for_neighbour in unique_rep_gduid_for_neighbours:
			# if (str(represent_gdu_id_for_neighbour) in dic_of_neighbours_super_gdus):
				# dic_of_neighbours_super_gdus[str(represent_gdu_id_for_neighbour)].append((neighbour_ft,neighbour_geom))
			# else:
				# dic_of_neighbours_super_gdus[str(represent_gdu_id_for_neighbour)]=[(neighbour_ft,neighbour_geom)]
	# final_neighbour_ft,final_neighbour_geom = None, None
	# if (len(dic_of_neighbours_super_gdus) == 0):
		# return final_neighbour_ft,final_neighbour_geom
	# else:
		# smallest_distance = -1.00
		# list_of_neighbours_from_small_circles = []
		# for key in dic_of_neighbours_super_gdus:
			# neighbour_rep_gdu_id = int(key)
			# list_of_neighbour_fts_and_geoms = dic_of_neighbours_super_gdus[key]
			# total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,represent_gdu_id,neighbour_rep_gdu_id, reconstruction_time, reference)
			# if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
				# E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
				# for neighbour_ft,neighbour_geom in list_of_neighbour_fts_and_geoms:
					# smallest_circle_angular_radius_degrees = 179.00
					# while (smallest_circle_angular_radius_degrees > 0.00):
						# small_circle_ft = None
						# small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
						# approx_rad_closest_dist_neighbour = pygplates.GeometryOnSphere.distance(neighbour_geom, small_circle_boundary)
						# approx_rad_closest_dist_ref = pygplates.GeometryOnSphere.distance(reconstructed_ref_line, small_circle_boundary)
						# if (approx_rad_closest_dist_neighbour == approx_rad_closest_dist_ref == 0.00):
							# list_of_neighbours_from_small_circles.append((neighbour_rep_gdu_id,neighbour_ft,neighbour_geom))
							# break
						# smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.00
		# for neighbour_rep_gdu_id,neighbour_ft,neighbour_geom in list_of_neighbours_from_small_circles:
			# distance_approx_km = pygplates.GeometryOnSphere.distance(neighbour_geom, reconstructed_ref_line) * pygplates.Earth.mean_radius_in_kms
			# if (smallest_distance == -1.00):
				# smallest_distance = distance_approx_km 
				# final_neighbour_ft = neighbour_ft
				# final_neighbour_geom = neighbour_geom
			# elif (smallest_distance > -1.00 and smallest_distance < distance_approx_km):
				# smallest_distance = distance_approx_km 
				# final_neighbour_ft = neighbour_ft
				# final_neighbour_geom = neighbour_geom
			# if (smallest_distance == 0.00):
				# break
		# return (final_neighbour_ft,final_neighbour_geom)
		
# def find_centroid_features_from_line_features(line_features,write_output,mmddyy):
	# featType = pygplates.FeatureType.gpml_continental_crust
	# list_of_centroid_fts = []
	# for line_ft in line_features:
		# lines = line_ft.get_geometries()
		# if (len(lines) > 1):
			# longest_line = None
			# for line in lines:
				# if (line.get_arc_length() > 0.00):
					# if (longest_line is None):
						# longest_line = line
					# else:
						# if (longest_line.get_arc_length() < line.get_arc_length()):
							# longest_line = line
			# centroid = longest_line.get_centroid()
			# begin_age,end_age = line_ft.get_valid_time()
			# GDU_id = line_ft.get_reconstruction_plate_id()
			# GDU_name = line_ft.get_name()
			# centroid_ft =  pygplates.Feature.create_reconstructable_feature(featType,centroid,name=GDU_name,valid_time = (begin_age,end_age),reconstruction_plate_id = GDU_id)
			# centroid_ft.set_description(line_ft.get_name())
			# list_of_centroid_fts.append(centroid_ft)
		# elif (len(lines) == 1):
			# line = lines[0]
			# centroid = line.get_centroid()
			# begin_age,end_age = line_ft.get_valid_time()
			# GDU_id = line_ft.get_reconstruction_plate_id()
			# GDU_name = line_ft.get_name()
			# centroid_ft =  pygplates.Feature.create_reconstructable_feature(featType,centroid,name=GDU_name,valid_time = (begin_age,end_age),reconstruction_plate_id = GDU_id)
			# centroid_ft.set_description(line_ft.get_name())
			# list_of_centroid_fts.append(centroid_ft)
	# if (write_output == True):
		# outputLinesFeatureCollection = pygplates.FeatureCollection(list_of_centroid_fts)
		# outputLinesFile = "centroid_features_for_line_features_for_BC_PalaeoPlatesNov2022_"+mmddyy+".shp"
		# outputLinesFeatureCollection.write(outputLinesFile)
	# return list_of_centroid_fts

# def find_neighbours_for_line_features(rotation_model,list_of_valid_line_fts,threshold_distance_in_km,dictionary_of_neighbours,reconstruction_time,reference):
	# reconstructed_line_features = []
	# final_reconstructed_line_features = []
	

	# #clear temporary storages storing reconstructed features after every reconstruction_time
	# reconstructed_line_features[:] = []
	# final_reconstructed_line_features[:] = []

	# #reconstruct all features to reconstruction_time
	# if (reference is not None):
		# #polygon_features
		# pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	# else:
		# #polygon_features
		# pygplates.reconstruct(list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
			
	# final_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
	
	# for each_ft,line in final_reconstructed_line_features:
		# if not(each_ft.get_name() in dictionary_of_neighbours):
			# dictionary_of_neighbours[each_ft.get_name()]=[]
		# for each_other_ft,other_line in final_reconstructed_line_features:
			# if (each_ft.get_name() != each_other_ft.get_name()):
				# #distance_radians = pygplates.GeometryOnSphere.distance(polygon,other_polygon)
				# _, closest_point_on_geometry1, closest_point_on_geometry2 = pygplates.GeometryOnSphere.distance(line, other_line, return_closest_positions=True)
				# #distance_in_km = distance_radians * pygplates.Earth.mean_radius_in_kms
				# lat1,lon1 = closest_point_on_geometry1.to_lat_lon()
				# lat2,lon2 = closest_point_on_geometry2.to_lat_lon()
				# distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
				# if (distance_in_km <= threshold_distance_in_km):
					# dictionary_of_neighbours[each_ft.get_name()].append(each_other_ft.get_name())
	# return dictionary_of_neighbours

# def find_neighbours_for_polygon_features(rotation_model,list_of_valid_polygons_fts,threshold_distance_in_km,dictionary_of_neighbours,reconstruction_time,reference):
	# reconstructed_polygon_features = []
	# final_reconstructed_polygon_features = []
	

	# #clear temporary storages storing reconstructed features after every reconstruction_time
	# reconstructed_polygon_features[:] = []
	# final_reconstructed_polygon_features[:] = []

	# #reconstruct all features to reconstruction_time
	# if (reference is not None):
		# #polygon_features
		# pygplates.reconstruct(list_of_valid_polygons_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	# else:
		# #polygon_features
		# pygplates.reconstruct(list_of_valid_polygons_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
			
	# final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
	
	# for each_ft,polygon in final_reconstructed_polygon_features:
		# if not(each_ft.get_description() in dictionary_of_neighbours):
			# dictionary_of_neighbours[each_ft.get_description()]=[]
		# for each_other_ft,other_polygon in final_reconstructed_polygon_features:
			# if (each_ft.get_description() != each_other_ft.get_description()):
				# #distance_radians = pygplates.GeometryOnSphere.distance(polygon,other_polygon)
				# _, closest_point_on_geometry1, closest_point_on_geometry2 = pygplates.GeometryOnSphere.distance(polygon, other_polygon, return_closest_positions=True)
				# #distance_in_km = distance_radians * pygplates.Earth.mean_radius_in_kms
				# lat1,lon1 = closest_point_on_geometry1.to_lat_lon()
				# lat2,lon2 = closest_point_on_geometry2.to_lat_lon()
				# distance_in_km = calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2)
				# if (distance_in_km <= threshold_distance_in_km):
					# dictionary_of_neighbours[each_ft.get_description()].append(each_other_ft.get_description())
	# return dictionary_of_neighbours

# def identify_tectonic_motion(common_filename_for_temporary_sgdu_and_members_csv, rotation_model, polygon_features_collection, centroid_features_file, line_features_collection, begin_reconstruction_time,end_reconstruction_time,interval,field_name_for_lithosphere_type,continental_type_symbol,threshold_distance_in_km,cos_value_for_transform,reference,modelname,mmddyy):
	
	# #convert temporary_list_of_processed_line_features to FeatureCollection
	# #line_features_collection = pygplates.FeatureCollection(topological_line_features_file)
	
	# # print('This is igneous_buffer_zone_features_file')
	# # print igneous_buffer_zone_features_file
	# # igneous_buffer_zone_features_collection = pygplates.FeatureCollection(igneous_buffer_zone_features_file)
	
	# # print('This is possible_line_fts_for_subduction_zone_deposits_file')
	# # print(possible_line_fts_for_subduction_zone_deposits_file)
	# #possible_line_fts_for_subduction_zone_deposits = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_deposits_file)
	
	# # print('This is possible_line_fts_for_subduction_zone_igneous_file')
	# # print(possible_line_fts_for_subduction_zone_igneous_file)
	# #possible_line_fts_for_subduction_zone_igneous = pygplates.FeatureCollection(possible_line_fts_for_subduction_zone_igneous_file)
	
	# list_of_continental_polygons_fts = None
	# if (field_name_for_lithosphere_type is not None and continental_type_symbol is not None):
		# list_of_continental_polygons_fts = polygon_features_collection.get(
				# lambda polygon_feature: polygon_feature.get_shapefile_attribute(field_name_for_lithosphere_type) == continental_type_symbol ,pygplates.FeatureReturn.all)
	# else:
		 # list_of_continental_polygons_fts = polygon_features_collection
	# list_of_centroid_fts = None
	# if (centroid_features_file is not None):
		# list_of_centroid_fts = pygplates.FeatureCollection(centroid_features_file)
	# else:
		# list_of_centroid_fts = find_centroid_features_from_line_features(line_features_collection,True,mmddyy)

	# dictionary_of_neighbours_id = {}
	
	# dictionary_of_distance = {}
	# dictionary_of_tectonic_motion = {}
	# dictionary_of_suspected_motion = {}
	# dictionary_of_tectonic_boundaries = {}
	# list_of_tectonic_boundaries = []
	
	# list_of_invalid_pairs_of_ft = []
	# list_of_appropriate_polygon_features = []
	# list_of_appropriate_neighbour_ft = []
	# reconstructed_polygon_features = []
	# final_reconstructed_polygon_features = []
	# list_of_valid_line_features = []
	# other_line_fts = []
	# reconstructed_line_features = []
	# final_reconstructed_line_features = []
	# pre_processed_line_features = []
	# list_of_valid_point_features = []
	# reconstructed_point_features = []
	# final_reconstructed_point_features = []
	# reconstructed_temp_point_features = []
	# final_reconstructed_temp_point_features = []
	
	# #list of keep tracks of processed GDUs to avoid override
	# recently_updated = []
	# #information for csv files
	# last_output_csv_files = -1.00

	# last_update_time_for_dictionary_of_neighbours = -1.00
	# boundaries_from_dictionary = []
	# reconstructed_boundaries = []
	# final_reconstructed_boundaries = []
	# boundaries = []
	# already_processed = []
	# record_cursor = None
	# reconstruction_time = begin_reconstruction_time
	# while (reconstruction_time > (end_reconstruction_time - interval)):
		# print("Here is reconstruction_time")
		# print(reconstruction_time)
		
		# #collect garbage
		# gc.collect()
		
		# #load line fts to FeatureCollection
		# #line_features_collection = pygplates.FeatureCollection(topological_line_features_file)
		
		
		# #to find the mean of difference in distance 
		# total_difference_in_distance = 0.00
		# count = 0
		
		# #empty all containers
		# list_of_invalid_pairs_of_ft[:] = []
		# list_of_appropriate_polygon_features[:] = []
		# reconstructed_polygon_features[:] = []
		# final_reconstructed_polygon_features[:] = []
		# list_of_valid_line_features[:] = []
		# reconstructed_line_features[:] = []
		# final_reconstructed_line_features[:] = []
		# list_of_valid_point_features[:] = []
		# reconstructed_point_features[:] = []
		# final_reconstructed_point_features[:] = []
		# #obtain list of topological line features that are between a continental GDU and an oceanic GDU at the reconstruction time
		# for line_ft in line_features_collection:#O(n) where n is number of CON-OCN line features from the initial input 
			# type_of_line_ft = line_ft.get_description()
			# valid = line_ft.is_valid_at_time(reconstruction_time)
			# if (valid == True):
				# list_of_valid_line_features.append(line_ft.clone())
		# #line_features_collection = None			
		# final_list_of_valid_line_fts = list_of_valid_line_features
		# print("Here is len(final_list_of_valid_line_fts)")
		# print(len(final_list_of_valid_line_fts))
		# #reconstructed all features to the reconstruction time 
		# if (reference is not None):
			# #line_features
			# pygplates.reconstruct(final_list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		# else:
			# #line_features
			# pygplates.reconstruct(final_list_of_valid_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
		
		# #find final reconstructed geometry for each reconstructed feature 
		# final_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
		# #clearing reconstructed_line_features
		# reconstructed_line_features[:] = []
		# print("here is len(final_reconstructed_line_features)")
		# print(len(final_reconstructed_line_features))
		# for appropriate_line_ft,_ in final_reconstructed_line_features: #O(n) where n is number of final_reconstructed_line_features
			# GDU_id = appropriate_line_ft.get_reconstruction_plate_id()
			# polygon_fts = [polygon_ft for polygon_ft in list_of_continental_polygons_fts  if (polygon_ft.get_reconstruction_plate_id() == GDU_id and polygon_ft.is_valid_at_time(reconstruction_time))]
			# for ft in polygon_fts: #O(m) where m is number of polygon_fts associated with the line feature through GDU_id and reconstruction_time 
				# ft.set_description(appropriate_line_ft.get_name())
				# list_of_appropriate_polygon_features.append(ft)
		# #find neighbours for each GDU_feature associated to each valid CON-OCN topological line feature
		# dictionary_of_neighbours_id.clear()
		# find_neighbours_for_line_features(rotation_model,final_list_of_valid_line_fts,threshold_distance_in_km,dictionary_of_neighbours_id,reconstruction_time,reference)
		# for appropriate_line_ft in final_list_of_valid_line_fts: #O(m') where m' is the number of polygon_fts in list_of_appropriate_polygon_features
			# line_ft_id = appropriate_line_ft.get_name()
			# for centroid_ft in list_of_centroid_fts: #O(M) where M is the number of continental polygon features from the initial input 
				# if (centroid_ft.get_description() == line_ft_id and centroid_ft.is_valid_at_time(reconstruction_time)):
					# list_of_valid_point_features.append(centroid_ft)
		# #reconstructed all features to the reconstruction time 
		# if (reference is not None):
			# #polygon_features
			# pygplates.reconstruct(list_of_appropriate_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# #point_features
			# pygplates.reconstruct(list_of_valid_point_features,rotation_model,reconstructed_point_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		# else:
			# #polygon_features
			# pygplates.reconstruct(list_of_appropriate_polygon_features,rotation_model,reconstructed_polygon_features,reconstruction_time, group_with_feature = True)
			# #point_features
			# pygplates.reconstruct(list_of_valid_point_features,rotation_model,reconstructed_point_features,reconstruction_time,group_with_feature = True)
		# final_reconstructed_polygon_features = find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
		# final_reconstructed_point_features = find_final_reconstructed_geometries(reconstructed_point_features,pygplates.PointOnSphere)
		
		# #clearing list containing reconstructed feature geometries
		# reconstructed_polygon_features[:] = []
		# reconstructed_point_features[:] = []
		# print("Here is the length for final_reconstructed_polygon_features")
		# print(len(final_reconstructed_polygon_features))
		# print("Here is the length for final_reconstructed_point_features")
		# print(len(final_reconstructed_point_features))
		# recently_updated[:] = []
		# already_processed[:] = []
		# for topological_line_ft,topological_line in final_reconstructed_line_features:
			# #get polygon feature id store in point_ft to access dictionary_of_neighbours_id
			# reference_feature_id = topological_line_ft.get_name()
			# input_ref_gdu_id = topological_line_ft.get_reconstruction_plate_id()
			# if (reference_feature_id not in already_processed):
				# centroid_reference_ft = None
				# for point_ft,pt in final_reconstructed_point_features:
					# if (point_ft.get_description() == reference_feature_id):
						# centroid_reference_ft = point_ft 
						# break
				# neighbours_feature_id = dictionary_of_neighbours_id[reference_feature_id]
				# neighbours_reconstructed_polygon_fts = [(polygon_ft,polygon) for polygon_ft,polygon in final_reconstructed_polygon_features if polygon_ft.get_description() in neighbours_feature_id]
				# neighbours_reconstructed_point_fts = [(point_ft,point) for point_ft,point in final_reconstructed_point_features if point_ft.get_description() in neighbours_feature_id]
				# neighbours_reconstructed_line_fts = [(line_ft,line) for line_ft,line in final_reconstructed_line_features if line_ft.get_name() in neighbours_feature_id]
			
				# reconstructed_ref_line_ft = topological_line_ft
				# reconstructed_ref_line = topological_line
				# final_neighbour_ft, final_neighbour_line = find_the_appropriate_neighbour_for_the_line_feature_at_reconstruction_time(common_filename_for_temporary_sgdu_and_members_csv,reconstructed_ref_line_ft, reconstructed_ref_line, neighbours_reconstructed_line_fts, reconstruction_time, rotation_model, reference)
				# if (final_neighbour_ft is not None):
					# neighbour_ft_id = final_neighbour_ft.get_name()
					# other_centroid_ft = None
					# for point_ft,pt in final_reconstructed_point_features:
						# if (point_ft.get_description() == neighbour_ft_id):
							# other_centroid_ft = point_ft 
							# break
					# tectonic_motion = supporting.relative_position_velocity_vectors_eval(rotation_model,centroid_reference_ft,other_centroid_ft,reconstruction_time,interval,reference,cos_value_for_transform)#cos_value_for_transform defines the upper and lower limit angles between velocity_vector and position_vector
					# #list_of_appropriate_neighbour_ft.append((reconstruction_time,reference_feature_id,neighbour_ft_id,tectonic_motion))
					# #record to the database
					# input_neighbour_gdu_id = final_neighbour_ft.get_reconstruction_plate_id()					
					# record_txt = """ INSERT INTO {input_name_of_database_table} (time,ref_gdu_id,neighbour_gdu_id,ref_ft_id,neighbour_ft_id,tectonic_motion) VALUES(%s, %s, %s, %s, %s, %s)"""
					# record_sql = record_txt.format(input_name_of_database_table = name_of_database_table)
					# record_cursor.execute(record_sql,(reconstruction_time,input_ref_gdu_id,input_neighbour_gdu_id,reference_feature_id,neighbour_ft_id,tectonic_motion.name))
					# conn.commit()
					# print("reconstruction_time,reference_feature_id,neighbour_ft_id,tectonic_motion")
					# print(reconstruction_time,reference_feature_id,neighbour_ft_id,tectonic_motion)
					# already_processed.append(reference_feature_id)
					# already_processed.append(neighbour_ft_id)
					
		# #update reconstruction_time
		# reconstruction_time = reconstruction_time - interval
	# #new_dataframe = pd.DataFrame.from_records(list_of_appropriate_neighbour_ft, columns= ['reconstruction_time','reference_feature_id','neighbour_ft_id','tectonic_motion'])
	# #new_dataframe.to_csv("tectonic_motion_of_appropriate_pairs_of_CON_OCN_line_fts_"+modelname+"_"+mmddyy+".csv",index = False)

# def is_line_crossing_polygon(point_1,point_2,polygon,threshold_distance_in_km):
	# featType = pygplates.FeatureType.gpml_continental_crust
	
	# #Create a new line between two points
	# new_line = pygplates.PolylineOnSphere([point_1,point_2])

	# if (new_line is None):
		# print("Error: there is something wrong - line cannot be created")
		# print("Here are input points:")
		# print(point_1)
		# print(point_2)
		# exit()
	# #Check whether this line intersect - "cutting across" the polygon
	# if (polygon.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.inside):
		# length = supporting.calculate_the_actual_length_of_a_line_in_km(new_line)
		# #length = new_line.get_arc_length()*pygplates.Earth.mean_radius_in_kms
		# return (True,length)
	# elif (polygon.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
		# geometry_inside_polygon = []
		# geometry_outside_polygon = []
		# polygon.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
		# #debug
		# # print "length of geometry_inside_polygon"
		# # print len(geometry_inside_polygon)
		# if (len(geometry_inside_polygon) > 0):
			# total_intersecting_length = 0.00
			# boundary_of_polygon = pygplates.PolylineOnSphere(polygon.to_lat_lon_list())
			# for geometry in geometry_inside_polygon:
				# length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
				# #length = geometry.get_arc_length()*pygplates.Earth.mean_radius_in_kms
				# #distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry) * pygplates.Earth.mean_radius_in_kms
				# total_intersecting_length = total_intersecting_length + length
				# # if (total_intersecting_length > threshold_distance_in_km):
					# # return (True,total_intersecting_length)
			# if (total_intersecting_length >= threshold_distance_in_km):
				# return (True,total_intersecting_length)
			# else:
				# return (False,0.00)
		# else:
			# return (False,0.00)
	# else:
		# return (False,0.00)

# def is_line_crossing_polygon_w_rel_position_vector(point_1, point_2, point_from_polygon):
	# #relative position from point_1 to point_2
	# x1,y1,z1 = point_1.to_xyz()
	# x2,y2,z2 = point_2.to_xyz()
	# vec_1 = pygplates.Vector3D(x2-x1, y2-y1, z2-z1)
	# #relative position from point_2 to point_1
	# vec_2 = pygplates.Vector3D(x1-x2, y1-y2, z1-z2)
	# #relative position from point_1 to centroid of polygon
	# #centroid_of_polygon = polygon.get_interior_centroid()
	# cx,cy,cz = point_from_polygon.to_xyz()
	# vec_1P = pygplates.Vector3D(cx-x1, cy-y1, cz-z1)
	# vec_2P = pygplates.Vector3D(cx-x2, cy-y2, cz-z2)
	# #convert vectors related to point 1 to local azimuthal coords
	# mag_1,azim_1,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(point_1, vec_1)
	# mag_1P,azim_1P,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(point_1, vec_1P)
	# local_vec_1 = pygplates.LocalCartesian.convert_from_geocentric_to_north_east_down(point_1, vec_1)
	# local_vec_1P = pygplates.LocalCartesian.convert_from_geocentric_to_north_east_down(point_1, vec_1P)
	# distance_btw_1_and_2 = pygplates.GeometryOnSphere.distance(point_1,point_2)
	# distance_btw_1_and_p = pygplates.GeometryOnSphere.distance(point_1,point_from_polygon)
	# distance_btw_2_and_p = pygplates.GeometryOnSphere.distance(point_2,point_from_polygon)
	# print('distance_btw_1_and_2',distance_btw_1_and_2)
	# azim_1_degrees = math.degrees(azim_1)
	# azim_1P_degrees = math.degrees(azim_1P)
	# print('azim_1_degrees',azim_1_degrees,'azim_1P_degrees',azim_1P_degrees)
	# max_range_for_1 = azim_1_degrees + 45.00
	# min_range_for_1 = azim_1_degrees - 45.00
	# print('max_range_for_1',max_range_for_1,'min_range_for_1',min_range_for_1)
	# polygon_in_btw = False
	# if (azim_1P_degrees >= min_range_for_1 and azim_1P_degrees <= max_range_for_1):
		# # if (mag_1P < mag_1):
			# # #polygon is between point 1 and 2 from point 1's view?
			# # polygon_in_btw = True
		# #project vec_1P onto vec_1
		# dot_product = pygplates.Vector3D.dot(local_vec_1P, local_vec_1)
		# print('dot_product',dot_product,'local_vec_1',local_vec_1.get_magnitude(),'distance_btw_1_and_p',distance_btw_1_and_p)
		# # if (dot_product <= local_vec_1.get_magnitude()):
			# # polygon_in_btw = True
		# if (distance_btw_1_and_2 > distance_btw_1_and_p):
			# polygon_in_btw = True
	# #relative position from point_2 to centroid of polygon
	# mag_2,azim_2,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(point_2, vec_2)
	# mag_2P,azim_2P,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(point_2, vec_2P)
	# local_vec_2 = pygplates.LocalCartesian.convert_from_geocentric_to_north_east_down(point_2, vec_2)
	# local_vec_2P = pygplates.LocalCartesian.convert_from_geocentric_to_north_east_down(point_2, vec_2P)
	# azim_2_degrees = math.degrees(azim_2)
	# azim_2P_degrees = math.degrees(azim_2P)
	# print('azim_2_degrees',azim_2_degrees,'azim_2P_degrees',azim_2P_degrees)
	# max_range_for_2 = azim_2_degrees + 45.00
	# min_range_for_2 = azim_2_degrees - 45.00
	# print('max_range_for_2',max_range_for_2,'min_range_for_2',min_range_for_2)
	# if (azim_2P_degrees >= min_range_for_2 and azim_2P_degrees <= max_range_for_2):
		# # if (mag_2P < mag_2):
			# # #polygon is between point 1 and 2 from point 1's view?
			# # polygon_in_btw = True
		# #project vec_2P onto vec_2
		# dot_product = pygplates.Vector3D.dot(local_vec_2P, local_vec_2)
		# print('dot_product',dot_product,'local_vec_2',local_vec_2.get_magnitude(),'distance_btw_2_and_p',distance_btw_2_and_p)
		# # if (dot_product <= local_vec_2.get_magnitude()):
			# # polygon_in_btw = True
		# if (distance_btw_1_and_2 > distance_btw_2_and_p):
			# polygon_in_btw = True
	# return polygon_in_btw

# def is_line_crossing_polygon_w_rel_position_vector(point_1, point_2, point_from_polygon):
	# #relative position from point_1 to point_2
	# x1,y1,z1 = point_1.to_xyz()
	# x2,y2,z2 = point_2.to_xyz()
	# vec_1 = pygplates.Vector3D(x2-x1, y2-y1, z2-z1)
	# #relative position from point_2 to point_1
	# vec_2 = pygplates.Vector3D(x1-x2, y1-y2, z1-z2)
	# #relative position from point_1 to centroid of polygon
	# #centroid_of_polygon = polygon.get_interior_centroid()
	# cx,cy,cz = point_from_polygon.to_xyz()
	# vec_1P = pygplates.Vector3D(cx-x1, cy-y1, cz-z1)
	# vec_2P = pygplates.Vector3D(cx-x2, cy-y2, cz-z2)
	# #convert vectors related to point 1 to local azimuthal coords
	# mag_1,azim_1,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(point_1, vec_1)
	# mag_1P,azim_1P,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(point_1, vec_1P)
	# local_vec_1 = pygplates.LocalCartesian.convert_from_geocentric_to_north_east_down(point_1, vec_1)
	# local_vec_1P = pygplates.LocalCartesian.convert_from_geocentric_to_north_east_down(point_1, vec_1P)
	# distance_btw_1_and_2 = pygplates.GeometryOnSphere.distance(point_1,point_2)
	# distance_btw_1_and_p = pygplates.GeometryOnSphere.distance(point_1,point_from_polygon)
	# distance_btw_2_and_p = pygplates.GeometryOnSphere.distance(point_2,point_from_polygon)
	# print('distance_btw_1_and_2',distance_btw_1_and_2)
	# azim_1_degrees = math.degrees(azim_1)
	# azim_1P_degrees = math.degrees(azim_1P)
	# print('azim_1_degrees',azim_1_degrees,'azim_1P_degrees',azim_1P_degrees)
	# max_range_for_1 = azim_1_degrees + 45.00
	# min_range_for_1 = azim_1_degrees - 45.00
	# print('max_range_for_1',max_range_for_1,'min_range_for_1',min_range_for_1)
	# polygon_in_btw = False
	# if (azim_1P_degrees >= min_range_for_1 and azim_1P_degrees <= max_range_for_1):
		# # if (mag_1P < mag_1):
			# # #polygon is between point 1 and 2 from point 1's view?
			# # polygon_in_btw = True
		# #project vec_1P onto vec_1
		# dot_product = pygplates.Vector3D.dot(local_vec_1P, local_vec_1)
		# print('dot_product',dot_product,'local_vec_1',local_vec_1.get_magnitude(),'distance_btw_1_and_p',distance_btw_1_and_p)
		# # if (dot_product <= local_vec_1.get_magnitude()):
			# # polygon_in_btw = True
		# if (distance_btw_1_and_2 > distance_btw_1_and_p):
			# polygon_in_btw = True
	# #relative position from point_2 to centroid of polygon
	# mag_2,azim_2,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(point_2, vec_2)
	# mag_2P,azim_2P,_ = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(point_2, vec_2P)
	# local_vec_2 = pygplates.LocalCartesian.convert_from_geocentric_to_north_east_down(point_2, vec_2)
	# local_vec_2P = pygplates.LocalCartesian.convert_from_geocentric_to_north_east_down(point_2, vec_2P)
	# azim_2_degrees = math.degrees(azim_2)
	# azim_2P_degrees = math.degrees(azim_2P)
	# print('azim_2_degrees',azim_2_degrees,'azim_2P_degrees',azim_2P_degrees)
	# max_range_for_2 = azim_2_degrees + 45.00
	# min_range_for_2 = azim_2_degrees - 45.00
	# print('max_range_for_2',max_range_for_2,'min_range_for_2',min_range_for_2)
	# if (azim_2P_degrees >= min_range_for_2 and azim_2P_degrees <= max_range_for_2):
		# # if (mag_2P < mag_2):
			# # #polygon is between point 1 and 2 from point 1's view?
			# # polygon_in_btw = True
		# #project vec_2P onto vec_2
		# dot_product = pygplates.Vector3D.dot(local_vec_2P, local_vec_2)
		# print('dot_product',dot_product,'local_vec_2',local_vec_2.get_magnitude(),'distance_btw_2_and_p',distance_btw_2_and_p)
		# # if (dot_product <= local_vec_2.get_magnitude()):
			# # polygon_in_btw = True
		# if (distance_btw_1_and_2 > distance_btw_2_and_p):
			# polygon_in_btw = True
	# return polygon_in_btw


# def is_small_circle_crossing_across_polygon(small_circle_boundary,polygon):
	# if (polygon.partition(small_circle_boundary) == pygplates.PolygonOnSphere.PartitionResult.inside):
		# length = supporting.calculate_the_actual_length_of_a_line_in_km(new_line)
		# #length = new_line.get_arc_length()*pygplates.Earth.mean_radius_in_kms
		# return True
	# elif (polygon.partition(small_circle_boundary) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
		# geometry_inside_polygon = []
		# geometry_outside_polygon = []
		# polygon.partition(small_circle_boundary, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
		# if (len(geometry_inside_polygon) > 0):
			# return True
		# else:
			# return False
	# elif (polygon.partition(small_circle_boundary) == pygplates.PolygonOnSphere.PartitionResult.outside):
		# return False

# def is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, polygon_1, polygon_2, in_btw_polygon):
	# dist_1,polyline_segment_indx_1,_ = pygplates.GeometryOnSphere.distance(small_circle_boundary,polygon_1,return_closest_indices = True)
	# dist_2,polyline_segment_indx_2,_ = pygplates.GeometryOnSphere.distance(small_circle_boundary,polygon_2,return_closest_indices = True)
	# polyline_segment_indx_btw = -1
	# list_of_segment_intersecting_small_circle = []
	# list_of_segments = in_btw_polygon.get_segments()
	# # print('len(small_circle_boundary.to_lat_lon_list())',len(small_circle_boundary.to_lat_lon_list()))
	# # print(small_circle_boundary[0])
	# # print(small_circle_boundary[1])
	# in_btw_seg = None
	# for index_of_segment in range(0,len(list_of_segments)-1):
		# s = list_of_segments[index_of_segment]
		# start_pt = s.get_start_point()
		# end_pt = s.get_end_point()
		# temp_polyline_on_sphere = pygplates.PolylineOnSphere([start_pt,end_pt])
		# temp_dist_btw,temp_polyline_segment_indx_btw,_ = pygplates.GeometryOnSphere.distance(small_circle_boundary,temp_polyline_on_sphere,return_closest_indices = True)
		# if (temp_dist_btw == 0.00):
			# list_of_segment_intersecting_small_circle.append((temp_polyline_on_sphere,temp_polyline_segment_indx_btw))
	# if (dist_1 == 0.00 and dist_2 == 0.00):
		# #print("len(list_of_segment_intersecting_small_circle)",len(list_of_segment_intersecting_small_circle))
		# for temp_polyline_on_sphere,inx in list_of_segment_intersecting_small_circle:
			# if (polyline_segment_indx_1 >= inx and inx >= polyline_segment_indx_2 and polyline_segment_indx_1 > polyline_segment_indx_2):
				# polyline_segment_indx_btw = inx
				# in_btw_seg = temp_polyline_on_sphere
			# elif (polyline_segment_indx_1 <= inx and inx <= polyline_segment_indx_2 and polyline_segment_indx_1 < polyline_segment_indx_2):
				# polyline_segment_indx_btw = inx
				# in_btw_seg = temp_polyline_on_sphere
			# #print('polyline_segment_indx_1',polyline_segment_indx_1,'polyline_segment_indx_2',polyline_segment_indx_2,'polyline_segment_indx_btw',inx)
	# if (in_btw_seg is None):
		# for temp_polyline_on_sphere,inx in list_of_segment_intersecting_small_circle:
			# if (inx >= 0 and inx < 25):
				# if ((polyline_segment_indx_1 > 74 and polyline_segment_indx_2 < 24) or (polyline_segment_indx_2 > 74 and polyline_segment_indx_1 < 24)):
					# polyline_segment_indx_btw = inx
					# in_btw_seg = temp_polyline_on_sphere
			# elif (inx >= 98 and inx < 74):
				# if ((polyline_segment_indx_1 > 74 and polyline_segment_indx_2 < 24) or (polyline_segment_indx_2 > 74 and polyline_segment_indx_1 < 24)):
					# polyline_segment_indx_btw = inx
					# in_btw_seg = temp_polyline_on_sphere
		# #print('polyline_segment_indx_1',polyline_segment_indx_1,'polyline_segment_indx_2',polyline_segment_indx_2,'polyline_segment_indx_btw',inx)
	# if (in_btw_seg is None):
		# return False
	
	# dist_1,closest_point_on_small_circle_1,closest_point_on_polygon_1 = pygplates.GeometryOnSphere.distance(small_circle_boundary,polygon_1,return_closest_positions = True)
	# dist_2,closest_point_on_small_circle_2,closest_point_on_polygon_2 = pygplates.GeometryOnSphere.distance(small_circle_boundary,polygon_2,return_closest_positions = True)
	# dist_btw,closest_point_on_small_circle_in_btw,closest_point_on_in_btw_polygon = pygplates.GeometryOnSphere.distance(small_circle_boundary,in_btw_seg,return_closest_positions = True)
	# # print('closest_point_on_small_circle_1,closest_point_on_polygon_1',closest_point_on_small_circle_1,closest_point_on_polygon_1)
	# # print('closest_point_on_small_circle_2,closest_point_on_polygon_2',closest_point_on_small_circle_2,closest_point_on_polygon_2)
	# # print('closest_point_on_small_circle_in_btw,closest_point_on_in_btw_polygon',closest_point_on_small_circle_in_btw,closest_point_on_in_btw_polygon)
	# #relative position from point_1 to point_2
	# x1,y1,z1 = closest_point_on_small_circle_1.to_xyz()
	# x2,y2,z2 = closest_point_on_small_circle_2.to_xyz()
	# vec_12 = pygplates.Vector3D(x2-x1, y2-y1, z2-z1)
	# #relative position from point_2 to point_1
	# vec_21 = pygplates.Vector3D(x1-x2, y1-y2, z1-z2)
	# #relative position from point_1 to centroid of polygon
	# #centroid_of_polygon = polygon.get_interior_centroid()
	# cx,cy,cz = closest_point_on_small_circle_in_btw.to_xyz()
	# vec_1P = pygplates.Vector3D(cx-x1, cy-y1, cz-z1)
	# vec_2P = pygplates.Vector3D(cx-x2, cy-y2, cz-z2)
	# vec_P2 = (-1.00)*vec_2P
	# # print('vec_12+vec_2P',vec_12+vec_2P,'vec_1P',vec_1P)
	# # print('|vec_12|',vec_12.get_magnitude(),'|vec_1P|',vec_1P.get_magnitude(),'|vec_2P|',vec_2P.get_magnitude())
	# # print('vec_1P+vec_P2',vec_1P+vec_P2,'vec_12',vec_12)
	# # print('|vec_12| < |vec_1P|',vec_12.get_magnitude() < vec_1P.get_magnitude())
	# # print('|vec_12| > |vec_1P|',vec_12.get_magnitude() > vec_1P.get_magnitude())
	# l = [vec_12.get_magnitude(),vec_1P.get_magnitude(),vec_2P.get_magnitude()]
	# l.sort(reverse=True)
	# #print('l',l)
	# max_dist = l[0]
	# if (dist_1 == 0.00 and dist_2 == 0.00):
		# if (polyline_segment_indx_1 > polyline_segment_indx_btw and polyline_segment_indx_btw > polyline_segment_indx_2 and polyline_segment_indx_1 > polyline_segment_indx_2):
			# return True
		# elif (polyline_segment_indx_1 < polyline_segment_indx_btw and polyline_segment_indx_btw < polyline_segment_indx_2 and polyline_segment_indx_1 < polyline_segment_indx_2):
			# return True
		# elif (polyline_segment_indx_1 == polyline_segment_indx_btw and polyline_segment_indx_1 != polyline_segment_indx_2):
			# if (vec_1P.get_magnitude() == max_dist or vec_2P.get_magnitude() == max_dist):
				# return False
			# else:
				# return True
		# elif (polyline_segment_indx_2 == polyline_segment_indx_btw and polyline_segment_indx_1 != polyline_segment_indx_2):
			# if (vec_1P.get_magnitude() == max_dist or vec_2P.get_magnitude() == max_dist):
				# return False
			# else:
				# return True
		# elif (polyline_segment_indx_btw >= 0 and polyline_segment_indx_btw < 25):
			# if ((polyline_segment_indx_1 > 74 and polyline_segment_indx_2 < 24) or (polyline_segment_indx_2 > 74 and polyline_segment_indx_1 < 24)):
				# return True
			# else:
				# return False
		# elif (polyline_segment_indx_btw >= 98 and polyline_segment_indx_btw < 74):
			# if ((polyline_segment_indx_1 > 74 and polyline_segment_indx_2 < 24) or (polyline_segment_indx_2 > 74 and polyline_segment_indx_1 < 24)):
				# return True
			# else:
				# return False
		# else:
			# return False
	# else:
		# return False

# def identify_tectonic_motion_3(name_of_database_table_for_pairs_of_line_fts, name_of_database_table_for_tectonic_motion, name_of_database_table_for_MOR, rotation_model, line_features_collection, super_gdu_features_collection, cos_value_for_transform, threshold_overlap_len_in_km, begin_reconstruction_time, end_reconstruction_time, interval, reference, modelname,yearmonthday):
	# try:
		# params = config()
		# conn = psycopg2.connect(**params)
		# cur = conn.cursor()
		# record_cursor = conn.cursor()
		# line_cursor = conn.cursor()
		# MOR_record_cursor = conn.cursor()
		# reconstructed_super_gdu_features = []
		# reconstructed_line_features = []
		# dic_super_gdu_and_members_line_fts = {}
		# outputPointFeatureCollection = pygplates.FeatureCollection()
		# dic_super_gdu_and_members = {}
		# txt = """SELECT DISTINCT gdu_id_member FROM super_gdu_and_members_id WHERE super_gdu_id = {input_super_gdu_id} """
		# reconstruction_time = begin_reconstruction_time 
		# while (reconstruction_time > (end_reconstruction_time - interval)):
			# #clean up containers 
			# reconstructed_super_gdu_features[:] = []
			# reconstructed_line_features[:] = []
			# dic_super_gdu_and_members_line_fts.clear()
			# valid_SuperGDU_features = [superGDU_ft for superGDU_ft in super_gdu_features_collection if superGDU_ft.is_valid_at_time(reconstruction_time)]
			# valid_CON_OCN_line_features = [line_ft for line_ft in line_features_collection if line_ft.is_valid_at_time(reconstruction_time)]
			# for superGDU_ft in valid_SuperGDU_features:
				# superGDU_name = superGDU_ft.get_name()
				# represent_gdu_id = superGDU_ft.get_reconstruction_plate_id()
				# if (superGDU_name not in dic_super_gdu_and_members):
					# super_gdu_id = int(superGDU_name)
					# sql = txt.format(input_super_gdu_id = super_gdu_id)
					# cur.execute(sql)
					# list_of_gdu_id_members = []
					# dic_super_gdu_and_members_line_fts[superGDU_name] = []
					# row = cur.fetchone()
					# while (row is not None):
						# gdu_id_member = int(row[0])
						# list_of_gdu_id_members.append(gdu_id_member)
						# selected_CON_OCN_line_features = [line_ft for line_ft in valid_CON_OCN_line_features if line_ft.get_reconstruction_plate_id() == gdu_id_member]
						# if (len(selected_CON_OCN_line_features) > 0):
							# dic_super_gdu_and_members_line_fts[superGDU_name] = dic_super_gdu_and_members_line_fts[superGDU_name] + selected_CON_OCN_line_features
						# row = cur.fetchone()
					# dic_super_gdu_and_members[superGDU_name] = list_of_gdu_id_members
				# else:
					# list_of_gdu_id_members = dic_super_gdu_and_members[superGDU_name]
					# selected_CON_OCN_line_features = [line_ft for line_ft in valid_CON_OCN_line_features if line_ft.get_reconstruction_plate_id() in list_of_gdu_id_members]
					# if (len(selected_CON_OCN_line_features) > 0):
						# dic_super_gdu_and_members_line_fts[superGDU_name] = selected_CON_OCN_line_features
			# #debug 
			# # if (reconstruction_time == 210):
				# # print (len(dic_super_gdu_and_members_line_fts['62726']))
				# # for ft in dic_super_gdu_and_members_line_fts['62726']:
					# # print(ft.get_name())
				# # print (len(dic_super_gdu_and_members_line_fts['62281']))
				# # for ft in dic_super_gdu_and_members_line_fts['62281']:
					# # print(ft.get_name())
				# # exit()
			# #reconstructed features
			# if (reference is not None):
				# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# else:
				# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,group_with_feature = True)
			# final_reconstructed_polygon_features = supporting.find_final_reconstructed_geometries(reconstructed_super_gdu_features,pygplates.PolygonOnSphere)
			# already_processed = []
			# for first_superGDU_ft,first_superGDU in final_reconstructed_polygon_features:
				# first_superGDU_name = first_superGDU_ft.get_name()
				# first_superGDU_represent_id = first_superGDU_ft.get_reconstruction_plate_id()
				# for second_superGDU_ft,second_superGDU in final_reconstructed_polygon_features:
					# second_superGDU_name = second_superGDU_ft.get_name()
					# k = first_superGDU_ft.get_feature_id().get_string()+'_'+second_superGDU_ft.get_feature_id().get_string()
					# re_k = second_superGDU_ft.get_feature_id().get_string()+'_'+first_superGDU_ft.get_feature_id().get_string()
					# if ((first_superGDU_name != second_superGDU_name) and (k not in already_processed) and (re_k not in already_processed) and (first_superGDU_name in dic_super_gdu_and_members_line_fts and second_superGDU_name in dic_super_gdu_and_members_line_fts)):
						# already_processed.append(k)
						# second_superGDU_represent_id = second_superGDU_ft.get_reconstruction_plate_id()
						# total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,first_superGDU_represent_id,second_superGDU_represent_id, reconstruction_time, reference)
						# if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
							# E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
							# smallest_circle_angular_radius_degrees = 179.00
							# while (smallest_circle_angular_radius_degrees > 0.00):
								# small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
								# dist_to_first = pygplates.GeometryOnSphere.distance(first_superGDU, small_circle_boundary)
								# dist_to_second = pygplates.GeometryOnSphere.distance(second_superGDU, small_circle_boundary)
								# dist_from_first_to_second = pygplates.GeometryOnSphere.distance(second_superGDU, first_superGDU)
								# intersecting_small_circle_boundary = None
								# in_btw_SuperGDUs = []
								# in_btw_SuperGDU_fts = []
								# if (dist_to_first == dist_to_second == 0.00):
									# is_valid = True
									# for any_superGDU_ft,any_superGDU in final_reconstructed_polygon_features:
										# any_superGDU_ft_name = any_superGDU_ft.get_name()
										# any_superGDU_ft_id = any_superGDU_ft.get_feature_id().get_name()
										# #if (any_superGDU_ft_name != first_superGDU_name and any_superGDU_ft_name != second_superGDU_name):
										# if (any_superGDU_ft_id != first_superGDU_ft.get_feature_id().get_string() and any_superGDU_ft_id != second_superGDU_ft.get_feature_id().get_string()):
											# dist_to_any_superGDU = pygplates.GeometryOnSphere.distance(any_superGDU, small_circle_boundary)
											# if (dist_to_any_superGDU == 0.00):
												# dist_from_any_to_first = pygplates.GeometryOnSphere.distance(first_superGDU, any_superGDU)
												# dist_from_any_to_second = pygplates.GeometryOnSphere.distance(second_superGDU, any_superGDU)
												
												# if (dist_from_first_to_second > dist_from_any_to_first and dist_from_first_to_second > dist_from_any_to_second):
													# is_valid = False
													# in_btw_SuperGDUs.append(any_superGDU)
													# in_btw_SuperGDU_fts.append(any_superGDU_ft)
												
												# # if (is_line_crossing_polygon(second_superGDU.get_interior_centroid(),first_superGDU.get_interior_centroid(),any_superGDU,0.00)):
													# # is_valid = False
													# # in_btw_SuperGDU = any_superGDU
													# # in_btw_SuperGDU_ft = any_superGDU_ft
												
										# # if (is_valid == False):
											# # break
									# intersecting_small_circle_boundary = small_circle_boundary
								# #debug 
								# # if (((first_superGDU_represent_id == 10041 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10041)) and intersecting_small_circle_boundary is not None):
									# # #temp_ft_collection = pygplates.FeatureCollection()
									# # # if (len(in_btw_SuperGDU_fts) > 0):
										# # # for in_btw_SuperGDU_ft in in_btw_SuperGDU_fts:
											# # # print('in_btw_SuperGDU_ft.get_reconstruction_plate_id',in_btw_SuperGDU_ft.get_reconstruction_plate_id())
											# # # print('in_btw_SuperGDU_ft.get_name()',in_btw_SuperGDU_ft.get_name())
										# # #temp_ft_collection.add(in_btw_SuperGDU_ft)
									# # print('intersecting_small_circle_boundary',intersecting_small_circle_boundary)
									# # print('smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
								# if (intersecting_small_circle_boundary is not None):
									# #obtain list_of CON-OCN line features
									# line_features_from_first_SuperGDU = dic_super_gdu_and_members_line_fts[first_superGDU_name]
									# line_features_from_second_SuperGDU = dic_super_gdu_and_members_line_fts[second_superGDU_name]
									# #print('len(line_features_from_first_SuperGDU),first_superGDU_name',len(line_features_from_first_SuperGDU),first_superGDU_name)
									# #print('len(line_features_from_second_SuperGDU),second_superGDU_name',len(line_features_from_second_SuperGDU),second_superGDU_name)
									# reconstructed_line_features[:] = []
									# if (reference is not None):
										# pygplates.reconstruct(line_features_from_first_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
									# else:
										# pygplates.reconstruct(line_features_from_first_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
									# final_reconstructed_first_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
									# reconstructed_line_features[:] = []
									# if (reference is not None):
										# pygplates.reconstruct(line_features_from_second_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
									# else:
										# pygplates.reconstruct(line_features_from_second_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
									# final_reconstructed_second_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
									# #find all lines from each SuperGDU that also intersect small_circle_boundary
									# list_of_intersecting_lines_from_first_SuperGDU = []
									# list_of_intersecting_lines_from_second_SuperGDU = []
									# for first_line_ft,first_line in final_reconstructed_first_line_features:
										# distance_to_first = pygplates.GeometryOnSphere.distance(first_line,intersecting_small_circle_boundary)
										# #print('distance_to_first',distance_to_first)
										# if (distance_to_first == 0.00):
											# list_of_intersecting_lines_from_first_SuperGDU.append((first_line_ft, first_line))
									# for second_line_ft,second_line in final_reconstructed_second_line_features:
										# distance_to_second = pygplates.GeometryOnSphere.distance(second_line,intersecting_small_circle_boundary)
										# #print('distance_to_second',distance_to_second)
										# if (distance_to_second == 0.00):
											# list_of_intersecting_lines_from_second_SuperGDU.append((second_line_ft, second_line))
									# #print('len(final_reconstructed_first_line_features)',len(final_reconstructed_first_line_features))
									# #print('len(final_reconstructed_second_line_features)',len(final_reconstructed_second_line_features))
									# #print('first_superGDU_represent_id,len(list_of_intersecting_lines_from_first_SuperGDU),degrees',first_superGDU_represent_id,len(list_of_intersecting_lines_from_first_SuperGDU),smallest_circle_angular_radius_degrees)
									# #print('second_superGDU_represent_id,len(list_of_intersecting_lines_from_second_SuperGDU)',second_superGDU_represent_id,len(list_of_intersecting_lines_from_second_SuperGDU))
									# min_distance = -1.00
									# most_appropriate_second_ft, most_appropriate_second_line = None, None
									# most_appropriate_first_ft, most_appropriate_first_line = None, None
									# pairs_of_lines_btw_GDUs = []
									# list_of_invalid_pairs_name = []
									# found_valid_pair = False
									# if (len(list_of_intersecting_lines_from_first_SuperGDU) > 0 and len(list_of_intersecting_lines_from_second_SuperGDU) > 0):
										# for first_line_ft,first_line in list_of_intersecting_lines_from_first_SuperGDU:
											# centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
											# for second_line_ft,second_line in list_of_intersecting_lines_from_second_SuperGDU:
												# centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
												
												# is_pair_of_lines_valid = True
												# pair_of_line_ft_names = first_line_ft.get_name()+'_'+second_line_ft.get_name()
												# inversed_pair_of_line_ft_names = second_line_ft.get_name()+'_'+first_line_ft.get_name()
												# if ((pair_of_line_ft_names in list_of_invalid_pairs_name) or (inversed_pair_of_line_ft_names in list_of_invalid_pairs_name)):
													# is_pair_of_lines_valid = False
												# #debug
												# #if ((first_superGDU_represent_id == 10041 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10041)):
													# #print('first_line_ft',first_line_ft.get_name(),'second_line_ft',second_line_ft.get_name())
												# if (len(in_btw_SuperGDUs) > 0 and is_pair_of_lines_valid == True):
													# #debug
													
													# for i in range(0,len(in_btw_SuperGDUs)):
														# # if ((first_superGDU_represent_id == 10041 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10041)):
														
															# # print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name())
														# in_btw_SuperGDU_ft = in_btw_SuperGDU_fts[i]
														# in_btw_SuperGDU = in_btw_SuperGDUs[i]
														# distance_from_first_line_to_other_SuperGDU = pygplates.GeometryOnSphere.distance(centroid_of_first_line, in_btw_SuperGDU)
														# distance_from_second_line_to_other_SuperGDU = pygplates.GeometryOnSphere.distance(centroid_of_second_line, in_btw_SuperGDU)
														# distance_btw_two_centroids = pygplates.GeometryOnSphere.distance(centroid_of_first_line,centroid_of_second_line)
														# #debug
														# # if ((first_superGDU_represent_id == 10041 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10041)):
															# # print('distance_from_first_line_to_other_SuperGDU',distance_from_first_line_to_other_SuperGDU)
															# # print('distance_from_second_line_to_other_SuperGDU',distance_from_second_line_to_other_SuperGDU)
															# # print('distance_btw_two_centroids',distance_btw_two_centroids)
													   
														# # if (distance_from_first_line_to_other_SuperGDU < distance_btw_two_centroids and distance_from_second_line_to_other_SuperGDU < distance_btw_two_centroids):
															# # is_pair_of_lines_valid = False
														# # if ((first_superGDU_represent_id == 10041 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10041)):
															# # print('is_pair_of_lines_valid',is_pair_of_lines_valid)
														# if (is_pair_of_lines_valid == True):
															# result,_ = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,in_btw_SuperGDU,0.00)
															# # #debug
															# # if ((first_superGDU_represent_id == 10310 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10310)):
																# # print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name())
																# # print('is_line_crossing_polygon',result)
																# # print('first_line_ft name',first_line_ft.get_name())
																# # print('second_line_ft name',second_line_ft.get_name())
																# # new_line = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
																# # print('in_btw_SuperGDU.partition(new_line)',in_btw_SuperGDU.partition(new_line))
																# # if ((first_line_ft.get_name() == 'GPlates-1f685ada-08b1-4156-a6a1-3077fe74904e' and second_line_ft.get_name() == 'GPlates-17051444-08ff-4478-a12a-48aa92582b87') or (first_line_ft.get_name() == 'GPlates-17051444-08ff-4478-a12a-48aa92582b87' and second_line_ft.get_name() == 'GPlates-1f685ada-08b1-4156-a6a1-3077fe74904e')):
																	# # #new_line = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
																	# # if (in_btw_SuperGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																		# # geometry_inside_polygon = []
																		# # geometry_outside_polygon = []
																		# # in_btw_SuperGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
																		# # print('geometry_inside_polygon', geometry_inside_polygon())
																		# # if (len(geometry_inside_polygon) > 0):
																			# # print('geometry_inside_polygon', geometry_inside_polygon())
																			# # total_intersecting_length = 0.00
																			# # boundary_of_polygon = pygplates.PolylineOnSphere(in_btw_SuperGDU.to_lat_lon_list())
																			# # temp_ft_collection = pygplates.FeatureCollection()
																			# # for geometry in geometry_inside_polygon:
																				# # #length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
																				# # distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
																				# # total_intersecting_length = total_intersecting_length + distance
																				# # print('total_intersecting_length',total_intersecting_length)
																				# # print('geometry',geometry)
																				# # inside_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, geometry, name = in_btw_SuperGDU_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = in_btw_SuperGDU_ft.get_reconstruction_plate_id())
																				# # temp_ft_collection.add(inside_ft)
																			# # pygplates.reverse_reconstruct(temp_ft_collection,rotation_model,reconstruction_time,reference)
																			# # temp_ft_collection.add(second_line_ft)
																			# # temp_ft_collection.write("geometry_inside_superGDU_AFR_ASI_5Ma.gpml")
																			# # exit()
															# if (result == True):
																# is_pair_of_lines_valid = False
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
														# if (is_pair_of_lines_valid == False):
															# break
												# if (is_pair_of_lines_valid == True):
													# if (dist_from_first_to_second == 0.00):
														# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,0.00)
														# if (result == False):
															# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,0.00)
															
															# if (result == True):
																# is_pair_of_lines_valid = False
																# if(total_len_inside <= threshold_overlap_len_in_km):
																	# pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
																# else:
																	# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
														# else:
															# is_pair_of_lines_valid = False
															# if(total_len_inside <= threshold_overlap_len_in_km):
																# pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
															# else:
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
													# else:
														# # if ((first_line_ft.get_name() == 'GPlates-1f685ada-08b1-4156-a6a1-3077fe74904e' and second_line_ft.get_name() == 'GPlates-17051444-08ff-4478-a12a-48aa92582b87') or (first_line_ft.get_name() == 'GPlates-17051444-08ff-4478-a12a-48aa92582b87' and second_line_ft.get_name() == 'GPlates-1f685ada-08b1-4156-a6a1-3077fe74904e')):
															# # new_line = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
															# # print('first_superGDU.partition(new_line)',first_superGDU.partition(new_line))
															# # if (first_superGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																# # geometry_inside_polygon = []
																# # geometry_outside_polygon = []
																# # first_superGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
																# # if (len(geometry_inside_polygon) > 0):
																	# # total_intersecting_length = 0.00
																	# # boundary_of_polygon = pygplates.PolylineOnSphere(first_superGDU.to_lat_lon_list())
																	# # temp_ft_collection = pygplates.FeatureCollection()
																	# # for geometry in geometry_inside_polygon:
																		# # #length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
																		# # distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
																		# # total_intersecting_length = total_intersecting_length + distance
																		# # print('total_intersecting_length',total_intersecting_length, 'geometry_inside_polygon', geometry_inside_polygon)
																		# # print('geometry',geometry)
																		# # inside_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, geometry, name = first_superGDU_name, description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_superGDU_ft.get_reconstruction_plate_id())
																		# # temp_ft_collection.add(inside_ft)
																	# # #bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, boundary_of_polygon, name = first_superGDU_name, valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_superGDU_represent_id)
																	# # print('is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,30.00)',is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,30.00))
																	# # pygplates.reverse_reconstruct(temp_ft_collection,rotation_model,reconstruction_time,reference)
																	# # temp_ft_collection.add(second_line_ft)
																	# # temp_ft_collection.write("geometry_inside_first_superGDU_10310_at_100Ma.gpml")
																	# # exit()
															# # if (second_superGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																# # geometry_inside_polygon = []
																# # geometry_outside_polygon = []
																# # second_superGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
																# # if (len(geometry_inside_polygon) > 0):
																	# # total_intersecting_length = 0.00
																	# # boundary_of_polygon = pygplates.PolylineOnSphere(second_superGDU.to_lat_lon_list())
																	# # for geometry in geometry_inside_polygon:
																		# # #length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
																		# # distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
																		# # total_intersecting_length = total_intersecting_length + distance
																	# # print(total_intersecting_length)
																	# # exit()
														# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,20.00)
														
														# #print('is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,20.00)',result)
														# if (result == False):
															# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,20.00)
															
															# #print('is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,20.00)',result)
															# if (result == True):
																# if(total_len_inside <= threshold_overlap_len_in_km):
																	# pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
																# else:
																	# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
																# is_pair_of_lines_valid = False
														# else:
															# if(total_len_inside <= threshold_overlap_len_in_km):
																# pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
															# else:
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# is_pair_of_lines_valid = False
												# if (is_pair_of_lines_valid == True):
													# pairs_of_lines_btw_GDUs.append((0.00,first_line_ft,first_line,second_line_ft,second_line))
													# found_valid_pair = True
													# break
											# if (found_valid_pair == True):
												# break
													# # dist = pygplates.GeometryOnSphere.distance(first_line, second_line)
													# # if (min_distance == -1.00):
														# # min_distance = dist
														# # most_appropriate_first_ft = first_line_ft
														# # most_appropriate_first_line = first_line
														# # most_appropriate_second_ft = second_line_ft
														# # most_appropriate_second_line = second_line
													# # elif (min_distance > -1.00 and min_distance > dist):
														# # min_distance = dist
														# # most_appropriate_first_ft = first_line_ft
														# # most_appropriate_first_line = first_line
														# # most_appropriate_second_ft = second_line_ft
														# # most_appropriate_second_line = second_line
												# # if (min_distance == 0.00):
													# # break
											# # if (min_distance == 0.00):
												# # break
										# if (len(pairs_of_lines_btw_GDUs) > 0):
											# #sort pairs_of_lines_btw_GDUs by total_len_inside
											# pairs_of_lines_btw_GDUs.sort()
											# record_w_minimum_len_inside = pairs_of_lines_btw_GDUs[0] 
											# #total_len_inside,first_line_ft,first_line,second_line_ft,second_line
											# most_appropriate_first_ft = record_w_minimum_len_inside[1]
											# most_appropriate_first_line = record_w_minimum_len_inside[2]
											# most_appropriate_second_ft = record_w_minimum_len_inside[3]
											# most_appropriate_second_line = record_w_minimum_len_inside[4]
										# if (most_appropriate_first_ft is not None and most_appropriate_second_ft is not None):
											# txt_1 = """INSERT INTO {input_name_of_database_table} (time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, first_line_name, second_line_name, first_line_gdu, second_line_gdu, at_angular_radius) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
											# sql_1 = txt_1.format(input_name_of_database_table = name_of_database_table_for_pairs_of_line_fts)
											# line_cursor.execute(sql_1, (reconstruction_time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(), most_appropriate_first_ft.get_reconstruction_plate_id(), most_appropriate_second_ft.get_reconstruction_plate_id(), smallest_circle_angular_radius_degrees))
											# temp_line_fts_collection = pygplates.FeatureCollection([most_appropriate_first_ft,most_appropriate_second_ft])
											# list_of_centroid_ft = find_centroid_features_from_line_features(temp_line_fts_collection,False,None)
											# first_centroid_ft = list_of_centroid_ft[0]
											# second_centroid_ft = list_of_centroid_ft[1]
											# tectonic_motion = supporting.relative_position_velocity_vectors_eval(rotation_model,first_centroid_ft,second_centroid_ft,reconstruction_time,interval,reference,cos_value_for_transform)#cos_value_for_transform defines the upper and lower limit angles between velocity_vector and position_vector
											# record_txt = """ INSERT INTO {input_name_of_database_table} (time,ref_ft_id,neighbour_ft_id,tectonic_motion) VALUES(%s, %s, %s, %s)"""
											# record_sql = record_txt.format(input_name_of_database_table = name_of_database_table_for_tectonic_motion)
											# record_cursor.execute(record_sql,(reconstruction_time,first_centroid_ft.get_description(),second_centroid_ft.get_description(),tectonic_motion.name))
											# conn.commit()
											# if (tectonic_motion.name == 'Divergence' or tectonic_motion.name == 'Oblique_divergence'):
												# _,chosen_pt_1,_ = pygplates.GeometryOnSphere.distance(most_appropriate_first_line,small_circle_boundary,return_closest_positions=True)
												# _,chosen_pt_2,_ = pygplates.GeometryOnSphere.distance(most_appropriate_second_line,small_circle_boundary,return_closest_positions=True)
												# #find MOR location
												# MOR_location = tm.find_the_mid_of_two_PointOnSphere(chosen_pt_1,chosen_pt_2)
												# great_circle_arc = pygplates.GreatCircleArc(MOR_location,E_pole)
												# normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
												# MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, MOR_location, valid_time = (reconstruction_time,0.00))
												# MOR_location_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
												# #MOR_location_ft.set_name(key)
												# side_1 = MOR_topology.classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1)
												# side_2 = MOR_topology.classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2)
												# if (side_1 == 'left' and side_2 == 'right'):
													# MOR_location_ft.set_left_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# MOR_location_ft.set_right_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
												# elif (side_1 == 'right' and side_2 == 'left'):
													# MOR_location_ft.set_left_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# MOR_location_ft.set_right_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
												# else:
													# print("Error unexpected values for side_1 and side_2")
													# print("side_1, side_2", side_1, side_2)
													# print(MOR_topology.calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1))
													# print(MOR_topology.calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2))
													# exit()
												# MOR_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
												# MOR_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,first_line_name,second_line_name,at_angular_radius) VALUES(%s, %s, %s, %s, %s, %s, %s, %s,%s)"""
												# MOR_record_sql = MOR_record_txt.format(input_name_of_database_table = name_of_database_table_for_MOR)
												# #print(MOR_record_sql)
												# #print((reconstruction_time,MOR_location_ft.get_feature_id().get_string(),first_superGDU_represent_id,second_superGDU_represent_id,first_superGDU_name,second_superGDU_name,most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(), smallest_circle_angular_radius_degrees))
												# MOR_record_cursor.execute(MOR_record_sql,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(),smallest_circle_angular_radius_degrees))
												
												# #list_of_MOR_locations.append((at_age,MOR_location_ft.get_feature_id().get_string(),MOR_location_ft.get_left_plate(),MOR_location_ft.get_right_plate(),smallest_circle_angular_radius_degrees))
												# outputPointFeatureCollection.add(MOR_location_ft)
											# conn.commit()
											# print("reconstruction_time,reference_feature_id,neighbour_ft_id,tectonic_motion")
											# print(reconstruction_time,first_centroid_ft.get_description(),second_centroid_ft.get_description(),tectonic_motion.name)
								# smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.00
			# if (len(outputPointFeatureCollection) > 0):
				# if (reference is not None):
					# pygplates.reverse_reconstruct(outputPointFeatureCollection,rotation_model,reconstruction_time,reference)
				# else:
					# pygplates.reverse_reconstruct(outputPointFeatureCollection,rotation_model,reconstruction_time)
			# #update reconstruction_time
			# reconstruction_time = reconstruction_time - interval
		# if (len(outputPointFeatureCollection) > 0):
			# outputPointFeatureCollection.write("MOR_features_from_"+modelname+"_"+yearmonthday+".shp")
			# outputPointFeatureCollection.write("MOR_features_from_"+modelname+"_"+yearmonthday+".gpml")
	# except(psycopg2.DatabaseError) as error:
		# print("Error in identify_tectonic_motion_3 related to Database")
		# print(error)
		# exit()
	# finally:
		# conn.close()

# def test_is_any_SuperGDU_btw_a_pair_of_line_features(line_ft_1,line_ft_2,rotation_model,reference,reconstruction_time,E_pole,smallest_circle_angular_radius_degrees,super_gdu_features_collection):
	# small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
	# #reconstructed all features to the reconstruction_time
	# reconstructed_super_gdu_features = []
	# reconstructed_line_features = []
	# valid_SuperGDU_features = [superGDU_ft for superGDU_ft in super_gdu_features_collection if superGDU_ft.is_valid_at_time(reconstruction_time)]
	# #reconstructed features
	# if (reference is not None):
		# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	# else:
		# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,group_with_feature = True)
	# final_reconstructed_polygon_features = supporting.find_final_reconstructed_geometries(reconstructed_super_gdu_features,pygplates.PolygonOnSphere)
	# if (reference is not None):
		# pygplates.reconstruct([line_ft_1],rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	# else:
		# pygplates.reconstruct([line_ft_1],rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
	# final_reconstructed_first_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
	# first_line_ft, first_line = final_reconstructed_first_line_features[0]
	# reconstructed_line_features[:] = []
	# if (reference is not None):
		# pygplates.reconstruct([line_ft_2],rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
	# else:
		# pygplates.reconstruct([line_ft_2],rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
	# final_reconstructed_second_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
	# second_line_ft, second_line = final_reconstructed_second_line_features[0]
	# first_SuperGDU = None
	# second_SuperGDU = None
	# first_SuperGDU_ft = None
	# second_SuperGDU_ft = None 
	# for SuperGDU_ft,SuperGDU in final_reconstructed_polygon_features:
		# if (pygplates.GeometryOnSphere.distance(SuperGDU,first_line) == 0.00):
			# first_SuperGDU = SuperGDU
			# first_SuperGDU_ft = SuperGDU_ft
		# if (pygplates.GeometryOnSphere.distance(SuperGDU,second_line) == 0.00):
			# second_SuperGDU = SuperGDU
			# second_SuperGDU_ft = SuperGDU_ft
		# # if (SuperGDU_ft.get_name() == '63088'):
			# # print('distance',pygplates.GeometryOnSphere.distance(SuperGDU,first_line))
	# print(first_SuperGDU_ft.get_name(),first_SuperGDU_ft.get_reconstruction_plate_id())
	# print(second_SuperGDU_ft.get_name(),second_SuperGDU_ft.get_reconstruction_plate_id())
	# print("distance btw two SuperGDUs",pygplates.GeometryOnSphere.distance(first_SuperGDU,second_SuperGDU))
	# print("distance btw small_circle_boundary and first_line",pygplates.GeometryOnSphere.distance(first_line,small_circle_boundary))
	# print("distance btw small_circle_boundary and second_line",pygplates.GeometryOnSphere.distance(second_line,small_circle_boundary))
	# temp_ft_collection = pygplates.FeatureCollection()
	# for in_btw_SuperGDU_ft,in_btw_SuperGDU in final_reconstructed_polygon_features:
		# if (in_btw_SuperGDU_ft.get_feature_id() != first_SuperGDU_ft.get_feature_id() and in_btw_SuperGDU_ft.get_feature_id() != second_SuperGDU_ft.get_feature_id()):
			# if (pygplates.GeometryOnSphere.distance(in_btw_SuperGDU,small_circle_boundary) == 0.00):
				# print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name())
				# # result = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_SuperGDU, second_SuperGDU, in_btw_SuperGDU)
				# # if (result == True):
					# # print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name(),in_btw_SuperGDU_ft.get_feature_id().get_string())
					# # print('in_btw_SuperGDU.get_area()',in_btw_SuperGDU.get_area())
					# # print('is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary for SuperGDU polygon',result)
				# # if (in_btw_SuperGDU_ft.get_name() == '63513'):
					# # print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name(),in_btw_SuperGDU_ft.get_feature_id().get_string())
					# # print('in_btw_SuperGDU.get_area()',in_btw_SuperGDU.get_area())
					# # print('is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary for SuperGDU polygon',result)
					# # #r,_ = is_line_crossing_polygon(temp_centroid_of_first_SuperGDU,temp_centroid_of_second_SuperGDU,any_superGDU,0.00)
				# #print('first_line_ft name',first_line_ft.get_name())
				# #print('second_line_ft name',second_line_ft.get_name())
				# centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
				# centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
				# result = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_line, second_line, in_btw_SuperGDU)
				# if (result == True):
					# print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name(),in_btw_SuperGDU_ft.get_feature_id().get_string())
					# print('in_btw_SuperGDU.get_area()',in_btw_SuperGDU.get_area())
					# print('is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary for line features using lines',result)
					# # distance_1,intersecting_point_w_first_SuperGDU,_ = pygplates.GeometryOnSphere.distance(first_line,small_circle_boundary,return_closest_positions = True)
					# # #print('distance between in_btw_SuperGDU and first_SuperGDU',distance_1)
					# # #print('first_SuperGDU == in_btw_SuperGDU',first_SuperGDU == in_btw_SuperGDU)
					# # distance_2,intersecting_point_w_second_SuperGDU,_ = pygplates.GeometryOnSphere.distance(second_line,small_circle_boundary,return_closest_positions = True)
					# # #print('distance between in_btw_SuperGDU and first_SuperGDU',pygplates.GeometryOnSphere.distance(second_SuperGDU,in_btw_SuperGDU))
					# # distance_3,intersecting_point_w_in_btw_SuperGDU,_ = pygplates.GeometryOnSphere.distance(in_btw_SuperGDU,small_circle_boundary,return_closest_positions = True)
					# # output_in_btw_SuperGDU_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, in_btw_SuperGDU, name = 'in_btw_'+in_btw_SuperGDU_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = in_btw_SuperGDU_ft.get_reconstruction_plate_id())
					# # temp_ft_collection.add(output_in_btw_SuperGDU_ft)
					# # intersecting_point_w_first_SuperGDU_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, intersecting_point_w_first_SuperGDU, name = 'intersecting_point_w_first_SuperGDU_'+first_line_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_line_ft.get_reconstruction_plate_id())
					# # intersecting_point_w_second_SuperGDU_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, intersecting_point_w_second_SuperGDU, name = 'intersecting_point_w_second_SuperGDU_'+second_line_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = second_line_ft.get_reconstruction_plate_id())
					# # intersecting_point_w_in_btw_SuperGDU_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, intersecting_point_w_in_btw_SuperGDU, name = 'intersecting_point_w_in_btw_SuperGDU_'+in_btw_SuperGDU_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = in_btw_SuperGDU_ft.get_reconstruction_plate_id())
					# # temp_ft_collection.add(intersecting_point_w_first_SuperGDU_ft)
					# # temp_ft_collection.add(intersecting_point_w_second_SuperGDU_ft)
					# # temp_ft_collection.add(intersecting_point_w_in_btw_SuperGDU_ft)
					# #print('second_SuperGDU == in_btw_SuperGDU', second_SuperGDU == in_btw_SuperGDU)
				# # if (in_btw_SuperGDU_ft.get_name() == '63513'):
					# # print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name(),in_btw_SuperGDU_ft.get_feature_id().get_string())
					# # print('in_btw_SuperGDU.get_area()',in_btw_SuperGDU.get_area())
					# # print('is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary for line features',result)
					# # #r,_ = is_line_crossing_polygon(temp_centroid_of_first_SuperGDU,temp_centroid_of_second_SuperGDU,any_superGDU,0.00)
					# # print('first_line_ft name',first_line_ft.get_name())
					# # print('second_line_ft name',second_line_ft.get_name())
				# # new_line = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
				# # if (in_btw_SuperGDU_ft.get_name() == '63513'):
					# # print('in_btw_SuperGDU.partition(new_line)',in_btw_SuperGDU.partition(new_line))
				# # if (in_btw_SuperGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
					# # geometry_inside_polygon = []
					# # geometry_outside_polygon = []
					# # in_btw_SuperGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
					# # if (in_btw_SuperGDU_ft.get_name() == '63513'):
						# # print('geometry_inside_polygon', geometry_inside_polygon)
					# # if (len(geometry_inside_polygon) > 0):
						# # if (in_btw_SuperGDU_ft.get_name() == '63513'):
							# # print('geometry_inside_polygon', geometry_inside_polygon)
						# # total_intersecting_length = 0.00
						# # boundary_of_polygon = pygplates.PolylineOnSphere(in_btw_SuperGDU.to_lat_lon_list())
						# # temp_ft_collection = pygplates.FeatureCollection()
						# # print("in_btw_SuperGDU_ft.get_name()",in_btw_SuperGDU_ft.get_name())
						# # for geometry in geometry_inside_polygon:
							# # length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
							# # #distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
							# # total_intersecting_length = total_intersecting_length + length
							# # print('total_intersecting_length',total_intersecting_length)
							# # print('geometry',geometry)
							# # inside_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, geometry, name = in_btw_SuperGDU_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = in_btw_SuperGDU_ft.get_reconstruction_plate_id())
							# # temp_ft_collection.add(inside_ft)
							# # pygplates.reverse_reconstruct(temp_ft_collection,rotation_model,reconstruction_time,reference)
							# # temp_ft_collection.add(second_line_ft)
							# # temp_ft_collection.write("geometry_inside_superGDU_AFR_ASI_5Ma.gpml")
				# # if (pygplates.GeometryOnSphere.distance(first_SuperGDU,second_SuperGDU) > 0.00):
					# # r,total_intersecting_length = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_SuperGDU,20.00)
					# # print("r",r,"total_intersecting_length within first_SuperGDU",total_intersecting_length)
					# # r,total_intersecting_length = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_SuperGDU,20.00)
					# # print("r",r,"total_intersecting_length within second_SuperGDU",total_intersecting_length)
				# # else:
					# # r,total_intersecting_length = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_SuperGDU,0.00)
					# # print("r",r,"total_intersecting_length within first_SuperGDU",total_intersecting_length)
					# # r,total_intersecting_length = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_SuperGDU,0.00)
					# # print("r",r,"total_intersecting_length within second_SuperGDU",total_intersecting_length)
	# first_SuperGDU_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, first_SuperGDU, name = first_SuperGDU_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_SuperGDU_ft.get_reconstruction_plate_id())
	# temp_ft_collection.add(first_SuperGDU_ft)
	# second_SuperGDU_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, second_SuperGDU, name = second_SuperGDU_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = second_SuperGDU_ft.get_reconstruction_plate_id())
	# temp_ft_collection.add(second_SuperGDU_ft)
	# pygplates.reverse_reconstruct(temp_ft_collection,rotation_model,reconstruction_time,700)
	# temp_ft_collection.write("in_btw_SuperGDU_first_and_second_line_fts_and_intersections.gpml")

# def identify_tectonic_motion_3_reverse(name_of_database_table_for_pairs_of_line_fts, name_of_database_table_for_tectonic_motion, name_of_database_table_for_MOR, rotation_model, line_features_collection, super_gdu_features_collection, cos_value_for_transform, threshold_overlap_len_in_km, begin_reconstruction_time, end_reconstruction_time, interval, reference, modelname,yearmonthday):
	# try:
		# params = config()
		# conn = psycopg2.connect(**params)
		# cur = conn.cursor()
		# record_cursor = conn.cursor()
		# line_cursor = conn.cursor()
		# MOR_record_cursor = conn.cursor()
		# reconstructed_super_gdu_features = []
		# reconstructed_line_features = []
		# dic_super_gdu_and_members_line_fts = {}
		# outputPointFeatureCollection = pygplates.FeatureCollection()
		# outputPointFeatureCollection_2 = pygplates.FeatureCollection()
		# dic_super_gdu_and_members = {}
		# txt = """SELECT DISTINCT gdu_id_member FROM super_gdu_and_members_id WHERE super_gdu_id = {input_super_gdu_id} """
		# reconstruction_time = end_reconstruction_time
		# while (reconstruction_time < (begin_reconstruction_time + interval)):
			# #clean up containers 
			# reconstructed_super_gdu_features[:] = []
			# reconstructed_line_features[:] = []
			# dic_super_gdu_and_members_line_fts.clear()
			# valid_SuperGDU_features = [superGDU_ft for superGDU_ft in super_gdu_features_collection if superGDU_ft.is_valid_at_time(reconstruction_time)]
			# valid_CON_OCN_line_features = [line_ft for line_ft in line_features_collection if line_ft.is_valid_at_time(reconstruction_time)]
			# for superGDU_ft in valid_SuperGDU_features:
				# superGDU_name = superGDU_ft.get_name()
				# represent_gdu_id = superGDU_ft.get_reconstruction_plate_id()
				# if (superGDU_name not in dic_super_gdu_and_members):
					# super_gdu_id = int(superGDU_name)
					# sql = txt.format(input_super_gdu_id = super_gdu_id)
					# cur.execute(sql)
					# list_of_gdu_id_members = []
					# dic_super_gdu_and_members_line_fts[superGDU_name] = []
					# row = cur.fetchone()
					# while (row is not None):
						# gdu_id_member = int(row[0])
						# list_of_gdu_id_members.append(gdu_id_member)
						# selected_CON_OCN_line_features = [line_ft for line_ft in valid_CON_OCN_line_features if line_ft.get_reconstruction_plate_id() == gdu_id_member]
						# if (len(selected_CON_OCN_line_features) > 0):
							# dic_super_gdu_and_members_line_fts[superGDU_name] = dic_super_gdu_and_members_line_fts[superGDU_name] + selected_CON_OCN_line_features
						# row = cur.fetchone()
					# dic_super_gdu_and_members[superGDU_name] = list_of_gdu_id_members
				# else:
					# list_of_gdu_id_members = dic_super_gdu_and_members[superGDU_name]
					# selected_CON_OCN_line_features = [line_ft for line_ft in valid_CON_OCN_line_features if line_ft.get_reconstruction_plate_id() in list_of_gdu_id_members]
					# if (len(selected_CON_OCN_line_features) > 0):
						# dic_super_gdu_and_members_line_fts[superGDU_name] = selected_CON_OCN_line_features
			# #debug 
			# # if (reconstruction_time == 210):
				# # print (len(dic_super_gdu_and_members_line_fts['62726']))
				# # for ft in dic_super_gdu_and_members_line_fts['62726']:
					# # print(ft.get_name())
				# # print (len(dic_super_gdu_and_members_line_fts['62281']))
				# # for ft in dic_super_gdu_and_members_line_fts['62281']:
					# # print(ft.get_name())
				# # exit()
			# #reconstructed features
			# if (reference is not None):
				# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# else:
				# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,group_with_feature = True)
			# final_reconstructed_polygon_features = supporting.find_final_reconstructed_geometries(reconstructed_super_gdu_features,pygplates.PolygonOnSphere)
			# already_processed = []
			# for first_superGDU_ft,first_superGDU in final_reconstructed_polygon_features:
				# first_superGDU_name = first_superGDU_ft.get_name()
				# first_superGDU_represent_id = first_superGDU_ft.get_reconstruction_plate_id()
				# for second_superGDU_ft,second_superGDU in final_reconstructed_polygon_features:
					# second_superGDU_name = second_superGDU_ft.get_name()
					# k = first_superGDU_ft.get_feature_id().get_string()+'_'+second_superGDU_ft.get_feature_id().get_string()
					# re_k = second_superGDU_ft.get_feature_id().get_string()+'_'+first_superGDU_ft.get_feature_id().get_string()
					# if ((first_superGDU_name != second_superGDU_name) and (k not in already_processed) and (re_k not in already_processed) and (first_superGDU_name in dic_super_gdu_and_members_line_fts and second_superGDU_name in dic_super_gdu_and_members_line_fts)):
						# already_processed.append(k)
						# second_superGDU_represent_id = second_superGDU_ft.get_reconstruction_plate_id()
						# total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,first_superGDU_represent_id,second_superGDU_represent_id, reconstruction_time, reference)
						# if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
							# E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
							# in_btw_SuperGDUs = []
							# in_btw_SuperGDU_fts = []
							# smallest_circle_angular_radius_degrees = 179.00
							# while (smallest_circle_angular_radius_degrees > 0.00):
								# #clean up the containers - because at each smallest_circle there will be a different set of SuperGDUs intersecting the small circle
								# #this might lead to the issue when either of the CON-OCN line feature is very long - part of the CON-OCN is valid and the other part is not
								# in_btw_SuperGDUs[:] = []
								# in_btw_SuperGDU_fts[:] = []
								# small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
								# dist_to_first, closest_pt_on_first_superGDU,_ = pygplates.GeometryOnSphere.distance(first_superGDU, small_circle_boundary, return_closest_positions = True)
								# dist_to_second, closest_pt_on_second_superGDU,_ = pygplates.GeometryOnSphere.distance(second_superGDU, small_circle_boundary, return_closest_positions = True)
								# dist_from_first_to_second = pygplates.GeometryOnSphere.distance(second_superGDU, first_superGDU)
								# intersecting_small_circle_boundary = None
								# if (dist_to_first == dist_to_second == 0.00):
									# for any_superGDU_ft,any_superGDU in final_reconstructed_polygon_features:
										# #is_valid = True
										# any_superGDU_ft_name = any_superGDU_ft.get_name()
										# any_superGDU_ft_id = any_superGDU_ft.get_feature_id().get_string()
										# #if (any_superGDU_ft_name != first_superGDU_name and any_superGDU_ft_name != second_superGDU_name):
										# if (any_superGDU_ft_id != first_superGDU_ft.get_feature_id() and any_superGDU_ft_id != second_superGDU_ft.get_feature_id()):
											# dist_to_any_superGDU, closest_pt_on_any_superGDU, _ = pygplates.GeometryOnSphere.distance(any_superGDU, small_circle_boundary, return_closest_positions = True)
											# if (dist_to_any_superGDU == 0.00):
												# #dist_from_any_to_first = pygplates.GeometryOnSphere.distance(first_superGDU, any_superGDU)
												# #dist_from_any_to_second = pygplates.GeometryOnSphere.distance(second_superGDU, any_superGDU)
												
												# #is_valid = False
												# in_btw_SuperGDUs.append(any_superGDU)
												# in_btw_SuperGDU_fts.append(any_superGDU_ft)
												
												# # if (dist_from_first_to_second > dist_from_any_to_first and dist_from_first_to_second > dist_from_any_to_second):
													# # is_valid = False
													# # in_btw_SuperGDUs.append(any_superGDU)
													# # in_btw_SuperGDU_fts.append(any_superGDU_ft)
												# # if (is_valid == True):
													# # temp_centroid_of_first_SuperGDU = first_superGDU.get_interior_centroid()
													# # temp_centroid_of_second_SuperGDU = second_superGDU.get_interior_centroid()
													# # #r,_ = is_line_crossing_polygon(temp_centroid_of_first_SuperGDU,temp_centroid_of_second_SuperGDU,any_superGDU,0.00)
													# # r = is_line_crossing_polygon_w_rel_position_vector(temp_centroid_of_first_SuperGDU,temp_centroid_of_second_SuperGDU,any_superGDU.get_interior_centroid())
													# # #r = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_superGDU, second_superGDU, any_superGDU)
													# # # if ((first_superGDU_represent_id == 10714 and second_superGDU_represent_id == 10817) or (first_superGDU_represent_id == 10817 and second_superGDU_represent_id == 10714)):
														# # # print("any_superGDU.get_name()",any_superGDU_ft.get_name())
														# # # print("any_superGDU_ft.get_reconstruction_plate_id()",any_superGDU_ft.get_reconstruction_plate_id())
														# # # print("result r",r)
														# # # print("smallest_circle_angular_radius_degrees",smallest_circle_angular_radius_degrees)
														# # #exit()
													# # if (r == True):
														# # is_valid = False
														# # in_btw_SuperGDUs.append(any_superGDU)
														# # in_btw_SuperGDU_fts.append(any_superGDU_ft)
												
												# # if (is_line_crossing_polygon(second_superGDU.get_interior_centroid(),first_superGDU.get_interior_centroid(),any_superGDU,0.00)):
													# # is_valid = False
													# # in_btw_SuperGDU = any_superGDU
													# # in_btw_SuperGDU_ft = any_superGDU_ft
												
									# intersecting_small_circle_boundary = small_circle_boundary
								# # #debug 
								# # if (((first_superGDU_represent_id == 10363 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10363)) and intersecting_small_circle_boundary is not None):
									# # #temp_ft_collection = pygplates.FeatureCollection()
									# # if (len(in_btw_SuperGDU_fts) > 0):
										# # for in_btw_SuperGDU_ft in in_btw_SuperGDU_fts:
											# # print('in_btw_SuperGDU_ft.get_reconstruction_plate_id',in_btw_SuperGDU_ft.get_reconstruction_plate_id())
											# # print('in_btw_SuperGDU_ft.get_name()',in_btw_SuperGDU_ft.get_name())
										# # #temp_ft_collection.add(in_btw_SuperGDU_ft)
									# # print('intersecting_small_circle_boundary',intersecting_small_circle_boundary)
									# # print('smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
								# if (intersecting_small_circle_boundary is not None):
									# #obtain list_of CON-OCN line features
									# line_features_from_first_SuperGDU = dic_super_gdu_and_members_line_fts[first_superGDU_name]
									# line_features_from_second_SuperGDU = dic_super_gdu_and_members_line_fts[second_superGDU_name]
									# #print('len(line_features_from_first_SuperGDU),first_superGDU_name',len(line_features_from_first_SuperGDU),first_superGDU_name)
									# #print('len(line_features_from_second_SuperGDU),second_superGDU_name',len(line_features_from_second_SuperGDU),second_superGDU_name)
									# reconstructed_line_features[:] = []
									# if (reference is not None):
										# pygplates.reconstruct(line_features_from_first_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
									# else:
										# pygplates.reconstruct(line_features_from_first_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
									# final_reconstructed_first_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
									# reconstructed_line_features[:] = []
									# if (reference is not None):
										# pygplates.reconstruct(line_features_from_second_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
									# else:
										# pygplates.reconstruct(line_features_from_second_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
									# final_reconstructed_second_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
									# #find all lines from each SuperGDU that also intersect small_circle_boundary
									# list_of_intersecting_lines_from_first_SuperGDU = []
									# list_of_intersecting_lines_from_second_SuperGDU = []
									# for first_line_ft,first_line in final_reconstructed_first_line_features:
										# distance_to_first = pygplates.GeometryOnSphere.distance(first_line,intersecting_small_circle_boundary)
										# #print('distance_to_first',distance_to_first)
										# if (distance_to_first == 0.00):
											# #confirm the line feature belongs to the SuperGDU --- think of the case of Madagascar and the AFR
											# approx_centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
											# distance_to_first_SuperGDU = pygplates.GeometryOnSphere.distance(approx_centroid_of_first_line,first_superGDU)
											# if (distance_to_first_SuperGDU == 0.00):
												# list_of_intersecting_lines_from_first_SuperGDU.append((first_line_ft, first_line))
									# for second_line_ft,second_line in final_reconstructed_second_line_features:
										# distance_to_second = pygplates.GeometryOnSphere.distance(second_line,intersecting_small_circle_boundary)
										# #print('distance_to_second',distance_to_second)
										# if (distance_to_second == 0.00):
											# #confirm the line feature belongs to the SuperGDU --- think of the case of Madagascar and the AFR
											# approx_centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
											# distance_to_second_SuperGDU = pygplates.GeometryOnSphere.distance(approx_centroid_of_second_line,second_superGDU)
											# if (distance_to_second_SuperGDU == 0.00):
												# list_of_intersecting_lines_from_second_SuperGDU.append((second_line_ft, second_line))
									# # print('len(final_reconstructed_first_line_features)',len(final_reconstructed_first_line_features))
									# # print('len(final_reconstructed_second_line_features)',len(final_reconstructed_second_line_features))
									# # if ((first_superGDU_represent_id == 10714 and second_superGDU_represent_id == 10817) or (first_superGDU_represent_id == 10817 and second_superGDU_represent_id == 10714)):
										# # print('first_superGDU_represent_id,len(list_of_intersecting_lines_from_first_SuperGDU),degrees',first_superGDU_represent_id,len(list_of_intersecting_lines_from_first_SuperGDU),smallest_circle_angular_radius_degrees)
										# # print('second_superGDU_represent_id,len(list_of_intersecting_lines_from_second_SuperGDU)',second_superGDU_represent_id,len(list_of_intersecting_lines_from_second_SuperGDU))
										# # print('len(in_btw_SuperGDUs)',len(in_btw_SuperGDUs))
									# min_distance = -1.00
									# most_appropriate_second_ft, most_appropriate_second_line = None, None
									# most_appropriate_first_ft, most_appropriate_first_line = None, None
									# pairs_of_lines_btw_GDUs = []
									# list_of_invalid_pairs_name = []
									# found_valid_pair = False
									# if (len(list_of_intersecting_lines_from_first_SuperGDU) > 0 and len(list_of_intersecting_lines_from_second_SuperGDU) > 0):
										# for first_line_ft,first_line in list_of_intersecting_lines_from_first_SuperGDU:
											# centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
											# for second_line_ft,second_line in list_of_intersecting_lines_from_second_SuperGDU:
												# centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
												# is_pair_of_lines_valid = True
												# pair_of_line_ft_names = first_line_ft.get_name()+'_'+second_line_ft.get_name()
												# inversed_pair_of_line_ft_names = second_line_ft.get_name()+'_'+first_line_ft.get_name()
												# if (first_line_ft.get_name() != second_line_ft.get_name()):
													# if ((pair_of_line_ft_names in list_of_invalid_pairs_name) or (inversed_pair_of_line_ft_names in list_of_invalid_pairs_name)):
														# is_pair_of_lines_valid = False
													# else:
														# is_pair_of_lines_valid = True
												# else:
													# is_pair_of_lines_valid = False
												# #debug
												# # if ((first_superGDU_represent_id == 10714 and second_superGDU_represent_id == 10817) or (first_superGDU_represent_id == 10817 and second_superGDU_represent_id == 10714)):
													# # print('first_line_ft',first_line_ft.get_name(),'second_line_ft',second_line_ft.get_name())
												# # if (len(in_btw_SuperGDUs) > 1 and is_pair_of_lines_valid == True):
													# # if ((first_superGDU_represent_id == 10363 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10363)):
														# # print('len(in_btw_SuperGDUs)',len(in_btw_SuperGDUs))
													# # is_pair_of_lines_valid = False
													# # list_of_invalid_pairs_name.append(pair_of_line_ft_names)
												# if (len(in_btw_SuperGDUs) > 0 and is_pair_of_lines_valid == True):
													# #debug
													
													# for i in range(0,len(in_btw_SuperGDUs)):
														# # print(i)
														# in_btw_SuperGDU_ft = in_btw_SuperGDU_fts[i]
														# in_btw_SuperGDU = in_btw_SuperGDUs[i]
														# #debug
														# # if ((first_superGDU_represent_id == 10714 and second_superGDU_represent_id == 10817) or (first_superGDU_represent_id == 10817 and second_superGDU_represent_id == 10714) ):
															# # print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name())
														# # in_btw_SuperGDU_ft = in_btw_SuperGDU_fts[i]
														# # in_btw_SuperGDU = in_btw_SuperGDUs[i]
														# # distance_from_first_line_to_other_SuperGDU = pygplates.GeometryOnSphere.distance(centroid_of_first_line, in_btw_SuperGDU)
														# # distance_from_second_line_to_other_SuperGDU = pygplates.GeometryOnSphere.distance(centroid_of_second_line, in_btw_SuperGDU)
														# # distance_btw_two_centroids = pygplates.GeometryOnSphere.distance(centroid_of_first_line,centroid_of_second_line)
														# # _, closest_pt_on_any_superGDU, _ = pygplates.GeometryOnSphere.distance(in_btw_SuperGDU, small_circle_boundary, return_closest_positions = True)
														# #debug
														# # if ((first_superGDU_represent_id == 10041 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10041)):
															# # print('distance_from_first_line_to_other_SuperGDU',distance_from_first_line_to_other_SuperGDU)
															# # print('distance_from_second_line_to_other_SuperGDU',distance_from_second_line_to_other_SuperGDU)
															# # print('distance_btw_two_centroids',distance_btw_two_centroids)
													
														# # if (distance_from_first_line_to_other_SuperGDU < distance_btw_two_centroids and distance_from_second_line_to_other_SuperGDU < distance_btw_two_centroids):
															# # is_pair_of_lines_valid = False
														# # if ((first_superGDU_represent_id == 10041 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10041)):
															# # print('is_pair_of_lines_valid',is_pair_of_lines_valid)
														# if (is_pair_of_lines_valid == True):
														
															# #result = is_line_crossing_polygon_w_rel_position_vector(centroid_of_first_line, centroid_of_second_line, closest_pt_on_any_superGDU)
															# result_2 = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(intersecting_small_circle_boundary, first_line, second_line, in_btw_SuperGDU)
															# result_3 = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_line, second_line, in_btw_SuperGDU)
															# # #debug
															# if ((first_superGDU_represent_id == 10439 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10439)):
																# if (smallest_circle_angular_radius_degrees == 101):
																	# if (pair_of_line_ft_names == 'GPlates-39226891-881e-45a0-b2fb-56a62f948ccf_GPlates-17051444-08ff-4478-a12a-48aa92582b87' or pair_of_line_ft_names == 'GPlates-17051444-08ff-4478-a12a-48aa92582b87_GPlates-39226891-881e-45a0-b2fb-56a62f948ccf'):
																		# print("E_pole",E_pole.to_lat_lon())
																		
																		# if (result_2 == True or result_3 == True):
																			# print('in_btw_SuperGDU',in_btw_SuperGDU_ft.get_name(),in_btw_SuperGDU_ft.get_feature_id().get_string())
																			# print('is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary w result_2',result_2)
																			# print('is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary w result_3',result_3)
																			# print('first_line_ft name',first_line_ft.get_name())
																			# print('second_line_ft name',second_line_ft.get_name())
																			# temp_ft_collection = pygplates.FeatureCollection()
																			# # for temp_superGDU_ft,temp_superGDU in final_reconstructed_polygon_features:
																				# # if (temp_superGDU_ft.get_name() == '64515'):
																					# # pygplates.reverse_reconstruct(temp_superGDU_ft, rotation_model, reconstruction_time, reference)
																					# # temp_ft_collection.add(temp_superGDU_ft)
																			
																			# # small_circle_boundary_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, intersecting_small_circle_boundary, description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = reference)
																			# # first_line_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, first_line, name = first_line_ft.get_name(), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_line_ft.get_reconstruction_plate_id())
																			# # second_line_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, second_line, name = second_line_ft.get_name(), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = second_line_ft.get_reconstruction_plate_id())
																			# # temp_ft_collection.add(small_circle_boundary_ft)
																			# # temp_ft_collection.add(first_line_ft)
																			# # temp_ft_collection.add(second_line_ft)
																			# # pygplates.reverse_reconstruct(temp_ft_collection, rotation_model, reconstruction_time, reference)
																			# # temp_ft_collection.write("small_circles_and_suspecting_pairs_of_CON_OCN_line_fts.gpml")
																			# # exit()
																
																# # new_line = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
																# # print('in_btw_SuperGDU.partition(new_line)',in_btw_SuperGDU.partition(new_line))
																# # if ((first_line_ft.get_name() == 'GPlates-b9e1bb88-9c63-4b26-b057-8695fa914430' and second_line_ft.get_name() == 'GPlates-ab5874d8-0ba6-44a8-aba9-b9f4a2b45827') or (first_line_ft.get_name() == 'GPlates-ab5874d8-0ba6-44a8-aba9-b9f4a2b45827' and second_line_ft.get_name() == 'GPlates-b9e1bb88-9c63-4b26-b057-8695fa914430')):
																	# # #new_line = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
																	# # if (in_btw_SuperGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																		# # geometry_inside_polygon = []
																		# # geometry_outside_polygon = []
																		# # in_btw_SuperGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
																		# # print('geometry_inside_polygon', geometry_inside_polygon)
																		# # if (len(geometry_inside_polygon) > 0):
																			# # print('geometry_inside_polygon', geometry_inside_polygon)
																			# # total_intersecting_length = 0.00
																			# # boundary_of_polygon = pygplates.PolylineOnSphere(in_btw_SuperGDU.to_lat_lon_list())
																			# # temp_ft_collection = pygplates.FeatureCollection()
																			# # for geometry in geometry_inside_polygon:
																				# # length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
																				# # #distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
																				# # total_intersecting_length = total_intersecting_length + length
																				# # print('total_intersecting_length',total_intersecting_length)
																				# # print('geometry',geometry)
																				# # # inside_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, geometry, name = in_btw_SuperGDU_ft.get_name(), description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = in_btw_SuperGDU_ft.get_reconstruction_plate_id())
																				# # # temp_ft_collection.add(inside_ft)
																			# # # pygplates.reverse_reconstruct(temp_ft_collection,rotation_model,reconstruction_time,reference)
																			# # # temp_ft_collection.add(second_line_ft)
																			# # # temp_ft_collection.write("geometry_inside_superGDU_AFR_ASI_5Ma.gpml")
																			# # exit()
															# if (result_2 == True):
																# is_pair_of_lines_valid = False
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# # else:
																# # list_of_SuperGDU_polygons_w_same_name = [temp_superGDU_polygon for temp_superGDU_ft, temp_superGDU_polygon in final_reconstructed_polygon_features if (temp_superGDU_ft.get_name() == in_btw_SuperGDU_ft.get_name() and temp_superGDU_ft.get_feature_id() != first_superGDU_ft.get_feature_id() and temp_superGDU_ft.get_feature_id() != second_superGDU_ft.get_feature_id())]
																# # for temp_superGDU_polygon in list_of_SuperGDU_polygons_w_same_name:
																	# # result_1 = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary,first_line,second_line,temp_superGDU_polygon)
																	# # if (result_1 == True):
																		# # is_pair_of_lines_valid = False
																		# # list_of_invalid_pairs_name.append(pair_of_line_ft_names)
																		# # break
														# if (is_pair_of_lines_valid == False):
															# break
												# if (is_pair_of_lines_valid == True):
													# if (dist_from_first_to_second == 0.00):
														# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,0.00)
														# if (result == False):
															# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,0.00)
															
															# if (result == True):
																# if (total_len_inside <= threshold_overlap_len_in_km):
																	# pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
																# else:
																	# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
																# is_pair_of_lines_valid = False
														# else:
															# if (total_len_inside <= threshold_overlap_len_in_km):
																# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,0.00)
																# if (result == True):
																	# if (total_len_inside <= threshold_overlap_len_in_km):
																		# pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
																	# else:
																		# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# else:
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# is_pair_of_lines_valid = False
														# #debug
														# # if ((first_line_ft.get_reconstruction_plate_id() == 11353 and second_line_ft.get_reconstruction_plate_id() == 10533) or (first_line_ft.get_reconstruction_plate_id() == 11353 and second_line_ft.get_reconstruction_plate_id() == 11353)):
															# # print("result,total_len_inside",result,total_len_inside)
															# # new_line = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
															
															# # print('first_superGDU_represent_id',first_superGDU_represent_id)
															# # print('second_superGDU_represent_id',second_superGDU_represent_id)
															# # print('in_btw_SuperGDU_fts',in_btw_SuperGDU_fts)
															# # if (len(in_btw_SuperGDU_fts) > 0):
																# # for btw_superGDU_ft in in_btw_SuperGDU_fts:
																	# # print (btw_superGDU_ft.get_reconstruction_plate_id())
															# # print('first_superGDU.partition(new_line)',first_superGDU.partition(new_line))
															# # print('first_superGDU_ft.get_feature_id().get_string()',first_superGDU_ft.get_feature_id().get_string())
															# # if (first_superGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																# # geometry_inside_polygon = []
																# # geometry_outside_polygon = []
																# # first_superGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
																# # print('len(geometry_inside_polygon)',len(geometry_inside_polygon))
																# # if (len(geometry_inside_polygon) > 0):
																	# # total_intersecting_length = 0.00
																	# # boundary_of_polygon = pygplates.PolylineOnSphere(first_superGDU.to_lat_lon_list())
																	# # temp_ft_collection = pygplates.FeatureCollection()
																	# # for geometry in geometry_inside_polygon:
																		# # length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
																		# # #distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
																		# # total_intersecting_length = total_intersecting_length + length
																		
																		# # print('geometry',geometry)
																		# # inside_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, geometry, name = first_superGDU_name, description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_superGDU_ft.get_reconstruction_plate_id())
																		# # temp_ft_collection.add(inside_ft)
																	# # #bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, boundary_of_polygon, name = first_superGDU_name, valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_superGDU_represent_id)
																	# # print('is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,30.00)',is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,30.00))
																	# # print('total_intersecting_length',total_intersecting_length, 'geometry_inside_polygon', geometry_inside_polygon)
																	# # pygplates.reverse_reconstruct(temp_ft_collection,rotation_model,reconstruction_time,reference)
																	# # temp_ft_collection.add(second_line_ft)
																	# # temp_ft_collection.write("geometry_inside_first_superGDU_10310_at_100Ma_3.gpml")
																	# #exit()
															# # if (second_superGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																# # geometry_inside_polygon = []
																# # geometry_outside_polygon = []
																# # second_superGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
																# # if (len(geometry_inside_polygon) > 0):
																	# # total_intersecting_length = 0.00
																	# # boundary_of_polygon = pygplates.PolylineOnSphere(second_superGDU.to_lat_lon_list())
																	# # for geometry in geometry_inside_polygon:
																		# # #length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
																		# # distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
																		# # total_intersecting_length = total_intersecting_length + distance
																	# # print(total_intersecting_length)
																	# #exit()
													# else:
														# # #debug
														# #if ((first_line_ft.get_name() == 'GPlates-a68ae568-64ea-4925-81ac-45e3e32d1c85' and second_line_ft.get_name() == 'GPlates-d7f2620e-868a-425f-961a-c199caa91433') or (first_line_ft.get_name() == 'GPlates-d7f2620e-868a-425f-961a-c199caa91433' and second_line_ft.get_name() == 'GPlates-a68ae568-64ea-4925-81ac-45e3e32d1c85')):
														# # if ((first_line_ft.get_reconstruction_plate_id() == 11353 and second_line_ft.get_reconstruction_plate_id() == 10533) or (first_line_ft.get_reconstruction_plate_id() == 11353 and second_line_ft.get_reconstruction_plate_id() == 11353)):
															# # temp_ft_collection = pygplates.FeatureCollection()
															# # new_line = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
															
															# # print('first_superGDU_represent_id',first_superGDU_represent_id)
															# # print('second_superGDU_represent_id',second_superGDU_represent_id)
															# # print('in_btw_SuperGDU_fts',in_btw_SuperGDU_fts)
															# # if (len(in_btw_SuperGDU_fts) > 0):
																# # for btw_superGDU_ft in in_btw_SuperGDU_fts:
																	# # print (btw_superGDU_ft.get_reconstruction_plate_id())
															# # print('first_superGDU.partition(new_line)',first_superGDU.partition(new_line))
															# # print('first_superGDU_ft.get_feature_id().get_string()',first_superGDU_ft.get_feature_id().get_string())
															# # if (first_superGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.outside):
																# # new_line_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, new_line, name = first_superGDU_name, description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = reference)
																# # temp_ft_collection.add(new_line_ft)
																# # pygplates.reverse_reconstruct(temp_ft_collection,rotation_model,reconstruction_time,reference)
																# # # temp_ft_collection.add(second_line_ft)
																# # temp_ft_collection.write("new_line_ft_btw_11353_10533_at_30Ma.gpml")
															# # elif (first_superGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																# # geometry_inside_polygon = []
																# # geometry_outside_polygon = []
																# # first_superGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
																# # print('len(geometry_inside_polygon)',len(geometry_inside_polygon))
																# # if (len(geometry_inside_polygon) > 0):
																	# # total_intersecting_length = 0.00
																	# # boundary_of_polygon = pygplates.PolylineOnSphere(first_superGDU.to_lat_lon_list())
																	# # temp_ft_collection = pygplates.FeatureCollection()
																	# # for geometry in geometry_inside_polygon:
																		# # length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
																		# # #distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
																		# # total_intersecting_length = total_intersecting_length + length
																		
																		# # print('geometry',geometry)
																		# # inside_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, geometry, name = first_superGDU_name, description = str(smallest_circle_angular_radius_degrees), valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_superGDU_ft.get_reconstruction_plate_id())
																		# # temp_ft_collection.add(inside_ft)
																	# # #bdn_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_continental_crust, boundary_of_polygon, name = first_superGDU_name, valid_time = (reconstruction_time, 0.00), reconstruction_plate_id = first_superGDU_represent_id)
																	# # print('is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,30.00)',is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,30.00))
																	# # print('total_intersecting_length',total_intersecting_length, 'geometry_inside_polygon', geometry_inside_polygon)
																	# # pygplates.reverse_reconstruct(temp_ft_collection,rotation_model,reconstruction_time,reference)
																	# # # temp_ft_collection.add(second_line_ft)
																	# # # temp_ft_collection.write("geometry_inside_first_superGDU_10310_at_100Ma_3.gpml")
																	# # #exit()
															# # if (second_superGDU.partition(new_line) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
																# # geometry_inside_polygon = []
																# # geometry_outside_polygon = []
																# # second_superGDU.partition(new_line, partitioned_geometries_inside = geometry_inside_polygon, partitioned_geometries_outside = geometry_outside_polygon)
																# # if (len(geometry_inside_polygon) > 0):
																	# # total_intersecting_length = 0.00
																	# # boundary_of_polygon = pygplates.PolylineOnSphere(second_superGDU.to_lat_lon_list())
																	# # for geometry in geometry_inside_polygon:
																		# # #length = supporting.calculate_the_actual_length_of_a_line_in_km(geometry)
																		# # distance = pygplates.GeometryOnSphere.distance(boundary_of_polygon,geometry)
																		# # total_intersecting_length = total_intersecting_length + distance
																	# # print(total_intersecting_length)
																	# #exit()
														# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,20.00)
														# # #debug
														# # if ((first_superGDU_represent_id == 10439 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10439)):
															# # if (smallest_circle_angular_radius_degrees == 101):
																# # if (pair_of_line_ft_names == 'GPlates-39226891-881e-45a0-b2fb-56a62f948ccf_GPlates-17051444-08ff-4478-a12a-48aa92582b87' or pair_of_line_ft_names == 'GPlates-17051444-08ff-4478-a12a-48aa92582b87_GPlates-39226891-881e-45a0-b2fb-56a62f948ccf'):
																	# # print('first_superGDU_represent_id',first_superGDU_represent_id)
																	# # print('is_line_crossing_polygon',result)
																	# # print('total_len_inside',total_len_inside)
																	# # print('first_line_ft name',first_line_ft.get_name())
																	# # print('second_line_ft name',second_line_ft.get_name())
																	# # exit()
														
														
														# #print('is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,20.00)',result,total_len_inside)
														# if (result == False):
															# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,20.00)
															
															# # #debug
															# # if ((first_superGDU_represent_id == 10439 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10439)):
																# # if (smallest_circle_angular_radius_degrees == 101):
																	# # if (pair_of_line_ft_names == 'GPlates-39226891-881e-45a0-b2fb-56a62f948ccf_GPlates-17051444-08ff-4478-a12a-48aa92582b87' or pair_of_line_ft_names == 'GPlates-17051444-08ff-4478-a12a-48aa92582b87_GPlates-39226891-881e-45a0-b2fb-56a62f948ccf'):
																		# # print('second_superGDU_represent_id',second_superGDU_represent_id)
																		# # print('is_line_crossing_polygon',result)
																		# # print('total_len_inside',total_len_inside)
																		# # print('first_line_ft name',first_line_ft.get_name())
																		# # print('second_line_ft name',second_line_ft.get_name())
																		# # exit()
															# #print('is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,20.00)',result,total_len_inside)
															# if (result == True):
																# # if (total_len_inside <= threshold_overlap_len_in_km):
																	# # pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
																# # else:
																	# # list_of_invalid_pairs_name.append(pair_of_line_ft_names)
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
																# is_pair_of_lines_valid = False
														# else:
															# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# # if (total_len_inside <= threshold_overlap_len_in_km):
																# # result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,20.00)
																# # if (total_len_inside <= threshold_overlap_len_in_km):
																	# # pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
																# # else:
																	# # list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# # else:
																# # list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# is_pair_of_lines_valid = False
												# if (is_pair_of_lines_valid == True):
													# pairs_of_lines_btw_GDUs.append((0.00,first_line_ft,first_line,second_line_ft,second_line))
													# found_valid_pair = True
													# #debug
													# # if ((first_superGDU_represent_id == 10714 and second_superGDU_represent_id == 10817) or (first_superGDU_represent_id == 10817 and second_superGDU_represent_id == 10714)):
														# # print('found_valid_pair',found_valid_pair)
														# # exit()
													# # break
											# if (found_valid_pair == True):
												# break
													# # dist = pygplates.GeometryOnSphere.distance(first_line, second_line)
													# # if (min_distance == -1.00):
														# # min_distance = dist
														# # most_appropriate_first_ft = first_line_ft
														# # most_appropriate_first_line = first_line
														# # most_appropriate_second_ft = second_line_ft
														# # most_appropriate_second_line = second_line
													# # elif (min_distance > -1.00 and min_distance > dist):
														# # min_distance = dist
														# # most_appropriate_first_ft = first_line_ft
														# # most_appropriate_first_line = first_line
														# # most_appropriate_second_ft = second_line_ft
														# # most_appropriate_second_line = second_line
												# # if (min_distance == 0.00):
													# # break
											# # if (min_distance == 0.00):
												# # break
										
										# #debug 
										# # if ((first_superGDU_represent_id == 10439 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10439)):
											# # if (smallest_circle_angular_radius_degrees == 101):
												# # print('pairs_of_lines_btw_GDUs',pairs_of_lines_btw_GDUs)
												# # print('list_of_invalid_pairs_name',list_of_invalid_pairs_name)
												# # exit()
										# if (len(pairs_of_lines_btw_GDUs) > 0):
											# #sort pairs_of_lines_btw_GDUs by total_len_inside
											# pairs_of_lines_btw_GDUs.sort()
											# # if ((first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10310) or (first_superGDU_represent_id == 10310 and second_superGDU_represent_id == 10953)):
												# # if (smallest_circle_angular_radius_degrees == 45.00):
													# # print(pairs_of_lines_btw_GDUs)
													# # print("threshold_overlap_len_in_km",threshold_overlap_len_in_km)
													# # exit()
											# record_w_minimum_len_inside = pairs_of_lines_btw_GDUs[0]
											# minimum_len_inside = record_w_minimum_len_inside[0]
											# if (minimum_len_inside <= threshold_overlap_len_in_km):
												# #total_len_inside,first_line_ft,first_line,second_line_ft,second_line
												# most_appropriate_first_ft = record_w_minimum_len_inside[1]
												# most_appropriate_first_line = record_w_minimum_len_inside[2]
												# most_appropriate_second_ft = record_w_minimum_len_inside[3]
												# most_appropriate_second_line = record_w_minimum_len_inside[4]
										# if (most_appropriate_first_ft is not None and most_appropriate_second_ft is not None):
											# txt_1 = """INSERT INTO {input_name_of_database_table} (time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, first_line_name, second_line_name, first_line_gdu, second_line_gdu, at_angular_radius) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
											# sql_1 = txt_1.format(input_name_of_database_table = name_of_database_table_for_pairs_of_line_fts)
											# line_cursor.execute(sql_1, (reconstruction_time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(), most_appropriate_first_ft.get_reconstruction_plate_id(), most_appropriate_second_ft.get_reconstruction_plate_id(), smallest_circle_angular_radius_degrees))
											# temp_line_fts_collection = pygplates.FeatureCollection([most_appropriate_first_ft,most_appropriate_second_ft])
											# list_of_centroid_ft = find_centroid_features_from_line_features(temp_line_fts_collection,False,None)
											# first_centroid_ft = list_of_centroid_ft[0]
											# second_centroid_ft = list_of_centroid_ft[1]
											# tectonic_motion = supporting.relative_position_velocity_vectors_eval(rotation_model,first_centroid_ft,second_centroid_ft,reconstruction_time,interval,reference,cos_value_for_transform)#cos_value_for_transform defines the upper and lower limit angles between velocity_vector and position_vector
											# record_txt = """ INSERT INTO {input_name_of_database_table} (time,ref_ft_id,neighbour_ft_id,tectonic_motion) VALUES(%s, %s, %s, %s)"""
											# record_sql = record_txt.format(input_name_of_database_table = name_of_database_table_for_tectonic_motion)
											# record_cursor.execute(record_sql,(reconstruction_time,first_centroid_ft.get_description(),second_centroid_ft.get_description(),tectonic_motion.name))
											# conn.commit()
											# if (tectonic_motion.name == 'Divergence' or tectonic_motion.name == 'Oblique_divergence'):
												# _,chosen_pt_1,_ = pygplates.GeometryOnSphere.distance(most_appropriate_first_line,small_circle_boundary,return_closest_positions=True)
												# _,chosen_pt_2,_ = pygplates.GeometryOnSphere.distance(most_appropriate_second_line,small_circle_boundary,return_closest_positions=True)
												# #find MOR location
												# #debug 
												# print("chosen_pt_1",chosen_pt_1)
												# print("chosen_pt_2",chosen_pt_2)
												# print("most_appropriate_first_line",most_appropriate_first_line.to_lat_lon_list())
												# print("most_appropriate_second_line",most_appropriate_second_line.to_lat_lon_list())
												# print("distance between chosen_pt_1 and chosen_pt_2",pygplates.GeometryOnSphere.distance(chosen_pt_1,chosen_pt_2))
												# print(pygplates.GeometryOnSphere.distance(small_circle_boundary,most_appropriate_second_line))
												# print('most_appropriate_first_ft',most_appropriate_first_ft.get_reconstruction_plate_id())
												# print('most_appropriate_second_ft',most_appropriate_second_ft.get_reconstruction_plate_id())
												# if (pygplates.GeometryOnSphere.distance(chosen_pt_1,chosen_pt_2) > 0.00):
													# MOR_location = tm.find_the_mid_of_two_PointOnSphere(chosen_pt_1,chosen_pt_2)
													
													# great_circle_arc = pygplates.GreatCircleArc(MOR_location,E_pole)
													# normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
													# MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, MOR_location, valid_time = (reconstruction_time,0.00))
													# MOR_location_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
													# #MOR_location_ft.set_name(key)
												
													# side_1 = MOR_topology.classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1)
													# side_2 = MOR_topology.classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2)
													# if (side_1 == 'left' and side_2 == 'right'):
														# MOR_location_ft.set_left_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# MOR_location_ft.set_right_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# elif (side_1 == 'right' and side_2 == 'left'):
														# MOR_location_ft.set_left_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# MOR_location_ft.set_right_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# else:
														# print("Error unexpected values for side_1 and side_2")
														# print("side_1, side_2", side_1, side_2)
														# print(MOR_topology.calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1))
														# print(MOR_topology.calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2))
														# exit()
													# MOR_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
													# MOR_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,first_line_name,second_line_name,at_angular_radius) VALUES(%s, %s, %s, %s, %s, %s, %s, %s,%s)"""
													# MOR_record_sql = MOR_record_txt.format(input_name_of_database_table = name_of_database_table_for_MOR)
													# print(MOR_record_sql)
													# #print((reconstruction_time,MOR_location_ft.get_feature_id().get_string(),first_superGDU_represent_id,second_superGDU_represent_id,first_superGDU_name,second_superGDU_name,most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(), smallest_circle_angular_radius_degrees))
													# MOR_record_cursor.execute(MOR_record_sql,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(),smallest_circle_angular_radius_degrees))
													
													# #list_of_MOR_locations.append((at_age,MOR_location_ft.get_feature_id().get_string(),MOR_location_ft.get_left_plate(),MOR_location_ft.get_right_plate(),smallest_circle_angular_radius_degrees))
													# outputPointFeatureCollection.add(MOR_location_ft)
													# #output chosen_pt_1 and chosen_pt_2
													# pt1_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, chosen_pt_1, valid_time = (reconstruction_time,0.00))
													# if (side_1 == 'left' and side_2 == 'right'):
														# pt1_location_ft.set_left_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# pt1_location_ft.set_right_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# elif (side_1 == 'right' and side_2 == 'left'):
														# pt1_location_ft.set_left_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# pt1_location_ft.set_right_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# pt1_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
													# pt1_location_ft.set_reconstruction_plate_id(first_superGDU_represent_id)
													# pt1_location_ft.set_name(str(first_superGDU_represent_id)+"_"+str(second_superGDU_represent_id))
													# outputPointFeatureCollection_2.add(pt1_location_ft)

													# pt2_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, chosen_pt_2, valid_time = (reconstruction_time,0.00))
													# if (side_1 == 'left' and side_2 == 'right'):
														# pt2_location_ft.set_left_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# pt2_location_ft.set_right_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# elif (side_1 == 'right' and side_2 == 'left'):
														# pt2_location_ft.set_left_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# pt2_location_ft.set_right_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# pt2_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
													# pt2_location_ft.set_reconstruction_plate_id(second_superGDU_represent_id)
													# pt2_location_ft.set_name(str(first_superGDU_represent_id)+"_"+str(second_superGDU_represent_id))
													# outputPointFeatureCollection_2.add(pt2_location_ft)
											# conn.commit()
											# print("reconstruction_time,reference_feature_id,neighbour_ft_id,tectonic_motion")
											# print(reconstruction_time,first_centroid_ft.get_description(),second_centroid_ft.get_description(),tectonic_motion.name)
								# smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.00
							# #debug
							# # if ((first_superGDU_represent_id == 11132 and second_superGDU_represent_id == 10041) or (first_superGDU_represent_id == 10041 and second_superGDU_represent_id == 11132)):
								# # print(list_of_invalid_pairs_name)
								# # exit()
			# if (len(outputPointFeatureCollection) > 0):
				# if (reference is not None):
					# pygplates.reverse_reconstruct(outputPointFeatureCollection,rotation_model,reconstruction_time,reference)
					# pygplates.reverse_reconstruct(outputPointFeatureCollection_2,rotation_model,reconstruction_time,reference)
				# else:
					# pygplates.reverse_reconstruct(outputPointFeatureCollection,rotation_model,reconstruction_time)
					# pygplates.reverse_reconstruct(outputPointFeatureCollection_2,rotation_model,reconstruction_time)
				# outputPointFeatureCollection.write(r"C:\\Users\\Lavie\Desktop\\Research\\Winter2022\\tectonic_boundaries\\MOR_location_features\\MOR_location_features_from_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
				# outputPointFeatureCollection_2.write(r"C:\\Users\\Lavie\Desktop\\Research\\Winter2022\\tectonic_boundaries\\div_location_features\\div_location_features_from_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
				# #outputPointFeatureCollection_previous_MOR.write("previous_MOR_location_features_from_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
				# outputPointFeatureCollection = pygplates.FeatureCollection()
				# outputPointFeatureCollection_2 = pygplates.FeatureCollection()
				# outputPointFeatureCollection_previous_MOR = pygplates.FeatureCollection()
				
				
			# #update reconstruction_time
			# reconstruction_time = reconstruction_time + interval
		# # if (len(outputPointFeatureCollection) > 0):
			# # outputPointFeatureCollection.write("MOR_features_from_reversed_"+modelname+"_"+yearmonthday+".shp")
			# # outputPointFeatureCollection.write("MOR_features_from_reversed_"+modelname+"_"+yearmonthday+".gpml")
			# # outputPointFeatureCollection_2.write("div_features_from_reversed_"+modelname+"_"+yearmonthday+".shp")
			# # outputPointFeatureCollection_2.write("div_features_from_reversed_"+modelname+"_"+yearmonthday+".gpml")
	# except(psycopg2.DatabaseError) as error:
		# print("Error in identify_tectonic_motion_3 related to Database")
		# print(error)
		# exit()
	# finally:
		# conn.close()
		
# def identify_tectonic_motion_4(name_of_database_table_for_pairs_of_line_fts, name_of_database_table_for_tectonic_motion, name_of_database_table_for_MOR, name_of_database_table_for_div, rotation_model, line_features_collection, super_gdu_features_collection, cos_value_for_transform, threshold_overlap_len_in_km, begin_reconstruction_time, end_reconstruction_time, interval, reference, modelname,yearmonthday):
	# try:
		# params = config()
		# conn = psycopg2.connect(**params)
		# cur = conn.cursor()
		# record_cursor = conn.cursor()
		# line_cursor = conn.cursor()
		# MOR_record_cursor = conn.cursor()
		# previous_MOR_cursor = conn.cursor() #time,MOR_ft_id,first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,first_line_name,second_line_name,at_angular_radius
		# current_MOR_cursor = conn.cursor()
		# div_record_cursor = conn.cursor()
		# passive_margins_cursor = conn.cursor()
		# reconstructed_super_gdu_features = []
		# reconstructed_line_features = []
		# OCN_OCN_line_features = []
		# OCN_OCN_ft_id = []
		# dic_super_gdu_and_members_line_fts = {}
		# outputPointFeatureCollection = pygplates.FeatureCollection()
		# outputPointFeatureCollection_2 = pygplates.FeatureCollection()
		# temporal_outputPointFeatureCollection_MOR = pygplates.FeatureCollection()
		# dic_super_gdu_and_members = {}
		# dic_MOR = {}
		# dic_margins = {}
		# txt = """SELECT DISTINCT gdu_id_member FROM super_gdu_and_members_id WHERE super_gdu_id = {input_super_gdu_id} """
		# previous_MOR_text = """SELECT first_line_name,second_line_name FROM {input_name_of_database_table} 
						# WHERE (first_superGDU_represent_id = {input_represent_gdu_id} or second_superGDU_represent_id = {input_represent_gdu_id})
						# AND time = {input_time}"""
		# reconstruction_time = begin_reconstruction_time 
		# while (reconstruction_time > (end_reconstruction_time - interval)):
			# #clean up containers 
			# reconstructed_super_gdu_features[:] = []
			# reconstructed_line_features[:] = []
			# dic_super_gdu_and_members_line_fts.clear()
			
			# valid_SuperGDU_features = [superGDU_ft for superGDU_ft in super_gdu_features_collection if superGDU_ft.is_valid_at_time(reconstruction_time)]
			# path_to_filename_oceanic_crust_features = r"C:\\Users\\Lavie\\Desktop\\Research\\Winter2022\\tectonic_boundaries\\oceanic_crust_features\\oceanic_crust_features_"+str(reconstruction_time + interval)+"_"+modelname+"_"+yearmonthday+".shp"
			# if (os.path.exists(path_to_filename_oceanic_crust_features)):
				# collection_oceanic_crust_fts = pygplates.FeatureCollection(path_to_filename_oceanic_crust_features)
				# list_of_represent_ids_of_valid_SuperGDU = [ft.get_reconstruction_plate_id() for ft in valid_SuperGDU_features]
				# for valid_oceanic_crust_ft in collection_oceanic_crust_fts:
					# if (valid_oceanic_crust_ft.get_reconstruction_plate_id() in list_of_represent_ids_of_valid_SuperGDU):
						# valid_SuperGDU_features.append(valid_oceanic_crust_ft)
			# valid_CON_OCN_line_features = [line_ft for line_ft in line_features_collection if line_ft.is_valid_at_time(reconstruction_time)]
			# OCN_OCN_line_features = None
			# for key_for_MOR_dic in dic_MOR.keys():
				# #MOR_ft = dic_MOR[key_for_MOR_dic] 
				# previous_time = reconstruction_time + interval
				# path_to_filename_passive_margin_fts = "C:\\Users\\Lavie\\Desktop\\Research\\Winter2022\\tectonic_boundaries\\oceanic_crust_features\\final_linear_for_entire_MOR_ft_"+key_for_MOR_dic+"_"+str(previous_time)+".shp"
				# if (os.path.exists(path_to_filename_passive_margin_fts)):
					# collection_passive_margin_fts = pygplates.FeatureCollection(path_to_filename_passive_margin_fts)
					# if (OCN_OCN_line_features is None):
						# OCN_OCN_line_features = pygplates.FeatureCollection()
					# for OCN_OCN_line_ft in collection_passive_margin_fts:
						# OCN_OCN_line_features.add(OCN_OCN_line_ft)
			# dic_MOR.clear()
			# dic_margins.clear()
			# for superGDU_ft in valid_SuperGDU_features:
				# superGDU_name = superGDU_ft.get_name()
				# represent_gdu_id = superGDU_ft.get_reconstruction_plate_id()
				# #check whether SuperGDU has oceanic crust features
				# # OCN_OCN_ft_id[:] = []
				# # previous_time = reconstruction_time + interval
				# # previous_MOR_sql = previous_MOR_text.format(input_name_of_database_table = name_of_database_table_for_MOR, input_represent_gdu_id = represent_gdu_id, input_time = previous_time)
				# # previous_MOR_cursor.execute(previous_MOR_sql)
				# # previous_MOR_row = previous_MOR_cursor.fetchone()
				# # while (previous_MOR_row is not None):
					# # previous_first_line_name = previous_MOR_row[0]
					# # previous_second_line_name = previous_MOR_row[1]
					# # OCN_OCN_ft_id.append(previous_first_line_name)
					# # OCN_OCN_ft_id.append(previous_second_line_name)
					# # previous_MOR_row = previous_MOR_cursor.fetchone()
				# # OCN_OCN_line_features = None
				# # if (len(OCN_OCN_ft_id) > 0):
					# # OCN_OCN_line_features = pygplates.FeatureCollection("previous_OCN_OCN_line_features.gpml")
				# if (superGDU_name not in dic_super_gdu_and_members):
					# super_gdu_id = int(superGDU_name)
					# sql = txt.format(input_super_gdu_id = super_gdu_id)
					# cur.execute(sql)
					# list_of_gdu_id_members = []
					# dic_super_gdu_and_members_line_fts[superGDU_name] = []
					# row = cur.fetchone()
					# while (row is not None):
						# gdu_id_member = int(row[0])
						# list_of_gdu_id_members.append(gdu_id_member)
						# selected_CON_OCN_line_features = [line_ft for line_ft in valid_CON_OCN_line_features if line_ft.get_reconstruction_plate_id() == gdu_id_member]
						# if (len(selected_CON_OCN_line_features) > 0):
							# dic_super_gdu_and_members_line_fts[superGDU_name] = dic_super_gdu_and_members_line_fts[superGDU_name] + selected_CON_OCN_line_features
							# selected_previous_OCN_OCN_line_features = None
							# if (OCN_OCN_line_features is not None):
								# selected_previous_OCN_OCN_line_features = [line_ft for line_ft in OCN_OCN_line_features if (line_ft.get_reconstruction_plate_id() == gdu_id_member and line_ft.is_valid_at_time(reconstruction_time))]
							# if (selected_previous_OCN_OCN_line_features is not None):
								# if (len(selected_previous_OCN_OCN_line_features) > 0):
									# dic_super_gdu_and_members_line_fts[superGDU_name] = dic_super_gdu_and_members_line_fts[superGDU_name] + selected_previous_OCN_OCN_line_features
						# row = cur.fetchone()
					# dic_super_gdu_and_members[superGDU_name] = list_of_gdu_id_members
				# else:
					# list_of_gdu_id_members = dic_super_gdu_and_members[superGDU_name]
					# selected_CON_OCN_line_features = [line_ft for line_ft in valid_CON_OCN_line_features if line_ft.get_reconstruction_plate_id() in list_of_gdu_id_members]
					# if (len(selected_CON_OCN_line_features) > 0):
						# dic_super_gdu_and_members_line_fts[superGDU_name] = selected_CON_OCN_line_features
						# selected_previous_OCN_OCN_line_features = None
						# if (OCN_OCN_line_features is not None):
							# selected_previous_OCN_OCN_line_features = [line_ft for line_ft in OCN_OCN_line_features if (line_ft.get_reconstruction_plate_id() in list_of_gdu_id_members and line_ft.is_valid_at_time(reconstruction_time))]
							# if (selected_previous_OCN_OCN_line_features is not None):
								# if (len(selected_previous_OCN_OCN_line_features) > 0):
									# dic_super_gdu_and_members_line_fts[superGDU_name] = selected_previous_OCN_OCN_line_features + selected_CON_OCN_line_features
			# #debug 
			# # if (reconstruction_time == 210):
				# # print (len(dic_super_gdu_and_members_line_fts['62726']))
				# # for ft in dic_super_gdu_and_members_line_fts['62726']:
					# # print(ft.get_name())
				# # print (len(dic_super_gdu_and_members_line_fts['62281']))
				# # for ft in dic_super_gdu_and_members_line_fts['62281']:
					# # print(ft.get_name())
				# # exit()
						# #reconstructed features
			# if (reference is not None):
				# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			# else:
				# pygplates.reconstruct(valid_SuperGDU_features,rotation_model,reconstructed_super_gdu_features,reconstruction_time,group_with_feature = True)
			# final_reconstructed_polygon_features = supporting.find_final_reconstructed_geometries(reconstructed_super_gdu_features,pygplates.PolygonOnSphere)
			# already_processed = []
			# for first_superGDU_ft,first_superGDU in final_reconstructed_polygon_features:
				# first_superGDU_name = first_superGDU_ft.get_name()
				# first_superGDU_represent_id = first_superGDU_ft.get_reconstruction_plate_id()
				# for second_superGDU_ft,second_superGDU in final_reconstructed_polygon_features:
					# second_superGDU_name = second_superGDU_ft.get_name()
					# k = first_superGDU_ft.get_feature_id().get_string()+'_'+second_superGDU_ft.get_feature_id().get_string()
					# re_k = second_superGDU_ft.get_feature_id().get_string()+'_'+first_superGDU_ft.get_feature_id().get_string()
					# if ((first_superGDU_name != second_superGDU_name) and (k not in already_processed) and (re_k not in already_processed) and (first_superGDU_name in dic_super_gdu_and_members_line_fts and second_superGDU_name in dic_super_gdu_and_members_line_fts)):
						# already_processed.append(k)
						# second_superGDU_represent_id = second_superGDU_ft.get_reconstruction_plate_id()
						# total_relative_reconstruction_rotation = tm.find_total_relative_reconstruction_rotation_(rotation_model,first_superGDU_represent_id,second_superGDU_represent_id, reconstruction_time, reference)
						# if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
							# E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
							# in_btw_SuperGDUs = []
							# in_btw_SuperGDU_fts = []
							# smallest_circle_angular_radius_degrees = 179.00
							# while (smallest_circle_angular_radius_degrees > 0.00):
								# #clean up the containers - because at each smallest_circle there will be a different set of SuperGDUs intersecting the small circle
								# #this might lead to the issue when either of the CON-OCN line feature is very long - part of the CON-OCN is valid and the other part is not
								# in_btw_SuperGDUs[:] = []
								# in_btw_SuperGDU_fts[:] = []
								# small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
								# dist_to_first, closest_pt_on_first_superGDU,_ = pygplates.GeometryOnSphere.distance(first_superGDU, small_circle_boundary, return_closest_positions = True)
								# dist_to_second, closest_pt_on_second_superGDU,_ = pygplates.GeometryOnSphere.distance(second_superGDU, small_circle_boundary, return_closest_positions = True)
								# dist_from_first_to_second = pygplates.GeometryOnSphere.distance(second_superGDU, first_superGDU)
								# intersecting_small_circle_boundary = None
								# if (dist_to_first == dist_to_second == 0.00):
									# for any_superGDU_ft,any_superGDU in final_reconstructed_polygon_features:
										# #is_valid = True
										# any_superGDU_ft_name = any_superGDU_ft.get_name()
										# any_superGDU_ft_id = any_superGDU_ft.get_feature_id().get_string()
										# #if (any_superGDU_ft_name != first_superGDU_name and any_superGDU_ft_name != second_superGDU_name):
										# if (any_superGDU_ft_id != first_superGDU_ft.get_feature_id() and any_superGDU_ft_id != second_superGDU_ft.get_feature_id()):
											# dist_to_any_superGDU, closest_pt_on_any_superGDU, _ = pygplates.GeometryOnSphere.distance(any_superGDU, small_circle_boundary, return_closest_positions = True)
											# if (dist_to_any_superGDU == 0.00):
												# #dist_from_any_to_first = pygplates.GeometryOnSphere.distance(first_superGDU, any_superGDU)
												# #dist_from_any_to_second = pygplates.GeometryOnSphere.distance(second_superGDU, any_superGDU)
												
												# #is_valid = False
												# in_btw_SuperGDUs.append(any_superGDU)
												# in_btw_SuperGDU_fts.append(any_superGDU_ft)
												
												# # if (dist_from_first_to_second > dist_from_any_to_first and dist_from_first_to_second > dist_from_any_to_second):
													# # is_valid = False
													# # in_btw_SuperGDUs.append(any_superGDU)
													# # in_btw_SuperGDU_fts.append(any_superGDU_ft)
												# # if (is_valid == True):
													# # temp_centroid_of_first_SuperGDU = first_superGDU.get_interior_centroid()
													# # temp_centroid_of_second_SuperGDU = second_superGDU.get_interior_centroid()
													# # #r,_ = is_line_crossing_polygon(temp_centroid_of_first_SuperGDU,temp_centroid_of_second_SuperGDU,any_superGDU,0.00)
													# # r = is_line_crossing_polygon_w_rel_position_vector(temp_centroid_of_first_SuperGDU,temp_centroid_of_second_SuperGDU,any_superGDU.get_interior_centroid())
													# # #r = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_superGDU, second_superGDU, any_superGDU)
													# # # if ((first_superGDU_represent_id == 10714 and second_superGDU_represent_id == 10817) or (first_superGDU_represent_id == 10817 and second_superGDU_represent_id == 10714)):
														# # # print("any_superGDU.get_name()",any_superGDU_ft.get_name())
														# # # print("any_superGDU_ft.get_reconstruction_plate_id()",any_superGDU_ft.get_reconstruction_plate_id())
														# # # print("result r",r)
														# # # print("smallest_circle_angular_radius_degrees",smallest_circle_angular_radius_degrees)
														# # #exit()
													# # if (r == True):
														# # is_valid = False
														# # in_btw_SuperGDUs.append(any_superGDU)
														# # in_btw_SuperGDU_fts.append(any_superGDU_ft)
												
												# # if (is_line_crossing_polygon(second_superGDU.get_interior_centroid(),first_superGDU.get_interior_centroid(),any_superGDU,0.00)):
													# # is_valid = False
													# # in_btw_SuperGDU = any_superGDU
													# # in_btw_SuperGDU_ft = any_superGDU_ft
												
									# intersecting_small_circle_boundary = small_circle_boundary
								# # #debug 
								# # if (((first_superGDU_represent_id == 10363 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10363)) and intersecting_small_circle_boundary is not None):
									# # #temp_ft_collection = pygplates.FeatureCollection()
									# # if (len(in_btw_SuperGDU_fts) > 0):
										# # for in_btw_SuperGDU_ft in in_btw_SuperGDU_fts:
											# # print('in_btw_SuperGDU_ft.get_reconstruction_plate_id',in_btw_SuperGDU_ft.get_reconstruction_plate_id())
											# # print('in_btw_SuperGDU_ft.get_name()',in_btw_SuperGDU_ft.get_name())
										# # #temp_ft_collection.add(in_btw_SuperGDU_ft)
									# # print('intersecting_small_circle_boundary',intersecting_small_circle_boundary)
									# # print('smallest_circle_angular_radius_degrees',smallest_circle_angular_radius_degrees)
								# if (intersecting_small_circle_boundary is not None):
									# #obtain list_of CON-OCN line features
									# line_features_from_first_SuperGDU = dic_super_gdu_and_members_line_fts[first_superGDU_name]
									# line_features_from_second_SuperGDU = dic_super_gdu_and_members_line_fts[second_superGDU_name]
									# #print('len(line_features_from_first_SuperGDU),first_superGDU_name',len(line_features_from_first_SuperGDU),first_superGDU_name)
									# #print('len(line_features_from_second_SuperGDU),second_superGDU_name',len(line_features_from_second_SuperGDU),second_superGDU_name)
									# reconstructed_line_features[:] = []
									# if (reference is not None):
										# pygplates.reconstruct(line_features_from_first_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
									# else:
										# pygplates.reconstruct(line_features_from_first_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
									# final_reconstructed_first_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
									# reconstructed_line_features[:] = []
									# if (reference is not None):
										# pygplates.reconstruct(line_features_from_second_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
									# else:
										# pygplates.reconstruct(line_features_from_second_SuperGDU,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
									# final_reconstructed_second_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
									# #find all lines from each SuperGDU that also intersect small_circle_boundary
									# list_of_intersecting_lines_from_first_SuperGDU = []
									# list_of_intersecting_lines_from_second_SuperGDU = []
									# for first_line_ft,first_line in final_reconstructed_first_line_features:
										# distance_to_first = pygplates.GeometryOnSphere.distance(first_line,intersecting_small_circle_boundary)
										# #print('distance_to_first',distance_to_first)
										# if (distance_to_first == 0.00):
											# #confirm the line feature belongs to the SuperGDU --- think of the case of Madagascar and the AFR
											# distance_to_first_SuperGDU = pygplates.GeometryOnSphere.distance(first_line,first_superGDU)
											# if (distance_to_first_SuperGDU == 0.00):
												# list_of_intersecting_lines_from_first_SuperGDU.append((first_line_ft, first_line))
									# for second_line_ft,second_line in final_reconstructed_second_line_features:
										# distance_to_second = pygplates.GeometryOnSphere.distance(second_line,intersecting_small_circle_boundary)
										# #print('distance_to_second',distance_to_second)
										# if (distance_to_second == 0.00):
											# #confirm the line feature belongs to the SuperGDU --- think of the case of Madagascar and the AFR
											# distance_to_second_SuperGDU = pygplates.GeometryOnSphere.distance(second_line,second_superGDU)
											# if (distance_to_second_SuperGDU == 0.00):
												# list_of_intersecting_lines_from_second_SuperGDU.append((second_line_ft, second_line))
									# # print('len(final_reconstructed_first_line_features)',len(final_reconstructed_first_line_features))
									# # print('len(final_reconstructed_second_line_features)',len(final_reconstructed_second_line_features))
									# # if ((first_superGDU_represent_id == 10714 and second_superGDU_represent_id == 10817) or (first_superGDU_represent_id == 10817 and second_superGDU_represent_id == 10714)):
										# # print('first_superGDU_represent_id,len(list_of_intersecting_lines_from_first_SuperGDU),degrees',first_superGDU_represent_id,len(list_of_intersecting_lines_from_first_SuperGDU),smallest_circle_angular_radius_degrees)
										# # print('second_superGDU_represent_id,len(list_of_intersecting_lines_from_second_SuperGDU)',second_superGDU_represent_id,len(list_of_intersecting_lines_from_second_SuperGDU))
										# # print('len(in_btw_SuperGDUs)',len(in_btw_SuperGDUs))
									# min_distance = -1.00
									# most_appropriate_second_ft, most_appropriate_second_line = None, None
									# most_appropriate_first_ft, most_appropriate_first_line = None, None
									# pairs_of_lines_btw_GDUs = []
									# list_of_invalid_pairs_name = []
									# found_valid_pair = False
									# if (len(list_of_intersecting_lines_from_first_SuperGDU) > 0 and len(list_of_intersecting_lines_from_second_SuperGDU) > 0):
										# for first_line_ft,first_line in list_of_intersecting_lines_from_first_SuperGDU:
											# centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
											# for second_line_ft,second_line in list_of_intersecting_lines_from_second_SuperGDU:
												# centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
												# is_pair_of_lines_valid = True
												# pair_of_line_ft_names = first_line_ft.get_name()+'_'+second_line_ft.get_name()
												# inversed_pair_of_line_ft_names = second_line_ft.get_name()+'_'+first_line_ft.get_name()
												# if ((pair_of_line_ft_names in list_of_invalid_pairs_name) or (inversed_pair_of_line_ft_names in list_of_invalid_pairs_name)):
													# is_pair_of_lines_valid = False
												# #debug
												# # if ((first_superGDU_represent_id == 10714 and second_superGDU_represent_id == 10817) or (first_superGDU_represent_id == 10817 and second_superGDU_represent_id == 10714)):
													# # print('first_line_ft',first_line_ft.get_name(),'second_line_ft',second_line_ft.get_name())
												# # if (len(in_btw_SuperGDUs) > 1 and is_pair_of_lines_valid == True):
													# # if ((first_superGDU_represent_id == 10363 and second_superGDU_represent_id == 10953) or (first_superGDU_represent_id == 10953 and second_superGDU_represent_id == 10363)):
														# # print('len(in_btw_SuperGDUs)',len(in_btw_SuperGDUs))
													# # is_pair_of_lines_valid = False
													# # list_of_invalid_pairs_name.append(pair_of_line_ft_names)
												# if (len(in_btw_SuperGDUs) > 0 and is_pair_of_lines_valid == True):
													# #debug
													
													# for i in range(0,len(in_btw_SuperGDUs)):
														# # print(i)
														# in_btw_SuperGDU_ft = in_btw_SuperGDU_fts[i]
														# in_btw_SuperGDU = in_btw_SuperGDUs[i]
														# if (is_pair_of_lines_valid == True):
														
															# #result = is_line_crossing_polygon_w_rel_position_vector(centroid_of_first_line, centroid_of_second_line, closest_pt_on_any_superGDU)
															# result_2 = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(intersecting_small_circle_boundary, first_line, second_line, in_btw_SuperGDU)
															# #result_3 = is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(small_circle_boundary, first_line, second_line, in_btw_SuperGDU)
															
															# if (result_2 == True):
																# is_pair_of_lines_valid = False
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															
														# if (is_pair_of_lines_valid == False):
															# break
												# if (is_pair_of_lines_valid == True):
													# if (dist_from_first_to_second == 0.00):
														# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,0.00)
														# if (result == False):
															# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,0.00)
															
															# if (result == True):
																# if (total_len_inside <= threshold_overlap_len_in_km):
																	# pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
																# else:
																	# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
																# is_pair_of_lines_valid = False
														# else:
															# if (total_len_inside <= threshold_overlap_len_in_km):
																# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,0.00)
																# if (result == True):
																	# if (total_len_inside <= threshold_overlap_len_in_km):
																		# pairs_of_lines_btw_GDUs.append((total_len_inside,first_line_ft,first_line,second_line_ft,second_line))
																	# else:
																		# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# else:
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															# is_pair_of_lines_valid = False
														
													# else:
														
														# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,first_superGDU,20.00)
														
														# if (result == False):
															# result,total_len_inside = is_line_crossing_polygon(centroid_of_first_line,centroid_of_second_line,second_superGDU,20.00)
															
															
															# if (result == True):
																# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
																# is_pair_of_lines_valid = False
														# else:
															# list_of_invalid_pairs_name.append(pair_of_line_ft_names)
															
															# is_pair_of_lines_valid = False
												# if (is_pair_of_lines_valid == True):
													# pairs_of_lines_btw_GDUs.append((0.00,first_line_ft,first_line,second_line_ft,second_line))
													# found_valid_pair = True
													
											# if (found_valid_pair == True):
												# break
													
										# if (len(pairs_of_lines_btw_GDUs) > 0):
											# #sort pairs_of_lines_btw_GDUs by total_len_inside
											# pairs_of_lines_btw_GDUs.sort()
											
											# record_w_minimum_len_inside = pairs_of_lines_btw_GDUs[0]
											# minimum_len_inside = record_w_minimum_len_inside[0]
											# if (minimum_len_inside <= threshold_overlap_len_in_km):
												# #total_len_inside,first_line_ft,first_line,second_line_ft,second_line
												# most_appropriate_first_ft = record_w_minimum_len_inside[1]
												# most_appropriate_first_line = record_w_minimum_len_inside[2]
												# most_appropriate_second_ft = record_w_minimum_len_inside[3]
												# most_appropriate_second_line = record_w_minimum_len_inside[4]
										# if (most_appropriate_first_ft is not None and most_appropriate_second_ft is not None):
											# txt_1 = """INSERT INTO {input_name_of_database_table} (time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, first_line_name, second_line_name, first_line_gdu, second_line_gdu, at_angular_radius) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
											# sql_1 = txt_1.format(input_name_of_database_table = name_of_database_table_for_pairs_of_line_fts)
											# line_cursor.execute(sql_1, (reconstruction_time, first_superGDU_represent_id, first_superGDU_name, second_superGDU_represent_id, second_superGDU_name, most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(), most_appropriate_first_ft.get_reconstruction_plate_id(), most_appropriate_second_ft.get_reconstruction_plate_id(), smallest_circle_angular_radius_degrees))
											# temp_line_fts_collection = pygplates.FeatureCollection([most_appropriate_first_ft,most_appropriate_second_ft])
											# list_of_centroid_ft = find_centroid_features_from_line_features(temp_line_fts_collection,False,None)
											# first_centroid_ft = list_of_centroid_ft[0]
											# second_centroid_ft = list_of_centroid_ft[1]
											# tectonic_motion = supporting.relative_position_velocity_vectors_eval(rotation_model,first_centroid_ft,second_centroid_ft,reconstruction_time,interval,reference,cos_value_for_transform)#cos_value_for_transform defines the upper and lower limit angles between velocity_vector and position_vector
											# record_txt = """ INSERT INTO {input_name_of_database_table} (time,ref_ft_id,neighbour_ft_id,tectonic_motion) VALUES(%s, %s, %s, %s)"""
											# record_sql = record_txt.format(input_name_of_database_table = name_of_database_table_for_tectonic_motion)
											# record_cursor.execute(record_sql,(reconstruction_time,first_centroid_ft.get_description(),second_centroid_ft.get_description(),tectonic_motion.name))
											# conn.commit()
											# if (tectonic_motion.name == 'Divergence' or tectonic_motion.name == 'Oblique_divergence'):
												# _,chosen_pt_1,_ = pygplates.GeometryOnSphere.distance(most_appropriate_first_line,small_circle_boundary,return_closest_positions=True)
												# _,chosen_pt_2,_ = pygplates.GeometryOnSphere.distance(most_appropriate_second_line,small_circle_boundary,return_closest_positions=True)
												# #find MOR location
												# MOR_location = tm.find_the_mid_of_two_PointOnSphere(chosen_pt_1,chosen_pt_2)
												# great_circle_arc = pygplates.GreatCircleArc(MOR_location,E_pole)
												# normal_vector_of_great_circle_arc = great_circle_arc.get_great_circle_normal()
												# MOR_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, MOR_location, valid_time = (reconstruction_time,0.00))
												# MOR_location_ft.set_reconstruction_method('HalfStageRotationVersion2',verify_information_model = pygplates.VerifyInformationModel.no)
												# key_for_MOR_dic = None
												# if (first_superGDU_represent_id > second_superGDU_represent_id):
													# key_for_MOR_dic = str(first_superGDU_represent_id)+"_"+str(second_superGDU_represent_id)
												# else:
													# key_for_MOR_dic = str(second_superGDU_represent_id)+"_"+str(first_superGDU_represent_id)
												# MOR_location_ft.set_name(key_for_MOR_dic)
												# side_1 = MOR_topology.classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1)
												# side_2 = MOR_topology.classify_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2)
												# if (side_1 == 'left' and side_2 == 'right'):
													# MOR_location_ft.set_left_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# MOR_location_ft.set_right_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
												# elif (side_1 == 'right' and side_2 == 'left'):
													# MOR_location_ft.set_left_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# MOR_location_ft.set_right_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
												# else:
													# print("Error unexpected values for side_1 and side_2")
													# print("side_1, side_2", side_1, side_2)
													# print(MOR_topology.calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_1))
													# print(MOR_topology.calculate_angle_for_classifying_left_or_right(normal_vector_of_great_circle_arc, MOR_location, chosen_pt_2))
													# exit()
												# MOR_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
												# MOR_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,first_line_name,second_line_name,at_angular_radius) VALUES(%s, %s, %s, %s, %s, %s, %s, %s,%s)"""
												# MOR_record_sql = MOR_record_txt.format(input_name_of_database_table = name_of_database_table_for_MOR)
												# #print(MOR_record_sql)
												# #print((reconstruction_time,MOR_location_ft.get_feature_id().get_string(),first_superGDU_represent_id,second_superGDU_represent_id,first_superGDU_name,second_superGDU_name,most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(), smallest_circle_angular_radius_degrees))
												# MOR_record_cursor.execute(MOR_record_sql,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,most_appropriate_first_ft.get_name(), most_appropriate_second_ft.get_name(),smallest_circle_angular_radius_degrees))
												# #list_of_MOR_locations.append((at_age,MOR_location_ft.get_feature_id().get_string(),MOR_location_ft.get_left_plate(),MOR_location_ft.get_right_plate(),smallest_circle_angular_radius_degrees))
												# outputPointFeatureCollection.add(MOR_location_ft)
												# if (key_for_MOR_dic not in dic_MOR):
													# dic_MOR[key_for_MOR_dic] = [MOR_location_ft]
												# else:
													# dic_MOR[key_for_MOR_dic].append(MOR_location_ft)
												# temporal_outputPointFeatureCollection_MOR.add(MOR_location_ft)
												# #check "Does this pair of SuperGDUs with the value of smallest_circle_angular_radius_degrees have any record in the previous time-step?"
												# #if there is a previous record, then get this MOR ft and make two copies of them to be the two associated divergent features
												# previous_MOR_record_txt = """SELECT time,MOR_ft_id,first_superGDU_represent_id,first_superGDU_name,second_superGDU_represent_id,second_superGDU_name,first_line_name,second_line_name,at_angular_radius
																				# FROM {input_name_of_database_table} 
																				# WHERE ((first_superGDU_represent_id = {input_first_superGDU_represent_id} and second_superGDU_represent_id = {input_second_superGDU_represent_id})
																					  # OR (first_superGDU_represent_id = {input_second_superGDU_represent_id} and second_superGDU_represent_id = {input_first_superGDU_represent_id}))
																				# AND at_angular_radius = {input_at_angular_radius}
																				# AND time = {input_time}"""
												# previous_MOR_record_sql = previous_MOR_record_txt.format(input_name_of_database_table = name_of_database_table_for_MOR, input_first_superGDU_represent_id = first_superGDU_represent_id, input_second_superGDU_represent_id = second_superGDU_represent_id, input_at_angular_radius = smallest_circle_angular_radius_degrees, input_time = reconstruction_time + interval)
												# previous_MOR_cursor.execute(previous_MOR_record_sql)
												# previous_MOR_record = previous_MOR_cursor.fetchone()
												# left_passive_margin_ft = None
												# right_passive_margin_ft = None
												# if (previous_MOR_record is not None):
													# #print(previous_MOR_record)
													# #get the MOR_ft_id 
													# previous_MOR_ft_id = previous_MOR_record[1]
													# passive_margins_record_txt = """SELECT left_div_ft,right_div_ft
																				# FROM {input_name_of_database_table}
																				# WHERE at_angular_radius = {input_at_angular_radius}
																				# AND time = {input_time}
																				# AND MOR_ft_id = '{input_MOR_ft_id}'"""
													# passive_margins_record_sql = passive_margins_record_txt.format(input_MOR_ft_id = previous_MOR_ft_id,input_name_of_database_table = name_of_database_table_for_div, input_at_angular_radius = smallest_circle_angular_radius_degrees, input_time = reconstruction_time + interval)
													# print(passive_margins_record_sql)
													# passive_margins_cursor.execute(passive_margins_record_sql)
													# passive_margins_record = passive_margins_cursor.fetchone()
													# #left_passive_margin_id = passive_margins_record[0]
													# #right_passive_margin_id = passive_margins_record[1]
													# path_to_filename_previous_MOR_fts = r"C:\\Users\\Lavie\\Desktop\\Research\\Winter2022\\tectonic_boundaries\\oceanic_crust_features\\previous_MOR_transform_fts_"+key_for_MOR_dic+"_"+str(reconstruction_time)+".shp"
													# if (os.path.exists(path_to_filename_previous_MOR_fts)):
														# outputPointFeatureCollection_previous_MOR = pygplates.FeatureCollection(path_to_filename_previous_MOR_fts)
														# for margin_ft in outputPointFeatureCollection_previous_MOR:
															# previous_small_circle_angular_radius = float(margin_ft.get_description())
															# if (margin_ft.get_name() == key_for_MOR_dic and margin_ft.get_left_plate() == margin_ft.get_reconstruction_plate_id() and previous_small_circle_angular_radius == smallest_circle_angular_radius_degrees):
																# left_passive_margin_ft = margin_ft
															# elif (margin_ft.get_name() == key_for_MOR_dic and margin_ft.get_right_plate() == margin_ft.get_reconstruction_plate_id() and previous_small_circle_angular_radius == smallest_circle_angular_radius_degrees):
																# right_passive_margin_ft = margin_ft
															# if (left_passive_margin_ft is not None and right_passive_margin_ft is not None):
																# break
														# # if (left_passive_margin_ft is None or right_passive_margin_ft is None):
															# # for margin_ft in outputPointFeatureCollection_previous_MOR:
																# # previous_small_circle_angular_radius = float(margin_ft.get_description())
																# # print("margin_ft.get_name",margin_ft.get_name())
																# # print("margin_ft.get_feature_id().get_string()",margin_ft.get_feature_id().get_string())
																# # print("float(margin_ft.get_description())",float(margin_ft.get_description()))
																# # print("left, right, reconstruction_plate_id",margin_ft.get_left_plate(),margin_ft.get_right_plate(),margin_ft.get_reconstruction_plate_id())
															# # exit()
														# if (left_passive_margin_ft is not None and right_passive_margin_ft is not None):
															# if (key_for_MOR_dic not in dic_margins):
																# dic_margins[key_for_MOR_dic] = {"left":[left_passive_margin_ft],"right":[right_passive_margin_ft]}
															# else:
																# dic_margins[key_for_MOR_dic]["left"].append(left_passive_margin_ft)
																# dic_margins[key_for_MOR_dic]["right"].append(right_passive_margin_ft)
												# #if there is no previous record or either left or right passive margin_ft is None, then create two divergent point features
												# if (left_passive_margin_ft is None or right_passive_margin_ft is None):
													# #output chosen_pt_1 and chosen_pt_2
													# pt1_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, chosen_pt_1, valid_time = (reconstruction_time,0.00))
													# if (side_1 == 'left' and side_2 == 'right'):
														# pt1_location_ft.set_left_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# pt1_location_ft.set_right_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# elif (side_1 == 'right' and side_2 == 'left'):
														# pt1_location_ft.set_left_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# pt1_location_ft.set_right_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# pt1_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
													# pt1_location_ft.set_reconstruction_plate_id(first_superGDU_represent_id)
													# pt1_location_ft.set_name(key_for_MOR_dic)
													# outputPointFeatureCollection_2.add(pt1_location_ft)

													# pt2_location_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, chosen_pt_2, valid_time = (reconstruction_time,0.00))
													# if (side_1 == 'left' and side_2 == 'right'):
														# pt2_location_ft.set_left_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# pt2_location_ft.set_right_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# elif (side_1 == 'right' and side_2 == 'left'):
														# pt2_location_ft.set_left_plate(second_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
														# pt2_location_ft.set_right_plate(first_superGDU_represent_id,verify_information_model = pygplates.VerifyInformationModel.no)
													# pt2_location_ft.set_description(str(smallest_circle_angular_radius_degrees))
													# pt2_location_ft.set_reconstruction_plate_id(second_superGDU_represent_id)
													# pt2_location_ft.set_name(key_for_MOR_dic)
													# outputPointFeatureCollection_2.add(pt2_location_ft)
												
													# if (side_1 == 'left' and side_2 == 'right'):
														# div_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,left_div_gdu,right_div_gdu,left_div_ft,right_div_ft,at_angular_radius) VALUES(%s, %s, %s, %s, %s, %s, %s)"""
														# div_record_sql = div_record_txt.format(input_name_of_database_table = name_of_database_table_for_div)
														# div_record_cursor.execute(div_record_sql,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),most_appropriate_first_ft.get_reconstruction_plate_id(),most_appropriate_second_ft.get_reconstruction_plate_id(),pt1_location_ft.get_feature_id().get_string(),pt2_location_ft.get_feature_id().get_string(), smallest_circle_angular_radius_degrees))
														# if (key_for_MOR_dic not in dic_margins):
															# dic_margins[key_for_MOR_dic] = {"left":[pt1_location_ft],"right":[pt2_location_ft]}
														# else:
															# dic_margins[key_for_MOR_dic]['left'].append(pt1_location_ft)
															# dic_margins[key_for_MOR_dic]['right'].append(pt2_location_ft)
													# elif (side_1 == 'right' and side_2 == 'left'):
														# div_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,left_div_gdu,right_div_gdu,left_div_ft,right_div_ft,at_angular_radius) VALUES(%s, %s, %s, %s, %s, %s, %s)"""
														# div_record_sql = div_record_txt.format(input_name_of_database_table = name_of_database_table_for_div)
														# div_record_cursor.execute(div_record_sql,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),most_appropriate_second_ft.get_reconstruction_plate_id(),most_appropriate_first_ft.get_reconstruction_plate_id(),pt2_location_ft.get_feature_id().get_string(),pt1_location_ft.get_feature_id().get_string(), smallest_circle_angular_radius_degrees))
														# if (key_for_MOR_dic not in dic_margins):
															# dic_margins[key_for_MOR_dic] = {"right":[pt1_location_ft],"left":[pt2_location_ft]}
														# else:
															# dic_margins[key_for_MOR_dic]['left'].append(pt2_location_ft)
															# dic_margins[key_for_MOR_dic]['right'].append(pt1_location_ft)

												# #create new passive margin features based on the current MOR ft
												# # left_MOR_ft,right_MOR_ft = MOR_topology.create_left_and_right_div_fts_from_MOR_ft(MOR_location_ft, MOR_location, reconstruction_time)
												# # left_right_MOR_record_txt = """ INSERT INTO {input_name_of_database_table} (time,MOR_ft_id,left_MOR_ft_id,right_MOR_ft_id,at_angular_radius) VALUES(%s, %s, %s, %s, %s)"""
												# # left_right_MOR_record_sql = left_right_MOR_record_txt.format(input_name_of_database_table = name_of_database_table_for_previous_MOR)
												# # left_right_MOR_record_cursor.execute(left_right_MOR_record_txt,(reconstruction_time,MOR_location_ft.get_feature_id().get_string(),left_MOR_ft.get_feature_id().get_string(),right_MOR_ft.get_feature_id().get_string(),smallest_circle_angular_radius_degrees))
												# # outputPointFeatureCollection_previous_MOR.add(left_MOR_ft)
												# # outputPointFeatureCollection_previous_MOR.add(right_MOR_ft)
												
											# #commit all records to database
											# conn.commit()
											# print("reconstruction_time,reference_feature_id,neighbour_ft_id,tectonic_motion")
											# print(reconstruction_time,first_centroid_ft.get_description(),second_centroid_ft.get_description(),tectonic_motion.name)
								# smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.00
			# if (len(outputPointFeatureCollection) > 0):
				# if (reference is not None):
					# pygplates.reverse_reconstruct(outputPointFeatureCollection,rotation_model,reconstruction_time,reference)
					# pygplates.reverse_reconstruct(outputPointFeatureCollection_2,rotation_model,reconstruction_time,reference)
					# #pygplates.reverse_reconstruct(outputPointFeatureCollection_previous_MOR,rotation_model,reconstruction_time,reference)
					# pygplates.reverse_reconstruct(temporal_outputPointFeatureCollection_MOR,rotation_model,reconstruction_time,reference)
				# else:
					# pygplates.reverse_reconstruct(outputPointFeatureCollection,rotation_model,reconstruction_time)
					# pygplates.reverse_reconstruct(outputPointFeatureCollection_2,rotation_model,reconstruction_time)
					# #pygplates.reverse_reconstruct(outputPointFeatureCollection_previous_MOR,rotation_model,reconstruction_time)
					# pygplates.reverse_reconstruct(temporal_outputPointFeatureCollection_MOR,rotation_model,reconstruction_time)
			
			# if (len(outputPointFeatureCollection) > 0):
				# outputPointFeatureCollection.write(r"C:\\Users\\Lavie\Desktop\\Research\\Winter2022\\tectonic_boundaries\\oceanic_crust_features\\MOR_location_features_from_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
				# outputPointFeatureCollection_2.write(r"C:\\Users\\Lavie\Desktop\\Research\\Winter2022\\tectonic_boundaries\\oceanic_crust_features\\div_location_features_from_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
				# #outputPointFeatureCollection_previous_MOR.write("previous_MOR_location_features_from_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
				# outputPointFeatureCollection = pygplates.FeatureCollection()
				# outputPointFeatureCollection_2 = pygplates.FeatureCollection()
				# outputPointFeatureCollection_previous_MOR = pygplates.FeatureCollection()
			
			# #finish evaluating all pairs of valid SuperGDUs at reconstruction_time. Now, create oceanic polygon features
			# #get all records for MOR_location_fts at the reconstruction_time by querying the MOR database table
			# current_MOR_records_txt = """SELECT MOR_ft_id,first_superGDU_represent_id,second_superGDU_represent_id
										# FROM {input_name_of_database_table} 
										# WHERE time = {input_time}"""
			# current_MOR_record_sql = current_MOR_records_txt.format(input_name_of_database_table = name_of_database_table_for_MOR, input_time = reconstruction_time + interval)
			# current_MOR_cursor.execute(current_MOR_record_sql)
			# current_MOR_record = current_MOR_cursor.fetchone()
			# if (current_MOR_record is not None):
				# is_ridge_and_transform = True
			# else:
				# is_ridge_and_transform = False
			# output_oceanic_crust_features = MOR_topology.create_temporal_oceanic_crust_features(dic_MOR, dic_margins, reconstruction_time, rotation_model, reference, is_ridge_and_transform)
			# if (output_oceanic_crust_features is not None):
				# if (len(output_oceanic_crust_features) > 0):
					# output_oceanic_crust_features.write(r"C:\\Users\\Lavie\\Desktop\\Research\\Winter2022\\tectonic_boundaries\\oceanic_crust_features\\oceanic_crust_features_"+str(reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
			# #update reconstruction_time
			# reconstruction_time = reconstruction_time - interval

		# if (len(temporal_outputPointFeatureCollection_MOR) > 0):
			# temporal_outputPointFeatureCollection_MOR.write("MOR_features_from_"+str(begin_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
			# #temporal_outputPointFeatureCollection_MOR.write("MOR_features_from_"+str(begin_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".gpml")
	# except(psycopg2.DatabaseError) as error:
		# print("Error in identify_tectonic_motion_3 related to Database")
		# print(error)
		# exit()
	# finally:
		# conn.close()

