import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
import supporting_modules_to_extend_tectonic_boundaries as supporting_extend

def main():
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	CON_OCN_line_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\utility\check_and_assign_ft_id_str_in_GPlates_format_to_ft_name_CON_OCN_line_features_PalaeoPlatesNov2021_20220224.gpml"
	CON_OCN_line_features = pygplates.FeatureCollection(CON_OCN_line_file)
	tectonic_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\tectonic_boundaries_from_final_summary_of_tectonic_boundaries_and_motion_test_21_PalaeoPlatesNov2021_350_0Ma_20220417.gpml"
	tectonic_features = pygplates.FeatureCollection(tectonic_features_file)
	buffer_distance_km = 100.00
	begin = 350.00
	end = 0.00
	interval = 5.00
	reference = 700
	modelname = "PalaeoPlatesNov2021"
	yyyymmdd = "20220418"
	supporting_extend.identify_new_lines_for_feats_without_SuperGDU(rotation_model, CON_OCN_line_features, tectonic_features, buffer_distance_km, begin, end, interval, reference, modelname, yyyymmdd)

if __name__=='__main__':
	main()