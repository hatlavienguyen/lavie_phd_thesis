import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
import rotation_utility
import evaluate_tectonic_motion as tectonic_motion

#A function to calculate the distance between two points on the sphere - specifically the Earth 
#I could have used haversine module for python, but for the purpose of practise, I do it myself
#According to the formula from https://www.igismap.com/haversine-formula-calculate-geographic-distance-earth/, 
#a = sin^2(Difference in latitudes/2)+cos(lat1)*cos(lat2)*sin^2(Difference in longitude/2)
#c = 2*atan2(sqrt(a),sqrt(1-a))
#d = Radius of the sphere * c
def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def convert_Point_in_Shapely_to_PointOnSphere_in_pygplates(point):
	'''point has coordinate as longitude and latitude'''
	longitude = point.x
	latitude = point.y
	point_on_sphere = pygplates.PointOnSphere(latitude,longitude)
	return point_on_sphere

def convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates(line):
	'''each data point of the line has coordinate as longitude and latitude'''
	if (line.length > 0.00):
		try:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.coords]
		except NotImplementedError as error:
			list_of_lat_lon_vertices = [(lat,lon) for lon,lat in line.exterior.coords]
		line_on_sphere = pygplates.PolylineOnSphere(list_of_lat_lon_vertices)
		if (line_on_sphere is None):
			print ("Error to convert convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
			print ("Here is a list_of_lat_lon_vertices")
			print (list_of_lat_lon_vertices)
			print (list_of_lat_lon_vertices)
			exit()
		return line_on_sphere
	else:
		print ("Error in convert_LineString_in_Shapely_to_LineOnSphere_in_pygplates")
		print ("line.length == 0")
		print ("here are coords for line:")
		print((line.coords))
		print ("here is line")
		print (line)
		exit()

def convert_Polygon_in_Shapely_to_PolygonOnSphere_in_pygplates(each_polygon):
	'''each data point of each_polygon has a coordinate as longitude and latitude'''
	if (each_polygon.area > 0.00):
		list_of_lat_lon_vertices = [(lat,lon) for lon,lat in list(each_polygon.exterior.coords)]
		final_list_of_lat_lon_vertices = []
		for lat,lon in list_of_lat_lon_vertices:
			#print("lat,lon")
			#print(lat,lon)
			if (pygplates.LatLonPoint.is_valid_latitude(lat) == False or pygplates.LatLonPoint.is_valid_longitude(lon) == False):
				print("Warning in convert_Polygon_to_PolygonOnSphere_in_pygplates")
				print("Warning invalid value of latitude or/and longitude")
				print("value of latitude")
				print(lat)
				print("value of longitude")
				print(lon)
				if (pygplates.LatLonPoint.is_valid_latitude(lat) == False):
					if (abs(abs(lat) - 90.00) < 0.500):
						if (lat < -90.00):
							lat = -90.000
						elif (lat > 90.00):
							lat = 90.000
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of latitude")
						print("value of latitude")
						print(lat)					
						exit()
				if (pygplates.LatLonPoint.is_valid_longitude(lon) == False):
					if (abs(abs(lon) - 180.00) < 0.500):
						if (lon < -180.00):
							lon = -180.00
						elif (lon > 180.00):
							lon = 180.00
					else:
						print("Error in convert_Polygon_to_PolygonOnSphere_in_pygplates")
						print("Error invalid value of longitude")
						print("value of longitude")
						print(lon)					
						exit()
			final_list_of_lat_lon_vertices.append((lat,lon))	
		new_polygon = pygplates.PolygonOnSphere(final_list_of_lat_lon_vertices)
		if (new_polygon is None):
			print("Error in creating polygon in pygplates in conversion module")
			print("Here is a list of lat_lon vertices")
			print(list_of_lat_lon_vertices)
			print("Here is the first vertex and the last vertex:")
			print(list_of_lat_lon_vertices[0])
			print(list_of_lat_lon_vertices[len(list_of_lat_lon_vertices)-1])
			exit()
		return new_polygon
	else:
		print("Error in creating polygon in pygplates in conversion module")
		print("Error each_polygon.area <= 0.00")
		print("here is each_polygon")
		print(each_polygon)
		print([(lon,lat) for lon,lat in each_polygon.exterior.coords])
		exit()

def convert_PolygonOnSphere_to_Polygon_in_Shapely(polygon_on_sphere):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in polygon_on_sphere.to_lat_lon_list()]
	new_polygon = Polygon(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating Polygon in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_polygon

def convert_PolylineOnSphere_to_LineString_in_Shapely(polyline_on_sphere):
	list_of_lon_lat_vertices = [(lon,lat) for lat,lon in polyline_on_sphere.to_lat_lon_list()]
	new_linestring = LineString(list_of_lon_lat_vertices)
	if (new_polygon is None):
		print("Error in creating LineString in Shapely in conversion module")
		print("Here is a list of lon_lat vertices")
		print(list_of_lon_lat_vertices)
		print("Here is the first vertex and the last vertex:")
		print(list_of_lon_lat_vertices[0])
		print(list_of_lon_lat_vertices[len(list_of_lon_lat_vertices)-1])
		exit()
	return new_linestring

def convert_PointOnSphere_to_Point_in_Shapely(point_on_sphere):
	lat,lon = point_on_sphere.to_lat_lon()
	new_point = Point(lon,lat)
	if (new_point is None):
		print("Error in creating Point in Shapely in conversion module")
		print("Here is a vertices")
		print(lat,lon)
		exit()
	return new_point

def project_any_Shapely_geometry_in_wgs84_lon_lat_coordinates_to_planar_projection(wgs84_geom, choosen_epsg_projection):
	'''wgs84_geom has a geometry data type defined in Shapely and coordinates with order longitude as x and latitude as y'''
	wgs84 = pyproj.CRS('EPSG:4326')
	projection = pyproj.CRS(choosen_epsg_projection)
	project = pyproj.Transformer.from_crs(wgs84, projection, always_xy = True).transform
	projected_geom = transform(project, wgs84_geom)
	return projected_geom

def project_any_Shapely_geometry_in_planar_projection_to_spherical_projection_wgs84_lon_lat(projected_geom, choosen_epsg_projection):
	wgs84 = pyproj.CRS('EPSG:4326')
	projection = pyproj.CRS(choosen_epsg_projection)
	project = pyproj.Transformer.from_crs(projection, wgs84, always_xy = True).transform
	wgs84_geom = transform(project,projected_geom)
	return wgs84_geom

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = mean(lat_values)
				mean_lon = mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries
	
def find_valid_con_ocn_line_features(line_features, common_filename_for_invalid_con_ocn_line_csv, reconstruction_time):
	#csv_filename = common_filename_for_invalid_con_ocn_line_csv.format(time = str(reconstruction_time))
	csv_filename= common_filename_for_invalid_con_ocn_line_csv
	#'reconstruction_time','LineID','OPOLYLID','POLYLID','GPLATE_FID'
	invalid_con_ocn_df = pd.read_csv(csv_filename, delimiter = ';', header = 0)
	valid_line_features = []
	for line_ft in line_features:
		polylid = line_ft.get_shapefile_attribute('POLYLID')
		opolylid = line_ft.get_shapefile_attribute('OPOLYLID')
		lineid = line_ft.get_shapefile_attribute('LineID')
		gplate_fid = line_ft.get_feature_id().get_string()
		result = invalid_con_ocn_df.loc[(invalid_con_ocn_df['POLYLID'] == polylid) & (invalid_con_ocn_df['OPOLYLID'] == opolylid) & (invalid_con_ocn_df['LineID'] == lineid) & (invalid_con_ocn_df['GPLATE_FID'] == gplate_fid)]
		if (result is not None):
			if (len(result) == 0):
				valid_line_features.append(line_ft)
		else:
			valid_line_features.append(line_ft)
	return valid_line_features

def find_gdu_features_associated_with_line_features(gdu_features, line_features):
	selected_gdu_features = {}
	for line_ft in line_features:
		polygid = line_ft.get_shapefile_attribute('POLYGID')
		if (polygid is not None):
			for gdu_ft in gdu_features:
				if (gdu_ft.get_shapefile_attribute('POLYGID') is not None and gdu_ft.get_shapefile_attribute('POLYGID') == polygid):
					if (polygid not in selected_gdu_features):
						selected_gdu_features[polygid] = [gdu_ft]
					else:
						list_of_gdu_fts = selected_gdu_features[polygid]
						found_duplicated = False
						for prev_ft in list_of_gdu_fts:
							prev_geometries = prev_ft.get_geometries()
							current_geometries = gdu_ft.get_geometries()
							for prev_geom in prev_geometries:
								for current_geom in current_geometries:
									if (prev_geom == current_geom):
										found_duplicated = True
										break
								if (found_duplicated == True):
									break
							if (found_duplicated == True):
								break
						if (found_duplicated == False):
							selected_gdu_features[polygid].append(gdu_ft)
	return selected_gdu_features

def find_gdu_members_of_each_sgdu_feat(gdu_features, sgdu_features,common_filename_for_temporary_sgdu_and_members_csv,reconstruction_time):
	list_of_distinct_gdu_ids = []
	dict_of_sgdu_and_members_ids = {}
	# for gdu_ft in gdu_features:
		# if (gdu_ft.get_reconstruction_plate_id() not in list_of_distinct_gdu_ids):
			# list_of_distinct_gdu_ids.append(gdu_ft.get_reconstruction_plate_id())
		# if (gdu_ft.get_reconstruction_plate_id() == 11732):
			# print('found gdu fts with gdu id')
			# print(gdu_ft.get_reconstruction_plate_id() in list_of_distinct_gdu_ids)
	# array_of_distinct_gdu_ids = np.array(list_of_distinct_gdu_ids)
	for sgdu_ft in sgdu_features:
		sgdu_id = sgdu_ft.get_name()
		rep_gdu_id = sgdu_ft.get_reconstruction_plate_id()
		list_of_associated_gdu_members = None
		if (sgdu_id not in dict_of_sgdu_and_members_ids):
			temp_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temp_df = pd.read_csv(temp_sgdu_and_members_csv, delimiter = ';', header = 0)
			
			unique_sgdus = temp_df.loc[(temp_df['repGDUID'] == rep_gdu_id),'SGDUID'].unique()
			records_of_gdu_members = []
			for sgdu in unique_sgdus:
				temp_members = temp_df.loc[(temp_df['SGDUID'] == sgdu),'GDUID'].unique()
				for temp_mem in temp_members:
					if (temp_mem not in records_of_gdu_members):
						records_of_gdu_members.append(temp_mem)

			#records_of_gdu_members = temp_df.loc[(temp_df['repGDUID'] == rep_gdu_id)|(temp_df['GDUID'] == rep_gdu_id),'GDUID'].unique()
			# if (sgdu_id == '70290'):
				# print('records_of_gdu_members',records_of_gdu_members)
			#array_of_all_distinct_gdu_members = records_of_gdu_members
			#wanted_gdu_members = np.intersect1d(array_of_distinct_gdu_ids,array_of_all_distinct_gdu_members)
			
			wanted_gdu_members = records_of_gdu_members
			
			#if (sgdu_id == '70290'):
				# print('wanted_gdu_members',wanted_gdu_members)
				# print(array_of_distinct_gdu_ids)
				# print(array_of_all_distinct_gdu_members)
			if (len(wanted_gdu_members) > 0):
				list_of_wanted_gdu_fts = []
				for each_gdu_ft in gdu_features:
					if (each_gdu_ft.is_valid_at_time(reconstruction_time) and each_gdu_ft.get_reconstruction_plate_id() in wanted_gdu_members):
						list_of_wanted_gdu_fts.append(each_gdu_ft)
				
				#the thing: there is a time latency between when SuperGDU feature occurs and when CON-OCN line features occur. 
				#if (len(list_of_wanted_gdu_fts) == 0):
					#print("Error could not find any gdu features for SuperGDU feature",sgdu_id)
					#print('records_of_gdu_members')
					#print(records_of_gdu_members)
					#pygplates.FeatureCollection(sgdu_ft).write('SGDU_feature_'+str(sgdu_id)+'_could_not_find_gdus.shp')
					# for each_gdu_ft in gdu_features:
						# if (each_gdu_ft.get_reconstruction_plate_id() == 19508):
							# print('each_gdu_ft.get_reconstruction_plate_id()',each_gdu_ft.get_reconstruction_plate_id())
							# print(each_gdu_ft.get_reconstruction_plate_id() in wanted_gdu_members)
					# exit()
				dict_of_sgdu_and_members_ids[sgdu_id] = list_of_wanted_gdu_fts
	return dict_of_sgdu_and_members_ids

def find_centroid_of_each_reconstructed_gdu_ft(final_reconstructed_gdu_features):
	dict_of_gdu_and_centroid = {}
	for recontructed_gdu_ft, polygon in final_reconstructed_gdu_features:
		gdu_id = recontructed_gdu_ft.get_reconstruction_plate_id()
		centroid = polygon.get_interior_centroid()
		polygid = recontructed_gdu_ft.get_shapefile_attribute('POLYGID')
		# if (str(gdu_id) not in dict_of_gdu_and_centroid):
			# dict_of_gdu_and_centroid[str(gdu_id)] = [(centroid,polygid)]
		# else:
			# dict_of_gdu_and_centroid[str(gdu_id)].append((centroid,polygid))
		
		if (polygid not in dict_of_gdu_and_centroid):
			dict_of_gdu_and_centroid[polygid] = [(centroid,polygid)]
		else:
			dict_of_gdu_and_centroid[polygid].append((centroid,polygid))
		
	return dict_of_gdu_and_centroid

def find_neighbours_of_each_reconstructed_gdu_ft(dict_of_gdu_and_centroid,threshold_distance_in_km_for_neighbour):
	dict_of_neighbours = {}
	# for str_gduid in dict_of_gdu_and_centroid:
		# tuples_of_centroid_and_polygid = dict_of_gdu_and_centroid[str_gduid]
		# for other_str_gduid in dict_of_gdu_and_centroid:
			# if (other_str_gduid != str_gduid):
				# tuples_of_other_centroid_and_polygid = dict_of_gdu_and_centroid[str_gduid]
				# for centroid_of_polygid, polygid in tuples_of_centroid_and_polygid:
					# lat1,lon1 = centroid_of_polygid.to_lat_lon()
					# for other_centroid, other_polygid in tuples_of_other_centroid_and_polygid:
						# lat2,lon2 = other_centroid.to_lat_lon()
						# if (calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2) <= threshold_distance_in_km_for_neighbour):
							# if (str_gduid not in dict_of_neighbours):
								# dict_of_neighbours[str_gduid] = [other_centroid]
							# else:
								# dict_of_neighbours[str_gduid].append(other_centroid)
	
	for polygid in dict_of_gdu_and_centroid:
		tuples_of_centroid_and_polygid = dict_of_gdu_and_centroid[polygid]
		for other_polygid in dict_of_gdu_and_centroid:
			if (other_polygid != polygid):
				tuples_of_other_centroid_and_polygid = dict_of_gdu_and_centroid[other_polygid]
				for centroid_of_polygid, _ in tuples_of_centroid_and_polygid:
					lat1,lon1 = centroid_of_polygid.to_lat_lon()
					for other_centroid, _ in tuples_of_other_centroid_and_polygid:
						lat2,lon2 = other_centroid.to_lat_lon()
						if (calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2) <= threshold_distance_in_km_for_neighbour):
							if (polygid not in dict_of_neighbours):
								#dict_of_neighbours[polygid] = [(other_centroid,other_polygid)]
								dict_of_neighbours[polygid] = [other_polygid]
							else:
								#dict_of_neighbours[polygid].append((other_centroid,other_polygid))
								dict_of_neighbours[polygid].append(other_polygid)
	
	return dict_of_neighbours

def find_magnitude_azimuth_inclination_from_a_ref_point_to_a_given_point(ref_point, given_point):
	'''ref_point and given_point have data type as PointOnSphere in pygplates'''
	if (ref_point == given_point):
		print('ref_point == given_point in find_azimuth_from_a_ref_point_to_a_given_point')
		return None
	elif (ref_point is None or given_point is None):
		print('ref_point is None or given_point is None')
		print('ref_point', ref_point, 'given_point', given_point)
		return None
	else:
		#local_cartesian = pygplates.LocalCartesian(ref_point)
		geocentric_vec = pygplates.Vector3D(given_point.to_xyz())
		mag,azi,inc = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(ref_point,geocentric_vec)
		return mag,azi,inc

def find_planar_vector_direction_from_a_ref_point_to_a_given_point(ref_point, given_point):
	'''ref_point and given_point have data type as Point in Shapely with planar projection coordinates xy'''
	vec_x = given_point.x - ref_point.x
	vec_y = given_point.y - ref_point.y
	return (vec_x,vec_y)

def calculate_dot_product_between_two_planar_vectors(tuple_vec1, tuple_vec2):
	#compute dot product
	x1,y1 = tuple_vec1
	x2,y2 = tuple_vec2
	dot_prod = (x1*x2)+(y1*y2)
	return dot_prod

def calculate_magnitude_of_a_planar_vector(tuple_vec1):
	x1,y1 = tuple_vec1
	magnitude_of_vec1 = math.sqrt((x1*x1)+(y1*y1))
	return magnitude_of_vec1

def calculate_angle_between_two_planar_vectors(tuple_vec1, tuple_vec2):
	#compute dot product
	dot_prod = calculate_dot_product_between_two_planar_vectors(tuple_vec1, tuple_vec2)
	#compute magnitude of each vector
	magnitude_of_vec1 = calculate_magnitude_of_a_planar_vector(tuple_vec1)
	magnitude_of_vec2 = calculate_magnitude_of_a_planar_vector(tuple_vec2)
	#cosine angle between two vectors
	cosine_angle_rads = dot_prod/(magnitude_of_vec1*magnitude_of_vec2)
	if (cosine_angle_rads < -1.00 or cosine_angle_rads > 1.00):
		print("cosine_angle_rads is out of the range -1.00 to 1.00")
		return None
	theta = math.acos(cosine_angle_rads)
	theta_degrees = math.degrees(theta)
	return theta_degrees

def examine_position_of_unknown_pt_relative_to_from_and_to_pts_in_planar_coordinates(from_point,to_point,unknown_point,maximum_accepted_angle_in_degrees):
	'''from_point, to_point and unknown_point have data type as Point in Shapely with planar projection coordinates xy'''
	ref_vec_direction = find_planar_vector_direction_from_a_ref_point_to_a_given_point(from_point,to_point)
	vec_direction_from_pt_to_unknown_pt = find_planar_vector_direction_from_a_ref_point_to_a_given_point(from_point,unknown_point)
	angle_between_two_planar_vectors = calculate_angle_between_two_planar_vectors(ref_vec_direction, vec_direction_from_pt_to_unknown_pt)
	if (angle_between_two_planar_vectors is None):
		return 'invalid'
	if (angle_between_two_planar_vectors <= maximum_accepted_angle_in_degrees):
		magnitude_of_ref_vec = calculate_magnitude_of_a_planar_vector(ref_vec_direction)
		magnitude_of_other_vec = calculate_magnitude_of_a_planar_vector(vec_direction_from_pt_to_unknown_pt)
		if (magnitude_of_other_vec <= magnitude_of_ref_vec):
			return 'between'
		else:
			return 'possibly_between'
	else:
		return 'outside'

def is_line_crossing_polygon(point_1, point_2, polygon, threshold_distance_in_km):
	"""point_1, point_2 and polygon have planar projected coordinates
	point_1 and point_2 have data type as Point and polygon has data type as Polygon in Shapely"""
	linestring = LineString([point_1,point_2])
	if (linestring.crosses(polygon) == True or linestring.within(polygon) == True):
		#find the portion of linestring intersecting Polygon and obtain its length
		portion = linestring.intersection(polygon)
		portion_in_meters = portion.length #length of the intersecting segment is in meters because often the planar map projection has unit in meters
		portion_in_km = portion_in_meters/1000.00
		if (portion_in_km >= threshold_distance_in_km):
			return True
		else:
			return False
	else:
		return False

def find_the_mid_of_two_PointOnSphere(p1,p2):
	"""
		p1 and p2: pygplates.PointOnSphere
		Return: a mid point between p1 and p2 in the datatype pygplates.PointOnSphere
		
		p1 and p2 can be expressed as (x,y,z) coordinates in pygplates. Thus, mid_point(x,y,z) = (x1+x2/2.0, y1+y2/2.0, z1+z2/2.0)
	"""
	x1,y1,z1 = p1.to_xyz()
	x2,y2,z2 = p2.to_xyz()
	mid_point_x = (x1+x2)/2.00
	mid_point_y = (y1+y2)/2.00
	mid_point_z = (z1+z2)/2.00
	
	vector = pygplates.Vector3D([mid_point_x, mid_point_y, mid_point_z])
	normalized_vector = vector.to_normalised()
	
	mid_point = pygplates.PointOnSphere(normalized_vector.to_xyz())
	return mid_point

def identify_left_gdu_and_right_gdu(normal_unit_vector, rift_point_location, mid_point_line_1, mid_point_line_2, plate_id_1, plate_id_2):
	#Method 1:
	opposite_unit_vector = normal_unit_vector*(-1.00)
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z = mid_point_line_2.to_xyz()
	
	#identify left and right
	vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	vector_to_line_2 = pygplates.Vector3D([(mid_point_line_2_x-rift_point_location_x),(mid_point_line_2_y-rift_point_location_y),(mid_point_line_2_z-rift_point_location_z)])
	normalized_vector_to_line_2 = vector_to_line_2.to_normalised()
	
	left = None
	right = None 

	if (pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,opposite_unit_vector) > 0):
		left = plate_id_1
		right = plate_id_2
	elif (pygplates.Vector3D.dot(normalized_vector_to_line_1,opposite_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector) > 0):
		left = plate_id_2
		right = plate_id_1
	
	if (left is not None and right is not None):
		return (left,right)

	magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z)
	if (azimuth <= math.pi or azimuth == 2*math.pi):
		right = plate_id_1
	elif (azimuth > math.pi):
		left = plate_id_1
	magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z)
	if (azimuth <= math.pi or azimuth == 2*math.pi):
		right = plate_id_2
	elif (azimuth > math.pi):
		left = plate_id_2
	return (left,right)

def find_total_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,reconstruction_time,reference_frame):
	"""
	Total reconstruction is a reconstruction relative to the present (in time) and relative to any reference frame (spin axis or mantle or anything else)
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_stage_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,from_time,to_time,reference_frame):
	"""
	Relative stage reconstruction is a reconstruction from any from_time to any to_time between any two GDUIDS
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("from_time,to_time")
		print(from_time,to_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(line):
	if (line.get_arc_length() > 0.00):
		list_of_lon_lat_vertices = [(lon,lat) for lat,lon in line.to_lat_lon_list()]
		linestr = LineString(list_of_lon_lat_vertices)
		if (linestr is None):
			print ("Error to convert convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely")
			print ("Here is a list_of_lon_lat_vertices")
			print (list_of_lon_lat_vertices)
			exit()
		return linestr
	else:
		print ("Error in convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely")
		print ("line.get_arc_length == 0")
		print ("here are coords for line:")
		print((line.to_lat_lon_list()))
		print ("here is line")
		print (line)
		exit()

def are_two_PolylineOnSphere_similar(geom1,geom2):
	line_in_LineStr = convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(geom1)
	other_line_in_LineStr = convert_LineOnSphere_in_pygplates_to_LineString_in_Shapely(geom2)
	result_of_geom_rlx = line_in_LineStr.equals(other_line_in_LineStr)
	if (result_of_geom_rlx == False):
		result_of_geom_rlx = line_in_LineStr.equals_exact(other_line_in_LineStr,tolerance=0.500)
		if (result_of_geom_rlx == False):
			coords_other_LineString = list(other_line_in_LineStr.coords)
			coords_other_LineString.reverse()
			other_line_in_LineStr_reversed = LineString(coords_other_LineString)
			result_of_geom_rlx = line_in_LineStr.equals_exact(other_line_in_LineStr_reversed,tolerance=0.500)
			if (result_of_geom_rlx == False):
				result_of_geom_rlx = line_in_LineStr.covers(other_line_in_LineStr_reversed)
				if (result_of_geom_rlx == False):
					result_of_geom_rlx = other_line_in_LineStr_reversed.covers(line_in_LineStr)
	return result_of_geom_rlx

def is_point_in_between_point_A_and_B_using_greatcirclearc(suspected_point,point_B,point_A):
	if (point_B == point_A or point_B == suspected_point):
		return None
	greatcirclearc_from_B_to_A = pygplates.GreatCircleArc(point_B,point_A)
	rad_arc_len_from_B_to_A = greatcirclearc_from_B_to_A.get_arc_length()
	greatcirclearc_from_B_to_suspected = pygplates.GreatCircleArc(point_B,suspected_point)
	rad_arc_len_from_B_to_suspected = greatcirclearc_from_B_to_suspected.get_arc_length()
	if (rad_arc_len_from_B_to_suspected <= rad_arc_len_from_B_to_A):
		dir_at_suspected = greatcirclearc_from_B_to_suspected.get_arc_direction(1.00)
		dir_at_A = greatcirclearc_from_B_to_A.get_arc_direction(1.00)
		angle = pygplates.Vector3D.angle_between(dir_at_A,dir_at_suspected)
		if (angle <= (math.pi/4.00)):
			return True
		else:
			return False
	else:
		return None

def classify_kinematics_for_line_features(rotation_model, common_filename_for_previous_tectonic_motion_from_div, common_filename_for_previous_tectonic_motion_from_conv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, threshold_distance_in_km_for_neighbour, threshold_distance_in_km, yearmonthday, modelname):
	dic_of_kin_sgdus = {}
	dict_of_polygid_and_Shapely_centroid = {}
	dic_of_gdu_members_for_each_sgdu = {}
	#previous_kin_line_feats = []
	temp_list_of_centroids_and_polygids = []
	reconstructed_sgdu_features = []
	output_kinematics = []
	suspected_output = []
	appropriate_pairs_of_sgdus = []
	key_of_sgdus = []
	reconstructed_gdu_fts_for_sgdu1 = []
	reconstructed_gdu_fts_for_sgdu2 = []
	prev_reconstructed_gdu_fts_for_sgdu1 = []
	prev_reconstructed_gdu_fts_for_sgdu2 = []
	reconstructed_gdu_features = []
	reconstructed_line_features = []
	other_reconstructed_gdu_features = []
	output_rift_point_features = pygplates.FeatureCollection()
	output_kinematic_line_features = pygplates.FeatureCollection()
	unsure_topology_for_MOR_fts = pygplates.FeatureCollection()
	#kin_line_feats_at_reconstruction_time = []
	list_of_ordered_pairs_gdu_fts = []
	output_temporary_MOR_line_feats = []
	dic_kin_line_feats = {}
	output_records_for_kin_feats = []
	results_of_all_possible_tectonic_motion = []
	pairs_of_kin_line_fts = []
	if (end_reconstruction_time <= 0.00):
		end_reconstruction_time = time_interval #if end_reconstruction_time == 0.00 and time_interval is 5.00, then update the last time instant to be evaluate to be 5.00
	reconstruction_time = begin_reconstruction_time
	while(reconstruction_time >= end_reconstruction_time):
		#debug
		#temporary_output_pair_div_line_fts = pygplates.FeatureCollection()
		print('reconstruction_time',reconstruction_time)
		filename_for_possible_tectonic_motion_from_div = common_filename_for_previous_tectonic_motion_from_div.format(time = str(reconstruction_time))
		possible_tectonic_motion_from_div_df = pd.read_csv(filename_for_possible_tectonic_motion_from_div)
		filename_for_possible_tectonic_motion_from_conv = common_filename_for_previous_tectonic_motion_from_conv.format(time = str(reconstruction_time))
		possible_tectonic_motion_from_conv_df = pd.read_csv(filename_for_possible_tectonic_motion_from_conv)
		dic_of_gdu_members_for_each_sgdu.clear()
		reconstructed_sgdu_features[:] = []
		reconstructed_gdu_features[:] = []
		reconstructed_line_features[:] = []
		other_reconstructed_gdu_features[:] = []
		results_of_all_possible_tectonic_motion[:] = []
		# #8) Find appropriate pairs of sgdus first based on the distance
		# #8i) Find valid sgdu features
		valid_sgdu_features = [sgdu_ft for sgdu_ft in sgdu_features if (sgdu_ft.is_valid_at_time(reconstruction_time))]
		# #8ii) Reconstruct sgdu features to reconstruction time
		if (reference is not None):
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_sgdu_features = find_final_reconstructed_geometries(reconstructed_sgdu_features, pygplates.PolygonOnSphere)
		#Find valid gdu features with con-ocn line features
		valid_con_ocn_line_features = [con_ocn_ft for con_ocn_ft in line_features_collection if con_ocn_ft.is_valid_at_time(reconstruction_time)]
		if (reference is not None):
			pygplates.reconstruct(valid_con_ocn_line_features, rotation_model, reconstructed_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_con_ocn_line_features, rotation_model, reconstructed_line_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_line_features, pygplates.PolylineOnSphere)
		polygid_all_valid_line_features = [con_ocn_ft.get_shapefile_attribute('polygid') for con_ocn_ft in valid_con_ocn_line_features]
		array_of_all_valid_polygid = np.array(polygid_all_valid_line_features)
		# #8i) Find valid gdu features at reconstruction_time 
		valid_in_time_gdu_features = [gdu_ft for gdu_ft in gdu_features_collection if (gdu_ft.is_valid_at_time(reconstruction_time))]
		valid_gdu_features = []
		already_included_gdu_fts = []
		for valid_line_ft,valid_line in final_reconstructed_line_features:
			#debug
			#if (valid_line_ft.get_reconstruction_plate_id() == 19508):
			#	print(valid_line_ft.get_reconstruction_plate_id())
			
			for gdu_ft in valid_in_time_gdu_features:
				if (valid_line_ft.get_shapefile_attribute('polygid') == gdu_ft.get_shapefile_attribute('POLYGID')):
					if (gdu_ft.get_feature_id() not in already_included_gdu_fts):
						valid_gdu_features.append(gdu_ft)
						already_included_gdu_fts.append(gdu_ft.get_feature_id())
				# else:
					# if (gdu_ft.get_reconstruction_plate_id() == valid_line_ft.get_reconstruction_plate_id()):
						# if (gdu_ft.get_feature_id() not in already_included_gdu_fts):
							# valid_gdu_features.append(gdu_ft)
							# already_included_gdu_fts.append(gdu_ft.get_feature_id())
		print('len(valid_gdu_features)',len(valid_gdu_features))
		print('len(valid_con_ocn_line_features)',len(valid_con_ocn_line_features))
						
		# #8ii) Reconstruct gdu features to reconstruction time
		if (reference is not None):
			pygplates.reconstruct(valid_gdu_features, rotation_model, reconstructed_gdu_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_gdu_features, rotation_model, reconstructed_gdu_features, reconstruction_time, group_with_feature = True)
		final_reconstructed_gdu_features = find_final_reconstructed_geometries(reconstructed_gdu_features, pygplates.PolygonOnSphere)
		dict_of_gdu_and_centroid = find_centroid_of_each_reconstructed_gdu_ft(final_reconstructed_gdu_features)
		dict_of_neighbours = find_neighbours_of_each_reconstructed_gdu_ft(dict_of_gdu_and_centroid,threshold_distance_in_km_for_neighbour)
		dic_of_gdu_members_for_each_sgdu = find_gdu_members_of_each_sgdu_feat(valid_gdu_features, valid_sgdu_features, common_filename_for_temporary_sgdu_and_members_csv, reconstruction_time)
		print('number of sgdu features in dic_of_gdu_members_for_each_sgdu',len(dic_of_gdu_members_for_each_sgdu))
		
		#information store in possible tectonic motion at each reconstruction time: 'reconstruction_time','SGDU1','SGDU2','tectonic_motion'

		already_evaluated_pairs_of_sgdus = []
		for sgdu_ft_1, sgdu_1 in final_reconstructed_sgdu_features:
			sgduid_1 = sgdu_ft_1.get_name()
			repgduid_1 = sgdu_ft_1.get_reconstruction_plate_id()
			for sgdu_ft_2, sgdu_2 in final_reconstructed_sgdu_features:
				sgduid_2 = sgdu_ft_2.get_name()
				repgduid_2 = sgdu_ft_2.get_reconstruction_plate_id()
				key  = sgduid_1+'+'+sgduid_2
				rev_key = sgduid_2+'+'+sgduid_1
				if ((key not in already_evaluated_pairs_of_sgdus) and (rev_key not in already_evaluated_pairs_of_sgdus) and (sgduid_1!= sgduid_2) and (key not in dic_of_kin_sgdus) and (rev_key not in dic_of_kin_sgdus)):
					#check whether the two sgdu already have been evaluated together in previous processes
					records_from_div = possible_tectonic_motion_from_div_df.loc[(possible_tectonic_motion_from_div_df['reconstruction_time'] == reconstruction_time) & (((possible_tectonic_motion_from_div_df['SGDU1'] == sgduid_1) & (possible_tectonic_motion_from_div_df['SGDU2'] == sgduid_2))|((possible_tectonic_motion_from_div_df['SGDU1'] == sgduid_2) & (possible_tectonic_motion_from_div_df['SGDU2'] == sgduid_1)))]
					records_from_conv = possible_tectonic_motion_from_conv_df.loc[(possible_tectonic_motion_from_conv_df['reconstruction_time'] == reconstruction_time) & (((possible_tectonic_motion_from_conv_df['SGDU1'] == sgduid_1) & (possible_tectonic_motion_from_conv_df['SGDU2'] == sgduid_2))|((possible_tectonic_motion_from_conv_df['SGDU1'] == sgduid_2) & (possible_tectonic_motion_from_conv_df['SGDU2'] == sgduid_1)))]
					if (len(records_from_div) == 0 and len(records_from_conv) == 0):
						gdu_features_for_sgdu1 = dic_of_gdu_members_for_each_sgdu[str(sgduid_1)]
						gdu_features_for_sgdu2 = dic_of_gdu_members_for_each_sgdu[str(sgduid_2)]
						#use the two repgduids from the two children 
						total_relative_reconstruction_rotation = find_total_relative_reconstruction_rotation_(rotation_model, repgduid_1, repgduid_2, float(reconstruction_time), reference)
						total_stage_rel_rot_of_1_to_2 = find_stage_relative_reconstruction_rotation_(rotation_model,repgduid_1,repgduid_2,float(reconstruction_time+time_interval),reconstruction_time,reference)
						total_stage_rel_rot_of_2_to_1 = find_stage_relative_reconstruction_rotation_(rotation_model,repgduid_2,repgduid_1,float(reconstruction_time+time_interval),reconstruction_time,reference)
						if (total_relative_reconstruction_rotation is not None):
							if (total_relative_reconstruction_rotation.represents_identity_rotation() == False):
								#check whether the pair of sgdus is valid
								child_sgud_1 = []
								child_sgud_2 = []
								non_related = []
								for yng_sgdu_ft,yng_sgdu in final_reconstructed_sgdu_features:
									if (yng_sgdu_ft.get_name() == str(sgduid_1)):
										child_sgud_1.append(yng_sgdu)
									elif (yng_sgdu_ft.get_name() == str(sgduid_2)):
										child_sgud_2.append(yng_sgdu)
									else:
										non_related.append(yng_sgdu)
								reconstructed_gdu_fts_for_sgdu1[:] = []
								reconstructed_gdu_fts_for_sgdu2[:] = []
								list_of_already_used_line_fts = []
								final_reconstructed_gdu_features_for_sgdu1 = []
								final_reconstructed_gdu_features_for_sgdu2 = []
								polygid_features_for_sgdu1 = [child_gdu_ft.get_shapefile_attribute('POLYGID') for child_gdu_ft in gdu_features_for_sgdu1]
								array_for_polygid_ft_sgdu1 = np.array(polygid_features_for_sgdu1)
								wanted_gdu_members_for_sgdu1 = np.intersect1d(array_for_polygid_ft_sgdu1,array_of_all_valid_polygid)
								polygid_features_for_sgdu2 = [child_gdu_ft.get_shapefile_attribute('POLYGID') for child_gdu_ft in gdu_features_for_sgdu2]
								array_for_polygid_ft_sgdu2 = np.array(polygid_features_for_sgdu2)
								wanted_gdu_members_for_sgdu2 = np.intersect1d(array_for_polygid_ft_sgdu2,array_of_all_valid_polygid)
								
								#CON-OCN line features that exit at the younger time (i.e. reconstruction_time - time_interval) and invalid at reconstruction_time
								#for child_gdu_ft_1, child_line_gdu_1 in final_reconstructed_line_features_ynger:
								for child_gdu_ft_1, child_line_gdu_1 in final_reconstructed_line_features:
									polygid_for_child_1 = child_gdu_ft_1.get_shapefile_attribute('polygid')
									#if ((polygid_for_child_1 in wanted_gdu_members_for_sgdu1) and (polygid_for_child_1 not in polygid_features_for_sgdu1_at_prev_time)):
									if (polygid_for_child_1 in wanted_gdu_members_for_sgdu1):
										for reconstructed_sgdu_1 in child_sgud_1:
											if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu_1,child_line_gdu_1) == 0.00):
												reconstructed_gdu_fts_for_sgdu1.append((child_gdu_ft_1, child_line_gdu_1))
												break
								#for child_gdu_ft_2, child_line_gdu_2 in final_reconstructed_line_features_ynger:
								for child_gdu_ft_2, child_line_gdu_2 in final_reconstructed_line_features:
									polygid_for_child_2 = child_gdu_ft_2.get_shapefile_attribute('polygid')
									#if ((polygid_for_child_2 in polygid_features_for_sgdu2) and (polygid_for_child_2 not in polygid_features_for_sgdu2_at_prev_time)):
									if (polygid_for_child_2 in wanted_gdu_members_for_sgdu2):
										for reconstructed_sgdu_2 in child_sgud_2:
											if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu_2,child_line_gdu_2) == 0.00):
												reconstructed_gdu_fts_for_sgdu2.append((child_gdu_ft_2, child_line_gdu_2))
												break
								print('len(reconstructed_gdu_fts_for_sgdu1)',len(reconstructed_gdu_fts_for_sgdu1))
								print('len(reconstructed_gdu_fts_for_sgdu2)',len(reconstructed_gdu_fts_for_sgdu2))
								
								E_pole,angle_rads = total_relative_reconstruction_rotation.get_euler_pole_and_angle()
								stage_rel_E_pole = None
								if (total_stage_rel_rot_of_1_to_2 is not None):
									if (total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == False):
										stage_rel_E_pole,_ = total_stage_rel_rot_of_1_to_2.get_euler_pole_and_angle()
								elif (total_stage_rel_rot_of_2_to_1 is not None):
									if (total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == False):
										stage_rel_E_pole,_ = total_stage_rel_rot_of_2_to_1.get_euler_pole_and_angle()
								if (stage_rel_E_pole is None):
									stage_rel_E_pole = E_pole
								result_of_tectonic_motion = None
								
								list_of_already_evaluated_pairs = []
								for line_feature_1, line_gdu_1 in reconstructed_gdu_fts_for_sgdu1:
									centroid_line_1 = line_gdu_1.get_centroid()
									for line_feature_2, line_gdu_2 in reconstructed_gdu_fts_for_sgdu2:
										centroid_line_2 = line_gdu_2.get_centroid()
										pair_polylids = line_feature_1.get_shapefile_attribute('POLYLID')+'+'+line_feature_2.get_shapefile_attribute('POLYLID')
										rev_pair_of_polylids = line_feature_2.get_shapefile_attribute('POLYLID')+'+'+line_feature_1.get_shapefile_attribute('POLYLID')
										if (pair_polylids in list_of_already_evaluated_pairs or rev_pair_of_polylids in list_of_already_evaluated_pairs):
											continue #these two line features have already been evaluated at this reconstruction time thus take the new tuple
										else:
											list_of_already_evaluated_pairs.append(pair_polylids)
										
											if (total_stage_rel_rot_of_1_to_2 is not None and total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == False):
												result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_line_2, centroid_line_1, stage_rel_E_pole)
											elif (total_stage_rel_rot_of_2_to_1 is not None and total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == False):
												result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_line_1, centroid_line_2, stage_rel_E_pole)
											else:
												result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(centroid_line_2, centroid_line_1, stage_rel_E_pole)
											
											#record all possible values of tectonic-motion to double-check with results when running identify_convergent_boundaries which is processing from present-day to the past
											results_of_all_possible_tectonic_motion.append((reconstruction_time,sgduid_1,sgduid_2,repgduid_1,repgduid_2,result_of_tectonic_motion))
											
											#find the mid_point between two points
											closest_point_on_gdu1 = centroid_line_1
											closest_point_on_gdu2 = centroid_line_2
											approx_mid_point = find_the_mid_of_two_PointOnSphere(closest_point_on_gdu1,closest_point_on_gdu2)
											valid_mid_point_feat = False
											if (approx_mid_point == closest_point_on_gdu1 or approx_mid_point == closest_point_on_gdu2):
												temp_list_of_closest_point_on_gdu1 = dict_of_gdu_and_centroid[line_feature_1.get_shapefile_attribute('polygid')]
												closest_point_on_gdu1 = temp_list_of_closest_point_on_gdu1[0][0]
												temp_list_of_closest_point_on_gdu2 = dict_of_gdu_and_centroid[line_feature_2.get_shapefile_attribute('polygid')]
												closest_point_on_gdu2 = temp_list_of_closest_point_on_gdu2[0][0]
												valid_mid_point_feat = True
											if (valid_mid_point_feat == False):
												if (pygplates.GeometryOnSphere.distance(line_gdu_1,line_gdu_2) == 0.00):
													valid_mid_point_feat = True
												else:
													for reconstructed_sgdu_1 in child_sgud_1:
														if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu_1,line_gdu_2) == 0.00):
															valid_mid_point_feat = True
															break
													if (valid_mid_point_feat == False):
														for reconstructed_sgdu_2 in child_sgud_2:
															if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu_2,line_gdu_1) == 0.00):
																valid_mid_point_feat = True
																break
											#NEW - check whether approx_mid_point positioned within any SGDUs
											if (valid_mid_point_feat == False):
												are_lines_similar = are_two_PolylineOnSphere_similar(line_gdu_1,line_gdu_2)
												if (are_lines_similar == True):
													valid_mid_point_feat = True
												elif (valid_mid_point_feat == False):
													#temporarily set valid_mid_point_feat to True
													valid_mid_point_feat = True
													for random_sgdu in non_related:
														if (random_sgdu.partition(approx_mid_point) == pygplates.PolygonOnSphere.PartitionResult.inside):
															valid_mid_point_feat = False
															break
													if (valid_mid_point_feat == True):
														for reconstructed_sgdu_2 in child_sgud_2:
															if (reconstructed_sgdu_2.partition(approx_mid_point) == pygplates.PolygonOnSphere.PartitionResult.inside):
																valid_mid_point_feat = False
																break
													if (valid_mid_point_feat == True):
														for reconstructed_sgdu_1 in child_sgud_1:
															if (reconstructed_sgdu_1.partition(approx_mid_point) == pygplates.PolygonOnSphere.PartitionResult.inside):
																valid_mid_point_feat = False
																break
											if (valid_mid_point_feat == True):
												#create an arc
												temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
												normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
												
												#create point feature
												#name = 'R'+str(child_1)+'_'+str(child_2)+'_'+str(smallest_circle_angular_radius_degrees)
												name = None
												intersecting_small_circle_boundary = None
												if (result_of_tectonic_motion == 'D'):
													smallest_circle_angular_radius_degrees = 178.00
													while (smallest_circle_angular_radius_degrees > 0.00):
														small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
														approx_rad_closest_dist_neighbour,closest_point_on_gdu1,_ = pygplates.GeometryOnSphere.distance(line_gdu_1, small_circle_boundary,return_closest_positions = True)
														approx_rad_closest_dist_ref,closest_point_on_gdu2,_= pygplates.GeometryOnSphere.distance(line_gdu_2, small_circle_boundary,return_closest_positions = True)
														if (approx_rad_closest_dist_neighbour == approx_rad_closest_dist_ref == 0.00):
															intersecting_small_circle_boundary = smallest_circle_angular_radius_degrees
															break
														smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 2.00
													if (intersecting_small_circle_boundary is None):
														smallest_circle_angular_radius_degrees = 179.00
														while (smallest_circle_angular_radius_degrees > 0.00):
															small_circle_boundary = rotation_utility.create_small_circle_PolylineOnSphere(E_pole,smallest_circle_angular_radius_degrees)
															approx_rad_closest_dist_neighbour,closest_point_on_gdu1,_ = pygplates.GeometryOnSphere.distance(line_gdu_1, small_circle_boundary,return_closest_positions = True)
															approx_rad_closest_dist_ref,closest_point_on_gdu2,_= pygplates.GeometryOnSphere.distance(line_gdu_2, small_circle_boundary,return_closest_positions = True)
															if (approx_rad_closest_dist_neighbour == approx_rad_closest_dist_ref == 0.00):
																intersecting_small_circle_boundary = smallest_circle_angular_radius_degrees
																break
															smallest_circle_angular_radius_degrees = smallest_circle_angular_radius_degrees - 1.00
													name = 'R'+key
													if (intersecting_small_circle_boundary is not None):
														new_approx_mid_point = find_the_mid_of_two_PointOnSphere(closest_point_on_gdu1,closest_point_on_gdu2)
														if (new_approx_mid_point != closest_point_on_gdu1 and new_approx_mid_point != closest_point_on_gdu2):
															approx_mid_point = new_approx_mid_point
													left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, closest_point_on_gdu1, closest_point_on_gdu2, line_feature_1.get_reconstruction_plate_id(), line_feature_2.get_reconstruction_plate_id())
													rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, approx_mid_point, name = name, valid_time = (reconstruction_time,0.00))
													if ((left_gduid == right_gduid)or (left_gduid is None) or (right_gduid is None)):
														rift_point_ft.set_left_plate(line_feature_1.get_reconstruction_plate_id())
														rift_point_ft.set_right_plate(line_feature_2.get_reconstruction_plate_id())
													else:
														rift_point_ft.set_left_plate(left_gduid)
														rift_point_ft.set_right_plate(right_gduid)
													rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
													if (reference is None):
														pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
													else:
														pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
													output_rift_point_features.add(rift_point_ft)
													if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
														unsure_topology_for_MOR_fts.add(rift_point_ft)
													if ((left_gduid == line_feature_1.get_reconstruction_plate_id() and right_gduid == line_feature_2.get_reconstruction_plate_id()) or (left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
														list_of_ordered_pairs_gdu_fts.append((reconstruction_time,name,smallest_circle_angular_radius_degrees, line_feature_1.get_shapefile_attribute('POLYLID'), line_feature_1.get_reconstruction_plate_id(), repgduid_1, line_feature_2.get_shapefile_attribute('POLYLID'), line_feature_2.get_reconstruction_plate_id(), repgduid_2))
													else:
														list_of_ordered_pairs_gdu_fts.append((reconstruction_time,name,smallest_circle_angular_radius_degrees, line_feature_2.get_shapefile_attribute('POLYLID'), line_feature_2.get_reconstruction_plate_id(), repgduid_2, line_feature_1.get_shapefile_attribute('POLYLID'), line_feature_1.get_reconstruction_plate_id(), repgduid_1))
												elif (result_of_tectonic_motion == 'C'):
													# #create point feature
													name = 'C'+key
													if (left_gduid == line_feature_1.get_reconstruction_plate_id() and right_gduid == line_feature_2.get_reconstruction_plate_id()):
														list_of_ordered_pairs_gdu_fts.append((reconstruction_time+time_interval,name, 0, line_feature_1.get_shapefile_attribute('POLYLID'), line_feature_1.get_reconstruction_plate_id(), repgduid_1, line_feature_2.get_shapefile_attribute('POLYLID'), line_feature_2.get_reconstruction_plate_id(), repgduid_2))
													else:
														list_of_ordered_pairs_gdu_fts.append((reconstruction_time+time_interval,name, 0, line_feature_2.get_shapefile_attribute('POLYLID'), line_feature_2.get_reconstruction_plate_id(), repgduid_2, line_feature_1.get_shapefile_attribute('POLYLID'), line_feature_1.get_reconstruction_plate_id(), repgduid_1))
												#create pair of line features associated with the rift point ft
												_,con_ocn_to_time = line_feature_1.get_valid_time()
												new_line_feature_1 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_1,name=line_feature_1.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
												new_line_feature_1.set_reconstruction_plate_id(line_feature_1.get_reconstruction_plate_id())
												new_line_feature_1.set_conjugate_plate_id(line_feature_2.get_reconstruction_plate_id())
												if (result_of_tectonic_motion == 'D'):
													new_line_feature_1.set_description('divergent_margin')
												elif (result_of_tectonic_motion == 'C'):
													new_line_feature_1.set_description('convergent_margin')
												_,con_ocn_to_time = line_feature_2.get_valid_time()
												new_line_feature_2 = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary,line_gdu_2,name=line_feature_2.get_shapefile_attribute('POLYLID'),valid_time = (reconstruction_time,con_ocn_to_time))
												new_line_feature_2.set_reconstruction_plate_id(line_feature_2.get_reconstruction_plate_id())
												new_line_feature_2.set_conjugate_plate_id(line_feature_1.get_reconstruction_plate_id())
												if (result_of_tectonic_motion == 'D'):
													new_line_feature_2.set_description('divergent_margin')
												elif (result_of_tectonic_motion == 'C'):
													new_line_feature_2.set_description('convergent_margin')
												if (reference is None):
													pygplates.reverse_reconstruct([new_line_feature_1,new_line_feature_2],rotation_model,reconstruction_time)
												else:
													pygplates.reverse_reconstruct([new_line_feature_1,new_line_feature_2],rotation_model,reconstruction_time,reference)
												if (key not in dic_of_kin_sgdus):
													dic_of_kin_sgdus[key] = [(reconstruction_time,new_line_feature_1,new_line_feature_2,result_of_tectonic_motion)]
												else:
													dic_of_kin_sgdus[key].append((reconstruction_time,new_line_feature_1,new_line_feature_2,result_of_tectonic_motion))
												#previous_kin_line_feats.append((new_line_feature_1,new_line_feature_2,reconstruction_time,pygplates.GeometryOnSphere.distance(line_gdu_1.get_centroid(),line_gdu_2.get_centroid())))
				elif ((key in dic_of_kin_sgdus) or (rev_key in dic_of_kin_sgdus)):
					if (rev_key in dic_of_kin_sgdus):
						key = rev_key
					#obtain list_of_kinematic_line_features 
					list_of_kinematic_line_features = dic_of_kin_sgdus[key]
					for recorded_time, recorded_line_ft_1, recorded_line_ft_2, recorded_tectonic_motion in list_of_kinematic_line_features:
						begin_age_line_ft_1,end_age_line_ft_1 = recorded_line_ft_1.get_valid_time()
						begin_age_line_ft_2,end_age_line_ft_2 = recorded_line_ft_2.get_valid_time()
						if ((recorded_time > reconstruction_time) and ((recorded_time - reconstruction_time) >= time_interval) and recorded_line_ft_1.is_valid_at_time(reconstruction_time) and recorded_line_ft_2.is_valid_at_time(reconstruction_time) and recorded_line_ft_1.is_valid_at_time(reconstruction_time+time_interval) and recorded_line_ft_2.is_valid_at_time(reconstruction_time+time_interval)):
							#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
							temporary_sgdu_and_member_csv_at_time = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
							temp_sgdu_and_gdu_df = pd.read_csv(temporary_sgdu_and_member_csv_at_time, delimiter = ';', header = 0)
							remaining_line_feats = []

							SGDUID_for_line_ft_1 = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == recorded_line_ft_1.get_reconstruction_plate_id(),'SGDUID'].unique()
							SGDUID_for_line_ft_2 = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == recorded_line_ft_2.get_reconstruction_plate_id(),'SGDUID'].unique()
							
							reconstructed_recorded_line_features = []
							if (reference is not None):
								pygplates.reconstruct([recorded_line_ft_1, recorded_line_ft_2], rotation_model, reconstructed_recorded_line_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct([recorded_line_ft_1, recorded_line_ft_2], rotation_model, reconstructed_recorded_line_features, reconstruction_time, group_with_feature = True)
							final_reconstructed_recorded_line_features = find_final_reconstructed_geometries(reconstructed_recorded_line_features, pygplates.PolylineOnSphere)
							current_reconstr_ft_1, current_reconstr_line_1 = final_reconstructed_recorded_line_features[0]
							current_reconstr_ft_2, current_reconstr_line_2 = final_reconstructed_recorded_line_features[1]
							
							reconstructed_prev_recorded_line_features = []
							if (reference is not None):
								pygplates.reconstruct([recorded_line_ft_1, recorded_line_ft_2], rotation_model, reconstructed_prev_recorded_line_features, reconstruction_time + time_interval, anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct([recorded_line_ft_1, recorded_line_ft_2], rotation_model, reconstructed_prev_recorded_line_features, reconstruction_time + time_interval, group_with_feature = True)
							final_prev_recorded_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_prev_recorded_line_features, pygplates.PolylineOnSphere)
							prev_reconstr_ft_1,prev_reconstr_line_1 = final_prev_recorded_reconstructed_line_features[0]
							prev_reconstr_ft_2,prev_reconstr_line_2 = final_prev_recorded_reconstructed_line_features[1]
					
							reconstructed_point_A_at_from_time = prev_reconstr_line_1.get_centroid()
							reconstructed_point_B_at_from_time = prev_reconstr_line_2.get_centroid()
							reconstructed_point_A_at_to_time = current_reconstr_line_1.get_centroid()
							reconstructed_point_B_at_to_time = current_reconstr_line_2.get_centroid()
							#result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_pos_and_angular_vel_vec(reconstructed_point_A_at_from_time, reconstructed_point_A_at_to_time, reconstructed_point_B_at_from_time, reconstructed_point_B_at_to_time, reconstruction_time, reconstruction_time-time_interval)
							result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_pos_and_angular_vel_vec(reconstructed_point_A_at_from_time, reconstructed_point_A_at_to_time, reconstructed_point_B_at_from_time, reconstructed_point_B_at_to_time, reconstruction_time+time_interval, reconstruction_time)
							
							is_valid_pair_of_line_fts = True
							for reconstructed_sgdu_ft_at_reconstruction_time, reconstructed_sgdu_at_reconstruction_time in final_reconstructed_sgdu_features:
								SGDUID_of_reconstructed_sgdu_ft = int(reconstructed_sgdu_ft_at_reconstruction_time.get_name())
								SGDUID_for_rand_sgdu_ft = temp_sgdu_and_gdu_df.loc[temp_sgdu_and_gdu_df['GDUID'] == reconstructed_sgdu_ft_at_reconstruction_time.get_reconstruction_plate_id(),'SGDUID'].unique()
								# #find the same value between SGDUID_for_gdu_ft and SGDUID_for_line_ft_1; SGDUID_for_gdu_ft and SGDUID_for_line_ft_2
								intersection_w_line_ft_1 = np.intersect1d(SGDUID_for_rand_sgdu_ft, SGDUID_for_line_ft_1)
								intersection_w_line_ft_2 = np.intersect1d(SGDUID_for_rand_sgdu_ft, SGDUID_for_line_ft_2)
								if (len(intersection_w_line_ft_1) == 0 and len(intersection_w_line_ft_2) == 0):
									temporary_line_connecting_A_and_B = pygplates.PolylineOnSphere([reconstructed_point_A_at_to_time,reconstructed_point_B_at_to_time])
									if (reconstructed_sgdu_at_reconstruction_time.partition(temporary_line_connecting_A_and_B) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
										is_valid_pair_of_line_fts = False
										break
							if (recorded_tectonic_motion == 'D'):
								print('is_valid_pair_of_line_fts',is_valid_pair_of_line_fts)
								print(result_of_tectonic_motion != 'D' and is_valid_pair_of_line_fts == True)
								if (result_of_tectonic_motion != 'D' and is_valid_pair_of_line_fts == True):
									#debug
									print('Enter this')
									#need to check the type of kinematic boundary in previous time
									if (recorded_line_ft_1.get_description() == 'plate_boundary_zone' and recorded_line_ft_2.get_description() == 'plate_boundary_zone'):
										line_feature_1_begin_time,line_feature_1_end_time = recorded_line_ft_1.get_valid_time()
										line_feature_2_begin_time,line_feature_2_end_time = recorded_line_ft_2.get_valid_time()
										cloned_line_ft_1 = recorded_line_ft_1.clone()
										cloned_line_ft_1.set_valid_time(line_feature_1_begin_time,reconstruction_time+0.100)
										cloned_line_ft_2 = recorded_line_ft_2.clone()
										cloned_line_ft_2.set_valid_time(line_feature_2_begin_time,reconstruction_time+0.100)
										output_kinematic_line_features.add(cloned_line_ft_1)
										output_kinematic_line_features.add(cloned_line_ft_2)
										pairs_of_kin_line_fts.append((line_feature_1_begin_time,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
										if (result_of_tectonic_motion == 'C'):
											recorded_line_ft_1.set_description('convergent_margin')
											recorded_line_ft_2.set_description('convergent_margin')
										elif (result_of_tectonic_motion == 'T'):
											recorded_line_ft_1.set_description('transform_fault')
											recorded_line_ft_2.set_description('transform_fault')
										if (line_feature_1_end_time <= reconstruction_time and line_feature_2_end_time <= reconstruction_time):
											recorded_line_ft_1.set_valid_time(reconstruction_time,line_feature_1_end_time)
											recorded_line_ft_2.set_valid_time(reconstruction_time,line_feature_2_end_time)
										else:
											recorded_line_ft_1 = None
											recorded_line_ft_2 = None
									elif (recorded_line_ft_1.get_description() != 'convergent_margin' and recorded_line_ft_2.get_description() != 'convergent_margin'):
										line_feature_1_begin_time,line_feature_1_end_time = recorded_line_ft_1.get_valid_time()
										line_feature_2_begin_time,line_feature_2_end_time = recorded_line_ft_2.get_valid_time()
										cloned_line_ft_1 = recorded_line_ft_1.clone()
										cloned_line_ft_1.set_valid_time(line_feature_1_begin_time,reconstruction_time+0.100)
										cloned_line_ft_2 = recorded_line_ft_2.clone()
										cloned_line_ft_2.set_valid_time(line_feature_2_begin_time,reconstruction_time+0.100)
										output_kinematic_line_features.add(cloned_line_ft_1)
										output_kinematic_line_features.add(cloned_line_ft_2)
										pairs_of_kin_line_fts.append((line_feature_1_begin_time,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
										if (result_of_tectonic_motion == 'C' and recorded_line_ft_1.get_description() == 'divergent_margin'):
											recorded_line_ft_1.set_description('plate_boundary_zone')
											recorded_line_ft_2.set_description('plate_boundary_zone')
										else:
											recorded_line_ft_1.set_description('transform_fault')
											recorded_line_ft_2.set_description('transform_fault')
										if (line_feature_1_end_time <= reconstruction_time and line_feature_2_end_time <= reconstruction_time):
											recorded_line_ft_1.set_valid_time(reconstruction_time,line_feature_1_end_time)
											recorded_line_ft_2.set_valid_time(reconstruction_time,line_feature_2_end_time)
										else:
											recorded_line_ft_1 = None
											recorded_line_ft_2 = None
									elif (recorded_line_ft_1.get_description() == 'convergent_margin' and recorded_line_ft_2.get_description() == 'convergent_margin'):
										line_feature_1_begin_time,line_feature_1_end_time = recorded_line_ft_1.get_valid_time()
										line_feature_2_begin_time,line_feature_2_end_time = recorded_line_ft_2.get_valid_time()
										cloned_line_ft_1 = recorded_line_ft_1.clone()
										cloned_line_ft_1.set_valid_time(line_feature_1_begin_time,reconstruction_time+0.100)
										cloned_line_ft_2 = recorded_line_ft_2.clone()
										cloned_line_ft_2.set_valid_time(line_feature_2_begin_time,reconstruction_time+0.100)
										output_kinematic_line_features.add(cloned_line_ft_1)
										output_kinematic_line_features.add(cloned_line_ft_2)
										pairs_of_kin_line_fts.append((line_feature_1_begin_time,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
										if (result_of_tectonic_motion == 'T'):
											recorded_line_ft_1.set_description('transform_fault')
											recorded_line_ft_2.set_description('transform_fault')
										if (line_feature_1_end_time <= reconstruction_time and line_feature_2_end_time <= reconstruction_time):
											recorded_line_ft_1.set_valid_time(reconstruction_time,line_feature_1_end_time)
											recorded_line_ft_2.set_valid_time(reconstruction_time,line_feature_2_end_time)
										else:
											recorded_line_ft_1 = None
											recorded_line_ft_2 = None
								elif (result_of_tectonic_motion == 'D' and is_valid_pair_of_line_fts == True):
									if (recorded_line_ft_1.get_description() == 'convergent_margin' and recorded_line_ft_2.get_description() == 'convergent_margin'):
										line_feature_1_begin_time,line_feature_1_end_time = recorded_line_ft_1.get_valid_time()
										line_feature_2_begin_time,line_feature_2_end_time = recorded_line_ft_2.get_valid_time()
										cloned_line_ft_1 = recorded_line_ft_1.clone()
										cloned_line_ft_1.set_valid_time(line_feature_1_begin_time,reconstruction_time+0.100)
										recorded_line_ft_1.set_description('plate_boundary_zone')
										cloned_line_ft_2 = recorded_line_ft_2.clone()
										cloned_line_ft_2.set_valid_time(line_feature_2_begin_time,reconstruction_time+0.100)
										output_kinematic_line_features.add(cloned_line_ft_1)
										output_kinematic_line_features.add(cloned_line_ft_2)
										recorded_line_ft_2.set_description('plate_boundary_zone')
										pairs_of_kin_line_fts.append((line_feature_1_begin_time,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
										if (line_feature_1_end_time <= reconstruction_time and line_feature_2_end_time <= reconstruction_time):
											recorded_line_ft_1.set_valid_time(reconstruction_time,line_feature_1_end_time)
											recorded_line_ft_2.set_valid_time(reconstruction_time,line_feature_2_end_time)
										else:
											recorded_line_ft_1 = None
											recorded_line_ft_2 = None
									elif (recorded_line_ft_1.get_description() != 'divergent_margin' and recorded_line_ft_1.get_description() != 'convergent_margin' and recorded_line_ft_2.get_description() != 'divergent_margin' and line_feature_2.get_description() != 'convergent_margin'):
										line_feature_1_begin_time,line_feature_1_end_time = recorded_line_ft_1.get_valid_time()
										line_feature_2_begin_time,line_feature_2_end_time = recorded_line_ft_2.get_valid_time()
										cloned_line_ft_1 = recorded_line_ft_1.clone()
										cloned_line_ft_1.set_valid_time(line_feature_1_begin_time,reconstruction_time+0.100)
										recorded_line_ft_1.set_description('divergent_margin')
										cloned_line_ft_2 = recorded_line_ft_2.clone()
										cloned_line_ft_2.set_valid_time(line_feature_2_begin_time,reconstruction_time+0.100)
										output_kinematic_line_features.add(cloned_line_ft_1)
										output_kinematic_line_features.add(cloned_line_ft_2)
										recorded_line_ft_2.set_description('divergent_margin')
										pairs_of_kin_line_fts.append((line_feature_1_begin_time,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
										if (line_feature_1_end_time <= reconstruction_time and line_feature_2_end_time <= reconstruction_time):
											recorded_line_ft_1.set_valid_time(reconstruction_time,line_feature_1_end_time)
											recorded_line_ft_2.set_valid_time(reconstruction_time,line_feature_2_end_time)
										else:
											recorded_line_ft_1 = None
											recorded_line_ft_2 = None
								if (is_valid_pair_of_line_fts == False):
									if (recorded_line_ft_1.get_description() != 'plate_boundary_zone' and recorded_line_ft_2.get_description() != 'plate_boundary_zone'):
										line_feature_1_begin_time,line_feature_1_end_time = recorded_line_ft_1.get_valid_time()
										line_feature_2_begin_time,line_feature_2_end_time = recorded_line_ft_2.get_valid_time()
										if (line_feature_1_begin_time > reconstruction_time):
											cloned_line_ft_1 = recorded_line_ft_1.clone()
											cloned_line_ft_1.set_valid_time(line_feature_1_begin_time,reconstruction_time+0.100)
											cloned_line_ft_2 = recorded_line_ft_2.clone()
											cloned_line_ft_2.set_valid_time(line_feature_2_begin_time,reconstruction_time+0.100)
											pairs_of_kin_line_fts.append((line_feature_1_begin_time,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
											output_kinematic_line_features.add(cloned_line_ft_1)
											output_kinematic_line_features.add(cloned_line_ft_2)
										recorded_line_ft_1.set_description('plate_boundary_zone')
										recorded_line_ft_2.set_description('plate_boundary_zone')
										if (line_feature_1_end_time <= reconstruction_time and line_feature_2_end_time <= reconstruction_time):
											recorded_line_ft_1.set_valid_time(reconstruction_time,line_feature_1_end_time)
											recorded_line_ft_2.set_valid_time(reconstruction_time,line_feature_2_end_time)
										else:
											recorded_line_ft_1 = None
											recorded_line_ft_2 = None
							elif (recorded_tectonic_motion == 'C'):
								if (result_of_tectonic_motion != 'C' and is_valid_pair_of_line_fts == True and reconstruction_time > end_age_line_ft_1):
									cloned_line_ft_1 = recorded_line_ft_1.clone()
									cloned_line_ft_1.set_valid_time(begin_age_line_ft_1,reconstruction_time+0.100)
									recorded_line_ft_1.set_valid_time(reconstruction_time,end_age_line_ft_1)
									cloned_line_ft_2 = recorded_line_ft_2.clone()
									cloned_line_ft_2.set_valid_time(begin_age_line_ft_2,reconstruction_time+0.100)
									output_kinematic_line_features.add(cloned_line_ft_1)
									output_kinematic_line_features.add(cloned_line_ft_2)
									pairs_of_kin_line_fts.append((begin_age_line_ft_1,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
									recorded_line_ft_2.set_valid_time(reconstruction_time,end_age_line_ft_2)
									if (recorded_line_ft_1.get_description() == 'convergent_margin' and recorded_line_ft_2.get_description() == 'convergent_margin'):
										recorded_line_ft_1.set_description('plate_boundary_zone')
										recorded_line_ft_2.set_description('plate_boundary_zone')
									elif (recorded_line_ft_1.get_description() != 'divergent_margin' and recorded_line_ft_2.get_description() != 'divergent_margin'):
										if (result_of_tectonic_motion == 'D'):
											recorded_line_ft_1.set_description('divergent_margin')
											recorded_line_ft_2.set_description('divergent_margin')
										elif (result_of_tectonic_motion == 'T'):
											recorded_line_ft_1.set_description('transform_fault')
											recorded_line_ft_2.set_description('transform_fault')
								elif (result_of_tectonic_motion == 'C' and is_valid_pair_of_line_fts == True and reconstruction_time > end_age_line_ft_1):
									if (recorded_line_ft_1.get_description() != 'convergent_margin' and recorded_line_ft_2.get_description() != 'convergent_margin'):
										cloned_line_ft_1 = recorded_line_ft_1.clone()
										cloned_line_ft_1.set_valid_time(begin_age_line_ft_1,reconstruction_time+0.100)
										recorded_line_ft_1.set_valid_time(reconstruction_time,end_age_line_ft_1)
										cloned_line_ft_2 = recorded_line_ft_2.clone()
										cloned_line_ft_2.set_valid_time(begin_age_line_ft_2,reconstruction_time+0.100)
										recorded_line_ft_2.set_valid_time(reconstruction_time,end_age_line_ft_2)
										output_kinematic_line_features.add(cloned_line_ft_1)
										output_kinematic_line_features.add(cloned_line_ft_2)
										pairs_of_kin_line_fts.append((begin_age_line_ft_1,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
										if (recorded_line_ft_1.get_description() == 'divergent_margin' and recorded_line_ft_2.get_description() == 'divergent_margin'):
											recorded_line_ft_1.set_description('plate_boundary_zone')
											recorded_line_ft_2.set_description('plate_boundary_zone')
										else:
											recorded_line_ft_1.set_description('convergent_margin')
											recorded_line_ft_2.set_description('convergent_margin')
								elif (is_valid_pair_of_line_fts == False):
									if (recorded_line_ft_1.get_description() != 'plate_boundary_zone' and recorded_line_ft_2.get_description() != 'plate_boundary_zone'):
										cloned_line_ft_1 = recorded_line_ft_1.clone()
										cloned_line_ft_1.set_valid_time(begin_age_line_ft_1,reconstruction_time+0.100)
										if (reconstruction_time > end_age_line_ft_1):
											recorded_line_ft_1.set_valid_time(reconstruction_time,end_age_line_ft_1)
											recorded_line_ft_1.set_description('plate_boundary_zone')
										else:
											recorded_line_ft_1 = None
										cloned_line_ft_2 = recorded_line_ft_2.clone()
										cloned_line_ft_2.set_valid_time(begin_age_line_ft_2,reconstruction_time+0.100)
										if (reconstruction_time > end_age_line_ft_2):
											recorded_line_ft_2.set_valid_time(reconstruction_time,end_age_line_ft_2)
											recorded_line_ft_2.set_description('plate_boundary_zone')
										else:
											recorded_line_ft_2 = None
										output_kinematic_line_features.add(cloned_line_ft_1)
										output_kinematic_line_features.add(cloned_line_ft_2)
										pairs_of_kin_line_fts.append((begin_age_line_ft_1,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
						elif (recorded_time > reconstruction_time and (recorded_line_ft_1.is_valid_at_time(reconstruction_time) == False or recorded_line_ft_2.is_valid_at_time(reconstruction_time) == False)):
							cloned_line_ft_1 = recorded_line_ft_1.clone()
							cloned_line_ft_1.set_valid_time(recorded_time,reconstruction_time+0.100)
							cloned_line_ft_2 = recorded_line_ft_2.clone()
							cloned_line_ft_2.set_valid_time(recorded_time,reconstruction_time+0.100)
							output_kinematic_line_features.add(cloned_line_ft_1)
							output_kinematic_line_features.add(cloned_line_ft_2)
							pairs_of_kin_line_fts.append((line_feature_1_begin_time,reconstruction_time+0.100,cloned_line_ft_1.get_description(),cloned_line_ft_1.get_name(),cloned_line_ft_2.get_name(),cloned_line_ft_1.get_feature_id().get_string(),cloned_line_ft_2.get_feature_id().get_string()))
				else:
					continue #take a different sgdu_ft_2 to be compared with sgdu_ft_1
		
		#write out the results of all possibile tectonic motion for every pair of SuperGDUs that possibly diverge from each other according to SuperGDU history records
		output_dataframe = pd.DataFrame.from_records(results_of_all_possible_tectonic_motion, columns = ['reconstruction_time','SGDU1','SGDU2','repGDUID1','repGDUID2','tectonic_motion'])
		filename = 'possible_tectonic_motion_from_plate_bdn_zone_process_at_'+str(reconstruction_time)+'_for_'+modelname+'_'+yearmonthday+'.csv'
		output_dataframe.to_csv(filename,index=False)
		output_dataframe = None
		reconstruction_time = reconstruction_time - time_interval
	
	if (len(dic_kin_line_feats) > 0):
		for key in dic_kin_line_feats:
			list_of_kinematic_line_features = dic_of_kin_sgdus[key]
			for recorded_time, recorded_line_ft_1, recorded_line_ft_2, recorded_tectonic_motion in list_of_kinematic_line_features:
				if (recorded_line_ft_1 is not None and recorded_line_ft_2 is not None):
					output_kinematic_line_features.add(line_feature_1)
					output_kinematic_line_features.add(line_feature_2)
					from_time_line_ft_1,to_time_line_ft_1 = recorded_line_ft_1.get_valid_time()
					pairs_of_kin_line_fts.append((from_time_line_ft_1,to_time_line_ft_1,recorded_line_ft_1.get_description(),recorded_line_ft_1.get_name(),recorded_line_ft_2.get_name(),recorded_line_ft_1.get_feature_id().get_string(),recorded_line_ft_2.get_feature_id().get_string()))
	output_kinematic_line_features.write('kinematic_line_features_for_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
	output_dataframe = pd.DataFrame.from_records(pairs_of_kin_line_fts, columns = ['from_time','to_time','type_kin','polylid1','polylid2','fid1','fid2'])
	filename = 'pairs_of_kin_line_fts_from_plate_bdn_zone_process_for_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)
	
	output_dataframe = pd.DataFrame.from_records(list_of_ordered_pairs_gdu_fts, columns = ['reconstruction_time','name','order','lpolylid','left_gdu','lrepgduid','rpolylid','right_gdu','rrepgduid'])
	filename = 'conv_features_records_for_'+str(begin_reconstruction_time)+'_'+str(end_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)
	
	unsure_topology_for_MOR_fts.write('unsure_topology_for_rift_pt_fts_from_plate_bdn_zone_process_for_'+modelname+'_'+yearmonthday+'.shp')