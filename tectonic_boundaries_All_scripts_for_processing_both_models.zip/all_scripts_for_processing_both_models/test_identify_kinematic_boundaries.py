import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import identify_kinematic_boundaries as kin_boundary
def main():
	# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Fall2022/PalaeoPlatesendOct2022/superGDU/T_Rot_Model_PalaeoPlates_20221018.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# sgdu_distance_csv = r"/globalhome/hon686/HPC/Geology/Research/Fall2022/PalaeoPlatesendOct2022/superGDU/PalaeoPlates2022_smallest_dist_km_btw_valid_sgdu_feats_3420.0_0.0_5.0_20230204.csv"
	# sgdu_outer_gdu_members_csv = r"PalaeoPlatesOct2022_sgu_and_outer_gdu_members_from_3420.0_0.0_20230204.csv"
	# sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Fall2022/PalaeoPlatesendOct2022/superGDU/no_duplicated_SuperGDU_features_PalaeoPlatesOct2022_20230204.shp"
	# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	
	# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# # sgdu_distance_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/QGISfixedPalaeoPlatesendJan2023_smallest_dist_km_btw_valid_sgdu_feats_3420.0_0.0_5.0_20230224.csv"
	# # #sgdu_outer_gdu_members_csv = r"PalaeoPlatesOct2022_sgu_and_outer_gdu_members_from_3420.0_0.0_20230204.csv"
	# sgdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	# common_filename_for_temporary_sgdu_and_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	# gdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	# gdu_features_collection = pygplates.FeatureCollection(gdu_features_file)
	# #line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_26_valid_single_dissolved_merged_POLGID_joined_line_fts_All_PalaeoPlatesJan2023_3420_0Ma_20230509.shp"
	# #line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/CON_OCN_w_temp_neighbours_for_test_32_original_and_new_valid_single_line_fts_All_PalaeoPlatesJan2023_20230628.shp"
	# line_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/AFR_NAM_SAM_CON_OCN_from_test_32_PalaeoPlatesJan2023_20230628.shp"
	# line_features_collection = pygplates.FeatureCollection(line_features_file)
	# original_present_day_line_fts_shp = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/vaild_single_dissolved_merged_POLYGID_joined_line_features_for_All_PalaeoPlatesendJan2023_w_geodesic_splitted_lines_20230328.shp"
	
	# rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# sgdu_distance_csv = r"C:\Users\lavie\Desktop\Research\Fall2022\tectonic_boundaries\PalaeoPlates2022_smallest_dist_km_btw_valid_sgdu_feats_3420.0_0.0_5.0_20230204.csv"
	# sgdu_outer_gdu_members_csv = r"C:\Users\lavie\Desktop\Research\Fall2022\tectonic_boundaries\PalaeoPlatesOct2022_sgu_and_outer_gdu_members_from_3420.0_0.0_20230204.csv"
	# sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	# common_filename_for_temporary_sgdu_and_members_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	# gdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\QGIS_fixed_valid_polygon_features_for_PalaeoPlatesJan2023.shp"
	# gdu_features_collection = pygplates.FeatureCollection(gdu_features_file)
	# #line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\CON_OCN_w_temp_neighbours_for_test_32_original_and_new_valid_single_line_fts_All_PalaeoPlatesJan2023_20230628.shp"
	# #line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\AFR_SAM_valid_till_present_CON_OCN_from_test_32_PalaeoPlatesJan2023_20230628.shp"
	# line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\troubled_line_features_should_be_div_but_conv_SAM_AFR_test_32_PalaeoPlates.shp"
	# line_features_collection = pygplates.FeatureCollection(line_features_file)
	# original_present_day_line_fts_shp = r"C:\Users\lavie\Desktop\Research\Fall2022\line_topology_qgis_geopandas_shapely\vaild_single_dissolved_merged_POLYGID_joined_line_features_for_All_PalaeoPlatesendJan2023_w_geodesic_splitted_lines_20230328.shp"
	
	# begin_reconstruction_time = 195.00
	# end_reconstruction_time = 100.0
	# time_interval = 5.0
	# reference = 700
	# angle_window_for_transform = 10.00
	# maximum_accepted_angle_in_degrees = 70.00
	# choosen_epsg_projection = 'ESRI:54032' #Azimuthal Equidistant
	# threshold_distance_in_km = 200.00
	# threshold_distance_in_km_for_neighbour = 2500.00
	# yearmonthday = "20230922"
	# modelname = "test_28_div_fts_SAM_AFR_PalaeoPlatesendJan2023_w_1_deg"
	# #kin_boundary.find_valid_pair_of_gdu_features_and_evaluate_their_kinematics(rotation_model, sgdu_distance_csv, sgdu_outer_gdu_members_csv, sgdu_features, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km, yearmonthday, modelname)
	# #rotation_model, sgdu_distance_csv, sgdu_history_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, original_present_day_line_fts_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour, threshold_distance_in_km, yearmonthday, modelname
	# #sgdu_history_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/sgdu_history_for__test_10_PalaeoPlatesJan2023_from_20230425_20230613.csv"
	# sgdu_history_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\sgdu_history_for__test_10_PalaeoPlatesJan2023_from_20230425_20230613.csv"
	# #kin_boundary.find_valid_pair_of_gdu_features_and_evaluate_their_kinematics(rotation_model, sgdu_distance_csv, sgdu_history_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, original_present_day_line_fts_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour,threshold_distance_in_km, yearmonthday, modelname)
	# #kin_boundary.find_valid_pair_of_gdu_features_and_evaluate_their_kinematics(rotation_model, sgdu_distance_csv, sgdu_history_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, original_present_day_line_fts_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour, threshold_distance_in_km, yearmonthday, modelname)
	# #start_time_of_div_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/start_time_of_div_test_13_PalaeoPlatesJan2023_20230614.csv"
	# start_time_of_div_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\start_time_of_div_test_13_PalaeoPlatesJan2023_20230614.csv"
	# kin_boundary.find_divergent_line_features(rotation_model, sgdu_history_csv, start_time_of_div_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, original_present_day_line_fts_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour, threshold_distance_in_km, yearmonthday, modelname)
	
	#EB2021
	rotation_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\1000_0_rotfile_Merdith_et_al.rot"
	rotation_model = pygplates.RotationModel(rotation_file)
	sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_995.0_0.0_Merdith_et_al_EB2021_20230428.shp"
	sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	common_filename_for_temporary_sgdu_and_members_csv = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\EB2022\supergdu_and_members_gdu_at_{time}_for_Merdith_et_al_EB2021_20230428.csv"
	gdu_features_file = r"C:\Users\lavie\Desktop\Research\GPlates\PlateTectonic_model_from_EarthByte\SM2\Single_valid_from_edit_shapes_continents_Merdith_et_al.shp"
	gdu_features_collection = pygplates.FeatureCollection(gdu_features_file)
	#line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\CON_OCN_w_temp_neighbours_for_test_32_original_and_new_valid_single_line_fts_All_PalaeoPlatesJan2023_20230628.shp"
	#line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\AFR_SAM_valid_till_present_CON_OCN_from_test_32_PalaeoPlatesJan2023_20230628.shp"
	#line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\CON_OCN_w_temp_neighbours_for_test_1_original_and_new_single_POLYGID_joined_line_fts_995.0_0.0_Merdith_et_al_EB2021_20230930.shp"
	line_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\line_topology_qgis_geopandas_shapely\selected_line_features_SAM_AFR_EB2022.shp"
	line_features_collection = pygplates.FeatureCollection(line_features_file)
	#original_present_day_line_fts_shp = r"C:\Users\lavie\Desktop\Research\Fall2022\line_topology_qgis_geopandas_shapely\vaild_single_dissolved_merged_POLYGID_joined_line_features_for_All_PalaeoPlatesendJan2023_w_geodesic_splitted_lines_20230328.shp"
	
	begin_reconstruction_time = 140.00
	end_reconstruction_time = 140.0
	time_interval = 5.0
	reference = 0
	angle_window_for_transform = 10.00
	maximum_accepted_angle_in_degrees = 70.00
	choosen_epsg_projection = 'ESRI:54032' #Azimuthal Equidistant
	threshold_distance_in_km = 200.00
	threshold_distance_in_km_for_neighbour = 2500.00
	yearmonthday = "20230922"
	modelname = "test_7_div_fts_SAM_AFR_EB2021_w_1_deg"
	#kin_boundary.find_valid_pair_of_gdu_features_and_evaluate_their_kinematics(rotation_model, sgdu_distance_csv, sgdu_outer_gdu_members_csv, sgdu_features, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km, yearmonthday, modelname)
	#rotation_model, sgdu_distance_csv, sgdu_history_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, original_present_day_line_fts_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour, threshold_distance_in_km, yearmonthday, modelname
	#sgdu_history_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/sgdu_history_for__test_10_PalaeoPlatesJan2023_from_20230425_20230613.csv"
	sgdu_history_csv = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\EB2022\sgdu_history_for__test_3_Merdith_et_al_EB2021_20231005.csv"
	#kin_boundary.find_valid_pair_of_gdu_features_and_evaluate_their_kinematics(rotation_model, sgdu_distance_csv, sgdu_history_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, original_present_day_line_fts_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour,threshold_distance_in_km, yearmonthday, modelname)
	#kin_boundary.find_valid_pair_of_gdu_features_and_evaluate_their_kinematics(rotation_model, sgdu_distance_csv, sgdu_history_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, original_present_day_line_fts_shp, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour, threshold_distance_in_km, yearmonthday, modelname)
	#start_time_of_div_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/start_time_of_div_test_13_PalaeoPlatesJan2023_20230614.csv"
	start_time_of_div_csv = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\EB2022\start_time_of_div_test_3_Merdith_et_al_EB2021_20231002.csv"
	kin_boundary.find_divergent_line_features(rotation_model, sgdu_history_csv, start_time_of_div_csv, common_filename_for_temporary_sgdu_and_members_csv, sgdu_features, gdu_features_collection, line_features_collection, begin_reconstruction_time, end_reconstruction_time, time_interval, reference, angle_window_for_transform, maximum_accepted_angle_in_degrees, choosen_epsg_projection, threshold_distance_in_km_for_neighbour, threshold_distance_in_km, yearmonthday, modelname)
	
	
	
if __name__ == '__main__':
	main()
