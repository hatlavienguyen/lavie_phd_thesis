import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_topological_modules as supporting
import supporting_modules_to_extend_tectonic_boundaries as cleaning


#rift_transform_point_features_shp = r"C:\Users\lavie\Desktop\Research\Winter2021\tectonic_boundaries\tectonic_boundaries_features_test_5_for_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_800km__110.0_100.0_5Ma_20210204.gpml"

# def main(rotation_file, SuperGDU_features_file, tectonic_boundaries_shp_or_gpml, margin_line_features_shp_or_gpml, only_check_inferred_fts, begin, end, interval, reference, modelname, yyyymmdd):
	# rotation_model = pygplates.RotationModel(rotation_file)
	# SuperGDU_features = pygplates.FeatureCollection(SuperGDU_features_file)
	# tectonic_features = pygplates.FeatureCollection(tectonic_boundaries_shp_or_gpml)
	# line_features = pygplates.FeatureCollection(margin_line_features_shp_or_gpml)
	# list_of_passive_margin_fts = [ft for ft in tectonic_features if type(ft.get_geometry()) == pygplates.PolylineOnSphere]
	# print("number of tectonic features:")
	# print(len(list_of_passive_margin_fts))
	# #SuperGDU_features, tectonic_features, line_features,
	# cleaning.clean_up_messy_tectonic_boundaries(rotation_model, SuperGDU_features, list_of_passive_margin_fts, line_features, only_check_inferred_fts, begin, end, interval, reference, modelname, yyyymmdd)

# def main(rift_transform_point_features_shp):
	# rift_transform_point_features = pygplates.FeatureCollection(rift_transform_point_features_shp)
	# list_of_transform_point_features = [ft for ft in rift_transform_point_features if ft.get_description() == 'transform']
	# print(list_of_transform_point_features)
	# list_of_tuples = supporting.find_pairs_of_points_for_passive_margins_associated_with_rift(list_of_transform_point_features)
	# result_topological_lines = supporting.create_topological_points_for_topological_lines(list_of_tuples)
	# print(result_topological_lines)

def main(featType,tectonic_boundaries_shp_or_gpml, at_age, rotation_file, reference,test_number, write_output):
	rotation_model = pygplates.RotationModel(rotation_file)
	tectonic_boundaries_fts = pygplates.FeatureCollection(tectonic_boundaries_shp_or_gpml)
	list_of_margin_fts = [ft for ft in tectonic_boundaries_fts if ft.get_feature_type() == featType]
	supporting.create_topological_boundaries_from_any_tectonic_boundary_features(featType,list_of_margin_fts, at_age, rotation_model, reference, test_number, write_output)
	
def main(featType,featType_in_description,tectonic_boundaries_shp_or_gpml, from_age, to_age, interval, rotation_file, reference, modelname, test_number, length_of_topological_margins_output_csv_file, yyyymmdd):
	write_output = True
	rotation_model = pygplates.RotationModel(rotation_file)
	tectonic_boundaries_fts = pygplates.FeatureCollection(tectonic_boundaries_shp_or_gpml)
	list_of_margin_fts = [ft for ft in tectonic_boundaries_fts if ft.get_feature_type() == featType]
	featType_create_reconstr_ft = featType
	if (featType_in_description == "divergent_zone"):
		final_con_ocn_div_margin_fts = [ft for ft in list_of_margin_fts if (ft.get_description() != "unknown_margin_convergent_zone" and ft.get_description () != "lower_plate_margin")]
		supporting.create_topological_boundaries_from_any_tectonic_boundary_features_within_period(featType_in_description,featType_create_reconstr_ft,final_con_ocn_div_margin_fts, from_age, to_age, interval, rotation_model, reference, modelname, test_number, write_output, length_of_topological_margins_output_csv_file, yyyymmdd)
	else:
		supporting.create_topological_boundaries_from_any_tectonic_boundary_features_within_period(featType_in_description,featType_create_reconstr_ft,list_of_margin_fts, from_age, to_age, interval, rotation_model, reference, modelname, test_number, write_output, length_of_topological_margins_output_csv_file, yyyymmdd)
# def main(tectonic_boundaries_shp_or_gpml, SuperGDU_shp_or_gpml, at_age, age_interval, rotation_file, reference, test_number, modelname, yyyymmdd):
	# rotation_model = pygplates.RotationModel(rotation_file)
	# tectonic_boundaries_fts = pygplates.FeatureCollection(tectonic_boundaries_shp_or_gpml)
	# SuperGDU_features = pygplates.FeatureCollection(SuperGDU_shp_or_gpml)
	# list_of_passive_margin_fts = [ft for ft in tectonic_boundaries_fts if ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary]
	# write_output = True
	# supporting.find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features(list_of_passive_margin_fts, SuperGDU_features, at_age, age_interval, rotation_model, reference, test_number, modelname, yyyymmdd, write_output)

# def main():
	# final_left_plate_id = 10439
	# final_right_plate_id = 10401
	# point_feature_file = r"C:\Users\lavie\Desktop\Research\Winter2021\utility\utility\new_rift_point_features_and_topological_MOR_SAM_AFR_PalaePlates2020__100.0_24_20210428.shp"
	# point_FeatureCollection = pygplates.FeatureCollection(point_feature_file)
	# list_of_ordered_middle_fts = []
	# list_of_ordered_fts_for_left = []
	# list_of_ordered_fts_for_right = []
	# for ft in point_FeatureCollection:
		# if (ft.get_feature_type() == pygplates.FeatureType.gpml_continental_rift):
			# list_of_ordered_middle_fts.append(ft)
			# for other_ft in point_FeatureCollection:
				# if (other_ft.get_feature_type() == pygplates.FeatureType.gpml_continental_crust):
					# if (other_ft.get_reconstruction_plate_id () == ft.get_left_plate() and other_ft.get_name() == ft.get_name()):
						# if (other_ft not in list_of_ordered_fts_for_left):
							# list_of_ordered_fts_for_left.append(other_ft)
					# elif (other_ft.get_reconstruction_plate_id () == ft.get_right_plate() and other_ft.get_name() == ft.get_name()):
						# if (other_ft not in list_of_ordered_fts_for_right):
							# list_of_ordered_fts_for_right.append(other_ft)
	# print(len(list_of_ordered_fts_for_left))
	# print(len(list_of_ordered_fts_for_right))
	# rotation_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\Rotation\T_Rot_Model_PalaeoPlates_20200131be.rot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# at_age = 100.00 
	# divergent_end_age = 0.00 
	# interval = 5.00 
	# reference = 700
	# test_left_oceanic_crust_from_MOR = supporting.find_subsequent_left_oceanic_crust(final_left_plate_id,list_of_ordered_middle_fts,list_of_ordered_fts_for_left, rotation_model, at_age, divergent_end_age, interval, reference)
	# test_right_oceanic_crust_from_MOR = supporting.find_subsequent_right_oceanic_crust(final_right_plate_id,list_of_ordered_middle_fts,list_of_ordered_fts_for_right, rotation_model, at_age, divergent_end_age, interval, reference)
	# test_number = 35
	# modelname = 'NAM_SAM_AFR_ANT_PalaePlates2020_'
	# yyyymmdd = '20210428'
	# output_FeatureCollection = pygplates.FeatureCollection(test_left_oceanic_crust_from_MOR)
	# for right_ft in test_right_oceanic_crust_from_MOR:
		# output_FeatureCollection.add(right_ft)
	# output_filename = "test_left_and_right_oceanic_crust_from_MOR_"+str(test_number)+"_"+yyyymmdd+".gpml"
	# output_FeatureCollection.write(output_filename)
	
def main(tectonic_boundaries_shp_or_gpml, SuperGDU_shp_or_gpml, from_age, to_age, age_interval, rotation_file, reference, test_number, modelname, yyyymmdd):
	rotation_model = pygplates.RotationModel(rotation_file)
	print(rotation_model)
	tectonic_boundaries_fts = pygplates.FeatureCollection(tectonic_boundaries_shp_or_gpml)
	SuperGDU_features = pygplates.FeatureCollection(SuperGDU_shp_or_gpml)
	list_of_passive_margin_fts = [ft for ft in tectonic_boundaries_fts if ft.get_feature_type() == pygplates.FeatureType.gpml_passive_continental_boundary]
	#list_of_passive_margin_fts = [ft for ft in tectonic_boundaries_fts]
	supporting.find_and_connect_rifting_locations_from_passive_margin_and_SuperGDU_features_within_period(list_of_passive_margin_fts, SuperGDU_features, from_age, to_age, age_interval, rotation_model, reference, test_number, modelname, yyyymmdd)


#tectonic_boundaries_shp_or_gpml = r"C:\Users\lavie\Desktop\Research\Winter2021\tectonic_boundaries\tectonic_boundaries_features_test_5_for_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_800km__110.0_100.0_5Ma_20210204.gpml"
if __name__ == "__main__":
	SuperGDU_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Winter2022\superGDU\clean_up_final_SuperGDU_features_PalaeoPlatesNov2021_test_2_20211217.gpml"
	from_age = 120.00
	to_age = 120.00
	at_age = 100.00
	age_interval = 5.00
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	reference = 700
	test_number = 2
	modelname = '_SAM_AFR_PalaePlatesNov2021_'
	yyyymmdd = '20211221'
		
	
	#rifts or MORs
	#within period
	tectonic_boundaries_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Winter2022\tectonic_boundaries\tectonic_boundaries_features_PalaeoPlatesNov2021_test_1_threshold_1000km_140.0_0.0_5.0Ma_20211220.gpml"
	main(tectonic_boundaries_shp_or_gpml, SuperGDU_shp_or_gpml, from_age, to_age, age_interval, rotation_file, reference, test_number, modelname, yyyymmdd)
	#at age
	#main(tectonic_boundaries_shp_or_gpml, SuperGDU_shp_or_gpml, at_age, age_interval, rotation_file, reference, test_number, modelname, yyyymmdd)
	
	#main()
	#CON-OCN tectoni boundary features such as margin features related to divergent zone or subduction zone
	# tectonic_boundaries_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Fall2021\tectonic_boundaries\extract_plate_tectonic_margins_from_database_table_summary_of_tectonic_boundaries_from_first_summary_of_tectonic_motion_PalaeoPlates_June_2021_test_2_threshold_1_20211010.gpml"
	# tectonic_boundaries_shp_or_gpml = r"C:\Users\Lavie\Desktop\Research\Fall2021\tectonic_boundaries\clean_up_messy_tectonic_boundaries_based_on_geological_topology_PalaeoPlatesJune2021_4_20211007.gpml"
	# rotation_file = r"C:\Users\Lavie\Desktop\Research\Summer2021\PalaeoPlatesJune2021\T_Rot_Model_PalaeoPlates_20210526.grot"
	# #tectonic_boundaries_shp_or_gpml = r"C:\Users\lavie\Desktop\Research\Winter2021\tectonic_boundaries\test_2_combine_and_finalize_subduction_margin_features_from_405.0_0.0_5.0_PalaeoPlates2020_20210727.gpml"
	# featType = pygplates.FeatureType.gpml_passive_continental_boundary
	# featType_in_description = "divergent_zone"
	# write_output = True
	# length_of_topological_margins_output_csv_file = "length_and_duration_of_con_ocn_div_margins_output_csv_file"
	
	# featType = pygplates.FeatureType.gpml_subduction_zone
	# featType_in_description = "unknown_convergent_margin"
	# write_output = True
	# length_of_topological_margins_output_csv_file = "length_and_duration_of_topological_unknown_convergent_margins_output_csv_file"
	#main(featType,tectonic_boundaries_shp_or_gpml, at_age, rotation_file, reference,test_number,write_output)
	# main(featType,featType_in_description,tectonic_boundaries_shp_or_gpml, from_age, to_age, age_interval, rotation_file, reference, modelname, test_number, length_of_topological_margins_output_csv_file, yyyymmdd)
	
	
	