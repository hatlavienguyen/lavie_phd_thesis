import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_find_passive_gdu_boundaries as supporting_passive
import supporting_modules_to_create_tectonic_boundaries_from_database_tables as supporting_create

def main():
	rotation_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\T_Rot_Model_PalaeoPlates_20211115.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	polygon_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\PalaeoPlatesNov2021\PlatePolygons2016Continental.shp"
	polygon_features_collection = pygplates.FeatureCollection(polygon_features_file)
	line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\examine_line_topology\final_CON_OCN_from_modifying_CON_OCN_line_features_PalaeoPlatesNov2021_20220408.gpml"
	#line_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\examine_line_topology\ft_id_str_CON_OCN_line_features_11353_10533_10532_PalaeoPlatesNov2021_20220129.shp"
	print('line_features_file',line_features_file)
	line_features_collection = pygplates.FeatureCollection(line_features_file)
	super_gdu_features_file = r"C:\Users\Lavie\Desktop\Research\Winter2022\superGDU\clean_up_final_SuperGDU_features_PalaeoPlatesNov2021_from_2000_20220120_20220126.gpml"
	super_gdu_features_collection = pygplates.FeatureCollection(super_gdu_features_file)
	begin_reconstruction_time = 2000.00
	end_reconstruction_time = 0.00
	interval = 5.00
	field_name_for_lithosphere_type = "COTID"
	continental_type_symbol = 'C'
	threshold_distance_in_km = 1000.00
	reference = 700
	cos_value_for_transform = 0.0100
	threshold_overlap_len_in_km = 350.00
	modelname = "test_11_rev_from_Gondwana_PalaeoPlatesNov2021_test_2"
	yearmonthday = "20220704"
	name_of_database_table_for_pairs_of_line_fts = 'test_pairs_of_line_features_at_each_time_reversed_2'
	name_of_database_table_for_tectonic_motion = 'test_rel_pos_vel_vector_motion_at_each_time_reversed_2'
	name_of_database_table_for_MOR = 'test_mor_location_fts_at_each_time_reversed_2'
	#supporting.identify_tectonic_motion_3_reverse(name_of_database_table_for_pairs_of_line_fts, name_of_database_table_for_tectonic_motion, name_of_database_table_for_MOR, rotation_model, line_features_collection, super_gdu_features_collection, cos_value_for_transform, threshold_overlap_len_in_km, begin_reconstruction_time, end_reconstruction_time, interval, reference, modelname,yearmonthday)
	#name_for_table_for_subsequent_tectonic_motion = 'test_subsequent_rel_pos_vel_vector_motion_at_each_time_reversed_2'
	name_for_table_for_subsequent_tectonic_motion = 'test_subsequent_rel_pos_vel_vector_motion_at_each_time_reversed_2'
	#supporting_eval_subseq.evaluate_subsequent_time_steps_for_tectonic_boundaries_from_database_tables(name_of_database_table_for_tectonic_motion, name_of_database_table_for_pairs_of_line_fts, name_for_table_for_subsequent_tectonic_motion, line_features_collection, super_gdu_features_collection, rotation_model, reference, cos_value_for_transform, begin_reconstruction_time, end_reconstruction_time,interval, modelname, yearmonthday)
	#name_for_table_for_summary_closest_tectonic_boundary = 'closest_boundary_rel_pos_vel_vector_motion_at_each_time_reversed_2'
	#supporting_find_closest.find_the_closest_boundary_for_each_boundary_from_database_table_tectonic_motion(name_of_database_table_for_tectonic_motion, name_for_table_for_summary_closest_tectonic_boundary, line_features_collection, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time,interval, modelname, yearmonthday)
	#name_for_table_for_summary_tectonic_boundary = 'summary_of_tectonic_boundaries_from_rel_pos_vect_reversed_2'
	name_of_table_for_tectonic_motion_of_all_pairs_of_line_features = 'temp_all_rel_pos_vel_vector_motion_at_each_time_from_gondwana_r'
	name_for_table_for_passive_boundaries = 'passive_boundaries_from_rel_pos_vel_vector_motion_at_each_time_reversed'
	#supporting_passive.find_unclassified_passive_boundaries_from_all_classified_line_fts_database_table(name_of_table_for_tectonic_motion_of_all_pairs_of_line_features, name_for_table_for_passive_boundaries, line_features_collection, begin_reconstruction_time, end_reconstruction_time, interval, modelname, yearmonthday)
	name_for_table_for_summary_passive_boundary = 'test_summary_of_passive_boundaries_gondwana_rev_2'
	supporting_create.create_passive_boundaries_from_database_table_passive_boundaries(name_for_table_for_passive_boundaries, name_for_table_for_summary_passive_boundary, line_features_collection, begin_reconstruction_time, end_reconstruction_time, interval, modelname, yearmonthday)
if __name__=='__main__':
	main()
