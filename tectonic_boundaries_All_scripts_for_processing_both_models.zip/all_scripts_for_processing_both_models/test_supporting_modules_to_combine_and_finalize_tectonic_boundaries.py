import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
import pygplates
import supporting_modules_to_extend_tectonic_boundaries as supporting


def main():
	#tectonic_boundaries_features_test_5_for_NAM_SAM_AFR_ANT_INO_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold_800km__170.0_150.0_5Ma_20210204.gpml
	# common_name_for_output_files = "tectonic_boundaries_features_test_1_for"
	# modelname = "PalaeoPlates_April_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_threshold"
	# threshold = 800
	# yyyymmdd = '20210129'
	# begin = 170.0
	# end = 100.0
	# interval = 5
	# output_freq = 4
	# fileformat = 'gpml'
	# supporting.finalize_tectonic_boundary_features_from_multiple_output_files(common_name_for_output_files,modelname,threshold,yyyymmdd,begin,end,interval,output_freq,fileformat)
	
	modelname = "PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_only_convergence"
	yyyymmdd = '20210324'
	begin = 170.0
	end = 0.0
	interval = 5.00
	#subduction_margin_features_file = r'C:\Users\lavie\Desktop\Research\Winter2021\utility\utility\combined_filestest_1_PalaeoPlatesApril2020_SuperGDU_20210121_convergent_boundaries_kinematics_and_deposits_eval_20210321.gpml'
	#subduction_margin_features_file = r"C:\Users\lavie\Desktop\Research\Winter2021\utility\utility\extracted_featuressubduction_zone_for_10448_PalaeoPlates2020_20210324.gpml"
	# subduction_margin_features_file = r"C:\Users\lavie\Desktop\Research\Winter2021\utility\utility\combined_filesPalaeoPlatesApril2020_kinematics_deposits_igneous_20210324.gpml"
	# subduction_margin_features = pygplates.FeatureCollection(subduction_margin_features_file)
	# supporting.exam_and_modify_end_age_of_possible_subduction_margin_features(subduction_margin_features, begin, end, interval, modelname, yyyymmdd)
	
	rotation_file = r"C:\Users\lavie\Desktop\Research\Summer2020\PalaeoPlates_April_2020\Rotation\T_Rot_Model_PalaeoPlates_20200131be.rot"
	SuperGDU_features_file = r"C:\Users\lavie\Desktop\Research\Winter2021\superGDU\superGDU\final_SuperGDU_fts_test_19_with_adding_small_time_to_begin_age205.0_0.0_20210121.gpml"
	tectonic_boundaries_shp_or_gpml = r"C:\Users\lavie\Desktop\Research\Winter2021\tectonic_boundaries\test_5_combine_and_finalize_subduction_margin_features_from_170.0_0.0_5.0_PalaeoPlates_2020_SuperGDU_20210121_CON_OCN_test_19_20210127_20210324.gpml"
	line_features_file = r"C:\Users\lavie\Desktop\Research\Winter2021\examine_line_topology\line_features_with_type_CON_OCN__test_8_for_PalaeoPlates2020_with_finalized_superGDU_from_20210121_test93_buffer_distance_10000km_test_19_20210127.gpml"
	only_check_inferred_fts = False
	rotation_model = pygplates.RotationModel(rotation_file)
	SuperGDU_features = pygplates.FeatureCollection(SuperGDU_features_file)
	tectonic_features = pygplates.FeatureCollection(tectonic_boundaries_shp_or_gpml)
	line_features = pygplates.FeatureCollection(line_features_file)
	reference = 700
	list_of_fts = [ft for ft in tectonic_features]
	print("number of tectonic features:")
	print(len(list_of_fts))
	supporting.clean_up_messy_tectonic_boundaries(rotation_model, SuperGDU_features, list_of_fts, line_features, only_check_inferred_fts, begin, end, interval, reference, modelname, yyyymmdd)

if __name__ == "__main__":
	main()