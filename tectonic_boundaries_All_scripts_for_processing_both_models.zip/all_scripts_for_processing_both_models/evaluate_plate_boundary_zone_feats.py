#import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import pandas as pd
import geopandas as gpd
import numpy as np
import pyproj
from shapely.ops import transform
from shapely.geometry import Polygon, LineString, MultiPoint, MultiPolygon, LinearRing, Point
import math
from multiprocessing import Pool
from os import environ
from time import sleep
import create_topological_isochron_and_estimate_MOR as create_topological
#ncpus = int(environ['SLURM_CPUS_PER_TASK'])

#oceanic_crust_features_file = r"oceanic_crust_from_rift_and_isochron_point_features_with_max_star_div_age_600.0_min_400.0_test_29_PalaeoPlatesendJan2023_20231106.shp"
#oceanic_crust_features = pygplates.FeatureCollection(oceanic_crust_features_file)
#oceanic_crust_features_file = r"oceanic_crust_from_rift_and_isochron_point_features_with_max_star_div_age_{input_max_time}_min_{input_min_time}_test_29_PalaeoPlatesendJan2023_20231106.shp"
supergdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
rotation_model = pygplates.RotationModel(rotation_file)
#gdu_oceanic_crust_features_file = r"oceanic_crust_for_gdus_from_rift_and_isochron_feats_with_max_star_div_age_2800.0_0.0_test_1_PalaeoPlatesendJan2023_20231211.shp"
#gdu_oceanic_crust_features_file = r"modified_end_age_of_oceanic_crust_feats_from_2800.00Ma_PalaeoPlatesendJan2023_20231128.shp"
gdu_oceanic_crust_features_file = r"modified_end_age_of_invalid_temporary_oceanic_crust_polygon_feats_max_div_age_2800.0_0.0_test_1_PalaeoPlatesendJan2023_20231212.shp"
gdu_oceanic_crust_features = pygplates.FeatureCollection(gdu_oceanic_crust_features_file)
plate_boundary_zone_boundaries_file = r"plate_boundary_zone_features_for_test_29_PalaeoPlatesendJan2023_from_2800Ma_20231101.shp"
plate_boundary_zone_boundaries = pygplates.FeatureCollection(plate_boundary_zone_boundaries_file)
records_of_kin_line_feats_from_div = r"pairs_of_kin_line_fts_from_div_bdn_process_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
reference = 700
yearmonthday = "20240103"
modelname = "test_2_PalaeoPlatesendJan2023"

def evaluate_plate_bdn_zone_ft_and_oceanic_crust_features_to_find_subduction_zone(maximum_reconstruction_time, minimum_reconstruction_time, time_interval):
	create_topological.evaluate_oceanic_crust_features_with_plate_boundary_zone(gdu_oceanic_crust_features, supergdu_features, plate_boundary_zone_boundaries, records_of_kin_line_feats_from_div, rotation_model, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, reference, modelname, yearmonthday)

if __name__ == '__main__':
	maximum_reconstruction_time = 600.00
	minimum_reconstruction_time = 0.00
	time_interval = 5.00
	evaluate_plate_bdn_zone_ft_and_oceanic_crust_features_to_find_subduction_zone(maximum_reconstruction_time, minimum_reconstruction_time, time_interval)