import pandas as pd
import os 

def find_initial_start_of_rifting_and_end_of_converging(sgdu_history_csv, common_filename_for_sgdu_and_gdu_members_csv, small_time_interval_to_define_supergdu, modelname, yearmonthday):
	#framework_dic = {'origin_lv':[],'SGDU':[],'parent':[],'from_time':[],'to_time':[],'repGDUID':[]}
	sgdu_history_df = pd.read_csv(sgdu_history_csv, delimiter=',', header = 0)
	output_rift_dic = {'SGDU':[],'start_div':[],'repGDUID':[]}
	#find the time when rifting first starts.
	#Get the unique values for parent: unique_parent_sguds
	unique_parent_sguds = sgdu_history_df['parent'].unique()
	#Iterate through unique_parent_sgdus. 
	#	For each unique_parent in unique_parent_sgdus, find records_of_children that contains these attributes ['SGDU','from_time','to_time','repGDUID']
	#		if there are more than one UNIQUE children SGDU, then 'from_time' value is the start of rifting. 
	for unique_parent in unique_parent_sguds:
		records_of_children = sgdu_history_df.loc[sgdu_history_df['parent'] == unique_parent, 'SGDU']
		unique_sgdu_children = records_of_children.unique()
		if (len(unique_sgdu_children) > 1):
			#divergence
			already_recorded_sgdu = []
			records_of_parents = sgdu_history_df.loc[sgdu_history_df['SGDU'] == unique_parent, ['to_time','repGDUID']]
			for tuple in records_of_parents.itertuples(index=False,name=None):
				to_time,repgduid = tuple
				if (repgduid not in already_recorded_sgdu):
					already_recorded_sgdu.append(repgduid)
					output_rift_dic['SGDU'].append(unique_parent)
					output_rift_dic['start_div'].append(to_time)
					output_rift_dic['repGDUID'].append(repgduid)
	
	output_dataframe = pd.DataFrame.from_dict(output_rift_dic)
	filename = 'start_time_of_div_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)
	
	# #find the time when converging first starts
	# output_conv_dic = {'SGDU':[],'start_conv':[],'repGDUID':[]}
	# framework_dic = {'origin_lv':[],'SGDU':[],'parent':[],'from_time':[],'to_time':[],'repGDUID':[]}
	# #Get the unique values for SGDU: unique_sgdus
	# unique_sgdus = sgdu_history_df['SGDU'].unique()
	# #Iterate through unique_sgdus.
	# for unique_child in unique_sgdus:
		# records_of_sgdus = sgdu_history_df.loc[(sgdu_history_df['SGDU'] == unique_child) & (sgdu_history_df['parent'] is not None), ['from_time','parent','origin_lv','to_time']]
		# already_recorded_sgdu = []
		# for tuple in records_of_sgdus.itertuples(index=False,name=None):
			# from_time, parent, lvl, to_time = tuple
			# if (parent not in already_recorded_sgdu):
				# # filename_prev_time = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(from_time + small_time_interval_to_define_supergdu))
				# # #;from_time;to_time;SGDUID;GDUID;POLYGID;buffer_distance_km;repGDUID
				# # temp_sgdu_gdu_df = pd.read_csv(filename_prev_time,header=0,delimiter=';')
				# already_recorded_sgdu.append(parent)
				# records_of_older_sgdu = sgdu_history_df.loc[(sgdu_history_df['SGDU'] != parent) & (sgdu_history_df['to_time'] > from_time) & (sgdu_history_df['parent'] is not None) , ['from_time','to_time','SGDU','repGDUID']]
				# if (len(records_of_older_sgdu) > 0):
					# filename_prev_time = common_filename_for_sgdu_and_gdu_members_csv.format(time = str(from_time + small_time_interval_to_define_supergdu))
					# #;from_time;to_time;SGDUID;GDUID;POLYGID;buffer_distance_km;repGDUID
					# temp_sgdu_gdu_df = pd.read_csv(filename_prev_time, header = 0, delimiter=';')
					# sorted_ancestors = records_of_older_sgdu.sort_values('to_time')
					# for result in sorted_ancestors.itertuples(index = False, name = None):
						# #'from_time','to_time','SGDU','repGDUID'
						# # direct_parents_of_sgdu = sorted_ancestors.head(1)
						# # arrary_of_sgdu = direct_parents_of_sgdu.to_numpy()
						# # ancestor_from_time = arrary_of_sgdu[0][0]
						# # ancestor_to_time = arrary_of_sgdu[0][1]
						# # ancestor_sgdu = arrary_of_sgdu[0][2]
						# # ancestor_repgdu = arrary_of_sgdu[0][3]
						
						# ancestor_from_time = result[0]
						# ancestor_to_time = result[1]
						# ancestor_sgdu = result[2]
						# ancestor_repgdu = result[3]
						# records_for_potential_parents = temp_sgdu_gdu_df.loc[(temp_sgdu_gdu_df['GDUID'] == int(ancestor_repgdu))|(temp_sgdu_gdu_df['repGDUID'] == int(ancestor_repgdu)),['SGDUID','repGDUID']]
						# unique_potential_parents = records_for_potential_parents['SGDUID'].unique()
						# if (len(unique_potential_parents) > 0):
							# already_recorded_potential_sgdu = []
							# for tuple_of_potential_parent in records_for_potential_parents.itertuples(index = False, name = None):
								# additional_sgdu_parent,additional_repgduid = tuple_of_potential_parent
								# if (additional_sgdu_parent not in already_recorded_potential_sgdu):
									# already_recorded_potential_sgdu.append(additional_sgdu_parent)
									# output_conv_dic['SGDU'].append(additional_sgdu_parent)
									# output_conv_dic['start_conv'].append(ancestor_to_time)
									# output_conv_dic['repGDUID'].append(additional_repgduid)
									# #additional parents for convergence
									# framework_dic['origin_lv'].append(lvl)
									# framework_dic['SGDU'].append(unique_child)
									# framework_dic['parent'].append(additional_sgdu_parent)
									# framework_dic['from_time'].append(from_time)
									# framework_dic['to_time'].append(to_time)
									# framework_dic['repGDUID'].append(additional_repgduid)

	# output_dataframe = pd.DataFrame.from_dict(output_conv_dic)
	# filename = 'start_time_of_conv_'+modelname+'_'+yearmonthday+'.csv'
	# output_dataframe.to_csv(filename,index=False)
	
	# output_dataframe = pd.DataFrame.from_dict(framework_dic)
	# filename = 'extra_sgdu_history_for_'+'_'+modelname+'_'+yearmonthday+'.csv'
	# output_dataframe.to_csv(filename,index=False)

def main():
	#supergdu_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/final_supergdu_feats_3420.0_0.0_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.shp"
	#supergdu_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.shp"
	#supergdu_features = pygplates.FeatureCollection(supergdu_file)
	#begin_reconstruction_time = 3420.0
	#end_reconstruction_time = 0.0
	#time_interval = 5.00
	common_filename_for_sgdu_and_gdu_members_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/supergdu_and_members_gdu_at_{time}_for_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.csv"
	#common_filename_for_sgdu_and_gdu_members_csv = r"C:\Users\lavie\Desktop\Research\Fall2022\line_topology_qgis_geopandas_shapely\supergdu_and_members\supergdu_and_members_gdu_at_{time}_for_QGISPalaeoPlatesendJan2023_w_valid_rot_20230218.csv"
	modelname = "test_1_PalaeoPlatesJan2023"
	yearmonthday = "20230403"
	sgdu_history_csv = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/sgdu_history_for__test_2_PalaeoPlatesJan2023_20230401.csv"
	small_time_interval_to_define_supergdu = 5.00
	find_initial_start_of_rifting_and_converging(sgdu_history_csv, common_filename_for_sgdu_and_gdu_members_csv, small_time_interval_to_define_supergdu, modelname, yearmonthday)
if __name__=='__main__':
	main()