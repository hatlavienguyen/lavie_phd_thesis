import sys
#pygplates is a specific package for plate tectonic study
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python37_win64')
#sys.path.insert(1,r'C:\Users\lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64')
import pygplates
import supporting_modules_to_be_converted as supporting
from shapely.geometry import Point, Polygon, LineString, MultiPoint, MultiPolygon, LinearRing
from shapely.ops import unary_union, transform, cascaded_union, polygonize, polygonize_full, linemerge, triangulate 
from shapely.validation import explain_validity 
import pyproj
from functools import partial
from config_plate_tectonics import config
import psycopg2

def identify_upper_plate_margins_from_porphyry_VMS_and_igneous_activities_approximated_plate_tectonic_margins_with_buffer(rotation_model,unknown_convergent_margin_line_features,deposits_or_geochron_buffer_features,from_age,to_age,interval,reference,modelname,yearmonthday):
	list_of_candidate_line_fts = []
	reconstructed_line_features = []
	final_reconstructed_line_features = []
	reconstructed_buffer_features = []
	final_reconstructed_buffer_features = []
	#create a new property
	xsi_number_of_points = pygplates.PropertyName.create_xsi('number_of_points')
	#create a new property
	xsi_number_of_buffers = pygplates.PropertyName.create_xsi('number_of_buffers')
	final_list_of_line_fts = []
	reconstruction_time = from_age
	last_output_shp = 0.00
	for ft in unknown_convergent_margin_line_features:
		ft_begin_age,ft_end_age = ft.get_valid_time()
		#filtering buffer features 
		list_of_buffer_features = [ft for ft in deposits_or_geochron_buffer_features if ft.is_valid_at_time(ft_begin_age)]
		print('len(list_of_buffer_features)')
		print(len(list_of_buffer_features))
		#reconstruct all features
		if (reference is not None):
			pygplates.reconstruct(list_of_buffer_features,rotation_model,reconstructed_buffer_features,ft_begin_age,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct([ft],rotation_model,reconstructed_line_features,ft_begin_age,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(list_of_buffer_features,rotation_model,reconstructed_buffer_features,ft_begin_age, group_with_feature = True)
			pygplates.reconstruct([ft],rotation_model,reconstructed_line_features,ft_begin_age, group_with_feature = True)
		final_reconstructed_line_features[:] = []
		final_reconstructed_line_features = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
		final_reconstructed_buffer_features[:] = []
		final_reconstructed_buffer_features = supporting.find_final_reconstructed_geometries(reconstructed_buffer_features,pygplates.PolygonOnSphere)
		#clearing lists
		reconstructed_line_features[:] = []
		reconstructed_buffer_features[:] = []
		
		line_ft,line = final_reconstructed_line_features[0]
		#obtain the plate id 
		plate_id = line_ft.get_reconstruction_plate_id()
			
		#list_of_associated_buffers = [(buffer_ft,buffer) for (buffer_ft,buffer) in final_reconstructed_buffer_features if (buffer_ft.get_reconstruction_plate_id() == plate_id)]
		list_of_associated_buffers = final_reconstructed_buffer_features
		#check to see how many buffers having a spatial relationship with line_ft
		count_buffers = 0
		count_points = 0
		for buffer_ft,buffer in final_reconstructed_buffer_features:
			if (buffer.partition(line) == pygplates.PolygonOnSphere.PartitionResult.intersecting or buffer.partition(line) == pygplates.PolygonOnSphere.PartitionResult.inside):
				count_buffers = count_buffers + 1
				count_points = count_points + int(buffer_ft.get_description())
		if (count_buffers > 0 and ft.get_description() == "unknown_convergent_margin"):
			#in the future when the new GPlates released we will create 2 new properties - for now we will use description field
			line_ft.set_description("upper_plate_margin")
			integer_property = pygplates.XsInteger(int(count_buffers))
			property_added = line_ft.add(xsi_number_of_buffers,integer_property,pygplates.VerifyInformationModel.no)
			integer_property = pygplates.XsInteger(int(count_points))
			property_added = line_ft.add(xsi_number_of_points,integer_property,pygplates.VerifyInformationModel.no)
		elif (count_buffers == 0 and ft.get_description() == "unknown_convergent_margin"):
			line_ft.set_description("lower_plate_margin")
			integer_property = pygplates.XsInteger(int(count_buffers))
			property_added = line_ft.add(xsi_number_of_buffers,integer_property,pygplates.VerifyInformationModel.no)
			integer_property = pygplates.XsInteger(int(count_points))
			property_added = line_ft.add(xsi_number_of_points,integer_property,pygplates.VerifyInformationModel.no)
		final_list_of_line_fts.append(line_ft)

	print("number of candidates in final_list_of_line_fts")
	print(len(final_list_of_line_fts))
	outputLinesFeatureCollection = pygplates.FeatureCollection(final_list_of_line_fts)
	outputLinesFile = "upper_plate_margins_"+modelname+"_"+str(from_age)+"_"+str(to_age)+"_"+str(interval)+"Ma_"+yearmonthday+".shp"
	outputLinesFeatureCollection.write(outputLinesFile)

def find_upper_plate_ft(line_1_ft, line_2_ft, possible_line_fts_for_subduction_zone, reconstruction_time):
	#using the left_plate and right_plate associated with line_1_ft and line_2_ft to find the ft in all possible line fts
	left_plate_of_1 = line_1_ft.get_left_plate()
	right_plate_of_1 = line_1_ft.get_right_plate()
	
	left_plate_of_2 = line_2_ft.get_left_plate()
	right_plate_of_2 = line_2_ft.get_right_plate()
	
	narrow_list_of_fts = []
	narrow_list_of_fts[:] = []
	
	found_1 = None
	found_2 = None
	for ft in possible_line_fts_for_subduction_zone:
		if (ft.is_valid_at_time(reconstruction_time)):
			if (ft.get_left_plate() == left_plate_of_1 and ft.get_right_plate() == right_plate_of_1):
				found_1 = ft
			elif (ft.get_left_plate() == left_plate_of_2 and ft.get_right_plate() == right_plate_of_2):
				found_2 = ft
	return found_1,found_2
def create_feature_for_convergent_zone_from_PointFeature_data(line_1_ft, line_2_ft, possible_line_fts_for_subduction_zone, reconstruction_time):
	line_1_name = line_1_ft.get_name()
	begin_1,end_1 = line_1_ft.get_valid_time()
	line_2_name = line_2_ft.get_name()
	begin_2,end_2 = line_2_ft.get_valid_time()
	found_1 = None
	found_2 = None
	for possible_margin_ft in possible_line_fts_for_subduction_zone:
		if (possible_margin_ft.is_valid_at_time(begin_1) and possible_margin_ft.get_name() == line_1_name):
			found_1 = possible_margin_ft
		elif (possible_margin_ft.is_valid_at_time(begin_2) and possible_margin_ft.get_name() == line_2_name):
			found_2 = possible_margin_ft
		if (found_1 is not None and found_2 is not None):
			break
	if (found_1 is not None and found_2 is None):
		subduction_zone = line_1_ft
		subduction_zone.set_description('upper_plate_margin')
		passive_margin = line_2_ft 
		passive_margin.set_description('lower_plate_margin')
		return [subduction_zone,passive_margin]
	elif (found_1 is None and found_2 is not None):
		subduction_zone = line_2_ft
		subduction_zone.set_description('upper_plate_margin')
		passive_margin = line_1_ft 
		passive_margin.set_description('lower_plate_margin')
		return [subduction_zone,passive_margin]
	elif (found_1 is None and found_2 is None):
		#based on deposits data we cannot tell which one is on the upper plate
		return [None,None]
	elif (found_1 is not None and found_2 is not None):
		#both have relationship with VMS deposits we need to check which one has a higher number of deposits 
		#gpml_number_of_buffers = pygplates.PropertyName.create_gpml('number_of_buffers')
		#number_of_buffers_for_1 = found_1.get(gpml_number_of_buffers)
		#number_of_buffers_for_2 = found_2.get(gpml_number_of_buffers)
		counts_1 = found_1.get_description().split('_')
		number_of_buffers_for_1 = int(counts_1[0])
		count_points_1 = int(counts_1[1])
		counts_2 = found_2.get_description().split('_')
		number_of_buffers_for_2 = int(counts_2[0])
		count_points_2 = int(counts_2[1])
		if (number_of_buffers_for_1 > number_of_buffers_for_2):
			subduction_zone = line_1_ft
			subduction_zone.set_description('upper_plate_margin')
			passive_margin = line_2_ft 
			passive_margin.set_description('lower_plate_margin')
			return [subduction_zone,passive_margin]
		elif (number_of_buffers_for_1 < number_of_buffers_for_2):
			subduction_zone = line_2_ft
			subduction_zone.set_description('upper_plate_margin')
			passive_margin = line_1_ft 
			passive_margin.set_description('lower_plate_margin')
			return [subduction_zone,passive_margin]
		else:
			return [None,None]

def identify_upper_gdu_boundary_from_tectonic_motion_of_pairs_of_line_database_table(name_of_table_for_tectonic_motion_of_pairs_of_line_features, name_for_table_convergent_boundaries, line_features_collection, deposits_or_geochron_buffer_features, rotation_model, reference, begin_reconstruction_time, end_reconstruction_time,time_interval, modelname, yearmonthday):
	txt = """SELECT DISTINCT ref_ft_id, neighbour_ft_id, tectonic_motion 
				FROM {input_name_of_table_for_tectonic_motion_of_pairs_of_line_features} 
				WHERE time = {input_time} AND (tectonic_motion = 'Convergence' or tectonic_motion = 'Oblique_convergence')"""
	txt_B = """INSERT INTO {input_name_for_table_convergent_boundaries}(time, ref_ft_id, neighbour_ft_id, tectonic_motion) VALUES (%s, %s, %s, %s)"""
	already_processed = []
	conn = None
	cur = None
	cur_1 = None
	try:
		#read database config
		params = config()
		#connect to the PostgreSQL
		conn = psycopg2.connect(**params)
		reconstruction_time = begin_reconstruction_time
		cur = conn.cursor()
		cur_1 = conn.cursor()
		cur_2 = conn.cursor()
		cur_3 = conn.cursor()
		cur_4 = conn.cursor()
		dic = {}
		while (reconstruction_time > (end_reconstruction_time - time_interval)):
			#filling the dictionary with temporal boundaries at begin_reconstruction_time
			sql = txt.format(input_name_of_table_for_tectonic_motion_of_pairs_of_line_features = name_of_table_for_tectonic_motion_of_pairs_of_line_features, input_time = begin_reconstruction_time)
			cur.execute(sql)
			row = cur.fetchone()
			while (row is not None):
				
				row = cur.fetchone()
		#update reconstruction_time to one time step after begin_reconstruction_time
		reconstruction_time = reconstruction_time - time_interval 
		while (reconstruction_time > (end_reconstruction_time - time_interval)):
			#keep in mind the dictionary is NOT empty.
			for key in dic:
				temp_first_line_name = None
				temp_second_line_name = None
				components_of_key = key.split("$")
				temp_first_line_name = components_of_key[0]
				temp_second_line_name = components_of_key[1]
				recorded_tectonic_motion = dic[key][1]
				sql_1 = txt_1.format(input_name_of_table_for_pairs_of_lines_and_GDUs_at_each_time = name_of_table_for_pairs_of_lines_and_GDUs_at_each_time,input_first_line_name = temp_first_line_name, input_second_line_name = temp_second_line_name, input_time = reconstruction_time)
				cur_1.execute(sql_1)
				row_1 = cur_1.fetchone()
				if (row_1 is None):
					#we have to validate the status of these two line features 
					#find the two line_ft
					first_line_ft = None
					second_line_ft = None
					for CON_OCN_line_ft in line_features_collection:
						if (CON_OCN_line_ft.get_name() == temp_first_line_name and CON_OCN_line_ft.is_valid_at_time(reconstruction_time)):
							first_line_ft = CON_OCN_line_ft
						if (CON_OCN_line_ft.get_name() == temp_second_line_name and CON_OCN_line_ft.is_valid_at_time(reconstruction_time)):
							second_line_ft = CON_OCN_line_ft
						if (first_line_ft is not None and second_line_ft is not None):
							break
					if (first_line_ft is not None and second_line_ft is not None):
						if (first_line_ft.is_valid_at_time(reconstruction_time) == True and second_line_ft.is_valid_at_time(reconstruction_time) == True):
							list_of_line_fts = [first_line_ft,second_line_ft]
							reconstructed_line_features = []
							if (reference is not None):
								pygplates.reconstruct(list_of_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(list_of_line_fts,rotation_model,reconstructed_line_features,reconstruction_time,group_with_feature = True)
							final_reconstructed_line_fts = supporting.find_final_reconstructed_geometries(reconstructed_line_features,pygplates.PolylineOnSphere)
							first_line_ft,first_line = final_reconstructed_line_fts[0]
							second_line_ft,second_line = final_reconstructed_line_fts[1]
							list_of_valid_SuperGDU_fts = [super_gdu_ft for super_gdu_ft in super_gdu_features_collection if super_gdu_ft.is_valid_at_time(reconstruction_time)]
							reconstructed_polygon_features = []
							if (reference is not None):
								pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(list_of_valid_SuperGDU_fts,rotation_model,reconstructed_polygon_features,reconstruction_time,group_with_feature = True)
							final_reconstructed_polygon_fts = supporting.find_final_reconstructed_geometries(reconstructed_polygon_features,pygplates.PolygonOnSphere)
							super_gdu_ft_of_first_line = None
							super_gdu_ft_of_second_line = None
							super_gdu_of_first_line = None
							super_gdu_of_second_line = None
							centroid_of_first_line = supporting.get_midpoint_of_line(first_line)
							centroid_of_second_line = supporting.get_midpoint_of_line(second_line)
							for super_gdu_ft,super_gdu in final_reconstructed_polygon_fts:
								if (pygplates.GeometryOnSphere.distance(centroid_of_first_line,super_gdu) == 0.00):
									super_gdu_ft_of_first_line = super_gdu_ft
									super_gdu_of_first_line = super_gdu
								if (pygplates.GeometryOnSphere.distance(centroid_of_second_line,super_gdu) == 0.00):
									super_gdu_ft_of_second_line = super_gdu_ft
									super_gdu_of_second_line = super_gdu
								if (super_gdu_ft_of_second_line is not None and super_gdu_of_first_line is not None):
									break
							temp_polyline = pygplates.PolylineOnSphere([centroid_of_first_line,centroid_of_second_line])
							#check any in_btw_SuperGDU
							valid = True
							for in_btw_super_gdu_ft,in_btw_super_gdu in final_reconstructed_polygon_fts:
								result = supporting_2.is_line_crossing_polygon_w_order_of_indices_of_closest_points_on_small_circle_boundary(temp_polyline, first_line, second_line, in_btw_super_gdu)
								if (result == True):
									valid = False
									break
							#the pair of line features have become invalid at the reconstruction_time
							if (valid == True):
								txt_4 = """INSERT INTO {input_name_for_table_for_subseq_tectonic_motion}(time, ref_ft_id, neighbour_ft_id, tectonic_motion) VALUES (%s, %s, %s, %s)"""
								sql_4 = txt_4.format(input_name_for_table_for_subseq_tectonic_motion = name_for_table_for_subsequent_tectonic_motion)
								list_of_centroid_ft = supporting_2.find_centroid_features_from_line_features(list_of_line_fts,False,None)
								first_centroid_ft = list_of_centroid_ft[0]
								second_centroid_ft = list_of_centroid_ft[1]
								tectonic_motion_at_reconstruction_time = supporting.relative_position_velocity_vectors_eval(rotation_model,first_centroid_ft,second_centroid_ft,reconstruction_time,time_interval,reference,cos_value_for_transform)
								cur_4.execute(sql_4,(reconstruction_time,temp_first_line_name,temp_second_line_name,tectonic_motion_at_reconstruction_time.name))
								
								#update value in dictionary
								dic[key] = (reconstruction_time,recorded_tectonic_motion)
			sql = txt.format(input_name_of_table_for_tectonic_motion_of_pairs_of_line_features = name_of_table_for_tectonic_motion_of_pairs_of_line_features, input_time = reconstruction_time)
			cur.execute(sql)
			row = cur.fetchone()
			while (row is not None):
				first_line_name = row[0]
				second_line_name = row[1]
				recorded_tectonic_motion = row[2]
				key = first_line_name+'$'+second_line_name
				inversed_key = second_line_name+'$'+first_line_name
				if (key not in dic and inversed_key not in dic):
					dic[key] = (reconstruction_time,recorded_tectonic_motion)
				row = cur.fetchone()
			#commit changes to database
			conn.commit()
			#update reconstruction_time
			reconstruction_time = reconstruction_time - time_interval 
	except (psycopg2.DatabaseError) as error:
		print("Error in identifying subduction GDU boundary")
		print(error)