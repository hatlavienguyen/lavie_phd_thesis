import sys
#pygplates is a specific package for plate tectonic study
sys.path.insert(1,r'C:\Users\Lavie\Desktop\Research\GPlates\pygplates_rev28_python38_win64\pygplates_rev28_python38_win64')
import pygplates
import numpy as np
import pandas as pd
import math
import evaluate_tectonic_motion as tectonic_motion

#A function to calculate the distance between two points on the sphere - specifically the Earth 
#I could have used haversine module for python, but for the purpose of practise, I do it myself
#According to the formula from https://www.igismap.com/haversine-formula-calculate-geographic-distance-earth/, 
#a = sin^2(Difference in latitudes/2)+cos(lat1)*cos(lat2)*sin^2(Difference in longitude/2)
#c = 2*atan2(sqrt(a),sqrt(1-a))
#d = Radius of the sphere * c
def calculate_distance_km_between_two_points_from_haversine_formula(lat1,lon1,lat2,lon2):
	difference_lat = math.radians(lat1 - lat2)
	difference_lon = math.radians(lon1 - lon2)
	a = (math.pow(math.sin(difference_lat/2.00),2.00)) + (math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.pow(math.sin(difference_lon/2.00),2.00))
	c = 2.00*math.atan2(math.sqrt(a),math.sqrt(1-a))
	distance = pygplates.Earth.mean_radius_in_kms * c
	return distance

def get_first_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_first_point_of_line is None")
		exit()
	return pygplates.PointOnSphere(polyline_on_sphere[0])

def get_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	last_point_index = len(polyline_on_sphere.to_lat_lon_list())-1
	return pygplates.PointOnSphere(polyline_on_sphere[last_point_index])

def get_second_last_point_of_line(polyline_on_sphere):
	if (polyline_on_sphere is None):
		print("Error input for get_last_point_of_line is None")
		exit()
	second_last_point_index = len(polyline_on_sphere.to_lat_lon_list())-2
	return pygplates.PointOnSphere(polyline_on_sphere[second_last_point_index])

def find_final_reconstructed_geometries(reconstructed_features_geometries,type):
	list_of_final_reconstructed_geometries = []
	if (type is pygplates.PointOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			if (len(reconstructed_ft_geometries) == 1):
				ft_geometry = reconstructed_ft_geometries[0]
				point = ft_geometry.get_reconstructed_geometry()
				list_of_final_reconstructed_geometries.append((each_ft,point))
			else:
				lat_values = []
				lon_values = []
				for ft_geometry in reconstructed_ft_geometries:
					point = ft_geometry.get_reconstructed_geometry()
					lat,lon = point.to_lat_lon()
					lat_values.append(lat)
					lon_values.append(lon)
				mean_lat = np.mean(lat_values)
				mean_lon = np.mean(lon_values)
				new_point = pygplates.PointOnSphere((mean_lat,mean_lon))
				list_of_final_reconstructed_geometries.append((each_ft,new_point))
	elif (type is pygplates.PolygonOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_area = 0
			current_polygon = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				polygon = reconstructed_ft_geometry.get_reconstructed_geometry()
				#print(polygon.get_area())
				
				if (polygon.get_area() > current_area):
					current_area = polygon.get_area()
					current_polygon = polygon 
			if (current_area > 0 and current_polygon is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_polygon))
	elif (type is pygplates.PolylineOnSphere):
		for each_ft,reconstructed_ft_geometries in reconstructed_features_geometries:
			current_len = 0
			current_line = None
			for reconstructed_ft_geometry in reconstructed_ft_geometries:
				line = reconstructed_ft_geometry.get_reconstructed_geometry()
				if (line is None):
					print("Error in calculate_distance_between_end_nodes")
					print("Error reconstructed_ft_geometry.get_reconstructed_geometry() is None")
					exit()
				first_point_of_line = get_first_point_of_line(line)							
				end_point_of_line = get_last_point_of_line(line)
				# if (line.get_arc_length() > current_len and first_point_of_line!= end_point_of_line):
					# current_len = line.get_arc_length()
					# current_line = line
				if (line.get_arc_length() > current_len):
					current_len = line.get_arc_length()
					current_line = line 
			if (current_len > 0 and current_line is not None):
				list_of_final_reconstructed_geometries.append((each_ft,current_line))
	return list_of_final_reconstructed_geometries

def evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(reconstructed_point_A_at_to_time, reconstructed_point_B_at_to_time, Euler_pole):
	# A.(E_of_B_rel_to_A x B)
	cross_product = pygplates.Vector3D.cross(Euler_pole.to_xyz(),reconstructed_point_B_at_to_time.to_xyz())
	dot_product = pygplates.Vector3D.dot(reconstructed_point_A_at_to_time.to_xyz(),cross_product)
	#C:[]
	# if (dot_product >= 0.200):
		# return ('C',dot_product)
	# elif (dot_product < -0.110):
		# return ('D',dot_product)
	# elif (dot_product >= -0.110 and dot_product <0.0150):
		# return ('T',dot_product)
	
	
	if (dot_product >= 0.300):
		return ('C',dot_product)
	elif (dot_product < 0.300 and dot_product >= 0.110):
		return ('C',dot_product) #oblique-convergence
	elif (dot_product >= -0.110 and dot_product < 0.110):
		return ('T',dot_product)
	elif (dot_product >= -0.300 and dot_product < -0.110):
		return ('D',dot_product) #oblique-divergence
	elif (dot_product < -0.300):
		return ('D',dot_product)

def create_topological_rift_point_sections(list_of_rift_point_features):
	topological_pt_sections = []
	for rift_point_ft in list_of_rift_point_features:
		topological_section = pygplates.GpmlTopologicalSection.create(rift_point_ft,topological_geometry_type=pygplates.GpmlTopologicalLine)
		if topological_section is not None:
			topological_pt_sections.append(topological_section)
	return topological_pt_sections

def create_topological_isochron_line_feature(topological_pt_sections):
	if (len(topological_pt_sections) > 1):
		topological_isochron_line_feature = pygplates.Feature.create_topological_feature(pygplates.FeatureType.gpml_isochron,pygplates.GpmlTopologicalLine(topological_pt_sections))
		return topological_isochron_line_feature
	else:
		return None

def create_isochron_from_temp_rift_point_features(input_point_features, rift_point_features_records_csv, maximum_reconstruction_time, modelname, yearmonthday):
	dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	temp_isochron_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[rift_history_df['start_div'] <= maximum_reconstruction_time]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'order'].to_numpy()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		#there should only be one value 
		if (len(array_of_start_div) == 1):
			start_div = array_of_start_div[0]
		else:
			print("Error there is more than one value for start_div for rift_name ", rift_name)
			exit()
		list_of_wanted_rift_point_features = []
		sorted_array_of_order_for_rift_points = np.sort(array_of_order_for_rift_points)
		already_included = []
		for order in sorted_array_of_order_for_rift_points:
			name_of_rift_point_ft = rift_name+'_'+str(order)
			if (name_of_rift_point_ft in already_included):
				continue
			found_point_ft = None
			for rift_point_ft in input_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					found_point_ft = rift_point_ft
					break
			if (found_point_ft is None):
				print("Error could not find the wanted rift point feature")
				print("name_of_rift_point_ft",name_of_rift_point_ft)
				exit()
			list_of_wanted_rift_point_features.append(found_point_ft)
		if (len(list_of_wanted_rift_point_features) > 1):
			topological_pt_sections = create_topological_rift_point_sections(list_of_wanted_rift_point_features)
			if (len(topological_pt_sections) > 1):
				topological_ft = create_topological_isochron_line_feature(topological_pt_sections)
				if (topological_ft is not None):
					temp_isochron_features.add(topological_ft)
					for each_original_pt_ft in list_of_wanted_rift_point_features:
						temp_isochron_features.add(each_original_pt_ft)
	temp_isochron_features.write('topological_isochron_fts_from_modified_rift_pt_fts_'+str(maximum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml')

def create_isochron_from_temp_isochron_point_features(input_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, modelname, yearmonthday):
	dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	temp_isochron_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_order_for_rift_points = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'order'].to_numpy()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		#there should only be one value 
		if (len(array_of_start_div) == 1):
			start_div = array_of_start_div[0]
		else:
			print("Error there is more than one value for start_div for rift_name ", rift_name)
			exit()
		list_of_wanted_rift_point_features = []
		sorted_array_of_order_for_rift_points = np.sort(array_of_order_for_rift_points)
		already_included = []
		for order in sorted_array_of_order_for_rift_points:
			name_of_rift_point_ft = rift_name+'_'+str(order)
			if (name_of_rift_point_ft in already_included):
				continue
			found_point_ft = None
			for rift_point_ft in input_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					found_point_ft = rift_point_ft
					break
			if (found_point_ft is not None):
				#isochron point features could be subducted...hence disappear
				list_of_wanted_rift_point_features.append(found_point_ft)
		if (len(list_of_wanted_rift_point_features) > 1):
			topological_pt_sections = create_topological_rift_point_sections(list_of_wanted_rift_point_features)
			if (len(topological_pt_sections) > 1):
				topological_ft = create_topological_isochron_line_feature(topological_pt_sections)
				if (topological_ft is not None):
					temp_isochron_features.add(topological_ft)
					for each_original_pt_ft in list_of_wanted_rift_point_features:
						temp_isochron_features.add(each_original_pt_ft)
	temp_isochron_features.write('topological_isochron_fts_from_temp_isochron_point_features_with_max_star_div_age_'+str(maximum_reconstruction_time)+'_min_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml')


def create_oceanic_crust_polygon_fts_at_age(at_age, to_age, list_of_reconstructed_points_from_div_margins, list_of_reconstructed_points_for_MOR, reconstruction_plate_id, left_plate_id, right_plate_id, left_or_right_side_rel_to_MOR, name, rotation_model, reference):
	oceanic_crust_ft = None
	#print(type(list_of_reconstructed_points_from_div_margins),type(list_of_reconstructed_points_for_MOR))
	if (left_or_right_side_rel_to_MOR == 'left'):
		temporary_reversed_ordered_left_fts = [item for item in reversed(list_of_reconstructed_points_from_div_margins)]
		final_list_of_points = list_of_reconstructed_points_for_MOR + temporary_reversed_ordered_left_fts
		oceanic_polygon = pygplates.PolygonOnSphere(final_list_of_points)
		oceanic_crust_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, oceanic_polygon, valid_time = (at_age,to_age))
		oceanic_crust_ft.set_reconstruction_plate_id(reconstruction_plate_id)
		oceanic_crust_ft.set_name(name)
		oceanic_crust_ft.set_left_plate(left_plate_id,verify_information_model = pygplates.VerifyInformationModel.no)
		oceanic_crust_ft.set_right_plate(right_plate_id,verify_information_model = pygplates.VerifyInformationModel.no)
	elif (left_or_right_side_rel_to_MOR == 'right'):
		temporary_reversed_ordered_middle_fts = [item for item in reversed(list_of_reconstructed_points_for_MOR)]
		final_list_of_points = list_of_reconstructed_points_from_div_margins + temporary_reversed_ordered_middle_fts
		oceanic_polygon = pygplates.PolygonOnSphere(final_list_of_points)
		oceanic_crust_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, oceanic_polygon, valid_time = (at_age,to_age))
		oceanic_crust_ft.set_reconstruction_plate_id(reconstruction_plate_id)
		oceanic_crust_ft.set_name(name)
		oceanic_crust_ft.set_left_plate(left_plate_id,verify_information_model = pygplates.VerifyInformationModel.no)
		oceanic_crust_ft.set_right_plate(right_plate_id,verify_information_model = pygplates.VerifyInformationModel.no)
	
	if (reference is not None):
		pygplates.reverse_reconstruct(oceanic_crust_ft, rotation_model, at_age, reference)
	else:
		pygplates.reverse_reconstruct(oceanic_crust_ft, rotation_model, at_age)
	
	return oceanic_crust_ft

def create_oceanic_crust_from_rift_and_isochron_point_features_w_distinct_pairs_of_sgdus(div_margin_features, left_input_point_features, right_input_point_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday):
	#dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	oceanic_crust_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_lrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'lrepgduid'].unique()
		array_of_rrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'rrepgduid'].unique()
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),['order','lpolylid','rpolylid','left_gdu','right_gdu']]
		sorted_rift_order_records = df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu.sort_values(by = 'order', ascending = False)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# start_div = -1.00
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		#NEW
		start_div = sorted_array_of_start_div[-1]
		
		valid_div_margin_features = [div_margin_ft for div_margin_ft in div_margin_features if div_margin_ft.is_valid_at_time(start_div)]
		list_of_wanted_left_isochron_point_features = []
		list_of_wanted_right_isochron_point_features = []
		list_of_wanted_rift_point_features = []
		#find a collection of divergent margins associated with rifts
		list_of_left_div_margin_feats = []
		list_of_right_div_margin_feats = []
		#sorted_array_of_order_for_rift_points = np.sort(array_of_order_for_rift_points)
		#desc_sorted_array_of_order_for_rift_points = np.flip(sorted_array_of_order_for_rift_points)
		already_included = []
		end_age_of_isochron_feats = -1.00
		
		list_of_pairs_gdus = []
		prev_left_gdu,prev_right_gdu = -1,-1
		for order, lpolylid, rpolylid, left_gdu, right_gdu in sorted_rift_order_records.itertuples(index = False, name = None):
			print('order, lpolylid, rpolylid, left_gdu, right_gdu',order, lpolylid, rpolylid, left_gdu, right_gdu)
			name_of_rift_point_ft = rift_name+'_'+str(order)
			pairs_of_gdus = str(left_gdu)+'_'+str(right_gdu)
			if (pairs_of_gdus in list_of_pairs_gdus):
				for left_point_ft in left_input_point_features:
					if (left_point_ft.get_name() == name_of_rift_point_ft and left_point_ft.get_reconstruction_plate_id() == left_gdu):
						list_of_wanted_left_isochron_point_features.append(left_point_ft)
						#break
				for right_point_ft in right_input_point_features:
					if (right_point_ft.get_name() == name_of_rift_point_ft and right_point_ft.get_reconstruction_plate_id() == right_gdu):
						list_of_wanted_right_isochron_point_features.append(right_point_ft)
						#break
				found_point_ft = None
				for rift_point_ft in rift_point_features:
					if (rift_point_ft.get_name() == name_of_rift_point_ft):
						found_point_ft = rift_point_ft
						_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
						if (end_age_of_isochron_feats == -1.00):
							end_age_of_isochron_feats = temp_rift_pt_end_age
						elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
							end_age_of_isochron_feats = temp_rift_pt_end_age
						break
				if (end_age_of_isochron_feats < 0.00):
					end_age_of_isochron_feats = 0.00
				if (found_point_ft is not None):
					list_of_wanted_rift_point_features.append(found_point_ft)
				
				already_included_margins = []
				for div_ft in valid_div_margin_features:
					polylid = div_ft.get_name()
					gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
					if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
						if (polylid not in already_included_margins):
							list_of_left_div_margin_feats.append(div_ft)
							already_included_margins.append(polylid)
					elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
						if (polylid not in already_included_margins):
							list_of_right_div_margin_feats.append(div_ft)
							already_included_margins.append(polylid)
				
			else:#find new pairs of gdu or this is the first time
				if (len(list_of_wanted_rift_point_features) > 1 and (len(list_of_wanted_left_isochron_point_features) > 1 or len(list_of_wanted_right_isochron_point_features) > 1)):
					selected_lrepgduid = prev_left_gdu
					selected_rrepgduid = prev_right_gdu
					#print('selected_rrepgduid',selected_rrepgduid,type(selected_rrepgduid))
					current_rift_age = start_div
					list_of_ordered_left_div_margin_fts = []
					list_of_ordered_right_div_margin_fts = []
					reconstructed_MOR_features = []
					reconstructed_left_div_fts = []
					reconstructed_right_div_fts = []
					reconstructed_right_MOR_features = []
					reconstructed_left_MOR_features = []
					list_of_wanted_and_valid_rift_point_features = []
					# if (rift_name == 'R79694_79700'):
						# print('start_div',start_div)
					while (current_rift_age >= end_age_of_isochron_feats):#create oceanic crust features with current data
						# if (rift_name == 'R79694_79700'):
							# print('current_rift_age',current_rift_age)
						list_of_ordered_left_div_margin_fts[:] = []
						list_of_ordered_right_div_margin_fts[:] = []
						reconstructed_MOR_features[:] = []
						reconstructed_left_div_fts[:] = []
						reconstructed_right_div_fts[:] = []
						list_of_wanted_and_valid_rift_point_features[:] = []
						if (current_rift_age == start_div):
							list_of_ordered_left_div_margin_fts = list_of_left_div_margin_feats
							list_of_ordered_right_div_margin_fts = list_of_right_div_margin_feats
							
							if (reference is not None):
								pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
								if (len(list_of_ordered_left_div_margin_fts) > 1):
									pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
								if (len(list_of_ordered_right_div_margin_fts) > 1):
									pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,group_with_feature = True)
								if (len(list_of_ordered_left_div_margin_fts) > 1):
									pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,group_with_feature = True)
								if (len(list_of_ordered_right_div_margin_fts) > 1):
									pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,group_with_feature = True)
							final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
							MOR_features,temp_reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
							reconstructed_MOR_points = list(temp_reconstructed_MOR_points)
							#print('reconstructed_MOR_points',reconstructed_MOR_points)
							if (len(reconstructed_left_div_fts) > 1):
								final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PolylineOnSphere)
								div_left_features,reconstructed_div_left_lines = zip(*final_reconstructed_left_fts)
								reconstructed_div_left_points = []
								for left_line in reconstructed_div_left_lines:
									list_of_lat_lon_tuples = left_line.to_lat_lon_list()
									for lat_lon_tuple in list_of_lat_lon_tuples:
										reconstructed_div_left_points.append(pygplates.PointOnSphere(lat_lon_tuple))
								#print(reconstructed_div_left_points)
								#print(reconstructed_MOR_points)
								left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_left_points, reconstructed_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
								oceanic_crust_features.add(left_oceanic_crust_feats)
							if (len(reconstructed_right_div_fts) > 1):
								final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PolylineOnSphere)
								div_right_features,reconstructed_div_right_lines = zip(*final_reconstructed_right_fts)
								reconstructed_div_right_points = []
								for right_line in reconstructed_div_right_lines:
									list_of_lat_lon_tuples = right_line.to_lat_lon_list()
									for lat_lon_tuple in list_of_lat_lon_tuples:
										reconstructed_div_right_points.append(pygplates.PointOnSphere(lat_lon_tuple))
								right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_right_points, reconstructed_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
								oceanic_crust_features.add(right_oceanic_crust_feats)
						elif (current_rift_age < start_div):
							reconstructed_left_MOR_features[:] = []
							reconstructed_right_MOR_features[:] = []
							for isochron_point_ft in list_of_wanted_left_isochron_point_features:
								begin_isochron_age,_ = isochron_point_ft.get_valid_time()
								if ((begin_isochron_age == (current_rift_age + age_interval_for_isochron_fts)) and isochron_point_ft.is_valid_at_time(current_rift_age)):
									list_of_ordered_left_div_margin_fts.append(isochron_point_ft.clone())
							for isochron_point_ft in list_of_wanted_right_isochron_point_features:
								begin_isochron_age,_ = isochron_point_ft.get_valid_time()
								if ((begin_isochron_age == (current_rift_age + age_interval_for_isochron_fts)) and isochron_point_ft.is_valid_at_time(current_rift_age)):
									list_of_ordered_right_div_margin_fts.append(isochron_point_ft.clone())
							#list_of_wanted_and_valid_rift_point_features_for_left = [valid_rift_point_ft for valid_rift_point_ft in list_of_wanted_left_isochron_point_features if valid_rift_point_ft.is_valid_at_time(current_rift_age)]
							#list_of_wanted_and_valid_rift_point_features_for_right = [valid_rift_point_ft for valid_rift_point_ft in list_of_wanted_right_isochron_point_features if valid_rift_point_ft.is_valid_at_time(current_rift_age)]
							for valid_rift_point_ft in list_of_wanted_rift_point_features:
								if (valid_rift_point_ft.is_valid_at_time(current_rift_age)):
									list_of_wanted_and_valid_rift_point_features.append(valid_rift_point_ft)
							#if (len(list_of_wanted_and_valid_rift_point_features_for_left) > 1 and len(list_of_wanted_and_valid_rift_point_features_for_right) > 1):
							
							if (rift_name == 'R79694_79700'):
								print('len(list_of_wanted_and_valid_rift_point_features)',len(list_of_wanted_and_valid_rift_point_features))
								print('len(list_of_wanted_left_isochron_point_features)',len(list_of_wanted_left_isochron_point_features))
								print('len(list_of_ordered_left_div_margin_fts)',len(list_of_ordered_left_div_margin_fts))
								print('len(list_of_wanted_right_isochron_point_features)',len(list_of_wanted_right_isochron_point_features))
								print('len(list_of_ordered_right_div_margin_fts)',len(list_of_ordered_right_div_margin_fts))
							
							
							if (len(list_of_wanted_and_valid_rift_point_features) > 1):
								if (reference is not None):
									pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_left_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									#pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_right_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									if (len(list_of_ordered_left_div_margin_fts) > 1):
										pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									if (len(list_of_ordered_right_div_margin_fts) > 1):
										pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
								else:
									pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_left_MOR_features,current_rift_age,group_with_feature = True)
									#pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_right_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									if (len(list_of_ordered_left_div_margin_fts) > 1):
										pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age, group_with_feature = True)
									if (len(list_of_ordered_right_div_margin_fts) > 1):
										pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age, group_with_feature = True)
								final_reconstructed_left_MOR_fts = find_final_reconstructed_geometries(reconstructed_left_MOR_features,pygplates.PointOnSphere)
								reconstructed_right_MOR_features = reconstructed_left_MOR_features
								final_reconstructed_right_MOR_fts = find_final_reconstructed_geometries(reconstructed_right_MOR_features,pygplates.PointOnSphere)
								left_MOR_features, temp_reconstructed_left_MOR_points = zip(*final_reconstructed_left_MOR_fts)
								reconstructed_left_MOR_points = list(temp_reconstructed_left_MOR_points)
								right_MOR_features, temp_reconstructed_right_MOR_points = zip(*final_reconstructed_right_MOR_fts)
								reconstructed_right_MOR_points = list(temp_reconstructed_right_MOR_points)
								if (rift_name == 'R79694_79700'):
									print('len(list_of_wanted_and_valid_rift_point_features)',len(list_of_wanted_and_valid_rift_point_features))
									print('len(reconstructed_div_left_points)',len(reconstructed_div_left_points))
									print('len(reconstructed_div_right_points)',len(reconstructed_div_right_points))
								if (len(reconstructed_left_div_fts) > 1):
									final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts, pygplates.PointOnSphere)
									div_left_features,temp_reconstructed_div_left_points = zip(*final_reconstructed_left_fts)
									reconstructed_div_left_points = list(temp_reconstructed_div_left_points)
									left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_left_points, reconstructed_left_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
									oceanic_crust_features.add(left_oceanic_crust_feats)
								if (len(reconstructed_right_div_fts) > 1):
									final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts, pygplates.PointOnSphere)
									div_right_features,temp_reconstructed_div_right_points = zip(*final_reconstructed_right_fts)
									reconstructed_div_right_points = list(temp_reconstructed_div_right_points)
									right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_right_points, reconstructed_right_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
									oceanic_crust_features.add(right_oceanic_crust_feats)
						current_rift_age = current_rift_age - age_interval_for_isochron_fts
					#reset everything and start new collections of data
					list_of_wanted_rift_point_features[:] = []
					list_of_wanted_left_isochron_point_features[:] = []
					list_of_wanted_right_isochron_point_features[:] = []
					list_of_left_div_margin_feats[:] = []
					list_of_right_div_margin_feats[:] = []
					end_age_of_isochron_feats = -1.00
					for left_point_ft in left_input_point_features:
						if (left_point_ft.get_name() == name_of_rift_point_ft and left_point_ft.get_reconstruction_plate_id() == left_gdu):
							list_of_wanted_left_isochron_point_features.append(left_point_ft)
							#break
					for right_point_ft in right_input_point_features:
						if (right_point_ft.get_name() == name_of_rift_point_ft and right_point_ft.get_reconstruction_plate_id() == right_gdu):
							list_of_wanted_right_isochron_point_features.append(right_point_ft)
							#break
					found_point_ft = None
					for rift_point_ft in rift_point_features:
						if (rift_point_ft.get_name() == name_of_rift_point_ft):
							found_point_ft = rift_point_ft
							_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
							if (end_age_of_isochron_feats == -1.00):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							break
					if (end_age_of_isochron_feats < 0.00):
						end_age_of_isochron_feats = 0.00
					if (found_point_ft is not None):
						list_of_wanted_rift_point_features.append(found_point_ft)
					already_included_margins = []
					for div_ft in valid_div_margin_features:
						polylid = div_ft.get_name()
						gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
						if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_left_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
						elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_right_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
				else:
					for left_point_ft in left_input_point_features:
						if (left_point_ft.get_name() == name_of_rift_point_ft and left_point_ft.get_reconstruction_plate_id() == left_gdu):
							list_of_wanted_left_isochron_point_features.append(left_point_ft)
							#break
					for right_point_ft in right_input_point_features:
						if (right_point_ft.get_name() == name_of_rift_point_ft and right_point_ft.get_reconstruction_plate_id() == right_gdu):
							list_of_wanted_right_isochron_point_features.append(right_point_ft)
							#break
					found_point_ft = None
					for rift_point_ft in rift_point_features:
						if (rift_point_ft.get_name() == name_of_rift_point_ft):
							found_point_ft = rift_point_ft
							_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
							if (end_age_of_isochron_feats == -1.00):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							break
					if (end_age_of_isochron_feats < 0.00):
						end_age_of_isochron_feats = 0.00
					if (found_point_ft is not None):
						list_of_wanted_rift_point_features.append(found_point_ft)
				
					already_included_margins = []
					for div_ft in valid_div_margin_features:
						polylid = div_ft.get_name()
						gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
						if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_left_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
						elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_right_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
				prev_left_gdu,prev_right_gdu = left_gdu, right_gdu
				list_of_pairs_gdus.append(pairs_of_gdus)
		
		if(len(list_of_wanted_rift_point_features) > 0):
			selected_lrepgduid = prev_left_gdu
			selected_rrepgduid = prev_right_gdu
			#print('selected_rrepgduid',selected_rrepgduid,type(selected_rrepgduid))
			current_rift_age = start_div
			list_of_ordered_left_div_margin_fts = []
			list_of_ordered_right_div_margin_fts = []
			reconstructed_MOR_features = []
			reconstructed_left_div_fts = []
			reconstructed_right_div_fts = []
			reconstructed_right_MOR_features = []
			reconstructed_left_MOR_features = []
			list_of_wanted_and_valid_rift_point_features = []
			# if (rift_name == 'R79694_79700'):
				# print('start_div',start_div)
			while (current_rift_age >= end_age_of_isochron_feats):#create oceanic crust features with current data
				# if (rift_name == 'R79694_79700'):
					# print('current_rift_age',current_rift_age)
				list_of_ordered_left_div_margin_fts[:] = []
				list_of_ordered_right_div_margin_fts[:] = []
				reconstructed_MOR_features[:] = []
				reconstructed_left_div_fts[:] = []
				reconstructed_right_div_fts[:] = []
				list_of_wanted_and_valid_rift_point_features[:] = []
				if (current_rift_age == start_div):
					list_of_ordered_left_div_margin_fts = list_of_left_div_margin_feats
					list_of_ordered_right_div_margin_fts = list_of_right_div_margin_feats
					
					if (reference is not None):
						pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
						if (len(list_of_ordered_left_div_margin_fts) > 1):
							pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
						if (len(list_of_ordered_right_div_margin_fts) > 1):
							pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
					else:
						pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,group_with_feature = True)
						if (len(list_of_ordered_left_div_margin_fts) > 1):
							pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,group_with_feature = True)
						if (len(list_of_ordered_right_div_margin_fts) > 1):
							pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,group_with_feature = True)
					final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
					MOR_features,temp_reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
					reconstructed_MOR_points = list(temp_reconstructed_MOR_points)
					#print('reconstructed_MOR_points',reconstructed_MOR_points)
					if (len(reconstructed_left_div_fts) > 1):
						final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PolylineOnSphere)
						div_left_features,reconstructed_div_left_lines = zip(*final_reconstructed_left_fts)
						reconstructed_div_left_points = []
						for left_line in reconstructed_div_left_lines:
							list_of_lat_lon_tuples = left_line.to_lat_lon_list()
							for lat_lon_tuple in list_of_lat_lon_tuples:
								reconstructed_div_left_points.append(pygplates.PointOnSphere(lat_lon_tuple))
						#print(reconstructed_div_left_points)
						#print(reconstructed_MOR_points)
						left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_left_points, reconstructed_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
						oceanic_crust_features.add(left_oceanic_crust_feats)
					if (len(reconstructed_right_div_fts) > 1):
						final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PolylineOnSphere)
						div_right_features,reconstructed_div_right_lines = zip(*final_reconstructed_right_fts)
						reconstructed_div_right_points = []
						for right_line in reconstructed_div_right_lines:
							list_of_lat_lon_tuples = right_line.to_lat_lon_list()
							for lat_lon_tuple in list_of_lat_lon_tuples:
								reconstructed_div_right_points.append(pygplates.PointOnSphere(lat_lon_tuple))
						right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_right_points, reconstructed_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
						oceanic_crust_features.add(right_oceanic_crust_feats)
				elif (current_rift_age < start_div):
					reconstructed_left_MOR_features[:] = []
					reconstructed_right_MOR_features[:] = []
					for isochron_point_ft in list_of_wanted_left_isochron_point_features:
						begin_isochron_age,_ = isochron_point_ft.get_valid_time()
						if ((begin_isochron_age == (current_rift_age + age_interval_for_isochron_fts)) and isochron_point_ft.is_valid_at_time(current_rift_age)):
							list_of_ordered_left_div_margin_fts.append(isochron_point_ft.clone())
					for isochron_point_ft in list_of_wanted_right_isochron_point_features:
						begin_isochron_age,_ = isochron_point_ft.get_valid_time()
						if ((begin_isochron_age == (current_rift_age + age_interval_for_isochron_fts)) and isochron_point_ft.is_valid_at_time(current_rift_age)):
							list_of_ordered_right_div_margin_fts.append(isochron_point_ft.clone())
					#list_of_wanted_and_valid_rift_point_features_for_left = [valid_rift_point_ft for valid_rift_point_ft in list_of_wanted_left_isochron_point_features if valid_rift_point_ft.is_valid_at_time(current_rift_age)]
					#list_of_wanted_and_valid_rift_point_features_for_right = [valid_rift_point_ft for valid_rift_point_ft in list_of_wanted_right_isochron_point_features if valid_rift_point_ft.is_valid_at_time(current_rift_age)]
					for valid_rift_point_ft in list_of_wanted_rift_point_features:
						if (valid_rift_point_ft.is_valid_at_time(current_rift_age)):
							list_of_wanted_and_valid_rift_point_features.append(valid_rift_point_ft)
					#if (len(list_of_wanted_and_valid_rift_point_features_for_left) > 1 and len(list_of_wanted_and_valid_rift_point_features_for_right) > 1):
					
					if (rift_name == 'R79694_79700'):
						print('len(list_of_wanted_and_valid_rift_point_features)',len(list_of_wanted_and_valid_rift_point_features))
						print('len(list_of_wanted_left_isochron_point_features)',len(list_of_wanted_left_isochron_point_features))
						print('len(list_of_ordered_left_div_margin_fts)',len(list_of_ordered_left_div_margin_fts))
						print('len(list_of_wanted_right_isochron_point_features)',len(list_of_wanted_right_isochron_point_features))
						print('len(list_of_ordered_right_div_margin_fts)',len(list_of_ordered_right_div_margin_fts))
							
							
					if (len(list_of_wanted_and_valid_rift_point_features) > 1):
						if (reference is not None):
							pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_left_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							#pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_right_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							if (len(list_of_ordered_left_div_margin_fts) > 1):
								pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							if (len(list_of_ordered_right_div_margin_fts) > 1):
								pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_left_MOR_features,current_rift_age,group_with_feature = True)
							#pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_right_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							if (len(list_of_ordered_left_div_margin_fts) > 1):
								pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age, group_with_feature = True)
							if (len(list_of_ordered_right_div_margin_fts) > 1):
								pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age, group_with_feature = True)
						final_reconstructed_left_MOR_fts = find_final_reconstructed_geometries(reconstructed_left_MOR_features,pygplates.PointOnSphere)
						reconstructed_right_MOR_features = reconstructed_left_MOR_features
						final_reconstructed_right_MOR_fts = find_final_reconstructed_geometries(reconstructed_right_MOR_features,pygplates.PointOnSphere)
						left_MOR_features, temp_reconstructed_left_MOR_points = zip(*final_reconstructed_left_MOR_fts)
						reconstructed_left_MOR_points = list(temp_reconstructed_left_MOR_points)
						right_MOR_features, temp_reconstructed_right_MOR_points = zip(*final_reconstructed_right_MOR_fts)
						reconstructed_right_MOR_points = list(temp_reconstructed_right_MOR_points)
						
						if (len(reconstructed_left_div_fts) > 1):
							final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts, pygplates.PointOnSphere)
							div_left_features,temp_reconstructed_div_left_points = zip(*final_reconstructed_left_fts)
							reconstructed_div_left_points = list(temp_reconstructed_div_left_points)
							left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_left_points, reconstructed_left_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
							oceanic_crust_features.add(left_oceanic_crust_feats)
						if (len(reconstructed_right_div_fts) > 1):
							final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts, pygplates.PointOnSphere)
							div_right_features,temp_reconstructed_div_right_points = zip(*final_reconstructed_right_fts)
							reconstructed_div_right_points = list(temp_reconstructed_div_right_points)
							right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_right_points, reconstructed_right_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
							oceanic_crust_features.add(right_oceanic_crust_feats)
				current_rift_age = current_rift_age - age_interval_for_isochron_fts
			#reset everything and start new collections of data
			list_of_wanted_rift_point_features[:] = []
			list_of_wanted_left_isochron_point_features[:] = []
			list_of_wanted_right_isochron_point_features[:] = []
			list_of_left_div_margin_feats[:] = []
			list_of_right_div_margin_feats[:] = []
			end_age_of_isochron_feats = -1.00
	oceanic_crust_features.write('oceanic_crust_for_gdus_from_rift_and_isochron_feats_with_max_star_div_age_'+str(maximum_reconstruction_time)+'_min_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def create_oceanic_crust_from_original_and_additional_rift_and_isochron_point_features_w_distinct_pairs_of_sgdus(div_margin_features, left_input_point_features, right_input_point_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday):
	#dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	oceanic_crust_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_lrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'lrepgduid'].unique()
		array_of_rrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'rrepgduid'].unique()
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),['order','lpolylid','rpolylid','left_gdu','right_gdu']]
		sorted_rift_order_records = df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu.sort_values(by = 'order', ascending = False)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# start_div = -1.00
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		#NEW
		start_div = sorted_array_of_start_div[-1]
		
		valid_div_margin_features = [div_margin_ft for div_margin_ft in div_margin_features if div_margin_ft.is_valid_at_time(start_div)]
		list_of_wanted_left_isochron_point_features = []
		list_of_wanted_right_isochron_point_features = []
		list_of_wanted_rift_point_features = []
		#find a collection of divergent margins associated with rifts
		list_of_left_div_margin_feats = []
		list_of_right_div_margin_feats = []
		#sorted_array_of_order_for_rift_points = np.sort(array_of_order_for_rift_points)
		#desc_sorted_array_of_order_for_rift_points = np.flip(sorted_array_of_order_for_rift_points)
		already_included = []
		end_age_of_isochron_feats = -1.00
		
		list_of_pairs_gdus = []
		prev_left_gdu,prev_right_gdu = -1,-1
		for order, lpolylid, rpolylid, left_gdu, right_gdu in sorted_rift_order_records.itertuples(index = False, name = None):
			print('order, lpolylid, rpolylid, left_gdu, right_gdu',order, lpolylid, rpolylid, left_gdu, right_gdu)
			name_of_rift_point_ft = rift_name+'_'+str(order)
			pairs_of_gdus = str(left_gdu)+'_'+str(right_gdu)
			if (pairs_of_gdus in list_of_pairs_gdus):
				for left_point_ft in left_input_point_features:
					if (left_point_ft.get_name() == name_of_rift_point_ft and left_point_ft.get_reconstruction_plate_id() == left_gdu):
						list_of_wanted_left_isochron_point_features.append(left_point_ft)
						#break
				for right_point_ft in right_input_point_features:
					if (right_point_ft.get_name() == name_of_rift_point_ft and right_point_ft.get_reconstruction_plate_id() == right_gdu):
						list_of_wanted_right_isochron_point_features.append(right_point_ft)
						#break
				found_point_ft = None
				for rift_point_ft in rift_point_features:
					if (rift_point_ft.get_name() == name_of_rift_point_ft):
						found_point_ft = rift_point_ft
						_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
						if (end_age_of_isochron_feats == -1.00):
							end_age_of_isochron_feats = temp_rift_pt_end_age
						elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
							end_age_of_isochron_feats = temp_rift_pt_end_age
						break
				if (end_age_of_isochron_feats < 0.00):
					end_age_of_isochron_feats = 0.00
				if (found_point_ft is not None):
					list_of_wanted_rift_point_features.append(found_point_ft)
				
				already_included_margins = []
				for div_ft in valid_div_margin_features:
					polylid = div_ft.get_name()
					gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
					if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
						if (polylid not in already_included_margins):
							list_of_left_div_margin_feats.append(div_ft)
							already_included_margins.append(polylid)
					elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
						if (polylid not in already_included_margins):
							list_of_right_div_margin_feats.append(div_ft)
							already_included_margins.append(polylid)
				
			else:#find new pairs of gdu or this is the first time
				if (len(list_of_wanted_rift_point_features) > 1 and (len(list_of_wanted_left_isochron_point_features) > 1 or len(list_of_wanted_right_isochron_point_features) > 1)):
					selected_lrepgduid = prev_left_gdu
					selected_rrepgduid = prev_right_gdu
					#print('selected_rrepgduid',selected_rrepgduid,type(selected_rrepgduid))
					current_rift_age = start_div
					list_of_ordered_left_div_margin_fts = []
					list_of_ordered_right_div_margin_fts = []
					reconstructed_MOR_features = []
					reconstructed_left_div_fts = []
					reconstructed_right_div_fts = []
					reconstructed_right_MOR_features = []
					reconstructed_left_MOR_features = []
					list_of_wanted_and_valid_rift_point_features = []
					# if (rift_name == 'R79694_79700'):
						# print('start_div',start_div)
					while (current_rift_age >= end_age_of_isochron_feats):#create oceanic crust features with current data
						# if (rift_name == 'R79694_79700'):
							# print('current_rift_age',current_rift_age)
						list_of_ordered_left_div_margin_fts[:] = []
						list_of_ordered_right_div_margin_fts[:] = []
						reconstructed_MOR_features[:] = []
						reconstructed_left_div_fts[:] = []
						reconstructed_right_div_fts[:] = []
						list_of_wanted_and_valid_rift_point_features[:] = []
						if (current_rift_age == start_div):
							list_of_ordered_left_div_margin_fts = list_of_left_div_margin_feats
							list_of_ordered_right_div_margin_fts = list_of_right_div_margin_feats
							
							if (reference is not None):
								pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
								if (len(list_of_ordered_left_div_margin_fts) > 1):
									pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
								if (len(list_of_ordered_right_div_margin_fts) > 1):
									pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,group_with_feature = True)
								if (len(list_of_ordered_left_div_margin_fts) > 1):
									pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,group_with_feature = True)
								if (len(list_of_ordered_right_div_margin_fts) > 1):
									pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,group_with_feature = True)
							final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
							MOR_features,temp_reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
							reconstructed_MOR_points = list(temp_reconstructed_MOR_points)
							#print('reconstructed_MOR_points',reconstructed_MOR_points)
							if (len(reconstructed_left_div_fts) > 1):
								final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PolylineOnSphere)
								div_left_features,reconstructed_div_left_lines = zip(*final_reconstructed_left_fts)
								reconstructed_div_left_points = []
								for left_line in reconstructed_div_left_lines:
									list_of_lat_lon_tuples = left_line.to_lat_lon_list()
									for lat_lon_tuple in list_of_lat_lon_tuples:
										reconstructed_div_left_points.append(pygplates.PointOnSphere(lat_lon_tuple))
								#print(reconstructed_div_left_points)
								#print(reconstructed_MOR_points)
								left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_left_points, reconstructed_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
								oceanic_crust_features.add(left_oceanic_crust_feats)
							if (len(reconstructed_right_div_fts) > 1):
								final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PolylineOnSphere)
								div_right_features,reconstructed_div_right_lines = zip(*final_reconstructed_right_fts)
								reconstructed_div_right_points = []
								for right_line in reconstructed_div_right_lines:
									list_of_lat_lon_tuples = right_line.to_lat_lon_list()
									for lat_lon_tuple in list_of_lat_lon_tuples:
										reconstructed_div_right_points.append(pygplates.PointOnSphere(lat_lon_tuple))
								right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_right_points, reconstructed_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
								oceanic_crust_features.add(right_oceanic_crust_feats)
						elif (current_rift_age < start_div):
							reconstructed_left_MOR_features[:] = []
							reconstructed_right_MOR_features[:] = []
							for isochron_point_ft in list_of_wanted_left_isochron_point_features:
								begin_isochron_age,_ = isochron_point_ft.get_valid_time()
								if ((begin_isochron_age == (current_rift_age + age_interval_for_isochron_fts)) and isochron_point_ft.is_valid_at_time(current_rift_age)):
									list_of_ordered_left_div_margin_fts.append(isochron_point_ft.clone())
							for isochron_point_ft in list_of_wanted_right_isochron_point_features:
								begin_isochron_age,_ = isochron_point_ft.get_valid_time()
								if ((begin_isochron_age == (current_rift_age + age_interval_for_isochron_fts)) and isochron_point_ft.is_valid_at_time(current_rift_age)):
									list_of_ordered_right_div_margin_fts.append(isochron_point_ft.clone())
							#list_of_wanted_and_valid_rift_point_features_for_left = [valid_rift_point_ft for valid_rift_point_ft in list_of_wanted_left_isochron_point_features if valid_rift_point_ft.is_valid_at_time(current_rift_age)]
							#list_of_wanted_and_valid_rift_point_features_for_right = [valid_rift_point_ft for valid_rift_point_ft in list_of_wanted_right_isochron_point_features if valid_rift_point_ft.is_valid_at_time(current_rift_age)]
							for valid_rift_point_ft in list_of_wanted_rift_point_features:
								if (valid_rift_point_ft.is_valid_at_time(current_rift_age)):
									list_of_wanted_and_valid_rift_point_features.append(valid_rift_point_ft)
							#if (len(list_of_wanted_and_valid_rift_point_features_for_left) > 1 and len(list_of_wanted_and_valid_rift_point_features_for_right) > 1):
							
							if (rift_name == 'R79694_79700'):
								print('len(list_of_wanted_and_valid_rift_point_features)',len(list_of_wanted_and_valid_rift_point_features))
								print('len(list_of_wanted_left_isochron_point_features)',len(list_of_wanted_left_isochron_point_features))
								print('len(list_of_ordered_left_div_margin_fts)',len(list_of_ordered_left_div_margin_fts))
								print('len(list_of_wanted_right_isochron_point_features)',len(list_of_wanted_right_isochron_point_features))
								print('len(list_of_ordered_right_div_margin_fts)',len(list_of_ordered_right_div_margin_fts))
							
							
							if (len(list_of_wanted_and_valid_rift_point_features) > 1):
								if (reference is not None):
									pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_left_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									#pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_right_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									if (len(list_of_ordered_left_div_margin_fts) > 1):
										pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									if (len(list_of_ordered_right_div_margin_fts) > 1):
										pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
								else:
									pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_left_MOR_features,current_rift_age,group_with_feature = True)
									#pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_right_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									if (len(list_of_ordered_left_div_margin_fts) > 1):
										pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age, group_with_feature = True)
									if (len(list_of_ordered_right_div_margin_fts) > 1):
										pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age, group_with_feature = True)
								final_reconstructed_left_MOR_fts = find_final_reconstructed_geometries(reconstructed_left_MOR_features,pygplates.PointOnSphere)
								reconstructed_right_MOR_features = reconstructed_left_MOR_features
								final_reconstructed_right_MOR_fts = find_final_reconstructed_geometries(reconstructed_right_MOR_features,pygplates.PointOnSphere)
								left_MOR_features, temp_reconstructed_left_MOR_points = zip(*final_reconstructed_left_MOR_fts)
								reconstructed_left_MOR_points = list(temp_reconstructed_left_MOR_points)
								right_MOR_features, temp_reconstructed_right_MOR_points = zip(*final_reconstructed_right_MOR_fts)
								reconstructed_right_MOR_points = list(temp_reconstructed_right_MOR_points)
								if (rift_name == 'R79694_79700'):
									print('len(list_of_wanted_and_valid_rift_point_features)',len(list_of_wanted_and_valid_rift_point_features))
									print('len(reconstructed_div_left_points)',len(reconstructed_div_left_points))
									print('len(reconstructed_div_right_points)',len(reconstructed_div_right_points))
								if (len(reconstructed_left_div_fts) > 1):
									final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts, pygplates.PointOnSphere)
									div_left_features,temp_reconstructed_div_left_points = zip(*final_reconstructed_left_fts)
									reconstructed_div_left_points = list(temp_reconstructed_div_left_points)
									left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_left_points, reconstructed_left_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
									oceanic_crust_features.add(left_oceanic_crust_feats)
								if (len(reconstructed_right_div_fts) > 1):
									final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts, pygplates.PointOnSphere)
									div_right_features,temp_reconstructed_div_right_points = zip(*final_reconstructed_right_fts)
									reconstructed_div_right_points = list(temp_reconstructed_div_right_points)
									right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_right_points, reconstructed_right_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
									oceanic_crust_features.add(right_oceanic_crust_feats)
						current_rift_age = current_rift_age - age_interval_for_isochron_fts
					#reset everything and start new collections of data
					list_of_wanted_rift_point_features[:] = []
					list_of_wanted_left_isochron_point_features[:] = []
					list_of_wanted_right_isochron_point_features[:] = []
					list_of_left_div_margin_feats[:] = []
					list_of_right_div_margin_feats[:] = []
					end_age_of_isochron_feats = -1.00
					for left_point_ft in left_input_point_features:
						if (left_point_ft.get_name() == name_of_rift_point_ft and left_point_ft.get_reconstruction_plate_id() == left_gdu):
							list_of_wanted_left_isochron_point_features.append(left_point_ft)
							#break
					for right_point_ft in right_input_point_features:
						if (right_point_ft.get_name() == name_of_rift_point_ft and right_point_ft.get_reconstruction_plate_id() == right_gdu):
							list_of_wanted_right_isochron_point_features.append(right_point_ft)
							#break
					found_point_ft = None
					for rift_point_ft in rift_point_features:
						if (rift_point_ft.get_name() == name_of_rift_point_ft):
							found_point_ft = rift_point_ft
							_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
							if (end_age_of_isochron_feats == -1.00):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							break
					if (end_age_of_isochron_feats < 0.00):
						end_age_of_isochron_feats = 0.00
					if (found_point_ft is not None):
						list_of_wanted_rift_point_features.append(found_point_ft)
					already_included_margins = []
					for div_ft in valid_div_margin_features:
						polylid = div_ft.get_name()
						gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
						if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_left_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
						elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_right_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
				else:
					for left_point_ft in left_input_point_features:
						if (left_point_ft.get_name() == name_of_rift_point_ft and left_point_ft.get_reconstruction_plate_id() == left_gdu):
							list_of_wanted_left_isochron_point_features.append(left_point_ft)
							#break
					for right_point_ft in right_input_point_features:
						if (right_point_ft.get_name() == name_of_rift_point_ft and right_point_ft.get_reconstruction_plate_id() == right_gdu):
							list_of_wanted_right_isochron_point_features.append(right_point_ft)
							#break
					found_point_ft = None
					for rift_point_ft in rift_point_features:
						if (rift_point_ft.get_name() == name_of_rift_point_ft):
							found_point_ft = rift_point_ft
							_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
							if (end_age_of_isochron_feats == -1.00):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							break
					if (end_age_of_isochron_feats < 0.00):
						end_age_of_isochron_feats = 0.00
					if (found_point_ft is not None):
						list_of_wanted_rift_point_features.append(found_point_ft)
				
					already_included_margins = []
					for div_ft in valid_div_margin_features:
						polylid = div_ft.get_name()
						gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
						if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_left_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
						elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_right_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
				prev_left_gdu,prev_right_gdu = left_gdu, right_gdu
				list_of_pairs_gdus.append(pairs_of_gdus)
				
	oceanic_crust_features.write('oceanic_crust_for_gdus_from_rift_and_isochron_feats_with_max_star_div_age_'+str(maximum_reconstruction_time)+'_min_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def create_oceanic_crust_from_rift_and_isochron_point_features(div_margin_features, left_input_point_features, right_input_point_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday):
	#dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	oceanic_crust_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_lrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'lrepgduid'].unique()
		array_of_rrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'rrepgduid'].unique()
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		df_of_rift_order_and_lpolylid_rpolylid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),['order','lpolylid','rpolylid']]
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# start_div = -1.00
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		#NEW
		start_div = sorted_array_of_start_div[-1]
		
		valid_div_margin_features = [div_margin_ft for div_margin_ft in div_margin_features if div_margin_ft.is_valid_at_time(start_div)]
		list_of_wanted_left_isochron_point_features = []
		list_of_wanted_right_isochron_point_features = []
		list_of_wanted_rift_point_features = []
		#find a collection of divergent margins associated with rifts
		list_of_left_div_margin_feats = []
		list_of_right_div_margin_feats = []
		sorted_array_of_order_for_rift_points = np.sort(array_of_order_for_rift_points)
		desc_sorted_array_of_order_for_rift_points = np.flip(sorted_array_of_order_for_rift_points)
		already_included = []
		end_age_of_isochron_feats = -1.00
		for order in desc_sorted_array_of_order_for_rift_points:
			name_of_rift_point_ft = rift_name+'_'+str(order)
			# if (name_of_rift_point_ft in already_included):
				# continue
			# already_included.append(name_of_rift_point_ft)
			found_point_ft = None
			for rift_point_ft in left_input_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					list_of_wanted_left_isochron_point_features.append(rift_point_ft)
				# if (rift_point_ft.get_name() == name_of_rift_point_ft):
					# found_point_ft = rift_point_ft
					# # _,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
					# # if (end_age_of_isochron_feats == -1.00):
						# # end_age_of_isochron_feats = temp_rift_pt_end_age
					# # elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
						# # end_age_of_isochron_feats = temp_rift_pt_end_age
					# break
			# if (found_point_ft is not None):
				# #isochron point features could be subducted...hence disappear
				# list_of_wanted_left_isochron_point_features.append(found_point_ft)
			
			found_point_ft = None
			for rift_point_ft in right_input_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					list_of_wanted_right_isochron_point_features.append(rift_point_ft)
				# if (rift_point_ft.get_name() == name_of_rift_point_ft):
					# found_point_ft = rift_point_ft
					# #_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
					# # if (end_age_of_isochron_feats > temp_rift_pt_end_age): #because we compare with the minimum end age from the left features
						# # end_age_of_isochron_feats = temp_rift_pt_end_age
					# break
			# if (found_point_ft is not None):
				# #isochron point features could be subducted...hence disappear
				# list_of_wanted_right_isochron_point_features.append(found_point_ft)
			
			found_point_ft = None
			for rift_point_ft in rift_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					found_point_ft = rift_point_ft
					_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
					if (end_age_of_isochron_feats == -1.00):
						end_age_of_isochron_feats = temp_rift_pt_end_age
					elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
						end_age_of_isochron_feats = temp_rift_pt_end_age
					break
			if (end_age_of_isochron_feats < 0.00):
				end_age_of_isochron_feats = 0.00
			if (found_point_ft is not None):
				list_of_wanted_rift_point_features.append(found_point_ft)
			wanted_lpolyglid_rpolylid = df_of_rift_order_and_lpolylid_rpolylid.loc[df_of_rift_order_and_lpolylid_rpolylid['order'] == order, ['lpolylid','rpolylid']]
			if (len(wanted_lpolyglid_rpolylid) > 1):
				print('Warning: unexpected result for wanted_lpolyglid_rpolylid')
				print('len(wanted_lpolyglid_rpolylid) > 1')
				print('current rift_name',rift_name, 'order', order)
			wanted_lpolylid, wanted_rpolylid = None, None
			for row in wanted_lpolyglid_rpolylid.itertuples(index = False, name = None):
				wanted_lpolylid = row[0]
				wanted_rpolylid = row[1]
			already_included_margins = []
			for div_ft in valid_div_margin_features:
				polylid = div_ft.get_name()
				if (polylid == wanted_lpolylid):
					if (polylid not in already_included_margins):
						list_of_left_div_margin_feats.append(div_ft)
						already_included_margins.append(polylid)
				elif (polylid == wanted_rpolylid):
					if (polylid not in already_included_margins):
						list_of_right_div_margin_feats.append(div_ft)
						already_included_margins.append(polylid)
		if (len(list_of_wanted_rift_point_features) > 1 and (len(list_of_wanted_left_isochron_point_features) > 1 or len(list_of_wanted_right_isochron_point_features) > 1)):
			selected_lrepgduid = array_of_lrepgduid[0]
			selected_rrepgduid = array_of_rrepgduid[0]
			#print('selected_lrepgduid',selected_lrepgduid,type(selected_lrepgduid))
			selected_lrepgduid = int(array_of_lrepgduid[0])
			selected_rrepgduid = int(array_of_rrepgduid[0])
			#print('selected_rrepgduid',selected_rrepgduid,type(selected_rrepgduid))
			current_rift_age = start_div
			list_of_ordered_left_div_margin_fts = []
			list_of_ordered_right_div_margin_fts = []
			reconstructed_MOR_features = []
			reconstructed_left_div_fts = []
			reconstructed_right_div_fts = []
			reconstructed_right_MOR_features = []
			reconstructed_left_MOR_features = []
			list_of_wanted_and_valid_rift_point_features = []
			while (current_rift_age >= end_age_of_isochron_feats):
				list_of_ordered_left_div_margin_fts[:] = []
				list_of_ordered_right_div_margin_fts[:] = []
				reconstructed_MOR_features[:] = []
				reconstructed_left_div_fts[:] = []
				reconstructed_right_div_fts[:] = []
				list_of_wanted_and_valid_rift_point_features[:] = []
				if (current_rift_age == start_div):
					list_of_ordered_left_div_margin_fts = list_of_left_div_margin_feats
					list_of_ordered_right_div_margin_fts = list_of_right_div_margin_feats
					if (reference is not None):
						pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
						if (len(list_of_ordered_left_div_margin_fts) > 1):
							pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
						if (len(list_of_ordered_right_div_margin_fts) > 1):
							pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
					else:
						pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,group_with_feature = True)
						if (len(list_of_ordered_left_div_margin_fts) > 1):
							pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,group_with_feature = True)
						if (len(list_of_ordered_right_div_margin_fts) > 1):
							pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,group_with_feature = True)
					final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
					MOR_features,temp_reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
					reconstructed_MOR_points = list(temp_reconstructed_MOR_points)
					#print('reconstructed_MOR_points',reconstructed_MOR_points)
					if (len(reconstructed_left_div_fts) > 1):
						final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PolylineOnSphere)
						div_left_features,reconstructed_div_left_lines = zip(*final_reconstructed_left_fts)
						reconstructed_div_left_points = []
						for left_line in reconstructed_div_left_lines:
							list_of_lat_lon_tuples = left_line.to_lat_lon_list()
							for lat_lon_tuple in list_of_lat_lon_tuples:
								reconstructed_div_left_points.append(pygplates.PointOnSphere(lat_lon_tuple))
						#print(reconstructed_div_left_points)
						#print(reconstructed_MOR_points)
						left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_left_points, reconstructed_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
						oceanic_crust_features.add(left_oceanic_crust_feats)
					if (len(reconstructed_right_div_fts) > 1):
						final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PolylineOnSphere)
						div_right_features,reconstructed_div_right_lines = zip(*final_reconstructed_right_fts)
						reconstructed_div_right_points = []
						for right_line in reconstructed_div_right_lines:
							list_of_lat_lon_tuples = right_line.to_lat_lon_list()
							for lat_lon_tuple in list_of_lat_lon_tuples:
								reconstructed_div_right_points.append(pygplates.PointOnSphere(lat_lon_tuple))
						right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_right_points, reconstructed_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
						oceanic_crust_features.add(right_oceanic_crust_feats)
				elif (current_rift_age < start_div):
					reconstructed_left_MOR_features[:] = []
					reconstructed_right_MOR_features[:] = []
					for isochron_point_ft in list_of_wanted_left_isochron_point_features:
						begin_isochron_age,_ = isochron_point_ft.get_valid_time()
						if ((begin_isochron_age == (current_rift_age + age_interval_for_isochron_fts)) and isochron_point_ft.is_valid_at_time(current_rift_age)):
							list_of_ordered_left_div_margin_fts.append(isochron_point_ft.clone())
					for isochron_point_ft in list_of_wanted_right_isochron_point_features:
						begin_isochron_age,_ = isochron_point_ft.get_valid_time()
						if ((begin_isochron_age == (current_rift_age + age_interval_for_isochron_fts)) and isochron_point_ft.is_valid_at_time(current_rift_age)):
							list_of_ordered_right_div_margin_fts.append(isochron_point_ft.clone())
					#list_of_wanted_and_valid_rift_point_features_for_left = [valid_rift_point_ft for valid_rift_point_ft in list_of_wanted_left_isochron_point_features if valid_rift_point_ft.is_valid_at_time(current_rift_age)]
					#list_of_wanted_and_valid_rift_point_features_for_right = [valid_rift_point_ft for valid_rift_point_ft in list_of_wanted_right_isochron_point_features if valid_rift_point_ft.is_valid_at_time(current_rift_age)]
					for valid_rift_point_ft in list_of_wanted_rift_point_features:
						if (valid_rift_point_ft.is_valid_at_time(current_rift_age)):
							list_of_wanted_and_valid_rift_point_features.append(valid_rift_point_ft)
					#if (len(list_of_wanted_and_valid_rift_point_features_for_left) > 1 and len(list_of_wanted_and_valid_rift_point_features_for_right) > 1):
					if (len(list_of_wanted_and_valid_rift_point_features) > 1):
						if (reference is not None):
							pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_left_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							#pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_right_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							if (len(list_of_ordered_left_div_margin_fts) > 1):
								pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							if (len(list_of_ordered_right_div_margin_fts) > 1):
								pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_left_MOR_features,current_rift_age,group_with_feature = True)
							#pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_right_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							if (len(list_of_ordered_left_div_margin_fts) > 1):
								pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age, group_with_feature = True)
							if (len(list_of_ordered_right_div_margin_fts) > 1):
								pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age, group_with_feature = True)
						final_reconstructed_left_MOR_fts = find_final_reconstructed_geometries(reconstructed_left_MOR_features,pygplates.PointOnSphere)
						reconstructed_right_MOR_features = reconstructed_left_MOR_features
						final_reconstructed_right_MOR_fts = find_final_reconstructed_geometries(reconstructed_right_MOR_features,pygplates.PointOnSphere)
						left_MOR_features, temp_reconstructed_left_MOR_points = zip(*final_reconstructed_left_MOR_fts)
						reconstructed_left_MOR_points = list(temp_reconstructed_left_MOR_points)
						right_MOR_features, temp_reconstructed_right_MOR_points = zip(*final_reconstructed_right_MOR_fts)
						reconstructed_right_MOR_points = list(temp_reconstructed_right_MOR_points)
						if (len(reconstructed_left_div_fts) > 1):
							final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts, pygplates.PointOnSphere)
							div_left_features,temp_reconstructed_div_left_points = zip(*final_reconstructed_left_fts)
							reconstructed_div_left_points = list(temp_reconstructed_div_left_points)
							left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_left_points, reconstructed_left_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
							oceanic_crust_features.add(left_oceanic_crust_feats)
						if (len(reconstructed_right_div_fts) > 1):
							final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts, pygplates.PointOnSphere)
							div_right_features,temp_reconstructed_div_right_points = zip(*final_reconstructed_right_fts)
							reconstructed_div_right_points = list(temp_reconstructed_div_right_points)
							right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, 0.00, reconstructed_div_right_points, reconstructed_right_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
							oceanic_crust_features.add(right_oceanic_crust_feats)
				current_rift_age = current_rift_age - age_interval_for_isochron_fts
	oceanic_crust_features.write('oceanic_crust_from_rift_and_isochron_point_features_with_max_star_div_age_'+str(maximum_reconstruction_time)+'_min_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def create_topological_rift_zones(modified_rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, modelname, yearmonthday):
	topological_rift_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_lrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'lrepgduid'].unique()
		array_of_rrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'rrepgduid'].unique()
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		df_of_rift_order_and_lpolylid_rpolylid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),['order','lpolylid','rpolylid']]
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# start_div = -1.00
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		#NEW
		start_div = sorted_array_of_start_div[-1]
		list_of_wanted_rift_point_features = []
		sorted_array_of_order_for_rift_points = np.sort(array_of_order_for_rift_points)
		desc_sorted_array_of_order_for_rift_points = np.flip(sorted_array_of_order_for_rift_points)
		already_included = []
		end_age_of_isochron_feats = -1.00
		for order in desc_sorted_array_of_order_for_rift_points:
			name_of_rift_point_ft = rift_name+'_'+str(order)
			found_point_ft = None
			for rift_point_ft in modified_rift_point_features:
				if (rift_point_ft.get_name() == name_of_rift_point_ft):
					found_point_ft = rift_point_ft
					_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
					if (end_age_of_isochron_feats == -1.00):
						end_age_of_isochron_feats = temp_rift_pt_end_age
					elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
						end_age_of_isochron_feats = temp_rift_pt_end_age
					break
			if (end_age_of_isochron_feats < 0.00):
				end_age_of_isochron_feats = 0.00
			if (found_point_ft is not None):
				list_of_wanted_rift_point_features.append(found_point_ft)
		if (len(list_of_wanted_rift_point_features) > 1):
			#clone list of wanted rift point features
			list_of_clones = []
			for each_original_pt_ft in list_of_wanted_rift_point_features:
				list_of_clones.append(each_original_pt_ft.clone())
			topological_pt_sections = create_topological_rift_point_sections(list_of_clones)
			if (len(topological_pt_sections) > 1):
				topological_ft = create_topological_isochron_line_feature(topological_pt_sections)
				if (topological_ft is not None):
					topological_rift_features.add(topological_ft)
					for each_clone_pt_ft in list_of_clones:
						topological_rift_features.add(each_clone_pt_ft)
	topological_rift_features.write('topological_rift_features_'+str(maximum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml')

def create_topological_MOR_to_represent_each_div_margin(div_margin_features,modified_rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, modelname, yearmonthday):
	topological_MOR_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	dic_of_div_margin = {}
	for div_margin_ft in div_margin_features:
		div_margin_begin,div_margin_end = div_margin_ft.get_valid_time()
		polylid = div_margin_ft.get_name()
		if (polylid not in dic_of_div_margin and div_margin_ft.get_description() == 'divergent_margin'):
			dic_of_div_margin[polylid] = None
			#obtain rift records for polylid
			selected_rift_record = rift_history_df.loc[((rift_history_df['lpolylid'] == polylid) | (rift_history_df['rpolylid'] == polylid)),['rift_name','order']]
			gduid_of_line_ft = div_margin_ft.get_reconstruction_plate_id()
			temporary_list_to_connect_features = []
			if (len(selected_rift_record) > 1):
				# #sort the dataframe of rift point features based on the order 
				sorted_selected_rift_record = selected_rift_record.sort_values(by='order', ascending=False)
				max_order_rift_point = None
				for rift_name, order in sorted_selected_rift_record.itertuples(index = False, name = None):
					rift_pt_ft_name = rift_name+'_'+str(order)
					found_rift_point_ft = None
					for rift_pt_ft in modified_rift_point_features:
						if (rift_pt_ft.get_name() == rift_pt_ft_name):
							found_rift_point_ft = rift_pt_ft
							break
					if (found_rift_point_ft is not None):
						temporary_list_to_connect_features.append(found_rift_point_ft)
				if (len(temporary_list_to_connect_features) > 1):
					clones_of_original_temp_MOR_fts = []
					for original_ft in temporary_list_to_connect_features:
						clones_of_original_temp_MOR_fts.append(original_ft.clone())
					topological_pt_sections = create_topological_rift_point_sections(clones_of_original_temp_MOR_fts)
					if (len(topological_pt_sections) > 1):
						topological_ft = create_topological_isochron_line_feature(topological_pt_sections)
						topological_ft.set_name(polylid)
						if (topological_ft is not None):
							topological_MOR_features.add(topological_ft)
							for each_original_pt_ft in clones_of_original_temp_MOR_fts:
								topological_MOR_features.add(each_original_pt_ft)
							dic_of_div_margin[polylid] = topological_ft
	topological_MOR_features.write('topological_MOR_to_represent_each_div_margin_'+str(maximum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.gpml')

def create_static_MOR_to_represent_each_div_margin(rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday):
	#dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	oceanic_crust_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),['order','lpolylid','rpolylid','left_gdu','right_gdu']]
		sorted_rift_order_records = df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu.sort_values(by = 'order', ascending = False)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# start_div = -1.00
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		#NEW
		start_div = sorted_array_of_start_div[-1]
		
		#valid_div_margin_features = [div_margin_ft for div_margin_ft in div_margin_features if div_margin_ft.is_valid_at_time(start_div)]
		#list_of_wanted_left_isochron_point_features = []
		#list_of_wanted_right_isochron_point_features = []
		list_of_wanted_rift_point_features = []
		#find a collection of divergent margins associated with rifts
		#list_of_left_div_margin_feats = []
		#list_of_right_div_margin_feats = []
		#sorted_array_of_order_for_rift_points = np.sort(array_of_order_for_rift_points)
		#desc_sorted_array_of_order_for_rift_points = np.flip(sorted_array_of_order_for_rift_points)
		already_included = []
		end_age_of_isochron_feats = -1.00
		
		list_of_pairs_gdus = []
		prev_left_gdu,prev_right_gdu = -1,-1
		for order, lpolylid, rpolylid, left_gdu, right_gdu in sorted_rift_order_records.itertuples(index = False, name = None):
			print('order, lpolylid, rpolylid, left_gdu, right_gdu',order, lpolylid, rpolylid, left_gdu, right_gdu)
			name_of_rift_point_ft = rift_name+'_'+str(order)
			pairs_of_gdus = str(left_gdu)+'_'+str(right_gdu)
			if (pairs_of_gdus in list_of_pairs_gdus):
				found_point_ft = None
				for rift_point_ft in rift_point_features:
					if (rift_point_ft.get_name() == name_of_rift_point_ft):
						found_point_ft = rift_point_ft
						_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
						if (end_age_of_isochron_feats == -1.00):
							end_age_of_isochron_feats = temp_rift_pt_end_age
						elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
							end_age_of_isochron_feats = temp_rift_pt_end_age
						break
				if (end_age_of_isochron_feats < 0.00):
					end_age_of_isochron_feats = 0.00
				if (found_point_ft is not None):
					list_of_wanted_rift_point_features.append(found_point_ft)
			else:#find new pairs of gdu or this is the first time
				if (len(list_of_wanted_rift_point_features) > 1):
					selected_lrepgduid = prev_left_gdu
					selected_rrepgduid = prev_right_gdu
					#print('selected_rrepgduid',selected_rrepgduid,type(selected_rrepgduid))
					reconstructed_MOR_features = []
					list_of_wanted_and_valid_rift_point_features = []
					if (rift_name == 'R79694_79700'):
						print('start_div',start_div)
					current_rift_age = start_div
					while (current_rift_age >= end_age_of_isochron_feats):#create oceanic crust features with current data
						if (rift_name == 'R79694_79700'):
							print('current_rift_age',current_rift_age)
						reconstructed_MOR_features[:] = []
						list_of_wanted_and_valid_rift_point_features[:] = []
						if (current_rift_age == start_div):
							if (reference is not None):
								pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							else:
								pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,group_with_feature = True)
							if (len(reconstructed_MOR_features) > 1):
								final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
								MOR_features,temp_reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
								reconstructed_MOR_points = list(temp_reconstructed_MOR_points)
								static_MOR_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, pygplates.PolylineOnSphere(reconstructed_MOR_points), name = rift_name, valid_time = (current_rift_age,end_age_of_isochron_feats))
								static_MOR_feature.set_left_plate(left_gdu)
								static_MOR_feature.set_right_plate(right_gdu)
								static_MOR_feature.set_reconstruction_method('HalfStageRotationVersion2')
								if (reference is None):
									pygplates.reverse_reconstruct(static_MOR_feature,rotation_model,current_rift_age)
								else:
									pygplates.reverse_reconstruct(static_MOR_feature,rotation_model,current_rift_age,reference)
								oceanic_crust_features.add(static_MOR_feature)
						elif (current_rift_age < start_div):
							reconstructed_MOR_features[:] = []
							for valid_rift_point_ft in list_of_wanted_rift_point_features:
								if (valid_rift_point_ft.is_valid_at_time(current_rift_age)):
									list_of_wanted_and_valid_rift_point_features.append(valid_rift_point_ft)
							#if (len(list_of_wanted_and_valid_rift_point_features_for_left) > 1 and len(list_of_wanted_and_valid_rift_point_features_for_right) > 1):
							
							# if (rift_name == 'R79694_79700'):
								# print('len(list_of_wanted_and_valid_rift_point_features)',len(list_of_wanted_and_valid_rift_point_features))
								# print('len(list_of_wanted_left_isochron_point_features)',len(list_of_wanted_left_isochron_point_features))
								# print('len(list_of_ordered_left_div_margin_fts)',len(list_of_ordered_left_div_margin_fts))
								# print('len(list_of_wanted_right_isochron_point_features)',len(list_of_wanted_right_isochron_point_features))
								# print('len(list_of_ordered_right_div_margin_fts)',len(list_of_ordered_right_div_margin_fts))
							
							if (len(list_of_wanted_and_valid_rift_point_features) > 1):
								if (reference is not None):
									pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
									
								else:
									pygplates.reconstruct(list_of_wanted_and_valid_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,group_with_feature = True)
								if (len(reconstructed_MOR_features) > 1):
									final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
									MOR_features,temp_reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
									reconstructed_MOR_points = list(temp_reconstructed_MOR_points)
									static_MOR_feature = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_mid_ocean_ridge, pygplates.PolylineOnSphere(reconstructed_MOR_points), name = rift_name, valid_time = (current_rift_age,end_age_of_isochron_feats))
									static_MOR_feature.set_left_plate(left_gdu)
									static_MOR_feature.set_right_plate(right_gdu)
									static_MOR_feature.set_reconstruction_method('HalfStageRotationVersion2')
									if (reference is None):
										pygplates.reverse_reconstruct(static_MOR_feature,rotation_model,current_rift_age)
									else:
										pygplates.reverse_reconstruct(static_MOR_feature,rotation_model,current_rift_age,reference)
									oceanic_crust_features.add(static_MOR_feature)
						current_rift_age = current_rift_age - age_interval_for_isochron_fts
					#reset everything and start new collections of data
					list_of_wanted_rift_point_features[:] = []
					
					end_age_of_isochron_feats = -1.00

					for rift_point_ft in rift_point_features:
						if (rift_point_ft.get_name() == name_of_rift_point_ft):
							found_point_ft = rift_point_ft
							_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
							if (end_age_of_isochron_feats == -1.00):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							break
					if (end_age_of_isochron_feats < 0.00):
						end_age_of_isochron_feats = 0.00
					if (found_point_ft is not None):
						list_of_wanted_rift_point_features.append(found_point_ft)
				else:
					
					found_point_ft = None
					for rift_point_ft in rift_point_features:
						if (rift_point_ft.get_name() == name_of_rift_point_ft):
							found_point_ft = rift_point_ft
							_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
							if (end_age_of_isochron_feats == -1.00):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							break
					if (end_age_of_isochron_feats < 0.00):
						end_age_of_isochron_feats = 0.00
					if (found_point_ft is not None):
						list_of_wanted_rift_point_features.append(found_point_ft)
				
				prev_left_gdu,prev_right_gdu = left_gdu, right_gdu
				list_of_pairs_gdus.append(pairs_of_gdus)
				
	oceanic_crust_features.write('static_MOR_feats_with_max_star_div_age_'+str(maximum_reconstruction_time)+'_min_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def find_the_mid_of_two_PointOnSphere(p1,p2):
	"""
		p1 and p2: pygplates.PointOnSphere
		Return: a mid point between p1 and p2 in the datatype pygplates.PointOnSphere
		
		p1 and p2 can be expressed as (x,y,z) coordinates in pygplates. Thus, mid_point(x,y,z) = (x1+x2/2.0, y1+y2/2.0, z1+z2/2.0)
	"""
	x1,y1,z1 = p1.to_xyz()
	x2,y2,z2 = p2.to_xyz()
	mid_point_x = (x1+x2)/2.00
	mid_point_y = (y1+y2)/2.00
	mid_point_z = (z1+z2)/2.00
	
	vector = pygplates.Vector3D([mid_point_x, mid_point_y, mid_point_z])
	normalized_vector = vector.to_normalised()
	
	mid_point = pygplates.PointOnSphere(normalized_vector.to_xyz())
	return mid_point

def identify_left_gdu_and_right_gdu(normal_unit_vector, rift_point_location, mid_point_line_1, mid_point_line_2, plate_id_1, plate_id_2):
	#Method 1:
	opposite_unit_vector = normal_unit_vector*(-1.00)
	#use this normal_unit_vector, from the rift_point_location, move to left line ft and move to right line ft 
	rift_point_location_x,rift_point_location_y,rift_point_location_z = rift_point_location.to_xyz()
	mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z = mid_point_line_1.to_xyz()
	mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z = mid_point_line_2.to_xyz()
	
	left = None
	right = None
	
	#identify left and right
	vector_to_line_1 = pygplates.Vector3D([(mid_point_line_1_x-rift_point_location_x),(mid_point_line_1_y-rift_point_location_y),(mid_point_line_1_z-rift_point_location_z)])
	if (vector_to_line_1.is_zero_magnitude()):
		return (left,right)
	normalized_vector_to_line_1 = vector_to_line_1.to_normalised()
	vector_to_line_2 = pygplates.Vector3D([(mid_point_line_2_x-rift_point_location_x),(mid_point_line_2_y-rift_point_location_y),(mid_point_line_2_z-rift_point_location_z)])
	normalized_vector_to_line_2 = vector_to_line_2.to_normalised() 
	if (vector_to_line_2.is_zero_magnitude()):
		return (left,right)
	if (pygplates.Vector3D.dot(normalized_vector_to_line_1,normal_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,opposite_unit_vector) > 0):
		left = plate_id_1
		right = plate_id_2
	elif (pygplates.Vector3D.dot(normalized_vector_to_line_1,opposite_unit_vector) > 0 and pygplates.Vector3D.dot(normalized_vector_to_line_2,normal_unit_vector) > 0):
		left = plate_id_2
		right = plate_id_1
	
	if (left is not None and right is not None):
		return (left,right)

	magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,mid_point_line_1_x,mid_point_line_1_y,mid_point_line_1_z)
	if (azimuth <= math.pi or azimuth == 2*math.pi):
		right = plate_id_1
	elif (azimuth > math.pi):
		left = plate_id_1
	magnitude, azimuth, inclination = pygplates.LocalCartesian.convert_from_geocentric_to_magnitude_azimuth_inclination(rift_point_location,mid_point_line_2_x,mid_point_line_2_y,mid_point_line_2_z)
	if (azimuth <= math.pi or azimuth == 2*math.pi):
		right = plate_id_2
	elif (azimuth > math.pi):
		left = plate_id_2
	return (left,right)


def find_total_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,reconstruction_time,reference_frame):
	"""
	Total reconstruction is a reconstruction relative to the present (in time) and relative to any reference frame (spin axis or mantle or anything else)
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, moving_plate_id, 0.00, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		print("Warning in find_rift_segment_and_transform_faults")
		print("Warning finite_rotation_1 is identity")
		print(moving_plate_id, fixed_plate_id, reference_frame)
		print("reconstruction_time")
		print(reconstruction_time)
		print('moving_plate_id')
		print(moving_plate_id)
		print('fixed_plate_id')
		print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		print("Euler_pole,angle_rads")
		print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		print("lat,lon,angle_degrees")
		print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_stage_relative_reconstruction_rotation_(rotation_model,moving_plate_id,fixed_plate_id,from_time,to_time,reference_frame):
	"""
	Relative stage reconstruction is a reconstruction from any from_time to any to_time between any two GDUIDS
	rotation_model: A pygplates.RotationModel
	moving_plate_id, fixed_plate_id: an int of a plate id or a gdu id - depends on the model
	reconstruction_time: a float - from present to reconstruction_time
	reference_frame: if reference_frame is None, pygplates will use 0 as the reference_frame
	"""
	finite_rotation_1 = None
	if (reference_frame is None):
		#finite_rotation_1 = rotation_model.get_rotation(reconstruction_time, plat_id_or_gdu_id, 0.00, anchor_plate_id = 0)
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = 0)
	else:
		finite_rotation_1 = rotation_model.get_rotation(to_time, moving_plate_id, from_time, fixed_plate_id,anchor_plate_id = reference_frame)
	if (finite_rotation_1.represents_identity_rotation() == False):
		# print('moving_plate_id')
		# print(moving_plate_id)
		# print('fixed_plate_id')
		# print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		# print("Euler_pole,angle_rads")
		# print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		# print("lat,lon,angle_degrees")
		# print(lat,lon,angle_degrees)
		return finite_rotation_1
	else:
		#print("Warning in find_rift_segment_and_transform_faults")
		#print("Warning finite_rotation_1 is identity")
		#print(moving_plate_id, fixed_plate_id, reference_frame)
		# print("from_time,to_time")
		# print(from_time,to_time)
		# print('moving_plate_id')
		# print(moving_plate_id)
		# print('fixed_plate_id')
		# print(fixed_plate_id)
		Euler_pole,angle_rads = finite_rotation_1.get_euler_pole_and_angle()
		# print("Euler_pole,angle_rads")
		# print(Euler_pole,angle_rads)
		lat,lon,angle_degrees = finite_rotation_1.get_lat_lon_euler_pole_and_angle_degrees()
		# print("lat,lon,angle_degrees")
		# print(lat,lon,angle_degrees)
		return finite_rotation_1

def find_subducted_and_remained_oceanic_geometries(continental_sgdu_polygon, oceanic_polygon):
	temp_returned_remained_polygon = []
	temp_returned_remained_geom = []
	temp_returned_subducted_geom = []
	geom_inside_supergdu = []
	geom_outside_supergdu = []
	geom_inside_ocean = []
	geom_outside_ocean = []
	continental_sgdu_polygon.partition(oceanic_polygon, partitioned_geometries_inside = geom_inside_supergdu, partitioned_geometries_outside = geom_outside_supergdu)
	oceanic_polygon.partition(continental_sgdu_polygon, partitioned_geometries_inside = geom_inside_ocean, partitioned_geometries_outside = geom_outside_ocean)
	
	if (len(geom_inside_supergdu) > 0 and len(geom_inside_ocean) > 0):
		#print('number of geom_inside_supergdu', len(geom_inside_supergdu))
		#print('number of geom_inside_ocean', len(geom_inside_ocean))
		#print('number of geom_outside_supergdu', len(geom_outside_supergdu))
		for each_geom_outside_sgdu in geom_outside_supergdu:
			end_pt_of_geom_outside_sgdu = get_last_point_of_line(each_geom_outside_sgdu)
			start_pt_of_geom_outside_sgdu = get_first_point_of_line(each_geom_outside_sgdu)
			found_remained_polygon = False
			for each_geom_inside_ocn in geom_inside_ocean:
				if (pygplates.GeometryOnSphere.distance(each_geom_outside_sgdu,each_geom_inside_ocn) == 0.00):
					end_pt_of_geom_inside_ocn = get_last_point_of_line(each_geom_inside_ocn)
					start_pt_of_geom_inside_ocn = get_first_point_of_line(each_geom_inside_ocn)
					if (pygplates.GeometryOnSphere.distance(end_pt_of_geom_outside_sgdu, start_pt_of_geom_inside_ocn) == 0.00):
						list_of_pts_for_polygon = each_geom_outside_sgdu.to_lat_lon_list()+each_geom_inside_ocn.to_lat_lon_list()
						new_remained_ocn_polyon = pygplates.PolygonOnSphere(list_of_pts_for_polygon)
						temp_returned_remained_polygon.append(new_remained_ocn_polyon)
						found_remained_polygon = True
					elif (pygplates.GeometryOnSphere.distance(end_pt_of_geom_outside_sgdu, end_pt_of_geom_inside_ocn) == 0.00):
						list_of_point_inside = each_geom_inside_ocn.to_lat_lon_list()
						list_of_point_inside.reverse()
						list_of_pts_for_polygon = each_geom_outside_sgdu.to_lat_lon_list()+list_of_point_inside
						new_remained_ocn_polyon = pygplates.PolygonOnSphere(list_of_pts_for_polygon)
						temp_returned_remained_polygon.append(new_remained_ocn_polyon)
						found_remained_polygon = True
					break
			if (found_remained_polygon == False):
				temp_returned_remained_geom.append(each_geom_outside_sgdu)
		for each_geom_inside_sgdu in geom_inside_supergdu:
			end_pt_of_geom_inside_sgdu = get_last_point_of_line(each_geom_inside_sgdu)
			start_pt_of_geom_inside_sgdu = get_first_point_of_line(each_geom_inside_sgdu)
			found_subducted_polygon = False
			for each_geom_inside_ocn in geom_inside_ocean:
				if (pygplates.GeometryOnSphere.distance(each_geom_inside_sgdu,each_geom_inside_ocn) == 0.00):
					end_pt_of_geom_inside_ocn = get_last_point_of_line(each_geom_inside_ocn)
					start_pt_of_geom_inside_ocn = get_first_point_of_line(each_geom_inside_ocn)
					if (pygplates.GeometryOnSphere.distance(end_pt_of_geom_inside_sgdu, start_pt_of_geom_inside_ocn) == 0.00):
						list_of_pts_for_polygon = each_geom_inside_sgdu.to_lat_lon_list()+each_geom_inside_ocn.to_lat_lon_list()
						new_subducted_ocn_polyon = pygplates.PolygonOnSphere(list_of_pts_for_polygon)
						temp_returned_subducted_geom.append(new_subducted_ocn_polyon)
						found_subducted_polygon = True
					elif (pygplates.GeometryOnSphere.distance(end_pt_of_geom_inside_sgdu, end_pt_of_geom_inside_ocn) == 0.00):
						list_of_point_inside = each_geom_inside_ocn.to_lat_lon_list()
						list_of_point_inside.reverse()
						list_of_pts_for_polygon = each_geom_inside_sgdu.to_lat_lon_list()+list_of_point_inside
						new_subducted_ocn_polyon = pygplates.PolygonOnSphere(list_of_pts_for_polygon)
						temp_returned_subducted_geom.append(new_subducted_ocn_polyon)
						found_subducted_polygon = True
					break
			if (found_subducted_polygon == False):
				temp_returned_subducted_geom.append(each_geom_inside_sgdu)
	#print('finished find_subducted_and_remained_oceanic_geometries')
	return (temp_returned_remained_polygon, temp_returned_remained_geom, temp_returned_subducted_geom)

def find_oceanic_boundaries(oceanic_crust_features, rotation_model, reference, maximum_reconstruction_time, time_interval, modelname, yearmonthday):
	output_remained_ocean_polygon_feats = pygplates.FeatureCollection()
	output_remained_ocean_feats = pygplates.FeatureCollection()
	output_subducted_ocean_feats = pygplates.FeatureCollection()
	reconstruction_time = maximum_reconstruction_time
	reconstructed_oceanic_features = []
	reconstructed_prev_oceanic_features = []
	while (reconstruction_time >= 0.00):
		print('reconstruction_time', reconstruction_time)
		reconstructed_oceanic_features[:] = []
		reconstructed_prev_oceanic_features[:] = []
		valid_oceanic_crust_features = [oceanic_crust_feat for oceanic_crust_feat in oceanic_crust_features if oceanic_crust_feat.is_valid_at_time(reconstruction_time)]
		#valid_prev_oceanic_crust_features = [oceanic_crust_feat for oceanic_crust_feat in oceanic_crust_features if oceanic_crust_feat.is_valid_at_time(reconstruction_time + time_interval)]
		print('number of features in valid_oceanic_crust_features', len(valid_oceanic_crust_features))
		if (reference is not None):
			pygplates.reconstruct(valid_oceanic_crust_features,rotation_model,reconstructed_oceanic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			#pygplates.reconstruct(valid_prev_oceanic_crust_features,rotation_model,reconstructed_prev_oceanic_features,reconstruction_time + time_interval,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_oceanic_crust_features,rotation_model,reconstructed_oceanic_features,reconstruction_time,group_with_feature = True)
			#pygplates.reconstruct(valid_prev_oceanic_crust_features,rotation_model,reconstructed_prev_oceanic_features,reconstruction_time + time_interval,anchor_plate_id = reference, group_with_feature = True)
		final_reconstructed_oceanic_crust_features = find_final_reconstructed_geometries(reconstructed_oceanic_features, pygplates.PolygonOnSphere)
		final_reconstructed_prev_oceanic_crust_features = find_final_reconstructed_geometries(reconstructed_prev_oceanic_features, pygplates.PolygonOnSphere)
		for oceanic_crust_ft, oceanic_crust in final_reconstructed_oceanic_crust_features:
			inside_supergdu = []
			outside_supergdu = []
			is_valid_oceanic_ft = True
			for other_oceanic_crust_ft, other_oceanic_crust in final_reconstructed_oceanic_crust_features:
				reconstructed_prev_oceanic_features[:] = []
				if (other_oceanic_crust_ft.get_reconstruction_plate_id() == oceanic_crust_ft.get_reconstruction_plate_id() or other_oceanic_crust_ft.get_name() == oceanic_crust_ft.get_name()):
					continue
				else:
					moving_plate_id = oceanic_crust_ft.get_reconstruction_plate_id()
					fixed_plate_id = other_oceanic_crust_ft.get_reconstruction_plate_id()
					from_time = reconstruction_time + time_interval
					to_time = reconstruction_time
					rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, from_time, to_time, reference)
					if (rel_stage_rot is None):
						continue
					else:
						if (rel_stage_rot.represents_identity_rotation()):
							continue
				older_oceanic_crust_ft, older_oceanic_crust = None, None 
				ynger_oceanic_crust_ft, ynger_oceanic_crust = None, None 
				begin_age_oceanic_ft,end_age_oceanic_ft = oceanic_crust_ft.get_valid_time()
				begin_age_other_oceanic_ft,end_age_other_oceanic_ft = other_oceanic_crust_ft.get_valid_time()
				
				if (begin_age_oceanic_ft > begin_age_other_oceanic_ft):
					older_oceanic_crust_ft, older_oceanic_crust = oceanic_crust_ft, oceanic_crust
					ynger_oceanic_crust_ft, ynger_oceanic_crust = other_oceanic_crust_ft, other_oceanic_crust
				else:
					older_oceanic_crust_ft, older_oceanic_crust = other_oceanic_crust_ft, other_oceanic_crust
					ynger_oceanic_crust_ft, ynger_oceanic_crust = oceanic_crust_ft, oceanic_crust
				
				if (reference is not None):
					pygplates.reconstruct([older_oceanic_crust_ft,ynger_oceanic_crust_ft], rotation_model, reconstructed_prev_oceanic_features, reconstruction_time + time_interval, anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct([older_oceanic_crust_ft,ynger_oceanic_crust_ft], rotation_model, reconstructed_prev_oceanic_features, reconstruction_time + time_interval, group_with_feature = True)
				final_prev_reconstructed_line_features = find_final_reconstructed_geometries(reconstructed_prev_oceanic_features,pygplates.PolygonOnSphere)
				prev_reconstr_older_ft,prev_reconstr_older = final_prev_reconstructed_line_features[0]
				prev_reconstr_ynger_ft,prev_reconstr_ynger = final_prev_reconstructed_line_features[1]
				
				reconstructed_point_A_at_from_time = prev_reconstr_older.get_interior_centroid()
				reconstructed_point_B_at_from_time = prev_reconstr_ynger.get_interior_centroid()
				reconstructed_point_A_at_to_time = older_oceanic_crust.get_interior_centroid()
				reconstructed_point_B_at_to_time = ynger_oceanic_crust.get_interior_centroid()
				#result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_pos_and_angular_vel_vec(reconstructed_point_A_at_from_time, reconstructed_point_A_at_to_time, reconstructed_point_B_at_from_time, reconstructed_point_B_at_to_time, reconstruction_time, reconstruction_time-time_interval)
				result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_pos_and_angular_vel_vec(reconstructed_point_A_at_from_time, reconstructed_point_A_at_to_time, reconstructed_point_B_at_from_time, reconstructed_point_B_at_to_time, reconstruction_time+time_interval, reconstruction_time)
				
				
				
				
				if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
					supergdu_polygon.partition(oceanic_crust, partitioned_geometries_inside = inside_supergdu, partitioned_geometries_outside = outside_supergdu)
					returned_remained_geom = []
					returned_subducted_geom = []
					returned_remained_polygon = []
					if (len(inside_supergdu) > 0):
						returned_remained_polygon, returned_remained_geom, returned_subducted_geom = find_subducted_and_remained_oceanic_geometries(supergdu_polygon, oceanic_crust)
						is_valid_oceanic_ft = False
						#for subducted_geom in inside_supergdu:
						for subducted_geom in returned_subducted_geom:
							_,end_age_of_sgdu = supergdu_ft.get_valid_time()
							#create output subducted feature 
							subducted_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, subducted_geom, valid_time = (reconstruction_time,end_age_of_sgdu))
							subducted_ocean_feat.set_reconstruction_plate_id(supergdu_ft.get_reconstruction_plate_id())
							subducted_ocean_feat.set_name(oceanic_crust_ft.get_name())
							if (reference is not None):
								pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time, reference)
							else:
								pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time)
							output_subducted_ocean_feats.add(subducted_ocean_feat)
					if (len(outside_supergdu) > 0 and len(returned_remained_polygon) > 0):
						is_valid_oceanic_ft = False
						#for remained_geom in outside_supergdu:
						for remained_geom in returned_remained_polygon:
							ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
							#create output subducted feature 
							remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (reconstruction_time, ocean_end_age))
							remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
							remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
							if (reference is not None):
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
							else:
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
							output_remained_ocean_polygon_feats.add(remained_ocean_feat)
					if (len(returned_remained_geom) > 0):
						for remained_geom in returned_remained_geom:
							ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
							#create output subducted feature 
							remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (reconstruction_time, ocean_end_age))
							remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
							remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
							if (reference is not None):
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
							else:
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
							output_remained_ocean_feats.add(remained_ocean_feat)
				if (is_valid_oceanic_ft == False):
					# if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
						# ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
						# #find the oceanic crust feature that we want
						# for initial_oceanic_crust_ft in valid_oceanic_crust_features:
							# if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
								# initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time)
								# break
					ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
					#find the oceanic crust feature that we want
					for initial_oceanic_crust_ft in valid_oceanic_crust_features:
						if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
							initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time)
							break
					
					break
			
			list_of_different_oceanic_crust_feats = []
			#find the oceanic subduction -- two different oceanic gdu features, previously were apart and now touch each other
			#the younger oceanic feature remains, the older oceanic feature is subducted
			#find the MOR --- two different oceanic gdu features, previously touched each other and now move apart
			#the geometry that two oceanic gdu features share is the new oceanic crust feature
def modified_end_age_of_temporary_oceanic_crust_polygon_features(oceanic_crust_features, supergdu_features, rotation_model, reference, maximum_reconstruction_time, time_interval, modelname, yearmonthday):
	output_remained_ocean_polygon_feats = pygplates.FeatureCollection()
	output_remained_ocean_feats = pygplates.FeatureCollection()
	output_subducted_ocean_feats = pygplates.FeatureCollection()
	reconstruction_time = maximum_reconstruction_time
	reconstructed_oceanic_features = []
	reconstructed_supergdu_features = []
	valid_oceanic_crust_features = []
	while (reconstruction_time >= 0.00):
		print('reconstruction_time', reconstruction_time)
		if (len(output_remained_ocean_polygon_feats) > 0):
			for remained_ft in output_remained_ocean_polygon_feats:
				if (remained_ft.is_valid_at_time(reconstruction_time)):
					current_begin_age_remain, current_end_age_remain = remained_ft.get_valid_time()
					if (current_begin_age_remain > reconstruction_time):
						#only take polygon_ft.....
						oceanic_crust_features.add(remained_ft.clone())
			output_remained_ocean_polygon_feats = None
			output_remained_ocean_polygon_feats = pygplates.FeatureCollection()#reset a new collection
		reconstructed_oceanic_features[:] = []
		reconstructed_supergdu_features[:] = []
		valid_oceanic_crust_features[:] = []
		valid_supergdu_features = [sgdu_feat for sgdu_feat in supergdu_features if sgdu_feat.is_valid_at_time(reconstruction_time)]
		for oceanic_crust_feat in oceanic_crust_features:
			if (oceanic_crust_feat.is_valid_at_time(reconstruction_time)):
				begin_oceanic_age, end_oceanic_age = oceanic_crust_feat.get_valid_time()
				if (begin_oceanic_age > reconstruction_time):
					valid_oceanic_crust_features.append(oceanic_crust_feat)
		print('number of features in valid_oceanic_crust_features', len(valid_oceanic_crust_features))
		if (reference is not None):
			pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_supergdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(valid_oceanic_crust_features,rotation_model,reconstructed_oceanic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_supergdu_features,reconstruction_time,group_with_feature = True)
			pygplates.reconstruct(valid_oceanic_crust_features,rotation_model,reconstructed_oceanic_features,reconstruction_time,group_with_feature = True)
		final_reconstructed_supergdu_features = find_final_reconstructed_geometries(reconstructed_supergdu_features, pygplates.PolygonOnSphere)
		final_reconstructed_oceanic_crust_features = find_final_reconstructed_geometries(reconstructed_oceanic_features, pygplates.PolygonOnSphere)
		for oceanic_crust_ft, oceanic_crust in final_reconstructed_oceanic_crust_features:
			inside_supergdu = []
			outside_supergdu = []
			is_valid_oceanic_ft = True
			parent_sgdu_feats = []
			for supergdu_ft, supergdu_polygon in final_reconstructed_supergdu_features:
				if (supergdu_ft.get_reconstruction_plate_id() == oceanic_crust_ft.get_reconstruction_plate_id()):
					parent_sgdu_feats.append((supergdu_ft, supergdu_polygon))
				else:
					moving_plate_id = oceanic_crust_ft.get_reconstruction_plate_id()
					fixed_plate_id = supergdu_ft.get_reconstruction_plate_id()
					from_time = reconstruction_time + time_interval
					to_time = reconstruction_time
					rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, from_time, to_time, reference)
					if (rel_stage_rot is None):
						parent_sgdu_feats.append((supergdu_ft, supergdu_polygon))
					else:
						if (rel_stage_rot.represents_identity_rotation()):
							parent_sgdu_feats.append((supergdu_ft, supergdu_polygon))
			for supergdu_ft, supergdu_polygon in parent_sgdu_feats:
				if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
					supergdu_polygon.partition(oceanic_crust, partitioned_geometries_inside = inside_supergdu, partitioned_geometries_outside = outside_supergdu)
					returned_remained_geom = []
					returned_subducted_geom = []
					returned_remained_polygon = []
					if (len(inside_supergdu) > 0):
						is_valid_oceanic_ft = False
						if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
							returned_remained_polygon, returned_remained_geom, returned_subducted_geom = find_subducted_and_remained_oceanic_geometries(supergdu_polygon, oceanic_crust)
							#for subducted_geom in inside_supergdu:
							for subducted_geom in returned_subducted_geom:
								_,end_age_of_sgdu = supergdu_ft.get_valid_time()
								#create output subducted feature 
								subducted_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, subducted_geom, valid_time = (reconstruction_time,end_age_of_sgdu))
								subducted_ocean_feat.set_reconstruction_plate_id(supergdu_ft.get_reconstruction_plate_id())
								subducted_ocean_feat.set_name(oceanic_crust_ft.get_name())
								if (reference is not None):
									pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time, reference)
								else:
									pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time)
								output_subducted_ocean_feats.add(subducted_ocean_feat)
						elif (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
							for subducted_geom in inside_supergdu:
								_,end_age_of_sgdu = supergdu_ft.get_valid_time()
								#create output subducted feature 
								subducted_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, subducted_geom, valid_time = (reconstruction_time,end_age_of_sgdu))
								subducted_ocean_feat.set_reconstruction_plate_id(supergdu_ft.get_reconstruction_plate_id())
								subducted_ocean_feat.set_name(oceanic_crust_ft.get_name())
								if (reference is not None):
									pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time, reference)
								else:
									pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time)
								output_subducted_ocean_feats.add(subducted_ocean_feat)
					if (len(outside_supergdu) > 0 and len(returned_remained_polygon) > 0):
						#for remained_geom in outside_supergdu:
						for remained_geom in returned_remained_polygon:
							ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
							#create output subducted feature 
							remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (reconstruction_time, ocean_end_age))
							remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
							remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
							if (reference is not None):
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
							else:
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
							output_remained_ocean_polygon_feats.add(remained_ocean_feat)
					if (len(returned_remained_geom) > 0):
						for remained_geom in returned_remained_geom:
							ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
							#create output subducted feature 
							remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (reconstruction_time, ocean_end_age))
							remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
							remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
							if (reference is not None):
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
							else:
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
							output_remained_ocean_feats.add(remained_ocean_feat)
				if (is_valid_oceanic_ft == False):
					# if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
						# ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
						# #find the oceanic crust feature that we want
						# for initial_oceanic_crust_ft in valid_oceanic_crust_features:
							# if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
								# initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time)
								# break
					ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
					#find the oceanic crust feature that we want
					for initial_oceanic_crust_ft in valid_oceanic_crust_features:
						if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
							initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time+0.100)
							break
					break
			if (is_valid_oceanic_ft == False):
				continue #process new oceanic crust feat
			for supergdu_ft, supergdu_polygon in final_reconstructed_supergdu_features:
				if (supergdu_ft.get_reconstruction_plate_id() == oceanic_crust_ft.get_reconstruction_plate_id()):
					continue
				else:
					moving_plate_id = oceanic_crust_ft.get_reconstruction_plate_id()
					fixed_plate_id = supergdu_ft.get_reconstruction_plate_id()
					from_time = reconstruction_time + time_interval
					to_time = reconstruction_time
					rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, from_time, to_time, reference)
					if (rel_stage_rot is None):
						continue
					else:
						if (rel_stage_rot.represents_identity_rotation()):
							continue
				if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
					supergdu_polygon.partition(oceanic_crust, partitioned_geometries_inside = inside_supergdu, partitioned_geometries_outside = outside_supergdu)
					returned_remained_geom = []
					returned_subducted_geom = []
					returned_remained_polygon = []
					if (len(inside_supergdu) > 0):
						is_valid_oceanic_ft = False
						if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
							returned_remained_polygon, returned_remained_geom, returned_subducted_geom = find_subducted_and_remained_oceanic_geometries(supergdu_polygon, oceanic_crust)
							#for subducted_geom in inside_supergdu:
							for subducted_geom in returned_subducted_geom:
								_,end_age_of_sgdu = supergdu_ft.get_valid_time()
								#create output subducted feature 
								subducted_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, subducted_geom, valid_time = (reconstruction_time,end_age_of_sgdu))
								subducted_ocean_feat.set_reconstruction_plate_id(supergdu_ft.get_reconstruction_plate_id())
								subducted_ocean_feat.set_name(oceanic_crust_ft.get_name())
								if (reference is not None):
									pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time, reference)
								else:
									pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time)
								output_subducted_ocean_feats.add(subducted_ocean_feat)
						elif (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
							for subducted_geom in inside_supergdu:
								_,end_age_of_sgdu = supergdu_ft.get_valid_time()
								#create output subducted feature 
								subducted_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, subducted_geom, valid_time = (reconstruction_time,end_age_of_sgdu))
								subducted_ocean_feat.set_reconstruction_plate_id(supergdu_ft.get_reconstruction_plate_id())
								subducted_ocean_feat.set_name(oceanic_crust_ft.get_name())
								if (reference is not None):
									pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time, reference)
								else:
									pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time)
								output_subducted_ocean_feats.add(subducted_ocean_feat)
					if (len(outside_supergdu) > 0 and len(returned_remained_polygon) > 0):
						is_valid_oceanic_ft = False
						#for remained_geom in outside_supergdu:
						for remained_geom in returned_remained_polygon:
							ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
							#create output subducted feature 
							remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (reconstruction_time, ocean_end_age))
							remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
							remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
							if (reference is not None):
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
							else:
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
							output_remained_ocean_polygon_feats.add(remained_ocean_feat)
					if (len(returned_remained_geom) > 0):
						for remained_geom in returned_remained_geom:
							ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
							#create output subducted feature 
							remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (reconstruction_time, ocean_end_age))
							remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
							remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
							if (reference is not None):
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
							else:
								pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
							output_remained_ocean_feats.add(remained_ocean_feat)
				if (is_valid_oceanic_ft == False):
					# if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
						# ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
						# #find the oceanic crust feature that we want
						# for initial_oceanic_crust_ft in valid_oceanic_crust_features:
							# if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
								# initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time)
								# break
					ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
					#find the oceanic crust feature that we want
					for initial_oceanic_crust_ft in valid_oceanic_crust_features:
						if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
							initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time+0.100)
							break
					break
			
			list_of_different_oceanic_crust_feats = []
			#find the oceanic subduction -- two different oceanic gdu features, previously were apart and now touch each other
			#the younger oceanic feature remains, the older oceanic feature is subducted
			#find the MOR --- two different oceanic gdu features, previously touched each other and now move apart
			#the geometry that two oceanic gdu features share is the new oceanic crust feature
			
			
		if (len(output_remained_ocean_feats) > 0):
			print('number of features in output_remained_ocean_feats', len(output_remained_ocean_feats))
			remained_ocean_feat_to_be_examined = []
			remained_ocean_polygon_feat_to_be_examined = []
			reconstructed_remained_ocean_feat = []
			reconstructed_remained_ocean_polygon_feat = []
			new_collection_of_remained_feats = pygplates.FeatureCollection()
			for remained_ft in output_remained_ocean_feats:
				if (remained_ft.is_valid_at_time(reconstruction_time)):
					current_begin_age_remain, current_end_age_remain = remained_ft.get_valid_time()
					if (current_begin_age_remain > reconstruction_time):
						remained_ocean_feat_to_be_examined.append(remained_ft)
						if (current_end_age_remain > reconstruction_time):
							new_collection_of_remained_feats.add(remained_ft.clone())
			# for remained_ft in output_remained_ocean_polygon_feats:
				# if (remained_ft.is_valid_at_time(reconstruction_time)):
					# current_begin_age_remain, current_end_age_remain = remained_ft.get_valid_time()
					# if (current_begin_age_remain > reconstruction_time):
						# #only take polygon_ft.....
						# remained_ocean_polygon_feat_to_be_examined.append(remained_ft)
			if (len(remained_ocean_feat_to_be_examined) > 0):
				print('number of features in remained_ocean_feat_to_be_examined', len(remained_ocean_feat_to_be_examined))
				if (reference is not None):
					pygplates.reconstruct(remained_ocean_feat_to_be_examined,rotation_model,reconstructed_remained_ocean_feat,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(remained_ocean_feat_to_be_examined,rotation_model,reconstructed_remained_ocean_feat,reconstruction_time,group_with_feature = True)
				final_reconstructed_remained_features = find_final_reconstructed_geometries(reconstructed_remained_ocean_feat, pygplates.PolylineOnSphere)
				for oceanic_crust_ft, oceanic_crust in final_reconstructed_remained_features:
					inside_supergdu = []
					outside_supergdu = []
					is_valid_oceanic_ft = True
					for supergdu_ft, supergdu_polygon in final_reconstructed_supergdu_features:
						if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
							supergdu_polygon.partition(oceanic_crust, partitioned_geometries_inside = inside_supergdu, partitioned_geometries_outside = outside_supergdu)
							is_valid_oceanic_ft = False
							if (len(inside_supergdu) > 0):
								#_, returned_remained_geom, returned_subducted_geom = find_subducted_and_remained_oceanic_geometries(supergdu_polygon, oceanic_crust)
								for subducted_geom in inside_supergdu:
								#for subducted_geom in returned_subducted_geom:
									_,end_age_of_sgdu = supergdu_ft.get_valid_time()
									#create output subducted feature 
									subducted_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, subducted_geom, valid_time = (reconstruction_time,end_age_of_sgdu))
									subducted_ocean_feat.set_reconstruction_plate_id(supergdu_ft.get_reconstruction_plate_id())
									subducted_ocean_feat.set_name(oceanic_crust_ft.get_name())
									if (reference is not None):
										pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time, reference)
									else:
										pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time)
									output_subducted_ocean_feats.add(subducted_ocean_feat)
							if (len(outside_supergdu) > 0):
								for remained_geom in outside_supergdu:
									ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
									#create output subducted feature 
									remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (ocean_begin_age, ocean_end_age))
									remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
									remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
									if (reference is not None):
										pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
									else:
										pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
									output_remained_ocean_feats.add(remained_ocean_feat)
						if (is_valid_oceanic_ft == False):
							# if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
								# ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
								# #find the oceanic crust feature that we want
								# for initial_oceanic_crust_ft in remained_ocean_feat_to_be_examined:
									# if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
										# initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time)
										# break
							
							ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
							#find the oceanic crust feature that we want
							# for initial_oceanic_crust_ft in remained_ocean_feat_to_be_examined:
								# if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
									# initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time)
									# break
							modified_remained_ft = oceanic_crust_ft.clone()
							modified_remained_ft.set_valid_time(ocean_begin_age, reconstruction_time)
							new_collection_of_remained_feats.add(modified_remained_ft)
							break
					if (is_valid_oceanic_ft == True):
						new_collection_of_remained_feats.add(oceanic_crust_ft.clone())
				output_remained_ocean_feats = new_collection_of_remained_feats
			# if (len(remained_ocean_polygon_feat_to_be_examined) > 0):
				# print('number of features in remained_ocean_polygon_feat_to_be_examined', len(remained_ocean_polygon_feat_to_be_examined))
				# if (reference is not None):
					# pygplates.reconstruct(remained_ocean_polygon_feat_to_be_examined, rotation_model, reconstructed_remained_ocean_polygon_feat, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
				# else:
					# pygplates.reconstruct(remained_ocean_polygon_feat_to_be_examined, rotation_model, reconstructed_remained_ocean_polygon_feat, reconstruction_time, group_with_feature = True)
				# final_reconstructed_remained_features = find_final_reconstructed_geometries(reconstructed_remained_ocean_polygon_feat, pygplates.PolygonOnSphere)
				# for oceanic_crust_ft, oceanic_crust in final_reconstructed_remained_features:
					# inside_supergdu = []
					# outside_supergdu = []
					# is_valid_oceanic_ft = True
					# for supergdu_ft, supergdu_polygon in final_reconstructed_supergdu_features:
						# if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
							# supergdu_polygon.partition(oceanic_crust, partitioned_geometries_inside = inside_supergdu, partitioned_geometries_outside = outside_supergdu)
							# returned_remained_polygon = []
							# returned_remained_geom = []
							# returned_subducted_geom = []
							# is_valid_oceanic_ft = False
							# if (len(inside_supergdu) > 0):
								# returned_remained_polygon, returned_remained_geom, returned_subducted_geom = find_subducted_and_remained_oceanic_geometries(supergdu_polygon, oceanic_crust)
								# #for subducted_geom in inside_supergdu:
								# for subducted_geom in returned_subducted_geom:
									# _,end_age_of_sgdu = supergdu_ft.get_valid_time()
									# #create output subducted feature 
									# subducted_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, subducted_geom, valid_time = (reconstruction_time,end_age_of_sgdu))
									# subducted_ocean_feat.set_reconstruction_plate_id(supergdu_ft.get_reconstruction_plate_id())
									# subducted_ocean_feat.set_name(oceanic_crust_ft.get_name())
									# if (reference is not None):
										# pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time, reference)
									# else:
										# pygplates.reverse_reconstruct(subducted_ocean_feat, rotation_model, reconstruction_time)
									# output_subducted_ocean_feats.add(subducted_ocean_feat)
							# if (len(outside_supergdu) > 0 and len(returned_remained_geom) > 0):
								# for remained_geom in returned_remained_geom:
									# ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
									# #create output subducted feature 
									# remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (ocean_begin_age, ocean_end_age))
									# remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
									# remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
									# if (reference is not None):
										# pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
									# else:
										# pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
									# output_remained_ocean_feats.add(remained_ocean_feat)
							# if (len(outside_supergdu) > 0 and len(returned_remained_polygon) > 0):
								# for remained_geom in returned_remained_polygon:
									# ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
									# #create output subducted feature 
									# remained_ocean_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, remained_geom, valid_time = (ocean_begin_age, ocean_end_age))
									# remained_ocean_feat.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
									# remained_ocean_feat.set_name(oceanic_crust_ft.get_name())
									# if (reference is not None):
										# pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time, reference)
									# else:
										# pygplates.reverse_reconstruct(remained_ocean_feat, rotation_model, reconstruction_time)
									# output_remained_ocean_polygon_feats.add(remained_ocean_feat)
						# if (is_valid_oceanic_ft == False):
							# # if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
								# # ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
								# # #find the oceanic crust feature that we want
								# # for initial_oceanic_crust_ft in remained_ocean_feat_to_be_examined:
									# # if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
										# # initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time)
										# # break
							
							# ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
							# #find the oceanic crust feature that we want
							# for initial_oceanic_crust_ft in remained_ocean_polygon_feat_to_be_examined:
								# if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
									# initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time)
									# break
							# break
				print('finished updating remained_ocean_polygon_feat_to_be_examined')
		reconstruction_time = reconstruction_time - time_interval
	oceanic_crust_features.write('modified_end_age_of_oceanic_crust_feats_'+str(maximum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
	if (len(output_subducted_ocean_feats) > 0):
		output_subducted_ocean_feats.write('subducted_ocean_feats_'+str(maximum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
	if (len(output_remained_ocean_feats) > 0):
		output_remained_ocean_feats.write('remained_fragment_of_ocean_feats'+str(maximum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
	# if (len(output_remained_ocean_polygon_feats) > 0):
		# output_remained_ocean_polygon_feats.write('remained_polygon_of_ocean_feats'+str(maximum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def extend_boundary_of_each_sgdu_from_rift_point_features_w_distinct_pairs_of_sgdus(div_margin_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday):
	#dic_of_invalid_rift_point_fts = {'reconstruction_time':[],'rift_point_name':[]}
	oceanic_crust_features = pygplates.FeatureCollection()
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time)]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	prev_rift_name = None
	for rift_name in series_of_unique_rift_name:
		array_of_lrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'lrepgduid'].unique()
		array_of_rrepgduid = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'rrepgduid'].unique()
		array_of_order_for_rift_points = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'order'].to_numpy()
		df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),['order','lpolylid','rpolylid','left_gdu','right_gdu']]
		sorted_rift_order_records = df_of_rift_order_and_lpolylid_rpolylid_left_and_right_gdu.sort_values(by = 'order', ascending = False)
		#there should only be one value according to old implementation. NEW: The new implementation will find multiple rifts. Hence, just take the oldest age. 
		# start_div = -1.00
		# if (len(array_of_start_div) == 1):
			# start_div = array_of_start_div[0]
		# else:
			# print("Error there is more than one value for start_div for rift_name ", rift_name)
			# exit()
		array_of_start_div = rift_history_df.loc[rift_history_df['rift_name'] == rift_name,'start_div'].unique()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		#NEW
		start_div = sorted_array_of_start_div[-1]
		
		valid_div_margin_features = [div_margin_ft for div_margin_ft in div_margin_features if div_margin_ft.is_valid_at_time(start_div)]
		list_of_wanted_rift_point_features = []
		#find a collection of divergent margins associated with rifts
		list_of_left_div_margin_feats = []
		list_of_right_div_margin_feats = []
		#sorted_array_of_order_for_rift_points = np.sort(array_of_order_for_rift_points)
		#desc_sorted_array_of_order_for_rift_points = np.flip(sorted_array_of_order_for_rift_points)
		already_included = []
		end_age_of_isochron_feats = -1.00
		
		list_of_pairs_gdus = []
		prev_left_gdu,prev_right_gdu = -1,-1
		for order, lpolylid, rpolylid, left_gdu, right_gdu in sorted_rift_order_records.itertuples(index = False, name = None):
			print('order, lpolylid, rpolylid, left_gdu, right_gdu',order, lpolylid, rpolylid, left_gdu, right_gdu)
			name_of_rift_point_ft = rift_name+'_'+str(order)
			pairs_of_gdus = str(left_gdu)+'_'+str(right_gdu)
			if (pairs_of_gdus in list_of_pairs_gdus):
				found_point_ft = None
				for rift_point_ft in rift_point_features:
					if (rift_point_ft.get_name() == name_of_rift_point_ft):
						found_point_ft = rift_point_ft
						_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
						if (end_age_of_isochron_feats == -1.00):
							end_age_of_isochron_feats = temp_rift_pt_end_age
						elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
							end_age_of_isochron_feats = temp_rift_pt_end_age
						break
				if (end_age_of_isochron_feats < 0.00):
					end_age_of_isochron_feats = 0.00
				if (found_point_ft is not None):
					list_of_wanted_rift_point_features.append(found_point_ft)
				
				already_included_margins = []
				for div_ft in valid_div_margin_features:
					polylid = div_ft.get_name()
					gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
					if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
						if (polylid not in already_included_margins):
							list_of_left_div_margin_feats.append(div_ft)
							already_included_margins.append(polylid)
					elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
						if (polylid not in already_included_margins):
							list_of_right_div_margin_feats.append(div_ft)
							already_included_margins.append(polylid)
				
			else:#find new pairs of gdu or this is the first time
				current_rift_age = start_div
				list_of_ordered_left_div_margin_fts = []
				list_of_ordered_right_div_margin_fts = []
				reconstructed_MOR_features = []
				reconstructed_left_div_fts = []
				reconstructed_right_div_fts = []
				list_of_wanted_and_valid_rift_point_features = []
				if (len(list_of_wanted_rift_point_features) > 1 and (len(list_of_left_div_margin_feats) > 0 or len(list_of_right_div_margin_feats) > 0)):
					selected_lrepgduid = prev_left_gdu
					selected_rrepgduid = prev_right_gdu
					#print('selected_rrepgduid',selected_rrepgduid,type(selected_rrepgduid))
					# if (rift_name == 'R79694_79700'):
						# print('start_div',start_div)
					
					list_of_ordered_left_div_margin_fts[:] = []
					list_of_ordered_right_div_margin_fts[:] = []
					reconstructed_MOR_features[:] = []
					reconstructed_left_div_fts[:] = []
					reconstructed_right_div_fts[:] = []
					list_of_wanted_and_valid_rift_point_features[:] = []
					
					print('current_rift_age',current_rift_age)
					while (current_rift_age >= end_age_of_isochron_feats):#create oceanic crust features with current data
						print('current_rift_age',current_rift_age)
						#list_of_ordered_left_div_margin_fts[:] = []
						#list_of_ordered_right_div_margin_fts[:] = []
						reconstructed_MOR_features[:] = []
						reconstructed_left_div_fts[:] = []
						reconstructed_right_div_fts[:] = []
						list_of_wanted_and_valid_rift_point_features[:] = []

						list_of_ordered_left_div_margin_fts = list_of_left_div_margin_feats
						list_of_ordered_right_div_margin_fts = list_of_right_div_margin_feats
						
						if (reference is not None):
							pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							if (len(list_of_ordered_left_div_margin_fts) >= 1):
								pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
							if (len(list_of_ordered_right_div_margin_fts) >= 1):
								pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
						else:
							pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,group_with_feature = True)
							if (len(list_of_ordered_left_div_margin_fts) >= 1):
								pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,group_with_feature = True)
							if (len(list_of_ordered_right_div_margin_fts) >= 1):
								pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,group_with_feature = True)
						final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
						MOR_features,temp_reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
						reconstructed_MOR_points = list(temp_reconstructed_MOR_points)
						#print('reconstructed_MOR_points',reconstructed_MOR_points)
						print('reconstructed_left_div_fts',len(reconstructed_left_div_fts))
						if (len(reconstructed_left_div_fts) >= 1):
							final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PolylineOnSphere)
							div_left_features,reconstructed_div_left_lines = zip(*final_reconstructed_left_fts)
							reconstructed_div_left_points = []
							for left_line in reconstructed_div_left_lines:
								list_of_lat_lon_tuples = left_line.to_lat_lon_list()
								for lat_lon_tuple in list_of_lat_lon_tuples:
									reconstructed_div_left_points.append(pygplates.PointOnSphere(lat_lon_tuple))
							#print(reconstructed_div_left_points)
							#print(reconstructed_MOR_points)
							left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, (current_rift_age-age_interval_for_isochron_fts*0.100), reconstructed_div_left_points, reconstructed_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
							if (current_rift_age == end_age_of_isochron_feats):
								left_oceanic_crust_feats.set_valid_time(current_rift_age,0.00)
							oceanic_crust_features.add(left_oceanic_crust_feats)
						print('reconstructed_right_div_fts',len(reconstructed_right_div_fts))
						if (len(reconstructed_right_div_fts) >= 1):
							final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PolylineOnSphere)
							div_right_features,reconstructed_div_right_lines = zip(*final_reconstructed_right_fts)
							reconstructed_div_right_points = []
							for right_line in reconstructed_div_right_lines:
								list_of_lat_lon_tuples = right_line.to_lat_lon_list()
								for lat_lon_tuple in list_of_lat_lon_tuples:
									reconstructed_div_right_points.append(pygplates.PointOnSphere(lat_lon_tuple))
							right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, (current_rift_age-age_interval_for_isochron_fts*0.100), reconstructed_div_right_points, reconstructed_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
							if (current_rift_age == end_age_of_isochron_feats):
								right_oceanic_crust_feats.set_valid_time(current_rift_age,0.00)
							oceanic_crust_features.add(right_oceanic_crust_feats)
						current_rift_age = current_rift_age - age_interval_for_isochron_fts
					#reset everything and start new collections of data
					list_of_wanted_rift_point_features[:] = []
					list_of_left_div_margin_feats[:] = []
					list_of_right_div_margin_feats[:] = []
					end_age_of_isochron_feats = -1.00
					
					found_point_ft = None
					for rift_point_ft in rift_point_features:
						if (rift_point_ft.get_name() == name_of_rift_point_ft):
							found_point_ft = rift_point_ft
							_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
							if (end_age_of_isochron_feats == -1.00):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							break
					if (end_age_of_isochron_feats < 0.00):
						end_age_of_isochron_feats = 0.00
					if (found_point_ft is not None):
						list_of_wanted_rift_point_features.append(found_point_ft)
					already_included_margins = []
					for div_ft in valid_div_margin_features:
						polylid = div_ft.get_name()
						gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
						if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_left_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
						elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_right_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
				else:
					found_point_ft = None
					for rift_point_ft in rift_point_features:
						if (rift_point_ft.get_name() == name_of_rift_point_ft):
							found_point_ft = rift_point_ft
							_,temp_rift_pt_end_age = rift_point_ft.get_valid_time()
							if (end_age_of_isochron_feats == -1.00):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							elif (end_age_of_isochron_feats > temp_rift_pt_end_age):
								end_age_of_isochron_feats = temp_rift_pt_end_age
							break
					if (end_age_of_isochron_feats < 0.00):
						end_age_of_isochron_feats = 0.00
					if (found_point_ft is not None):
						list_of_wanted_rift_point_features.append(found_point_ft)
					already_included_margins = []
					for div_ft in valid_div_margin_features:
						polylid = div_ft.get_name()
						gduid_of_div_ft = div_ft.get_reconstruction_plate_id()
						if (polylid == lpolylid and left_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_left_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
						elif (polylid == rpolylid and right_gdu == gduid_of_div_ft):
							if (polylid not in already_included_margins):
								list_of_right_div_margin_feats.append(div_ft)
								already_included_margins.append(polylid)
				prev_left_gdu,prev_right_gdu = left_gdu, right_gdu
				list_of_pairs_gdus.append(pairs_of_gdus)
		if (len(list_of_wanted_rift_point_features) and (len(list_of_left_div_margin_feats) > 0 or len(list_of_right_div_margin_feats) > 0)):
			current_rift_age = start_div
			list_of_ordered_left_div_margin_fts = []
			list_of_ordered_right_div_margin_fts = []
			reconstructed_MOR_features = []
			reconstructed_left_div_fts = []
			reconstructed_right_div_fts = []
			list_of_wanted_and_valid_rift_point_features = []
			selected_lrepgduid = prev_left_gdu
			selected_rrepgduid = prev_right_gdu
			while (current_rift_age >= end_age_of_isochron_feats):#create oceanic crust features with current data
				print('current_rift_age',current_rift_age)
				#list_of_ordered_left_div_margin_fts[:] = []
				#list_of_ordered_right_div_margin_fts[:] = []
				reconstructed_MOR_features[:] = []
				reconstructed_left_div_fts[:] = []
				reconstructed_right_div_fts[:] = []
				list_of_wanted_and_valid_rift_point_features[:] = []

				list_of_ordered_left_div_margin_fts = list_of_left_div_margin_feats
				list_of_ordered_right_div_margin_fts = list_of_right_div_margin_feats
						
				if (reference is not None):
					pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
					if (len(list_of_ordered_left_div_margin_fts) >= 1):
						pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
					if (len(list_of_ordered_right_div_margin_fts) >= 1):
						pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,anchor_plate_id = reference, group_with_feature = True)
				else:
					pygplates.reconstruct(list_of_wanted_rift_point_features,rotation_model,reconstructed_MOR_features,current_rift_age,group_with_feature = True)
					if (len(list_of_ordered_left_div_margin_fts) >= 1):
						pygplates.reconstruct(list_of_ordered_left_div_margin_fts,rotation_model,reconstructed_left_div_fts,current_rift_age,group_with_feature = True)
					if (len(list_of_ordered_right_div_margin_fts) >= 1):
						pygplates.reconstruct(list_of_ordered_right_div_margin_fts,rotation_model,reconstructed_right_div_fts,current_rift_age,group_with_feature = True)
				final_reconstructed_MOR_fts = find_final_reconstructed_geometries(reconstructed_MOR_features,pygplates.PointOnSphere)
				MOR_features,temp_reconstructed_MOR_points = zip(*final_reconstructed_MOR_fts)
				reconstructed_MOR_points = list(temp_reconstructed_MOR_points)
				#print('reconstructed_MOR_points',reconstructed_MOR_points)
				print('reconstructed_left_div_fts',len(reconstructed_left_div_fts))
				if (len(reconstructed_left_div_fts) >= 1):
					final_reconstructed_left_fts = find_final_reconstructed_geometries(reconstructed_left_div_fts,pygplates.PolylineOnSphere)
					div_left_features,reconstructed_div_left_lines = zip(*final_reconstructed_left_fts)
					reconstructed_div_left_points = []
					for left_line in reconstructed_div_left_lines:
						list_of_lat_lon_tuples = left_line.to_lat_lon_list()
						for lat_lon_tuple in list_of_lat_lon_tuples:
							reconstructed_div_left_points.append(pygplates.PointOnSphere(lat_lon_tuple))
					#print(reconstructed_div_left_points)
					#print(reconstructed_MOR_points)
					left_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, (current_rift_age-age_interval_for_isochron_fts*0.100), reconstructed_div_left_points, reconstructed_MOR_points, selected_lrepgduid, selected_lrepgduid, selected_rrepgduid, 'left', rift_name, rotation_model, reference)
					if (current_rift_age == end_age_of_isochron_feats):
						left_oceanic_crust_feats.set_valid_time(current_rift_age,0.00)
					oceanic_crust_features.add(left_oceanic_crust_feats)
				print('reconstructed_right_div_fts',len(reconstructed_right_div_fts))
				if (len(reconstructed_right_div_fts) >= 1):
					final_reconstructed_right_fts = find_final_reconstructed_geometries(reconstructed_right_div_fts,pygplates.PolylineOnSphere)
					div_right_features,reconstructed_div_right_lines = zip(*final_reconstructed_right_fts)
					reconstructed_div_right_points = []
					for right_line in reconstructed_div_right_lines:
						list_of_lat_lon_tuples = right_line.to_lat_lon_list()
						for lat_lon_tuple in list_of_lat_lon_tuples:
							reconstructed_div_right_points.append(pygplates.PointOnSphere(lat_lon_tuple))
					right_oceanic_crust_feats = create_oceanic_crust_polygon_fts_at_age(current_rift_age, (current_rift_age-age_interval_for_isochron_fts*0.100), reconstructed_div_right_points, reconstructed_MOR_points, selected_rrepgduid, selected_lrepgduid, selected_rrepgduid, 'right', rift_name, rotation_model, reference)
					if (current_rift_age == end_age_of_isochron_feats):
						right_oceanic_crust_feats.set_valid_time(current_rift_age,0.00)
					oceanic_crust_features.add(right_oceanic_crust_feats)
				current_rift_age = current_rift_age - age_interval_for_isochron_fts
	oceanic_crust_features.write('extend_boundary_of_each_sgdu_with_max_age'+str(maximum_reconstruction_time)+'_min_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features(common_filename_for_temporary_sgdu_and_members_csv,rift_point_features_records_csv, oceanic_crust_features, supergdu_features, rotation_model, reference, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, modelname, yearmonthday):
	#subduction_zone_features = pygplates.FeatureCollection()
	reconstructed_oceanic_features = []
	reconstructed_supergdu_features = []
	valid_oceanic_crust_features = []
	
	dic_of_supergdu_and_gdu_members = {}
	
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna())]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	
	for rift_name in series_of_unique_rift_name:
		splited_str = rift_name.split('_')
		part_1 = splited_str[0]
		splited_str_part_1 = part_1.split('R')
		child_1 = splited_str_part_1[1]
		child_2 = splited_str[1]
		print('child_1', child_1)
		print('child_2', child_2)
		records_start_div = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'start_div']
		array_of_start_div = records_start_div.to_numpy()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		oldest_div_age = sorted_array_of_start_div[-1] #because the order of sorting is ascending
		reconstruction_time = oldest_div_age - time_interval
		while (reconstruction_time >= 0.00):
			print('reconstruction_time', reconstruction_time)
			
			valid_supergdu_features = [sgdu_feat for sgdu_feat in supergdu_features if sgdu_feat.is_valid_at_time(reconstruction_time)]
			#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
			temporary_sgdu_and_member_csv_at_time = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(reconstruction_time))
			temp_sgdu_and_gdu_df = pd.read_csv(temporary_sgdu_and_member_csv_at_time, delimiter = ';', header = 0)
			for valid_supergdu_ft in valid_supergdu_features:
				sgdu_begin,_ = valid_supergdu_ft.get_valid_time()
				initial_sgdu_and_members_csv = common_filename_for_temporary_sgdu_and_members_csv.format(time = str(sgdu_begin))
				#;from_time;to_time;SGDUID;GDUID;buffer_distance_km;repGDUID
				initial_df = pd.read_csv(initial_sgdu_and_members_csv, delimiter = ';', header = 0)
				if (valid_supergdu_ft.get_name() not in dic_of_supergdu_and_gdu_members):
					unique_sgdus = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['repGDUID'] == valid_supergdu_ft.get_reconstruction_plate_id())|(temp_sgdu_and_gdu_df['GDUID'] == valid_supergdu_ft.get_reconstruction_plate_id()),'SGDUID'].unique()
					records_of_gdu_members = []
					for sgdu in unique_sgdus:
						temp_members = temp_sgdu_and_gdu_df.loc[(temp_sgdu_and_gdu_df['SGDUID'] == sgdu),'GDUID'].unique()
						for temp_mem in temp_members:
							if (temp_mem not in records_of_gdu_members):
								records_of_gdu_members.append(temp_mem)
					temp_members = initial_df.loc[(initial_df['SGDUID'] == int(valid_supergdu_ft.get_name())),'GDUID'].unique()
					for temp_mem in temp_members:
						if (temp_mem not in records_of_gdu_members):
							records_of_gdu_members.append(temp_mem)
					dic_of_supergdu_and_gdu_members[valid_supergdu_ft.get_name()] = records_of_gdu_members
			
			reconstructed_oceanic_features[:] = []
			reconstructed_supergdu_features[:] = []
			valid_oceanic_crust_features[:] = []
			for oceanic_crust_feat in oceanic_crust_features:
				if (oceanic_crust_feat.is_valid_at_time(reconstruction_time) and oceanic_crust_feat.get_name() == rift_name):
					begin_oceanic_age, end_oceanic_age = oceanic_crust_feat.get_valid_time()
					if (begin_oceanic_age > reconstruction_time):
						valid_oceanic_crust_features.append(oceanic_crust_feat)
			print('number of features in valid_oceanic_crust_features', len(valid_oceanic_crust_features))
			if (reference is not None):
				pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_supergdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(valid_oceanic_crust_features,rotation_model,reconstructed_oceanic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_supergdu_features,reconstruction_time,group_with_feature = True)
				pygplates.reconstruct(valid_oceanic_crust_features,rotation_model,reconstructed_oceanic_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_supergdu_features = find_final_reconstructed_geometries(reconstructed_supergdu_features, pygplates.PolygonOnSphere)
			final_reconstructed_oceanic_crust_features = find_final_reconstructed_geometries(reconstructed_oceanic_features, pygplates.PolygonOnSphere)
			for oceanic_crust_ft, oceanic_crust in final_reconstructed_oceanic_crust_features:
				gduid_of_oceanic_crust_ft = oceanic_crust_ft.get_reconstruction_plate_id()
				inside_supergdu = []
				outside_supergdu = []
				is_valid_oceanic_ft = True
				potential_sgdu_feats = []
				for supergdu_ft, supergdu_polygon in final_reconstructed_supergdu_features:
					if (supergdu_ft.get_name() != child_1 and supergdu_ft.get_name() != child_2):
						gdu_members_of_current_sgdu = dic_of_supergdu_and_gdu_members[supergdu_ft.get_name()]
						if (gduid_of_oceanic_crust_ft not in gdu_members_of_current_sgdu):
							potential_sgdu_feats.append((supergdu_ft, supergdu_polygon))
						else:
							sgdu_begin_age,_ = supergdu_ft.get_valid_time()
							current_ocean_begin_age,_ = oceanic_crust_ft.get_valid_time()
							if (abs(sgdu_begin_age-current_ocean_begin_age) > time_interval):
								potential_sgdu_feats.append((supergdu_ft, supergdu_polygon))
				
				for supergdu_ft, supergdu_polygon in potential_sgdu_feats:
					if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
						supergdu_polygon.partition(oceanic_crust, partitioned_geometries_inside = inside_supergdu, partitioned_geometries_outside = outside_supergdu)
						returned_remained_geom = []
						returned_subducted_geom = []
						returned_remained_polygon = []
						if (len(inside_supergdu) > 0):
							is_valid_oceanic_ft = False
							# #get the geometry of the subduction zone
							# oceanic_crust.partition(supergdu_polygon, partitioned_geometries_inside = returned_subducted_geom)
							# if (len(returned_subducted_geom) > 0):
								# for subduction_geom in returned_subducted_geom:
									# #create subduction zone features: PlateID of sgdu and conjugate PlateID of ocean crust
									# subduction_zone_feat = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, subduction_geom, valid_time = (reconstruction_time,0.00))
									# subduction_zone_feat.set_reconstruction_plate_id(supergdu_ft.get_reconstruction_plate_id())
									# subduction_zone_feat.set_description("subduction_zone")
									# if (reference is not None):
										# pygplates.reverse_reconstruct(subduction_zone_feat, rotation_model, reconstruction_time, reference)
									# else:
										# pygplates.reverse_reconstruct(subduction_zone_feat, rotation_model, reconstruction_time)
									# subduction_zone_features.add(subduction_zone_feat)
							break
				if (is_valid_oceanic_ft == False):
					ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
					#find the oceanic crust feature that we want
					for initial_oceanic_crust_ft in valid_oceanic_crust_features:
						if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
							initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time+0.100)
							break
			reconstruction_time = reconstruction_time-time_interval
	oceanic_crust_features.write('modified_end_age_of_invalid_temporary_oceanic_crust_polygon_feats_'+str(maximum_reconstruction_time)+'_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')
	#subduction_zone_features.write('temporary_subduction_zone_features_'+str(maximum_reconstruction_time)+'_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features_based_on_spatial_rlxn_with_any_sgdu(rift_point_features_records_csv, oceanic_crust_features, supergdu_features, rotation_model, reference, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, modelname, yearmonthday):

	reconstructed_oceanic_features = []
	reconstructed_supergdu_features = []
	valid_oceanic_crust_features = []
	
	dic_of_supergdu_and_gdu_members = {}
	
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna())]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	
	for rift_name in series_of_unique_rift_name:
		splited_str = rift_name.split('_')
		part_1 = splited_str[0]
		splited_str_part_1 = part_1.split('R')
		child_1 = splited_str_part_1[1]
		child_2 = splited_str[1]
		print('child_1', child_1)
		print('child_2', child_2)
		records_start_div = rift_history_df.loc[(rift_history_df['rift_name'] == rift_name) & (rift_history_df['lpolylid'].notna()) & (rift_history_df['rpolylid'].notna()),'start_div']
		array_of_start_div = records_start_div.to_numpy()
		sorted_array_of_start_div = np.sort(array_of_start_div)
		oldest_div_age = sorted_array_of_start_div[-1] #because the order of sorting is ascending
		reconstruction_time = oldest_div_age - time_interval
		while (reconstruction_time >= 0.00):
			print('reconstruction_time', reconstruction_time)
			
			valid_supergdu_features = [sgdu_feat for sgdu_feat in supergdu_features if sgdu_feat.is_valid_at_time(reconstruction_time)]
			
			reconstructed_oceanic_features[:] = []
			reconstructed_supergdu_features[:] = []
			valid_oceanic_crust_features[:] = []
			for oceanic_crust_feat in oceanic_crust_features:
				if (oceanic_crust_feat.is_valid_at_time(reconstruction_time) and oceanic_crust_feat.get_name() == rift_name):
					begin_oceanic_age, end_oceanic_age = oceanic_crust_feat.get_valid_time()
					if (begin_oceanic_age > reconstruction_time):
						valid_oceanic_crust_features.append(oceanic_crust_feat)
			print('number of features in valid_oceanic_crust_features', len(valid_oceanic_crust_features))
			if (reference is not None):
				pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_supergdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
				pygplates.reconstruct(valid_oceanic_crust_features,rotation_model,reconstructed_oceanic_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_supergdu_features,reconstruction_time,group_with_feature = True)
				pygplates.reconstruct(valid_oceanic_crust_features,rotation_model,reconstructed_oceanic_features,reconstruction_time,group_with_feature = True)
			final_reconstructed_supergdu_features = find_final_reconstructed_geometries(reconstructed_supergdu_features, pygplates.PolygonOnSphere)
			final_reconstructed_oceanic_crust_features = find_final_reconstructed_geometries(reconstructed_oceanic_features, pygplates.PolygonOnSphere)
			for oceanic_crust_ft, oceanic_crust in final_reconstructed_oceanic_crust_features:
				inside_supergdu = []
				outside_supergdu = []
				is_valid_oceanic_ft = True
				for supergdu_ft, supergdu_polygon in final_reconstructed_supergdu_features:
					if (supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.intersecting or supergdu_polygon.partition(oceanic_crust) == pygplates.PolygonOnSphere.PartitionResult.inside):
						supergdu_polygon.partition(oceanic_crust, partitioned_geometries_inside = inside_supergdu, partitioned_geometries_outside = outside_supergdu)
						returned_remained_geom = []
						returned_subducted_geom = []
						returned_remained_polygon = []
						if (len(inside_supergdu) > 0):
							is_valid_oceanic_ft = False
							break
				if (is_valid_oceanic_ft == False):
					ocean_begin_age, ocean_end_age = oceanic_crust_ft.get_valid_time()
					#find the oceanic crust feature that we want
					for initial_oceanic_crust_ft in valid_oceanic_crust_features:
						if (initial_oceanic_crust_ft.get_feature_id() == oceanic_crust_ft.get_feature_id()):
							initial_oceanic_crust_ft.set_valid_time(ocean_begin_age, reconstruction_time+0.100)
							break
			reconstruction_time = reconstruction_time-time_interval
	oceanic_crust_features.write('hard_modified_end_age_of_invalid_temporary_oceanic_crust_polygon_feats_'+str(maximum_reconstruction_time)+'_'+str(minimum_reconstruction_time)+'_'+modelname+'_'+yearmonthday+'.shp')

def check_and_assign_proper_SuperGDU_to_rift_point_features(rift_point_features_records_csv, temp_oceanic_crust_features, sgdu_features, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, rotation_model, reference, modelname, yearmonthday):
	dic_of_modified_features = {}
	new_oceanic_crust_features = pygplates.FeatureCollection()
	reconstructed_sgdu_features_1 = []
	reconstructed_sgdu_features_2 = []
	reconstructed_oceanic_crust_features = []
	#updates_rift_records = []
	#start_div,rift_name,order,lpolylid,left_gdu,lrepgduid,rpolylid,right_gdu,rrepgduid
	rift_history_df = pd.read_csv(rift_point_features_records_csv, delimiter=',', header = 0)
	selected_rift_history_df = None
	if (maximum_reconstruction_time is not None):
		selected_rift_history_df = rift_history_df.loc[(rift_history_df['start_div'] <= maximum_reconstruction_time) & (rift_history_df['start_div'] > minimum_reconstruction_time) ]
	if (selected_rift_history_df is not None):
		rift_history_df = selected_rift_history_df
	series_of_unique_rift_name = rift_history_df['rift_name'].unique()
	for rift_name in series_of_unique_rift_name:
		print('rift_name',rift_name)
		reconstructed_sgdu_features_1[:] = []
		reconstructed_sgdu_features_2[:] = []
		reconstructed_oceanic_crust_features[:] = []
		splited_str = rift_name.split('_')
		part_1 = splited_str[0]
		splited_str_part_1 = part_1.split('R')
		child_1 = splited_str_part_1[1]
		child_2 = splited_str[1]
		print('child_1', child_1)
		print('child_2', child_2)
		wanted_oceanic_crust_features = []
		oldest_age_of_oceanic_ft = -1.000
		for oceanic_ft in temp_oceanic_crust_features:
			if (oceanic_ft.get_name() == rift_name):
				begin_age_oceanic_ft, end_age_oceanic_ft = oceanic_ft.get_valid_time()
				if (oldest_age_of_oceanic_ft == -1.00):
					oldest_age_of_oceanic_ft = begin_age_oceanic_ft
				elif (oldest_age_of_oceanic_ft < begin_age_oceanic_ft and oldest_age_of_oceanic_ft >= 0.00):
					oldest_age_of_oceanic_ft = begin_age_oceanic_ft
				wanted_oceanic_crust_features.append(oceanic_ft)
		print('oldest_age_of_oceanic_ft',oldest_age_of_oceanic_ft)
		print('wanted_oceanic_crust_features',wanted_oceanic_crust_features)
		wanted_oldest_oceanic_crust_features = []
		for wanted_feat in wanted_oceanic_crust_features:
			begin_age_oceanic_ft, end_age_oceanic_ft = wanted_feat.get_valid_time()
			if (begin_age_oceanic_ft == oldest_age_of_oceanic_ft):
				wanted_oldest_oceanic_crust_features.append(wanted_feat)
		valid_sgdu_features = [sgdu_ft for sgdu_ft in sgdu_features if (sgdu_ft.is_valid_at_time(oldest_age_of_oceanic_ft))]
		wanted_sgdu_features_1 = []
		wanted_sgdu_features_2 = []
		for valid_sgdu_ft in valid_sgdu_features:
			if (valid_sgdu_ft.get_name() == child_1):
				wanted_sgdu_features_1.append(valid_sgdu_ft)
			elif (valid_sgdu_ft.get_name() == child_2):
				wanted_sgdu_features_2.append(valid_sgdu_ft)
		
		if (reference is not None):
			pygplates.reconstruct(wanted_sgdu_features_1, rotation_model, reconstructed_sgdu_features_1, oldest_age_of_oceanic_ft, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(wanted_sgdu_features_2, rotation_model, reconstructed_sgdu_features_2, oldest_age_of_oceanic_ft, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(wanted_oldest_oceanic_crust_features, rotation_model, reconstructed_oceanic_crust_features, oldest_age_of_oceanic_ft, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(wanted_sgdu_features_1, rotation_model, reconstructed_sgdu_features_1, oldest_age_of_oceanic_ft, group_with_feature = True)
			pygplates.reconstruct(wanted_sgdu_features_2, rotation_model, reconstructed_sgdu_features_2, oldest_age_of_oceanic_ft, group_with_feature = True)
			pygplates.reconstruct(wanted_oldest_oceanic_crust_features, rotation_model, reconstructed_oceanic_crust_features, oldest_age_of_oceanic_ft, group_with_feature = True)
		final_reconstructed_sgdu_features_1 = find_final_reconstructed_geometries(reconstructed_sgdu_features_1, pygplates.PolygonOnSphere)
		final_reconstructed_sgdu_features_2 = find_final_reconstructed_geometries(reconstructed_sgdu_features_2, pygplates.PolygonOnSphere)
		final_reconstructed_oceanic_crust_features = find_final_reconstructed_geometries(reconstructed_oceanic_crust_features, pygplates.PolygonOnSphere)
		
		print('len(final_reconstructed_sgdu_features_1)',len(final_reconstructed_sgdu_features_1))
		print('len(final_reconstructed_sgdu_features_2)',len(final_reconstructed_sgdu_features_2))
		print('len(final_reconstructed_oceanic_crust_features)',len(final_reconstructed_oceanic_crust_features))
		
		for reconstructed_oldest_oceanic_crust_ft, reconstructed_oldest_oceanic_crust in final_reconstructed_oceanic_crust_features:
			gduid_of_oceanic_ft = reconstructed_oldest_oceanic_crust_ft.get_reconstruction_plate_id()
			is_required_to_change = False
			is_sgdu_1 = False
			is_sgdu_2 = False
			for sgd_ft_1, sgdu_1 in final_reconstructed_sgdu_features_1:
				repgduid_of_sgdu_1 = sgd_ft_1.get_reconstruction_plate_id()
				if (repgduid_of_sgdu_1 == gduid_of_oceanic_ft):
					is_sgdu_1 = True
					#check the distance between two features 
					distance = pygplates.GeometryOnSphere.distance(reconstructed_oldest_oceanic_crust, sgdu_1)
					if (distance > 0.00):
						is_required_to_change = True
						break
						#Note: same rotation or same repgduid, need to check for distance.
						#if distance == 0.00, nothing happens - No need to change the repgduid of the oceanic crust feature. If the distance > 0.00, need to find the supergdu feature that is next to oceanic crust feature. 
				# else:
					# moving_plate_id = gduid_of_oceanic_ft
					# fixed_plate_id = repgduid_of_sgdu_1
					# from_time = oldest_age_of_oceanic_ft + time_interval
					# to_time = oldest_age_of_oceanic_ft
					# rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, from_time, to_time, reference)
					# if (rel_stage_rot is None):
						# is_sgdu_1 = True
						# #check the distance between two features 
						# distance = pygplates.GeometryOnSphere.distance(reconstructed_oldest_oceanic_crust, sgdu_1)
						# if (distance > 0.00):
							# is_required_to_change = True
							# break
					# else:
						# if (rel_stage_rot.represents_identity_rotation()):
							# is_sgdu_1 = True
							# #check the distance between two features 
							# distance = pygplates.GeometryOnSphere.distance(reconstructed_oldest_oceanic_crust, sgdu_1)
							# if (distance > 0.00):
								# is_required_to_change = True
								# break
			if (is_sgdu_1 == False):
				for sgd_ft_2, sgdu_2 in final_reconstructed_sgdu_features_2:
					repgduid_of_sgdu_2 = sgd_ft_2.get_reconstruction_plate_id()
					if (repgduid_of_sgdu_2 == gduid_of_oceanic_ft):
						is_sgdu_2 = True 
						#check the distance between two features 
						distance = pygplates.GeometryOnSphere.distance(reconstructed_oldest_oceanic_crust, sgdu_2)
						if (distance > 0.00):
							is_required_to_change = True
							break
							#Note: same rotation or same repgduid, need to check for distance.
							#if distance == 0.00, nothing happens - No need to change the repgduid of the oceanic crust feature. If the distance > 0.00, need to find the supergdu feature that is next to oceanic crust feature. 
					# else:
						# moving_plate_id = gduid_of_oceanic_ft
						# fixed_plate_id = repgduid_of_sgdu_2
						# from_time = oldest_age_of_oceanic_ft + time_interval
						# to_time = oldest_age_of_oceanic_ft
						# rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, from_time, to_time, reference)
						# if (rel_stage_rot is None):
							# is_sgdu_2 = True
							# #check the distance between two features 
							# distance = pygplates.GeometryOnSphere.distance(reconstructed_oldest_oceanic_crust, sgdu_2)
							# if (distance > 0.00):
								# is_required_to_change = True
								# break
						# else:
							# if (rel_stage_rot.represents_identity_rotation()):
								# is_sgdu_2 = True
								# #check the distance between two features 
								# distance = pygplates.GeometryOnSphere.distance(reconstructed_oldest_oceanic_crust, sgdu_2)
								# if (distance > 0.00):
									# is_required_to_change = True
									# break
			if (is_required_to_change == True):
				#find the proper sgdu feature 
				if (is_sgdu_1 == True):
					for sgd_ft_1, sgdu_1 in final_reconstructed_sgdu_features_1:
						#check the distance between two features 
						distance = pygplates.GeometryOnSphere.distance(reconstructed_oldest_oceanic_crust, sgdu_1)
						if (distance == 0.00):
							for temp_oceanic_ft in wanted_oceanic_crust_features:
								temp_gduid = temp_oceanic_ft.get_reconstruction_plate_id()
								temp_left_gduid = temp_oceanic_ft.get_left_plate()
								temp_right_gduid = temp_oceanic_ft.get_right_plate()
								if (temp_gduid == gduid_of_oceanic_ft):
									new_oceanic_ft = None
									begin_age_oceanic_ft,end_age_oceanic_ft = temp_oceanic_ft.get_valid_time()
									reconstruction_time = begin_age_oceanic_ft
									if (begin_age_oceanic_ft == oldest_age_of_oceanic_ft):
										new_oceanic_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, reconstructed_oldest_oceanic_crust, valid_time = (begin_age_oceanic_ft,end_age_oceanic_ft))
									else:
										temp_reconstructed_ynger_feats = []
										if (reference is not None):
											pygplates.reconstruct(temp_oceanic_ft, rotation_model, temp_reconstructed_ynger_feats, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
										else:
											pygplates.reconstruct(temp_oceanic_ft, rotation_model, temp_reconstructed_ynger_feats, reconstruction_time, group_with_feature = True)
										final_reconstructed_ynger_feat = find_final_reconstructed_geometries(temp_reconstructed_ynger_feats, pygplates.PolygonOnSphere)
										if (len(final_reconstructed_ynger_feat) > 0):
											_,new_geom = final_reconstructed_ynger_feat[0]
											new_oceanic_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, new_geom, valid_time = (begin_age_oceanic_ft,end_age_oceanic_ft))
											if (temp_gduid == temp_left_gduid):
												new_oceanic_ft.set_reconstruction_plate_id(sgd_ft_1.get_reconstruction_plate_id())
												new_oceanic_ft.set_left_plate(sgd_ft_1.get_reconstruction_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
												new_oceanic_ft.set_right_plate(temp_right_gduid,verify_information_model = pygplates.VerifyInformationModel.no)
											elif (temp_gduid == temp_right_gduid):
												new_oceanic_ft.set_reconstruction_plate_id(sgd_ft_1.get_reconstruction_plate_id())
												new_oceanic_ft.set_right_plate(sgd_ft_1.get_reconstruction_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
												new_oceanic_ft.set_left_plate(temp_left_gduid,verify_information_model = pygplates.VerifyInformationModel.no)
											if (reference is not None):
												pygplates.reverse_reconstruct(new_oceanic_ft, rotation_model, reconstruction_time, reference)
											else:
												pygplates.reverse_reconstruct(new_oceanic_ft, rotation_model, reconstruction_time)
											new_oceanic_ft.set_name(rift_name)
											new_oceanic_crust_features.add(new_oceanic_ft)
									if (rift_name not in dic_of_modified_features):
										dic_of_modified_features[rift_name] = (gduid_of_oceanic_ft,sgd_ft_1.get_reconstruction_plate_id())
							break
				elif (is_sgdu_2 == True):
					for sgd_ft_2, sgdu_2 in final_reconstructed_sgdu_features_2:
						#check the distance between two features 
						distance = pygplates.GeometryOnSphere.distance(reconstructed_oldest_oceanic_crust, sgdu_2)
						if (distance == 0.00):
							for temp_oceanic_ft in wanted_oceanic_crust_features:
								print('sgd_ft_2.get_reconstruction_plate_id()',sgd_ft_2.get_reconstruction_plate_id())
								print('temp_oceanic_ft..get_reconstruction_plate_id()',temp_oceanic_ft.get_reconstruction_plate_id())
								temp_gduid = temp_oceanic_ft.get_reconstruction_plate_id()
								temp_left_gduid = temp_oceanic_ft.get_left_plate()
								temp_right_gduid = temp_oceanic_ft.get_right_plate()
								if (temp_gduid == gduid_of_oceanic_ft):
									new_oceanic_ft = None
									begin_age_oceanic_ft,end_age_oceanic_ft = temp_oceanic_ft.get_valid_time()
									reconstruction_time = begin_age_oceanic_ft
									if (begin_age_oceanic_ft == oldest_age_of_oceanic_ft):
										new_oceanic_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, reconstructed_oldest_oceanic_crust, valid_time = (begin_age_oceanic_ft,end_age_oceanic_ft))
									else:
										temp_reconstructed_ynger_feats = []
										if (reference is not None):
											pygplates.reconstruct(temp_oceanic_ft, rotation_model, temp_reconstructed_ynger_feats, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
										else:
											pygplates.reconstruct(temp_oceanic_ft, rotation_model, temp_reconstructed_ynger_feats, reconstruction_time, group_with_feature = True)
										final_reconstructed_ynger_feat = find_final_reconstructed_geometries(temp_reconstructed_ynger_feats, pygplates.PolygonOnSphere)
										if (len(final_reconstructed_ynger_feat) > 0):
											_,new_geom = final_reconstructed_ynger_feat[0]
											new_oceanic_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_oceanic_crust, new_geom, valid_time = (begin_age_oceanic_ft,end_age_oceanic_ft))
											if (temp_gduid == temp_left_gduid):
												new_oceanic_ft.set_reconstruction_plate_id(sgd_ft_2.get_reconstruction_plate_id())
												new_oceanic_ft.set_left_plate(sgd_ft_2.get_reconstruction_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
												new_oceanic_ft.set_right_plate(temp_right_gduid,verify_information_model = pygplates.VerifyInformationModel.no)
											elif (temp_gduid == temp_right_gduid):
												new_oceanic_ft.set_reconstruction_plate_id(sgd_ft_2.get_reconstruction_plate_id())
												new_oceanic_ft.set_right_plate(sgd_ft_2.get_reconstruction_plate_id(),verify_information_model = pygplates.VerifyInformationModel.no)
												new_oceanic_ft.set_right_plate(temp_left_gduid,verify_information_model = pygplates.VerifyInformationModel.no)
											if (reference is not None):
												pygplates.reverse_reconstruct(new_oceanic_ft, rotation_model, reconstruction_time, reference)
											else:
												pygplates.reverse_reconstruct(new_oceanic_ft, rotation_model, reconstruction_time)
											new_oceanic_ft.set_name(rift_name)
											new_oceanic_crust_features.add(new_oceanic_ft)
									if (rift_name not in dic_of_modified_features):
										dic_of_modified_features[rift_name] = (gduid_of_oceanic_ft,sgd_ft_2.get_reconstruction_plate_id())
							break
			# if (is_required_to_change == False):
				# for temp_oceanic_ft in wanted_oceanic_crust_features:
					# new_oceanic_crust_features.add(temp_oceanic_ft)
					# break
	for original_ocean_ft in temp_oceanic_crust_features:
		rift_name = original_ocean_ft.get_name()
		original_repgduid = original_ocean_ft.get_reconstruction_plate_id()
		if (rift_name in dic_of_modified_features):
			old_repgduid, new_repgduid = dic_of_modified_features[rift_name]
			if (original_repgduid != old_repgduid):
				original_left = original_ocean_ft.get_left_plate()
				original_right = original_ocean_ft.get_right_plate()
				if (original_left == old_repgduid):
					original_ocean_ft.set_left_plate(new_repgduid, verify_information_model = pygplates.VerifyInformationModel.no)
				elif (original_right == old_repgduid):
					original_ocean_ft.set_right_plate(new_repgduid, verify_information_model = pygplates.VerifyInformationModel.no)
				new_oceanic_crust_features.add(original_ocean_ft)
		else:
			new_oceanic_crust_features.add(original_ocean_ft)
	new_oceanic_crust_features.write('new_repgduid_of_oceanic_crust_feats_for_'+str(maximum_reconstruction_time)+'_'+modelname+'.shp')

def quickly_derive_mid_point_and_order_of_mid_point_from_two_divergent_points(pt_1,pt_2,Euler_pole):
	approx_mid_point = find_the_mid_of_two_PointOnSphere(pt_1,pt_2)
	vec_E_pole = pygplates.Vector3D(Euler_pole.to_xyz())
	vec_mid_point = pygplates.Vector3D(approx_mid_point.to_xyz())
	angle_rads = pygplates.Vector3D.angle_between(vec_mid_point,vec_E_pole)
	#convert angle_rads to degrees
	theta_degrees = math.degrees(angle_rads)
	return (approx_mid_point,theta_degrees)

def evaluate_oceanic_crust_features_with_each_other(oceanic_crust_features, sgdu_features, rotation_model, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, reference, modelname, yearmonthday):
	# oceanic_crust_features_to_be_evaluated = pygplates.FeatureCollection()
	# for oceanic_ft in oceanic_crust_features:
		# oceanic_ft_begin_age,oceanic_ft_end_age = oceanic_ft.get_valid_time()
		# #print("oceanic_ft_begin_age,oceanic_ft_end_age",oceanic_ft_begin_age,oceanic_ft_end_age)
		# is_included = True
		# #print('is_included',is_included)
		# # if (oceanic_ft_begin_age < minimum_reconstruction_time or oceanic_ft_end_age > maximum_reconstruction_time):
			# # is_included = False
		# #ancient oceanic crust features can participate
		# if (oceanic_ft_begin_age < minimum_reconstruction_time):
			# is_included = False
		# if (is_included == True):
			# oceanic_crust_features_to_be_evaluated.add(oceanic_ft)
	# print('oceanic_crust_features_to_be_evaluated',len(oceanic_crust_features_to_be_evaluated))
	temporary_list_of_subduction_feats = []
	new_subduction_feats = []
	temporary_list_of_rift_feats = []
	new_rift_feats = []
	temporary_list_of_transform_feats = []
	new_transform_feats = []
	
	output_rift_point_features = pygplates.FeatureCollection()
	output_subducted_ocean_feats = pygplates.FeatureCollection()
	output_trans_feats = pygplates.FeatureCollection()
	#output_rift_feats = pygplates.FeatureCollection()
	
	list_of_oceanic_records = []
	oceanic_crust_features_to_be_evaluated = []
	reconstruction_time = maximum_reconstruction_time
	reconstructed_oceanic_features = []
	reconstructed_prev_oceanic_features = []
	reconstructed_sgdu_features = []
	reconstructed_rift_features = []
	reconstructed_trans_features = []
	reconstructed_subduction_features = []
	unique_pairs_of_rift_name = []
	#output_subduction_positions = pygplates.FeatureCollection()
	while (reconstruction_time >= minimum_reconstruction_time):
		new_subduction_feats[:] = []
		new_rift_feats[:] = []
		new_transform_feats[:] = []
		#find valid oceanic crust features
		oceanic_crust_features_to_be_evaluated[:] = []
		
		for oceanic_ft in oceanic_crust_features:
			oceanic_ft_begin_age,oceanic_ft_end_age = oceanic_ft.get_valid_time()
			#print("oceanic_ft_begin_age,oceanic_ft_end_age",oceanic_ft_begin_age,oceanic_ft_end_age)
			is_included = True
			#print('is_included',is_included)
			# if (oceanic_ft_begin_age < minimum_reconstruction_time or oceanic_ft_end_age > maximum_reconstruction_time):
				# is_included = False
			#ancient oceanic crust features can participate
			if (oceanic_ft_begin_age < minimum_reconstruction_time):
				is_included = False
			if (is_included == True):
				oceanic_crust_features_to_be_evaluated.append(oceanic_ft)
		#print('oceanic_crust_features_to_be_evaluated',len(oceanic_crust_features_to_be_evaluated))
		
		valid_oceanic_crust_features = [oceanic_ft for oceanic_ft in oceanic_crust_features_to_be_evaluated if oceanic_ft.is_valid_at_time(reconstruction_time)]
		print('reconstruction_time',reconstruction_time)
		reconstructed_oceanic_features[:] = []
		reconstructed_sgdu_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(valid_oceanic_crust_features, rotation_model, reconstructed_oceanic_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_oceanic_crust_features, rotation_model, reconstructed_oceanic_features, reconstruction_time, group_with_feature = True)
		#find final reconstruct oceanic crust features
		final_reconstructed_oceanic_feats = []
		temp_final_reconstructed_oceanic_feats = find_final_reconstructed_geometries(reconstructed_oceanic_features, pygplates.PolygonOnSphere)
		
		#check whether oceanic crust features are being subducted
		if (len(temporary_list_of_subduction_feats) > 0):
			reconstructed_subduction_features[:] = []
			valid_subduction_features = [subduction_ft for subduction_ft in temporary_list_of_subduction_feats if subduction_ft.is_valid_at_time(reconstruction_time)]
			if (reference is not None):
				pygplates.reconstruct(valid_subduction_features, rotation_model, reconstructed_subduction_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			else:
				pygplates.reconstruct(valid_subduction_features, rotation_model, reconstructed_subduction_features, reconstruction_time, group_with_feature = True)
			for oc_ft, reconstructed_oc in temp_final_reconstructed_oceanic_feats:
				is_subducted_oc = False
				for subduction_feature, subduction_feature_reconstructed_geometries in reconstructed_subduction_features:
					rep_reconstructed_subduction = subduction_feature_reconstructed_geometries[0].get_reconstructed_geometry()
					if (oc_ft.get_name() == subduction_feature.get_name()):
						dist_btw_oc_and_subduction = pygplates.GeometryOnSphere.distance(reconstructed_oc, rep_reconstructed_subduction)
						if (dist_btw_oc_and_subduction == 0.00):
							is_subducted_oc = True
							for ocean_ft in oceanic_crust_features:
								if (ocean_ft.get_feature_id() == oc_ft.get_feature_id()):
									current_begin_age_of_oc, _ = ocean_ft.get_valid_time()
									ocean_ft.set_valid_time(current_begin_age_of_oc, reconstruction_time)
							break
				if (is_subducted_oc == False):
					final_reconstructed_oceanic_feats.append((oc_ft, reconstructed_oc))
		else:
			final_reconstructed_oceanic_feats = temp_final_reconstructed_oceanic_feats
		print('number of ft in final_reconstructed_oceanic_feats to be evaluated:', len(final_reconstructed_oceanic_feats))
		
		valid_oceanic_crust_features_at_prev_time = [oceanic_ft for oceanic_ft in valid_oceanic_crust_features if oceanic_ft.is_valid_at_time(reconstruction_time+time_interval)]
		
		
		unique_pairs_of_rift_name[:] = []
		for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
			rift_name = oceanic_crust_ft.get_name()
			for other_oceanic_crust_ft, reconstruct_other_ocean in final_reconstructed_oceanic_feats:
				other_rift_name = other_oceanic_crust_ft.get_name()
				# if (rift_name != other_rift_name):
					# pair = rift_name+'$'+other_rift_name
					# rev_pair = other_rift_name+'$'+rift_name
					# if (pair not in unique_pairs_of_rift_name and rev_pair not in unique_pairs_of_rift_name):
						# unique_pairs_of_rift_name.append(pair)
				# if (other_rift_name == rift_name == 'R79174_79175'):
					# print('rift_name',rift_name)
				
				pair = rift_name+'$'+other_rift_name
				rev_pair = other_rift_name+'$'+rift_name
				if (pair not in unique_pairs_of_rift_name and rev_pair not in unique_pairs_of_rift_name):
					unique_pairs_of_rift_name.append(pair)
					# if (other_rift_name == rift_name == 'R79174_79175'):
						# print('included ', rift_name)
		for unique_pair in unique_pairs_of_rift_name:
			splitted_str = unique_pair.split('$')
			first_rift_name = splitted_str[0]
			second_rift_name = splitted_str[1]
			all_first_oceanic_crust_feats = []
			all_second_oceanic_crust_feats = []
			for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
				rift_name = oceanic_crust_ft.get_name()
				if (first_rift_name	!= second_rift_name):
					if (rift_name == first_rift_name):
						all_first_oceanic_crust_feats.append((oceanic_crust_ft, reconstructed_ocean))
					elif (rift_name == second_rift_name):
						all_second_oceanic_crust_feats.append((oceanic_crust_ft, reconstructed_ocean))
				else:
					if (rift_name == first_rift_name):
						all_first_oceanic_crust_feats.append((oceanic_crust_ft, reconstructed_ocean))
						all_second_oceanic_crust_feats.append((oceanic_crust_ft, reconstructed_ocean))
			for first_oc_ft, first_ocean in all_first_oceanic_crust_feats:
				first_oc_old_age, first_oc_yng_age = first_oc_ft.get_valid_time()
				ft_id_first_ft = first_oc_ft.get_feature_id()
				for second_oc_ft, second_ocean in all_second_oceanic_crust_feats:
					if (first_oc_ft.get_reconstruction_plate_id() == second_oc_ft.get_reconstruction_plate_id()):
						continue
					total_stage_rel_rot_of_1_to_2 = find_stage_relative_reconstruction_rotation_(rotation_model, first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id(), float(reconstruction_time)+time_interval, float(reconstruction_time), reference)
					if (total_stage_rel_rot_of_1_to_2 is not None):
						if (total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == True):
							continue
					else:
						continue
					second_oc_old_age, second_oc_yng_age = second_oc_ft.get_valid_time()
					ft_id_second_ft = second_oc_ft.get_feature_id()
					geometry_inside_first = []
					geometry_inside_second = []
					distance = -1.00
					result_of_tectonic_motion = None
					intersection_on_first_oc,intersection_on_second_oc = None,None
					E_pole = None
					
					#already
					
					if (first_oc_old_age <= second_oc_old_age): #keep the first ocean feat because first ocean feat is younger
						distance,intersection_on_first_oc,intersection_on_second_oc = pygplates.GeometryOnSphere.distance(first_ocean, second_ocean, return_closest_positions = True)
						#old
						# if (first_ocean.partition(second_ocean) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
							# first_ocean.partition(second_ocean, partitioned_geometries_inside = geometry_inside, partitioned_geometries_outside = geometry_outside)
						# elif(first_ocean.partition(second_ocean) == pygplates.PolygonOnSphere.PartitionResult.inside):
							# geometry_inside = [second_ocean]
						# else:
							# if (distance == 0.00):
								# geometry_inside.append(intersection_on_first_oc)
						#new
						if (distance == 0.00):
							# geometry_inside.append(intersection_on_first_oc)
							# geometry_inside.append(intersection_on_second_oc)
							first_ocean.partition(second_ocean, partitioned_geometries_inside = geometry_inside_first)
							second_ocean.partition(first_ocean, partitioned_geometries_inside = geometry_inside_second)
						if (len(geometry_inside_first) > 0  and len(geometry_inside_second) > 0 and second_oc_ft.is_valid_at_time(reconstruction_time + time_interval) and first_oc_ft.is_valid_at_time(reconstruction_time + time_interval)):
							#check kinematics
							total_stage_rel_rot_of_1_to_2 = find_stage_relative_reconstruction_rotation_(rotation_model, first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id(), float(reconstruction_time)+time_interval, float(reconstruction_time), reference)
							if (total_stage_rel_rot_of_1_to_2 is not None):
								if (total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == False):
									#stage_rel_E_pole = total_stage_rel_rot_of_1_to_2
									E_pole,angle_rads = total_stage_rel_rot_of_1_to_2.get_euler_pole_and_angle()
									#result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(second_ocean.get_interior_centroid(), first_ocean.get_interior_centroid(), E_pole)
									
									#find the two features at prev time 
									first_oc_prev_time = None
									second_oc_prev_time = None
									reconstructed_prev_oceanic_features[:] = []
									if (reference is not None):
										pygplates.reconstruct([first_oc_ft,second_oc_ft], rotation_model, reconstructed_prev_oceanic_features, reconstruction_time+time_interval, anchor_plate_id = reference, group_with_feature = True)
									else:
										pygplates.reconstruct([first_oc_ft,second_oc_ft], rotation_model, reconstructed_prev_oceanic_features, reconstruction_time+time_interval, group_with_feature = True)
									#find final reconstruct oceanic crust features
									final_reconstructed_prev_oceanic_feats = find_final_reconstructed_geometries(reconstructed_prev_oceanic_features, pygplates.PolygonOnSphere)
									if (len(final_reconstructed_prev_oceanic_feats) == 2):
										_,prev_first_ocean = final_reconstructed_prev_oceanic_feats[0]
										_,prev_second_ocean = final_reconstructed_prev_oceanic_feats[1]
									
										result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_pos_and_angular_vel_vec(prev_first_ocean.get_interior_centroid(), first_ocean.get_interior_centroid(), prev_second_ocean.get_interior_centroid(), second_ocean.get_interior_centroid(), reconstruction_time+time_interval, reconstruction_time)
										diff_rel_dist = pygplates.GeometryOnSphere.distance(prev_second_ocean, prev_first_ocean) - pygplates.GeometryOnSphere.distance(second_ocean, first_ocean)
										if (result_of_tectonic_motion == 'C' and diff_rel_dist > 0):
											#old
											# for new_geom in geometry_inside:
												# new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, new_geom, valid_time = (reconstruction_time,0.00))
												# new_subduction_ft.set_name(first_oc_ft.get_name())
												# new_subduction_ft.set_reconstruction_plate_id(first_oc_ft.get_reconstruction_plate_id())
												# new_subduction_ft.set_description("subduction_zone")
												# if (reference is not None):
													# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
												# else:
													# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
											
											#NEW
											for new_geom in geometry_inside_second:
												#new_oceanic_subduction_zone = 
												new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, new_geom, valid_time = (reconstruction_time,0.00))
												new_subduction_ft.set_name(first_oc_ft.get_name())
												new_subduction_ft.set_reconstruction_plate_id(first_oc_ft.get_reconstruction_plate_id())
												new_subduction_ft.set_description("subduction_zone")
												if (reference is not None):
													pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
												else:
													pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
											
											# if (first_oc_ft.get_name() not in dic_subduction_positions):
												# dic_subduction_positions[first_oc_ft.get_name()] = [new_subduction_ft]
											# else:
												# list_of_current_subduction_feats = dic_subduction_positions[first_oc_ft.get_name()]
												# for temp_sub_ft in list_of_current_subduction_feats:
													# start_temp_sub_ft, end_temp_sub_ft = temp_sub_ft.get_reconstruction_plate_id()
													# if (end_temp_sub_ft < reconstruction_time and start_temp_sub_ft > reconstruction_time):
														# temp_sub_ft.set_valid_time(start_temp_sub_ft, reconstruction_time)
												# dic_subduction_positions[first_oc_ft.get_name()].append(new_subduction_ft)
												new_subduction_feats.append(new_subduction_ft)
											for second_ocean_ft in oceanic_crust_features:
												if (second_ocean_ft.get_feature_id() == ft_id_second_ft):
													second_ocean_ft.set_valid_time(second_oc_old_age, reconstruction_time)
										print('result_of_tectonic_motion',result_of_tectonic_motion)
										if (result_of_tectonic_motion is not None):
											if (result_of_tectonic_motion == 'T'):
												# for new_geom in geometry_inside:
													# new_trans_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, new_geom, valid_time = (reconstruction_time,0.00))
													# new_trans_ft.set_name(first_oc_ft.get_name())
													# new_trans_ft.set_reconstruction_plate_id(first_oc_ft.get_reconstruction_plate_id())
													# new_trans_ft.set_description("transform_fault")
													# if (reference is not None):
														# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time, reference)
													# else:
														# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time)
													# new_transform_feats.append(new_trans_ft)
												for new_geom in geometry_inside_second:
													new_trans_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, new_geom, valid_time = (reconstruction_time,0.00))
													new_trans_ft.set_name(first_oc_ft.get_name())
													new_trans_ft.set_reconstruction_plate_id(first_oc_ft.get_reconstruction_plate_id())
													new_trans_ft.set_description("transform_fault")
													if (reference is not None):
														pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time, reference)
													else:
														pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time)
													new_transform_feats.append(new_trans_ft)
											elif (result_of_tectonic_motion == 'D'):
												final_approx_mid_point = find_the_mid_of_two_PointOnSphere(intersection_on_first_oc,intersection_on_second_oc)
												if (distance == 0.00):
													first_ocean_point = first_ocean.get_interior_centroid()
													second_ocean_point = second_ocean.get_interior_centroid()
												elif (distance > 0.00):
													first_ocean_point = intersection_on_first_oc
													second_ocean_point = intersection_on_second_oc
												approx_mid_point = find_the_mid_of_two_PointOnSphere(first_ocean_point,second_ocean_point)
												# for check_oc_ft, check_oc_polygon in all_first_oceanic_crust_feats:
													# if (check_oc_polygon.is_point_in_polygon(final_approx_mid_point)):
														# result_of_tectonic_motion = 'T'
														# break
												# for check_oc_ft, check_oc_polygon in all_second_oceanic_crust_feats:
													# if (check_oc_polygon.is_point_in_polygon(final_approx_mid_point)):
														# result_of_tectonic_motion = 'T'
														# break
									
												#create an arc
												final_approx_mid_point,mid_pt_order = quickly_derive_mid_point_and_order_of_mid_point_from_two_divergent_points(first_ocean_point,second_ocean_point,E_pole)
												mid_pt_order = round(mid_pt_order,2)
												temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
												normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
												left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, first_ocean_point, second_ocean_point, first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id())
												name = unique_pair
												rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, final_approx_mid_point, name = name, valid_time = (reconstruction_time,0.00))
												if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None) or (left_gduid == first_oc_ft.get_reconstruction_plate_id() and right_gduid == second_oc_ft.get_reconstruction_plate_id())):
													rift_point_ft.set_left_plate(first_oc_ft.get_reconstruction_plate_id())
													rift_point_ft.set_right_plate(second_oc_ft.get_reconstruction_plate_id())
													list_of_oceanic_records.append((reconstruction_time, unique_pair, mid_pt_order, first_oc_ft.get_name(), first_oc_ft.get_reconstruction_plate_id(), first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_name(), second_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id()))
												else:
													rift_point_ft.set_left_plate(left_gduid)
													rift_point_ft.set_right_plate(right_gduid)
													list_of_oceanic_records.append((reconstruction_time,unique_pair, mid_pt_order, second_oc_ft.get_name(), second_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id(), first_oc_ft.get_name(), first_oc_ft.get_reconstruction_plate_id(), first_oc_ft.get_reconstruction_plate_id()))
												rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
												if (reference is None):
													pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
												else:
													pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
												rift_point_ft.set_description(str(mid_pt_order))
												new_rift_feats.append(rift_point_ft)
												print('len(new_rift_feats)',len(new_rift_feats))
									
						# elif (len(geometry_inside) > 0):
							# #check kinematics
							# total_stage_rel_rot_of_1_to_2 = find_stage_relative_reconstruction_rotation_(rotation_model, first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id(), float(reconstruction_time)+time_interval, float(reconstruction_time), reference)
							# if (total_stage_rel_rot_of_1_to_2 is not None):
								# if (total_stage_rel_rot_of_1_to_2.represents_identity_rotation() == False):
									# #stage_rel_E_pole = total_stage_rel_rot_of_1_to_2
									# E_pole,angle_rads = total_stage_rel_rot_of_1_to_2.get_euler_pole_and_angle()
									# result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(second_ocean.get_interior_centroid(), first_ocean.get_interior_centroid(), E_pole)
									# if (result_of_tectonic_motion is not None):
										# if (result_of_tectonic_motion == 'T'):
											# for new_geom in geometry_inside:
												# new_trans_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, new_geom, valid_time = (reconstruction_time,0.00))
												# new_trans_ft.set_name(first_oc_ft.get_name())
												# new_trans_ft.set_reconstruction_plate_id(first_oc_ft.get_reconstruction_plate_id())
												# new_trans_ft.set_description("transform_fault")
												# if (reference is not None):
													# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time, reference)
												# else:
													# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time)
												# new_transform_feats.append(new_trans_ft)
										# elif (result_of_tectonic_motion == 'D'):
											# final_approx_mid_point = find_the_mid_of_two_PointOnSphere(intersection_on_first_oc,intersection_on_second_oc)
											# if (distance == 0.00):
												# first_ocean_point = first_ocean.get_interior_centroid()
												# second_ocean_point = second_ocean.get_interior_centroid()
											# elif (distance > 0.00):
												# first_ocean_point = intersection_on_first_oc
												# second_ocean_point = intersection_on_second_oc
											# approx_mid_point = find_the_mid_of_two_PointOnSphere(first_ocean_point,second_ocean_point)
											# # for check_oc_ft, check_oc_polygon in all_first_oceanic_crust_feats:
												# # if (check_oc_polygon.is_point_in_polygon(final_approx_mid_point)):
													# # result_of_tectonic_motion = 'T'
													# # break
											# # for check_oc_ft, check_oc_polygon in all_second_oceanic_crust_feats:
												# # if (check_oc_polygon.is_point_in_polygon(final_approx_mid_point)):
													# # result_of_tectonic_motion = 'T'
													# # break
											# if (result_of_tectonic_motion == 'D'):
												# #create an arc
												# temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
												# normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
												# left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, first_ocean_point, second_ocean_point, first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id())
												# name = unique_pair
												# rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, final_approx_mid_point, name = name, valid_time = (reconstruction_time,0.00))
												# if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
													# rift_point_ft.set_left_plate(first_oc_ft.get_reconstruction_plate_id())
													# rift_point_ft.set_right_plate(second_oc_ft.get_reconstruction_plate_id())
												# else:
													# rift_point_ft.set_left_plate(left_gduid)
													# rift_point_ft.set_right_plate(right_gduid)
												# rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
												# if (reference is None):
													# pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
												# else:
													# pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
												# new_rift_feats.append(rift_point_ft)
												# print('len(new_rift_feats)',len(new_rift_feats))
											# else:
												# new_trans_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, final_approx_mid_point, valid_time = (reconstruction_time,0.00))
												# new_trans_ft.set_name(first_oc_ft.get_name())
												# new_trans_ft.set_reconstruction_plate_id(first_oc_ft.get_reconstruction_plate_id())
												# new_trans_ft.set_description("transform_fault")
												# if (reference is not None):
													# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time, reference)
												# else:
													# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time)
												# new_transform_feats.append(new_trans_ft)
					elif (first_oc_old_age > second_oc_old_age): #keep the second ocean feat
						distance,intersection_on_first_oc,intersection_on_second_oc = pygplates.GeometryOnSphere.distance(first_ocean, second_ocean, return_closest_positions = True)
						#old
						# if (second_ocean.partition(first_ocean) == pygplates.PolygonOnSphere.PartitionResult.intersecting):
							# second_ocean.partition(first_ocean, partitioned_geometries_inside = geometry_inside, partitioned_geometries_outside = geometry_outside)
						# elif (second_ocean.partition(first_ocean) == pygplates.PolygonOnSphere.PartitionResult.inside):
							# geometry_inside = [first_ocean]
						# else:
							# #distance,intersection_on_first_oc,intersection_on_second_oc = pygplates.GeometryOnSphere.distance(first_ocean, second_ocean, return_closest_positions = True)
							# if (distance == 0.00):
								# geometry_inside.append(intersection_on_first_oc)
						#new
						if (distance == 0.00):
							# geometry_inside.append(intersection_on_first_oc)
							# geometry_inside.append(intersection_on_second_oc)
							first_ocean.partition(second_ocean, partitioned_geometries_inside = geometry_inside_first)
							second_ocean.partition(first_ocean, partitioned_geometries_inside = geometry_inside_second)
						if (len(geometry_inside_first) > 0 and len(geometry_inside_second) > 0 and second_oc_ft.is_valid_at_time(reconstruction_time + time_interval) and first_oc_ft.is_valid_at_time(reconstruction_time + time_interval)):
							#check kinematics
							# total_stage_rel_rot_of_2_to_1 = find_stage_relative_reconstruction_rotation_(rotation_model, second_oc_ft.get_reconstruction_plate_id(), first_oc_ft.get_reconstruction_plate_id(), float(reconstruction_time)+time_interval, float(reconstruction_time), reference)
							
							# for new_geom in geometry_inside:
								# new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, new_geom, valid_time = (reconstruction_time,0.00))
								# new_subduction_ft.set_name(second_oc_ft.get_name())
								# new_subduction_ft.set_reconstruction_plate_id(second_oc_ft.get_reconstruction_plate_id())
								# if (reference is not None):
									# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
								# else:
									# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
								# output_subduction_positions.add(new_subduction_ft)
							# for first_ocean_ft in valid_oceanic_crust_features:
								# if (first_ocean_ft.get_feature_id() == ft_id_first_ft):
									# first_ocean_ft.set_valid_time(first_oc_old_age, reconstruction_time)
							
							#check kinematics
							total_stage_rel_rot_of_2_to_1 = find_stage_relative_reconstruction_rotation_(rotation_model, second_oc_ft.get_reconstruction_plate_id(), first_oc_ft.get_reconstruction_plate_id(), float(reconstruction_time)+time_interval, float(reconstruction_time), reference)
							if (total_stage_rel_rot_of_2_to_1 is not None):
								if (total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == False):
									#stage_rel_E_pole = total_stage_rel_rot_of_2_to_1
									E_pole,angle_rads = total_stage_rel_rot_of_2_to_1.get_euler_pole_and_angle()
									#result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(first_ocean.get_interior_centroid(), second_ocean.get_interior_centroid(), E_pole)
									
									#find the two features at prev time 
									first_oc_prev_time = None
									second_oc_prev_time = None
									reconstructed_prev_oceanic_features[:] = []
									if (reference is not None):
										pygplates.reconstruct([first_oc_ft,second_oc_ft], rotation_model, reconstructed_prev_oceanic_features, reconstruction_time+time_interval, anchor_plate_id = reference, group_with_feature = True)
									else:
										pygplates.reconstruct([first_oc_ft,second_oc_ft], rotation_model, reconstructed_prev_oceanic_features, reconstruction_time+time_interval, group_with_feature = True)
									#find final reconstruct oceanic crust features
									final_reconstructed_prev_oceanic_feats = find_final_reconstructed_geometries(reconstructed_prev_oceanic_features, pygplates.PolygonOnSphere)
									#print(reconstruction_time, reconstruction_time+time_interval)
									#print(first_oc_ft.get_feature_id().get_string(),first_oc_ft.get_valid_time())
									#print(second_oc_ft.get_feature_id().get_string(),second_oc_ft.get_valid_time())
									if (len(final_reconstructed_prev_oceanic_feats) == 2):
										
										_,prev_first_ocean = final_reconstructed_prev_oceanic_feats[0]
										_,prev_second_ocean = final_reconstructed_prev_oceanic_feats[1]
									
										result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_pos_and_angular_vel_vec(prev_first_ocean.get_interior_centroid(), first_ocean.get_interior_centroid(), prev_second_ocean.get_interior_centroid(), second_ocean.get_interior_centroid(), reconstruction_time+time_interval, reconstruction_time)
										diff_rel_dist = pygplates.GeometryOnSphere.distance(prev_second_ocean, prev_first_ocean) - pygplates.GeometryOnSphere.distance(second_ocean, first_ocean)
										if (result_of_tectonic_motion == 'C' and diff_rel_dist > 0):
											for new_geom in geometry_inside_first:
												new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, new_geom, valid_time = (reconstruction_time,0.00))
												new_subduction_ft.set_name(second_oc_ft.get_name())
												new_subduction_ft.set_reconstruction_plate_id(second_oc_ft.get_reconstruction_plate_id())
												new_subduction_ft.set_description("subduction_zone")
												if (reference is not None):
													pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
												else:
													pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
												# if (first_oc_ft.get_name() not in dic_subduction_positions):
													# dic_subduction_positions[first_oc_ft.get_name()] = [new_subduction_ft]
												# else:
													# list_of_current_subduction_feats = dic_subduction_positions[first_oc_ft.get_name()]
													# for temp_sub_ft in list_of_current_subduction_feats:
														# start_temp_sub_ft, end_temp_sub_ft = temp_sub_ft.get_reconstruction_plate_id()
														# if (end_temp_sub_ft < reconstruction_time and start_temp_sub_ft > reconstruction_time):
														# temp_sub_ft.set_valid_time(start_temp_sub_ft, reconstruction_time)
													# dic_subduction_positions[first_oc_ft.get_name()].append(new_subduction_ft)
												new_subduction_feats.append(new_subduction_ft)
											for first_ocean_ft in oceanic_crust_features:
												if (first_ocean_ft.get_feature_id() == ft_id_first_ft):
													first_ocean_ft.set_valid_time(first_oc_old_age, reconstruction_time)
										if (result_of_tectonic_motion is not None):
											if (result_of_tectonic_motion == 'D'):
												final_approx_mid_point = find_the_mid_of_two_PointOnSphere(intersection_on_first_oc,intersection_on_second_oc)
												first_ocean_point,second_ocean_point = None, None
												if (distance == 0.00):
													first_ocean_point = first_ocean.get_interior_centroid()
													second_ocean_point = second_ocean.get_interior_centroid()
												elif (distance > 0.00):
													first_ocean_point = intersection_on_first_oc
													second_ocean_point = intersection_on_second_oc
												approx_mid_point = find_the_mid_of_two_PointOnSphere(first_ocean_point,second_ocean_point)
												#for check_oc_ft, check_oc_polygon in all_first_oceanic_crust_feats:
													# if (check_oc_polygon.is_point_in_polygon(final_approx_mid_point)):
														# result_of_tectonic_motion = 'T'
														# break
												# for check_oc_ft, check_oc_polygon in all_second_oceanic_crust_feats:
													# if (check_oc_polygon.is_point_in_polygon(final_approx_mid_point)):
														# result_of_tectonic_motion = 'T'
														# break
												#create an arc
												final_approx_mid_point,mid_pt_order = quickly_derive_mid_point_and_order_of_mid_point_from_two_divergent_points(first_ocean_point,second_ocean_point,E_pole)
												mid_pt_order = round(mid_pt_order,2)
												temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
												normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
												left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, first_ocean_point, second_ocean_point, first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id())
												name = unique_pair
												rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, final_approx_mid_point, name = name, valid_time = (reconstruction_time,0.00))
												if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None) or (left_gduid == first_oc_ft.get_reconstruction_plate_id() and right_gduid == second_oc_ft.get_reconstruction_plate_id())):
													rift_point_ft.set_left_plate(first_oc_ft.get_reconstruction_plate_id())
													rift_point_ft.set_right_plate(second_oc_ft.get_reconstruction_plate_id())
													list_of_oceanic_records.append((reconstruction_time, unique_pair, mid_pt_order, first_oc_ft.get_name(), first_oc_ft.get_reconstruction_plate_id(), first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_name(), second_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id()))
												else:
													rift_point_ft.set_left_plate(left_gduid)
													rift_point_ft.set_right_plate(right_gduid)
													list_of_oceanic_records.append((reconstruction_time,unique_pair, mid_pt_order, second_oc_ft.get_name(), second_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id(), first_oc_ft.get_name(), first_oc_ft.get_reconstruction_plate_id(), first_oc_ft.get_reconstruction_plate_id()))
												rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
												if (reference is None):
													pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
												else:
													pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
												rift_point_ft.set_description(str(mid_pt_order))
												new_rift_feats.append(rift_point_ft)
												print('len(new_rift_feats)',len(new_rift_feats))
												
												
												
											elif (result_of_tectonic_motion == 'T'):
												for new_geom in geometry_inside_first:
													new_trans_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, new_geom, valid_time = (reconstruction_time,0.00))
													new_trans_ft.set_name(second_oc_ft.get_name())
													new_trans_ft.set_reconstruction_plate_id(second_oc_ft.get_reconstruction_plate_id())
													new_trans_ft.set_description("transform_fault")
													if (reference is not None):
														pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time, reference)
													else:
														pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time)
													new_transform_feats.append(new_trans_ft)
						# elif (len(geometry_inside) > 0):
							# if (total_stage_rel_rot_of_2_to_1 is not None):
								# if (total_stage_rel_rot_of_2_to_1.represents_identity_rotation() == False):
									# #stage_rel_E_pole = total_stage_rel_rot_of_2_to_1
									# E_pole,angle_rads = total_stage_rel_rot_of_2_to_1.get_euler_pole_and_angle()
									# result_of_tectonic_motion = tectonic_motion.evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(first_ocean.get_interior_centroid(), second_ocean.get_interior_centroid(), E_pole)
									# if (result_of_tectonic_motion is not None):
										# if (result_of_tectonic_motion == 'D'):
											# final_approx_mid_point = find_the_mid_of_two_PointOnSphere(intersection_on_first_oc,intersection_on_second_oc)
											# first_ocean_point,second_ocean_point = None, None
											# if (distance == 0.00):
												# first_ocean_point = first_ocean.get_interior_centroid()
												# second_ocean_point = second_ocean.get_interior_centroid()
											# elif (distance > 0.00):
												# first_ocean_point = intersection_on_first_oc
												# second_ocean_point = intersection_on_second_oc
											# approx_mid_point = find_the_mid_of_two_PointOnSphere(first_ocean_point,second_ocean_point)
											# # for check_oc_ft, check_oc_polygon in all_first_oceanic_crust_feats:
												# # if (check_oc_polygon.is_point_in_polygon(final_approx_mid_point)):
													# # result_of_tectonic_motion = 'T'
													# # break
											# # for check_oc_ft, check_oc_polygon in all_second_oceanic_crust_feats:
												# # if (check_oc_polygon.is_point_in_polygon(final_approx_mid_point)):
													# # result_of_tectonic_motion = 'T'
													# # break
											
											# if (result_of_tectonic_motion == 'D'):
												# #create an arc
												# temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
												# normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
												# left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, first_ocean_point, second_ocean_point, first_oc_ft.get_reconstruction_plate_id(), second_oc_ft.get_reconstruction_plate_id())
												# name = unique_pair
												# rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, final_approx_mid_point, name = name, valid_time = (reconstruction_time,0.00))
												# if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
													# rift_point_ft.set_left_plate(first_oc_ft.get_reconstruction_plate_id())
													# rift_point_ft.set_right_plate(second_oc_ft.get_reconstruction_plate_id())
												# else:
													# rift_point_ft.set_left_plate(left_gduid)
													# rift_point_ft.set_right_plate(right_gduid)
												# rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
												# if (reference is None):
													# pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
												# else:
													# pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
												# new_rift_feats.append(rift_point_ft)
												# print('len(new_rift_feats)',len(new_rift_feats))
											# else:
												# new_trans_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, final_approx_mid_point, valid_time = (reconstruction_time,0.00))
												# new_trans_ft.set_name(second_oc_ft.get_name())
												# new_trans_ft.set_reconstruction_plate_id(second_oc_ft.get_reconstruction_plate_id())
												# new_trans_ft.set_description("transform_fault")
												# if (reference is not None):
													# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time, reference)
												# else:
													# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time)
												# new_transform_feats.append(new_trans_ft)
										# else: #if (result_of_tectonic_motion == 'T'):
											# for new_geom in geometry_inside:
												# new_trans_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, new_geom, valid_time = (reconstruction_time,0.00))
												# new_trans_ft.set_name(second_oc_ft.get_name())
												# new_trans_ft.set_reconstruction_plate_id(second_oc_ft.get_reconstruction_plate_id())
												# new_trans_ft.set_description("transform_fault")
												# if (reference is not None):
													# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time, reference)
												# else:
													# pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time)
												# new_transform_feats.append(new_trans_ft)
		#find valid sgdu crust features
		valid_sgdu_features = [sgdu_ft for sgdu_ft in sgdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
		reconstructed_sgdu_features[:] = []
		reconstructed_rift_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_sgdu_features, rotation_model, reconstructed_sgdu_features, reconstruction_time, group_with_feature = True)
		#find final reconstruct sgdu crust features
		final_reconstructed_sgdu_feats = find_final_reconstructed_geometries(reconstructed_sgdu_features, pygplates.PolygonOnSphere)
		
		valid_rift_point_features = [pt_ft for pt_ft in temporary_list_of_rift_feats if pt_ft.is_valid_at_time(reconstruction_time)]
		if (reference is not None):
			pygplates.reconstruct(valid_rift_point_features, rotation_model, reconstructed_rift_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_rift_point_features, rotation_model, reconstructed_rift_features, reconstruction_time, group_with_feature = True)
		#find final reconstruct rift pt features
		final_reconstructed_rift_feats = find_final_reconstructed_geometries(reconstructed_rift_features, pygplates.PointOnSphere)
		remained_rift_point_features = []
		for rift_point_ft, rift_point in final_reconstructed_rift_feats:
			is_valid = True
			for sgdu_ft, sgdu in final_reconstructed_sgdu_feats:
				if (sgdu.is_point_in_polygon(rift_point)):
					current_rift_begin, current_rift_end = rift_point_ft.get_valid_time()
					rift_point_ft.set_valid_time(current_rift_begin,reconstruction_time)
					output_rift_point_features.add(rift_point_ft)
					is_valid = False
					break
			if (is_valid == True):
				#remained_rift_point_features.append((rift_point_ft, rift_point))
				remained_rift_point_features.append(rift_point_ft)
		# final_remained_rift_point_features = []
		# for rift_point_ft, rift_point in remained_rift_point_features:
			# is_valid = True
			# #testing: no longer take rift point feature to be subduction feature
			# # for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
				# # if (reconstructed_ocean.is_point_in_polygon(rift_point)):
					# # current_rift_begin, current_rift_end = rift_point_ft.get_valid_time()
					# # rift_point_ft.set_valid_time(current_rift_begin,reconstruction_time)
					# # output_rift_point_features.add(rift_point_ft)
					# # is_valid = False
					# # break
			# if (is_valid == True):
				# final_remained_rift_point_features.append(rift_point_ft)
			# else:
				# new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, rift_point, valid_time = (reconstruction_time,0.00))
				# new_subduction_ft.set_name(oceanic_crust_ft.get_name())
				# new_subduction_ft.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
				# new_subduction_ft.set_description("subduction_zone")
				# if (reference is not None):
					# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
				# else:
					# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
				# new_subduction_feats.append(new_subduction_ft)
		# temporary_list_of_rift_feats = final_remained_rift_point_features
		
		temporary_list_of_rift_feats = remained_rift_point_features
		for new_rift_ft in new_rift_feats:
			temporary_list_of_rift_feats.append(new_rift_ft.clone())
		
		
		# reconstructed_subduction_features[:] = []
		# valid_subduction_features = [subduction_ft for subduction_ft in temporary_list_of_subduction_feats if subduction_ft.is_valid_at_time(reconstruction_time)]
		# if (reference is not None):
			# pygplates.reconstruct(valid_subduction_features, rotation_model, reconstructed_subduction_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		# else:
			# pygplates.reconstruct(valid_subduction_features, rotation_model, reconstructed_subduction_features, reconstruction_time, group_with_feature = True)
		
		remained_subduction_features = []
		for subduction_feature, subduction_feature_reconstructed_geometries in reconstructed_subduction_features:
			is_valid = True
			for feature_reconstructed_geometry in subduction_feature_reconstructed_geometries:
				for sgdu_ft, sgdu in final_reconstructed_sgdu_feats:
					if (sgdu.partition(feature_reconstructed_geometry.get_reconstructed_geometry()) != pygplates.PolygonOnSphere.PartitionResult.outside):
						current_subd_begin, current_sub_end = subduction_feature.get_valid_time()
						subduction_feature.set_valid_time(current_subd_begin,reconstruction_time)
						output_subducted_ocean_feats.add(subduction_feature)
						is_valid = False
						break
				if (is_valid == False):
					break
			if (is_valid == True):
				remained_subduction_features.append(subduction_feature)
		temporary_list_of_subduction_feats = remained_subduction_features
		for subduction_ft in new_subduction_feats:
			temporary_list_of_subduction_feats.append(subduction_ft.clone())
		
		valid_transform_features = [trans_ft for trans_ft in temporary_list_of_transform_feats if trans_ft.is_valid_at_time(reconstruction_time)]
		reconstructed_trans_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(valid_transform_features, rotation_model, reconstructed_trans_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_transform_features, rotation_model, reconstructed_trans_features, reconstruction_time, group_with_feature = True)
		#find final reconstruct trans pt features
		final_reconstructed_trans_feats = find_final_reconstructed_geometries(reconstructed_trans_features, pygplates.PointOnSphere)
		remained_transform_features = []
		for trans_feature, trans_feature_reconstructed_geometry in final_reconstructed_trans_feats:
			is_valid = True
			for sgdu_ft, sgdu in final_reconstructed_sgdu_feats:
				if (sgdu.partition(trans_feature_reconstructed_geometry) != pygplates.PolygonOnSphere.PartitionResult.outside):
					current_trans_begin, current_trans_end = trans_feature.get_valid_time()
					trans_feature.set_valid_time(current_trans_begin,reconstruction_time)
					output_trans_feats.add(trans_feature)
					is_valid = False
					break
			if (is_valid == True):
				#remained_transform_features.append((trans_feature, trans_feature_reconstructed_geometry))
				remained_transform_features.append(trans_feature)
		# final_remained_transform_features = []
		# for trans_point_ft, trans_point in remained_transform_features:
			# is_valid = True
			# #testing: no longer take transform point feature to be subduction feature
			# # for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
				# # if (reconstructed_ocean.is_point_in_polygon(trans_point)):
					# # current_rift_begin, current_rift_end = trans_point_ft.get_valid_time()
					# # trans_point_ft.set_valid_time(current_rift_begin,reconstruction_time)
					# # output_trans_feats.add(trans_point_ft)
					# # is_valid = False
					# # break
			# if (is_valid == True):
				# final_remained_transform_features.append(trans_point_ft)
			# else:
				# new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, trans_point, valid_time = (reconstruction_time,0.00))
				# new_subduction_ft.set_name(oceanic_crust_ft.get_name())
				# new_subduction_ft.set_reconstruction_plate_id(oceanic_crust_ft.get_reconstruction_plate_id())
				# new_subduction_ft.set_description("subduction_zone")
				# if (reference is not None):
					# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
				# else:
					# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
				# new_subduction_feats.append(new_subduction_ft)
		# temporary_list_of_transform_feats = final_remained_transform_features
		
		temporary_list_of_transform_feats = remained_transform_features
		for new_trans_ft in new_transform_feats:
			temporary_list_of_transform_feats.append(new_trans_ft.clone())
		reconstruction_time = reconstruction_time - time_interval
	
	if (len(temporary_list_of_rift_feats) > 0):
		for rift_pt_ft in temporary_list_of_rift_feats:
			output_rift_point_features.add(rift_pt_ft)
	if (len(temporary_list_of_subduction_feats) > 0):
		for sub_pt_ft in temporary_list_of_subduction_feats:
			output_subducted_ocean_feats.add(sub_pt_ft)
	if (len(temporary_list_of_transform_feats) > 0):
		for trans_pt_ft in temporary_list_of_transform_feats:
			output_trans_feats.add(trans_pt_ft)
	output_subducted_ocean_feats.write("oceanic_subduction_features_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
	oceanic_crust_features.write("remained_ocean_feat_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
	output_rift_point_features.write("oceanic_rift_features_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
	output_trans_feats.write("oceanic_transform_features_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
	
	#list_of_oceanic_records.append((start_div,name,smallest_circle_angular_radius_degrees, gdu_line_ft_2.get_shapefile_attribute('POLYLID'), gdu_line_ft_2.get_reconstruction_plate_id(), child_repgduid_2, gdu_line_ft_1.get_shapefile_attribute('POLYLID'), gdu_line_ft_1.get_reconstruction_plate_id(), child_repgduid_1))
	output_dataframe = pd.DataFrame.from_records(list_of_oceanic_records, columns = ['start_div','rift_name','order','lpolylid','left_gdu','lrepgduid','rpolylid','right_gdu','rrepgduid'])
	filename = 'rift_oceanic_point_features_records_for_'+modelname+'_'+yearmonthday+'.csv'
	output_dataframe.to_csv(filename,index=False)

def evaluate_oceanic_crust_features_with_plate_boundary_zone(oceanic_crust_features, super_gdu_features, plate_boundary_zone_features, records_of_kin_line_feats_from_div, rotation_model, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, reference, modelname, yearmonthday):
	# oceanic_crust_features_to_be_evaluated = pygplates.FeatureCollection()
	# for oceanic_ft in oceanic_crust_features:
		# oceanic_ft_begin_age,oceanic_ft_end_age = oceanic_ft.get_valid_time()
		# is_included = True
		# if (oceanic_ft_begin_age < minimum_reconstruction_time or oceanic_ft_end_age > maximum_reconstruction_time):
			# is_included = False
		# if (is_included == True):
			# oceanic_crust_features_to_be_evaluated.add(oceanic_ft)
	
	output_dic = {'reconstruction_time':[],'polylid':[],'ocean':[],'type':[], 'dot_prod':[], 'from_time':[], 'to_time':[]}
	
	#from_time,to_time,type_kin,polylid1,polylid2,fid1,fid2
	kinematic_line_from_div_df = pd.read_csv(records_of_kin_line_feats_from_div, delimiter=',', header = 0)
	
	output_rift_point_features = pygplates.FeatureCollection()
	
	oceanic_crust_features_to_be_evaluated = oceanic_crust_features
	
	reconstruction_time = maximum_reconstruction_time
	reconstructed_oceanic_features = []
	reconstructed_bdn_features = []
	reconstructed_subduction_features = []
	reconstructed_supergdu_features = []
	valid_plate_bdn_zone_features = []
	unique_pairs_of_rift_name = []
	dic_subduction_zone = {}
	subduction_zone_features = []
	valid_supergdu_features = []
	output_subduction_zones = pygplates.FeatureCollection()
	while (reconstruction_time >= minimum_reconstruction_time):
		valid_plate_bdn_zone_features[:] = []
		subduction_zone_features[:] = []
		valid_supergdu_features[:] = []
		valid_supergdu_features = [sgdu_ft for sgdu_ft in super_gdu_features if sgdu_ft.is_valid_at_time(reconstruction_time)]
		#find valid oceanic crust features
		valid_oceanic_crust_features = [oceanic_ft for oceanic_ft in oceanic_crust_features_to_be_evaluated if oceanic_ft.is_valid_at_time(reconstruction_time)]
		for bdn_ft in plate_boundary_zone_features:
			if (bdn_ft.is_valid_at_time(reconstruction_time)):
				if (bdn_ft.get_name() not in dic_subduction_zone):
					valid_plate_bdn_zone_features.append(bdn_ft)
				# else:
					# subduction_ft = dic_subduction_zone[bdn_ft.get_name()]
					# subduction_zone_features.append(subduction_ft)
				else:
					subduction_ft = dic_subduction_zone[bdn_ft.get_name()]
					if (subduction_ft.is_valid_at_time(reconstruction_time) == False):
						valid_plate_bdn_zone_features.append(bdn_ft)
						output_subduction_zones.add(subduction_ft.clone())
						del dic_subduction_zone[bdn_ft.get_name()]
		
		for bdn_name in dic_subduction_zone:
			subduction_ft = dic_subduction_zone[bdn_name]
			if (subduction_ft.is_valid_at_time(reconstruction_time) == True):
				subduction_zone_features.append(subduction_ft)
		
		reconstructed_oceanic_features[:] = []
		reconstructed_bdn_features[:] = []
		reconstructed_subduction_features[:] = []
		reconstructed_supergdu_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_supergdu_features,reconstruction_time,anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(valid_oceanic_crust_features, rotation_model, reconstructed_oceanic_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(valid_plate_bdn_zone_features, rotation_model, reconstructed_bdn_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(subduction_zone_features, rotation_model, reconstructed_subduction_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_supergdu_features,rotation_model,reconstructed_supergdu_features,reconstruction_time,group_with_feature = True)
			pygplates.reconstruct(valid_oceanic_crust_features, rotation_model, reconstructed_oceanic_features, reconstruction_time, group_with_feature = True)
			pygplates.reconstruct(valid_plate_bdn_zone_features, rotation_model, reconstructed_bdn_features, reconstruction_time, group_with_feature = True)
			pygplates.reconstruct(subduction_zone_features, rotation_model, reconstructed_subduction_features, reconstruction_time, group_with_feature = True)
		#find final reconstruct oceanic crust features
		final_reconstructed_supergdu_features = find_final_reconstructed_geometries(reconstructed_supergdu_features, pygplates.PolygonOnSphere)
		final_reconstructed_oceanic_feats = find_final_reconstructed_geometries(reconstructed_oceanic_features, pygplates.PolygonOnSphere)
		final_reconstructed_plate_bdn_zone = find_final_reconstructed_geometries(reconstructed_bdn_features, pygplates.PolylineOnSphere)
		final_reconstructed_subduction_zone = find_final_reconstructed_geometries(reconstructed_subduction_features, pygplates.PolylineOnSphere)
		for plate_bdn_ft, bdn in final_reconstructed_plate_bdn_zone:
			fixed_plate_id = plate_bdn_ft.get_reconstruction_plate_id()
			_,end_age_of_plate_bdn_zone = plate_bdn_ft.get_valid_time()
			# for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
				# moving_plate_id = oceanic_crust_ft.get_reconstruction_plate_id()
				# rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, reconstruction_time+time_interval, reconstruction_time, reference)
				# if (rel_stage_rot is not None):
					# if (rel_stage_rot.represents_identity_rotation() == False):
						# closest_rad_dist,pt_on_plate_bdn,pt_on_oceanic_crust = pygplates.GeometryOnSphere.distance(bdn, reconstructed_ocean, return_closest_positions = True)
						# closest_km_dist = -1.00
						# if (closest_rad_dist == 0.00):
							# closest_km_dist = 0.00
							# break
						# else:
							# lat_plate_bdn,lon_plate_bdn = pt_on_plate_bdn.to_lat_lon()
							# lat_ocean_crust,lon_ocean_crust = pt_on_oceanic_crust.to_lat_lon()
							# closest_km_dist = calculate_distance_km_between_two_points_from_haversine_formula(lat_plate_bdn,lon_plate_bdn,lat_ocean_crust,lon_ocean_crust)
						# if (closest_km_dist >= 0.00 and closest_km_dist <= 150.00):
							# new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, bdn, valid_time = (reconstruction_time,end_age_of_plate_bdn_zone))
							# new_subduction_ft.set_name(plate_bdn_ft.get_name())
							# new_subduction_ft.set_reconstruction_plate_id(plate_bdn_ft.get_reconstruction_plate_id())
							# oldest_age_of_oc_ft,_ = oceanic_crust_ft.get_valid_time()
							# name_of_oc_ft = oceanic_crust_ft.get_name()+"+"+str(oldest_age_of_oc_ft)
							# new_subduction_ft.set_description(name_of_oc_ft)
							# if (reference is not None):
								# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
							# else:
								# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
							# dic_subduction_zone[new_subduction_ft.get_name()] = new_subduction_ft
							# break
			closest_km_dist = -1.00 #find the closest oceanic crust features
			closest_ocean_crust_ft, closest_ocean = None, None
			closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust = None, None
			final_stage_of_rot = None
			for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
				moving_plate_id = oceanic_crust_ft.get_reconstruction_plate_id()
				rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, reconstruction_time+time_interval, reconstruction_time, reference)
				if (rel_stage_rot is not None):
					if (rel_stage_rot.represents_identity_rotation() == False):
						closest_rad_dist,pt_on_plate_bdn,pt_on_oceanic_crust = pygplates.GeometryOnSphere.distance(bdn, reconstructed_ocean, return_closest_positions = True)
						if (closest_rad_dist == 0.00):
							closest_km_dist = 0.00
							closest_ocean_crust_ft, closest_ocean = oceanic_crust_ft, reconstructed_ocean
							closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust = pt_on_plate_bdn,pt_on_oceanic_crust
							final_stage_of_rot = rel_stage_rot
							break
						else:
							lat_plate_bdn,lon_plate_bdn = pt_on_plate_bdn.to_lat_lon()
							lat_ocean_crust,lon_ocean_crust = pt_on_oceanic_crust.to_lat_lon()
							new_km_dist = calculate_distance_km_between_two_points_from_haversine_formula(lat_plate_bdn,lon_plate_bdn,lat_ocean_crust,lon_ocean_crust)
							if (closest_km_dist > -1.00 and closest_km_dist > new_km_dist):
								closest_km_dist = new_km_dist
								closest_ocean_crust_ft, closest_ocean = oceanic_crust_ft, reconstructed_ocean
								closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust = pt_on_plate_bdn,pt_on_oceanic_crust
								final_stage_of_rot = rel_stage_rot
							elif (closest_km_dist == -1.00):
								closest_km_dist = new_km_dist
								closest_ocean_crust_ft, closest_ocean = oceanic_crust_ft, reconstructed_ocean
								closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust = pt_on_plate_bdn,pt_on_oceanic_crust
								final_stage_of_rot = rel_stage_rot
			
			if (closest_km_dist > 0.00):
				is_valid = True
				#temp_polyline = pygplates.PolylineOnSphere([closest_pt_on_plate_bdn, closest_pt_on_oceanic_crust])
				#find_mid_point
				mid_point =  find_the_mid_of_two_PointOnSphere(closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust)
				for sgdu_ft, reconstructed_sgdu in final_reconstructed_supergdu_features:
					if (reconstructed_sgdu.is_point_in_polygon(mid_point)):
						is_valid = False
						break
					# if (pygplates.GeometryOnSphere.distance(reconstructed_sgdu,temp_polyline) == 0.00):
						# temp_rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, closest_ocean_crust_ft.get_reconstruction_plate_id(), sgdu_ft.get_reconstruction_plate_id(), reconstruction_time+time_interval, reconstruction_time, reference)
						# if (temp_rel_stage_rot is not None):
							# if (temp_rel_stage_rot.represents_identity_rotation() == False):
								# is_valid = False
								# break
				if (is_valid == False):
					closest_ocean_crust_ft = None
			if (closest_ocean_crust_ft is not None):
				E_pole,angle_rads = final_stage_of_rot.get_euler_pole_and_angle()
				#evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(reconstructed_point_A_at_to_time, reconstructed_point_B_at_to_time, Euler_pole)
				#A.(E_of_B_rel_to_A x B)
				result_of_tectonic_motion,dot_product = evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(bdn.get_centroid(), closest_ocean.get_interior_centroid(), E_pole)
				
				#{'reconstruction_time':[],'polylid':[],'ocean':[],'type':[],'from_time':[],'to_time':[]}
				
				if (result_of_tectonic_motion == 'C'):
					new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, bdn, valid_time = (reconstruction_time,end_age_of_plate_bdn_zone))
					new_subduction_ft.set_name(plate_bdn_ft.get_name())
					new_subduction_ft.set_reconstruction_plate_id(plate_bdn_ft.get_reconstruction_plate_id())
					oldest_age_of_oc_ft,_ = closest_ocean_crust_ft.get_valid_time()
					name_of_oc_ft = closest_ocean_crust_ft.get_name()+"+"+str(oldest_age_of_oc_ft)
					new_subduction_ft.set_description("subduction_zone")
					if (reference is not None):
						pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
					else:
						pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
					dic_subduction_zone[new_subduction_ft.get_name()] = new_subduction_ft
					output_dic['reconstruction_time'].append(reconstruction_time)
					output_dic['polylid'].append(plate_bdn_ft.get_name())
					output_dic['ocean'].append(closest_ocean_crust_ft.get_name())
					output_dic['type'].append('subduction_zone')
					output_dic['dot_prod'].append(dot_product)
					output_dic['from_time'].append(reconstruction_time)
					output_dic['to_time'].append(end_age_of_plate_bdn_zone)
				elif (result_of_tectonic_motion == 'T'):
					new_trans_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_transform, bdn, valid_time = (reconstruction_time,end_age_of_plate_bdn_zone))
					new_trans_ft.set_name(plate_bdn_ft.get_name())
					new_trans_ft.set_reconstruction_plate_id(plate_bdn_ft.get_reconstruction_plate_id())
					oldest_age_of_oc_ft,_ = closest_ocean_crust_ft.get_valid_time()
					name_of_oc_ft = closest_ocean_crust_ft.get_name()+"+"+str(oldest_age_of_oc_ft)
					new_trans_ft.set_description("transform_fault")
					if (reference is not None):
						pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time, reference)
					else:
						pygplates.reverse_reconstruct(new_trans_ft, rotation_model, reconstruction_time)
					dic_subduction_zone[new_trans_ft.get_name()] = new_trans_ft
					output_dic['reconstruction_time'].append(reconstruction_time)
					output_dic['polylid'].append(plate_bdn_ft.get_name())
					output_dic['ocean'].append(closest_ocean_crust_ft.get_name())
					output_dic['type'].append('transform_fault')
					output_dic['dot_prod'].append(dot_product)
					output_dic['from_time'].append(reconstruction_time)
					output_dic['to_time'].append(end_age_of_plate_bdn_zone)
				elif (result_of_tectonic_motion == 'D'): 
					final_mid_point = find_the_mid_of_two_PointOnSphere(closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust)
					approx_mid_point = None
					if (closest_km_dist == 0.00):
						approx_mid_point = find_the_mid_of_two_PointOnSphere(bdn.get_centroid(),closest_ocean.get_interior_centroid())
					else:
						approx_mid_point = final_mid_point
					#create an arc
					temporary_GreatCircleArc = pygplates.GreatCircleArc(approx_mid_point,E_pole)
					normal_unit_vector = temporary_GreatCircleArc.get_great_circle_normal()
					left_gduid, right_gduid = identify_left_gdu_and_right_gdu(normal_unit_vector, approx_mid_point, closest_pt_on_plate_bdn, closest_pt_on_oceanic_crust, plate_bdn_ft.get_reconstruction_plate_id(), closest_ocean_crust_ft.get_reconstruction_plate_id())
					#after finding left and right gduid we have to change approx_mid_point even if there are not distinguish among three points
					
					name = closest_ocean_crust_ft.get_name()+"+"+plate_bdn_ft.get_name()
					rift_point_ft = pygplates.Feature.create_tectonic_section(pygplates.FeatureType.gpml_mid_ocean_ridge, final_mid_point, name = name, valid_time = (reconstruction_time,0.00))
					if ((left_gduid == right_gduid) or (left_gduid is None) or (right_gduid is None)):
						rift_point_ft.set_left_plate(plate_bdn_ft.get_reconstruction_plate_id())
						rift_point_ft.set_right_plate(closest_ocean_crust_ft.get_reconstruction_plate_id())
					else:
						rift_point_ft.set_left_plate(left_gduid)
						rift_point_ft.set_right_plate(right_gduid)
					rift_point_ft.set_reconstruction_method('HalfStageRotationVersion2')
					if (reference is None):
						pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time)
					else:
						pygplates.reverse_reconstruct(rift_point_ft,rotation_model,reconstruction_time,reference)
					output_rift_point_features.add(rift_point_ft)

					new_div_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_passive_continental_boundary, bdn, valid_time = (reconstruction_time,end_age_of_plate_bdn_zone))
					new_div_ft.set_name(plate_bdn_ft.get_name())
					new_div_ft.set_reconstruction_plate_id(plate_bdn_ft.get_reconstruction_plate_id())
					oldest_age_of_oc_ft,_ = closest_ocean_crust_ft.get_valid_time()
					name_of_oc_ft = closest_ocean_crust_ft.get_name()+"+"+str(oldest_age_of_oc_ft)
					new_div_ft.set_description('divergent_margin')
					if (reference is not None):
						pygplates.reverse_reconstruct(new_div_ft, rotation_model, reconstruction_time, reference)
					else:
						pygplates.reverse_reconstruct(new_div_ft, rotation_model, reconstruction_time)
					dic_subduction_zone[new_div_ft.get_name()] = new_div_ft
					output_dic['reconstruction_time'].append(reconstruction_time)
					output_dic['polylid'].append(plate_bdn_ft.get_name())
					output_dic['ocean'].append(closest_ocean_crust_ft.get_name())
					output_dic['type'].append('divergent_margin')
					output_dic['dot_prod'].append(dot_product)
					output_dic['from_time'].append(reconstruction_time)
					output_dic['to_time'].append(end_age_of_plate_bdn_zone)
		# for plate_bdn_ft, bdn in final_reconstructed_subduction_zone: #i might not need to check because the entire period the bdn feature is classified as plate_boundary_zone
			# fixed_plate_id = plate_bdn_ft.get_reconstruction_plate_id()
			# is_continuously_subducted = False
			# is_divergent = False
			# wanted_records_of_kinematic_line_from_div_df = kinematic_line_from_div_df.loc[((kinematic_line_from_div_df['polylid1'] == plate_bdn_ft.get_name()) | (kinematic_line_from_div_df['polylid2'] == plate_bdn_ft.get_name())) & (kinematic_line_from_div_df['type_kin'] != 'convergent_margin') & (kinematic_line_from_div_df['type_kin'] != 'plate_boundary_zone') & (abs(kinematic_line_from_div_df['from_time'] - reconstruction_time) <= (time_interval*0.500)),'from_time']
			# if (len(wanted_records_of_kinematic_line_from_div_df) > 0):
				# is_divergent = True
			# # if (is_divergent == False):
				# # for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
					# # moving_plate_id = oceanic_crust_ft.get_reconstruction_plate_id()
					# # rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, reconstruction_time+time_interval, reconstruction_time, reference)
					# # if (rel_stage_rot is not None):
						# # if (rel_stage_rot.represents_identity_rotation() == False):
							# # closest_rad_dist,pt_on_plate_bdn,pt_on_oceanic_crust = pygplates.GeometryOnSphere.distance(bdn, reconstructed_ocean, return_closest_positions = True)
							# # closest_km_dist = -1.00
							# # if (closest_rad_dist == 0.00):
								# # closest_km_dist = 0.00
							# # else:
								# # lat_plate_bdn,lon_plate_bdn = pt_on_plate_bdn.to_lat_lon()
								# # lat_ocean_crust,lon_ocean_crust = pt_on_oceanic_crust.to_lat_lon()
								# # closest_km_dist = calculate_distance_km_between_two_points_from_haversine_formula(lat_plate_bdn,lon_plate_bdn,lat_ocean_crust,lon_ocean_crust)
							# # if (closest_km_dist >= 0.00 and closest_km_dist <= 150.00):
								# # is_continuously_subducted = True
								# # break
			# # if (is_continuously_subducted == False and is_divergent == True):
				# # #edit the end time of subduction feature
				# # current_subduction_ft = dic_subduction_zone[plate_bdn_ft.get_name()]
				# # current_begin_subduction_age,_ = current_subduction_ft.get_valid_time()
				# # current_subduction_ft.set_valid_time(current_begin_subduction_age,reconstruction_time)
				# # output_subduction_zones.add(current_subduction_ft.clone())
				# # del dic_subduction_zone[plate_bdn_ft.get_name()]
			
			# if (line features subductions):
			# if (is_divergent == True):
				# #edit the end time of subduction feature
				# current_subduction_ft = dic_subduction_zone[plate_bdn_ft.get_name()]
				# current_begin_subduction_age,_ = current_subduction_ft.get_valid_time()
				# current_subduction_ft.set_valid_time(current_begin_subduction_age,reconstruction_time)
				# output_subduction_zones.add(current_subduction_ft.clone())
				# del dic_subduction_zone[plate_bdn_ft.get_name()]
			# if (line features transform):
			# if (line features divergence)
		reconstruction_time = reconstruction_time - time_interval
	if (len(dic_subduction_zone) > 0):
		for subduction_name in dic_subduction_zone:
			subduction_ft = dic_subduction_zone[subduction_name]
			if (subduction_ft is not None):
				output_subduction_zones.add(subduction_ft)
	print("output_subduction_zones",output_subduction_zones)
	output_subduction_zones.write("informed_plate_bdn_features_from_interacting_oceanic_crust_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
	output_rift_point_features.write("rift_point_features_from_interacting_oceanic_crust_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
	df_interacts_bdn = pd.DataFrame.from_dict(output_dic)
	df_interacts_bdn.to_csv("records_of_plate_bdn_interact_w_oceanic_crust_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".csv",index=False)


def evaluate_oceanic_crust_features_with_convergent_features(oceanic_crust_features, convergent_features, rotation_model, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, threshold_distance_km, reference, modelname, yearmonthday):
	# oceanic_crust_features_to_be_evaluated = pygplates.FeatureCollection()
	# for oceanic_ft in oceanic_crust_features:
		# oceanic_ft_begin_age,oceanic_ft_end_age = oceanic_ft.get_valid_time()
		# is_included = True
		# if (oceanic_ft_begin_age < minimum_reconstruction_time or oceanic_ft_end_age > maximum_reconstruction_time):
			# is_included = False
		# if (is_included == True):
			# oceanic_crust_features_to_be_evaluated.add(oceanic_ft)
	
	output_dic = {'reconstruction_time':[],'polylid':[],'ocean':[],'type':[], 'from_time':[], 'to_time':[]}
	
	oceanic_crust_features_to_be_evaluated = oceanic_crust_features
	
	reconstruction_time = maximum_reconstruction_time
	reconstructed_oceanic_features = []
	reconstructed_bdn_features = []
	valid_plate_bdn_zone_features = []
	unique_pairs_of_rift_name = []
	dic_subduction_zone = {}
	valid_supergdu_features = []
	output_subduction_zones = pygplates.FeatureCollection()
	while (reconstruction_time >= minimum_reconstruction_time):
		valid_plate_bdn_zone_features[:] = []
		#find valid oceanic crust features
		valid_oceanic_crust_features = [oceanic_ft for oceanic_ft in oceanic_crust_features_to_be_evaluated if oceanic_ft.is_valid_at_time(reconstruction_time)]
		for bdn_ft in convergent_features:
			if (bdn_ft.is_valid_at_time(reconstruction_time) and bdn_ft.get_description() == 'convergent_margin'):
				if (bdn_ft.get_name() not in dic_subduction_zone):
					valid_plate_bdn_zone_features.append(bdn_ft)
				# else:
					# subduction_ft = dic_subduction_zone[bdn_ft.get_name()]
					# subduction_zone_features.append(subduction_ft)
				else:
					subduction_ft = dic_subduction_zone[bdn_ft.get_name()]
					if (subduction_ft.is_valid_at_time(reconstruction_time) == False):
						valid_plate_bdn_zone_features.append(bdn_ft)
						output_subduction_zones.add(subduction_ft.clone())
						del dic_subduction_zone[bdn_ft.get_name()]
		
		reconstructed_oceanic_features[:] = []
		reconstructed_bdn_features[:] = []
		if (reference is not None):
			pygplates.reconstruct(valid_oceanic_crust_features, rotation_model, reconstructed_oceanic_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
			pygplates.reconstruct(valid_plate_bdn_zone_features, rotation_model, reconstructed_bdn_features, reconstruction_time, anchor_plate_id = reference, group_with_feature = True)
		else:
			pygplates.reconstruct(valid_oceanic_crust_features, rotation_model, reconstructed_oceanic_features, reconstruction_time, group_with_feature = True)
			pygplates.reconstruct(valid_plate_bdn_zone_features, rotation_model, reconstructed_bdn_features, reconstruction_time, group_with_feature = True)
		#find final reconstruct oceanic crust features
		final_reconstructed_oceanic_feats = find_final_reconstructed_geometries(reconstructed_oceanic_features, pygplates.PolygonOnSphere)
		final_reconstructed_plate_bdn_zone = find_final_reconstructed_geometries(reconstructed_bdn_features, pygplates.PolylineOnSphere)
		for plate_bdn_ft, bdn in final_reconstructed_plate_bdn_zone:
			fixed_plate_id = plate_bdn_ft.get_reconstruction_plate_id()
			_,end_age_of_plate_bdn_zone = plate_bdn_ft.get_valid_time()
			# for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
				# moving_plate_id = oceanic_crust_ft.get_reconstruction_plate_id()
				# rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, reconstruction_time+time_interval, reconstruction_time, reference)
				# if (rel_stage_rot is not None):
					# if (rel_stage_rot.represents_identity_rotation() == False):
						# closest_rad_dist,pt_on_plate_bdn,pt_on_oceanic_crust = pygplates.GeometryOnSphere.distance(bdn, reconstructed_ocean, return_closest_positions = True)
						# closest_km_dist = -1.00
						# if (closest_rad_dist == 0.00):
							# closest_km_dist = 0.00
							# break
						# else:
							# lat_plate_bdn,lon_plate_bdn = pt_on_plate_bdn.to_lat_lon()
							# lat_ocean_crust,lon_ocean_crust = pt_on_oceanic_crust.to_lat_lon()
							# closest_km_dist = calculate_distance_km_between_two_points_from_haversine_formula(lat_plate_bdn,lon_plate_bdn,lat_ocean_crust,lon_ocean_crust)
						# if (closest_km_dist >= 0.00 and closest_km_dist <= 150.00):
							# new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, bdn, valid_time = (reconstruction_time,end_age_of_plate_bdn_zone))
							# new_subduction_ft.set_name(plate_bdn_ft.get_name())
							# new_subduction_ft.set_reconstruction_plate_id(plate_bdn_ft.get_reconstruction_plate_id())
							# oldest_age_of_oc_ft,_ = oceanic_crust_ft.get_valid_time()
							# name_of_oc_ft = oceanic_crust_ft.get_name()+"+"+str(oldest_age_of_oc_ft)
							# new_subduction_ft.set_description(name_of_oc_ft)
							# if (reference is not None):
								# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
							# else:
								# pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
							# dic_subduction_zone[new_subduction_ft.get_name()] = new_subduction_ft
							# break
			closest_km_dist = -1.00 #find the closest oceanic crust features
			closest_ocean_crust_ft, closest_ocean = None, None
			closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust = None, None
			final_stage_of_rot = None

			for oceanic_crust_ft, reconstructed_ocean in final_reconstructed_oceanic_feats:
				moving_plate_id = oceanic_crust_ft.get_reconstruction_plate_id()
				rel_stage_rot = find_stage_relative_reconstruction_rotation_(rotation_model, moving_plate_id, fixed_plate_id, reconstruction_time+time_interval, reconstruction_time, reference)
				if (rel_stage_rot is not None):
					if (rel_stage_rot.represents_identity_rotation() == False):
						closest_rad_dist,pt_on_plate_bdn,pt_on_oceanic_crust = pygplates.GeometryOnSphere.distance(bdn, reconstructed_ocean, return_closest_positions = True)
						if (closest_rad_dist == 0.00):
							closest_km_dist = 0.00
							closest_ocean_crust_ft, closest_ocean = oceanic_crust_ft, reconstructed_ocean
							closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust = pt_on_plate_bdn,pt_on_oceanic_crust
							final_stage_of_rot = rel_stage_rot
							break
						else:
							lat_plate_bdn,lon_plate_bdn = pt_on_plate_bdn.to_lat_lon()
							lat_ocean_crust,lon_ocean_crust = pt_on_oceanic_crust.to_lat_lon()
							new_km_dist = calculate_distance_km_between_two_points_from_haversine_formula(lat_plate_bdn,lon_plate_bdn,lat_ocean_crust,lon_ocean_crust)
							if (closest_km_dist > -1.00 and closest_km_dist > new_km_dist):
								closest_km_dist = new_km_dist
								closest_ocean_crust_ft, closest_ocean = oceanic_crust_ft, reconstructed_ocean
								closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust = pt_on_plate_bdn,pt_on_oceanic_crust
								final_stage_of_rot = rel_stage_rot
							elif (closest_km_dist == -1.00):
								closest_km_dist = new_km_dist
								closest_ocean_crust_ft, closest_ocean = oceanic_crust_ft, reconstructed_ocean
								closest_pt_on_plate_bdn,closest_pt_on_oceanic_crust = pt_on_plate_bdn,pt_on_oceanic_crust
								final_stage_of_rot = rel_stage_rot
			
			is_valid = True
			if (closest_km_dist >= 0.00 and closest_km_dist <= threshold_distance_km):
				is_valid = True
			else:
				if (is_valid == False):
					closest_ocean_crust_ft = None
			if (closest_ocean_crust_ft is not None):
				E_pole,angle_rads = final_stage_of_rot.get_euler_pole_and_angle()
				#evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(reconstructed_point_A_at_to_time, reconstructed_point_B_at_to_time, Euler_pole)
				#A.(E_of_B_rel_to_A x B)
				result_of_tectonic_motion,dot_product = evaluate_tectonic_motion_btw_reconstructed_point_A_and_B_using_Euler_pole(bdn.get_centroid(), closest_ocean.get_interior_centroid(), E_pole)
				#{'reconstruction_time':[],'polylid':[],'ocean':[],'type':[],'from_time':[],'to_time':[]}
				
				if (result_of_tectonic_motion == 'C'):
					new_subduction_ft = pygplates.Feature.create_reconstructable_feature(pygplates.FeatureType.gpml_subduction_zone, bdn, valid_time = (reconstruction_time,end_age_of_plate_bdn_zone))
					new_subduction_ft.set_name(plate_bdn_ft.get_name())
					new_subduction_ft.set_reconstruction_plate_id(plate_bdn_ft.get_reconstruction_plate_id())
					new_subduction_ft.set_left_plate(plate_bdn_ft.get_left_plate())
					new_subduction_ft.set_right_plate(plate_bdn_ft.get_right_plate())
					oldest_age_of_oc_ft,_ = closest_ocean_crust_ft.get_valid_time()
					name_of_oc_ft = closest_ocean_crust_ft.get_name()+"+"+str(oldest_age_of_oc_ft)
					new_subduction_ft.set_description("subduction_zone")
					if (reference is not None):
						pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time, reference)
					else:
						pygplates.reverse_reconstruct(new_subduction_ft, rotation_model, reconstruction_time)
					dic_subduction_zone[new_subduction_ft.get_name()] = new_subduction_ft
					output_dic['reconstruction_time'].append(reconstruction_time)
					output_dic['polylid'].append(plate_bdn_ft.get_name())
					output_dic['ocean'].append(name_of_oc_ft)
					output_dic['type'].append('subduction_zone')
					output_dic['from_time'].append(reconstruction_time)
					output_dic['to_time'].append(end_age_of_plate_bdn_zone)
		reconstruction_time = reconstruction_time - time_interval
	if (len(dic_subduction_zone) > 0):
		for subduction_name in dic_subduction_zone:
			subduction_ft = dic_subduction_zone[subduction_name]
			if (subduction_ft is not None):
				output_subduction_zones.add(subduction_ft)
	print("output_subduction_zones",output_subduction_zones)
	output_subduction_zones.write("informed_conv_bdn_features_from_interacting_oceanic_crust_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".shp")
	
	df_interacts_bdn = pd.DataFrame.from_dict(output_dic)
	df_interacts_bdn.to_csv("records_of_conv_bdn_interact_w_oceanic_crust_"+str(maximum_reconstruction_time)+"_"+str(minimum_reconstruction_time)+"_"+modelname+"_"+yearmonthday+".csv",index=False)

def main():
	# input_point_features_file = r"isochron_right_point_features_test_22_PalaeoPlatesJan2023_fts_from_early_July_max_1000.0_800_20230712.shp"
	# input_point_features = pygplates.FeatureCollection(input_point_features_file)
	# rift_point_features_records_csv = r"rift_point_features_records_for_test_20_short_PalaeoPlatesendOct2022_w_1_deg_20230705.csv"
	# maximum_reconstruction_time = 1000.00
	# minimum_reconstruction_time = 800.00
	# modelname = 'Left_PalaeoPlatesendJan2023'
	# yearmonthday = '20230718'
	# create_isochron_from_temp_isochron_point_features(input_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, modelname, yearmonthday)
	
	#modified_rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	#modified_rift_point_features = pygplates.FeatureCollection(modified_rift_point_features_file)
	rift_point_features_records_csv = r"rift_point_features_records_for_test_29_short_PalaeoPlatesendJan2023_20231020.csv"
	maximum_reconstruction_time = 2800.00
	minimum_reconstruction_time = 0.00
	age_interval_for_isochron_fts = 5.00
	modelname = r"v4_PalaeoPlatesendJan2023"
	yearmonthday = "20231123"
	#create_topological_rift_zones(modified_rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, modelname, yearmonthday)
	
	#div_margin_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\tectonic_boundaries\diverging_line_features_for_2800.0_5.0_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	div_margin_features_file = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\all_div_margin_PalaeoPlatesendJan2023_from_both_kin_processes_and_unrelated_SGDU_20240304.shp"
	div_margin_features = pygplates.FeatureCollection(div_margin_features_file)
	#create_topological_MOR_to_represent_each_div_margin(div_margin_features,modified_rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, modelname, yearmonthday)
	
	#PalaeoPlatesendJan2023
	#common_filename_for_temporary_sgdu_and_members_csv = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\supergdu_and_members_gdu_at_{time}_for_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_20230425.csv"
	#sgdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	#sgdu_features = pygplates.FeatureCollection(sgdu_features_file)
	rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	rotation_model = pygplates.RotationModel(rotation_file)
	#rift_point_features_file = r"modified_end_age_of_rift_point_features_for_v2_test_29_short_PalaeoPlatesendJan2023_20231020.shp"
	rift_point_features_file = "modified_end_age_of_rift_point_features_based_on_kinematic_records_and_sgdu_2800.0_test_29_PalaeoPlatesendJan2023_fts_20240304.shp"
	rift_point_features = pygplates.FeatureCollection(rift_point_features_file)
	#temp_unwanted_rift_point_features_file = r"unwanted_rift_point_features_for_version_5_test_8_EB2022_20231020.shp"
	#temp_unwanted_rift_point_features = pygplates.FeatureCollection(temp_unwanted_rift_point_features_file)
	#div_margin_feats_file = r"C:\Users\lavie\Desktop\Research\Summer2023\utility\extract_features_based_on_descriptiondivergent_margin_PalaeoPlatesendJan2023_2800_5Ma_from_test_29_identify_div_bdn_20231106.shp"
	#div_margin_features = pygplates.FeatureCollection(div_margin_feats_file)
	
	
	maximum_reconstruction_time,minimum_reconstruction_time = 200.0,0.0
	age_interval_for_isochron_fts = 5.00
	#input_point_features_file = r"isochron_right_point_features_v2_test_29_PalaeoPlatesendJan2023_fts_max_400.0_200.0_20231102.shp"
	#right_input_point_features = pygplates.FeatureCollection(input_point_features_file)
	#input_point_features_file = r"isochron_left_point_features_v2_test_29_PalaeoPlatesendJan2023_fts_max_400.0_200.0_20231102.shp"
	#left_input_point_features = pygplates.FeatureCollection(input_point_features_file)
	yearmonthday = "20240319"
	modelname = 'modified_rift_point_test_29_PalaeoPlatesendJan2023'
	reference = 700
	time_interval = 5.00
	
	#create_oceanic_crust_from_rift_and_isochron_point_features_w_distinct_pairs_of_sgdus(div_margin_features, left_input_point_features, right_input_point_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday)
	
	# oceanic_crust_features_file = r"oceanic_crust_for_gdus_from_rift_and_isochron_feats_with_max_star_div_age_200.0_min_0.0_test_1_PalaeoPlatesendJan2023_20231211.shp"
	# oceanic_crust_features = pygplates.FeatureCollection(oceanic_crust_features_file)
	# supergdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
	# rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	# modified_end_age_of_invalid_temporary_oceanic_crust_polygon_features(common_filename_for_temporary_sgdu_and_members_csv, rift_point_features_records_csv, oceanic_crust_features, supergdu_features, rotation_model, reference, maximum_reconstruction_time, minimum_reconstruction_time, time_interval, modelname, yearmonthday)
	
	# oceanic_crust_features_file = r"oceanic_crust_from_rift_and_isochron_point_features_with_max_star_div_age_200.0_min_0.0_test_29_PalaeoPlatesendJan2023_20231106.shp"
	# oceanic_crust_features = pygplates.FeatureCollection(oceanic_crust_features_file)
	# supergdu_features_file = r"C:\Users\lavie\Desktop\Research\Winter2023\superGDU\final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
	# rotation_file = r"C:\Users\lavie\Desktop\Research\Winter2023\PalaeoPlatesJan2023\T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	
	# oceanic_crust_features_file = r"oceanic_crust_from_rift_and_isochron_point_features_with_max_star_div_age_200.0_min_0.0_test_29_PalaeoPlatesendJan2023_20231106.shp"
	# oceanic_crust_features = pygplates.FeatureCollection(oceanic_crust_features_file)
	# supergdu_features_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/superGDU/temp_working/final_supergdu_feats_3420.0_0.0_test_6_QGIS_fixed_PalaeoPlatesJan2023_w_valid_rot_1000km_polygid_20230425.shp"
	# supergdu_features = pygplates.FeatureCollection(supergdu_features_file)
	# rotation_file = r"/globalhome/hon686/HPC/Geology/Research/Winter2023/PalaeoPlatesendJan2023/T_Rot_Model_PalaeoPlates_20230125.grot"
	# rotation_model = pygplates.RotationModel(rotation_file)
	
	
	# reference = 700
	# maximum_reconstruction_time = 200.00
	# time_interval = 5.00
	# yearmonthday = "20231203"
	#modified_end_age_of_temporary_oceanic_crust_polygon_features(oceanic_crust_features, supergdu_features, rotation_model, reference, maximum_reconstruction_time, time_interval, modelname, yearmonthday)
	
	extend_boundary_of_each_sgdu_from_rift_point_features_w_distinct_pairs_of_sgdus(div_margin_features, rift_point_features, rift_point_features_records_csv, maximum_reconstruction_time, minimum_reconstruction_time, age_interval_for_isochron_fts, rotation_model, reference, modelname, yearmonthday)
	
# if __name__ == '__main__':
	# main()